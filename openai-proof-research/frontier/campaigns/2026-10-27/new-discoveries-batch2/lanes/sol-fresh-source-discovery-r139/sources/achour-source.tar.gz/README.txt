This arXiv source package contains the LaTeX source for:

A Degree-Spread Bound Between Independent Domination and Minimum Maximal Matchings: A Conjecture

Author: Hassine Achour
Contact: hassine.achour@gmail.com
Zenodo DOI: 10.5281/zenodo.21806398

The manuscript compiles with pdflatex and uses only standard packages.
