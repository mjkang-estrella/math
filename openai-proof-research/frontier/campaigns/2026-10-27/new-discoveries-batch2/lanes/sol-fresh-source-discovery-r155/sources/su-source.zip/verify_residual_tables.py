#!/usr/bin/env python3
"""Independent consistency checks for selected residual tables in Appendix F.

This script is supplementary only.  The manuscript proofs are algebraic and
self-contained.  Here we reconstruct the finite signed-class residual lists
used in the p=17/19, p=23, and p=35 arguments, and check that every displayed
certificate is a legal four-leaf +,-,* expression that vanishes modulo p.

No third-party packages are required.
"""

from __future__ import annotations

import ast
import itertools
import math
from collections import Counter


def signed_rep(x: int, p: int) -> int:
    """Canonical representative of [x]={x,-x} modulo odd p."""
    r = x % p
    if r == 0:
        return 0
    return min(r, p - r)


def pairings4():
    return [((0, 1), (2, 3)), ((0, 2), (1, 3)), ((0, 3), (1, 2))]


def pair_to_third(S, p: int) -> bool:
    for i, j, k in itertools.permutations(range(4), 3):
        if len({i, j, k}) < 3:
            continue
        if signed_rep(S[i] * S[j], p) == S[k]:
            return True
    return False


def equal_disjoint_pair_products(S, p: int) -> bool:
    for (i, j), (k, l) in pairings4():
        if signed_rep(S[i] * S[j], p) == signed_rep(S[k] * S[l], p):
            return True
    return False


def cset(r: int, s: int, p: int):
    return {
        signed_rep(r * s, p),
        signed_rep(r + s, p),
        signed_rep(r - s, p),
    }


def reconstruct_17_19(p: int):
    classes = range(1, (p - 1) // 2 + 1)
    out = []
    for S in itertools.combinations(classes, 4):
        if 1 not in S:
            continue
        if pair_to_third(S, p):
            continue
        if equal_disjoint_pair_products(S, p):
            continue
        out.append(S)
    return out


def reconstruct_23():
    p = 23
    out = []
    for x, y, z in itertools.combinations(range(2, 12), 3):
        S = (1, x, y, z)
        if cset(1, x, p) & cset(y, z, p):
            continue
        if cset(1, y, p) & cset(x, z, p):
            continue
        if cset(1, z, p) & cset(x, y, p):
            continue
        if pair_to_third(S, p):
            continue
        if equal_disjoint_pair_products(S, p):
            continue
        out.append((x, y, z))
    return out


def local_collision(a: int, b: int, p: int) -> bool:
    return signed_rep(a, p) == signed_rep(b, p)


def split_local_5_7(S) -> bool:
    for (i, j), (k, l) in pairings4():
        if local_collision(S[i], S[j], 5) and local_collision(S[k], S[l], 7):
            return True
        if local_collision(S[i], S[j], 7) and local_collision(S[k], S[l], 5):
            return True
    return False


def reconstruct_35():
    units = [r for r in range(1, 18) if math.gcd(r, 35) == 1]
    out = []
    for S in itertools.combinations(units, 4):
        if split_local_5_7(S):
            continue
        if pair_to_third(S, 35):
            continue
        if equal_disjoint_pair_products(S, 35):
            continue
        out.append(S)
    return out


def assert_legal_read_once(expr: str, variables) -> None:
    tree = ast.parse(expr, mode="eval")
    allowed = (ast.Expression, ast.BinOp, ast.Add, ast.Sub, ast.Mult, ast.Name, ast.Load)
    for node in ast.walk(tree):
        if not isinstance(node, allowed):
            raise AssertionError(f"disallowed syntax in {expr!r}: {type(node).__name__}")
    names = Counter(node.id for node in ast.walk(tree) if isinstance(node, ast.Name))
    expected = Counter(variables)
    if names != expected:
        raise AssertionError(f"not read-once on {variables}: {expr!r} has variables {dict(names)}")


def eval_expr(expr: str, values: dict[str, int]) -> int:
    return int(eval(compile(ast.parse(expr, mode="eval"), "<certificate>", "eval"), {"__builtins__": {}}, values))


def check_rows(p: int, rows, variables):
    for reps, expr in rows:
        assert len(reps) == len(variables)
        assert_legal_read_once(expr, variables)
        val = eval_expr(expr, dict(zip(variables, reps)))
        if val % p != 0:
            raise AssertionError(f"p={p}, reps={reps}, expr={expr}, value={val}")


ROWS_17 = [
    ((1,2,3,4), "(a+b-c)*d"),
    ((1,2,4,5), "(a+b)*c+d"),
    ((1,2,4,6), "a*b+c-d"),
    ((1,2,4,7), "a+b+c-d"),
    ((1,2,6,7), "a-b-c+d"),
    ((1,3,4,8), "a+b+c-d"),
    ((1,3,5,8), "a+b+c+d"),
    ((1,4,5,8), "(a+b-c)*d"),
    ((1,4,6,8), "a-b-c-d"),
    ((1,4,7,8), "c+(a-b)*d"),
]

ROWS_19 = [
    ((1,2,3,4), "(a+b-c)*d"),
    ((1,2,3,5), "(a+b-c)*d"),
    ((1,2,4,6), "a*b+c-d"),
    ((1,2,4,7), "a+b+c-d"),
    ((1,2,5,6), "a-b-c+d"),
    ((1,2,6,8), "a*b+c-d"),
    ((1,3,4,8), "a+b+c-d"),
    ((1,3,4,9), "(a+b-c)*d"),
    ((1,3,5,9), "a+b+c-d"),
    ((1,3,7,9), "(a+b)*c-d"),
    ((1,4,6,9), "a-b-c+d"),
    ((1,5,6,7), "a+b+c+d"),
    ((1,5,6,9), "(a+b-c)*d"),
    ((1,5,8,9), "(a+b)*c+d"),
]

ROWS_23 = [
    ((1,2,3,9), "(a+x-y)*z"),
    ((1,3,5,11), "x*(a-y)-z"),
    ((1,4,5,11), "(a+x-y)*z"),
    ((1,4,7,8), "x*(a+y-z)"),
    ((1,4,7,9), "(a+y)*x-z"),
    ((1,6,7,8), "(a+x-y)*z"),
    ((1,6,8,11), "(a+x)*z-y"),
    ((1,8,9,10), "(a-z+y)*x"),
    ((1,9,10,11), "(a-z+y)*x"),
]

ROWS_35 = [
    ((1,2,3,4), "(a+b-c)*d"),
    ((1,2,3,9), "(a+b-c)*d"),
    ((1,2,4,6), "a*b+c-d"),
    ((1,2,4,11), "b-(a-c)*d"),
    ((1,2,4,13), "a+b*(c*d)"),
    ((1,2,6,11), "a-b*c+d"),
    ((1,2,8,11), "a-b*(c*d)"),
    ((1,3,6,9), "a*b+c-d"),
    ((1,3,6,16), "a+b*c+d"),
    ((1,3,8,16), "a+b*(c*d)"),
    ((1,3,9,13), "a-b*(c*d)"),
    ((1,3,9,16), "a+b-c*d"),
    ((1,4,6,12), "a-b*c-d"),
    ((1,4,8,12), "a+b*(c*d)"),
    ((1,4,11,12), "b*(a+c-d)"),
    ((1,4,12,17), "b*(a+c)-d"),
    ((1,6,9,17), "a-b*c-d"),
    ((1,6,11,12), "b*(a+c-d)"),
    ((1,6,16,17), "b*(a+c-d)"),
    ((1,8,9,17), "a+b*(c*d)"),
    ((1,9,12,17), "a+c-b*d"),
    ((1,9,16,17), "a-b-c*d"),
    ((1,11,12,13), "a-b*(c*d)"),
    ((1,13,16,17), "a-b*(c*d)"),
    ((4,8,11,16), "b-c*(a-d)"),
    ((4,11,13,16), "b-a*(c+d)"),
    ((8,9,11,16), "a*(b-c)+d"),
    ((9,11,13,16), "a*b-c-d"),
]


def main():
    exp17 = [r for r, _ in ROWS_17]
    exp19 = [r for r, _ in ROWS_19]
    exp23 = [(r[1], r[2], r[3]) for r, _ in ROWS_23]
    exp35 = [r for r, _ in ROWS_35]

    assert reconstruct_17_19(17) == exp17
    assert reconstruct_17_19(19) == exp19
    assert reconstruct_23() == exp23
    assert reconstruct_35() == exp35

    check_rows(17, ROWS_17, ("a","b","c","d"))
    check_rows(19, ROWS_19, ("a","b","c","d"))
    check_rows(23, ROWS_23, ("a","x","y","z"))
    check_rows(35, ROWS_35, ("a","b","c","d"))

    print("PASS: reconstructed residual lists and verified all displayed certificates")
    print(f"  p=17: {len(exp17)} residual signed-class configurations")
    print(f"  p=19: {len(exp19)} residual signed-class configurations")
    print(f"  p=23: {len(exp23)} residual signed-class configurations")
    print(f"  p=35: {len(exp35)} residual signed-class configurations")


if __name__ == "__main__":
    main()
