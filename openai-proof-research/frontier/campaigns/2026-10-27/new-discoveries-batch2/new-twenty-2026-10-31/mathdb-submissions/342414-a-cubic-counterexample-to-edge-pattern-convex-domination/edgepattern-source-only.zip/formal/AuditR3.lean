import AuditR2
import BridgeR3
import InvarianceR2
import ReductionR2
import Invariance
import Concrete
import Canonical
import Separation
import Lean.Util.CollectAxioms
open Lean
set_option pp.all true
set_option pp.universes true
set_option pp.proofs true
set_option pp.maxSteps 2000000
set_option pp.deepTerms true
namespace AuditR3
abbrev Store := Lean.ExprStructMap Nat × Array String

def encode (e : Expr) : StateM Store Nat := do
  if let some id := (← get).1.get? ⟨e⟩ then return id
  let row ← match e with
    | .bvar i => pure s!"bvar {i}"
    | .fvar i => pure s!"fvar {reprStr i}"
    | .mvar i => pure s!"mvar {reprStr i}"
    | .sort l => pure s!"sort {reprStr l}"
    | .const n ls => pure s!"const {reprStr n} {reprStr ls}"
    | .app f a => do
        let f ← encode f
        let a ← encode a
        pure s!"app {f} {a}"
    | .lam n t b bi => do
        let t ← encode t
        let b ← encode b
        pure s!"lam {reprStr n} {t} {b} {reprStr bi}"
    | .forallE n t b bi => do
        let t ← encode t
        let b ← encode b
        pure s!"forallE {reprStr n} {t} {b} {reprStr bi}"
    | .letE n t v b nd => do
        let t ← encode t
        let v ← encode v
        let b ← encode b
        pure s!"letE {reprStr n} {t} {v} {b} {nd}"
    | .lit v => pure s!"lit {reprStr v}"
    | .mdata md b => do
        let b ← encode b
        pure s!"mdata {reprStr md} {b}"
    | .proj n i b => do
        let b ← encode b
        pure s!"proj {reprStr n} {i} {b}"
  let id := (← get).2.size
  modify fun (memo, rows) => (memo.insert ⟨e⟩ id, rows.push row)
  return id
termination_by e
end AuditR3

run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  let mut store : AuditR3.Store := ({}, #[])
  for (n, ci) in env.constants.toList do
    let modName := match env.getModuleIdxFor? n with
      | some idx => env.header.moduleNames[idx.toNat]!
      | none => env.header.mainModule
    if modName ∈ [`Definitions, `Concrete, `Canonical, `Separation, `Invariance, `Audit, `InvarianceR2, `ConcreteR2, `GirthR2, `ReductionR2, `AuditR2, `MaskR3, `TreeModelsR3, `ChecksR3_0000_0, `EvalR3_0000, `ChecksR3_0001_0, `EvalR3_0001, `ChecksR3_0002_0, `EvalR3_0002, `ChecksR3_0010_0, `EvalR3_0010, `ChecksR3_0011_0, `EvalR3_0011, `ChecksR3_0012_0, `EvalR3_0012, `ChecksR3_0020_0, `EvalR3_0020, `ChecksR3_0021_0, `EvalR3_0021, `ChecksR3_0022_0, `EvalR3_0022, `ChecksR3_0100_0, `EvalR3_0100, `ChecksR3_0101_0, `EvalR3_0101, `ChecksR3_0102_0, `EvalR3_0102, `ChecksR3_0110_0, `EvalR3_0110, `ChecksR3_0111_0, `EvalR3_0111, `ChecksR3_0112_0, `EvalR3_0112, `ChecksR3_0120_0, `EvalR3_0120, `ChecksR3_0121_0, `EvalR3_0121, `ChecksR3_0122_0, `ChecksR3_0122_1, `EvalR3_0122, `ChecksR3_0200_0, `EvalR3_0200, `ChecksR3_0201_0, `EvalR3_0201, `ChecksR3_0202_0, `EvalR3_0202, `ChecksR3_0210_0, `EvalR3_0210, `ChecksR3_0211_0, `EvalR3_0211, `ChecksR3_0212_0, `ChecksR3_0212_1, `EvalR3_0212, `ChecksR3_0220_0, `EvalR3_0220, `ChecksR3_0221_0, `ChecksR3_0221_1, `EvalR3_0221, `ChecksR3_0222_0, `ChecksR3_0222_1, `ChecksR3_0222_2, `ChecksR3_0222_3, `EvalR3_0222, `ChecksR3_1000_0, `EvalR3_1000, `ChecksR3_1001_0, `EvalR3_1001, `ChecksR3_1002_0, `EvalR3_1002, `ChecksR3_1010_0, `EvalR3_1010, `ChecksR3_1011_0, `EvalR3_1011, `ChecksR3_1012_0, `EvalR3_1012, `ChecksR3_1020_0, `EvalR3_1020, `ChecksR3_1021_0, `EvalR3_1021, `ChecksR3_1022_0, `ChecksR3_1022_1, `EvalR3_1022, `ChecksR3_1100_0, `EvalR3_1100, `ChecksR3_1101_0, `EvalR3_1101, `ChecksR3_1102_0, `EvalR3_1102, `ChecksR3_1110_0, `EvalR3_1110, `ChecksR3_1111_0, `EvalR3_1111, `ChecksR3_1112_0, `ChecksR3_1112_1, `EvalR3_1112, `ChecksR3_1120_0, `EvalR3_1120, `ChecksR3_1121_0, `ChecksR3_1121_1, `EvalR3_1121, `ChecksR3_1122_0, `ChecksR3_1122_1, `ChecksR3_1122_2, `ChecksR3_1122_3, `EvalR3_1122, `ChecksR3_1200_0, `EvalR3_1200, `ChecksR3_1201_0, `EvalR3_1201, `ChecksR3_1202_0, `ChecksR3_1202_1, `EvalR3_1202, `ChecksR3_1210_0, `EvalR3_1210, `ChecksR3_1211_0, `ChecksR3_1211_1, `EvalR3_1211, `ChecksR3_1212_0, `ChecksR3_1212_1, `ChecksR3_1212_2, `ChecksR3_1212_3, `EvalR3_1212, `ChecksR3_1220_0, `ChecksR3_1220_1, `EvalR3_1220, `ChecksR3_1221_0, `ChecksR3_1221_1, `ChecksR3_1221_2, `ChecksR3_1221_3, `EvalR3_1221, `ChecksR3_1222_0, `ChecksR3_1222_1, `ChecksR3_1222_2, `ChecksR3_1222_3, `ChecksR3_1222_4, `ChecksR3_1222_5, `ChecksR3_1222_6, `ChecksR3_1222_7, `EvalR3_1222, `ChecksR3_2000_0, `EvalR3_2000, `ChecksR3_2001_0, `EvalR3_2001, `ChecksR3_2002_0, `EvalR3_2002, `ChecksR3_2010_0, `EvalR3_2010, `ChecksR3_2011_0, `EvalR3_2011, `ChecksR3_2012_0, `ChecksR3_2012_1, `EvalR3_2012, `ChecksR3_2020_0, `EvalR3_2020, `ChecksR3_2021_0, `ChecksR3_2021_1, `EvalR3_2021, `ChecksR3_2022_0, `ChecksR3_2022_1, `ChecksR3_2022_2, `ChecksR3_2022_3, `EvalR3_2022, `ChecksR3_2100_0, `EvalR3_2100, `ChecksR3_2101_0, `EvalR3_2101, `ChecksR3_2102_0, `ChecksR3_2102_1, `EvalR3_2102, `ChecksR3_2110_0, `EvalR3_2110, `ChecksR3_2111_0, `ChecksR3_2111_1, `EvalR3_2111, `ChecksR3_2112_0, `ChecksR3_2112_1, `ChecksR3_2112_2, `ChecksR3_2112_3, `EvalR3_2112, `ChecksR3_2120_0, `ChecksR3_2120_1, `EvalR3_2120, `ChecksR3_2121_0, `ChecksR3_2121_1, `ChecksR3_2121_2, `ChecksR3_2121_3, `EvalR3_2121, `ChecksR3_2122_0, `ChecksR3_2122_1, `ChecksR3_2122_2, `ChecksR3_2122_3, `ChecksR3_2122_4, `ChecksR3_2122_5, `ChecksR3_2122_6, `ChecksR3_2122_7, `EvalR3_2122, `ChecksR3_2200_0, `EvalR3_2200, `ChecksR3_2201_0, `ChecksR3_2201_1, `EvalR3_2201, `ChecksR3_2202_0, `ChecksR3_2202_1, `ChecksR3_2202_2, `ChecksR3_2202_3, `EvalR3_2202, `ChecksR3_2210_0, `ChecksR3_2210_1, `EvalR3_2210, `ChecksR3_2211_0, `ChecksR3_2211_1, `ChecksR3_2211_2, `ChecksR3_2211_3, `EvalR3_2211, `ChecksR3_2212_0, `ChecksR3_2212_1, `ChecksR3_2212_2, `ChecksR3_2212_3, `ChecksR3_2212_4, `ChecksR3_2212_5, `ChecksR3_2212_6, `ChecksR3_2212_7, `EvalR3_2212, `ChecksR3_2220_0, `ChecksR3_2220_1, `ChecksR3_2220_2, `ChecksR3_2220_3, `EvalR3_2220, `ChecksR3_2221_0, `ChecksR3_2221_1, `ChecksR3_2221_2, `ChecksR3_2221_3, `ChecksR3_2221_4, `ChecksR3_2221_5, `ChecksR3_2221_6, `ChecksR3_2221_7, `EvalR3_2221, `ChecksR3_2222_0, `ChecksR3_2222_1, `ChecksR3_2222_2, `ChecksR3_2222_3, `ChecksR3_2222_4, `ChecksR3_2222_5, `ChecksR3_2222_6, `ChecksR3_2222_7, `ChecksR3_2222_8, `ChecksR3_2222_9, `ChecksR3_2222_10, `ChecksR3_2222_11, `ChecksR3_2222_12, `ChecksR3_2222_13, `ChecksR3_2222_14, `ChecksR3_2222_15, `EvalR3_2222, `BridgeR3, `AuditR3] then
      count := count + 1
      let axs ← collectAxioms n
      let (ty, st) := (AuditR3.encode ci.type).run store
      store := st
      let mut body := "none"
      if let some value := ci.value? (allowOpaque := true) then
        let (id, st) := (AuditR3.encode value).run store
        store := st
        body := s!"node {id}"
      logInfo m!"DECL {n}\nMODULE {modName}\nUNSAFE {ci.isUnsafe}\nPARTIAL {ci.isPartial}\nTYPE_NODE {ty}\nBODY {body}\nAXIOMS {axs}"
      if ci.isUnsafe || ci.isPartial then throwError "Forbidden safety flag: {n}"
      for ax in axs do
        unless ax == `propext || ax == `Classical.choice || ax == `Quot.sound do
          throwError "Forbidden axiom {ax} in {n}"
  for i in [:store.2.size] do
    logInfo m!"EXPR_NODE {i} {store.2[i]!}"
  logInfo m!"TOTAL_EXPR_NODES {store.2.size}"
  logInfo m!"TOTAL_LOCAL_DECLARATIONS {count}"
