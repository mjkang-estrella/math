/- Gate E controls: hexagonal lattice, balls, rooted isomorphism, ballFraction. Reviewer-authored. -/
import FulLatticeAut

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false
set_option linter.unnecessarySeqFocus false

noncomputable section

namespace Control

open Ful Ful.Stmt SimpleGraph

variable {V : Type*} {G : SimpleGraph V}

theorem walk_zero {o q : V} (h : ∃ p : G.Walk o q, p.length < 1) : q = o := by
  obtain ⟨p, hp⟩ := h
  have h0 : p.length = 0 := by omega
  exact (Walk.eq_of_length_eq_zero h0).symm

theorem walk_one {o q : V} (h : ∃ p : G.Walk o q, p.length < 2) : q = o ∨ G.Adj o q := by
  obtain ⟨p, hp⟩ := h
  cases p with
  | nil => exact Or.inl rfl
  | @cons _ a _ h p' =>
    right
    rw [Walk.length_cons] at hp
    have h0 : p'.length = 0 := by omega
    have := Walk.eq_of_length_eq_zero h0
    subst this
    exact h

theorem walk_two {o q : V} (h : ∃ p : G.Walk o q, p.length < 3) :
    q = o ∨ G.Adj o q ∨ ∃ a, G.Adj o a ∧ G.Adj a q := by
  obtain ⟨p, hp⟩ := h
  cases p with
  | nil => exact Or.inl rfl
  | @cons _ a _ h p' =>
    rw [Walk.length_cons] at hp
    rcases walk_one (G := G) ⟨p', by omega⟩ with rfl | h2
    · exact Or.inr (Or.inl h)
    · exact Or.inr (Or.inr ⟨a, h, h2⟩)

theorem mem_ball_self (o : V) {r : ℕ} (h : 0 < r) : o ∈ ballSet G o r :=
  mem_ballSet_iff.2 ⟨Walk.nil, by simpa using h⟩

theorem mem_ball_adj {o a : V} {r : ℕ} (h1 : 1 < r) (h : G.Adj o a) : a ∈ ballSet G o r :=
  mem_ballSet_iff.2 ⟨Walk.cons h Walk.nil, by simpa using h1⟩

theorem mem_ball_two {o a b : V} {r : ℕ} (h1 : 2 < r) (h : G.Adj o a) (h' : G.Adj a b) :
    b ∈ ballSet G o r :=
  mem_ballSet_iff.2 ⟨Walk.cons h (Walk.cons h' Walk.nil), by simpa using h1⟩

/-! ### The hexagonal lattice of Eq. (3). -/

def n1 : ℤ × ℤ × Bool := (0, 0, true)
def n2 : ℤ × ℤ × Bool := (0, -1, true)
def n3 : ℤ × ℤ × Bool := (1, -1, true)

/-- The root has exactly the three nearest neighbours of Eq. (3). -/
theorem root_adj_iff (q : ℤ × ℤ × Bool) :
    hexLattice.Adj hexRoot q ↔ q = n1 ∨ q = n2 ∨ q = n3 := by
  obtain ⟨x, y, c⟩ := q
  simp only [hex_adj_iff, hexRoot, n1, n2, n3, Prod.mk.injEq]
  cases c <;> simp <;> omega

theorem true_adj_iff (x y : ℤ) (q : ℤ × ℤ × Bool) :
    hexLattice.Adj (x, y, true) q ↔
      q = (x, y, false) ∨ q = (x, y + 1, false) ∨ q = (x - 1, y + 1, false) := by
  obtain ⟨x', y', c⟩ := q
  simp only [hex_adj_iff, Prod.mk.injEq]
  cases c <;> simp <;> omega

/-- The point `(1,0,false)` is at distance `√3` from the root: `hexDist4 = 12`. A definition joining
the six triangular-lattice neighbours would make this adjacent. -/
theorem hexDist4_triangular : hexDist4 hexRoot (1, 0, false) = 12 := by
  norm_num [hexDist4, hexRoot, bit]

theorem root_not_adj_triangular : ¬ hexLattice.Adj hexRoot (1, 0, false) := by
  intro h
  have : hexDist4 hexRoot (1, 0, false) = 4 := h
  rw [hexDist4_triangular] at this
  norm_num at this

/-- The nearest-neighbour rule: nothing other than the root is at distance below one. -/
theorem root_nearest (q : ℤ × ℤ × Bool) (h : q ≠ hexRoot) : 4 ≤ hexDist4 hexRoot q :=
  hexDist4_ge (Ne.symm h)

theorem root_neighbor_card : Nat.card (hexLattice.neighborSet hexRoot) = 3 := by
  have h : hexLattice.neighborSet hexRoot = ↑({n1, n2, n3} : Finset (ℤ × ℤ × Bool)) := by
    ext q
    simp only [mem_neighborSet, root_adj_iff, Finset.coe_insert, Finset.coe_singleton,
      Set.mem_insert_iff, Set.mem_singleton_iff]
  rw [h, Nat.card_coe_set_eq, Set.ncard_coe_finset]
  decide

/-- Strict ball: radius one is the root alone. -/
theorem ball1 : ballSet hexLattice hexRoot 1 = {hexRoot} := by
  ext q
  rw [mem_ballSet_iff, Set.mem_singleton_iff]
  constructor
  · exact walk_zero
  · rintro rfl
    exact ⟨Walk.nil, by simp⟩

/-- Radius two is the root and its three neighbours. -/
theorem ball2 : ballSet hexLattice hexRoot 2 = {hexRoot, n1, n2, n3} := by
  ext q
  simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · intro hq
    rcases walk_one (mem_ballSet_iff.1 hq) with h | h
    · exact Or.inl h
    · exact Or.inr ((root_adj_iff q).1 h)
  · rintro (rfl | h)
    · exact mem_ball_self _ (by norm_num)
    · exact mem_ball_adj (by norm_num) ((root_adj_iff q).2 h)

def ball3List : Finset (ℤ × ℤ × Bool) :=
  {hexRoot, n1, n2, n3, (0, 1, false), (-1, 1, false), (0, -1, false), (-1, 0, false),
    (1, -1, false), (1, 0, false)}

/-- Radius three: ten vertices (the root, three neighbours, six at distance two). -/
theorem ball3 : ballSet hexLattice hexRoot 3 = ↑ball3List := by
  ext q
  simp only [ball3List, Finset.coe_insert, Finset.coe_singleton, Set.mem_insert_iff,
    Set.mem_singleton_iff]
  constructor
  · intro hq
    rcases walk_two (mem_ballSet_iff.1 hq) with rfl | h | ⟨a, ha, hq'⟩
    · exact Or.inl rfl
    · rcases (root_adj_iff q).1 h with h | h | h <;> subst h <;> simp
    · rcases (root_adj_iff a).1 ha with rfl | rfl | rfl
      · rw [n1, true_adj_iff] at hq'
        rcases hq' with rfl | rfl | rfl <;> norm_num [hexRoot, n1, n2, n3]
      · rw [n2, true_adj_iff] at hq'
        rcases hq' with rfl | rfl | rfl <;> norm_num [hexRoot, n1, n2, n3]
      · rw [n3, true_adj_iff] at hq'
        rcases hq' with rfl | rfl | rfl <;> norm_num [hexRoot, n1, n2, n3]
  · have an1 : hexLattice.Adj hexRoot n1 := (root_adj_iff _).2 (Or.inl rfl)
    have an2 : hexLattice.Adj hexRoot n2 := (root_adj_iff _).2 (Or.inr (Or.inl rfl))
    have an3 : hexLattice.Adj hexRoot n3 := (root_adj_iff _).2 (Or.inr (Or.inr rfl))
    have a1 : ∀ q', hexLattice.Adj n1 q' ↔ _ := fun q' => true_adj_iff 0 0 q'
    have a2 : ∀ q', hexLattice.Adj n2 q' ↔ _ := fun q' => true_adj_iff 0 (-1) q'
    have a3 : ∀ q', hexLattice.Adj n3 q' ↔ _ := fun q' => true_adj_iff 1 (-1) q'
    rintro (rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl)
    · exact mem_ball_self _ (by norm_num)
    · exact mem_ball_adj (by norm_num) an1
    · exact mem_ball_adj (by norm_num) an2
    · exact mem_ball_adj (by norm_num) an3
    · exact mem_ball_two (by norm_num) an1 ((a1 _).2 (by norm_num))
    · exact mem_ball_two (by norm_num) an1 ((a1 _).2 (by norm_num))
    · exact mem_ball_two (by norm_num) an2 ((a2 _).2 (by norm_num))
    · exact mem_ball_two (by norm_num) an2 ((a2 _).2 (by norm_num))
    · exact mem_ball_two (by norm_num) an3 ((a3 _).2 (by norm_num))
    · exact mem_ball_two (by norm_num) an3 ((a3 _).2 (by norm_num))

/-- Cardinalities of the hexagonal balls; a non-strict ball would give 4, 10, 22 here instead. -/
theorem ball_counts : (ballSet hexLattice hexRoot 1).ncard = 1 ∧
    (ballSet hexLattice hexRoot 2).ncard = 4 ∧ (ballSet hexLattice hexRoot 3).ncard = 10 := by
  refine ⟨?_, ?_, ?_⟩
  · rw [ball1, Set.ncard_singleton]
  · have : ({hexRoot, n1, n2, n3} : Set (ℤ × ℤ × Bool)) =
        ↑({hexRoot, n1, n2, n3} : Finset (ℤ × ℤ × Bool)) := by
      simp only [Finset.coe_insert, Finset.coe_singleton]
    rw [ball2, this, Set.ncard_coe_finset]
    decide
  · rw [ball3, Set.ncard_coe_finset]
    decide

/-! ### Rooted isomorphism and `ballFraction` on a path. -/

def P3 : SimpleGraph (Fin 3) where
  Adj a b := a.val + 1 = b.val ∨ b.val + 1 = a.val
  symm := ⟨fun a b h => h.symm⟩
  loopless := ⟨fun a h => by rcases h with h | h <;> omega⟩

instance : DecidableRel P3.Adj := fun a b => inferInstanceAs (Decidable (_ ∨ _))

theorem P3_01 : P3.Adj 0 1 := by decide
theorem P3_10 : P3.Adj 1 0 := by decide
theorem P3_12 : P3.Adj 1 2 := by decide
theorem P3_21 : P3.Adj 2 1 := by decide

/-- Strictness: `1 ∉ B(0,1)` although `edist 0 1 = 1`. -/
theorem not_mem_strict : (1 : Fin 3) ∉ ballSet P3 0 1 := by
  intro h
  have := walk_zero (mem_ballSet_iff.1 h)
  exact absurd this (by decide)

theorem ball_P3_0 : ballSet P3 0 2 = ↑({0, 1} : Finset (Fin 3)) := by
  ext q
  simp only [Finset.coe_insert, Finset.coe_singleton, Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · intro hq
    rcases walk_one (mem_ballSet_iff.1 hq) with h | h
    · exact Or.inl h
    · right
      clear hq
      revert h
      revert q
      decide
  · rintro (rfl | rfl)
    · exact mem_ball_self _ (by norm_num)
    · exact mem_ball_adj (by norm_num) P3_01

theorem ball_P3_2 : ballSet P3 2 2 = ↑({1, 2} : Finset (Fin 3)) := by
  ext q
  simp only [Finset.coe_insert, Finset.coe_singleton, Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · intro hq
    rcases walk_one (mem_ballSet_iff.1 hq) with h | h
    · exact Or.inr h
    · left
      clear hq
      revert h
      revert q
      decide
  · rintro (rfl | rfl)
    · exact mem_ball_adj (by norm_num) P3_21
    · exact mem_ball_self _ (by norm_num)

theorem ball_P3_1 : ballSet P3 1 2 = ↑({0, 1, 2} : Finset (Fin 3)) := by
  ext q
  simp only [Finset.coe_insert, Finset.coe_singleton, Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · intro hq
    clear hq
    revert q
    decide
  · rintro (rfl | rfl | rfl)
    · exact mem_ball_adj (by norm_num) P3_10
    · exact mem_ball_self _ (by norm_num)
    · exact mem_ball_adj (by norm_num) P3_12

theorem nc_P3_0 : Nat.card ↥(ballSet P3 0 2) = 2 := by
  rw [ball_P3_0, Nat.card_coe_set_eq, Set.ncard_coe_finset]
  decide

theorem nc_P3_2 : Nat.card ↥(ballSet P3 2 2) = 2 := by
  rw [ball_P3_2, Nat.card_coe_set_eq, Set.ncard_coe_finset]
  decide

theorem nc_P3_1 : Nat.card ↥(ballSet P3 1 2) = 3 := by
  rw [ball_P3_1, Nat.card_coe_set_eq, Set.ncard_coe_finset]
  decide

/-- Wrong root: a uniform root at an end of the path is not the middle ball. -/
theorem no_iso_0 : ¬ RootedBallIso P3 0 P3 1 2 := by
  rintro ⟨e, -⟩
  have h := Nat.card_congr e.toEquiv
  rw [nc_P3_0, nc_P3_1] at h
  omega

theorem no_iso_2 : ¬ RootedBallIso P3 2 P3 1 2 := by
  rintro ⟨e, -⟩
  have h := Nat.card_congr e.toEquiv
  rw [nc_P3_2, nc_P3_1] at h
  omega

theorem iso_refl_1 : RootedBallIso P3 1 P3 1 2 := ⟨Iso.refl, fun _ _ => rfl⟩

/-- A small case of `ballFraction`: exactly one of the three roots has the ball of the middle. -/
theorem fraction_P3 : ballFraction P3 2 P3 1 = 1 / 3 := by
  have hv : ∀ v : Fin 3, RootedBallIso P3 v P3 1 2 ↔ v = 1 := by
    intro v
    have hv3 : v = 0 ∨ v = 1 ∨ v = 2 := by revert v; decide
    rcases hv3 with rfl | rfl | rfl
    · exact iff_of_false no_iso_0 (by decide)
    · exact iff_of_true iso_refl_1 rfl
    · exact iff_of_false no_iso_2 (by decide)
  unfold ballFraction
  have h : Nat.card {v : Fin 3 // RootedBallIso P3 v P3 1 2} = 1 := by
    rw [Nat.card_congr (Equiv.subtypeEquivRight hv)]
    simp
  rw [h]
  norm_num

/-- Rootedness matters: both balls of radius 3 are the whole path, but the rooted balls differ. -/
theorem no_iso_rooted : ¬ RootedBallIso P3 0 P3 1 3 := by
  rintro ⟨e, he⟩
  have m0 : (0 : Fin 3) ∈ ballSet P3 0 3 := mem_ball_self _ (by norm_num)
  have m1 : (1 : Fin 3) ∈ ballSet P3 1 3 := mem_ball_self _ (by norm_num)
  have me0 : (0 : Fin 3) ∈ ballSet P3 1 3 := mem_ball_adj (by norm_num) P3_10
  have me2 : (2 : Fin 3) ∈ ballSet P3 1 3 := mem_ball_adj (by norm_num) P3_12
  have hroot := he m0 m1
  have ha0 : P3.Adj 0 (e.symm ⟨0, me0⟩).1 := by
    have h : (P3.induce (ballSet P3 1 3)).Adj (e ⟨0, m0⟩) (e (e.symm ⟨0, me0⟩)) := by
      rw [hroot, e.apply_symm_apply]
      exact P3_10
    exact e.map_adj_iff.1 h
  have hb0 : P3.Adj 0 (e.symm ⟨2, me2⟩).1 := by
    have h : (P3.induce (ballSet P3 1 3)).Adj (e ⟨0, m0⟩) (e (e.symm ⟨2, me2⟩)) := by
      rw [hroot, e.apply_symm_apply]
      exact P3_12
    exact e.map_adj_iff.1 h
  have uniq : ∀ x y : Fin 3, P3.Adj 0 x → P3.Adj 0 y → x = y := by decide
  have hab := uniq _ _ ha0 hb0
  have heq : e.symm ⟨0, me0⟩ = e.symm ⟨2, me2⟩ := Subtype.ext hab
  have := e.symm.injective heq
  simp at this

/-- Wrong graph: the triangle and the path have different rooted balls. -/
theorem no_iso_wrong_graph : ¬ RootedBallIso P3 1 (⊤ : SimpleGraph (Fin 3)) 0 2 := by
  rintro ⟨e, -⟩
  have mt0 : (0 : Fin 3) ∈ ballSet (⊤ : SimpleGraph (Fin 3)) 0 2 := mem_ball_self _ (by norm_num)
  have mt1 : (1 : Fin 3) ∈ ballSet (⊤ : SimpleGraph (Fin 3)) 0 2 :=
    mem_ball_adj (by norm_num) (by decide)
  have mt2 : (2 : Fin 3) ∈ ballSet (⊤ : SimpleGraph (Fin 3)) 0 2 :=
    mem_ball_adj (by norm_num) (by decide)
  have triangle : ∀ x y z : Fin 3, P3.Adj x y → P3.Adj y z → P3.Adj x z → False := by decide
  have a01 : P3.Adj (e.symm ⟨0, mt0⟩).1 (e.symm ⟨1, mt1⟩).1 := by
    have h : (⊤ : SimpleGraph (Fin 3)).Adj (0 : Fin 3) 1 := by decide
    exact e.symm.map_adj_iff.2 h
  have a12 : P3.Adj (e.symm ⟨1, mt1⟩).1 (e.symm ⟨2, mt2⟩).1 := by
    have h : (⊤ : SimpleGraph (Fin 3)).Adj (1 : Fin 3) 2 := by decide
    exact e.symm.map_adj_iff.2 h
  have a02 : P3.Adj (e.symm ⟨0, mt0⟩).1 (e.symm ⟨2, mt2⟩).1 := by
    have h : (⊤ : SimpleGraph (Fin 3)).Adj (0 : Fin 3) 2 := by decide
    exact e.symm.map_adj_iff.2 h
  exact triangle _ _ _ a01 a12 a02

/-- Vertex-transitivity: a rooted isomorphism between the two sublattices. -/
theorem hex_root_iso (r : ℕ) : RootedBallIso hexLattice hexRoot hexLattice (0, 0, true) r := by
  obtain ⟨e, he⟩ := hex_vertexTransitive hexRoot (0, 0, true)
  have h := rootedBallIso_of_local (G := hexLattice) (H := hexLattice) (fun a => e.symm a)
    ((0, 0, true) : ℤ × ℤ × Bool) r
    (fun a b _ _ hab => e.symm.map_adj_iff.2 hab)
    (fun a b _ _ hab => e.symm.injective hab)
    (fun a _ w hw => ⟨e w, by simpa using e.map_adj_iff.2 hw, by simp⟩)
  rwa [show e.symm (0, 0, true) = hexRoot from by rw [← he]; exact e.symm_apply_apply _] at h

open scoped Classical in
/-- The limit value of Eq. (4): for `K = H` the limit is `1`. -/
theorem limit_value_one (r : ℕ) :
    (if RootedBallIso hexLattice hexRoot hexLattice hexRoot r then (1 : ℝ) else 0) = 1 := by
  rw [Helix.ifT ⟨Iso.refl, fun _ _ => rfl⟩]

end Control

end
