/- Gate C audit: #print axioms and transitive constant closure. Reviewer-authored. -/
import FulEndpoint
import FulLatticeAut
import Lean

open Lean Meta Elab Command

#print axioms Ful.endpoint
#print axioms Ful.localWeakConvergence
#print axioms Ful.CMap.IsFullerene.dual_simple
#print axioms Ful.Helix.helix_isFullerene
#print axioms Ful.Helix.numFullerenes_ge
#print axioms Ful.Helix.nonVacuous
#print axioms Ful.bad_bound
#print axioms Ful.exc_card_le
#print axioms Ful.transfer_ball

#check @Ful.endpoint
#check @Ful.localWeakConvergence

/-- Reviewer's worklist closure over type and value constants. -/
def auditClosure (env : Environment) (roots : List Name) : IO (Array ConstantInfo × Nat) := do
  let mut seen : NameHashSet := {}
  let mut stack : Array Name := roots.toArray
  let mut out : Array ConstantInfo := #[]
  let mut missing := 0
  let mut steps := 0
  while !stack.isEmpty && steps < 3000000 do
    steps := steps + 1
    let n := stack.back!
    stack := stack.pop
    if seen.contains n then continue
    seen := seen.insert n
    match env.find? n with
    | none => missing := missing + 1
    | some c =>
      out := out.push c
      for m in c.getUsedConstantsAsSet do
        if !seen.contains m then stack := stack.push m
  return (out, missing)

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quot"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "ctor"
  | .recInfo _ => "recursor"

def auditRoots : List Name :=
  [``Ful.endpoint, ``Ful.localWeakConvergence, ``Ful.CMap.IsFullerene.dual_simple,
   ``Ful.Helix.helix_isFullerene, ``Ful.Helix.numFullerenes_ge, ``Ful.Helix.nonVacuous,
   ``Ful.bad_bound, ``Ful.exc_card_le, ``Ful.transfer_ball]

#eval show CoreM Unit from do
  let env ← getEnv
  let (cs, missing) ← auditClosure env auditRoots
  IO.println s!"CLOSURE total={cs.size} missing={missing}"
  let mut counts : Std.HashMap String Nat := {}
  for c in cs do
    counts := counts.insert (kindOf c) (counts.getD (kindOf c) 0 + 1)
  IO.println s!"BY_KIND {counts.toList}"
  let axs := cs.filter (fun c => match c with | .axiomInfo _ => true | _ => false)
  IO.println s!"AXIOMS {axs.map (·.name)}"
  let opq := cs.filter (fun c => match c with | .opaqueInfo _ => true | _ => false)
  IO.println s!"OPAQUE count={opq.size} sample={(opq.map (·.name)).toList.take 40}"
  let uns := cs.filter (fun c => c.isUnsafe)
  IO.println s!"UNSAFE count={uns.size} {(uns.map (·.name)).toList.take 40}"
  let par := cs.filter (fun c => c.isPartial)
  IO.println s!"PARTIAL count={par.size} {(par.map (·.name)).toList.take 40}"
  let impl := cs.filter (fun c => (Compiler.getImplementedBy? env c.name).isSome)
  IO.println s!"IMPLEMENTED_BY count={impl.size} {(impl.map (·.name)).toList.take 60}"
  let ext := cs.filter (fun c => isExtern env c.name)
  IO.println s!"EXTERN count={ext.size} {(ext.map (·.name)).toList.take 60}"
  let ful := cs.filter (fun c => (`Ful).isPrefixOf c.name)
  IO.println s!"FUL_CONSTANTS {ful.size}"
  let fulOpq := ful.filter (fun c => c.isUnsafe || c.isPartial || (match c with | .opaqueInfo _ => true | .axiomInfo _ => true | _ => false))
  IO.println s!"FUL_SUSPECT {(fulOpq.map (·.name)).toList.take 60}"
  let reduceBool := cs.filter (fun c => c.name == ``Lean.ofReduceBool || c.name == ``Lean.ofReduceNat || c.name == `Lean.trustCompiler)
  IO.println s!"REDUCE_BOOL_FAMILY {reduceBool.map (·.name)}"
