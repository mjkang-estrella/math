/-
FulMapFin: the combinatorial map on `Fin (3 n)` of a fullerene graph on `Fin n` with a rotation
system; relation between its vertices and the graph's vertices.
-/
import FulMapOf
import FulGraphOf

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.style.haveILetI false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt
open scoped Classical

universe u

variable {V : Type u} [Fintype V] [DecidableEq V] {G : SimpleGraph V}

/-- The combinatorial map of a rotation system. -/
def mapOf (ρ : RotationSystem G) : CMap G.Dart where
  σ := ρ.σ
  α := symmPerm G
  α_invol d := SimpleGraph.Dart.symm_symm d
  α_ne d := SimpleGraph.Dart.symm_ne d

variable (ρ : RotationSystem G)

theorem mapOf_tail_iff {a b : G.Dart} : (mapOf ρ).tail a = (mapOf ρ).tail b ↔ a.fst = b.fst := by
  constructor
  · intro h
    exact Orb.eq_of_mk_eq (fun d : G.Dart => d.fst) (fun d => ρ.tail_eq d) h
  · intro h
    exact Orb.mk_eq_iff.2 (ρ.transitive a b h)

theorem mapOf_α_fst (d : G.Dart) : ((mapOf ρ).α d).fst = d.snd := rfl
theorem mapOf_α_snd (d : G.Dart) : ((mapOf ρ).α d).snd = d.fst := rfl

/-- The map of a fullerene graph with its embedding is a fullerene map. -/
theorem mapOf_isFullerene (hG : IsFullerene G)
    (hρ : Nat.card V + ρ.numFaces = Nat.card G.edgeSet + 2 ∧ ∀ d, ρ.faceLen d = 5 ∨ ρ.faceLen d = 6) :
    (mapOf ρ).IsFullerene := by
  have hne : Nonempty V := hG.connected.nonempty
  obtain ⟨v0⟩ := hne
  have hnb : ∀ v : V, ∃ w, G.Adj v w := by
    intro v
    have h3 := hG.cubic v
    have : Nonempty (G.neighborSet v) := by
      by_contra hc
      rw [not_nonempty_iff] at hc
      have h4 : Nat.card (G.neighborSet v) = 0 := Nat.card_of_isEmpty
      omega
    obtain ⟨⟨w, hw⟩⟩ := this
    exact ⟨w, hw⟩
  -- connectedness
  have hconn : (mapOf ρ).Connected := by
    obtain ⟨w0, hw0⟩ := hnb v0
    refine ⟨⟨⟨(v0, w0), hw0⟩⟩, fun x y => ?_⟩
    let Gp := Subgroup.closure ({(mapOf ρ).σ, (mapOf ρ).α} : Set (Perm G.Dart))
    have hσG : (mapOf ρ).σ ∈ Gp := Subgroup.subset_closure (by simp)
    have hαG : (mapOf ρ).α ∈ Gp := Subgroup.subset_closure (by simp)
    have hrot : ∀ (a b : G.Dart), a.fst = b.fst → ∃ g ∈ Gp, g a = b := by
      intro a b hab
      obtain ⟨i, hi⟩ := Orb.mk_eq_iff.1 ((mapOf_tail_iff ρ).2 hab)
      exact ⟨(mapOf ρ).σ ^ i, Subgroup.zpow_mem _ hσG i, hi⟩
    have key : ∀ {u v : V} (w : G.Walk u v) (a : G.Dart), a.fst = u →
        ∃ g ∈ Gp, (g a).fst = v := by
      intro u v w
      induction w with
      | nil =>
        intro a ha
        exact ⟨1, Subgroup.one_mem _, ha⟩
      | @cons u v w hadj p ih =>
        intro a ha
        let b : G.Dart := ⟨(u, v), hadj⟩
        obtain ⟨g1, hg1, h1⟩ := hrot a b ha
        obtain ⟨g2, hg2, h2⟩ := ih ((mapOf ρ).α b) rfl
        refine ⟨g2 * ((mapOf ρ).α * g1), Subgroup.mul_mem _ hg2 (Subgroup.mul_mem _ hαG hg1), ?_⟩
        rw [Perm.mul_apply, Perm.mul_apply, h1]
        exact h2
    obtain ⟨w⟩ := hG.connected.preconnected x.fst y.fst
    obtain ⟨g1, hg1, h1⟩ := key w x rfl
    obtain ⟨g2, hg2, h2⟩ := hrot (g1 x) y h1
    exact ⟨g2 * g1, Subgroup.mul_mem _ hg2 hg1, by rw [Perm.mul_apply, h2]⟩
  -- simple
  have hsimple : (mapOf ρ).IsSimple := by
    refine ⟨fun d hd => ?_, fun a b h1 h2 => ?_⟩
    · have hd2 := (mapOf_tail_iff ρ).1 hd
      rw [mapOf_α_fst] at hd2
      exact G.ne_of_adj d.adj hd2
    · have ha : a.fst = b.fst := (mapOf_tail_iff ρ).1 h1
      have hb : a.snd = b.snd := by
        have := (mapOf_tail_iff ρ).1 h2
        simpa [mapOf_α_fst] using this
      exact SimpleGraph.Dart.ext _ _ (Prod.ext ha hb)
  -- degrees
  have hcubic : ∀ v, (mapOf ρ).deg v = 3 := by
    intro v
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
    have hcount : (univ.filter (fun x => (mapOf ρ).tail x = (mapOf ρ).tail d)).card =
        Nat.card (G.neighborSet d.fst) := by
      rw [Nat.card_eq_fintype_card, ← Set.toFinset_card]
      apply Finset.card_bij (fun x _ => x.snd)
      · intro x hx
        simp only [mem_filter, mem_univ, true_and] at hx
        simp only [Set.mem_toFinset, SimpleGraph.mem_neighborSet]
        rw [← (mapOf_tail_iff ρ).1 hx]
        exact x.adj
      · intro x hx y hy hxy
        simp only [mem_filter, mem_univ, true_and] at hx hy
        exact SimpleGraph.Dart.ext _ _
          (Prod.ext (((mapOf_tail_iff ρ).1 hx).trans ((mapOf_tail_iff ρ).1 hy).symm) hxy)
      · intro w hw
        simp only [Set.mem_toFinset, SimpleGraph.mem_neighborSet] at hw
        refine ⟨⟨(d.fst, w), hw⟩, ?_, rfl⟩
        simp only [mem_filter, mem_univ, true_and]
        exact (mapOf_tail_iff ρ).2 rfl
    show (univ.filter (fun x => (mapOf ρ).tail x = (mapOf ρ).tail d)).card = 3
    rw [hcount]
    exact hG.cubic _
  -- faces
  have hfaces : ∀ f, (mapOf ρ).faceLen f = 5 ∨ (mapOf ρ).faceLen f = 6 := by
    intro f
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    have hcount : (mapOf ρ).faceLen ((mapOf ρ).face d) = ρ.faceLen d := by
      show (univ.filter (fun x => (mapOf ρ).face x = (mapOf ρ).face d)).card =
        Nat.card {x // ρ.φ.SameCycle d x}
      rw [Nat.card_eq_fintype_card, Fintype.card_subtype]
      congr 1
      ext x
      simp only [mem_filter, mem_univ, true_and]
      rw [show (mapOf ρ).face x = (mapOf ρ).face d ↔ (mapOf ρ).φ.SameCycle x d from Orb.mk_eq_iff,
        sameCycle_comm]
      rfl
    have h5 := hρ.2 d
    rw [← hcount] at h5
    exact h5
  -- genus
  have hV : (mapOf ρ).numV = Fintype.card V := by
    have e : (mapOf ρ).V ≃ V :=
      { toFun := Orb.lift (fun d : G.Dart => d.fst) (fun d => (ρ.tail_eq d).symm ▸ rfl)
        invFun := fun v => (mapOf ρ).tail ⟨(v, (hnb v).choose), (hnb v).choose_spec⟩
        left_inv := fun v => by
          obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
          exact (mapOf_tail_iff ρ).2 rfl
        right_inv := fun v => rfl }
    exact Fintype.card_congr e
  have hF : (mapOf ρ).numF = ρ.numFaces := by
    unfold CMap.numF RotationSystem.numFaces
    rw [Nat.card_eq_fintype_card]
    exact Fintype.card_congr (Equiv.refl _)
  have hE : (mapOf ρ).numE = Nat.card G.edgeSet := by
    have h1 := G.dart_card_eq_twice_card_edges
    have h3 := card_dart_two (M := mapOf ρ)
    have h5 : Nat.card G.edgeSet = #G.edgeFinset := by
      rw [SimpleGraph.edgeFinset, Set.toFinset_card, Nat.card_eq_fintype_card]
    omega
  refine ⟨hconn, ?_, hsimple, hcubic, hfaces⟩
  unfold CMap.Genus0
  rw [hV, hF, hE, ← Nat.card_eq_fintype_card]
  exact hρ.1

end Ful

end
