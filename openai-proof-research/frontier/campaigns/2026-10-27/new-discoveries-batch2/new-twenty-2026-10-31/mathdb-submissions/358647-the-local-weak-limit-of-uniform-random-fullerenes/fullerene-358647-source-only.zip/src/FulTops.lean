/-
FulTops: the top darts of a ring of period `2 ℓ`: number of `U` moves, periodicity, and every
boundary edge of the region beyond the ring is a top edge.
-/
import FulEss

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

theorem blk_add_sum {K : ℕ → ℕ} (hK : ∀ j, 1 ≤ K j) (n : ℕ) :
    blk K n + n = ∑ j ∈ range n, K j := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [blk_succ, Finset.sum_range_succ, ← ih]
    have := hK n
    omega

theorem two_vals {α : Type*} {u w x1 x2 x : α} (h1 : x1 = u ∨ x1 = w) (h2 : x2 = u ∨ x2 = w)
    (hne : x1 ≠ x2) (hx : x = u ∨ x = w) : x = x1 ∨ x = x2 := by
  rcases h1 with rfl | rfl <;> rcases h2 with rfl | rfl <;> rcases hx with rfl | rfl <;> simp_all

theorem pred_mod {k ℓ : ℕ} (hk : k < ℓ) :
    (k + ℓ - 1) % ℓ = if k = 0 then ℓ - 1 else k - 1 := by
  by_cases h0 : k = 0
  · subst h0
    rw [ite_eq_left rfl, zero_add]
    exact Nat.mod_eq_of_lt (by omega)
  · rw [ite_eq_right h0, show k + ℓ - 1 = k - 1 + ℓ by omega, Nat.add_mod_right]
    exact Nat.mod_eq_of_lt (by omega)

namespace CMap

variable {M : CMap D}

namespace SimpleCycle

variable {C : SimpleCycle M} {Q : Finset M.F}

section tops

variable (hlen : 2 ≤ C.len) (hK : ∀ j, 2 ≤ C.K j) (hP : C.P = 2 * C.len)
include hlen hK hP

theorem count_U : Nat.count (fun x => C.W x = false) C.P = C.len := by
  rw [Nat.count_eq_card_filter_range]
  have hA : ((range C.P).filter (fun x => C.W x = true)) = (range C.len).image (blk C.K) := by
    ext m
    simp only [mem_filter, mem_range, mem_image]
    constructor
    · rintro ⟨h1, h2⟩
      obtain ⟨j, rfl⟩ := word_eq_true_iff.1 h2
      exact ⟨j, (blk_mono hK).lt_iff_lt.1 h1, rfl⟩
    · rintro ⟨j, hj, rfl⟩
      exact ⟨(blk_mono hK) hj, word_blk j⟩
  have hAc : ((range C.P).filter (fun x => C.W x = true)).card = C.len := by
    rw [hA, card_image_of_injective _ (blk_mono hK).injective, card_range]
  have hone : ∀ m, (if C.W m = false then 1 else 0) + (if C.W m = true then 1 else 0) = 1 := by
    intro m
    cases hw : C.W m <;> simp
  have hsplit : ((range C.P).filter (fun x => C.W x = false)).card +
      ((range C.P).filter (fun x => C.W x = true)).card = C.P := by
    rw [Finset.card_filter, Finset.card_filter, ← Finset.sum_add_distrib]
    simp [hone]
  omega

theorem exists_U' : ∃ m, C.W m = false := by
  have h := count_U hlen hK hP
  rw [Nat.count_eq_card_filter_range] at h
  obtain ⟨m, hm⟩ := Finset.card_pos.1 (show 0 < _ by rw [h]; omega)
  exact ⟨m, (mem_filter.1 hm).2⟩

theorem hinf' : ({m | C.W m = false} : Set ℕ).Infinite := by
  obtain ⟨m, hm⟩ := exists_U' hlen hK hP
  exact infinite_U (P_pos hlen hK (by omega)) (hPeriod hlen hK) hm

theorem topDart_add (k : ℕ) : C.topDart (k + C.len) = C.topDart k := by
  have h := posU_add_period (hinf' hlen hK hP) (hPeriod hlen hK) k
  rw [count_U hlen hK hP] at h
  unfold topDart
  rw [h, r_add_P hlen hK]

theorem topDart_mod (k : ℕ) : C.topDart (k % C.len) = C.topDart k :=
  Function.Periodic.map_mod_nat (f := C.topDart) (a := C.len)
    (fun x => topDart_add hlen hK hP x) k

variable (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q)
include h hor

theorem tail_r_mem (m : ℕ) : M.tail (C.r m) ∈ C.verts := by
  have := tail_cor0_mem hlen hK h hor m
  rwa [cor0, M.tail_σ] at this

/-- A dart on the inner boundary of the region beyond the ring is a top dart. -/
theorem exists_top_of_bd (hT : M.IsTriangulation) {d : D} (hd : M.face d ∈ C.Y Q)
    (hd2 : M.face (M.α d) ∉ C.Y Q) : ∃ k, k < C.len ∧ d = C.topDart k := by
  obtain ⟨hdQ, ht0⟩ := mem_filter.1 hd
  have hnv : ∀ x, M.face x = M.face d → M.tail x ∉ C.verts := t_eq_zero_iff.1 ht0
  have hne : M.edge d ∉ C.edges := fun he => hnv d rfl (C.tail_mem_of_edge_mem he)
  have hiff : M.face d ∈ Q ↔ M.face (M.α d) ∈ Q := not_not.1 fun hn => hne ((h d).2 hn)
  have hαQ : M.face (M.α d) ∈ Q := hiff.1 hdQ
  have ht1 : 1 ≤ C.t (M.face (M.α d)) := by
    by_contra hlt
    exact hd2 (mem_filter.2 ⟨hαQ, by omega⟩)
  obtain ⟨m, hm⟩ := cover hlen hK h hor hαQ ht1
  have hhead : M.tail (M.α d) ∉ C.verts := by
    rw [← M.tail_φ]
    exact hnv _ (M.face_φ d)
  rcases eq_cor_of_face hT hm.symm with h1 | h1 | h1
  · exact absurd (h1 ▸ tail_cor0_mem hlen hK h hor m) hhead
  · by_cases hw : C.W m = true
    · have h2 : C.r (m + 1) = M.cor1 (C.r m) := rung_succ_true hw
      exact absurd (h1 ▸ h2 ▸ tail_r_mem hlen hK hP h hor (m + 1)) hhead
    · have hw' : C.W m = false := by simpa using hw
      refine ⟨(Nat.count (fun x => C.W x = false) m) % C.len, Nat.mod_lt _ (by omega), ?_⟩
      rw [topDart_mod hlen hK hP]
      unfold topDart
      rw [posU_count hw', ← h1, M.α_α]
  · have h2 : d = C.r m := M.α.injective h1
    exact absurd (h2 ▸ tail_r_mem hlen hK hP h hor m) (hnv d rfl)

end tops

end SimpleCycle

end CMap

end Ful

end
