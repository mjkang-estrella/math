/-
FulChord: closing an arc of a simple cycle with a chord, and splitting a disc along a chord.
-/
import FulWalk

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

namespace SimpleCycle

variable (C : SimpleCycle M)

theorem edge_eq_mod {m n : ℕ} (h : M.edge (C.dart m) = M.edge (C.dart n)) :
    m % C.len = n % C.len := by
  rw [← C.dart_mod m, ← C.dart_mod n] at h
  exact C.edge_inj _ _ (C.mod_lt m) (C.mod_lt n) h

theorem tail_offset_inj {i a b : ℕ} (ha : a < C.len) (hb : b < C.len)
    (h : M.tail (C.dart (i + a)) = M.tail (C.dart (i + b))) : a = b := by
  have h1 : (i + a) ≡ (i + b) [MOD C.len] := C.tail_eq_mod h
  have h2 : a % C.len = b % C.len := Nat.ModEq.add_left_cancel' i h1
  rwa [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at h2

theorem edge_offset_inj {i a b : ℕ} (ha : a < C.len) (hb : b < C.len)
    (h : M.edge (C.dart (i + a)) = M.edge (C.dart (i + b))) : a = b := by
  have h1 : (i + a) ≡ (i + b) [MOD C.len] := C.edge_eq_mod h
  have h2 : a % C.len = b % C.len := Nat.ModEq.add_left_cancel' i h1
  rwa [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at h2

/-- Every position of a period is reached from `i` by an offset below the period. -/
theorem exists_offset {i n : ℕ} (hi : i < C.len) (hn : n < C.len) :
    ∃ a, a < C.len ∧ C.dart (i + a) = C.dart n := by
  rcases Nat.lt_or_ge n i with h | h
  · refine ⟨n + C.len - i, by omega, ?_⟩
    rw [show i + (n + C.len - i) = n + C.len by omega, C.periodic]
  · exact ⟨n - i, by omega, by rw [show i + (n - i) = n by omega]⟩

/-- Close the arc `dart i, ..., dart (i+p-1)` with the dart `x`. -/
def arc (i p : ℕ) (x : D) (hp0 : 0 < p) (hp : p < C.len)
    (h1 : M.tail x = M.tail (C.dart (i + p))) (h2 : M.tail (M.α x) = M.tail (C.dart i))
    (hx : M.edge x ∉ C.edges) : SimpleCycle M where
  len := p + 1
  len_pos := by omega
  dart := fun n => if n % (p + 1) < p then C.dart (i + n % (p + 1)) else x
  periodic := fun n => by simp only [Nat.add_mod_right]
  chain := by
    intro n
    have hm := Nat.mod_lt n (show 0 < p + 1 by omega)
    have hs : (n + 1) % (p + 1) = (n % (p + 1) + 1) % (p + 1) := by rw [Nat.mod_add_mod]
    rcases Nat.lt_or_ge (n % (p + 1)) p with hlt | hge
    · rw [ite_eq_left hlt]
      rcases Nat.lt_or_ge (n % (p + 1) + 1) p with hlt2 | hge2
      · have h3 : (n + 1) % (p + 1) = n % (p + 1) + 1 := by
          rw [hs, Nat.mod_eq_of_lt (by omega)]
        have h4 : (n + 1) % (p + 1) < p := by omega
        simp only [h4, ite_true]
        rw [h3, C.chain, ← add_assoc]
      · have h3 : n % (p + 1) + 1 = p := by omega
        have h5 : (n + 1) % (p + 1) = p := by
          rw [hs, h3, Nat.mod_eq_of_lt (by omega)]
        simp only [h5, lt_irrefl, ite_false]
        rw [h1, C.chain, add_assoc, h3]
    · have h3 : n % (p + 1) = p := by omega
      have h5 : (n + 1) % (p + 1) = 0 := by
        rw [hs, h3, Nat.mod_self]
      simp only [h3, lt_irrefl, ite_false, h5, hp0, ite_true, add_zero]
      exact h2
  tail_inj := by
    intro a b ha hb hab
    simp only [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at hab
    by_cases h3 : a < p <;> by_cases h4 : b < p
    · simp only [h3, h4, ite_true] at hab
      exact C.tail_offset_inj (by omega) (by omega) hab
    · simp only [h3, h4, ite_true, ite_false] at hab
      rw [h1] at hab
      have := C.tail_offset_inj (i := i) (a := a) (b := p) (by omega) (by omega) hab
      omega
    · simp only [h3, h4, ite_true, ite_false] at hab
      rw [h1] at hab
      have := C.tail_offset_inj (i := i) (a := p) (b := b) (by omega) (by omega) hab
      omega
    · omega
  edge_inj := by
    intro a b ha hb hab
    simp only [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at hab
    by_cases h3 : a < p <;> by_cases h4 : b < p
    · simp only [h3, h4, ite_true] at hab
      exact C.edge_offset_inj (by omega) (by omega) hab
    · simp only [h3, h4, ite_true, ite_false] at hab
      exact absurd (hab ▸ C.edge_mem (i + a)) hx
    · simp only [h3, h4, ite_true, ite_false] at hab
      exact absurd (hab.symm ▸ C.edge_mem (i + b)) hx
    · omega

variable {C} {i p : ℕ} {x : D} {hp0 : 0 < p} {hp : p < C.len}
  {h1 : M.tail x = M.tail (C.dart (i + p))} {h2 : M.tail (M.α x) = M.tail (C.dart i)}
  {hx : M.edge x ∉ C.edges}

theorem arc_dart_lt {a : ℕ} (ha : a < p) :
    (C.arc i p x hp0 hp h1 h2 hx).dart a = C.dart (i + a) := by
  have h3 : a % (p + 1) = a := Nat.mod_eq_of_lt (by omega)
  simp only [arc, h3, ha, ite_true]

theorem arc_dart_p : (C.arc i p x hp0 hp h1 h2 hx).dart p = x := by
  have h3 : p % (p + 1) = p := Nat.mod_eq_of_lt (by omega)
  simp only [arc, h3, lt_irrefl, ite_false]

theorem arc_edge_left {a : ℕ} (ha : a < p) :
    M.edge (C.dart (i + a)) ∈ (C.arc i p x hp0 hp h1 h2 hx).edges := by
  have := (C.arc i p x hp0 hp h1 h2 hx).edge_mem a
  rwa [arc_dart_lt ha] at this

theorem arc_edge_x : M.edge x ∈ (C.arc i p x hp0 hp h1 h2 hx).edges := by
  have := (C.arc i p x hp0 hp h1 h2 hx).edge_mem p
  rwa [arc_dart_p] at this

theorem arc_edge_cases {e : M.E} (he : e ∈ (C.arc i p x hp0 hp h1 h2 hx).edges) :
    e = M.edge x ∨ ∃ a, a < p ∧ M.edge (C.dart (i + a)) = e := by
  obtain ⟨n, hn, rfl⟩ := mem_image.1 he
  have hn' : n < p + 1 := mem_range.1 hn
  rcases Nat.lt_or_ge n p with h3 | h3
  · right
    exact ⟨n, h3, by rw [arc_dart_lt h3]⟩
  · left
    have h4 : n = p := by omega
    subst h4
    rw [arc_dart_p]

end SimpleCycle

/-- The hypotheses needed to split at a chord, packaged as a result. -/
theorem IsSide.chord_split (hc : M.Connected) (hg : M.Genus0) {C : SimpleCycle M}
    {S : Finset M.F} (h : IsSide C S) (x : D) (hxe : M.edge x ∉ C.edges) (hxS : M.edge x ∈ clE S)
    (t1 : M.tail x ∈ C.verts) (t2 : M.tail (M.α x) ∈ C.verts)
    (hloop : M.tail x ≠ M.tail (M.α x)) :
    ∃ (C1 C2 : SimpleCycle M) (S1 S2 : Finset M.F),
      IsSide C1 S1 ∧ IsSide C2 S2 ∧ S1 ⊆ S ∧ S2 ⊆ S ∧ S1.card + S2.card = S.card ∧
      C1.len + C2.len = C.len + 2 := by
  obtain ⟨i, hi⟩ := C.exists_of_vert_mem t2
  obtain ⟨j, hj⟩ := C.exists_of_vert_mem t1
  -- reduce both indices below the period
  have hi' : M.tail (C.dart (i % C.len)) = M.tail (M.α x) := by rw [C.dart_mod]; exact hi
  have hj' : M.tail (C.dart (j % C.len)) = M.tail x := by rw [C.dart_mod]; exact hj
  obtain ⟨i0, hi0, hti⟩ : ∃ i0, i0 < C.len ∧ M.tail (C.dart i0) = M.tail (M.α x) :=
    ⟨_, C.mod_lt i, hi'⟩
  obtain ⟨j0, hj0, htj⟩ : ∃ j0, j0 < C.len ∧ M.tail (C.dart j0) = M.tail x :=
    ⟨_, C.mod_lt j, hj'⟩
  have hij : i0 ≠ j0 := by
    rintro rfl
    exact hloop (htj.symm.trans hti)
  obtain ⟨p, hp0, hp, hpart⟩ : ∃ p, 0 < p ∧ p < C.len ∧ C.dart (i0 + p) = C.dart j0 := by
    rcases Nat.lt_or_ge i0 j0 with h3 | h3
    · exact ⟨j0 - i0, by omega, by omega, by rw [show i0 + (j0 - i0) = j0 by omega]⟩
    · refine ⟨j0 + C.len - i0, ?_, ?_, ?_⟩
      · omega
      · have : j0 < i0 := by omega
        omega
      · rw [show i0 + (j0 + C.len - i0) = j0 + C.len by omega, C.periodic]
  have ha1 : M.tail x = M.tail (C.dart (i0 + p)) := by rw [hpart, htj]
  have ha2 : M.tail (M.α x) = M.tail (C.dart i0) := hti.symm
  let C1 := C.arc i0 p x hp0 hp ha1 ha2 hxe
  have hb1 : M.tail (M.α x) = M.tail (C.dart (i0 + p + (C.len - p))) := by
    rw [show i0 + p + (C.len - p) = i0 + C.len by omega, C.periodic, hti]
  have hb2 : M.tail (M.α (M.α x)) = M.tail (C.dart (i0 + p)) := by
    rw [M.α_α]; exact ha1
  have hxe' : M.edge (M.α x) ∉ C.edges := by rw [M.edge_α]; exact hxe
  let C2 := C.arc (i0 + p) (C.len - p) (M.α x) (by omega) (by omega) hb1 hb2 hxe'
  have hC1 : ∀ e ∈ C1.edges, e ∈ clE S := by
    intro e he
    rcases SimpleCycle.arc_edge_cases he with rfl | ⟨a, -, rfl⟩
    · exact hxS
    · exact h.edges_subset (C.edge_mem _)
  obtain ⟨S1, hS1sub, hS1⟩ := IsSide.exists_side_subset hc hg h C1 hC1
  have hind : ∀ e, C1.ind e + C2.ind e = C.ind e := by
    intro e
    have mem1 : ∀ a, a < p → M.edge (C.dart (i0 + a)) ∈ C1.edges :=
      fun a ha => SimpleCycle.arc_edge_left ha
    have mem2 : ∀ b, b < C.len - p → M.edge (C.dart (i0 + p + b)) ∈ C2.edges :=
      fun b hb => SimpleCycle.arc_edge_left hb
    have hxin1 : M.edge x ∈ C1.edges := SimpleCycle.arc_edge_x
    have hxin2 : M.edge x ∈ C2.edges := by
      have : M.edge (M.α x) ∈ C2.edges := SimpleCycle.arc_edge_x
      rwa [M.edge_α] at this
    unfold SimpleCycle.ind
    by_cases he1 : e = M.edge x
    · subst he1
      simp only [hxin1, hxin2, hxe, ite_true, ite_false]
      exact F2.add_self _
    by_cases heC : e ∈ C.edges
    · obtain ⟨n0, hn0⟩ := C.exists_of_edge_mem heC
      obtain ⟨a, ha, hda⟩ := C.exists_offset hi0 (C.mod_lt n0)
      have hea : M.edge (C.dart (i0 + a)) = e := by rw [hda, C.dart_mod]; exact hn0
      rw [ite_eq_left heC]
      rcases Nat.lt_or_ge a p with h3 | h3
      · have hin1 : e ∈ C1.edges := hea ▸ mem1 a h3
        have hnot2 : e ∉ C2.edges := by
          intro hin
          rcases SimpleCycle.arc_edge_cases hin with hx' | ⟨b, hb, hbe⟩
          · rw [M.edge_α] at hx'; exact he1 hx'
          · rw [← hea, show i0 + p + b = i0 + (p + b) by omega] at hbe
            have := C.edge_offset_inj (i := i0) (a := p + b) (b := a) (by omega) ha hbe
            omega
        rw [ite_eq_left hin1, ite_eq_right hnot2, add_zero]
      · have hb : a - p < C.len - p := by omega
        have hin2 : e ∈ C2.edges := by
          have := mem2 (a - p) hb
          rwa [show i0 + p + (a - p) = i0 + a by omega, hea] at this
        have hnot1 : e ∉ C1.edges := by
          intro hin
          rcases SimpleCycle.arc_edge_cases hin with hx' | ⟨b, hb', hbe⟩
          · exact he1 hx'
          · rw [← hea] at hbe
            have := C.edge_offset_inj (i := i0) (a := b) (b := a) (by omega) ha hbe
            omega
        rw [ite_eq_right hnot1, ite_eq_left hin2, zero_add]
    · have hnot1 : e ∉ C1.edges := by
        intro hin
        rcases SimpleCycle.arc_edge_cases hin with hx' | ⟨b, -, hbe⟩
        · exact he1 hx'
        · exact heC (hbe ▸ C.edge_mem _)
      have hnot2 : e ∉ C2.edges := by
        intro hin
        rcases SimpleCycle.arc_edge_cases hin with hx' | ⟨b, -, hbe⟩
        · rw [M.edge_α] at hx'; exact he1 hx'
        · exact heC (hbe ▸ C.edge_mem _)
      rw [ite_eq_right hnot1, ite_eq_right hnot2, ite_eq_right heC, add_zero]
  have hindF : indF (S \ S1) = indF S + indF S1 := by
    funext f
    simp only [indF, mem_sdiff, Pi.add_apply]
    by_cases a : f ∈ S <;> by_cases b : f ∈ S1
    · simp only [a, b, not_true_eq_false, and_false, ite_false, ite_true]
      exact (F2.add_self _).symm
    · simp only [a, b, not_false_eq_true, and_self, ite_true, ite_false, add_zero]
    · exact absurd (hS1sub b) a
    · simp only [a, b, false_and, ite_false, add_zero]
  have hS2 : IsSide C2 (S \ S1) := by
    refine isSide_of_d2 C2 ?_
    rw [hindF, Matrix.mulVec_add, h.d2_indF C, hS1.d2_indF C1]
    funext e
    have h3 := hind e
    simp only [Pi.add_apply]
    rw [← h3]
    calc C1.ind e + C2.ind e + C1.ind e = (C1.ind e + C1.ind e) + C2.ind e := by ring
      _ = C2.ind e := by rw [F2.add_self, zero_add]
  refine ⟨C1, C2, S1, S \ S1, hS1, hS2, hS1sub, sdiff_subset, ?_, ?_⟩
  · have := card_sdiff_add_card_eq_card hS1sub
    omega
  · show p + 1 + (C.len - p + 1) = C.len + 2
    omega

end CMap

end Ful

end
