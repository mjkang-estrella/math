/-
FulBad: the number of fullerene vertices with a non-hexagonal ball, on a fullerene whose dual has no
short essential cycle, is bounded independently of the number of vertices.
-/
import FulFmap
import FulTransfer2

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt CMap
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D] {T : CMap D}

namespace CMap

theorem Reach.trans {a b c : T.V} {k l : ℕ} (h1 : T.Reach a k b) (h2 : T.Reach b l c) :
    T.Reach a (k + l) c := by
  induction h2 with
  | zero => simpa using h1
  | stay _ ih => exact Reach.stay ih
  | step d h _ ih => exact Reach.step d h ih

theorem Reach.symm {a b : T.V} {k : ℕ} (h : T.Reach a k b) : T.Reach b k a := by
  induction h with
  | zero => exact Reach.zero
  | stay _ ih => exact Reach.stay ih
  | @step n v d hd _ ih =>
    have h1 : T.Reach (T.tail (T.α d)) (0 + 1) (T.tail (T.α (T.α d))) :=
      Reach.step (T.α d) rfl Reach.zero
    rw [T.α_α, hd] at h1
    have h2 := Reach.trans h1 ih
    rwa [Nat.zero_add, Nat.add_comm] at h2

/-- Balls in a map of bounded degree are small. -/
theorem card_reach_le (hd6 : ∀ v, T.deg v ≤ 6) (w : T.V) (R : ℕ) :
    (univ.filter (fun v => T.Reach w R v)).card ≤ 7 ^ R := by
  induction R with
  | zero =>
    have h : univ.filter (fun v => T.Reach w 0 v) ⊆ {w} := by
      intro v hv
      simp only [mem_filter, mem_univ, true_and] at hv
      cases hv
      simp
    simpa using Finset.card_le_card h
  | succ R ih =>
    set B := univ.filter (fun v => T.Reach w R v) with hB
    let S : Finset D := univ.filter (fun d => T.tail d ∈ B)
    have hsub : univ.filter (fun v => T.Reach w (R + 1) v) ⊆ B ∪ S.image (fun d => T.tail (T.α d)) := by
      intro v hv
      simp only [mem_filter, mem_univ, true_and] at hv
      simp only [mem_union, mem_image]
      cases hv with
      | stay h =>
        left
        simp [hB, h]
      | step d hd h =>
        right
        refine ⟨d, ?_, rfl⟩
        simp only [S, mem_filter, mem_univ, true_and]
        rw [hd]
        simp [hB, h]
    have hS : S.card ≤ 6 * B.card := by
      have h1 : S.card = ∑ b ∈ B, (S.filter (fun d => T.tail d = b)).card :=
        Finset.card_eq_sum_card_fiberwise (fun d hd => by
          simp only [S, mem_coe, mem_filter, mem_univ, true_and] at hd
          exact hd)
      have h2 : ∀ b ∈ B, (S.filter (fun d => T.tail d = b)).card ≤ 6 := by
        intro b _
        have h3 : S.filter (fun d => T.tail d = b) ⊆ univ.filter (fun d => T.tail d = b) := by
          intro d hd
          simp only [mem_filter, mem_univ, true_and] at hd ⊢
          exact hd.2
        exact (Finset.card_le_card h3).trans (hd6 b)
      rw [h1]
      calc ∑ b ∈ B, (S.filter (fun d => T.tail d = b)).card ≤ ∑ _b ∈ B, 6 :=
            Finset.sum_le_sum h2
        _ = 6 * B.card := by simp [mul_comm]
    have hc := Finset.card_le_card hsub
    have hu := Finset.card_union_le B (S.image (fun d => T.tail (T.α d)))
    have hi : (S.image (fun d => T.tail (T.α d))).card ≤ S.card := Finset.card_image_le
    have hp : 7 ^ (R + 1) = 7 * 7 ^ R := by ring
    omega

/-- A fullerene dual has twelve vertices of degree five. -/
theorem card_pent (hT : T.IsTriangulation) (hg : T.Genus0) (h56 : ∀ v, T.deg v = 5 ∨ T.deg v = 6) :
    (univ.filter (fun v => T.deg v ≠ 6)).card = 12 := by
  have hsum := sum_curv hT hg
  have h2 : ∑ v : T.V, (6 - (T.deg v : ℤ)) = ∑ v ∈ univ.filter (fun v => T.deg v ≠ 6), (1 : ℤ) := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro v _
    rcases h56 v with h | h <;> simp [h]
  rw [h2, Finset.sum_const, nsmul_eq_mul, mul_one] at hsum
  exact_mod_cast hsum

end CMap

/-! ### The bad-vertex bound -/

variable {n : ℕ} {G : SimpleGraph (Fin n)}

/-- The flatness radius. -/
def Rad (r : ℕ) : ℕ :=
  2 * (r + 2) + 2 + 2 * (4 * (r + 2) + 4) + (4 * (r + 2) + 4) + bnd (4 * (r + 2) + 4) + 7

/-- Hexagonal balls at flat vertices. -/
theorem ball_of_flat (hG : IsFullerene G) (r : ℕ) (d : Fin (3 * n))
    (hF : ((fmap hG).dual).FlatTo (((fmap hG).dual).tail d) (Rad r))
    (hsys : ∀ (C : SimpleCycle (fmap hG).dual) (S : Finset (fmap hG).dual.F),
      Essential C S → 4 * (r + 2) + 4 < C.len) :
    RootedBallIso G (tauF hG (((fmap hG).dual).psi d (0, 0) 1)) hexLattice hexRoot r := by
  have h := fmap_isFullerene hG
  have hT := h.dual_tri
  have hc := h.dual_connected
  have hg := h.dual_genus
  have hs := h.dual_simple
  have hd6 := h.dual_deg_le
  have hlb := local_ball hT hc hg hs hd6 d (r + 2) hF hsys
  apply transfer_ball hT hF (fun x y => fmapT_face_iff hG) (fmapT_adj hG) hG.cubic r hlb.2.2.1
  simp only [Rad]
  omega

/-- The bad-vertex count. -/
theorem bad_bound (hG : IsFullerene G) (r : ℕ)
    (hsys : ∀ (C : SimpleCycle (fmap hG).dual) (S : Finset (fmap hG).dual.F),
      Essential C S → 4 * (r + 2) + 4 < C.len) :
    (univ.filter (fun v : Fin n => ¬ RootedBallIso G v hexLattice hexRoot r)).card ≤
      72 * 7 ^ Rad r := by
  have h := fmap_isFullerene hG
  set T := (fmap hG).dual with hTdef
  have hT : T.IsTriangulation := h.dual_tri
  have hg : T.Genus0 := h.dual_genus
  have h56 : ∀ v, T.deg v = 5 ∨ T.deg v = 6 := h.dual_deg
  have hd6 : ∀ v, T.deg v ≤ 6 := h.dual_deg_le
  let P : Finset T.V := univ.filter (fun v => T.deg v ≠ 6)
  have hPc : P.card = 12 := card_pent hT hg h56
  -- choose a dart at each vertex
  let dv : Fin n → Fin (3 * n) := fun v => Classical.choose (tauF_surj hG v)
  have hdv : ∀ v, tauF hG (dv v) = v := fun v => Classical.choose_spec (tauF_surj hG v)
  -- the region around the pentagons
  let Rg : Finset T.V := P.biUnion (fun w => univ.filter (fun v => T.Reach w (Rad r) v))
  have hRg : Rg.card ≤ 12 * 7 ^ Rad r := by
    calc Rg.card ≤ ∑ w ∈ P, (univ.filter (fun v => T.Reach w (Rad r) v)).card :=
          Finset.card_biUnion_le
      _ ≤ ∑ _w ∈ P, 7 ^ Rad r := Finset.sum_le_sum (fun w _ => card_reach_le hd6 w _)
      _ = 12 * 7 ^ Rad r := by simp [hPc]
  -- bad vertices have their chosen dart at the region
  have hbad : ∀ v, ¬ RootedBallIso G v hexLattice hexRoot r → T.tail (dv v) ∈ Rg := by
    intro v hv
    by_contra hnot
    apply hv
    set d := T.σ⁻¹ (dv v) with hd
    have htail : T.tail d = T.tail (dv v) := tail_inv (dv v)
    have hdev : T.psi d (0, 0) 1 = dv v := by
      show (T.σ ^ 1) (T.dev d 0 0) = dv v
      have h1 : T.dev d 0 0 = d := by simp [CMap.dev]
      rw [h1, pow_one]
      exact σ_σ_inv (dv v)
    have hF : T.FlatTo (T.tail d) (Rad r) := by
      intro w hw
      by_contra hne
      apply hnot
      have hw' : T.Reach (T.tail (dv v)) (Rad r) w := by rwa [htail] at hw
      simp only [Rg, mem_biUnion]
      exact ⟨w, by simp [P, hne], by simpa using hw'.symm⟩
    have hb := ball_of_flat hG r d hF hsys
    rw [hdev, hdv] at hb
    exact hb
  -- count
  let Bad := univ.filter (fun v : Fin n => ¬ RootedBallIso G v hexLattice hexRoot r)
  let Darts : Finset (Fin (3 * n)) := univ.filter (fun x => T.tail x ∈ Rg)
  have hmap : ∀ v ∈ Bad, dv v ∈ Darts := by
    intro v hv
    simp only [Darts, mem_filter, mem_univ, true_and]
    simp only [Bad, mem_filter, mem_univ, true_and] at hv
    exact hbad v hv
  have hinj : Set.InjOn dv (Bad : Set (Fin n)) := by
    intro a _ b _ hab
    have := hdv a
    rw [hab, hdv] at this
    exact this.symm
  have hcard1 : Bad.card ≤ Darts.card := Finset.card_le_card_of_injOn dv hmap hinj
  have hDarts : Darts.card ≤ 6 * Rg.card := by
    have h1 : Darts.card = ∑ b ∈ Rg, (Darts.filter (fun d => T.tail d = b)).card :=
      Finset.card_eq_sum_card_fiberwise (fun d hd => by
        simp only [Darts, mem_coe, mem_filter, mem_univ, true_and] at hd
        exact hd)
    have h2 : ∀ b ∈ Rg, (Darts.filter (fun d => T.tail d = b)).card ≤ 6 := by
      intro b _
      have h3 : Darts.filter (fun d => T.tail d = b) ⊆ univ.filter (fun d => T.tail d = b) := by
        intro d hd
        simp only [mem_filter, mem_univ, true_and] at hd ⊢
        exact hd.2
      exact (Finset.card_le_card h3).trans (hd6 b)
    rw [h1]
    calc ∑ b ∈ Rg, (Darts.filter (fun d => T.tail d = b)).card ≤ ∑ _b ∈ Rg, 6 :=
          Finset.sum_le_sum h2
      _ = 6 * Rg.card := by simp [mul_comm]
  show Bad.card ≤ 72 * 7 ^ Rad r
  omega

end Ful

end
