# FIDELITY.md: MathDB 358647, third Lean lane (credit 0, campaign 60/80 unchanged)

Checked against `inputs/sources/2306.01462.txt` (Bille, Buchstaber, Coste, Kuriki, Spodarev) and
`inputs/literal358647.json`. Lean definitions: `src/FulStatement.lean`.

## Source text, verbatim

Definition 2 (p. 3): "A fullerene (graph) is a finite, connected, 3-regular planar graph with faces
of degrees both 5 and 6."

Section 2.2 (p. 4): "If H = (V, E) is a graph and v ∈ V, we denote by B_H(v, r) the 'ball of radius r
around v', that is, the subgraph of H induced by all the vertices of H whose graph distance to v is
smaller than r. ... a sequence of finite random graphs (G_n) converges locally weakly towards (the
law of) a random rooted graph (G, o) if for any fixed integer r and fixed rooted graph (H, o),
P(B_{G_n}(o_n, r) is isomorphic to B_H(o, r)) → P(B_G(o, r) is isomorphic to B_H(o, r)) (4), where
o_n is itself a random element uniformly distributed over the vertices of G_n."

Conjecture 1: "Let F_n be a random fullerene, chosen uniformly on the set of fullerenes with n
vertices. The sequence (F_n) converges locally weakly towards the planar hexagonal lattice H."

Eq. (3): V(H) := { (√3 x + y √3/2, 3y/2 + c) ∈ R² | x, y ∈ Z, c ∈ {0,1} }, "and every vertex is
connected with its three nearest neighbors (w.r.t. the Euclidean distance) by an edge".

## Reading against root's reading

Root's reading agrees with the source on every point. No deviation that changes the claim was found.
Points the source leaves implicit are listed below, with the choice made and why.

## Modelling decisions

1. **Planar with faces, as a rotation system.** "Planar" is rendered as: the graph admits a rotation
   system with `V + F = E + 2` where faces are the orbits of `σ ∘ reverse`. For a connected graph this
   is the combinatorial definition of a planar (genus-0, cellular) embedding: a connected genus-0
   rotation system is equivalent to a planar embedding of a connected graph. The equivalence with
   topological planarity is classical (Heffter-Edmonds, Euler) and is not proved here.
2. **"Faces of degrees both 5 and 6".** Read as "every face has length 5 or 6", as the source's
   preceding paragraph states ("in fullerenes, one only allows faces with degree 5 or 6 and it turns
   out that the number of faces of degree 5 (called pentagons) must exactly be 12"). The alternative
   reading (at least one face of each degree) excludes only the dodecahedron (`n = 20`) and changes no
   limit. `IsFullerene.embedding` uses `faceLen d = 5 ∨ faceLen d = 6`, where face length is the length of
   the facial walk (orbit size of `φ`); a walk traversing an edge twice counts it twice. (Fullerenes
   are 3-connected, so all faces are cycles, but that is not assumed in the definition.)
3. **Simple.** The source's graphs have `E ⊂ V²` (no multi-edges), and Lean's `SimpleGraph` is simple and
   loopless by construction. Loops and parallel edges in the *dual* triangulation are proved absent
   (digon descent, `FulDigon`); no extra hypothesis.
4. **Vertex and edge counts.** `Nat.card V`, `Nat.card G.edgeSet`, `Nat.card` of the quotient by
   `SameCycle` for faces, avoiding `Fintype` instance arguments in the definition.
5. **Uniform over isomorphism classes.** "Chosen uniformly on the set of fullerenes with n vertices" is
   read as uniform over isomorphism classes of graphs on `n` vertices (`FullereneClass n`, the quotient of
   labelled fullerenes on `Fin n` by graph isomorphism). This is the standard chemical/graph-enumeration
   meaning (`F(n) ~ n^9`). Note the literature also knows the labelled model; the proof method is
   robust to it (the two models differ by bounded factors since |Aut| ≤ 120 by Whitney, not formalized
   here). Isomorphism is of graphs only, not of embeddings: a graph admitting two embeddings is one class.
   `fullereneBallProb` averages over classes then over the root.
6. **Representative of a class.** `fullereneBallProb` uses `Quotient.out`. The quantity `ballFraction` is
   invariant under graph isomorphism (`Ful.Stmt.ballFraction_congr` in `FulLatticeAut`), so the choice is
   immaterial.
7. **Along n with at least one fullerene.** `fullereneLimit = atTop ⊓ 𝓟 FullereneOrders` (root's reading).
   `NonVacuous` (`NeBot`) is proved, so the statement is not vacuous.
8. **Balls.** `ballSet G o r = {v | edist o v < r}` in `ℕ∞`, verbatim the source's strict inequality.
   Note that with this strict convention the source's `r` corresponds to the usual radius `r-1`. `dist`
   in Mathlib is `0` on unreachable pairs, so `edist` is used deliberately. `RootedBallIso` is an
   isomorphism of the induced subgraphs taking root to root; for `r = 0` the balls are empty and the
   root condition vacuous.
9. **"Fixed rooted graph (H, o)" of Eq. (4).** Quantified over *all* rooted simple graphs `(K, o)` in
   any universe; the source restricts to locally finite rooted graphs, so this is formally stronger.
10. **The random limit.** Since `H` is deterministic, `P(B_H(o, r) ≅ B_K(o', r))` is `1` or `0`;
    the statement uses `if RootedBallIso hexLattice hexRoot K o r then 1 else 0`.
11. **Lattice.** `hexLattice : SimpleGraph (ℤ × ℤ × Bool)`, adjacent iff `hexDist4 p q = 4`, where
    `hexDist4` is exactly `4 · |p − q|²` for the points of Eq. (3). `FulLattice` proves `hex_adj_iff` (exactly
    the three explicit neighbours) and `hexDist4_ge` (distinct points are at distance at least 1, so these
    are the nearest neighbours); the source's Euclidean description is thus literal. The root
    `hexRoot = (0,0,0)`; `FulLatticeAut.hex_vertexTransitive` proves the lattice is vertex-transitive, so
    the root is immaterial.

## The theorem as proved

`Ful.endpoint : LocalWeakConvergence.{v} ∧ NonVacuous` in `src/FulEndpoint.lean`, with
`Ful.localWeakConvergence : LocalWeakConvergence.{v}` (see `src/FulStatement.lean` for the definition, which
is Eq. (4) of the source with the conventions recorded above). `#print axioms` shows only `propext`,
`Classical.choice`, `Quot.sound`. Everything in `FulStatement` is a definition (no statement or conclusion
is assumed anywhere; `IsFullerene` carries no property of balls, tubes or sys).

## Further modelling decisions made during the proof (for the audit)

12. **Choice of embedding per class.** The fullerene property only asserts that SOME genus-0 embedding with
    faces of length 5 and 6 exists. A graph that admits several such embeddings is ONE class. For the proof each
    class fixes one embedding by `Classical.choose` (`embOf`), and only uses that embedding; no uniqueness of
    embeddings (Whitney) is proved or used. The exceptional set is defined per class through that embedding,
    so the counting is over the chosen maps; a class is exceptional as soon as its chosen embedding has a short
    essential cycle. Non-exceptional classes use the same embedding for the local isomorphism.
13. **Dual map on `Fin (3n)`.** The map of a fullerene graph is transported to `Fin (3n)` (`fmap`) so that the
    sealed fixed-dart-type counting theorem (`count_short_essential`) applies; the transport is a map isomorphism
    (`FulMapOf`), and graph isomorphism is recovered from map isomorphism of the duals (`graphIso_of_mapIso`).
14. **Non-vacuity.** `Ful.endpoint` also includes `NonVacuous`; the helical family gives fullerenes on every
    large even `n`, and all fullerene orders are even (`even_of_order`).
15. **Lower bound on F(n).** `F(n) → ∞` is obtained from the helical family with very different circumferences:
    `numFullerenes_ge` gives at least `M` classes for every large even `n`. Non-isomorphism is proved from two
    graph-distance bounds on the explicit family, not from `sys` or Whitney. This replaces the plan's route.

## What is NOT claimed

The MathDB entry's informal gloss ("rooted balls around uniformly chosen vertices converge in
distribution") is the same as Eq. (4). Everything else (proof status, novelty, significance) is for root.
