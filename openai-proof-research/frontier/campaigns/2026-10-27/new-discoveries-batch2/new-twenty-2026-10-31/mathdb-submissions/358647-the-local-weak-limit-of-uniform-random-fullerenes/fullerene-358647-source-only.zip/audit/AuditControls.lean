/- Gate E: axioms of the reviewer's controls, and the literal endpoint restated. Reviewer-authored. -/
import ControlFace

#print axioms Control.root_neighbor_card
#print axioms Control.root_not_adj_triangular
#print axioms Control.ball_counts
#print axioms Control.not_mem_strict
#print axioms Control.no_iso_rooted
#print axioms Control.no_iso_wrong_graph
#print axioms Control.fraction_P3
#print axioms Control.hex_root_iso
#print axioms Control.k4Planar_euler
#print axioms Control.k4Toroidal_no_euler
#print axioms Control.dodec_isFullerene
#print axioms Control.fullerene_ge_twenty
#print axioms Control.k4_not_fullerene
#print axioms Control.no_order_18
#print axioms Control.prism_euler
#print axioms Control.prism_has_square
#print axioms Control.prism_not_fullerene
#print axioms Control.helix_order_92

/-- The endpoint restated with the definitions unfolded by name, universe-polymorphic. -/
example : ∀ (r : ℕ) (W : Type 3) (K : SimpleGraph W) (o : W),
    Filter.Tendsto (fun n => Ful.Stmt.fullereneBallProb n r K o) Ful.Stmt.fullereneLimit
      (nhds (@ite ℝ (Ful.Stmt.RootedBallIso Ful.Stmt.hexLattice Ful.Stmt.hexRoot K o r)
        (Classical.propDecidable _) 1 0)) := fun r W K o => Ful.localWeakConvergence r W K o
