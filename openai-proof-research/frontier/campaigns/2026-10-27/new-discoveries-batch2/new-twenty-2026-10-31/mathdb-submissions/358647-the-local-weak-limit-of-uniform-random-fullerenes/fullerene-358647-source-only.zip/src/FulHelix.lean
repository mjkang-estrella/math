/-
FulHelix: explicit neighbour lists and index lists of the helical fullerene dual `T_s(m)`:
integer labels `[-s, m + s]`, circumference `L = 2 s + 5`.
-/
import FulTable

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

namespace Ful.Helix

/-- The circumference. -/
def Lp (s : ℤ) : ℤ := 2 * s + 5

/-- The part of a boundary vertex's rotation lying in the cap. -/
def cf (s y : ℤ) : List ℤ :=
  if y ≤ s - 1 then [-y, -y - 1]
  else if y ≤ s + 2 then [-s]
  else if y ≤ 2 * s + 1 then [y - 2 * s - 3, y - 2 * s - 2]
  else if y = 2 * s + 2 then [-1]
  else if y = 2 * s + 3 then [-1, 0]
  else [0]

/-- Reverse indices of the entries of `cf`. -/
def cfIx (s y : ℤ) : List ℕ :=
  if y ≤ s - 1 then [4, 5]
  else if y = s then [4]
  else if y = s + 1 then [3]
  else if y = s + 2 then [2]
  else if y ≤ 2 * s + 1 then [1, 2]
  else if y = 2 * s + 2 then [1]
  else if y = 2 * s + 3 then [0, 1]
  else [0]

def lowr (s y : ℤ) : List ℤ := if Lp s ≤ y then [y - Lp s, y - Lp s + 1] else cf s y
def upr (s m y : ℤ) : List ℤ :=
  if y ≤ m - Lp s then [y + Lp s, y + Lp s - 1] else (cf s (m - y)).map (fun x => m - x)

/-- The neighbours of an interior cap vertex. -/
def intA (s x : ℤ) : List ℤ :=
  [if x = -1 then 2 * s + 3 else x + 1, 2 * s + 3 + x, 2 * s + 2 + x,
    if x = -s then s + 1 else x - 1, -x, -x - 1]

/-- The rotation at a vertex. -/
def Nb (s m u : ℤ) : List ℤ :=
  if u ≤ -1 then intA s u
  else if u = 0 then [Lp s - 1, Lp s - 2, -1, 1, Lp s]
  else if u < m then (u - 1) :: (lowr s u ++ (u + 1) :: upr s m u)
  else if u = m then [m - Lp s + 1, m - Lp s + 2, m + 1, m - 1, m - Lp s]
  else (intA s (m - u)).map (fun x => m - x)

/-- The reverse indices. -/
def Ix (s m u : ℤ) : List ℕ :=
  if u ≤ -1 then
    [if u = -1 then 1 else 3, 1, if u = -s then 1 else 2, if u = -s then 1 else 0, 1, 2]
  else if u = 0 then [1, 2, 5, 0, 1]
  else if u < m then
    (1 + (lowr s (u - 1)).length) ::
      ((if Lp s ≤ u then [2 + (lowr s (u - Lp s)).length, 3 + (lowr s (u - Lp s + 1)).length]
        else cfIx s u) ++
        (if u + 1 = m then 3 else 0) ::
          (if u ≤ m - Lp s then [if u + Lp s = m then 4 else 1, 2] else cfIx s (m - u)))
  else if u = m then [4, 5, 5, 3, 4]
  else
    [if m - u = -1 then 4 else 3, 4, if m - u = -s then 4 else 5, if m - u = -s then 4 else 0, 4,
      if m - u = -1 then 2 else 5]

/-! ### Case analysis of the rotation -/

section

variable {s m y u : ℤ}

theorem ifT {α : Type*} {c : Prop} [Decidable c] {a b : α} (h : c) : (if c then a else b) = a := by
  simp [h]
theorem ifF {α : Type*} {c : Prop} [Decidable c] {a b : α} (h : ¬c) :
    (if c then a else b) = b := by simp [h]

theorem cf_a (h : y ≤ s - 1) : cf s y = [-y, -y - 1] := by
  unfold cf; simp [h]
theorem cf_b (hs : 1 ≤ s) (h1 : s ≤ y) (h2 : y ≤ s + 2) : cf s y = [-s] := by
  unfold cf; rw [ifF (by omega), ifT h2]
theorem cf_c (hs : 1 ≤ s) (h1 : s + 3 ≤ y) (h2 : y ≤ 2 * s + 1) :
    cf s y = [y - 2 * s - 3, y - 2 * s - 2] := by
  unfold cf; rw [ifF (by omega), ifF (by omega), ifT h2]
theorem cf_d (hs : 1 ≤ s) (h : y = 2 * s + 2) : cf s y = [-1] := by
  unfold cf; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifT h]
theorem cf_e (hs : 1 ≤ s) (h : y = 2 * s + 3) : cf s y = [-1, 0] := by
  unfold cf; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega), ifT h]
theorem cf_f (h1 : 0 ≤ s) (h : y = 2 * s + 4) : cf s y = [0] := by
  unfold cf; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega),
    ifF (by omega)]

theorem cfIx_a (h : y ≤ s - 1) : cfIx s y = [4, 5] := by
  unfold cfIx; rw [ifT h]
theorem cfIx_b0 (hs : 1 ≤ s) (h : y = s) : cfIx s y = [4] := by
  unfold cfIx; rw [ifF (by omega), ifT h]
theorem cfIx_b1 (hs : 1 ≤ s) (h : y = s + 1) : cfIx s y = [3] := by
  unfold cfIx; rw [ifF (by omega), ifF (by omega), ifT h]
theorem cfIx_b2 (hs : 1 ≤ s) (h : y = s + 2) : cfIx s y = [2] := by
  unfold cfIx; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifT h]
theorem cfIx_c (hs : 1 ≤ s) (h1 : s + 3 ≤ y) (h2 : y ≤ 2 * s + 1) : cfIx s y = [1, 2] := by
  unfold cfIx; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega),
    ifT h2]
theorem cfIx_d (hs : 1 ≤ s) (h : y = 2 * s + 2) : cfIx s y = [1] := by
  unfold cfIx
  rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega),
    ifT h]
theorem cfIx_e (hs : 1 ≤ s) (h : y = 2 * s + 3) : cfIx s y = [0, 1] := by
  unfold cfIx
  rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega),
    ifF (by omega), ifT h]
theorem cfIx_f (h1 : 0 ≤ s) (h : y = 2 * s + 4) : cfIx s y = [0] := by
  unfold cfIx
  rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega),
    ifF (by omega), ifF (by omega)]

theorem low_gen (h : Lp s ≤ y) : lowr s y = [y - Lp s, y - Lp s + 1] := by
  unfold lowr; rw [ifT h]
theorem low_cf (h : y < Lp s) : lowr s y = cf s y := by
  unfold lowr; rw [ifF (by omega)]
theorem up_gen (h : y ≤ m - Lp s) : upr s m y = [y + Lp s, y + Lp s - 1] := by
  unfold upr; rw [ifT h]
theorem up_cf (h : m - Lp s < y) : upr s m y = (cf s (m - y)).map (fun x => m - x) := by
  unfold upr; rw [ifF (by omega)]

theorem Nb_int (h : u ≤ -1) : Nb s m u = intA s u := by
  unfold Nb; rw [ifT h]
theorem Nb_zero (h : u = 0) : Nb s m u = [Lp s - 1, Lp s - 2, -1, 1, Lp s] := by
  unfold Nb; rw [ifF (by omega), ifT h]
theorem Nb_mid (h1 : 0 < u) (h2 : u < m) :
    Nb s m u = (u - 1) :: (lowr s u ++ (u + 1) :: upr s m u) := by
  unfold Nb; rw [ifF (by omega), ifF (by omega), ifT h2]
theorem Nb_m (h1 : 0 < u) (h : u = m) :
    Nb s m u = [m - Lp s + 1, m - Lp s + 2, m + 1, m - 1, m - Lp s] := by
  unfold Nb; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifT h]
theorem Nb_intB (h1 : 0 < m) (h : m < u) : Nb s m u = (intA s (m - u)).map (fun x => m - x) := by
  unfold Nb; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega)]

theorem Ix_int (h : u ≤ -1) : Ix s m u =
    [if u = -1 then 1 else 3, 1, if u = -s then 1 else 2, if u = -s then 1 else 0, 1, 2] := by
  unfold Ix; rw [ifT h]
theorem Ix_zero (h : u = 0) : Ix s m u = [1, 2, 5, 0, 1] := by
  unfold Ix; rw [ifF (by omega), ifT h]
theorem Ix_mid (h1 : 0 < u) (h2 : u < m) : Ix s m u =
    (1 + (lowr s (u - 1)).length) ::
      ((if Lp s ≤ u then [2 + (lowr s (u - Lp s)).length, 3 + (lowr s (u - Lp s + 1)).length]
        else cfIx s u) ++
        (if u + 1 = m then 3 else 0) ::
          (if u ≤ m - Lp s then [if u + Lp s = m then 4 else 1, 2] else cfIx s (m - u))) := by
  unfold Ix; rw [ifF (by omega), ifF (by omega), ifT h2]
theorem Ix_m (h1 : 0 < u) (h : u = m) : Ix s m u = [4, 5, 5, 3, 4] := by
  unfold Ix; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifT h]
theorem Ix_intB (h1 : 0 < m) (h : m < u) : Ix s m u =
    [if m - u = -1 then 4 else 3, 4, if m - u = -s then 4 else 5, if m - u = -s then 4 else 0, 4,
      if m - u = -1 then 2 else 5] := by
  unfold Ix; rw [ifF (by omega), ifF (by omega), ifF (by omega), ifF (by omega)]

end

end Ful.Helix
