/-
FulChart: the dart tables of a tube with two capped ends, and the whole-map isomorphism: two
triangulations with the same rooted cap codes, the same number of rings and the same first word
are isomorphic.
-/
import FulTube

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D] {D' : Type*} [Fintype D'] [DecidableEq D']

/-- Finite data of a rooted cap: the face permutation, the partial edge involution, the boundary. -/
@[ext] structure CapCode (a ℓ : ℕ) where
  ph : Fin a → Fin a
  al : Fin a → Option (Fin a)
  bd : Fin ℓ → Fin a

instance (a ℓ : ℕ) : Fintype (CapCode a ℓ) :=
  Fintype.ofEquiv ((Fin a → Fin a) × (Fin a → Option (Fin a)) × (Fin ℓ → Fin a))
    { toFun := fun x => ⟨x.1, x.2.1, x.2.2⟩
      invFun := fun c => ⟨c.ph, c.al, c.bd⟩
      left_inv := fun _ => rfl
      right_inv := fun _ => rfl }

namespace CMap

variable {M : CMap D} {M' : CMap D'}

/-- A chart of a face set by a cap code: the darts of `A` are numbered by `Fin a`, and the code
tables read the `φ`/`α` structure of `A`; `bdry` lists the boundary darts of the cap. -/
structure CapChart (M : CMap D) (A : Finset M.F) (bdry : ℕ → D) {a ℓ : ℕ} (c : CapCode a ℓ) where
  ι : Fin a → D
  inj : Function.Injective ι
  mem : ∀ x, M.face (ι x) ∈ A
  surj : ∀ d, M.face d ∈ A → ∃ x, ι x = d
  hφ : ∀ x, M.φ (ι x) = ι (c.ph x)
  hal_some : ∀ x y, c.al x = some y → M.α (ι x) = ι y
  hal_none : ∀ x, c.al x = none → M.face (M.α (ι x)) ∉ A
  hbd : ∀ j : Fin ℓ, ι (c.bd j) = bdry j.val

end CMap

/-- Dart coordinates of a capped tube. -/
abbrev Xc (a b ℓ H : ℕ) := Fin a ⊕ ((Fin H × Fin (2 * ℓ)) × Fin 3) ⊕ Fin b

def modP {ℓ : ℕ} (hℓ : 0 < ℓ) (n : ℕ) : Fin (2 * ℓ) := ⟨n % (2 * ℓ), Nat.mod_lt _ (by omega)⟩
def modL {ℓ : ℕ} (hℓ : 0 < ℓ) (n : ℕ) : Fin ℓ := ⟨n % ℓ, Nat.mod_lt _ hℓ⟩

section tables

variable {a b ℓ H : ℕ} (hℓ : 0 < ℓ) (hH : 0 < H) (Kf : ℕ → ℕ → ℕ)
  (cA : CapCode a ℓ) (cB : CapCode b ℓ)

/-- Index of the boundary position carrying a cap dart. -/
def idx {n : ℕ} (c : CapCode n ℓ) (x : Fin n) : ℕ :=
  if h : ∃ j : Fin ℓ, c.bd j = x then (Classical.choose h).val else 0

/-- Which block starts at position `m`. -/
def blkInv (K : ℕ → ℕ) (m : ℕ) : ℕ := if h : ∃ j, blk K j = m then Nat.find h else 0

/-- Number of `U` moves before position `m`. -/
def cntU (W : ℕ → Bool) (m : ℕ) : ℕ := Nat.count (fun x => W x = false) m

/-- The word at a level. -/
def Wf (Kf : ℕ → ℕ → ℕ) (i : ℕ) : ℕ → Bool := word (Kf i)

/-- Table of `φ` in coordinates. -/
def tabφ (cA : CapCode a ℓ) (cB : CapCode b ℓ) : Xc a b ℓ H → Xc a b ℓ H
  | .inl x => .inl (cA.ph x)
  | .inr (.inl (p, c)) => .inr (.inl (p, c + 1))
  | .inr (.inr x) => .inr (.inr (cB.ph x))

/-- Table of `α` on tube coordinates. -/
def tabT (i : Fin H) (m : Fin (2 * ℓ)) (c : Fin 3) : Xc a b ℓ H :=
  if c.val = 0 then
    if Wf Kf i m = true then
      if h : i.val = 0 then
        .inl (cA.bd (modL hℓ (blkInv (Kf i) m)))
      else
        .inr (.inl ((⟨i.val - 1, by have := i.isLt; omega⟩,
          modP hℓ (posU (Wf Kf (i.val - 1)) (blkInv (Kf i) m))), 1))
    else
      .inr (.inl ((i, modP hℓ (m.val + 1)), 2))
  else if c.val = 1 then
    if Wf Kf i m = true then
      .inr (.inl ((i, modP hℓ (m.val + 1)), 2))
    else if h : i.val + 1 < H then
      .inr (.inl ((⟨i.val + 1, h⟩,
        modP hℓ (blk (Kf (i.val + 1)) (cntU (Wf Kf i) m))), 0))
    else
      .inr (.inr (cB.bd (modL hℓ (cntU (Wf Kf i) m))))
  else
    .inr (.inl ((i, modP hℓ (m.val + 2 * ℓ - 1)),
      if Wf Kf i (m.val + 2 * ℓ - 1) = true then 1 else 0))

/-- Table of `α` in coordinates. -/
def tabα : Xc a b ℓ H → Xc a b ℓ H
  | .inl x =>
    match cA.al x with
    | some y => .inl y
    | none => .inr (.inl ((⟨0, hH⟩, modP hℓ (blk (Kf 0) (idx cA x))), 0))
  | .inr (.inl ((i, m), c)) => tabT hℓ hH Kf cA cB i m c
  | .inr (.inr x) =>
    match cB.al x with
    | some y => .inr (.inr y)
    | none =>
      .inr (.inl ((⟨H - 1, by omega⟩, modP hℓ (posU (Wf Kf (H - 1)) (idx cB x))), 1))

end tables

namespace CMap

variable {M : CMap D} {M' : CMap D'}

/-- Two maps whose darts are numbered with identical tables are isomorphic. -/
theorem iso_of_tables {X : Type*} {ψ : X → D} {ψ' : X → D'} (hψ : Function.Bijective ψ)
    (hψ' : Function.Bijective ψ') (tα tφ : X → X)
    (h1 : ∀ ξ, M.α (ψ ξ) = ψ (tα ξ)) (h2 : ∀ ξ, M.φ (ψ ξ) = ψ (tφ ξ))
    (h1' : ∀ ξ, M'.α (ψ' ξ) = ψ' (tα ξ)) (h2' : ∀ ξ, M'.φ (ψ' ξ) = ψ' (tφ ξ)) :
    Nonempty (MapIso M M') := by
  set e : D ≃ D' := (Equiv.ofBijective ψ hψ).symm.trans (Equiv.ofBijective ψ' hψ') with he
  have hE : ∀ ξ, e (ψ ξ) = ψ' ξ := by
    intro ξ
    simp only [he, Equiv.trans_apply]
    have : (Equiv.ofBijective ψ hψ).symm (ψ ξ) = ξ :=
      (Equiv.ofBijective ψ hψ).symm_apply_apply ξ
    rw [this]
    rfl
  refine ⟨⟨e, fun d => ?_, fun d => ?_⟩⟩
  · obtain ⟨ξ, rfl⟩ := hψ.2 d
    have ha : M.σ (ψ ξ) = M.φ (M.α (ψ ξ)) := by simp [CMap.φ_apply]
    have hb : M'.σ (ψ' ξ) = M'.φ (M'.α (ψ' ξ)) := by simp [CMap.φ_apply]
    rw [ha, h1, h2, hE, hE, hb, h1', h2']
  · obtain ⟨ξ, rfl⟩ := hψ.2 d
    rw [h1, hE, hE, h1']

namespace Tube

variable {ℓ H a b : ℕ} (T : Tube M ℓ H) {cA : CapCode a ℓ} {cB : CapCode b ℓ}
  (A : CapChart M (T.Q 0)ᶜ (fun j => M.α ((T.C 0).dart j)) cA)
  (B : CapChart M (T.Q H) (fun j => (T.C H).dart j) cB)

/-- The first-return exponents as a level-indexed table. -/
def Kf (T : Tube M ℓ H) (i j : ℕ) : ℕ := if i ≤ H then (T.C i).K j else 0

theorem Kf_eq {i : ℕ} (hi : i ≤ H) : T.Kf i = (T.C i).K := by
  funext j
  simp [Kf, hi]

theorem word_Kf {i : ℕ} (hi : i ≤ H) : Wf T.Kf i = (T.C i).W := by
  funext m
  simp only [Wf, SimpleCycle.W, T.Kf_eq hi]

/-- Corner points of the tube. -/
def psiT (T : Tube M ℓ H) (p : (Fin H × Fin (2 * ℓ)) × Fin 3) : D :=
  M.corN p.2.val ((T.C p.1.1.val).r p.1.2.val)

/-- The coordinate map of a capped tube. -/
def psi : Xc a b ℓ H → D := Sum.elim A.ι (Sum.elim T.psiT B.ι)

theorem psiT_face (p : (Fin H × Fin (2 * ℓ)) × Fin 3) :
    M.face (T.psiT p) = M.tri ((T.C p.1.1.val).r p.1.2.val) := face_corN p.2.isLt _

theorem psiT_inj {p q : (Fin H × Fin (2 * ℓ)) × Fin 3} (h : T.psiT p = T.psiT q) : p = q := by
  have hf := congrArg M.face h
  rw [T.psiT_face, T.psiT_face] at hf
  have hi : p.1.1.val = q.1.1.val := T.tri_level_inj p.1.1.isLt q.1.1.isLt hf
  have hp : p.1.1 = q.1.1 := Fin.ext hi
  rw [hi] at hf
  have hm : p.1.2.val = q.1.2.val := T.tri_pos_inj q.1.1.isLt p.1.2.isLt q.1.2.isLt hf
  have hp2 : p.1.2 = q.1.2 := Fin.ext hm
  have hc : p.2.val = q.2.val := by
    apply corN_ne T.hT ((T.C p.1.1.val).r p.1.2.val) p.2.isLt q.2.isLt
    have h' := h
    unfold psiT at h'
    rw [hi, hm] at h'
    rw [hi, hm]
    exact h'
  exact Prod.ext (Prod.ext hp hp2) (Fin.ext hc)

variable {T A B}

theorem A_face_not (x : Fin a) : M.face (A.ι x) ∉ T.Q 0 := by
  have := A.mem x
  simpa using this

/-- A ring triangle is on the `Q 0` side, unlike a cap-A face. -/
theorem psi_inj : Function.Injective (T.psi A B) := by
  rintro (x | ⟨p⟩ | x) (y | ⟨q⟩ | y) h
  all_goals simp only [psi, Sum.elim_inl, Sum.elim_inr] at h
  · exact congrArg _ (A.inj h)
  · exfalso
    have h1 := T.A_face_not (A := A) x
    rw [h, T.psiT_face] at h1
    exact h1 (T.Q_subset (Nat.zero_le _) q.1.1.isLt.le (T.tri_ring q.1.1.isLt _).1)
  · exfalso
    have h1 := T.A_face_not (A := A) x
    rw [h] at h1
    exact h1 (T.Q_subset (Nat.zero_le _) le_rfl (B.mem y))
  · exfalso
    have h1 := T.A_face_not (A := A) y
    rw [← h, T.psiT_face] at h1
    exact h1 (T.Q_subset (Nat.zero_le _) p.1.1.isLt.le (T.tri_ring p.1.1.isLt _).1)
  · exact congrArg _ (congrArg _ (T.psiT_inj h))
  · exfalso
    have h1 := T.tri_not_mem_succ p.1.1.isLt p.1.2.val
    rw [← T.psiT_face (p := p), h] at h1
    exact h1 (T.Q_subset (by have := p.1.1.isLt; omega) le_rfl (B.mem y))
  · exfalso
    have h1 := T.A_face_not (A := A) y
    rw [← h] at h1
    exact h1 (T.Q_subset (Nat.zero_le _) le_rfl (B.mem x))
  · exfalso
    have h1 := T.tri_not_mem_succ q.1.1.isLt q.1.2.val
    rw [← T.psiT_face (p := q), ← h] at h1
    exact h1 (T.Q_subset (by have := q.1.1.isLt; omega) le_rfl (B.mem x))
  · exact congrArg _ (congrArg _ (B.inj h))

theorem psi_surj : Function.Surjective (T.psi A B) := by
  intro d
  by_cases h0 : M.face d ∈ T.Q 0
  · by_cases hH : M.face d ∈ T.Q H
    · obtain ⟨x, rfl⟩ := B.surj d hH
      exact ⟨.inr (.inr x), rfl⟩
    · obtain ⟨i, hi, h1, h2⟩ := T.exists_level h0 hH
      obtain ⟨m, hm, htri⟩ := T.exists_cover hi h1 h2
      have hd : M.face d = M.tri ((T.C i).r m) := htri.symm
      rcases eq_cor_of_face T.hT hd with h | h | h
      · exact ⟨.inr (.inl ((⟨i, hi⟩, ⟨m, hm⟩), 0)), h.symm⟩
      · exact ⟨.inr (.inl ((⟨i, hi⟩, ⟨m, hm⟩), 1)), h.symm⟩
      · exact ⟨.inr (.inl ((⟨i, hi⟩, ⟨m, hm⟩), 2)), h.symm⟩
  · obtain ⟨x, rfl⟩ := A.surj d (by simpa using h0)
    exact ⟨.inl x, rfl⟩

theorem psi_bij : Function.Bijective (T.psi A B) := ⟨psi_inj, psi_surj⟩

/-- `φ` in coordinates. -/
theorem charted_φ (ξ : Xc a b ℓ H) : M.φ (T.psi A B ξ) = T.psi A B (tabφ cA cB ξ) := by
  rcases ξ with x | ⟨⟨p, c⟩⟩ | x
  · exact A.hφ x
  · simp only [psi, Sum.elim_inr, Sum.elim_inl, tabφ, psiT]
    have h := φ_corN T.hT c.isLt ((T.C p.1.val).r p.2.val)
    rw [h]
    congr 1
  · exact B.hφ x

/-! ### α in coordinates -/

theorem blkInv_spec {K : ℕ → ℕ} {m : ℕ} (h : ∃ j, blk K j = m) : blk K (blkInv K m) = m := by
  simp only [blkInv, dite_eq_left h]
  exact Nat.find_spec h

theorem idx_spec {n : ℕ} {c : CapCode n ℓ} {x : Fin n} (h : ∃ j : Fin ℓ, c.bd j = x)
 : c.bd ⟨idx c x, by simp only [idx, dite_eq_left h]; exact (Classical.choose h).isLt⟩ = x := by
  have h1 : (Classical.choose h) = ⟨idx c x, by simp only [idx, dite_eq_left h]; exact (Classical.choose h).isLt⟩ := by
    apply Fin.ext
    simp only [idx, dite_eq_left h]
  rw [← h1]
  exact Classical.choose_spec h

theorem dart_mod_ℓ (T : Tube M ℓ H) {i : ℕ} (hi : i ≤ H) (j : ℕ) :
    (T.C i).dart (j % ℓ) = (T.C i).dart j := by
  have h := (T.C i).dart_mod j
  rwa [T.len i hi] at h

/-- The first dart of a ring is a dart of its lower cycle, with its block start as index. -/
theorem cor0_blk {i : ℕ} (hi : i < H) (j : ℕ) :
    M.cor0 ((T.C i).r (blk (T.C i).K j % (2 * ℓ))) = (T.C i).dart j := by
  rw [T.r_mod2 hi]
  exact SimpleCycle.σ_r_blk (T.hlen hi.le) (T.K2 i hi) j

/-- The top dart reversal. -/
theorem α_topDart {i : ℕ} (k : ℕ) :
    M.α ((T.C i).topDart k) = M.cor1 ((T.C i).r (posU (T.C i).W k)) := by
  simp [SimpleCycle.topDart]

/-- Cap-A: a dart with no successor inside the cap is a boundary dart. -/
theorem capA_bd (A : CapChart M (T.Q 0)ᶜ (fun j => M.α ((T.C 0).dart j)) cA) {x : Fin a}
    (hal : cA.al x = none) : ∃ j : Fin ℓ, cA.bd j = x := by
  have hn := A.hal_none x hal
  have h0 : M.face (M.α (A.ι x)) ∈ T.Q 0 := by simpa using hn
  have h1 := T.A_face_not (A := A) x
  have he : M.edge (A.ι x) ∈ (T.C 0).edges := (T.side 0 (Nat.zero_le _) _).2 fun hiff => h1 (hiff.2 h0)
  obtain ⟨i0, hi0⟩ := (T.C 0).exists_of_edge_mem he
  rcases M.edge_eq_iff.1 hi0 with h | h
  · exact absurd (h ▸ T.orient 0 (Nat.zero_le _) i0) h1
  · refine ⟨⟨i0 % ℓ, Nat.mod_lt _ T.ℓ_pos⟩, A.inj ?_⟩
    rw [A.hbd, h]
    show M.α ((T.C 0).dart (i0 % ℓ)) = _
    rw [T.dart_mod_ℓ (Nat.zero_le _)]

/-- Cap-B: a dart with no successor inside the cap is a boundary dart. -/
theorem capB_bd (B : CapChart M (T.Q H) (fun j => (T.C H).dart j) cB) {x : Fin b}
    (hal : cB.al x = none) : ∃ j : Fin ℓ, cB.bd j = x := by
  have hn := B.hal_none x hal
  have h1 := B.mem x
  have he : M.edge (B.ι x) ∈ (T.C H).edges := (T.side H le_rfl _).2 fun hiff => hn (hiff.1 h1)
  obtain ⟨i0, hi0⟩ := (T.C H).exists_of_edge_mem he
  rcases M.edge_eq_iff.1 hi0 with h | h
  · refine ⟨⟨i0 % ℓ, Nat.mod_lt _ T.ℓ_pos⟩, B.inj ?_⟩
    rw [B.hbd, h]
    show (T.C H).dart (i0 % ℓ) = _
    rw [T.dart_mod_ℓ le_rfl]
  · exfalso
    have h2 := T.orient H le_rfl i0
    have h3 := (T.side H le_rfl (M.α ((T.C H).dart i0))).1 (by rw [M.edge_α]; exact (T.C H).edge_mem i0)
    apply h3
    rw [h] at h1
    rw [M.α_α]
    exact iff_of_true h1 h2

theorem charted_tube (i : Fin H) (m : Fin (2 * ℓ)) (c : Fin 3) :
    M.α (M.corN c.val ((T.C i.val).r m.val)) =
      T.psi A B (tabT T.ℓ_pos T.hH T.Kf cA cB i m c) := by
  have hKi := T.Kf_eq i.isLt.le
  have hWi : Wf T.Kf i.val = (T.C i.val).W := T.word_Kf i.isLt.le
  have hP := T.P_eq i.val i.isLt
  have hi := i.isLt
  obtain ⟨iN, hiN⟩ := i
  simp only at hKi hWi hP hi ⊢
  unfold tabT
  simp only [hWi]
  by_cases hc0 : c.val = 0
  · rw [ite_eq_left hc0, hc0]
    show M.α (M.cor0 ((T.C iN).r m.val)) = _
    by_cases hw : (T.C iN).W m.val = true
    · simp only [ite_eq_left hw]
      have hex : ∃ j, blk (T.C iN).K j = m.val := word_eq_true_iff.1 hw
      have hj : blk (T.C iN).K (blkInv (T.C iN).K m.val) = m.val := blkInv_spec hex
      rw [hKi] 
      set j := blkInv (T.C iN).K m.val with hjdef
      have hd : M.cor0 ((T.C iN).r m.val) = (T.C iN).dart j := by
        rw [← hj]
        exact SimpleCycle.σ_r_blk (T.hlen hi.le) (T.K2 iN hi) j
      rw [hd]
      by_cases hi0 : iN = 0
      · subst hi0
        rw [dite_eq_left rfl]
        show _ = A.ι (cA.bd (modL T.ℓ_pos j))
        rw [A.hbd]
        show M.α ((T.C 0).dart j) = M.α ((T.C 0).dart (j % ℓ))
        rw [T.dart_mod_ℓ (Nat.zero_le _)]
      · obtain ⟨i', rfl⟩ := Nat.exists_eq_succ_of_ne_zero hi0
        rw [dite_eq_right hi0]
        simp only [Nat.succ_eq_add_one, Nat.add_sub_cancel]
        have hW' : Wf T.Kf i' = (T.C i').W := T.word_Kf (by omega)
        rw [hW']
        show _ = M.corN 1 ((T.C i').r (posU (T.C i').W j % (2 * ℓ)))
        rw [T.r_mod2 (by omega), T.tops i' (by omega) j]
        exact T.α_topDart j
    · have hw' : (T.C iN).W m.val = false := by simpa using hw
      simp only [ite_eq_right hw]
      show _ = M.corN 2 ((T.C iN).r ((m.val + 1) % (2 * ℓ)))
      rw [T.r_mod2 hi]
      exact α_cor0_of_false hw'
  · rw [ite_eq_right hc0]
    by_cases hc1 : c.val = 1
    · rw [ite_eq_left hc1, hc1]
      show M.α (M.cor1 ((T.C iN).r m.val)) = _
      by_cases hw : (T.C iN).W m.val = true
      · simp only [ite_eq_left hw]
        show _ = M.corN 2 ((T.C iN).r ((m.val + 1) % (2 * ℓ)))
        rw [T.r_mod2 hi]
        exact α_cor1_of_true hw
      · have hw' : (T.C iN).W m.val = false := by simpa using hw
        simp only [ite_eq_right hw]
        set k := cntU (T.C iN).W m.val with hk
        have hposk : posU (T.C iN).W k = m.val := posU_count hw'
        have htop : M.α (M.cor1 ((T.C iN).r m.val)) = (T.C iN).topDart k := by
          simp only [SimpleCycle.topDart]
          rw [hposk]
        rw [htop, ← T.tops iN hi k]
        by_cases hlt : iN + 1 < H
        · rw [dite_eq_left hlt]
          have hKs : T.Kf (iN + 1) = (T.C (iN + 1)).K := T.Kf_eq hlt.le
          rw [hKs]
          show _ = M.corN 0 ((T.C (iN + 1)).r (blk (T.C (iN + 1)).K k % (2 * ℓ)))
          exact (T.cor0_blk hlt k).symm
        · rw [dite_eq_right hlt]
          have hEq : iN + 1 = H := by omega
          subst hEq
          show _ = B.ι (cB.bd (modL T.ℓ_pos k))
          rw [B.hbd]
          show _ = (T.C (iN + 1)).dart (k % ℓ)
          rw [T.dart_mod_ℓ le_rfl]
    · have hc2 : c.val = 2 := by have := c.isLt; omega
      rw [ite_eq_right hc1, hc2]
      show M.α (M.cor2 ((T.C iN).r m.val)) = _
      rw [α_cor2]
      have hn : m.val + 2 * ℓ - 1 + 1 = m.val + 2 * ℓ := by have := T.ℓ_pos; omega
      have hrmd : (T.C iN).r m.val = (T.C iN).r (m.val + 2 * ℓ) := by
        have h' := SimpleCycle.r_add_P (T.hlen hi.le) (T.K2 iN hi) m.val
        rw [hP] at h'
        exact h'.symm
      rw [hrmd, ← hn]
      show M.rung _ _ _ = _
      rw [rung_succ, Nat.add_sub_cancel]
      show _ = M.corN _ ((T.C iN).r ((m.val + 2 * ℓ - 1) % (2 * ℓ)))
      rw [T.r_mod2 hi]
      by_cases hw : (T.C iN).W (m.val + 2 * ℓ - 1) = true
      · simp only [hw, ite_true]
        show M.mv _ _ = _
        simp [mv, hw]
        rfl
      · have hw' : (T.C iN).W (m.val + 2 * ℓ - 1) = false := by simpa using hw
        simp only [hw', ite_false]
        show M.mv _ _ = _
        simp [mv, hw', cor0, corN]
        rfl

theorem charted_α (ξ : Xc a b ℓ H) :
    M.α (T.psi A B ξ) = T.psi A B (tabα T.ℓ_pos T.hH T.Kf cA cB ξ) := by
  rcases ξ with x | ⟨⟨p, c⟩⟩ | x
  · cases hal : cA.al x with
    | some y => simp only [tabα, hal]; exact A.hal_some x y hal
    | none =>
      simp only [tabα, hal]
      obtain ⟨j, hj⟩ := capA_bd A hal
      have hspec := idx_spec (c := cA) ⟨j, hj⟩
      have hι : A.ι x = M.α ((T.C 0).dart (idx cA x)) := by
        conv_lhs => rw [← hspec]
        rw [A.hbd]
      show M.α (A.ι x) = M.corN 0 ((T.C 0).r ((blk (T.Kf 0) (idx cA x)) % (2 * ℓ)))
      rw [T.Kf_eq (Nat.zero_le _)]
      show _ = M.cor0 _
      rw [T.cor0_blk T.hH, hι, M.α_α]
  · exact T.charted_tube (A := A) (B := B) p.1 p.2 c
  · cases hal : cB.al x with
    | some y => simp only [tabα, hal]; exact B.hal_some x y hal
    | none =>
      simp only [tabα, hal]
      obtain ⟨j, hj⟩ := capB_bd B hal
      have hspec := idx_spec (c := cB) ⟨j, hj⟩
      have hι : B.ι x = (T.C H).dart (idx cB x) := by
        conv_lhs => rw [← hspec]
        rw [B.hbd]
      have hH1 : H - 1 < H := by have := T.hH; omega
      have hWf : Wf T.Kf (H - 1) = (T.C (H - 1)).W := T.word_Kf hH1.le
      show M.α (B.ι x) = M.corN 1 ((T.C (H - 1)).r (posU (Wf T.Kf (H - 1)) (idx cB x) % (2 * ℓ)))
      rw [hWf, T.r_mod2 hH1]
      have hHe : H - 1 + 1 = H := by have := T.hH; omega
      have h2 : M.α ((T.C H).dart (idx cB x)) = M.cor1 ((T.C (H - 1)).r (posU (T.C (H - 1)).W (idx cB x))) := by
        have h3 := T.tops (H - 1) hH1 (idx cB x)
        rw [hHe] at h3
        rw [h3]
        exact T.α_topDart _
      rw [hι]
      exact h2

end Tube

/-- **Whole-map determinism.** Two triangulations which are stacks of `H` clean rings of length `ℓ`
with the same first-return exponents on the first cycle and the same two rooted cap codes are
isomorphic. -/
theorem Tube.iso {ℓ H a b : ℕ} (T : Tube M ℓ H) (T' : Tube M' ℓ H)
    (hK : ∀ j, (T.C 0).K j = (T'.C 0).K j) {cA : CapCode a ℓ} {cB : CapCode b ℓ}
    (A : CapChart M (T.Q 0)ᶜ (fun j => M.α ((T.C 0).dart j)) cA)
    (B : CapChart M (T.Q H) (fun j => (T.C H).dart j) cB)
    (A' : CapChart M' (T'.Q 0)ᶜ (fun j => M'.α ((T'.C 0).dart j)) cA)
    (B' : CapChart M' (T'.Q H) (fun j => (T'.C H).dart j) cB) :
    Nonempty (MapIso M M') := by
  have hlev : ∀ i, i ≤ H → (T.C i).K = (T'.C i).K := by
    intro i hi
    induction i with
    | zero => funext j; exact hK j
    | succ i ih =>
      have hW : (T.C i).W = (T'.C i).W := by
        unfold SimpleCycle.W
        rw [ih (by omega)]
      funext k
      rw [T.K_rec (by omega), T'.K_rec (by omega), hW]
  have hKf : T.Kf = T'.Kf := by
    funext i j
    unfold Tube.Kf
    by_cases hi : i ≤ H
    · rw [ite_eq_left hi, ite_eq_left hi, hlev i hi]
    · rw [ite_eq_right hi, ite_eq_right hi]
  have h1' : ∀ ξ, M'.α (T'.psi A' B' ξ) =
      T'.psi A' B' (tabα T.ℓ_pos T.hH T.Kf cA cB ξ) := by
    intro ξ
    rw [hKf]
    exact Tube.charted_α ξ
  exact iso_of_tables (ψ := T.psi A B) (ψ' := T'.psi A' B') Tube.psi_bij Tube.psi_bij
    (tabα T.ℓ_pos T.hH T.Kf cA cB) (tabφ cA cB)
    (fun ξ => Tube.charted_α ξ) (fun ξ => Tube.charted_φ ξ) h1' (fun ξ => Tube.charted_φ ξ)

end CMap

end Ful

end
