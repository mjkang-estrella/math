/-
FulEss: essential and shortest essential cycles, total curvature, degree six on essential
cycles, and the reversal of a simple cycle.
-/
import FulCount

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- A cycle is essential if each side carries curvature at least six. -/
def Essential (C : SimpleCycle M) (S : Finset M.F) : Prop :=
  IsSide C S ∧ 6 ≤ C.curv S ∧ 6 ≤ C.curv Sᶜ

/-- A cycle no longer than any essential cycle. -/
def IsShortest (C : SimpleCycle M) : Prop :=
  ∀ (C' : SimpleCycle M) (S' : Finset M.F), Essential C' S' → C.len ≤ C'.len

/-- Total curvature of a triangulated sphere. -/
theorem sum_curv (hT : M.IsTriangulation) (hg : M.Genus0) :
    ∑ v : M.V, (6 - (M.deg v : ℤ)) = 12 := by
  have hV : Fintype.card D = ∑ v : M.V, M.deg v := by
    have h := count_fiber (D := D) M.tail (fun _ => True)
    simpa [deg] using h
  have hF : Fintype.card D = 3 * Fintype.card M.F := by
    have h := hT.corners_card (univ : Finset M.F)
    simpa using h
  have hE : Fintype.card D = 2 * Fintype.card M.E := by
    have h := count_fiber (D := D) M.edge (fun _ => True)
    have h1 : ∀ e : M.E, (univ.filter (fun d => M.edge d = e ∧ True)).card = 2 := by
      intro e
      obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
      have := card_edge_and M (fun _ => True) d
      show (univ.filter (fun x => M.edge x = M.edge d ∧ True)).card = 2
      simpa using this
    simp only [h1] at h
    simpa [mul_comm] using h
  have hgen : Fintype.card M.V + Fintype.card M.F = Fintype.card M.E + 2 := hg
  rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, ← Nat.cast_sum, ← hV]
  omega

variable {C : SimpleCycle M} {S : Finset M.F}

/-- Curvature splits over the two sides and the cycle. -/
theorem IsSide.curv_split (h : IsSide C S) (hT : M.IsTriangulation) (hg : M.Genus0) :
    C.curv S + C.curv Sᶜ + ∑ v ∈ C.verts, (6 - (M.deg v : ℤ)) = 12 := by
  have huniv : (C.intV S ∪ C.intV Sᶜ) ∪ C.verts = univ := by
    ext v
    simp only [mem_union, mem_univ, iff_true]
    rcases h.vertex_trichotomy v with h1 | h1 | h1
    · exact Or.inr h1
    · exact Or.inl (Or.inl h1)
    · exact Or.inl (Or.inr h1)
  have hd1 : Disjoint (C.intV S) (C.intV Sᶜ) := h.disjoint_intV
  have hd2 : Disjoint (C.intV S ∪ C.intV Sᶜ) C.verts := by
    rw [Finset.disjoint_union_left]
    constructor
    · exact Finset.disjoint_left.2 fun v hv hv2 => (Finset.mem_sdiff.1 hv).2 hv2
    · exact Finset.disjoint_left.2 fun v hv hv2 => (Finset.mem_sdiff.1 hv).2 hv2
  have h1 := sum_curv hT hg
  rw [← huniv, Finset.sum_union hd2, Finset.sum_union hd1] at h1
  exact h1

/-- On an essential cycle in a degree-at-most-six triangulated sphere: each side has curvature
exactly six and every cycle vertex has degree six. -/
theorem Essential.split (hE : Essential C S) (hT : M.IsTriangulation) (hg : M.Genus0)
    (hdeg : ∀ v, M.deg v ≤ 6) :
    C.curv S = 6 ∧ C.curv Sᶜ = 6 ∧ ∀ v ∈ C.verts, M.deg v = 6 := by
  obtain ⟨h, h1, h2⟩ := hE
  have hs := h.curv_split hT hg
  have hnn : ∀ v ∈ C.verts, (0 : ℤ) ≤ 6 - (M.deg v : ℤ) := fun v _ => by
    have := hdeg v; omega
  have hsum0 : 0 ≤ ∑ v ∈ C.verts, (6 - (M.deg v : ℤ)) := Finset.sum_nonneg hnn
  have ha : C.curv S = 6 := by omega
  have hb : C.curv Sᶜ = 6 := by omega
  have hz : ∑ v ∈ C.verts, (6 - (M.deg v : ℤ)) = 0 := by omega
  refine ⟨ha, hb, fun v hv => ?_⟩
  have := (Finset.sum_eq_zero_iff_of_nonneg hnn).1 hz v hv
  omega

theorem Essential.compl (hE : Essential C S) : Essential C Sᶜ := by
  obtain ⟨h, h1, h2⟩ := hE
  exact ⟨IsSide.compl C h, h2, by rwa [compl_compl]⟩

namespace SimpleCycle

variable (C)

theorem dart_add_mul (n m : ℕ) : C.dart (n + m * C.len) = C.dart n := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [show n + (m + 1) * C.len = n + m * C.len + C.len by ring, C.periodic, ih]

/-- Reversal of a simple cycle. -/
def rev : SimpleCycle M where
  len := C.len
  len_pos := C.len_pos
  dart j := M.α (C.dart ((C.len - 1) * (j + 1)))
  periodic j := by
    congr 1
    rw [show (C.len - 1) * (j + C.len + 1) = (C.len - 1) * (j + 1) + (C.len - 1) * C.len by ring]
    exact C.dart_add_mul _ _
  chain j := by
    rw [M.α_α, C.chain]
    have hk : (C.len - 1) * (j + 1 + 1) + 1 = (C.len - 1) * (j + 1) + C.len := by
      have := C.len_pos
      obtain ⟨k, hk⟩ : ∃ k, C.len = k + 1 := ⟨C.len - 1, by omega⟩
      rw [hk]
      simp only [Nat.add_sub_cancel]
      ring
    rw [hk, C.periodic]
  tail_inj i j hi hj hij := by
    rw [C.chain, C.chain] at hij
    have h1 : (C.len - 1) * (i + 1) + 1 ≡ (C.len - 1) * (j + 1) + 1 [MOD C.len] := C.tail_eq_mod hij
    have h2 : (C.len - 1) * (i + 1) ≡ (C.len - 1) * (j + 1) [MOD C.len] :=
      Nat.ModEq.add_right_cancel' 1 h1
    have hgcd : Nat.gcd C.len (C.len - 1) = 1 := by
      obtain ⟨k, hk⟩ : ∃ k, C.len = k + 1 := ⟨C.len - 1, by have := C.len_pos; omega⟩
      rw [hk]
      simp
    have h3 := Nat.ModEq.cancel_left_of_coprime hgcd h2
    have h4 : i ≡ j [MOD C.len] := Nat.ModEq.add_right_cancel' 1 h3
    have := Nat.ModEq.eq_of_lt_of_lt h4 hi hj
    exact this
  edge_inj i j hi hj hij := by
    rw [M.edge_α, M.edge_α] at hij
    have h1 : (C.len - 1) * (i + 1) ≡ (C.len - 1) * (j + 1) [MOD C.len] := C.edge_eq_mod hij
    have hgcd : Nat.gcd C.len (C.len - 1) = 1 := by
      obtain ⟨k, hk⟩ : ∃ k, C.len = k + 1 := ⟨C.len - 1, by have := C.len_pos; omega⟩
      rw [hk]
      simp
    have h3 := Nat.ModEq.cancel_left_of_coprime hgcd h1
    have h4 : i ≡ j [MOD C.len] := Nat.ModEq.add_right_cancel' 1 h3
    exact Nat.ModEq.eq_of_lt_of_lt h4 hi hj

@[simp] theorem rev_len : C.rev.len = C.len := rfl

theorem rev_dart (j : ℕ) : C.rev.dart j = M.α (C.dart ((C.len - 1) * (j + 1))) := rfl

theorem rev_edges : C.rev.edges = C.edges := by
  apply Finset.eq_of_subset_of_card_le
  · intro e he
    obtain ⟨i, rfl⟩ := C.rev.exists_of_edge_mem he
    rw [rev_dart, M.edge_α]
    exact C.edge_mem _
  · rw [card_edges, card_edges, rev_len]

theorem verts_eq_of_edges_eq {C1 C2 : SimpleCycle M} (h : C1.edges = C2.edges) :
    C1.verts = C2.verts := by
  have key : ∀ {A B : SimpleCycle M}, A.edges = B.edges → A.verts ⊆ B.verts := by
    intro A B hAB v hv
    obtain ⟨i, rfl⟩ := A.exists_of_vert_mem hv
    exact B.tail_mem_of_edge_mem (hAB ▸ A.edge_mem i)
  exact Finset.Subset.antisymm (key h) (key h.symm)

theorem isSide_of_edges_eq {C1 C2 : SimpleCycle M} (h : C1.edges = C2.edges) {S : Finset M.F}
    (hS : IsSide C2 S) : IsSide C1 S := by
  intro d
  rw [h]
  exact hS d

theorem curv_of_edges_eq {C1 C2 : SimpleCycle M} (h : C1.edges = C2.edges) (S : Finset M.F) :
    C1.curv S = C2.curv S := by
  unfold curv intV
  rw [verts_eq_of_edges_eq h]

theorem essential_of_edges_eq {C1 C2 : SimpleCycle M} (h : C1.edges = C2.edges) {S : Finset M.F}
    (hE : Essential C2 S) : Essential C1 S :=
  ⟨isSide_of_edges_eq h hE.1, by rw [curv_of_edges_eq h]; exact hE.2.1,
    by rw [curv_of_edges_eq h]; exact hE.2.2⟩

/-- The reversal of a cycle oriented into `Q` is oriented into the complement. -/
theorem rev_orient {Q : Finset M.F} (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q) (j : ℕ) :
    M.face (C.rev.dart j) ∈ Qᶜ := by
  rw [rev_dart, mem_compl]
  intro hm
  exact (h _).1 (C.edge_mem _) (iff_of_true (hor _) hm)

theorem IsShortest_rev (h : IsShortest C) : IsShortest C.rev := h

end SimpleCycle

end CMap

end Ful

end
