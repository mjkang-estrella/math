/-
FulDigon: the dual of a fullerene map is simple.  Loops of the dual are excluded by a count along
the facial walk (faces of length ≤ 6, the fullerene is simple and cubic).  Digons are excluded by
the descent: a digon side has curvature ≥ 6, and a minimal digon side yields a smaller one.
-/
import FulBridge

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-! ### No loops in the dual -/

private theorem fold_small (hs : M.IsSimple) (hc3 : ∀ v, M.deg v = 3) (d : D) :
    (M.φ d ≠ M.α d) ∧ (M.φ (M.φ d) ≠ M.α d) ∧ (M.φ (M.φ (M.φ d)) ≠ M.α d) := by
  refine ⟨fun h1 => ?_, fun h2 => ?_, fun h3 => ?_⟩
  · have hσ : (M.σ ^ 1) (M.α d) = M.α d := by rw [pow_one]; exact h1
    have := (pow_eq_self_iff_of_deg (hc3 (M.tail (M.α d))) (by norm_num) 1).1 hσ
    omega
  · have ht1 : M.tail (M.φ d) = M.tail (M.α d) := M.tail_φ d
    have ht2 : M.tail (M.α (M.φ d)) = M.tail (M.α d) := by
      rw [← h2]
      exact (M.tail_φ _).symm
    exact hs.1 (M.φ d) (ht1.trans ht2.symm)
  · have ht1 : M.tail (M.φ d) = M.tail (M.α (M.φ (M.φ d))) := by
      rw [M.tail_φ, ← M.tail_φ (M.φ (M.φ d)), h3]
    have ht2 : M.tail (M.α (M.φ d)) = M.tail (M.α (M.α (M.φ (M.φ d)))) := by
      rw [M.α_α]
      exact (M.tail_φ _).symm
    have he : M.φ d = M.α (M.φ (M.φ d)) := hs.2 _ _ ht1 ht2
    have hσ1 : M.σ (M.α d) = M.φ d := rfl
    have hσ2 : M.σ (M.φ d) = M.α d := by
      rw [he]
      exact h3
    have hσ : (M.σ ^ 2) (M.α d) = M.α d := by
      rw [pow_two, Perm.mul_apply, hσ1, hσ2]
    have := (pow_eq_self_iff_of_deg (hc3 (M.tail (M.α d))) (by norm_num) 2).1 hσ
    omega

/-- In a fullerene map a dart and its reverse are never on the same face. -/
theorem IsFullerene.no_fold (h : M.IsFullerene) (d : D) : ¬ SameCycle M.φ d (M.α d) := by
  intro hsc
  have hdual : ∀ x : D, (M.φ ^ (M.dual.deg (M.dual.tail x))) x = x := by
    intro x
    have hN := pow_eq_self_iff_of_deg (M := M.dual) (x := x) rfl
      (by rcases h.dual_deg (M.dual.tail x) with h1 | h1 <;> omega) (M.dual.deg (M.dual.tail x))
    exact hN.2 (dvd_refl _)
  have hm5 : M.dual.deg (M.dual.tail d) = 5 ∨ M.dual.deg (M.dual.tail d) = 6 := h.dual_deg _
  obtain ⟨n, -, hn⟩ := hsc.exists_pow_eq'
  have hi := pow_mod_apply (hdual d) n
  set m := M.dual.deg (M.dual.tail d) with hm
  have hilt : n % m < m := Nat.mod_lt _ (by rcases hm5 with h1 | h1 <;> omega)
  rw [hn] at hi
  have hi0 : n % m ≠ 0 := by
    intro h0
    rw [h0, pow_zero, Perm.one_apply] at hi
    exact M.α_ne d hi.symm
  have hfs := fun x => fold_small h.simple h.cubic x
  set i := n % m with hidef
  have hi1 : i = 1 ∨ i = 2 ∨ i = 3 ∨ i = 4 ∨ i = 5 := by rcases hm5 with h1 | h1 <;> omega
  have hrev : (M.φ ^ (m - i)) (M.α d) = d := by
    rw [← hi, ← Perm.mul_apply, ← pow_add, show m - i + i = m by omega]
    exact hdual d
  have hα : M.α (M.α d) = d := M.α_α d
  rcases hi1 with h1 | h1 | h1 | h1 | h1
  · rw [h1, pow_one] at hi
    exact (hfs d).1 hi
  · rw [h1, pow_two, Perm.mul_apply] at hi
    exact (hfs d).2.1 hi
  · rw [h1, pow_succ', pow_two, Perm.mul_apply, Perm.mul_apply] at hi
    exact (hfs d).2.2 hi
  · have hc : m - i = 1 ∨ m - i = 2 := by rcases hm5 with h2 | h2 <;> omega
    rcases hc with h2 | h2
    · rw [h2, pow_one] at hrev
      exact (hfs (M.α d)).1 (hrev.trans hα.symm)
    · rw [h2, pow_two, Perm.mul_apply] at hrev
      exact (hfs (M.α d)).2.1 (hrev.trans hα.symm)
  · have hc : m - i = 1 := by rcases hm5 with h2 | h2 <;> omega
    rw [hc, pow_one] at hrev
    exact (hfs (M.α d)).1 (hrev.trans hα.symm)

/-- The dual of a fullerene map has no loops. -/
theorem IsFullerene.dual_no_loop (h : M.IsFullerene) (d : D) :
    M.dual.tail d ≠ M.dual.tail (M.dual.α d) := fun he => h.no_fold d (Orb.mk_eq_iff.1 he)

/-! ### Digons -/

/-- The cycle of length two on two darts. -/
def mkDigon (f g : D) (h1 : M.tail (M.α f) = M.tail g) (h2 : M.tail (M.α g) = M.tail f)
    (ht : M.tail f ≠ M.tail g) (he : M.edge f ≠ M.edge g) : SimpleCycle M where
  len := 2
  len_pos := by norm_num
  dart i := if i % 2 = 0 then f else g
  periodic i := by simp only [Nat.add_mod_right]
  chain i := by
    rcases Nat.mod_two_eq_zero_or_one i with h | h
    · have h' : (i + 1) % 2 = 1 := by omega
      simp [h, h', h1]
    · have h' : (i + 1) % 2 = 0 := by omega
      simp [h, h', h2]
  tail_inj i j hi hj hij := by
    interval_cases i <;> interval_cases j <;> simp at hij ⊢
    · exact ht hij
    · exact ht hij.symm
  edge_inj i j hi hj hij := by
    interval_cases i <;> interval_cases j <;> simp at hij ⊢
    · exact he hij
    · exact he hij.symm

variable {C : SimpleCycle M} {Q : Finset M.F}

open SimpleCycle

private theorem dart_add_two (hlen : C.len = 2) (j : ℕ) : C.dart (j + 2) = C.dart j := by
  have := C.periodic j
  rwa [hlen] at this

private theorem dart_two_cases (hlen : C.len = 2) (j i : ℕ) :
    C.dart i = C.dart j ∨ C.dart i = C.dart (j + 1) := by
  have h : i % 2 = j % 2 ∨ i % 2 = (j + 1) % 2 := by omega
  rcases h with h | h
  · left
    rw [← C.dart_mod i, ← C.dart_mod j, hlen, h]
  · right
    rw [← C.dart_mod i, ← C.dart_mod (j + 1), hlen, h]

theorem digon_K_ne_one (hT : M.IsTriangulation) (hnl : ∀ d, M.tail d ≠ M.tail (M.α d))
    (hlen : C.len = 2) (j : ℕ) : C.K j ≠ 1 := by
  intro h1
  have hnext := C.next_eq (by omega : 2 ≤ C.len) j
  rw [h1, pow_one] at hnext
  have hφ : M.φ (C.dart j) = C.dart (j + 1) := hnext
  have tri := (hT (C.dart j)).1
  rw [hφ] at tri
  apply hnl (M.φ (C.dart (j + 1)))
  have h2 : M.tail (M.φ (C.dart (j + 1))) = M.tail (C.dart j) := by
    rw [M.tail_φ, C.chain, dart_add_two hlen]
  have h3 : M.tail (M.α (M.φ (C.dart (j + 1)))) = M.tail (C.dart j) := by
    rw [← M.tail_φ, tri]
  rw [h2, h3]

theorem digon_two (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (hnl : ∀ d, M.tail d ≠ M.tail (M.α d)) (hd5 : ∀ v, 5 ≤ M.deg v) (hlen : C.len = 2)
    (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q) (j : ℕ) (hK : C.K j = 2) :
    ∃ (C' : SimpleCycle M) (Q' : Finset M.F), C'.len = 2 ∧ IsSide C' Q' ∧ Q' ⊂ Q := by
  have h2 : 2 ≤ C.len := by omega
  have hnext := C.next_eq h2 j
  rw [hK, pow_two, Perm.mul_apply] at hnext
  set c := C.dart j with hcdef
  set c' := C.dart (j + 1) with hc'def
  set e := M.φ c with hedef
  have he : M.σ e = c' := hnext
  set f1 := M.φ e with hf1
  have hf1φ : M.φ f1 = c := (hT c).1
  set f2 := M.φ c' with hf2
  have hαe : M.φ (M.α e) = c' := by rw [φ_apply, M.α_α]; exact he
  have hf2φ : M.φ f2 = M.α e := by
    have := (hT (M.α e)).1
    rwa [hαe] at this
  have tf1 : M.tail f1 = M.tail (M.α e) := M.tail_φ e
  have af1 : M.tail (M.α f1) = M.tail c := by rw [← M.tail_φ, hf1φ]
  have tf2 : M.tail f2 = M.tail c := by rw [hf2, M.tail_φ, hc'def, C.chain, dart_add_two hlen]
  have af2 : M.tail (M.α f2) = M.tail (M.α e) := by rw [← M.tail_φ, hf2φ]
  have hzy : M.tail (M.α e) ≠ M.tail c := by
    intro h3
    exact hnl f1 (tf1.trans (h3.trans af1.symm))
  have hxz : M.tail (M.α e) ≠ M.tail c' := by
    intro h3
    have hte : M.tail e = M.tail c' := by rw [hedef, M.tail_φ, hcdef, C.chain]
    exact hnl e (hte.trans h3.symm)
  have hedge : M.edge f1 ≠ M.edge f2 := by
    intro hee
    rcases M.edge_eq_iff.1 hee with h3 | h3
    · have : M.tail (M.α e) = M.tail c := by rw [← tf1, ← tf2, h3]
      exact hzy this
    · have hαf : M.α f2 = f1 := by rw [h3, M.α_α]
      have hσf1 : M.σ f1 = M.α e := by
        rw [← hαf]
        exact hf2φ
      have hσ : (M.σ ^ 2) (M.α e) = M.α e := by
        rw [pow_two, Perm.mul_apply]
        show M.σ (M.φ e) = M.α e
        exact hσf1
      have := (pow_eq_self_iff_of_deg (M := M) (x := M.α e) rfl
        (by have := hd5 (M.tail (M.α e)); omega) 2).1 hσ
      have h5 := hd5 (M.tail (M.α e))
      have := Nat.le_of_dvd (by norm_num) this
      omega
  let C' : SimpleCycle M := mkDigon f1 f2 (af1.trans tf2.symm) (af2.trans tf1.symm)
    (by rw [tf1, tf2]; exact hzy) hedge
  have hC'edges : ∀ a ∈ C'.edges, a ∈ clE Q := by
    intro a ha
    obtain ⟨i, rfl⟩ := C'.exists_of_edge_mem ha
    have hfc : M.face f1 ∈ Q := by
      have : M.face f1 = M.face c := by rw [hf1, M.face_φ, hedef, M.face_φ]
      rw [this]
      exact hor j
    have hfc' : M.face f2 ∈ Q := by
      rw [hf2, M.face_φ]
      exact hor (j + 1)
    rw [mem_clE]
    refine ⟨C'.dart i, rfl, ?_⟩
    show M.face (if i % 2 = 0 then f1 else f2) ∈ Q
    split
    · exact hfc
    · exact hfc'
  obtain ⟨T', hT'sub, hT'⟩ := h.exists_side_subset hc hg C' hC'edges
  refine ⟨C', T', rfl, hT', Finset.ssubset_iff_subset_ne.2 ⟨hT'sub, ?_⟩⟩
  intro heq
  rw [heq] at hT'
  have hmem : M.edge f1 ∈ C'.edges := by
    have := C'.edge_mem 0
    simpa [C', mkDigon] using this
  have hC : M.edge f1 ∈ C.edges := by
    have h3 := (hT' f1).1 hmem
    exact (h f1).2 h3
  have hv := C.tail_mem_of_edge_mem hC
  obtain ⟨i, hi⟩ := C.exists_of_vert_mem hv
  rw [tf1] at hi
  rcases dart_two_cases hlen j i with h3 | h3
  · rw [h3] at hi
    exact hzy hi.symm
  · rw [h3] at hi
    exact hxz hi.symm

theorem digon_three (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (hnl : ∀ d, M.tail d ≠ M.tail (M.α d)) (hd5 : ∀ v, 5 ≤ M.deg v) (hlen : C.len = 2)
    (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q) (hK0 : C.K 0 = 3) (hK1 : C.K 1 = 3) :
    ∃ (C' : SimpleCycle M) (Q' : Finset M.F), C'.len = 2 ∧ IsSide C' Q' ∧ Q' ⊂ Q := by
  have h2 : 2 ≤ C.len := by omega
  have hn0 := C.next_eq h2 0
  have hn1 := C.next_eq h2 1
  rw [hK0, pow_succ', pow_two, Perm.mul_apply, Perm.mul_apply] at hn0
  rw [hK1, pow_succ', pow_two, Perm.mul_apply, Perm.mul_apply] at hn1
  have hd2 : C.dart (1 + 1) = C.dart 0 := dart_add_two hlen 0
  rw [hd2] at hn1
  set c0 := C.dart 0 with hc0
  set c1 := C.dart (0 + 1) with hc1
  set e1 := M.φ c0 with he1
  set e2 := M.σ e1 with he2
  have hne : M.σ e2 = c1 := hn0
  set g1 := M.φ c1 with hg1
  set g2 := M.σ g1 with hg2
  have hng : M.σ g2 = c0 := hn1
  have hg2φ : M.φ (M.α g2) = c0 := by rw [φ_apply, M.α_α]; exact hng
  have he2φ : M.φ (M.α e2) = c1 := by rw [φ_apply, M.α_α]; exact hne
  have hp : M.φ e1 = M.α g2 := by
    apply M.φ.injective
    rw [(hT c0).1, hg2φ]
  have hp' : M.φ g1 = M.α e2 := by
    apply M.φ.injective
    rw [(hT c1).1, he2φ]
  have hmid1 : M.φ (M.α e1) = e2 := by rw [φ_apply, M.α_α]
  have hmid2 : M.φ (M.α g1) = g2 := by rw [φ_apply, M.α_α]
  set r := M.φ e2 with hr
  have hrφ : M.φ r = M.α e1 := by
    have := (hT (M.α e1)).1
    rwa [hmid1] at this
  set w := M.φ g2 with hw
  have hwφ : M.φ w = M.α g1 := by
    have := (hT (M.α g1)).1
    rwa [hmid2] at this
  have tr : M.tail r = M.tail (M.α e2) := M.tail_φ e2
  have ar : M.tail (M.α r) = M.tail (M.α e1) := by rw [← M.tail_φ, hrφ]
  have tw : M.tail w = M.tail (M.α e1) := by
    rw [hw, M.tail_φ, ← hp, M.tail_φ]
  have aw : M.tail (M.α w) = M.tail (M.α e2) := by
    rw [← M.tail_φ, hwφ, ← M.tail_φ g1, hp']
  have hz : M.tail r ≠ M.tail w := by
    rw [tw, ← ar]
    exact hnl r
  have hedge : M.edge r ≠ M.edge w := by
    intro hee
    rcases M.edge_eq_iff.1 hee with h3 | h3
    · exact hz (by rw [h3])
    · have hσ1 : M.σ (M.α e1) = M.α g2 := by rw [← hp]; rfl
      have hσ2 : M.σ (M.α g2) = w := by rw [hw]; rfl
      have hσ3 : M.σ w = M.α e1 := by rw [h3]; exact hrφ
      have hσ : (M.σ ^ 3) (M.α e1) = M.α e1 := by
        rw [pow_succ', pow_two, Perm.mul_apply, Perm.mul_apply, hσ1, hσ2, hσ3]
      have hdvd := (pow_eq_self_iff_of_deg (M := M) (x := M.α e1) rfl
        (by have := hd5 (M.tail (M.α e1)); omega) 3).1 hσ
      have h5 := hd5 (M.tail (M.α e1))
      have := Nat.le_of_dvd (by norm_num) hdvd
      omega
  let C' : SimpleCycle M := mkDigon r w (ar.trans tw.symm) (aw.trans tr.symm) hz hedge
  have hfe2 : M.face e2 ∈ Q := by
    have := fan_side h (hor 0) 2 (by norm_num) (by omega)
    rw [pow_two, Perm.mul_apply] at this
    exact this
  have hfg2 : M.face g2 ∈ Q := by
    have := fan_side h (hor 1) 2 (by norm_num) (by omega)
    rw [pow_two, Perm.mul_apply] at this
    exact this
  have hC'edges : ∀ a ∈ C'.edges, a ∈ clE Q := by
    intro a ha
    obtain ⟨i, rfl⟩ := C'.exists_of_edge_mem ha
    rw [mem_clE]
    refine ⟨C'.dart i, rfl, ?_⟩
    show M.face (if i % 2 = 0 then r else w) ∈ Q
    split
    · rw [hr, M.face_φ]
      exact hfe2
    · rw [hw, M.face_φ]
      exact hfg2
  obtain ⟨T', hT'sub, hT'⟩ := h.exists_side_subset hc hg C' hC'edges
  refine ⟨C', T', rfl, hT', Finset.ssubset_iff_subset_ne.2 ⟨hT'sub, ?_⟩⟩
  intro heq
  rw [heq] at hT'
  have hmem : M.edge r ∈ C'.edges := by
    have := C'.edge_mem 0
    simpa [C', mkDigon] using this
  have hCe : M.edge r ∈ C.edges := (h r).2 ((hT' r).1 hmem)
  have hv := C.tail_mem_of_edge_mem hCe
  obtain ⟨i, hi⟩ := C.exists_of_vert_mem hv
  rw [tr] at hi
  rcases dart_two_cases hlen 0 i with h3 | h3
  · rw [h3, ← hc0] at hi
    have htg1 : M.tail g1 = M.tail c0 := by
      rw [hg1, M.tail_φ, hc1, C.chain]
      show M.tail (C.dart (0 + 1 + 1)) = _
      rw [show (0 + 1 + 1) = 0 + 2 from rfl, dart_add_two hlen]
    have hag1 : M.tail (M.α g1) = M.tail (M.α e2) := by rw [← M.tail_φ, hp']
    exact hnl g1 (htg1.trans (hi.trans hag1.symm))
  · rw [h3, ← hc1] at hi
    have hte2 : M.tail e2 = M.tail c1 := by
      rw [he2, M.tail_σ, he1, M.tail_φ, hc0, C.chain]
    exact hnl e2 (hte2.trans hi)

theorem exists_oriented (hlen : 2 ≤ C.len) {S : Finset M.F} (h : IsSide C S) :
    ∃ C0 : SimpleCycle M, C0.len = C.len ∧ C0.edges = C.edges ∧ ∀ j, M.face (C0.dart j) ∈ S := by
  by_cases h0 : M.face (C.dart 0) ∈ S
  · exact ⟨C, rfl, rfl, SimpleCycle.orient hlen h h0⟩
  · have hor : ∀ j, M.face (C.dart j) ∈ Sᶜ :=
      SimpleCycle.orient hlen h.compl (by simpa using h0)
    refine ⟨C.rev, rfl, C.rev_edges, fun j => ?_⟩
    have := SimpleCycle.rev_orient C h.compl hor j
    simpa using this

/-- Sum of the two first-return exponents of a digon equals the curvature of the side. -/
theorem digon_sum (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hlen : C.len = 2)
    {S : Finset M.F} (h : IsSide C S) (hor : ∀ j, M.face (C.dart j) ∈ S) :
    ((C.K 0 + C.K 1 : ℕ) : ℤ) = C.curv S := by
  have h1 := h.boundary_corners hT hc hg
  have h2 := SimpleCycle.sum_K (by omega) h hor
  have h3 : ∑ j ∈ range C.len, C.K j = C.K 0 + C.K 1 := by
    rw [hlen]; simp [Finset.sum_range_succ]
  rw [← h2, h3, hlen] at h1
  push_cast at h1 ⊢
  linarith

/-- Every side of a digon has curvature at least six. -/
theorem digon_curv_ge (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (hnl : ∀ d, M.tail d ≠ M.tail (M.α d)) (hd5 : ∀ v, 5 ≤ M.deg v) (hd6 : ∀ v, M.deg v ≤ 6) :
    ∀ (n : ℕ) (C : SimpleCycle M) (S : Finset M.F), S.card = n → C.len = 2 → IsSide C S →
      6 ≤ C.curv S := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
    intro C S hn hlen hS
    obtain ⟨C0, h0len, h0e, hor⟩ := exists_oriented (by omega) hS
    have hS0 : IsSide C0 S := isSide_of_edges_eq h0e hS
    have h0len2 : C0.len = 2 := by omega
    rw [← curv_of_edges_eq h0e S]
    have hsum := digon_sum hT hc hg h0len2 hS0 hor
    have hK2 : ∀ j, 2 ≤ C0.K j := fun j => by
      have h1 := C0.K_pos j
      have h2 := digon_K_ne_one hT hnl h0len2 j
      omega
    have hIH : ∀ j, C0.K j = 2 → 6 ≤ C0.curv S := fun j hj => by
      obtain ⟨C', Q', hl', hs', hsub⟩ := digon_two hT hc hg hnl hd5 h0len2 hS0 hor j hj
      have h1 := ih Q'.card (by rw [← hn]; exact Finset.card_lt_card hsub) C' Q' rfl hl' hs'
      have h2 := curv_mono hd6 (intV_sub_of_subset hS0 hs' hsub.1)
      exact le_trans h1 h2
    by_cases hK0 : C0.K 0 = 2
    · exact hIH 0 hK0
    · by_cases hK1 : C0.K 1 = 2
      · exact hIH 1 hK1
      · have h0 := hK2 0
        have h1 := hK2 1
        have h3 : 3 ≤ C0.K 0 := by omega
        have h4 : 3 ≤ C0.K 1 := by omega
        have h5 : ((C0.K 0 + C0.K 1 : ℕ) : ℤ) ≥ 6 := by exact_mod_cast (by omega : 6 ≤ C0.K 0 + C0.K 1)
        linarith

/-- A triangulated sphere with degrees 5 and 6 and no loops has no digon. -/
theorem no_digon (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (hnl : ∀ d, M.tail d ≠ M.tail (M.α d)) (hd5 : ∀ v, 5 ≤ M.deg v) (hd6 : ∀ v, M.deg v ≤ 6)
    (C : SimpleCycle M) (hlen : C.len = 2) : False := by
  have hex : ∃ n, ∃ (C : SimpleCycle M) (S : Finset M.F), C.len = 2 ∧ IsSide C S ∧ S.card = n := by
    obtain ⟨S, hS⟩ := exists_isSide C hc hg
    exact ⟨S.card, C, S, hlen, hS, rfl⟩
  obtain ⟨C1, S1, hl1, hS1, hn1⟩ := Nat.find_spec hex
  have hmin : ∀ (C' : SimpleCycle M) (S' : Finset M.F), C'.len = 2 → IsSide C' S' →
      S1.card ≤ S'.card := fun C' S' hl hs => by
    rw [hn1]
    exact Nat.find_min' hex ⟨C', S', hl, hs, rfl⟩
  obtain ⟨C0, h0len, h0e, hor⟩ := exists_oriented (by omega) hS1
  have hS0 : IsSide C0 S1 := isSide_of_edges_eq h0e hS1
  have h0len2 : C0.len = 2 := by omega
  have hsplit := hS0.curv_split hT hg
  have hge1 := digon_curv_ge hT hc hg hnl hd5 hd6 _ C0 S1 rfl h0len2 hS0
  have hge2 := digon_curv_ge hT hc hg hnl hd5 hd6 _ C0 S1ᶜ rfl h0len2 hS0.compl
  have hnn : 0 ≤ ∑ v ∈ C0.verts, (6 - (M.deg v : ℤ)) := by
    apply Finset.sum_nonneg
    intro v _
    have := hd6 v
    have h6 : (M.deg v : ℤ) ≤ 6 := by exact_mod_cast this
    linarith
  have hcurv : C0.curv S1 = 6 := by linarith
  have hsum := digon_sum hT hc hg h0len2 hS0 hor
  rw [hcurv] at hsum
  have hsum' : C0.K 0 + C0.K 1 = 6 := by exact_mod_cast hsum
  have hK2 : ∀ j, 2 ≤ C0.K j := fun j => by
    have h1 := C0.K_pos j
    have h2 := digon_K_ne_one hT hnl h0len2 j
    omega
  have hdesc : ∀ (C' : SimpleCycle M) (Q' : Finset M.F), C'.len = 2 → IsSide C' Q' → Q' ⊂ S1 →
      False := fun C' Q' hl' hs' hsub => by
    have h1 := hmin C' Q' hl' hs'
    have h2 := Finset.card_lt_card hsub
    omega
  by_cases hK0 : C0.K 0 = 2
  · obtain ⟨C', Q', hl', hs', hsub⟩ := digon_two hT hc hg hnl hd5 h0len2 hS0 hor 0 hK0
    exact hdesc C' Q' hl' hs' hsub
  · by_cases hK1 : C0.K 1 = 2
    · obtain ⟨C', Q', hl', hs', hsub⟩ := digon_two hT hc hg hnl hd5 h0len2 hS0 hor 1 hK1
      exact hdesc C' Q' hl' hs' hsub
    · have h0 := hK2 0
      have h1 := hK2 1
      obtain ⟨C', Q', hl', hs', hsub⟩ :=
        digon_three hT hc hg hnl hd5 h0len2 hS0 hor (by omega) (by omega)
      exact hdesc C' Q' hl' hs' hsub

/-- **Digon descent.** The dual of a fullerene map is simple: this removes the hypothesis
`IsSimple` from the sealed theorems about duals of fullerenes. -/
theorem IsFullerene.dual_simple (h : M.IsFullerene) : M.dual.IsSimple := by
  have hT := h.dual_tri
  have hc := h.dual_connected
  have hg := h.dual_genus
  have hd5 : ∀ v, 5 ≤ M.dual.deg v := fun v => by
    rcases h.dual_deg v with h1 | h1 <;> omega
  have hd6 := h.dual_deg_le
  have hnl := h.dual_no_loop
  refine ⟨hnl, fun d d' h1 h2 => ?_⟩
  by_contra hne
  have hd'α : d' ≠ M.dual.α d := by
    intro h3
    apply hnl d
    rw [h1, h3]
  have hedge : M.dual.edge d ≠ M.dual.edge (M.dual.α d') := by
    intro hee
    rw [M.dual.edge_α] at hee
    rcases M.dual.edge_eq_iff.1 hee with h3 | h3
    · exact hne h3.symm
    · exact hd'α h3
  have ht : M.dual.tail d ≠ M.dual.tail (M.dual.α d') := by
    rw [← h2]
    exact hnl d
  let C : SimpleCycle M.dual := mkDigon d (M.dual.α d') h2 (by
    rw [M.dual.α_α]; exact h1.symm) ht hedge
  exact no_digon hT hc hg hnl hd5 hd6 C rfl

end CMap

end Ful

end
