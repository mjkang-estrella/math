/-
FulHelixC: the local laws of the helical rotation table at the middle vertices.
-/
import FulHelixB

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace Ful.Helix

variable {s m u : ℤ} {k : ℕ}

set_option maxHeartbeats 2000000 in
theorem law_mid (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : 0 < u) (h2 : u < m)
    (hk : k < len s m u) : Law s m u k := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hc : u = 1 ∨ (2 ≤ u ∧ u ≤ s - 2) ∨ u = s - 1 ∨ u = s ∨ u = s + 1 ∨ u = s + 2 ∨ (s + 3 ≤ u ∧ u ≤ 2 * s) ∨
      u = 2 * s + 1 ∨ u = 2 * s + 2 ∨ u = 2 * s + 3 ∨ u = 2 * s + 4 ∨ u = 2 * s + 5 ∨
      (2 * s + 5 < u ∧ u < m - (2 * s + 5)) ∨ u = m - (2 * s + 5) ∨
      (m - u = 2 * s + 4) ∨ (m - u = 2 * s + 3) ∨ (m - u = 2 * s + 2) ∨ (m - u = 2 * s + 1) ∨
      (s + 3 ≤ m - u ∧ m - u ≤ 2 * s) ∨ (m - u = s + 2) ∨ (m - u = s + 1) ∨ (m - u = s) ∨
      (m - u = s - 1) ∨ (2 ≤ m - u ∧ m - u ≤ s - 2) ∨ m - u = 1 := by omega
  unfold Law
  rcases hc with hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc |
    hc | hc | hc | hc | hc | hc | hc <;> (simp (disch := omega) only [nz, iz, len, Nb_int, Nb_zero, Nb_mid, Nb_m, Nb_intB, low_gen,
      low_cf, up_gen, up_cf, intA, ifT, ifF, cf_a, cf_b, cf_c, cf_d, cf_e, cf_f,
      List.length_cons, List.length_nil, List.length_append, List.cons_append, List.nil_append,
      List.map_cons, List.map_nil, Nat.reduceAdd, Nat.zero_add, Nat.add_zero, List.length_map] at hk) <;> interval_cases k <;> reduce_u <;> omega

end Ful.Helix
