/-
FulHelixN: `F(n) → ∞`: the number of fullerene isomorphism classes on `n` vertices is unbounded
along even `n`; fullerenes on `n` vertices exist only for even `n`; the limit filter is proper.
-/
import FulHelixG
import Mathlib.Order.Filter.AtTopBot.Basic

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

noncomputable section

namespace Ful.Helix

open Stmt Filter
open scoped Classical

/-- The circumference parameters. -/
def Ps (j : ℕ) : ℕ := 30 ^ (j + 1)

theorem Ps_ge (j : ℕ) : 30 ≤ Ps j := by
  unfold Ps
  calc 30 = 30 ^ 1 := by norm_num
    _ ≤ 30 ^ (j + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)

theorem Ps_mono {j k : ℕ} (h : j < k) : 30 * Ps j ≤ Ps k := by
  unfold Ps
  calc 30 * 30 ^ (j + 1) = 30 ^ (j + 2) := by ring
    _ ≤ 30 ^ (k + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)

theorem Ps_le {j M : ℕ} (h : j < M) : Ps j ≤ Ps M := by
  have := Ps_mono h
  have := Ps_ge j
  omega

/-- There are at least `M` fullerene classes on every large even `n`. -/
theorem numFullerenes_ge (M : ℕ) : ∃ N, ∀ n, N ≤ n → Even n → M ≤ numFullerenes n := by
  set a := 2 * Ps M + 5 with ha
  refine ⟨400 * (a * a), fun n hn he => ?_⟩
  have ha5 : 65 ≤ a := by have := Ps_ge M; omega
  obtain ⟨n0, rfl⟩ := he
  -- data for one parameter
  have data : ∀ j : Fin M, ∃ (hs : 4 ≤ Ps j.1)
      (hm : 3 * (2 * Ps j.1 + 5) ≤ (n0 + n0 + 2 - 4 * Ps j.1) / 2),
      Fintype.card (helix hs hm).T.dual.V = n0 + n0 := by
    intro j
    have hle := Ps_le j.2
    have hs : 4 ≤ Ps j.1 := by have := Ps_ge j.1; omega
    have hP : 2 * Ps j.1 ≤ a := by omega
    have haa : a ≤ a * a := Nat.le_mul_self a
    have hlarge : 3 * (2 * Ps j.1 + 5) ≤ (n0 + n0 + 2 - 4 * Ps j.1) / 2 := by
      have h3 : 4 * Ps j.1 ≤ 2 * a := by omega
      have h4 : 400 * a ≤ n0 + n0 := le_trans (Nat.mul_le_mul_left 400 haa) hn
      omega
    refine ⟨hs, hlarge, ?_⟩
    rw [helix_card hs hlarge]
    have h5 : 400 * a ≤ n0 + n0 := le_trans (Nat.mul_le_mul_left 400 haa) hn
    have h6 : 4 * Ps j.1 ≤ 2 * a := by omega
    omega
  choose hs hm hc using data
  let f : Fin M → FullereneClass (n0 + n0) := fun j =>
    Quotient.mk _ ⟨helixG (hs j) (hm j) (hc j), helixG_isFullerene (hs j) (hm j) (hc j)⟩
  have hinj : Function.Injective f := by
    intro a0 b0 hab
    by_contra hne
    have hne' : a0.1 ≠ b0.1 := fun h => hne (Fin.ext h)
    have key : ∀ (i j : Fin M), i.1 < j.1 →
        IsEmpty ((helixG (hs i) (hm i) (hc i)) ≃g (helixG (hs j) (hm j) (hc j))) := by
      intro i j hij
      have h30 := Ps_mono hij
      have hi30 := Ps_ge i.1
      have hle1 := Ps_le i.2
      have hle2 := Ps_le j.2
      have hP1 : 2 * Ps i.1 + 5 ≤ a := by omega
      have hP2 : 2 * Ps j.1 + 5 ≤ a := by omega
      have hP3 : Ps j.1 ≤ a := by omega
      refine helixG_not_iso (hs i) (hm i) (hc i) (hs j) (hm j) (hc j) ?_ ?_ ?_
      · omega
      · have hmono : n0 + n0 + 2 - 4 * Ps j.1 ≤ n0 + n0 + 2 - 4 * Ps i.1 := by omega
        exact Nat.div_le_div_right hmono
      · have haa : a ≤ a * a := Nat.le_mul_self a
        have h1 : 24 * (2 * Ps i.1 + 5) * ((2 * Ps j.1 + 5) + Ps j.1) ≤ 24 * a * (a + a) :=
          Nat.mul_le_mul (Nat.mul_le_mul_left 24 hP1) (by omega)
        have h2 : 24 * a * (a + a) = 48 * (a * a) := by ring
        have h3 : 14 * (2 * Ps i.1 + 5) ≤ 14 * (a * a) := by
          have : 2 * Ps i.1 + 5 ≤ a * a := hP1.trans haa
          omega
        have h4 : 4 * Ps i.1 ≤ 2 * a := by omega
        have h5 : 2 * a ≤ 2 * (a * a) := by omega
        have h6 : 2 * ((n0 + n0 + 2 - 4 * Ps i.1) / 2) = n0 + n0 + 2 - 4 * Ps i.1 := by
          have : (n0 + n0 + 2 - 4 * Ps i.1) % 2 = 0 := by omega
          omega
        omega
    have hiso : Nonempty ((helixG (hs a0) (hm a0) (hc a0)) ≃g (helixG (hs b0) (hm b0) (hc b0))) :=
      Quotient.exact hab
    rcases lt_or_gt_of_ne hne' with h | h
    · exact (key a0 b0 h).elim hiso.some
    · exact (key b0 a0 h).elim hiso.some.symm
  have hcard := Fintype.card_le_of_injective f hinj
  simpa [numFullerenes] using hcard

/-- Orders of fullerenes are even. -/
theorem even_of_order {n : ℕ} (h : Nonempty (FullereneClass n)) : Even n := by
  obtain ⟨c⟩ := h
  obtain ⟨⟨G, hG⟩, -⟩ := Quotient.exists_rep c
  have hdeg : ∀ v, G.degree v = 3 := by
    intro v
    have := hG.cubic v
    rw [Nat.card_eq_fintype_card, ← SimpleGraph.card_neighborFinset_eq_degree, ← Set.toFinset_card] at *
    convert this using 2
    ext w
    simp
  have hsum := G.sum_degrees_eq_twice_card_edges
  simp only [hdeg, Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul] at hsum
  rcases Nat.even_or_odd n with h | h
  · exact h
  · exfalso
    rcases h with ⟨k, hk⟩
    omega

/-- The limit filter is proper. -/
theorem nonVacuous : NonVacuous := by
  unfold NonVacuous fullereneLimit
  obtain ⟨N, hN⟩ := numFullerenes_ge 1
  rw [Filter.inf_principal_neBot_iff]
  intro U hU
  obtain ⟨k, hk⟩ := Filter.mem_atTop_sets.1 hU
  have hn : N + k ≤ 2 * (N + k) := by omega
  refine ⟨2 * (N + k), hk _ (by omega), ?_⟩
  have h1 := hN (2 * (N + k)) (by omega) (even_two_mul _)
  have hpos : 0 < numFullerenes (2 * (N + k)) := by omega
  exact Fintype.card_pos_iff.1 hpos

end Ful.Helix

end
