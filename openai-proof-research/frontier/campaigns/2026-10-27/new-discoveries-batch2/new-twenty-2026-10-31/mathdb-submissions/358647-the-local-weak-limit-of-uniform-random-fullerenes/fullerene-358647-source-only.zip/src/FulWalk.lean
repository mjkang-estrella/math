/-
FulWalk: extraction of simple cycles from even edge sets, and bond-cycle duality:
a set of faces that is strongly connected and has a strongly connected complement is a side of
a simple cycle.
-/
import FulDisc
import Mathlib.Data.Fintype.Pigeonhole

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- In an even edge set, one can leave the head of a dart along a different edge of the set. -/
theorem exists_next (z : M.E → F2) (hz : M.d1.mulVec z = 0) (d : D)
    (hd : z (M.edge d) = 1) :
    ∃ y, z (M.edge y) = 1 ∧ M.tail y = M.tail (M.α d) ∧ y ≠ M.α d := by
  by_contra hcon
  push Not at hcon
  have h1 := congrFun hz (M.tail (M.α d))
  rw [d1_mulVec, Finset.sum_eq_single (M.α d)] at h1
  · rw [M.edge_α, hd] at h1
    exact one_ne_zero h1
  · intro y hy hne
    rcases F2.eq_zero_or_one (z (M.edge y)) with h0 | h0
    · exact h0
    · exact absurd (hcon y h0 (mem_filter.1 hy).2) hne
  · intro hn
    exact (hn (mem_filter.2 ⟨mem_univ _, rfl⟩)).elim

/-- Every nonzero even edge set contains the edges of a simple cycle. -/
theorem exists_simpleCycle_of_even (z : M.E → F2) (hz : M.d1.mulVec z = 0) (d0 : D)
    (h0 : z (M.edge d0) = 1) : ∃ Γ : SimpleCycle M, ∀ i, z (M.edge (Γ.dart i)) = 1 := by
  let Zd := {d : D // z (M.edge d) = 1}
  have hex : ∀ d : Zd, ∃ y : Zd, M.tail y.1 = M.tail (M.α d.1) ∧ y.1 ≠ M.α d.1 := by
    intro d
    obtain ⟨y, h1, h2, h3⟩ := exists_next z hz d.1 d.2
    exact ⟨⟨y, h1⟩, h2, h3⟩
  choose nxt hnxt1 hnxt2 using hex
  let w : ℕ → Zd := fun n => nxt^[n] ⟨d0, h0⟩
  have hw : ∀ n, w (n + 1) = nxt (w n) := fun n => by
    simp only [w, Function.iterate_succ_apply']
  have hstep : ∀ n, M.tail (w (n + 1)).1 = M.tail (M.α (w n).1) := fun n => by
    rw [hw]; exact hnxt1 _
  have hne : ∀ n, (w (n + 1)).1 ≠ M.α (w n).1 := fun n => by
    rw [hw]; exact hnxt2 _
  obtain ⟨x, y, hxy, hf⟩ := Finite.exists_ne_map_eq_of_infinite (fun n => M.tail (w n).1)
  have hexP : ∃ j, ∃ i, i < j ∧ M.tail (w i).1 = M.tail (w j).1 := by
    rcases lt_or_gt_of_ne hxy with h | h
    · exact ⟨y, x, h, hf⟩
    · exact ⟨x, y, h, hf.symm⟩
  let j := Nat.find hexP
  obtain ⟨i, hij, heq⟩ : ∃ i, i < j ∧ M.tail (w i).1 = M.tail (w j).1 := Nat.find_spec hexP
  have hmin : ∀ m, m < j → ¬ ∃ i, i < m ∧ M.tail (w i).1 = M.tail (w m).1 :=
    fun m hm => Nat.find_min hexP hm
  have hL : 0 < j - i := by omega
  have hdist : ∀ a b, i + a < j → i + b < j →
      M.tail (w (i + a)).1 = M.tail (w (i + b)).1 → a = b := by
    intro a b ha hb hab
    rcases lt_trichotomy a b with h | h | h
    · exact absurd ⟨i + a, by omega, hab⟩ (hmin (i + b) hb)
    · exact h
    · exact absurd ⟨i + b, by omega, hab.symm⟩ (hmin (i + a) ha)
  have hmod : ∀ n, i + n % (j - i) < j := fun n => by
    have := Nat.mod_lt n hL
    omega
  have hedge_lt : ∀ a b, a < b → i + b < j →
      M.edge (w (i + a)).1 ≠ M.edge (w (i + b)).1 := by
    intro a b hab hb he
    rcases M.edge_eq_iff.1 he with h1 | h1
    · have : a = b := hdist a b (by omega) hb (by rw [h1])
      omega
    · have h2 : M.tail (w (i + b)).1 = M.tail (w (i + a + 1)).1 := by
        rw [h1, hstep]
      rcases Nat.lt_or_ge (a + 1) b with h3 | h3
      · have : a + 1 = b := hdist (a + 1) b (by omega) hb (by
          rw [show i + (a + 1) = i + a + 1 by omega]; exact h2.symm)
        omega
      · have h4 : b = a + 1 := by omega
        subst h4
        exact hne (i + a) (by rw [show i + a + 1 = i + (a + 1) by omega]; exact h1)
  refine ⟨{ len := j - i
            len_pos := hL
            dart := fun n => (w (i + n % (j - i))).1
            periodic := fun n => by simp only [Nat.add_mod_right]
            chain := ?_
            tail_inj := ?_
            edge_inj := ?_ }, fun n => (w _).2⟩
  · intro n
    have hm := Nat.mod_lt n hL
    have h1 : (n + 1) % (j - i) = (n % (j - i) + 1) % (j - i) := by
      rw [Nat.mod_add_mod]
    rcases Nat.lt_or_ge (n % (j - i) + 1) (j - i) with h | h
    · rw [h1, Nat.mod_eq_of_lt h, ← add_assoc, hstep]
    · have h2 : n % (j - i) + 1 = j - i := by omega
      rw [h1, h2, Nat.mod_self, add_zero, heq, ← hstep (i + n % (j - i))]
      rw [show i + n % (j - i) + 1 = j by omega]
  · intro a b ha hb hab
    simp only [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at hab
    exact hdist a b (by omega) (by omega) hab
  · intro a b ha hb hab
    simp only [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at hab
    rcases lt_trichotomy a b with h | h | h
    · exact absurd hab (hedge_lt a b h (by omega))
    · exact h
    · exact absurd hab.symm (hedge_lt b a h (by omega))

/-- `X` is strongly connected: a function constant across interior edges is constant on `X`. -/
def StrongConn (X : Finset M.F) : Prop :=
  ∀ x : M.F → F2, (∀ d, M.face d ∈ X → M.face (M.α d) ∈ X → x (M.face d) = x (M.face (M.α d))) →
    ∀ f ∈ X, ∀ f' ∈ X, x f = x f'

/-- **Bond-cycle duality.** A set of faces which is strongly connected, with strongly connected
nonempty complement, is a side of a simple cycle. -/
theorem exists_cycle_of_strong (hc : M.Connected) (hg : M.Genus0) {X : Finset M.F}
    (hne : X.Nonempty) (hne' : Xᶜ.Nonempty) (hX : StrongConn X) (hX' : StrongConn Xᶜ) :
    ∃ Γ : SimpleCycle M, IsSide Γ X := by
  obtain ⟨fa, hfa⟩ := hne
  obtain ⟨fb, hfb⟩ := hne'
  have hfb' : fb ∉ X := mem_compl.1 hfb
  set z0 : M.E → F2 := M.d2.mulVec (indF X) with hz0
  have hz0e : ∀ d, z0 (M.edge d) = indF X (M.face d) + indF X (M.face (M.α d)) :=
    fun d => M.d2_mulVec_edge _ d
  -- minimality
  have hmin : ∀ z : M.E → F2, (∀ e, z0 e = 0 → z e = 0) → M.d1.mulVec z = 0 → z = 0 ∨ z = z0 := by
    intro z hz hcz
    obtain ⟨w, hw⟩ := hc.exists_d2_eq hg z hcz
    have hze : ∀ d, z (M.edge d) = w (M.face d) + w (M.face (M.α d)) := fun d => by
      rw [← hw]; exact M.d2_mulVec_edge _ d
    have hin : ∀ f ∈ X, w f = w fa := by
      intro f hf
      refine hX w (fun d h1 h2 => ?_) f hf fa hfa
      have h3 : z0 (M.edge d) = 0 := by
        rw [hz0e]; simp only [indF, h1, h2, ite_true]; exact F2.add_self _
      have h4 := hz _ h3
      rw [hze] at h4
      exact F2.eq_of_add_eq_zero h4
    have hout : ∀ f, f ∉ X → w f = w fb := by
      intro f hf
      refine hX' w (fun d h1 h2 => ?_) f (mem_compl.2 hf) fb hfb
      have h1' := mem_compl.1 h1
      have h2' := mem_compl.1 h2
      have h3 : z0 (M.edge d) = 0 := by
        rw [hz0e]; simp only [indF, h1', h2', ite_false, add_zero]
      have h4 := hz _ h3
      rw [hze] at h4
      exact F2.eq_of_add_eq_zero h4
    have hform : ∀ d, z (M.edge d) = (w fa + w fb) * z0 (M.edge d) := by
      intro d
      rw [hze, hz0e]
      by_cases h1 : M.face d ∈ X <;> by_cases h2 : M.face (M.α d) ∈ X
      · simp only [hin _ h1, hin _ h2, indF, h1, h2, ite_true, F2.add_self, mul_zero]
      · simp only [hin _ h1, hout _ h2, indF, h1, h2, ite_true, ite_false, add_zero, mul_one]
      · simp only [hout _ h1, hin _ h2, indF, h1, h2, ite_true, ite_false, zero_add, mul_one,
          add_comm]
      · simp only [hout _ h1, hout _ h2, indF, h1, h2, ite_false, add_zero, mul_zero, F2.add_self]
    rcases F2.eq_zero_or_one (w fa + w fb) with h0 | h0
    · left
      funext e
      obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
      show z (M.edge d) = 0
      rw [hform, h0, zero_mul]
    · right
      funext e
      obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
      show z (M.edge d) = z0 (M.edge d)
      rw [hform, h0, one_mul]
  -- a dart on the boundary
  have hdart : ∃ d0, z0 (M.edge d0) = 1 := by
    by_contra hcon
    push Not at hcon
    have hzero : z0 = 0 := by
      funext e
      obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
      rcases F2.eq_zero_or_one (z0 (M.edge d)) with h | h
      · exact h
      · exact absurd h (hcon d)
    rcases hc.ker_d2 hzero with h1 | h1
    · have := congrFun h1 fa
      simp only [indF, hfa, ite_true, Pi.zero_apply] at this
      exact one_ne_zero this
    · have := congrFun h1 fb
      simp only [indF, hfb', ite_false, Pi.one_apply] at this
      exact zero_ne_one this
  obtain ⟨d0, hd0⟩ := hdart
  obtain ⟨Γ, hΓ⟩ := exists_simpleCycle_of_even z0 (M.d1_d2 _) d0 hd0
  refine ⟨Γ, isSide_of_d2 Γ ?_⟩
  have hsupp : ∀ e, z0 e = 0 → Γ.ind e = 0 := by
    intro e he
    unfold SimpleCycle.ind
    by_cases hm : e ∈ Γ.edges
    · obtain ⟨i, rfl⟩ := Γ.exists_of_edge_mem hm
      rw [hΓ i] at he
      exact absurd he one_ne_zero
    · rw [ite_eq_right hm]
  rcases hmin Γ.ind hsupp Γ.d1_ind with h1 | h1
  · exfalso
    have := congrFun h1 (M.edge (Γ.dart 0))
    simp only [SimpleCycle.ind, Γ.edge_mem 0, ite_true, Pi.zero_apply] at this
    exact one_ne_zero this
  · exact h1.symm

end CMap

end Ful

end
