/-
FulDev: development of the triangular lattice into a triangulation near a flat vertex.  The
lattice is `ℤ × ℤ` with unit vectors `(1,0),(0,1),(-1,1),(-1,0),(0,-1),(1,-1)`.  The development
is defined by two total permutations (straight step, and straight step in the next direction), so
no region is needed to define it; flatness is used only to prove the lattice relations.
-/
import FulChain

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable (M : CMap D)

/-- Straight step along a dart at a degree-six vertex. -/
def stp : Perm D := M.σ * M.σ * M.σ * M.α

/-- Straight step in the next direction, keeping the direction label. -/
def st1 : Perm D := M.σ⁻¹ * M.stp * M.σ

/-- A dart at a vertex of order six under the rotation. -/
def Fl (x : D) : Prop := M.σ (M.σ (M.σ (M.σ (M.σ (M.σ x))))) = x

/-- Walks of length at most `n` from a root vertex. -/
inductive Reach (v0 : M.V) : ℕ → M.V → Prop
  | zero : Reach v0 0 v0
  | stay {n : ℕ} {v : M.V} : Reach v0 n v → Reach v0 (n + 1) v
  | step {n : ℕ} {v : M.V} (d : D) : M.tail d = v → Reach v0 n v →
      Reach v0 (n + 1) (M.tail (M.α d))

variable {M}

theorem stp_apply (x : D) : M.stp x = M.σ (M.σ (M.σ (M.α x))) := rfl
theorem st1_apply (x : D) : M.st1 x = M.σ⁻¹ (M.stp (M.σ x)) := rfl
theorem σ_inv_σ (x : D) : M.σ⁻¹ (M.σ x) = x := M.σ.symm_apply_apply x
theorem σ_σ_inv (x : D) : M.σ (M.σ⁻¹ x) = x := M.σ.apply_symm_apply x
theorem tail_inv (x : D) : M.tail (M.σ⁻¹ x) = M.tail x := by
  rw [← M.tail_σ (M.σ⁻¹ x), σ_σ_inv]

theorem Fl_of_deg {x : D} (h : M.deg (M.tail x) = 6) : M.Fl x := by
  have h6 := (pow_eq_self_iff_of_deg h (by norm_num) 6).2 (dvd_refl 6)
  have e : (M.σ ^ 6) x = M.σ (M.σ (M.σ (M.σ (M.σ (M.σ x))))) := by
    simp only [pow_succ', pow_zero, mul_one, Perm.mul_apply]
  rw [e] at h6
  exact h6

theorem inv5 {y : D} (h : M.Fl y) : M.σ (M.σ (M.σ (M.σ (M.σ y)))) = M.σ⁻¹ y := by
  rw [← h, σ_inv_σ]
  rw [h]

theorem star (hT : M.IsTriangulation) (d : D) :
    M.σ (M.α (M.σ (M.α (M.σ d)))) = M.α d := by
  have h := (hT (M.α d)).1
  simpa only [φ_apply, M.α_α] using h

theorem star' (hT : M.IsTriangulation) (d : D) :
    M.σ (M.α (M.σ d)) = M.α (M.σ⁻¹ (M.α d)) := by
  have h := star hT d
  have h2 : M.α (M.σ (M.α (M.σ d))) = M.σ⁻¹ (M.α d) := by
    conv_rhs => rw [← h]
    rw [σ_inv_σ]
  have h3 := congrArg M.α h2
  rwa [M.α_α] at h3

/-- Flat identity along a triangle: direction `u+1` equals direction `u` then `u+2`. -/
theorem fF (hT : M.IsTriangulation) {d : D} (hf : M.Fl (M.α d)) :
    M.stp (M.σ d) = M.σ⁻¹ (M.stp (M.σ (M.σ (M.stp d)))) := by
  simp only [stp_apply, σ_inv_σ]
  rw [inv5 hf, ← star' hT d]

theorem fF2 (hT : M.IsTriangulation) (x : D) :
    M.stp x = M.σ (M.stp (M.σ⁻¹ (M.σ⁻¹ (M.stp (M.σ x))))) := by
  simp only [stp_apply, σ_inv_σ]
  rw [star hT x]

/-- **Rhombus identity.** The two straight steps commute around a flat vertex. -/
theorem rhombus (hT : M.IsTriangulation) {d : D} (hf : M.Fl (M.α d)) :
    M.stp (M.st1 d) = M.st1 (M.stp d) := by
  rw [st1_apply, st1_apply, fF hT hf, fF2 hT (M.σ (M.stp d)), σ_inv_σ]

/-- Forward then turning around and forward is the identity up to rotation. -/
theorem stp_rev {h : D} (hf : M.Fl (M.α h)) :
    M.stp (M.σ (M.σ (M.σ (M.stp h)))) = M.σ (M.σ (M.σ h)) := by
  simp only [stp_apply]
  have e : M.σ (M.σ (M.σ (M.σ (M.σ (M.σ (M.α h)))))) = M.α h := hf
  rw [e, M.α_α]

/-! ### Reach -/

variable {v0 : M.V}

theorem Reach.mono {n m : ℕ} {v : M.V} (h : M.Reach v0 n v) (hnm : n ≤ m) : M.Reach v0 m v := by
  induction m, hnm using Nat.le_induction with
  | base => exact h
  | succ m _ ih => exact Reach.stay ih

theorem Reach.head {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) :
    M.Reach v0 (n + 1) (M.tail (M.α d)) := Reach.step d rfl h

theorem tail_stp (x : D) : M.tail (M.stp x) = M.tail (M.α x) := by
  simp only [stp_apply, M.tail_σ]

theorem tail_st1 (x : D) : M.tail (M.st1 x) = M.tail (M.α (M.σ x)) := by
  rw [st1_apply, tail_inv, tail_stp]

theorem reach_stp {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) :
    M.Reach v0 (n + 1) (M.tail (M.stp d)) := by
  rw [tail_stp]; exact h.head

theorem reach_stp_inv {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) :
    M.Reach v0 (n + 1) (M.tail (M.stp⁻¹ d)) := by
  have hy : M.stp (M.stp⁻¹ d) = d := M.stp.apply_symm_apply d
  have ht : M.tail (M.α (M.stp⁻¹ d)) = M.tail d := by rw [← tail_stp, hy]
  have := Reach.step (M := M) (v0 := v0) (M.α (M.stp⁻¹ d)) ht h
  rwa [M.α_α] at this

theorem reach_st1 {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) :
    M.Reach v0 (n + 1) (M.tail (M.st1 d)) := by
  rw [tail_st1]
  exact Reach.step (M.σ d) (M.tail_σ d) h

theorem reach_st1_inv {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) :
    M.Reach v0 (n + 1) (M.tail (M.st1⁻¹ d)) := by
  have hy : M.st1 (M.st1⁻¹ d) = d := M.st1.apply_symm_apply d
  have ht : M.tail (M.α (M.σ (M.st1⁻¹ d))) = M.tail d := by rw [← tail_st1, hy]
  have := Reach.step (M := M) (v0 := v0) (M.α (M.σ (M.st1⁻¹ d))) ht h
  rwa [M.α_α, M.tail_σ] at this

theorem reach_pow {T : Perm D}
    (hs : ∀ {n : ℕ} {d : D}, M.Reach v0 n (M.tail d) → M.Reach v0 (n + 1) (M.tail (T d)))
    (m : ℕ) {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) :
    M.Reach v0 (n + m) (M.tail ((T ^ m) d)) := by
  induction m with
  | zero => simpa using h
  | succ m ih =>
    rw [pow_succ', Perm.mul_apply]
    exact hs ih

theorem reach_zpow {T : Perm D}
    (hs : ∀ {n : ℕ} {d : D}, M.Reach v0 n (M.tail d) → M.Reach v0 (n + 1) (M.tail (T d)))
    (hs' : ∀ {n : ℕ} {d : D}, M.Reach v0 n (M.tail d) → M.Reach v0 (n + 1) (M.tail (T⁻¹ d)))
    (k : ℤ) {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) :
    M.Reach v0 (n + k.natAbs) (M.tail ((T ^ k) d)) := by
  cases k with
  | ofNat m =>
    simpa using reach_pow hs m h
  | negSucc m =>
    have h1 := reach_pow hs' (m + 1) h
    have e : T ^ (Int.negSucc m) = (T⁻¹) ^ (m + 1) := by
      rw [zpow_negSucc, inv_pow]
    rw [e]
    simpa using h1

/-! ### The development -/

/-- The development, direction `0`, at lattice point `(x, y)`. -/
def dev (M : CMap D) (d0 : D) (x y : ℤ) : D := (M.st1 ^ y) ((M.stp ^ x) d0)

theorem reach_dev (d0 : D) (x y : ℤ) :
    M.Reach (M.tail d0) (x.natAbs + y.natAbs) (M.tail (M.dev d0 x y)) := by
  have h0 : M.Reach (M.tail d0) 0 (M.tail d0) := Reach.zero
  have h1 := reach_zpow (T := M.stp) reach_stp reach_stp_inv x h0
  have h2 := reach_zpow (T := M.st1) reach_st1 reach_st1_inv y h1
  unfold dev
  simpa using h2

theorem dev_y_succ (d0 : D) (x y : ℤ) : M.st1 (M.dev d0 x y) = M.dev d0 x (y + 1) := by
  unfold dev
  rw [add_comm y 1, zpow_one_add, Perm.mul_apply]

/-- A vertex within radius `R` is flat. -/
def FlatTo (M : CMap D) (v0 : M.V) (R : ℕ) : Prop := ∀ v, M.Reach v0 R v → M.deg v = 6

variable {R : ℕ}

theorem FlatTo.fl (hF : M.FlatTo v0 R) {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d)) (hn : n ≤ R) :
    M.Fl d := Fl_of_deg (hF _ (h.mono hn))

theorem FlatTo.fl_head (hF : M.FlatTo v0 R) {n : ℕ} {d : D} (h : M.Reach v0 n (M.tail d))
    (hn : n + 1 ≤ R) : M.Fl (M.α d) := hF.fl h.head hn

/-- Commuting the straight step past powers of the other. -/
theorem commute_pow (hT : M.IsTriangulation) (hF : M.FlatTo v0 R) {n : ℕ} {e : D}
    (he : M.Reach v0 n (M.tail e)) :
    ∀ m : ℕ, n + m + 1 ≤ R → M.stp ((M.st1 ^ m) e) = (M.st1 ^ m) (M.stp e) := by
  intro m
  induction m with
  | zero => intro _; simp
  | succ m ih =>
    intro hm
    have hr : M.Reach v0 (n + m) (M.tail ((M.st1 ^ m) e)) := reach_pow reach_st1 m he
    rw [pow_succ', Perm.mul_apply, Perm.mul_apply, rhombus hT (hF.fl_head hr (by omega)),
      ih (by omega)]

theorem commute_inv_pow (hT : M.IsTriangulation) (hF : M.FlatTo v0 R) {n : ℕ} {e : D}
    (he : M.Reach v0 n (M.tail e)) :
    ∀ m : ℕ, n + m + 1 ≤ R → M.stp (((M.st1)⁻¹ ^ m) e) = ((M.st1)⁻¹ ^ m) (M.stp e) := by
  intro m
  induction m with
  | zero => intro _; simp
  | succ m ih =>
    intro hm
    have hr : M.Reach v0 (n + (m + 1)) (M.tail (((M.st1)⁻¹ ^ (m + 1)) e)) :=
      reach_pow reach_st1_inv (m + 1) he
    set c := ((M.st1)⁻¹ ^ m) e with hc
    have hsplit : ((M.st1)⁻¹ ^ (m + 1)) e = (M.st1)⁻¹ c := by
      rw [pow_succ', Perm.mul_apply]
    have hbd : M.st1 ((M.st1)⁻¹ c) = c := M.st1.apply_symm_apply c
    have hr' : M.Reach v0 (n + (m + 1)) (M.tail ((M.st1)⁻¹ c)) := by rw [← hsplit]; exact hr
    have hrh := rhombus hT (hF.fl_head hr' (by omega))
    rw [hbd, ih (by omega)] at hrh
    rw [pow_succ', Perm.mul_apply, Perm.mul_apply]
    rw [show M.stp ((M.st1)⁻¹ c) = (M.st1)⁻¹ (M.st1 (M.stp ((M.st1)⁻¹ c))) from
      (M.st1.symm_apply_apply _).symm, ← hrh]

/-- Step in direction `0` of the development. -/
theorem dev_E0 (hT : M.IsTriangulation) {d0 : D} (hF : M.FlatTo (M.tail d0) R) {x y : ℤ}
    (h : x.natAbs + y.natAbs + 1 ≤ R) : M.stp (M.dev d0 x y) = M.dev d0 (x + 1) y := by
  have he := reach_zpow (T := M.stp) (v0 := M.tail d0) reach_stp reach_stp_inv x
    (show M.Reach (M.tail d0) 0 (M.tail d0) from Reach.zero)
  rw [zero_add] at he
  unfold dev
  have hx : (M.stp ^ (x + 1)) d0 = M.stp ((M.stp ^ x) d0) := by
    rw [add_comm x 1, zpow_one_add, Perm.mul_apply]
  rw [hx]
  cases y with
  | ofNat m =>
    have := commute_pow hT hF he m (by simpa using h)
    simpa using this
  | negSucc m =>
    have hm := commute_inv_pow hT hF he (m + 1) (by simpa using h)
    have e : M.st1 ^ (Int.negSucc m) = ((M.st1)⁻¹) ^ (m + 1) := by
      rw [zpow_negSucc, inv_pow]
    rw [e]
    exact hm

/-- Step in direction `1`. -/
theorem dev_E1 (d0 : D) (x y : ℤ) : M.stp (M.σ (M.dev d0 x y)) = M.σ (M.dev d0 x (y + 1)) := by
  rw [← dev_y_succ, st1_apply, σ_σ_inv]

/-- Step in direction `2`. -/
theorem dev_E2 (hT : M.IsTriangulation) {d0 : D} (hF : M.FlatTo (M.tail d0) R) {x y : ℤ}
    (h : x.natAbs + y.natAbs + 3 ≤ R) :
    M.stp (M.σ (M.σ (M.dev d0 x y))) = M.σ (M.σ (M.dev d0 (x - 1) (y + 1))) := by
  have hr := reach_dev (M := M) d0 x y
  have hrσ : M.Reach (M.tail d0) (x.natAbs + y.natAbs) (M.tail (M.σ (M.dev d0 x y))) := by
    rw [M.tail_σ]; exact hr
  have hf1 := hF.fl_head hrσ (by omega)
  have h1 := fF hT hf1
  rw [dev_E1] at h1
  have hc := reach_dev (M := M) d0 (x - 1) (y + 1)
  have hna : (x - 1).natAbs + (y + 1).natAbs ≤ x.natAbs + y.natAbs + 2 := by omega
  have hrc := hc.mono hna
  have hE := dev_E0 hT hF (x := x - 1) (y := y + 1) (by omega)
  rw [sub_add_cancel] at hE
  have hrev := stp_rev (hF.fl_head hrc (by omega))
  rw [hE] at hrev
  rw [h1, hrev, σ_inv_σ]

/-- Step in direction `3`. -/
theorem dev_E3 (hT : M.IsTriangulation) {d0 : D} (hF : M.FlatTo (M.tail d0) R) {x y : ℤ}
    (h : x.natAbs + y.natAbs + 3 ≤ R) :
    M.stp (M.σ (M.σ (M.σ (M.dev d0 x y)))) = M.σ (M.σ (M.σ (M.dev d0 (x - 1) y))) := by
  have hc := (reach_dev (M := M) d0 (x - 1) y).mono (show _ ≤ x.natAbs + y.natAbs + 1 by omega)
  have hE := dev_E0 hT hF (x := x - 1) (y := y) (by omega)
  rw [sub_add_cancel] at hE
  have hrev := stp_rev (hF.fl_head hc (by omega))
  rwa [hE] at hrev

/-- Step in direction `4`. -/
theorem dev_E4 {d0 : D} (hF : M.FlatTo (M.tail d0) R) {x y : ℤ}
    (h : x.natAbs + y.natAbs + 3 ≤ R) :
    M.stp (M.σ (M.σ (M.σ (M.σ (M.dev d0 x y))))) = M.σ (M.σ (M.σ (M.σ (M.dev d0 x (y - 1))))) := by
  have hc := (reach_dev (M := M) d0 x (y - 1)).mono (show _ ≤ x.natAbs + y.natAbs + 1 by omega)
  have hE := dev_E1 (M := M) d0 x (y - 1)
  rw [sub_add_cancel] at hE
  have hrev := stp_rev (h := M.σ (M.dev d0 x (y - 1)))
    (hF.fl_head (by rw [M.tail_σ]; exact hc) (by omega))
  rwa [hE] at hrev

/-- Step in direction `5`. -/
theorem dev_E5 (hT : M.IsTriangulation) {d0 : D} (hF : M.FlatTo (M.tail d0) R) {x y : ℤ}
    (h : x.natAbs + y.natAbs + 6 ≤ R) :
    M.stp (M.σ (M.σ (M.σ (M.σ (M.σ (M.dev d0 x y)))))) =
      M.σ (M.σ (M.σ (M.σ (M.σ (M.dev d0 (x + 1) (y - 1)))))) := by
  have hc := (reach_dev (M := M) d0 (x + 1) (y - 1)).mono
    (show _ ≤ x.natAbs + y.natAbs + 2 by omega)
  have hE := dev_E2 hT hF (x := x + 1) (y := y - 1) (by omega)
  rw [add_sub_cancel_right, sub_add_cancel] at hE
  have hrev := stp_rev (h := M.σ (M.σ (M.dev d0 (x + 1) (y - 1))))
    (hF.fl_head (by rw [M.tail_σ, M.tail_σ]; exact hc) (by omega))
  rwa [hE] at hrev

end CMap

end Ful

end
