import FulStatement
import FulDigon

#print axioms Ful.Stmt.LocalWeakConvergence
#print axioms Ful.CMap.IsFullerene.no_fold
#print axioms Ful.CMap.IsFullerene.dual_no_loop
#print axioms Ful.CMap.digon_curv_ge
#print axioms Ful.CMap.no_digon
#print axioms Ful.CMap.IsFullerene.dual_simple
