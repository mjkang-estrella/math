/-
FulCut: the gate.  In a connected genus-zero combinatorial map, a simple cycle has exactly two
sides, each a disc with Euler characteristic one; faces, interior vertices and interior edges are
partitioned.  The proof is Euler additivity across the cycle plus the bound `χ ≤ 1` for each side;
no Jordan curve theorem and no surgery on the map are used.
-/
import FulCycle

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

/-- Extension by zero of a function on a finset. -/
def extend0 {ι : Type*} (A : Finset ι) (x : A → F2) (i : ι) : F2 :=
  if h : i ∈ A then x ⟨i, h⟩ else 0

theorem extend0_coe {ι : Type*} (A : Finset ι) (x : A → F2) (a : A) : extend0 A x a.1 = x a := by
  simp only [extend0, a.2, dite_true]

theorem extend0_not_mem {ι : Type*} {A : Finset ι} (x : A → F2) {i : ι} (h : i ∉ A) :
    extend0 A x i = 0 := by
  simp only [extend0, h, dite_false]

theorem sub_mulVec {R T : Type*} [Fintype R] [Fintype T] (N : Matrix R T F2) (A : Finset R)
    (B : Finset T) (x : B → F2) (r : A) :
    (N.submatrix (fun a : A => a.1) (fun b : B => b.1)).mulVec x r =
      N.mulVec (extend0 B x) r.1 := by
  simp only [Matrix.mulVec, dotProduct, Matrix.submatrix_apply]
  have h1 : ∑ t, N r.1 t * extend0 B x t = ∑ t ∈ B, N r.1 t * extend0 B x t :=
    (Finset.sum_subset (Finset.subset_univ B) (fun t _ ht => by
      rw [extend0_not_mem x ht, mul_zero])).symm
  rw [h1, ← Finset.sum_coe_sort B (fun t => N r.1 t * extend0 B x t)]
  exact Finset.sum_congr rfl fun t _ => by rw [extend0_coe]

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- Vertices of the closed region spanned by a set of faces. -/
def clV (S : Finset M.F) : Finset M.V := univ.filter fun v => ∃ d, M.tail d = v ∧ M.face d ∈ S
/-- Edges of the closed region spanned by a set of faces. -/
def clE (S : Finset M.F) : Finset M.E := univ.filter fun e => ∃ d, M.edge d = e ∧ M.face d ∈ S

theorem mem_clV {S : Finset M.F} {v : M.V} : v ∈ clV S ↔ ∃ d, M.tail d = v ∧ M.face d ∈ S := by
  simp only [clV, mem_filter, mem_univ, true_and]

theorem mem_clE {S : Finset M.F} {e : M.E} : e ∈ clE S ↔ ∃ d, M.edge d = e ∧ M.face d ∈ S := by
  simp only [clE, mem_filter, mem_univ, true_and]

/-- Interior vertices of a side. -/
def SimpleCycle.intV (C : SimpleCycle M) (S : Finset M.F) : Finset M.V := clV S \ C.verts
/-- Interior edges of a side. -/
def SimpleCycle.intE (C : SimpleCycle M) (S : Finset M.F) : Finset M.E := clE S \ C.edges

variable {C : SimpleCycle M} {S : Finset M.F}

theorem IsSide.edges_subset (h : IsSide C S) : C.edges ⊆ clE S := by
  intro e he
  obtain ⟨i, rfl⟩ := C.exists_of_edge_mem he
  have h0 := (h (C.dart i)).1 he
  by_cases h1 : M.face (C.dart i) ∈ S
  · exact mem_clE.2 ⟨_, rfl, h1⟩
  · have h2 : M.face (M.α (C.dart i)) ∈ S := by
      by_contra h2
      exact h0 (iff_of_false h1 h2)
    exact mem_clE.2 ⟨_, M.edge_α _, h2⟩

theorem IsSide.verts_subset (h : IsSide C S) : C.verts ⊆ clV S := by
  intro v hv
  obtain ⟨i, rfl⟩ := C.exists_of_vert_mem hv
  have h0 := (h (C.dart i)).1 (C.edge_mem i)
  by_cases h1 : M.face (C.dart i) ∈ S
  · exact mem_clV.2 ⟨_, rfl, h1⟩
  · have h2 : M.face (M.α (C.dart i)) ∈ S := by
      by_contra h2
      exact h0 (iff_of_false h1 h2)
    rw [M.face_α] at h2
    exact mem_clV.2 ⟨_, M.tail_σ _, h2⟩

/-- Away from the cycle, all corners at a vertex lie on the same side. -/
theorem IsSide.same_side (h : IsSide C S) {d d' : D} (ht : M.tail d = M.tail d')
    (hv : M.tail d ∉ C.verts) : M.face d ∈ S ↔ M.face d' ∈ S := by
  have step : ∀ x, M.tail x ∉ C.verts → (M.face (M.σ x) ∈ S ↔ M.face x ∈ S) := by
    intro x hx
    have he : M.edge x ∉ C.edges := fun h' => hx (C.tail_mem_of_edge_mem h')
    have h1 : M.face x ∈ S ↔ M.face (M.α x) ∈ S := not_not.1 fun hn => he ((h x).2 hn)
    rw [M.face_α] at h1
    exact h1.symm
  have hg : ∀ x, (M.tail (M.σ x) ∈ C.verts ∨ M.face (M.σ x) ∈ S) =
      (M.tail x ∈ C.verts ∨ M.face x ∈ S) := by
    intro x
    apply propext
    rw [M.tail_σ]
    by_cases hx : M.tail x ∈ C.verts
    · simp only [hx, true_or]
    · simp only [hx, false_or]
      exact step x hx
  have key : (M.tail d ∈ C.verts ∨ M.face d ∈ S) = (M.tail d' ∈ C.verts ∨ M.face d' ∈ S) :=
    Orb.eq_of_mk_eq (p := M.σ) (fun x => M.tail x ∈ C.verts ∨ M.face x ∈ S) hg ht
  have hv' : M.tail d' ∉ C.verts := ht ▸ hv
  simp only [hv, hv', false_or] at key
  exact key.to_iff

theorem IsSide.clE_inter (h : IsSide C S) : clE S ∩ clE Sᶜ = C.edges := by
  ext e
  constructor
  · intro he
    obtain ⟨d, rfl, hd⟩ := mem_clE.1 (mem_inter.1 he).1
    obtain ⟨d', hd', hnd'⟩ := mem_clE.1 (mem_inter.1 he).2
    rcases M.edge_eq_iff.1 hd'.symm with rfl | rfl
    · exact absurd hd (mem_compl.1 hnd')
    · exact (h d).2 fun hi => mem_compl.1 hnd' (hi.1 hd)
  · intro he
    exact mem_inter.2 ⟨h.edges_subset he, (IsSide.compl C h).edges_subset he⟩

theorem IsSide.clE_union : clE S ∪ clE Sᶜ = (univ : Finset M.E) := by
  rw [eq_univ_iff_forall]
  intro e
  obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
  by_cases h1 : M.face d ∈ S
  · exact mem_union_left _ (mem_clE.2 ⟨d, rfl, h1⟩)
  · exact mem_union_right _ (mem_clE.2 ⟨d, rfl, mem_compl.2 h1⟩)

theorem IsSide.clV_inter (h : IsSide C S) : clV S ∩ clV Sᶜ = C.verts := by
  ext v
  constructor
  · intro hv
    obtain ⟨d, rfl, hd⟩ := mem_clV.1 (mem_inter.1 hv).1
    obtain ⟨d', hd', hnd'⟩ := mem_clV.1 (mem_inter.1 hv).2
    by_contra hn
    exact mem_compl.1 hnd' ((h.same_side hd'.symm hn).1 hd)
  · intro hv
    exact mem_inter.2 ⟨h.verts_subset hv, (IsSide.compl C h).verts_subset hv⟩

theorem IsSide.clV_union : clV S ∪ clV Sᶜ = (univ : Finset M.V) := by
  rw [eq_univ_iff_forall]
  intro v
  obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
  by_cases h1 : M.face d ∈ S
  · exact mem_union_left _ (mem_clV.2 ⟨d, rfl, h1⟩)
  · exact mem_union_right _ (mem_clV.2 ⟨d, rfl, mem_compl.2 h1⟩)

/-- A vertex function locally constant along the closed region of a side is constant.  This is
connectivity of the closed region. -/
theorem IsSide.side_const (hc : M.Connected) (h : IsSide C S) (g : M.V → F2)
    (step : ∀ d, M.edge d ∈ clE S → g (M.tail d) = g (M.tail (M.α d))) :
    ∀ v ∈ clV S, g v = g (M.tail (C.dart 0)) := by
  set a := g (M.tail (C.dart 0)) with ha
  have hcyc : ∀ i, g (M.tail (C.dart i)) = a := by
    intro i
    induction i with
    | zero => rfl
    | succ n ih =>
      rw [← C.chain, ← step _ (h.edges_subset (C.edge_mem n)), ih]
  have hvert : ∀ v ∈ C.verts, g v = a := by
    intro v hv
    obtain ⟨i, rfl⟩ := C.exists_of_vert_mem hv
    exact hcyc i
  let t : M.F → F2 := Orb.lift (p := M.φ) (fun d => if M.face d ∈ S then g (M.tail d) else 0)
    (fun d => by
      simp only [M.face_φ]
      by_cases hd : M.face d ∈ S
      · simp only [hd, ite_true]
        rw [M.tail_φ]
        exact (step d (mem_clE.2 ⟨d, rfl, hd⟩)).symm
      · simp only [hd, ite_false])
  have ht : ∀ d, t (M.face d) = if M.face d ∈ S then g (M.tail d) else 0 := fun d => rfl
  have hx : M.d2.mulVec (fun f => t f + a * indF S f) = 0 := by
    refine d2_eq_zero_iff.2 fun d => ?_
    show t (M.face d) + a * indF S (M.face d) = t (M.face (M.α d)) + a * indF S (M.face (M.α d))
    rw [ht, ht]
    unfold indF
    by_cases h1 : M.face d ∈ S
    · by_cases h2 : M.face (M.α d) ∈ S
      · simp only [h1, h2, ite_true]
        rw [step d (mem_clE.2 ⟨d, rfl, h1⟩)]
      · have he : M.edge d ∈ C.edges := (h d).2 fun hi => h2 (hi.1 h1)
        simp only [h1, h2, ite_true, ite_false, mul_one, mul_zero, add_zero]
        rw [hvert _ (C.tail_mem_of_edge_mem he)]
        exact F2.add_self _
    · by_cases h2 : M.face (M.α d) ∈ S
      · have he : M.edge d ∈ C.edges := (h d).2 fun hi => h1 (hi.2 h2)
        have he' : M.edge (M.α d) ∈ C.edges := by rw [M.edge_α]; exact he
        simp only [h1, h2, ite_true, ite_false, mul_one, mul_zero, add_zero]
        rw [hvert _ (C.tail_mem_of_edge_mem he')]
        exact (F2.add_self _).symm
      · simp only [h1, h2, ite_false, mul_zero, add_zero]
  obtain ⟨f0, hf0⟩ := (IsSide.exists_mem C h).2
  obtain ⟨d0, rfl⟩ := Orb.mk_surjective _ f0
  have hf0' : M.face d0 ∉ S := mem_compl.1 hf0
  have hval0 : t (M.face d0) + a * indF S (M.face d0) = 0 := by
    rw [ht]
    unfold indF
    simp only [hf0', ite_false, mul_zero, add_zero]
  rcases hc.ker_d2 hx with h0 | h1
  · intro v hv
    obtain ⟨d, rfl, hd⟩ := mem_clV.1 hv
    have := congrFun h0 (M.face d)
    simp only [Pi.zero_apply] at this
    rw [ht] at this
    unfold indF at this
    simp only [hd, ite_true, mul_one] at this
    exact F2.eq_of_add_eq_zero this
  · exfalso
    have := congrFun h1 (M.face d0)
    simp only [Pi.one_apply] at this
    rw [show t (M.face d0) + a * indF S (M.face d0) = 0 from hval0] at this
    exact zero_ne_one this

/-- The closed region of a side has Euler characteristic at most one. -/
theorem IsSide.euler_le (hc : M.Connected) (h : IsSide C S) :
    (clV S).card + S.card ≤ (clE S).card + 1 := by
  let P : Matrix (clV S) (clE S) F2 := M.d1.submatrix (fun a => a.1) (fun b => b.1)
  let Q : Matrix (clE S) S F2 := M.d2.submatrix (fun a => a.1) (fun b => b.1)
  have hQext : ∀ x : S → F2, extend0 (clE S) (Q.mulVec x) = M.d2.mulVec (extend0 S x) := by
    intro x
    funext e
    by_cases he : e ∈ clE S
    · exact (extend0_coe _ _ ⟨e, he⟩).trans (sub_mulVec M.d2 (clE S) S x ⟨e, he⟩)
    · rw [extend0_not_mem _ he]
      obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
      show _ = M.d2.mulVec _ (M.edge d)
      rw [d2_mulVec_edge]
      have h1 : M.face d ∉ S := fun hn => he (mem_clE.2 ⟨d, rfl, hn⟩)
      have h2 : M.face (M.α d) ∉ S := fun hn => he (mem_clE.2 ⟨M.α d, M.edge_α d, hn⟩)
      rw [extend0_not_mem _ h1, extend0_not_mem _ h2, add_zero]
  have hPQ : ∀ x, P.mulVec (Q.mulVec x) = 0 := by
    intro x
    funext v
    have := sub_mulVec M.d1 (clV S) (clE S) (Q.mulVec x) v
    rw [hQext] at this
    exact this.trans (congrFun (M.d1_d2 _) v.1)
  have ha : finrank F2 (LinearMap.ker Q.mulVecLin) ≤ 0 := by
    have hker : LinearMap.ker Q.mulVecLin = ⊥ := by
      rw [Submodule.eq_bot_iff]
      intro x hx
      have hx0 : Q.mulVec x = 0 := LinearMap.mem_ker.1 hx
      have h0 : M.d2.mulVec (extend0 S x) = 0 := by
        rw [← hQext, hx0]
        funext e
        by_cases he : e ∈ clE S
        · exact extend0_coe _ _ ⟨e, he⟩
        · exact extend0_not_mem _ he
      rcases hc.ker_d2 h0 with h1 | h1
      · funext s
        have := congrFun h1 s.1
        rwa [extend0_coe] at this
      · exfalso
        obtain ⟨f0, hf0⟩ := (IsSide.exists_mem C h).2
        have := congrFun h1 f0
        rw [extend0_not_mem _ (mem_compl.1 hf0)] at this
        exact zero_ne_one this
    rw [hker, finrank_bot]
  have hb : finrank F2 (LinearMap.ker P.transpose.mulVecLin) ≤ 1 := by
    refine finrank_le_one_of_forall _ 1 fun g hg => ?_
    have hg0 : P.transpose.mulVec g = 0 := LinearMap.mem_ker.1 hg
    have step : ∀ d, M.edge d ∈ clE S →
        extend0 (clV S) g (M.tail d) = extend0 (clV S) g (M.tail (M.α d)) := by
      intro d hd
      have h1 := congrFun hg0 ⟨M.edge d, hd⟩
      have h2 := sub_mulVec M.d1.transpose (clE S) (clV S) g ⟨M.edge d, hd⟩
      have h3 : P.transpose = M.d1.transpose.submatrix (fun a => a.1) (fun b => b.1) := rfl
      rw [← h3] at h2
      rw [h2] at h1
      simp only [Pi.zero_apply] at h1
      rw [d1T_mulVec_edge] at h1
      exact F2.eq_of_add_eq_zero h1
    have hconst := IsSide.side_const hc h (extend0 (clV S) g) step
    rcases F2.eq_zero_or_one (extend0 (clV S) g (M.tail (C.dart 0))) with h0 | h0
    · left
      funext v
      have := hconst v.1 v.2
      rw [extend0_coe, h0] at this
      exact this
    · right
      funext v
      have := hconst v.1 v.2
      rw [extend0_coe, h0] at this
      exact this
  have := euler_abstract P Q hPQ ha hb
  simp only [Fintype.card_coe] at this
  omega

/-- **Euler additivity.** The closed region of each side has Euler characteristic exactly one. -/
theorem IsSide.euler (hc : M.Connected) (hg : M.Genus0) (h : IsSide C S) :
    (clV S).card + S.card = (clE S).card + 1 := by
  have a1 := IsSide.euler_le hc h
  have a2 := IsSide.euler_le hc (IsSide.compl C h)
  have c1 := card_union_add_card_inter (clV S) (clV Sᶜ)
  rw [IsSide.clV_union, h.clV_inter, card_univ, C.card_verts] at c1
  have c2 := card_union_add_card_inter (clE S) (clE Sᶜ)
  rw [IsSide.clE_union, h.clE_inter, card_univ, C.card_edges] at c2
  have c3 := Finset.card_compl S
  have c4 := Finset.card_le_univ S
  unfold Genus0 numV numF numE at hg
  omega

theorem IsSide.card_intV (h : IsSide C S) : (C.intV S).card + C.len = (clV S).card := by
  have := card_sdiff_add_card_eq_card h.verts_subset
  rwa [C.card_verts] at this

theorem IsSide.card_intE (h : IsSide C S) : (C.intE S).card + C.len = (clE S).card := by
  have := card_sdiff_add_card_eq_card h.edges_subset
  rwa [C.card_edges] at this

/-- Euler characteristic one in the form used for discs: `I + F = E_int + 1`. -/
theorem IsSide.euler_int (hc : M.Connected) (hg : M.Genus0) (h : IsSide C S) :
    (C.intV S).card + S.card = (C.intE S).card + 1 := by
  have := IsSide.euler hc hg h
  have a := h.card_intV
  have b := h.card_intE
  omega

theorem IsSide.mem_intV (h : IsSide C S) {v : M.V} :
    v ∈ C.intV S ↔ v ∉ C.verts ∧ ∀ d, M.tail d = v → M.face d ∈ S := by
  unfold SimpleCycle.intV
  rw [mem_sdiff]
  constructor
  · rintro ⟨hc, hn⟩
    obtain ⟨d, rfl, hd⟩ := mem_clV.1 hc
    exact ⟨hn, fun d' hd' => (h.same_side hd'.symm hn).1 hd⟩
  · rintro ⟨hn, hall⟩
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
    exact ⟨mem_clV.2 ⟨d, rfl, hall d rfl⟩, hn⟩

theorem IsSide.mem_intE (h : IsSide C S) {e : M.E} :
    e ∈ C.intE S ↔ e ∉ C.edges ∧ ∀ d, M.edge d = e → M.face d ∈ S := by
  unfold SimpleCycle.intE
  rw [mem_sdiff]
  constructor
  · rintro ⟨hc, hn⟩
    obtain ⟨d, rfl, hd⟩ := mem_clE.1 hc
    refine ⟨hn, fun d' hd' => ?_⟩
    have hiff : M.face d ∈ S ↔ M.face (M.α d) ∈ S := not_not.1 fun hx => hn ((h d).2 hx)
    rcases M.edge_eq_iff.1 hd'.symm with rfl | rfl
    · exact hd
    · exact hiff.1 hd
  · rintro ⟨hn, hall⟩
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
    exact ⟨mem_clE.2 ⟨d, rfl, hall d rfl⟩, hn⟩

theorem IsSide.disjoint_intV (h : IsSide C S) : Disjoint (C.intV S) (C.intV Sᶜ) := by
  rw [Finset.disjoint_left]
  intro v h1 h2
  have h3 := (mem_sdiff.1 h1).2
  exact h3 (h.clV_inter ▸ mem_inter.2 ⟨(mem_sdiff.1 h1).1, (mem_sdiff.1 h2).1⟩)

theorem IsSide.disjoint_intE (h : IsSide C S) : Disjoint (C.intE S) (C.intE Sᶜ) := by
  rw [Finset.disjoint_left]
  intro v h1 h2
  have h3 := (mem_sdiff.1 h1).2
  exact h3 (h.clE_inter ▸ mem_inter.2 ⟨(mem_sdiff.1 h1).1, (mem_sdiff.1 h2).1⟩)

theorem IsSide.vertex_trichotomy (_h : IsSide C S) (v : M.V) :
    v ∈ C.verts ∨ v ∈ C.intV S ∨ v ∈ C.intV Sᶜ := by
  by_cases hv : v ∈ C.verts
  · exact Or.inl hv
  · right
    have : v ∈ clV S ∪ clV Sᶜ := by rw [IsSide.clV_union]; exact mem_univ v
    rcases mem_union.1 this with h1 | h1
    · exact Or.inl (mem_sdiff.2 ⟨h1, hv⟩)
    · exact Or.inr (mem_sdiff.2 ⟨h1, hv⟩)

theorem IsSide.edge_trichotomy (_h : IsSide C S) (e : M.E) :
    e ∈ C.edges ∨ e ∈ C.intE S ∨ e ∈ C.intE Sᶜ := by
  by_cases hv : e ∈ C.edges
  · exact Or.inl hv
  · right
    have : e ∈ clE S ∪ clE Sᶜ := by rw [IsSide.clE_union]; exact mem_univ e
    rcases mem_union.1 this with h1 | h1
    · exact Or.inl (mem_sdiff.2 ⟨h1, hv⟩)
    · exact Or.inr (mem_sdiff.2 ⟨h1, hv⟩)

/-- Strong connectivity of the faces of a side across interior edges. -/
theorem IsSide.face_const (hc : M.Connected) (h : IsSide C S) (x : M.F → F2)
    (hx : ∀ d, M.face d ∈ S → M.face (M.α d) ∈ S → x (M.face d) = x (M.face (M.α d)))
    {f f' : M.F} (hf : f ∈ S) (hf' : f' ∈ S) : x f = x f' := by
  set t : M.F → F2 := fun f => x f * indF S f with ht
  have hsupp : ∀ e, e ∉ C.edges → M.d2.mulVec t e = 0 := by
    intro e he
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
    show M.d2.mulVec t (M.edge d) = 0
    rw [d2_mulVec_edge]
    have hiff : M.face d ∈ S ↔ M.face (M.α d) ∈ S := not_not.1 fun hn => he ((h d).2 hn)
    simp only [ht, indF]
    by_cases h1 : M.face d ∈ S
    · have h2 := hiff.1 h1
      simp only [h1, h2, ite_true, mul_one]
      rw [hx d h1 h2]
      exact F2.add_self _
    · have h2 : M.face (M.α d) ∉ S := fun h2 => h1 (hiff.2 h2)
      simp only [h1, h2, ite_false, mul_zero, add_zero]
  obtain ⟨f0, hf0⟩ := (IsSide.exists_mem C h).2
  have hf0' : f0 ∉ S := mem_compl.1 hf0
  have ht0 : t f0 = 0 := by simp only [ht, indF, hf0', ite_false, mul_zero]
  have hval : ∀ {f}, f ∈ S → t f = x f := fun {f} hfS => by
    simp only [ht, indF, hfS, ite_true, mul_one]
  rcases C.eq_zero_or_ind _ hsupp (M.d1_d2 t) with h0 | h0
  · rcases hc.ker_d2 h0 with h1 | h1
    · rw [← hval hf, ← hval hf', congrFun h1 f, congrFun h1 f']
      rfl
    · exfalso
      have := congrFun h1 f0
      rw [ht0] at this
      exact zero_ne_one this
  · have hker : M.d2.mulVec (t + indF S) = 0 := by
      rw [Matrix.mulVec_add, h0, h.d2_indF C]
      funext e
      exact F2.add_self _
    have hzero : (t + indF S) f0 = 0 := by
      simp only [Pi.add_apply, ht0, indF, hf0', ite_false, add_zero]
    rcases hc.ker_d2 hker with h1 | h1
    · have val : ∀ {f}, f ∈ S → x f = 1 := fun {f} hfS => by
        have := congrFun h1 f
        simp only [Pi.add_apply, Pi.zero_apply, indF, hfS, ite_true] at this
        rw [hval hfS] at this
        exact F2.eq_of_add_eq_zero this
      rw [val hf, val hf']
    · exfalso
      have := congrFun h1 f0
      rw [hzero] at this
      exact zero_ne_one this

/-- **Sub-disc principle.** A simple cycle contained in the closed region of a side has a side
contained in that side. This is what chord splitting and block extraction consume. -/
theorem IsSide.exists_side_subset (hc : M.Connected) (hg : M.Genus0) (h : IsSide C S)
    (C' : SimpleCycle M) (hC' : ∀ e ∈ C'.edges, e ∈ clE S) : ∃ T, T ⊆ S ∧ IsSide C' T := by
  obtain ⟨T, hT⟩ := exists_isSide C' hc hg
  set x : M.F → F2 := indF (T \ S) with hxdef
  have hsupp : ∀ e, e ∉ C.edges → M.d2.mulVec x e = 0 := by
    intro e he
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
    show M.d2.mulVec x (M.edge d) = 0
    rw [d2_mulVec_edge]
    have hiff : M.face d ∈ S ↔ M.face (M.α d) ∈ S := not_not.1 fun hn => he ((h d).2 hn)
    simp only [hxdef, indF, mem_sdiff]
    by_cases h1 : M.face d ∈ S
    · have h2 := hiff.1 h1
      simp only [h1, h2, not_true_eq_false, and_false, ite_false, add_zero]
    · have h2 : M.face (M.α d) ∉ S := fun h2 => h1 (hiff.2 h2)
      have hne : M.edge d ∉ clE S := by
        intro hmem
        obtain ⟨d', hd', hS'⟩ := mem_clE.1 hmem
        rcases M.edge_eq_iff.1 hd'.symm with rfl | rfl
        · exact h1 hS'
        · exact h2 hS'
      have hnC : M.edge d ∉ C'.edges := fun hmem => hne (hC' _ hmem)
      have hT' : M.face d ∈ T ↔ M.face (M.α d) ∈ T := not_not.1 fun hn => hnC ((hT d).2 hn)
      by_cases h3 : M.face d ∈ T
      · have h4 := hT'.1 h3
        simp only [h1, h2, h3, h4, not_false_eq_true, and_true, ite_true]
        exact F2.add_self _
      · have h4 : M.face (M.α d) ∉ T := fun h4 => h3 (hT'.2 h4)
        simp only [h3, h4, false_and, ite_false, add_zero]
  obtain ⟨f1, hf1⟩ := (IsSide.exists_mem C h).1
  have hx1 : x f1 = 0 := by
    simp only [hxdef, indF, mem_sdiff, hf1, not_true_eq_false, and_false, ite_false]
  rcases C.eq_zero_or_ind _ hsupp (M.d1_d2 x) with h0 | h0
  · rcases hc.ker_d2 h0 with h1 | h1
    · refine ⟨T, ?_, hT⟩
      intro f hf
      by_contra hnf
      have := congrFun h1 f
      simp only [hxdef, indF, mem_sdiff, hf, hnf, not_false_eq_true, and_self, ite_true,
        Pi.zero_apply] at this
      exact one_ne_zero this
    · exfalso
      have := congrFun h1 f1
      rw [hx1] at this
      exact zero_ne_one this
  · have hker : M.d2.mulVec (x + indF Sᶜ) = 0 := by
      rw [Matrix.mulVec_add, h0, (IsSide.compl C h).d2_indF C]
      funext e
      exact F2.add_self _
    have hzero : (x + indF Sᶜ) f1 = 0 := by
      simp only [Pi.add_apply, hx1, indF, mem_compl, hf1, not_true_eq_false, ite_false, add_zero]
    rcases hc.ker_d2 hker with h1 | h1
    · refine ⟨Tᶜ, ?_, IsSide.compl C' hT⟩
      intro f hf
      by_contra hnf
      have := congrFun h1 f
      simp only [Pi.add_apply, Pi.zero_apply, hxdef, indF, mem_sdiff, mem_compl.1 hf, hnf,
        mem_compl, false_and, not_false_eq_true, ite_true, ite_false, zero_add] at this
      exact one_ne_zero this
    · exfalso
      have := congrFun h1 f1
      rw [hzero] at this
      exact zero_ne_one this

/-- A side of a simple cycle in a connected genus-zero map: a disc, in the form that later
modules consume. -/
structure IsDisc (C : SimpleCycle M) (S : Finset M.F) : Prop where
  side : IsSide C S
  nonempty : S.Nonempty
  compl_nonempty : Sᶜ.Nonempty
  euler : (C.intV S).card + S.card = (C.intE S).card + 1
  vertex_connected : ∀ g : M.V → F2, (∀ d, M.edge d ∈ clE S → g (M.tail d) = g (M.tail (M.α d))) →
    ∀ v ∈ clV S, ∀ w ∈ clV S, g v = g w
  face_connected : ∀ x : M.F → F2,
    (∀ d, M.face d ∈ S → M.face (M.α d) ∈ S → x (M.face d) = x (M.face (M.α d))) →
    ∀ f ∈ S, ∀ f' ∈ S, x f = x f'
  sub_disc : ∀ C' : SimpleCycle M, (∀ e ∈ C'.edges, e ∈ clE S) → ∃ T, T ⊆ S ∧ IsSide C' T

theorem isDisc_of_isSide (hc : M.Connected) (hg : M.Genus0) (h : IsSide C S) : IsDisc C S where
  side := h
  nonempty := (IsSide.exists_mem C h).1
  compl_nonempty := (IsSide.exists_mem C h).2
  euler := IsSide.euler_int hc hg h
  vertex_connected := fun g hstep v hv w hw => by
    rw [IsSide.side_const hc h g hstep v hv, IsSide.side_const hc h g hstep w hw]
  face_connected := fun x hx f hf f' hf' => IsSide.face_const hc h x hx hf hf'
  sub_disc := fun C' hC' => IsSide.exists_side_subset hc hg h C' hC'

/-- **The gate.** Cutting a connected genus-zero map along a simple cycle: there is a set of faces
`S` such that `S` and its complement are both discs with Euler characteristic one, they are the
only two sides, and the faces, interior vertices and interior edges are partitioned. -/
theorem cut_along_cycle (hc : M.Connected) (hg : M.Genus0) (C : SimpleCycle M) :
    ∃ S : Finset M.F,
      IsDisc C S ∧ IsDisc C Sᶜ ∧
      (∀ T, IsSide C T → T = S ∨ T = Sᶜ) ∧
      Disjoint (C.intV S) (C.intV Sᶜ) ∧ Disjoint (C.intE S) (C.intE Sᶜ) ∧
      (∀ v, v ∈ C.verts ∨ v ∈ C.intV S ∨ v ∈ C.intV Sᶜ) ∧
      (∀ e, e ∈ C.edges ∨ e ∈ C.intE S ∨ e ∈ C.intE Sᶜ) ∧
      (∀ v, v ∈ C.intV S → v ∉ C.verts ∧ ∀ d, M.tail d = v → M.face d ∈ S) ∧
      (∀ v, v ∈ C.intV Sᶜ → v ∉ C.verts ∧ ∀ d, M.tail d = v → M.face d ∉ S) := by
  obtain ⟨S, h⟩ := exists_isSide C hc hg
  have h' := IsSide.compl C h
  refine ⟨S, isDisc_of_isSide hc hg h, isDisc_of_isSide hc hg h',
    fun T hT => IsSide.eq_or_eq_compl C hc h hT, h.disjoint_intV, h.disjoint_intE,
    h.vertex_trichotomy, h.edge_trichotomy, fun v hv => h.mem_intV.1 hv, fun v hv => ?_⟩
  obtain ⟨hn, hall⟩ := h'.mem_intV.1 hv
  exact ⟨hn, fun d hd => mem_compl.1 (hall d hd)⟩

/-- The gate for a simple cycle in the dual of a connected genus-zero map (in particular the dual
triangulation of a fullerene map). -/
theorem cut_along_dual_cycle (hc : M.Connected) (hg : M.Genus0) (C : SimpleCycle M.dual) :
    ∃ S : Finset M.dual.F,
      IsDisc C S ∧ IsDisc C Sᶜ ∧ (∀ T, IsSide C T → T = S ∨ T = Sᶜ) := by
  obtain ⟨S, h1, h2, h3, -⟩ := cut_along_cycle hc.dual hg.dual C
  exact ⟨S, h1, h2, h3⟩

end CMap

end Ful

end
