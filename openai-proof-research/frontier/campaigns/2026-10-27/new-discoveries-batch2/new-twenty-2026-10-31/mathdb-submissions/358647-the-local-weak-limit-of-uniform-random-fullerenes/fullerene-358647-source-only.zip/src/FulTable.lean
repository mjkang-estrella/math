/-
FulTable: a sphere triangulation from an explicit rotation table.  A `Table` lists, for each of the
`n` vertices, its neighbours in rotation order; the laws are local.  The dual of the resulting map
is a fullerene map once the total curvature is 12.
-/
import FulDigon

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset
open scoped Classical

theorem mod_add_one_sub {d k : ℕ} (hk : k < d) : ((k + 1) % d + d - 1) % d = k := by
  by_cases h : k + 1 = d
  · rw [h, Nat.mod_self, Nat.zero_add, Nat.mod_eq_of_lt (by omega)]
    omega
  · rw [Nat.mod_eq_of_lt (by omega : k + 1 < d)]
    have h2 : k + 1 + d - 1 = k + d := by omega
    rw [h2, Nat.add_mod_right, Nat.mod_eq_of_lt hk]

theorem mod_sub_one_add {d k : ℕ} (hk : k < d) : ((k + d - 1) % d + 1) % d = k := by
  by_cases h : k = 0
  · subst h
    rw [Nat.zero_add, Nat.mod_eq_of_lt (by omega : d - 1 < d), show d - 1 + 1 = d by omega, Nat.mod_self]
  · have h2 : k + d - 1 = (k - 1) + d := by omega
    rw [h2, Nat.add_mod_right, Nat.mod_eq_of_lt (by omega : k - 1 < d),
      show k - 1 + 1 = k by omega, Nat.mod_eq_of_lt hk]

/-- A rotation table on `n` vertices. -/
structure Table (n : ℕ) where
  deg : Fin n → ℕ
  nb : Fin n → ℕ → Fin n
  ix : Fin n → ℕ → ℕ
  deg_pos : ∀ u, 0 < deg u
  ix_lt : ∀ u k, k < deg u → ix u k < deg (nb u k)
  irr : ∀ u k, k < deg u → nb u k ≠ u
  nb_ix : ∀ u k, k < deg u → nb (nb u k) (ix u k) = u
  inj : ∀ u k k', k < deg u → k' < deg u → nb u k = nb u k' → k = k'
  tri : ∀ u k, k < deg u →
    nb (nb u k) ((ix u k + 1) % deg (nb u k)) = nb u ((k + deg u - 1) % deg u)

namespace Table

variable {n : ℕ} (A : Table n)

/-- Darts are pairs (vertex, index). -/
abbrev Dart : Type := {p : Fin n × ℕ // p.2 < A.deg p.1}

noncomputable instance : Fintype A.Dart :=
  Fintype.ofInjective (fun p => (⟨p.1.1, ⟨p.1.2, p.2⟩⟩ : Σ u, Fin (A.deg u))) (by
    intro p q h
    apply Subtype.ext
    obtain ⟨⟨u, k⟩, hk⟩ := p
    obtain ⟨⟨v, l⟩, hl⟩ := q
    simp only [Sigma.mk.injEq] at h
    obtain ⟨rfl, h2⟩ := h
    simp only [heq_eq_eq, Fin.mk.injEq] at h2
    exact Prod.ext rfl h2)

/-- The reversal of a dart. -/
def nbD (p : A.Dart) : A.Dart := ⟨(A.nb p.1.1 p.1.2, A.ix p.1.1 p.1.2), A.ix_lt _ _ p.2⟩

theorem nbD_nbD (p : A.Dart) : A.nbD (A.nbD p) = p := by
  apply Subtype.ext
  apply Prod.ext
  · exact A.nb_ix _ _ p.2
  · show A.ix (A.nb p.1.1 p.1.2) (A.ix p.1.1 p.1.2) = p.1.2
    have h1 : A.nb (A.nb p.1.1 p.1.2) (A.ix p.1.1 p.1.2) = p.1.1 := A.nb_ix _ _ p.2
    have h2 := A.nb_ix (A.nb p.1.1 p.1.2) (A.ix p.1.1 p.1.2) (A.ix_lt _ _ p.2)
    rw [h1] at h2
    have h3 := A.ix_lt (A.nb p.1.1 p.1.2) (A.ix p.1.1 p.1.2) (A.ix_lt _ _ p.2)
    rw [h1] at h3
    exact A.inj _ _ _ h3 p.2 h2

/-- The rotation of a dart around its tail. -/
def rotD (p : A.Dart) : A.Dart := ⟨(p.1.1, (p.1.2 + 1) % A.deg p.1.1), Nat.mod_lt _ (A.deg_pos _)⟩
def rotDInv (p : A.Dart) : A.Dart :=
  ⟨(p.1.1, (p.1.2 + A.deg p.1.1 - 1) % A.deg p.1.1), Nat.mod_lt _ (A.deg_pos _)⟩

/-- The combinatorial map of a table. -/
def T : CMap A.Dart where
  σ :=
    { toFun := A.rotD
      invFun := A.rotDInv
      left_inv := fun p => by
        apply Subtype.ext
        apply Prod.ext
        · rfl
        · exact mod_add_one_sub p.2
      right_inv := fun p => by
        apply Subtype.ext
        apply Prod.ext
        · rfl
        · exact mod_sub_one_add p.2 }
  α := Function.Involutive.toPerm A.nbD A.nbD_nbD
  α_invol := A.nbD_nbD
  α_ne := fun p h => A.irr _ _ p.2 (congrArg (fun q => q.1.1) h)

@[simp] theorem T_σ_fst (p : A.Dart) : (A.T.σ p).1.1 = p.1.1 := rfl
@[simp] theorem T_α_fst (p : A.Dart) : (A.T.α p).1.1 = A.nb p.1.1 p.1.2 := rfl
theorem T_α_snd (p : A.Dart) : (A.T.α p).1.2 = A.ix p.1.1 p.1.2 := rfl
theorem T_σ_snd (p : A.Dart) : (A.T.σ p).1.2 = (p.1.2 + 1) % A.deg p.1.1 := rfl

theorem σ_pow (a : ℕ) (p : A.Dart) :
    ((A.T.σ ^ a) p).1 = (p.1.1, (p.1.2 + a) % A.deg p.1.1) := by
  induction a with
  | zero =>
    apply Prod.ext
    · rfl
    · show p.1.2 = (p.1.2 + 0) % A.deg p.1.1
      rw [Nat.add_zero, Nat.mod_eq_of_lt p.2]
  | succ a ih =>
    apply Prod.ext
    · rw [pow_succ', Perm.mul_apply]
      show ((A.T.σ ^ a) p).1.1 = _
      rw [ih]
    · rw [pow_succ', Perm.mul_apply]
      show ((((A.T.σ ^ a) p).1.2 + 1) % A.deg ((A.T.σ ^ a) p).1.1) = _
      rw [ih]
      show ((p.1.2 + a) % A.deg p.1.1 + 1) % A.deg p.1.1 = (p.1.2 + (a + 1)) % A.deg p.1.1
      rw [Nat.mod_add_mod, Nat.add_assoc]

theorem tail_eq_iff {p q : A.Dart} : A.T.tail p = A.T.tail q ↔ p.1.1 = q.1.1 := by
  constructor
  · intro h
    exact Orb.eq_of_mk_eq (fun d : A.Dart => d.1.1) (fun d => rfl) h
  · intro h
    refine Orb.mk_eq_iff.2 ?_
    refine ⟨((q.1.2 + A.deg p.1.1 - p.1.2 : ℕ) : ℤ), ?_⟩
    rw [zpow_natCast]
    apply Subtype.ext
    rw [σ_pow, show p.1.2 + (q.1.2 + A.deg p.1.1 - p.1.2) = q.1.2 + A.deg p.1.1 by
      have := p.2
      omega]
    apply Prod.ext
    · exact h
    · show (q.1.2 + A.deg p.1.1) % A.deg p.1.1 = q.1.2
      rw [Nat.add_mod_right, h, Nat.mod_eq_of_lt q.2]

/-- The vertex with index `u`. -/
def vtx (u : Fin n) : A.T.V := A.T.tail ⟨(u, 0), A.deg_pos u⟩

/-- Darts are the vertices of the table times indices: the vertices of the map are `Fin n`. -/
def vEquiv : A.T.V ≃ Fin n where
  toFun := Orb.lift (fun d : A.Dart => d.1.1) (fun d => rfl)
  invFun := A.vtx
  left_inv := fun v => by
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
    exact (A.tail_eq_iff.2 rfl)
  right_inv := fun u => rfl

theorem deg_vtx (u : Fin n) : A.T.deg (A.vtx u) = A.deg u := by
  unfold CMap.deg
  have h : univ.filter (fun d => A.T.tail d = A.vtx u) =
      univ.image (fun k : Fin (A.deg u) => (⟨(u, k.1), k.2⟩ : A.Dart)) := by
    ext d
    simp only [mem_filter, mem_univ, true_and, mem_image]
    constructor
    · intro h
      have hu : d.1.1 = u := A.tail_eq_iff.1 h
      refine ⟨⟨d.1.2, by have := d.2; rwa [hu] at this⟩, ?_⟩
      apply Subtype.ext
      apply Prod.ext
      · exact hu.symm
      · rfl
    · rintro ⟨k, rfl⟩
      exact A.tail_eq_iff.2 rfl
  rw [h, Finset.card_image_of_injective]
  · simp
  · intro a b hab
    have := congrArg (fun q : A.Dart => q.1.2) hab
    exact Fin.ext this

theorem numV_eq : A.T.numV = n := by
  unfold CMap.numV
  rw [Fintype.card_congr A.vEquiv, Fintype.card_fin]

theorem card_dart : Fintype.card A.Dart = ∑ u, A.deg u := by
  have e : A.Dart ≃ Σ u, Fin (A.deg u) :=
    { toFun := fun p => ⟨p.1.1, ⟨p.1.2, p.2⟩⟩
      invFun := fun x => ⟨(x.1, x.2.1), x.2.2⟩
      left_inv := fun p => rfl
      right_inv := fun x => rfl }
  rw [Fintype.card_congr e, Fintype.card_sigma]
  simp

theorem isTriangulation : A.T.IsTriangulation := by
  intro p
  constructor
  · apply Subtype.ext
    set u := p.1.1 with hu
    set k := p.1.2 with hk
    have hk' : k < A.deg u := p.2
    set v := A.nb u k with hv
    set j := A.ix u k with hj
    have hj' : j < A.deg v := A.ix_lt _ _ hk'
    have hφ1 : (A.T.φ p).1 = (v, (j + 1) % A.deg v) := rfl
    have hj1 : (j + 1) % A.deg v < A.deg v := Nat.mod_lt _ (A.deg_pos _)
    set j1 := (j + 1) % A.deg v with hj1def
    have hφ2 : (A.T.φ (A.T.φ p)).1 =
        (A.nb v j1, (A.ix v j1 + 1) % A.deg (A.nb v j1)) := by
      show ((A.T.σ (A.T.α (A.T.φ p))).1 : Fin n × ℕ) = _
      have e1 : (A.T.φ p).1.1 = v := rfl
      have e2 : (A.T.φ p).1.2 = j1 := rfl
      show (A.nb (A.T.φ p).1.1 (A.T.φ p).1.2,
        (A.ix (A.T.φ p).1.1 (A.T.φ p).1.2 + 1) % A.deg (A.nb (A.T.φ p).1.1 (A.T.φ p).1.2)) = _
      rw [e1, e2]
    have htri1 := A.tri u k hk'
    set w := A.nb v j1 with hw
    have hw' : w = A.nb u ((k + A.deg u - 1) % A.deg u) := htri1
    have hpk : (k + A.deg u - 1) % A.deg u < A.deg u := Nat.mod_lt _ (A.deg_pos _)
    have hj2 : (A.ix v j1 + 1) % A.deg w < A.deg w := Nat.mod_lt _ (A.deg_pos _)
    set j2 := (A.ix v j1 + 1) % A.deg w with hj2def
    have htri2 := A.tri v j1 hj1
    rw [← hw] at htri2
    have htri3 : A.nb w j2 = u := by
      rw [show A.nb w j2 = A.nb v ((j1 + A.deg v - 1) % A.deg v) from htri2, hj1def,
        mod_add_one_sub hj', hj]
      exact A.nb_ix _ _ hk'
    have hix : A.ix w j2 = (k + A.deg u - 1) % A.deg u := by
      have h1 := A.nb_ix w j2 hj2
      rw [htri3] at h1
      have h2 := A.ix_lt w j2 hj2
      rw [htri3] at h2
      exact A.inj u _ _ h2 hpk (h1.trans hw')
    show (A.T.φ (A.T.φ (A.T.φ p))).1 = p.1
    have e1 : (A.T.φ (A.T.φ p)).1.1 = w := congrArg Prod.fst hφ2
    have e2 : (A.T.φ (A.T.φ p)).1.2 = j2 := congrArg Prod.snd hφ2
    show (A.nb (A.T.φ (A.T.φ p)).1.1 (A.T.φ (A.T.φ p)).1.2,
      (A.ix (A.T.φ (A.T.φ p)).1.1 (A.T.φ (A.T.φ p)).1.2 + 1) %
        A.deg (A.nb (A.T.φ (A.T.φ p)).1.1 (A.T.φ (A.T.φ p)).1.2)) = _
    rw [e1, e2, htri3, hix]
    apply Prod.ext
    · rfl
    · show ((k + A.deg u - 1) % A.deg u + 1) % A.deg u = k
      exact mod_sub_one_add hk'
  · intro h
    apply A.irr _ _ p.2
    exact congrArg (fun q : A.Dart => q.1.1) h

theorem isSimple : A.T.IsSimple := by
  refine ⟨fun p h => A.irr _ _ p.2 (A.tail_eq_iff.1 h).symm, fun p q h1 h2 => ?_⟩
  have hu : p.1.1 = q.1.1 := A.tail_eq_iff.1 h1
  have hv : A.nb p.1.1 p.1.2 = A.nb q.1.1 q.1.2 := A.tail_eq_iff.1 h2
  obtain ⟨⟨u, k⟩, hk⟩ := p
  obtain ⟨⟨v, l⟩, hl⟩ := q
  simp only at hu hv hk hl
  subst hu
  have := A.inj u k l hk hl hv
  subst this
  rfl

/-- Connectivity of a table given a descending function. -/
theorem connected (hn : 0 < n) (f : Fin n → ℕ)
    (h0 : ∀ u v, f u = 0 → f v = 0 → u = v)
    (hstep : ∀ u, f u ≠ 0 → ∃ k, ∃ _ : k < A.deg u, f (A.nb u k) < f u) : A.T.Connected := by
  set u0 : Fin n := ⟨0, hn⟩
  let G := Subgroup.closure ({A.T.σ, A.T.α} : Set (Perm A.Dart))
  have hσG : A.T.σ ∈ G := Subgroup.subset_closure (by simp)
  have hαG : A.T.α ∈ G := Subgroup.subset_closure (by simp)
  have hrot : ∀ (p q : A.Dart), p.1.1 = q.1.1 → ∃ g ∈ G, g p = q := by
    intro p q h
    have hsc : A.T.tail p = A.T.tail q := A.tail_eq_iff.2 h
    obtain ⟨i, hi⟩ := Orb.mk_eq_iff.1 hsc
    exact ⟨A.T.σ ^ i, Subgroup.zpow_mem _ hσG i, hi⟩
  have hmin : ∃ u, f u = 0 := by
    by_contra hne
    push Not at hne
    let m := Nat.find (⟨f u0, u0, rfl⟩ : ∃ a, ∃ u, f u = a)
    obtain ⟨u, hu⟩ := Nat.find_spec (⟨f u0, u0, rfl⟩ : ∃ a, ∃ u, f u = a)
    obtain ⟨k, _, hk⟩ := hstep u (hne u)
    rw [hu] at hk
    exact Nat.find_min (⟨f u0, u0, rfl⟩ : ∃ a, ∃ u, f u = a) hk ⟨_, rfl⟩
  obtain ⟨c, hc⟩ := hmin
  let q0 : A.Dart := ⟨(c, 0), A.deg_pos c⟩
  have key : ∀ (m : ℕ) (u : Fin n), f u = m → ∀ p : A.Dart, p.1.1 = u → ∃ g ∈ G, g p = q0 := by
    intro m
    induction m using Nat.strong_induction_on with
    | _ m ih =>
      intro u hu p hp
      by_cases h : f u = 0
      · have huc : u = c := h0 u c h hc
        exact hrot p q0 (hp.trans huc)
      · obtain ⟨k, hk, hlt⟩ := hstep u h
        have p1 : ∃ g ∈ G, g p = (⟨(u, k), hk⟩ : A.Dart) := hrot p _ hp
        obtain ⟨g1, hg1, h1⟩ := p1
        obtain ⟨g2, hg2, h2⟩ := ih (f (A.nb u k)) (hu ▸ hlt) (A.nb u k) rfl
          (A.T.α ⟨(u, k), hk⟩) rfl
        refine ⟨g2 * (A.T.α * g1), Subgroup.mul_mem _ hg2 (Subgroup.mul_mem _ hαG hg1), ?_⟩
        rw [Perm.mul_apply, Perm.mul_apply, h1, h2]
  refine ⟨⟨q0⟩, fun x y => ?_⟩
  obtain ⟨g1, hg1, h1⟩ := key _ x.1.1 rfl x rfl
  obtain ⟨g2, hg2, h2⟩ := key _ y.1.1 rfl y rfl
  refine ⟨g2⁻¹ * g1, Subgroup.mul_mem _ (Subgroup.inv_mem _ hg2) hg1, ?_⟩
  rw [Perm.mul_apply, h1, ← h2]
  simp

/-- Genus zero from total curvature `12`. -/
theorem genus0 (hsum : ∑ u, (6 - (A.deg u : ℤ)) = 12) : A.T.Genus0 := by
  have hT := A.isTriangulation
  have hF : Fintype.card A.Dart = 3 * A.T.numF := by
    have h := hT.corners_card (univ : Finset A.T.F)
    simpa [CMap.numF] using h
  have hE : Fintype.card A.Dart = 2 * A.T.numE := by
    have h := count_fiber (D := A.Dart) A.T.edge (fun _ => True)
    have h1 : ∀ e : A.T.E, (univ.filter (fun d => A.T.edge d = e ∧ True)).card = 2 := by
      intro e
      obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
      have := CMap.card_edge_and A.T (fun _ => True) d
      show (univ.filter (fun x => A.T.edge x = A.T.edge d ∧ True)).card = 2
      simpa using this
    simp only [h1] at h
    simpa [CMap.numE, mul_comm] using h
  have hV := A.numV_eq
  have hD := A.card_dart
  have hsum' : (6 * n : ℤ) - ∑ u, (A.deg u : ℤ) = 12 := by
    rw [← hsum, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin]
    simp only [nsmul_eq_mul]
    ring
  rw [← Nat.cast_sum, ← hD] at hsum'
  unfold CMap.Genus0
  have hsum'' : ((6 * n : ℕ) : ℤ) = (Fintype.card A.Dart : ℤ) + 12 := by
    push_cast
    linarith
  omega

end Table

namespace CMap

variable {D : Type*} [Fintype D] [DecidableEq D] {T : CMap D}

/-- The dual of a simple triangulation with vertex degrees at least three is simple. -/
theorem dual_simple_of (hT : T.IsTriangulation) (hs : T.IsSimple) (hd : ∀ v, 3 ≤ T.deg v) :
    T.dual.IsSimple := by
  have hface : ∀ {x y : D}, T.dual.tail x = T.dual.tail y → T.face x = T.face y := fun h => h
  refine ⟨fun d hd2 => ?_, fun d d' h1 h2 => ?_⟩
  · have hf : T.face d = T.face (T.α d) := hface hd2
    rcases hT.face_eq_iff.1 hf.symm with h | h | h
    · exact T.α_ne d h
    · have e := T.φ d
      apply hs.1 (T.φ (T.φ d))
      have h1 : T.tail (T.φ (T.φ d)) = T.tail d := by
        rw [T.tail_φ, ← h]
        rw [T.α_α]
      have h3 := (hT d).1
      have h2 : T.tail (T.α (T.φ (T.φ d))) = T.tail d := by
        rw [← T.tail_φ, h3]
      rw [h1, h2]
    · apply hs.1 (T.φ d)
      have h1 : T.tail (T.φ d) = T.tail (T.α d) := T.tail_φ d
      have h2 : T.tail (T.α (T.φ d)) = T.tail (T.α d) := by
        rw [← T.tail_φ, ← h]
      rw [h1, h2]
  · have hf1 : T.face d = T.face d' := hface h1
    have hf2 : T.face (T.α d) = T.face (T.α d') := hface h2
    by_contra hne
    have key : ∀ {x y : D}, T.φ x = y → x ≠ y → T.face (T.α x) = T.face (T.α y) → False := by
      intro x y hxy hne' hfa
      rcases hT.face_eq_iff.1 hfa.symm with h | h | h
      · exact hne' (T.α.injective h).symm
      · have hτ : T.σ x = T.α y := by
          rw [h, T.φ_apply, T.α_α]
        apply hne'
        have h3 : T.tail x = T.tail (T.α y) := by
          rw [← hτ, T.tail_σ]
        have h4 : T.tail (T.α x) = T.tail (T.α (T.α y)) := by
          rw [T.α_α, ← hxy, T.tail_φ]
        have h5 : x = T.α y := hs.2 _ _ h3 h4
        exfalso
        have h6 : T.σ (T.α x) = T.α x := by
          have h7 : T.α x = y := by rw [h5, T.α_α]
          show T.φ x = T.α x
          rw [hxy, h7]
        have h8 : (T.σ ^ 1) (T.α x) = T.α x := by rw [pow_one]; exact h6
        have h9 := (pow_eq_self_iff_of_deg (M := T) (x := T.α x) rfl
          (by have := hd (T.tail (T.α x)); omega) 1).1 h8
        have h10 := hd (T.tail (T.α x))
        have := Nat.le_of_dvd one_pos h9
        omega
      · have hτ : T.σ y = T.α x := by
          have h3 : T.φ (T.α y) = T.α x := by
            rw [h]
            exact (hT (T.α x)).1
          rw [T.φ_apply, T.α_α] at h3
          exact h3
        have hτ2 : T.σ (T.α x) = y := hxy
        have h5 : (T.σ ^ 2) y = y := by
          rw [pow_two, Perm.mul_apply, hτ, hτ2]
        have h9 := (pow_eq_self_iff_of_deg (M := T) (x := y) rfl
          (by have := hd (T.tail y); omega) 2).1 h5
        have h10 := hd (T.tail y)
        have := Nat.le_of_dvd (by norm_num) h9
        omega
    rcases hT.face_eq_iff.1 hf1.symm with h | h | h
    · exact hne h.symm
    · exact key h.symm hne hf2
    · have h3 : T.φ d' = d := by
        rw [h]
        exact (hT d).1
      exact key h3 (Ne.symm hne) hf2.symm

end CMap

namespace Table

variable {n : ℕ} (A : Table n)

/-- The dual of the map of a table with degrees 5 and 6 and total curvature 12 is a fullerene map. -/
theorem dual_isFullerene (hdeg : ∀ u, A.deg u = 5 ∨ A.deg u = 6) (hcon : A.T.Connected)
    (hsum : ∑ u, (6 - (A.deg u : ℤ)) = 12) : A.T.dual.IsFullerene := by
  have hT := A.isTriangulation
  have hg := A.genus0 hsum
  have hdT : ∀ v : A.T.V, 3 ≤ A.T.deg v := fun v => by
    rw [← A.vEquiv.symm_apply_apply v]
    show 3 ≤ A.T.deg (A.vtx _)
    rw [A.deg_vtx]
    rcases hdeg (A.vEquiv v) with h | h <;> omega
  refine ⟨hcon.dual, hg.dual, CMap.dual_simple_of hT A.isSimple hdT, ?_, ?_⟩
  · intro v
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
    have h : univ.filter (fun x => A.T.dual.tail x = Orb.mk A.T.dual.σ d) =
        {d, A.T.φ d, A.T.φ (A.T.φ d)} := by
      ext x
      simp only [mem_filter, mem_univ, true_and, mem_insert, mem_singleton]
      exact hT.face_eq_iff
    show (univ.filter (fun x => A.T.dual.tail x = Orb.mk A.T.dual.σ d)).card = 3
    rw [h]
    rw [Finset.card_insert_of_notMem, Finset.card_insert_of_notMem, Finset.card_singleton]
    · simp only [mem_singleton]
      exact hT.ne3 d |>.symm
    · simp only [mem_insert, mem_singleton, not_or]
      exact ⟨fun h1 => hT.ne1 d h1.symm, fun h1 => hT.ne2 d h1.symm⟩
  · intro f
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    show (univ.filter (fun x => A.T.dual.face x = A.T.dual.face d)).card = 5 ∨
      (univ.filter (fun x => A.T.dual.face x = A.T.dual.face d)).card = 6
    have h : univ.filter (fun x => A.T.dual.face x = A.T.dual.face d) =
        univ.filter (fun x => A.T.tail x = A.T.tail d) := by
      ext x
      simp only [mem_filter, mem_univ, true_and]
      show Orb.mk A.T.dual.φ x = Orb.mk A.T.dual.φ d ↔ Orb.mk A.T.σ x = Orb.mk A.T.σ d
      rw [Orb.mk_eq_iff, Orb.mk_eq_iff, A.T.dual_φ]
    rw [h]
    have hdv := A.deg_vtx d.1.1
    have heq : A.vtx d.1.1 = A.T.tail d := by
      show A.T.tail (⟨(d.1.1, 0), A.deg_pos _⟩ : A.Dart) = A.T.tail d
      exact A.tail_eq_iff.2 rfl
    show A.T.deg (A.T.tail d) = 5 ∨ A.T.deg (A.T.tail d) = 6
    rw [← heq, hdv]
    exact hdeg _

end Table

end Ful

end
