/-
FulTransfer2: the transfer to the hexagonal lattice ball.
-/
import FulTransfer

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt CMap
open scoped Classical

universe u

variable {D : Type*} [Fintype D] [DecidableEq D] {T : CMap D} {d0 : D} {R : ℕ}
variable {V : Type u} [Fintype V] {G : SimpleGraph V} {τ : D → V}

/-- The map from the hexagonal lattice to the fullerene. -/
def Psi (T : CMap D) (d0 : D) (τ : D → V) (a : ℤ × ℤ × Bool) : V :=
  τ (T.psi d0 (pLat a) (uOf a.2.2))

theorem three_nbrs {v a b c w : V} (hc : Nat.card (G.neighborSet v) = 3) (ha : G.Adj v a)
    (hb : G.Adj v b) (hcc : G.Adj v c) (hab : a ≠ b) (hbc : b ≠ c) (hac : a ≠ c)
    (hw : G.Adj v w) : w = a ∨ w = b ∨ w = c := by
  have hcard : (G.neighborFinset v).card = 3 := by
    rw [Nat.card_eq_fintype_card] at hc
    rw [← hc]
    exact Set.toFinset_card _
  have hsub : ({a, b, c} : Finset V) ⊆ G.neighborFinset v := by
    intro x hx
    simp only [mem_insert, mem_singleton] at hx
    rcases hx with rfl | rfl | rfl <;> simpa
  have hc3 : ({a, b, c} : Finset V).card = 3 := by
    rw [Finset.card_insert_of_notMem (by simp [hab, hac]), Finset.card_insert_of_notMem (by simp [hbc]),
      Finset.card_singleton]
  have heq := Finset.eq_of_subset_of_card_le hsub (by omega)
  have hmem : w ∈ ({a, b, c} : Finset V) := by
    rw [heq]
    simpa using hw
  simpa only [mem_insert, mem_singleton] using hmem

theorem Psi_adj (hT : T.IsTriangulation) (hF : T.FlatTo (T.tail d0) R)
    (hface : ∀ x y, T.face x = T.face y ↔ τ x = τ y) (hadj : ∀ d, G.Adj (τ d) (τ (T.α d)))
    {a b : ℤ × ℤ × Bool} (ha : L1 (pLat a) + 20 ≤ R) (hb : L1 (pLat b) + 20 ≤ R)
    (hab : hexLattice.Adj a b) : G.Adj (Psi T d0 τ a) (Psi T d0 τ b) := by
  obtain ⟨x, y, c⟩ := a
  obtain ⟨x', y', c'⟩ := b
  rw [hex_adj_iff] at hab
  simp only at hab
  rcases hab with ⟨h1, h2, h3⟩ | ⟨h1, h2, h3⟩
  · subst h1; subst h2
    exact Psi_ft hT hF hface hadj (by simpa [pLat] using ha) h3
  · subst h1; subst h2
    have h4 : (x = x' ∧ y = y') ∨ (x = x' ∧ y = y' - 1) ∨ (x = x' + 1 ∧ y = y' - 1) := by omega
    have := Psi_ft (x := x') (y := y') (x' := x) (y' := y) hT hF hface hadj (by simpa [pLat] using hb) h4
    exact this.symm

theorem uOf_cases (c : Bool) : uOf c = 1 ∨ uOf c = 2 := by
  cases c <;> simp [uOf]

theorem uOf_inj {c c' : Bool} (h : uOf c = uOf c') : c = c' := by
  cases c <;> cases c' <;> simp_all [uOf]

/-- Injectivity on a ball. -/
theorem Psi_inj (hT : T.IsTriangulation) (hF : T.FlatTo (T.tail d0) R)
    (hface : ∀ x y, T.face x = T.face y ↔ τ x = τ y)
    (k : ℕ) (hinjZ : ∀ z w, LReach (k + 2) z → LReach (k + 2) w →
      T.tail (T.dev d0 z.1 z.2) = T.tail (T.dev d0 w.1 w.2) → z = w)
    (hk : 2 * (k + 2) + 20 ≤ R) {a b : ℤ × ℤ × Bool} (ha : LReach k (pLat a)) (hb : LReach k (pLat b))
    (hab : Psi T d0 τ a = Psi T d0 τ b) : a = b := by
  have hLa := ha.L1_le
  have hLb := hb.L1_le
  have hfeq : T.face (T.psi d0 (pLat b) (uOf b.2.2)) = T.face (T.psi d0 (pLat a) (uOf a.2.2)) :=
    (hface _ _).2 hab.symm
  rcases hT.face_eq_iff.1 hfeq with h1 | h1 | h1
  · -- same dart
    have ht : T.tail (T.dev d0 (pLat b).1 (pLat b).2) = T.tail (T.dev d0 (pLat a).1 (pLat a).2) := by
      have h2 := congrArg T.tail h1
      rw [tail_psi, tail_psi] at h2
      exact h2
    have hz := hinjZ _ _ (lreach_mono (by omega) hb) (lreach_mono (by omega) ha) ht
    rw [hz] at h1
    have hmod := psi_inj_mod hF (by omega) h1
    have hu : uOf b.2.2 = uOf a.2.2 := by
      rcases uOf_cases b.2.2 with h3 | h3 <;> rcases uOf_cases a.2.2 with h4 | h4 <;>
        rw [h3, h4] at hmod ⊢ <;> simp_all
    have hc := uOf_inj hu
    have h5 : pLat b = pLat a := hz
    simp only [pLat, Prod.mk.injEq, neg_inj] at h5
    obtain ⟨xa, ya, ca⟩ := a
    obtain ⟨xb, yb, cb⟩ := b
    simp only at h5 hc
    obtain ⟨rfl, rfl⟩ := h5
    subst hc
    rfl
  · -- one rotation of the face
    exfalso
    have hu := uOf_cases a.2.2
    set P := pLat a with hP
    set Q := pLat b with hQ
    have hφ := φ_psi hT hF (z := P) (uOf a.2.2) (by omega)
    rw [hφ] at h1
    have huP : LReach (k + 1) (P.1 + ex (uOf a.2.2), P.2 + ey (uOf a.2.2)) := by
      have h3 : uOf a.2.2 < 6 := by rcases hu with h4 | h4 <;> omega
      exact LReach.step _ h3 ha
    have ht : T.tail (T.dev d0 Q.1 Q.2) =
        T.tail (T.dev d0 (P.1 + ex (uOf a.2.2)) (P.2 + ey (uOf a.2.2))) := by
      have h2 := congrArg T.tail h1
      rw [tail_psi, tail_psi] at h2
      exact h2
    have hz := hinjZ _ _ (lreach_mono (by omega) hb) (lreach_mono (by omega) huP) ht
    rw [hz] at h1
    have hmod := psi_inj_mod hF (z := (P.1 + ex (uOf a.2.2), P.2 + ey (uOf a.2.2))) (by
      have := L1_add P (uOf a.2.2); omega) h1
    rcases uOf_cases b.2.2 with h3 | h3 <;> rcases hu with h4 | h4 <;> rw [h3, h4] at hmod <;> omega
  · -- two rotations of the face
    exfalso
    have hu := uOf_cases a.2.2
    set P := pLat a with hP
    set Q := pLat b with hQ
    have hL1 : L1 (P.1 + ex (uOf a.2.2), P.2 + ey (uOf a.2.2)) + 8 ≤ R := by
      have := L1_add P (uOf a.2.2); omega
    have hφ := φ_psi hT hF (z := P) (uOf a.2.2) (by omega)
    have hφ2 := φ_psi hT hF (z := (P.1 + ex (uOf a.2.2), P.2 + ey (uOf a.2.2))) (uOf a.2.2 + 4) hL1
    rw [hφ, hφ2] at h1
    have huP : LReach (k + 2)
        ((P.1 + ex (uOf a.2.2)) + ex (uOf a.2.2 + 4), (P.2 + ey (uOf a.2.2)) + ey (uOf a.2.2 + 4)) := by
      have h3 : uOf a.2.2 < 6 := by rcases hu with h4 | h4 <;> omega
      have h4 : (uOf a.2.2 + 4) % 6 < 6 := Nat.mod_lt _ (by norm_num)
      have h5 := LReach.step ((uOf a.2.2 + 4) % 6) h4 (LReach.step _ h3 ha)
      have e1 : ex ((uOf a.2.2 + 4) % 6) = ex (uOf a.2.2 + 4) := by simp [ex]
      have e2 : ey ((uOf a.2.2 + 4) % 6) = ey (uOf a.2.2 + 4) := by simp [ey]
      rwa [e1, e2] at h5
    have ht : T.tail (T.dev d0 Q.1 Q.2) = T.tail (T.dev d0
        ((P.1 + ex (uOf a.2.2)) + ex (uOf a.2.2 + 4)) ((P.2 + ey (uOf a.2.2)) + ey (uOf a.2.2 + 4))) := by
      have h2 := congrArg T.tail h1
      rw [tail_psi, tail_psi] at h2
      exact h2
    have hz := hinjZ _ _ (lreach_mono (by omega) hb) huP ht
    rw [hz] at h1
    have hmod := psi_inj_mod hF (by
      have := L1_add (P.1 + ex (uOf a.2.2), P.2 + ey (uOf a.2.2)) (uOf a.2.2 + 4)
      simp only at this
      omega) h1
    rcases uOf_cases b.2.2 with h3 | h3 <;> rcases hu with h4 | h4 <;> rw [h3, h4] at hmod <;> omega

/-- The transfer theorem. -/
theorem transfer_ball (hT : T.IsTriangulation) (hF : T.FlatTo (T.tail d0) R)
    (hface : ∀ x y, T.face x = T.face y ↔ τ x = τ y) (hadj : ∀ d, G.Adj (τ d) (τ (T.α d)))
    (hc3 : ∀ v, Nat.card (G.neighborSet v) = 3) (r : ℕ)
    (hinjZ : ∀ z w, LReach (r + 3) z → LReach (r + 3) w →
      T.tail (T.dev d0 z.1 z.2) = T.tail (T.dev d0 w.1 w.2) → z = w)
    (hR : 2 * (r + 3) + 20 ≤ R) :
    RootedBallIso G (τ (T.psi d0 (0, 0) 1)) hexLattice hexRoot r := by
  have hroot : Psi T d0 τ hexRoot = τ (T.psi d0 (0, 0) 1) := by
    simp [Psi, pLat, hexRoot, uOf]
  rw [← hroot]
  apply rootedBallIso_of_local (Psi T d0 τ) hexRoot r
  · intro a b ha hb hab
    have h1 := (lreach_ball ha).L1_le
    have h2 := (lreach_ball hb).L1_le
    exact Psi_adj hT hF hface hadj (by omega) (by omega) hab
  · intro a b ha hb hab
    exact Psi_inj hT hF hface (r + 1) hinjZ (by omega) (lreach_ball ha) (lreach_ball hb) hab
  · intro a ha w hw
    have hLa : LReach r (pLat a) := lreach_ball ha
    have hLa1 := hLa.L1_le
    -- the three neighbours of `a`
    have hmemN : ∀ b, hexLattice.Adj a b → b ∈ ballSet hexLattice hexRoot (r + 1) := by
      intro b hb
      obtain ⟨p, hp⟩ := mem_ballSet_iff.1 ha
      exact mem_ballSet_iff.2 ⟨p.concat hb, by rw [SimpleGraph.Walk.length_concat]; omega⟩
    have hPsiAdj : ∀ b, hexLattice.Adj a b → G.Adj (Psi T d0 τ a) (Psi T d0 τ b) := by
      intro b hb
      have h1 := (lreach_ball (hmemN b hb)).L1_le
      exact Psi_adj hT hF hface hadj (by omega) (by omega) hb
    have hinj2 : ∀ b1 b2, hexLattice.Adj a b1 → hexLattice.Adj a b2 → b1 ≠ b2 →
        Psi T d0 τ b1 ≠ Psi T d0 τ b2 := by
      intro b1 b2 hb1 hb2 hne heq
      exact hne (Psi_inj hT hF hface (r + 1) hinjZ (by omega) (lreach_ball (hmemN _ hb1))
        (lreach_ball (hmemN _ hb2)) heq)
    obtain ⟨x, y, c⟩ := a
    cases c
    · -- false: neighbours (x,y,true), (x,y-1,true), (x+1,y-1,true)
      have h1 : hexLattice.Adj (x, y, false) (x, y, true) := by
        rw [hex_adj_iff]; simp
      have h2 : hexLattice.Adj (x, y, false) (x, y - 1, true) := by
        rw [hex_adj_iff]; simp
      have h3 : hexLattice.Adj (x, y, false) (x + 1, y - 1, true) := by
        rw [hex_adj_iff]; simp
      have hd12 : ((x, y, true) : ℤ × ℤ × Bool) ≠ (x, y - 1, true) := by
        intro h; simp at h <;> omega
      have hd23 : ((x, y - 1, true) : ℤ × ℤ × Bool) ≠ (x + 1, y - 1, true) := by
        intro h; simp at h <;> omega
      have hd13 : ((x, y, true) : ℤ × ℤ × Bool) ≠ (x + 1, y - 1, true) := by
        intro h; simp at h <;> omega
      rcases three_nbrs (hc3 _) (hPsiAdj _ h1) (hPsiAdj _ h2) (hPsiAdj _ h3)
        (hinj2 _ _ h1 h2 hd12) (hinj2 _ _ h2 h3 hd23) (hinj2 _ _ h1 h3 hd13) hw with h | h | h
      · exact ⟨_, h1, h.symm⟩
      · exact ⟨_, h2, h.symm⟩
      · exact ⟨_, h3, h.symm⟩
    · -- true: neighbours (x,y,false), (x,y+1,false), (x-1,y+1,false)
      have h1 : hexLattice.Adj (x, y, true) (x, y, false) := by
        rw [hex_adj_iff]; simp
      have h2 : hexLattice.Adj (x, y, true) (x, y + 1, false) := by
        rw [hex_adj_iff]; simp
      have h3 : hexLattice.Adj (x, y, true) (x - 1, y + 1, false) := by
        rw [hex_adj_iff]; simp
      have hd12 : ((x, y, false) : ℤ × ℤ × Bool) ≠ (x, y + 1, false) := by
        intro h; simp at h <;> omega
      have hd23 : ((x, y + 1, false) : ℤ × ℤ × Bool) ≠ (x - 1, y + 1, false) := by
        intro h; simp at h <;> omega
      have hd13 : ((x, y, false) : ℤ × ℤ × Bool) ≠ (x - 1, y + 1, false) := by
        intro h; simp at h <;> omega
      rcases three_nbrs (hc3 _) (hPsiAdj _ h1) (hPsiAdj _ h2) (hPsiAdj _ h3)
        (hinj2 _ _ h1 h2 hd12) (hinj2 _ _ h2 h3 hd23) (hinj2 _ _ h1 h3 hd13) hw with h | h | h
      · exact ⟨_, h1, h.symm⟩
      · exact ⟨_, h2, h.symm⟩
      · exact ⟨_, h3, h.symm⟩

end Ful

end
