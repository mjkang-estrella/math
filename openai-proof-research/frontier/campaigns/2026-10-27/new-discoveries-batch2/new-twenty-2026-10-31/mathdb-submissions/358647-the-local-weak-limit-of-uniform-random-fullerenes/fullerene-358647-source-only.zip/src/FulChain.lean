/-
FulChain: iterate the peeling dichotomy from both ends of a shortest essential cycle, assemble a
capped tube, and bound the number of isomorphism classes of maps with a short essential cycle
independently of their size.
-/
import FulPeel

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- The facts carried at each level of a peeling chain. -/
structure Lev (M : CMap D) (ℓ : ℕ) (C : SimpleCycle M) (Q : Finset M.F) : Prop where
  len : C.len = ℓ
  ess : Essential C Q
  sh : IsShortest C
  orient : ∀ j, M.face (C.dart j) ∈ Q
  deg6 : ∀ k, M.deg (M.tail (C.dart k)) = 6

/-- The facts carried between two consecutive levels. -/
structure Stp (M : CMap D) (ℓ : ℕ) (C : SimpleCycle M) (Q : Finset M.F) (C' : SimpleCycle M)
    (Q' : Finset M.F) : Prop where
  K2 : ∀ j, 2 ≤ C.K j
  P_eq : C.P = 2 * ℓ
  ring : (Q.filter fun f => 1 ≤ C.t f).card = 2 * ℓ
  nest : Q' = Q.filter fun f => C.t f = 0
  tops : ∀ k, C'.dart k = C.topDart k

/-- Iterating the dichotomy until the remaining side is small. -/
theorem exists_chain (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hs : M.IsSimple)
    (hdeg : ∀ v, M.deg v ≤ 6) (ℓ : ℕ) :
    ∀ (n : ℕ) (C : SimpleCycle M) (Q : Finset M.F), Q.card = n → Lev M ℓ C Q →
      ∃ (H : ℕ) (Cs : ℕ → SimpleCycle M) (Qs : ℕ → Finset M.F),
        Cs 0 = C ∧ Qs 0 = Q ∧ (∀ i, i ≤ H → Lev M ℓ (Cs i) (Qs i)) ∧
        (∀ i, i < H → Stp M ℓ (Cs i) (Qs i) (Cs (i + 1)) (Qs (i + 1))) ∧
        (Qs H).card ≤ 2 * ℓ + bnd ℓ := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  intro C Q hn hL
  rcases peel hT hc hg hs hdeg hL.ess hL.sh hL.orient with hsmall | ⟨C', hlen, htops, hE', hor',
    hK2, hP, hring, hQ⟩
  · refine ⟨0, fun _ => C, fun _ => Q, rfl, rfl, ?_, ?_, ?_⟩
    · intro i _
      exact hL
    · intro i hi
      omega
    · show Q.card ≤ _
      rw [← hL.len]
      exact hsmall
  · have hposl : 0 < C.len := C.len_pos
    have hlt : (C.Y Q).card < n := by omega
    have hL' : Lev M ℓ C' (C.Y Q) :=
      { len := by rw [hlen]; exact hL.len
        ess := hE'
        sh := fun C'' S'' he => by rw [hlen]; exact hL.sh C'' S'' he
        orient := hor'
        deg6 := fun k => (hE'.split hT hg hdeg).2.2 _ (C'.tail_mem k) }
    obtain ⟨H, Cs, Qs, h0, h0', hLev, hStp, hend⟩ := ih _ hlt C' (C.Y Q) rfl hL'
    refine ⟨H + 1, fun i => Nat.casesOn i C Cs, fun i => Nat.casesOn i Q Qs, rfl, rfl, ?_, ?_, ?_⟩
    · intro i hi
      cases i with
      | zero => exact hL
      | succ i => exact hLev i (by omega)
    · intro i hi
      cases i with
      | zero =>
        show Stp M ℓ C Q (Cs 0) (Qs 0)
        rw [h0, h0']
        rw [← hL.len]
        exact ⟨hK2, hP, hring, rfl, htops⟩
      | succ i => exact hStp i (by omega)
    · exact hend

/-- A map with a short essential cycle is small or has a tube parameter. -/
theorem exists_par (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hs : M.IsSimple)
    (hdeg : ∀ v, M.deg v ≤ 6) {L : ℕ}
    (hex : ∃ (C : SimpleCycle M) (S : Finset M.F), Essential C S ∧ C.len ≤ L) :
    Fintype.card M.F ≤ 2 * (2 * L + bnd L) ∨ ∃ p : Par L (3 * (2 * L + bnd L)), M.HasPar p := by
  -- a shortest essential cycle
  have hexn : ∃ n, ∃ (C : SimpleCycle M) (S : Finset M.F), Essential C S ∧ C.len = n := by
    obtain ⟨C, S, h, -⟩ := hex
    exact ⟨C.len, C, S, h, rfl⟩
  obtain ⟨C0, S0, hE0, hlen0⟩ := Nat.find_spec hexn
  have hsh0 : IsShortest C0 := by
    intro C' S' h'
    rw [hlen0]
    exact Nat.find_min' hexn ⟨C', S', h', rfl⟩
  have hleL : C0.len ≤ L := by
    obtain ⟨C, S, h, hl⟩ := hex
    exact (hsh0 C S h).trans hl
  set ℓ := C0.len with hℓdef
  have hl3 : 3 ≤ ℓ := C0.len_ge_three hs
  have hlen2 : 2 ≤ C0.len := by omega
  -- orient into a side
  obtain ⟨Q0, hE1, hor1⟩ : ∃ Q0, Essential C0 Q0 ∧ ∀ j, M.face (C0.dart j) ∈ Q0 := by
    by_cases h0 : M.face (C0.dart 0) ∈ S0
    · exact ⟨S0, hE0, fun j => SimpleCycle.orient hlen2 hE0.1 h0 j⟩
    · exact ⟨S0ᶜ, hE0.compl, fun j => SimpleCycle.orient hlen2 hE0.compl.1 (mem_compl.2 h0) j⟩
  have mkLev : ∀ (C : SimpleCycle M) (Q : Finset M.F), C.len = ℓ → Essential C Q → IsShortest C →
      (∀ j, M.face (C.dart j) ∈ Q) → Lev M ℓ C Q := fun C Q hl hE hS hO =>
    ⟨hl, hE, hS, hO, fun k => (hE.split hT hg hdeg).2.2 _ (C.tail_mem k)⟩
  obtain ⟨H1, Cs1, Qs1, -, -, hLev1, -, hend1⟩ :=
    exists_chain hT hc hg hs hdeg ℓ _ C0 Q0 rfl (mkLev C0 Q0 rfl hE1 hsh0 hor1)
  have hL1 := hLev1 H1 le_rfl
  -- reverse the far cycle and peel towards the other end
  have hrevE : Essential (Cs1 H1).rev (Qs1 H1)ᶜ :=
    SimpleCycle.essential_of_edges_eq (Cs1 H1).rev_edges hL1.ess.compl
  have hrevO := (Cs1 H1).rev_orient hL1.ess.1 hL1.orient
  obtain ⟨H, Cs, Qs, hC0, hQ0, hLev, hStp, hend⟩ :=
    exists_chain hT hc hg hs hdeg ℓ _ (Cs1 H1).rev (Qs1 H1)ᶜ rfl
      (mkLev _ _ hL1.len hrevE hL1.sh hrevO)
  have hbL : 2 * ℓ + bnd ℓ ≤ 2 * L + bnd L := by
    have := bnd_mono hleL
    omega
  by_cases hH : H = 0
  · left
    subst hH
    rw [hQ0] at hend
    have hcard : (Qs1 H1).card + ((Qs1 H1)ᶜ).card = Fintype.card M.F := by
      rw [Finset.card_compl]
      have := Finset.card_le_univ (Qs1 H1)
      omega
    omega
  right
  have hHpos : 0 < H := Nat.pos_of_ne_zero hH
  let T : Tube M ℓ H :=
    { C := Cs
      Q := Qs
      hT := hT
      hℓ := by omega
      hH := hHpos
      len := fun i hi => (hLev i hi).len
      side := fun i hi => (hLev i hi).ess.1
      orient := fun i hi => (hLev i hi).orient
      K2 := fun i hi => (hStp i hi).K2
      P_eq := fun i hi => (hStp i hi).P_eq
      ring := fun i hi => (hStp i hi).ring
      nest := fun i hi => (hStp i hi).nest
      tops := fun i hi => (hStp i hi).tops
      deg6 := fun i hi => (hLev i hi).deg6 }
  have hbA : ∀ j, M.face (M.α ((T.C 0).dart j)) ∈ (T.Q 0)ᶜ := by
    intro j
    rw [mem_compl]
    intro hm
    exact (T.side 0 (Nat.zero_le _) _).1 ((T.C 0).edge_mem j)
      (iff_of_true (T.orient 0 (Nat.zero_le _) j) hm)
  obtain ⟨cA, ⟨chA⟩⟩ := exists_capChart M (T.Q 0)ᶜ (ℓ := ℓ) _ hbA
  obtain ⟨cB, ⟨chB⟩⟩ := exists_capChart M (T.Q H) (ℓ := ℓ) (fun j => (T.C H).dart j)
    (T.orient H le_rfl)
  have haN : (univ.filter (fun d => M.face d ∈ (T.Q 0)ᶜ)).card < 3 * (2 * L + bnd L) + 1 := by
    rw [hT.corners_card]
    have h1 : (T.Q 0)ᶜ = Qs1 H1 := by
      show (Qs 0)ᶜ = _
      rw [hQ0, compl_compl]
    rw [h1]
    omega
  have hbN : (univ.filter (fun d => M.face d ∈ T.Q H)).card < 3 * (2 * L + bnd L) + 1 := by
    rw [hT.corners_card]
    have : (T.Q H).card ≤ 2 * ℓ + bnd ℓ := hend
    omega
  have hK7 : ∀ j : Fin ℓ, (T.C 0).K j.val < 7 := by
    intro j
    have h1 := SimpleCycle.cornerAt_eq (T.hlen (Nat.zero_le _)) (T.side 0 (Nat.zero_le _))
      (T.orient 0 (Nat.zero_le _)) j.val
    have h2 : cornerAt (T.Q 0) (M.tail ((T.C 0).dart (j.val + 1))) ≤
        M.deg (M.tail ((T.C 0).dart (j.val + 1))) := by
      unfold cornerAt deg
      apply Finset.card_le_card
      intro d hd
      simp only [mem_filter, mem_univ, true_and] at hd ⊢
      exact hd.1
    have h3 := T.deg6 0 (Nat.zero_le _) (j.val + 1)
    omega
  refine ⟨⟨⟨ℓ, by omega⟩, ⟨_, haN⟩, ⟨_, hbN⟩, cA, cB, fun j => ⟨(T.C 0).K j.val, hK7 j⟩⟩,
    H, T, fun j => rfl, ⟨chA⟩, ⟨chB⟩⟩

end CMap

/-- **The number of isomorphism classes of triangulated spheres of degree at most six with an
essential cycle of length at most `L` is bounded independently of the number of darts.** -/
theorem count_short_essential {ι : Type*} [Fintype ι] {L : ℕ} (f : ι → CMap D)
    (hsize : 3 * (2 * (2 * L + bnd L)) < Fintype.card D)
    (hT : ∀ i, (f i).IsTriangulation) (hc : ∀ i, (f i).Connected) (hg : ∀ i, (f i).Genus0)
    (hs : ∀ i, (f i).IsSimple) (hdeg : ∀ i v, (f i).deg v ≤ 6)
    (hex : ∀ i, ∃ (C : CMap.SimpleCycle (f i)) (S : Finset (f i).F), CMap.Essential C S ∧ C.len ≤ L)
    (hinj : ∀ i j, Nonempty (MapIso (f i) (f j)) → i = j) :
    Fintype.card ι ≤ Fintype.card (Par L (3 * (2 * L + bnd L))) := by
  apply count_le_card_par f _ hinj
  intro i
  rcases CMap.exists_par (hT i) (hc i) (hg i) (hs i) (hdeg i) (hex i) with h | h
  · exfalso
    have h3 : Fintype.card D = 3 * Fintype.card (f i).F := by
      have h := (hT i).corners_card (univ : Finset (f i).F)
      simpa using h
    omega
  · exact h

end Ful

end
