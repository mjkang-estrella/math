/-
FulPeel: the peeling dichotomy.  A shortest essential cycle either bounds a small cap or is
followed by a clean ring whose top darts form a shortest essential cycle again.
-/
import FulTops

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D} {C : SimpleCycle M} {Q : Finset M.F}

/-- With no chord and an interior vertex, every first-return exponent is at least two. -/
theorem K_ge_two (hT : M.IsTriangulation) (hc : M.Connected) (hlen : 2 ≤ C.len) (h : IsSide C Q)
    (hor : ∀ j, M.face (C.dart j) ∈ Q) (hcf : ChordFree C Q) (hI : (C.intV Q).Nonempty) (j : ℕ) :
    2 ≤ C.K j := by
  by_contra hlt
  have h1 : C.K j = 1 := by have := C.K_pos j; omega
  have hn := C.next_eq hlen j
  rw [h1, pow_one] at hn
  have hφ : M.φ (C.dart j) = C.dart (j + 1) := hn
  have ht := hT.t_face C (C.dart j)
  have a1 : M.tail (C.dart j) ∈ C.verts := C.tail_mem j
  have a2 : M.tail (M.φ (C.dart j)) ∈ C.verts := by rw [hφ]; exact C.tail_mem _
  have a3 : M.tail (M.φ (M.φ (C.dart j))) ∈ C.verts := by
    rw [hφ, M.tail_φ, C.chain]
    exact C.tail_mem _
  rw [ite_eq_left a1, ite_eq_left a2, ite_eq_left a3] at ht
  have h2 := h.t_le_two hT hc hcf hI (hor j)
  omega

/-- A chord beyond a shortest essential cycle forces a small side. -/
theorem peel_chord (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hs : M.IsSimple)
    (hdeg : ∀ v, M.deg v ≤ 6) (hE : Essential C Q) (hsh : IsShortest C) (hcf : ¬ ChordFree C Q) :
    Q.card ≤ bnd C.len := by
  have h := hE.1
  unfold ChordFree at hcf
  push Not at hcf
  obtain ⟨x, hxS, t1, t2, hxe⟩ := hcf
  obtain ⟨C1, C2, S1, S2, hS1, hS2, hs1, hs2, hcard, hlen⟩ :=
    IsSide.chord_split hc hg h x hxe hxS t1 t2 (hs.1 x)
  have l1 := C1.len_ge_three hs
  have l2 := C2.len_ge_three hs
  have hb : ∀ (C' : SimpleCycle M) (S' : Finset M.F), IsSide C' S' → S' ⊆ Q → C'.len < C.len →
      C'.curv S' ≤ 5 := by
    intro C' S' hS' hsub hlt
    by_contra hn
    have h6 : 6 ≤ C'.curv S' := by omega
    have hcomp : C.curv Qᶜ ≤ C'.curv S'ᶜ :=
      curv_mono hdeg (intV_sub_of_subset (IsSide.compl C' hS') (IsSide.compl C h)
        (Finset.compl_subset_compl.2 hsub))
    have := hsh C' S' ⟨hS', h6, le_trans hE.2.2 hcomp⟩
    omega
  have b1 := bounded_disc hT hc hg hs hdeg _ C1 S1 rfl hS1 (hb C1 S1 hS1 hs1 (by omega))
  have b2 := bounded_disc hT hc hg hs hdeg _ C2 S2 rfl hS2 (hb C2 S2 hS2 hs2 (by omega))
  obtain ⟨a, ha⟩ := Nat.exists_eq_add_of_le (show 2 ≤ C1.len by omega)
  obtain ⟨b', hb'⟩ := Nat.exists_eq_add_of_le (show 2 ≤ C2.len by omega)
  have hlenC : C.len = 2 + a + b' := by omega
  rw [ha] at b1
  rw [hb'] at b2
  rw [hlenC]
  have := bnd_split a b'
  omega

/-- **The peeling dichotomy.** -/
theorem peel (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hs : M.IsSimple)
    (hdeg : ∀ v, M.deg v ≤ 6) (hE : Essential C Q) (hsh : IsShortest C)
    (hor : ∀ j, M.face (C.dart j) ∈ Q) :
    Q.card ≤ 2 * C.len + bnd C.len ∨
      ∃ C' : SimpleCycle M, C'.len = C.len ∧ (∀ k, C'.dart k = C.topDart k) ∧
        Essential C' (C.Y Q) ∧ (∀ j, M.face (C'.dart j) ∈ C.Y Q) ∧
        (∀ j, 2 ≤ C.K j) ∧ C.P = 2 * C.len ∧
        (Q.filter fun f => 1 ≤ C.t f).card = 2 * C.len ∧
        Q.card = (C.Y Q).card + 2 * C.len := by
  have h := hE.1
  obtain ⟨hk, hkc, hv6⟩ := hE.split hT hg hdeg
  have hl := C.len_ge_three hs
  have hlen : 2 ≤ C.len := by omega
  by_cases hcf : ChordFree C Q
  swap
  · left
    have := peel_chord hT hc hg hs hdeg hE hsh hcf
    omega
  have hI : (C.intV Q).Nonempty := by
    by_contra hne
    rw [Finset.not_nonempty_iff_eq_empty] at hne
    have h0 : C.curv Q = 0 := by
      unfold SimpleCycle.curv
      rw [hne, Finset.sum_empty]
    omega
  have hKK := K_ge_two hT hc hlen h hor hcf hI
  have hring := h.ring_identity hT hc hg hcf hI
  have hN2 := h.card_t_two hT hc hcf hI
  have hN1 : (Q.filter fun f => C.t f = 1).card = C.len := by
    rw [hk] at hring
    omega
  have hP : C.P = 2 * C.len := by
    have hsum := SimpleCycle.sum_K hlen h hor
    have hbc := h.boundary_corners hT hc hg
    rw [hk] at hbc
    have hb := blk_add_sum (K := C.K) (fun j => by have := hKK j; omega) C.len
    unfold SimpleCycle.P
    omega
  have hcard_ring : (Q.filter fun f => 1 ≤ C.t f).card = 2 * C.len := by
    have hsplit : (Q.filter fun f => 1 ≤ C.t f).card =
        (Q.filter fun f => C.t f = 1).card + (Q.filter fun f => C.t f = 2).card := by
      rw [Finset.card_filter, Finset.card_filter, Finset.card_filter, ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun f hf => ?_
      have hle := h.t_le_two hT hc hcf hI hf
      have h3 : C.t f = 0 ∨ C.t f = 1 ∨ C.t f = 2 := by omega
      rcases h3 with h3 | h3 | h3 <;> simp [h3]
    omega
  have hQ : Q.card = (C.Y Q).card + 2 * C.len := by
    have hsplit : (C.Y Q).card + (Q.filter fun f => 1 ≤ C.t f).card = Q.card := by
      unfold SimpleCycle.Y
      rw [Finset.card_filter, Finset.card_filter, ← Finset.sum_add_distrib, Finset.card_eq_sum_ones]
      refine Finset.sum_congr rfl fun f _ => ?_
      by_cases h0 : C.t f = 0
      · simp [h0]
      · have h1 : 1 ≤ C.t f := by omega
        simp [h0, h1]
    omega
  have hbdY := card_bd_Y_le hT hc h
  by_cases hall : ∀ f0 ∈ C.Y Q, (comp (C.Y Q) f0).card ≤ bnd (bd (comp (C.Y Q) f0)).card
  · left
    have hYb := block_induct hall (C.Y Q) (Finset.Subset.refl _) (fun g _ g' ha => ha.2.1)
    have hmono := bnd_mono (show (bd (C.Y Q)).card ≤ C.len by omega)
    omega
  push Not at hall
  obtain ⟨f0, hf0, hgt⟩ := hall
  right
  set Y := C.Y Q with hY
  set X := comp Y f0 with hX
  have hXY : X ⊆ Y := comp_subset hf0
  have hYS : Y ⊆ Q := filter_subset _ _
  obtain ⟨f1, hf1⟩ := (IsSide.exists_mem C h).2
  have hcne : Xᶜ.Nonempty := ⟨f1, mem_compl.2 fun hn => mem_compl.1 hf1 (hYS (hXY hn))⟩
  have hcompl_strong : StrongConn Xᶜ := comp_compl_strong hc h hf0
  obtain ⟨Γ, hΓ⟩ := exists_cycle_of_strong hc hg ⟨f0, self_mem_comp _ _⟩ hcne
    (comp_strong _ _) hcompl_strong
  have hΓlen : Γ.len = (bd X).card := by rw [← hΓ.edges_eq_bd, Γ.card_edges]
  have h6 : 6 ≤ Γ.curv X := by
    by_contra hn
    have hb := bounded_disc hT hc hg hs hdeg _ Γ X rfl hΓ (by omega)
    rw [hΓlen] at hb
    omega
  have hcompc : C.curv Qᶜ ≤ Γ.curv Xᶜ :=
    curv_mono hdeg (intV_sub_of_subset (IsSide.compl Γ hΓ) (IsSide.compl C h)
      (Finset.compl_subset_compl.2 (hXY.trans hYS)))
  have hEΓ : Essential Γ X := ⟨hΓ, h6, le_trans hE.2.2 hcompc⟩
  have hge := hsh Γ X hEΓ
  have hbdsub : bd X ⊆ bd Y := by
    intro e he
    obtain ⟨d, rfl, h1, h2⟩ := mem_bd.1 he
    refine mem_bd.2 ⟨d, rfl, hXY h1, fun h3 => h2 ?_⟩
    exact comp_closed h1 ⟨hXY h1, h3, d, rfl, rfl⟩
  have hbdcard : (bd Y).card = C.len := by
    have h1 := Finset.card_le_card hbdsub
    omega
  have hbdeq : bd X = bd Y := Finset.eq_of_subset_of_card_le hbdsub (by omega)
  have hXeqY : X = Y := by
    apply Finset.Subset.antisymm hXY
    intro g hg
    by_contra hgX
    let x : M.F → F2 := fun g => if g ∈ Y ∧ g ∉ X then 1 else 0
    have hx : ∀ d, M.face d ∈ Xᶜ → M.face (M.α d) ∈ Xᶜ → x (M.face d) = x (M.face (M.α d)) := by
      intro d h1 h2
      have hnotbd : ∀ z, (z = d ∨ z = M.α d) → M.face z ∈ Y → M.face (M.α z) ∈ Y := by
        intro z hz hzY
        by_contra hzn
        have hb : M.edge z ∈ bd X := by
          rw [hbdeq]
          exact mem_bd.2 ⟨z, rfl, hzY, hzn⟩
        obtain ⟨d', hd', h3, -⟩ := mem_bd.1 hb
        have h4 : M.edge z = M.edge d := by
          rcases hz with rfl | rfl
          · rfl
          · exact M.edge_α d
        rw [h4] at hd'
        rcases M.edge_eq_iff.1 hd'.symm with h5 | h5
        · rw [h5] at h3
          exact mem_compl.1 h1 h3
        · rw [h5] at h3
          exact mem_compl.1 h2 h3
      have ha : M.face d ∈ Y ↔ M.face (M.α d) ∈ Y :=
        ⟨hnotbd d (Or.inl rfl), fun hm => by
          have := hnotbd (M.α d) (Or.inr rfl) hm
          rwa [M.α_α] at this⟩
      have hn1 : M.face d ∉ X := mem_compl.1 h1
      have hn2 : M.face (M.α d) ∉ X := mem_compl.1 h2
      simp only [x, hn1, hn2, not_false_iff, and_true, ha]
    have hconst := hcompl_strong x hx
    have h1 := hconst g (mem_compl.2 hgX) f1 (mem_compl.2 fun hn => mem_compl.1 hf1 (hYS (hXY hn)))
    have hxg : x g = 1 := by simp only [x, hg, hgX, not_false_iff, and_self, ite_true]
    have hxf1 : x f1 = 0 := by
      have : f1 ∉ Y := fun hn => mem_compl.1 hf1 (hYS hn)
      simp only [x, this, false_and, ite_false]
    rw [hxg, hxf1] at h1
    exact one_ne_zero h1
  have hΓY : IsSide Γ Y := by rw [← hXeqY]; exact hΓ
  have hEΓY : Essential Γ Y := by rw [← hXeqY]; exact hEΓ
  have hinf := SimpleCycle.hinf' (C := C) hlen hKK hP
  have hadd := SimpleCycle.topDart_add (C := C) hlen hKK hP
  have hmodt := SimpleCycle.topDart_mod (C := C) hlen hKK hP
  set Tops := (range C.len).image (fun k => M.edge (C.topDart k)) with hTops
  have hsub : bd Y ⊆ Tops := by
    intro e he
    obtain ⟨d, rfl, h1, h2⟩ := mem_bd.1 he
    obtain ⟨k, hk1, rfl⟩ := SimpleCycle.exists_top_of_bd hlen hKK hP h hor hT h1 h2
    exact mem_image.2 ⟨k, mem_range.2 hk1, rfl⟩
  have hcTops : Tops.card ≤ C.len := by
    have := Finset.card_image_le (s := range C.len) (f := fun k => M.edge (C.topDart k))
    rwa [card_range] at this
  have hTopsEq : bd Y = Tops := Finset.eq_of_subset_of_card_le hsub (by omega)
  have hinjOn : Set.InjOn (fun k => M.edge (C.topDart k)) (range C.len : Finset ℕ) :=
    Finset.card_image_iff.1 (by
      have : Tops.card = C.len := by rw [← hTopsEq]; exact hbdcard
      rw [card_range]
      exact this)
  have hedge_mod : ∀ a b, M.edge (C.topDart a) = M.edge (C.topDart b) → a % C.len = b % C.len := by
    intro a b hab
    apply hinjOn (mem_coe.2 (mem_range.2 (Nat.mod_lt _ (by omega))))
      (mem_coe.2 (mem_range.2 (Nat.mod_lt _ (by omega))))
    show M.edge (C.topDart (a % C.len)) = M.edge (C.topDart (b % C.len))
    rw [hmodt, hmodt, hab]
  have hΓe : Γ.edges = Tops := by rw [hΓY.edges_eq_bd, hTopsEq]
  have hmemE : ∀ k, M.edge (C.topDart k) ∈ Γ.edges := by
    intro k
    rw [hΓe, ← hmodt k]
    exact mem_image.2 ⟨k % C.len, mem_range.2 (Nat.mod_lt _ (by omega)), rfl⟩
  have hprev : ∀ k, M.tail (M.α (C.topDart (k + C.len - 1))) = M.tail (C.topDart k) := by
    intro k
    rw [SimpleCycle.head_topDart hT hinf, show k + C.len - 1 + 1 = k + C.len by omega, hadd]
  have htinj : ∀ i j, i < C.len → j < C.len → M.tail (C.topDart i) = M.tail (C.topDart j) →
      i = j := by
    intro i j hi hj htt
    by_contra hne
    obtain ⟨a, ha⟩ := Γ.exists_of_vert_mem (Γ.tail_mem_of_edge_mem (hmemE i))
    have hlΓ := Γ.len_pos
    set a' := a + Γ.len - 1 with ha'
    have hda : Γ.dart (a' + 1) = Γ.dart a := by
      rw [show a' + 1 = a + Γ.len by omega, Γ.periodic]
    have hcases : ∀ x, M.tail x = M.tail (C.topDart i) → M.edge x ∈ Γ.edges →
        x = Γ.dart (a' + 1) ∨ x = M.α (Γ.dart a') := by
      intro x hx he
      exact Γ.dart_cases (j := a') (by rw [hda, ha]; exact hx) he
    have hx1 := hcases _ rfl (hmemE i)
    have hx2 := hcases _ htt.symm (hmemE j)
    have hneq : C.topDart i ≠ C.topDart j := by
      intro heq
      have := hedge_mod i j (by rw [heq])
      rw [Nat.mod_eq_of_lt hi, Nat.mod_eq_of_lt hj] at this
      exact hne this
    have hpi := two_vals hx1 hx2 hneq (hcases _ (hprev i) (by rw [M.edge_α]; exact hmemE _))
    have hpj := two_vals hx1 hx2 hneq
      (hcases _ ((hprev j).trans htt.symm) (by rw [M.edge_α]; exact hmemE _))
    have him : ∀ {k m : ℕ}, M.α (C.topDart (k + C.len - 1)) = C.topDart m →
        (k + C.len - 1) % C.len = m % C.len := by
      intro k m hkm
      exact hedge_mod _ _ (by rw [← hkm, M.edge_α])
    have pi' := pred_mod hi
    have pj' := pred_mod hj
    have hci : i % C.len = i := Nat.mod_eq_of_lt hi
    have hcj : j % C.len = j := Nat.mod_eq_of_lt hj
    rcases hpi with h1 | h1 <;> rcases hpj with h2 | h2
    all_goals
      have e1 := him h1
      have e2 := him h2
      rw [pi'] at e1
      rw [pj'] at e2
      simp only [hci, hcj] at e1 e2
      split_ifs at e1 e2 <;> omega
  let C' : SimpleCycle M :=
    { len := C.len
      len_pos := C.len_pos
      dart := C.topDart
      periodic := hadd
      chain := SimpleCycle.head_topDart hT hinf
      tail_inj := htinj
      edge_inj := fun a b ha hb hab => hinjOn (mem_coe.2 (mem_range.2 ha))
        (mem_coe.2 (mem_range.2 hb)) hab }
  have hC'e : C'.edges = Γ.edges := by
    rw [hΓe]
    rfl
  have hC'E : Essential C' Y := SimpleCycle.essential_of_edges_eq hC'e hEΓY
  refine ⟨C', rfl, fun k => rfl, hC'E, ?_, hKK, hP, hcard_ring, hQ⟩
  intro j
  show M.face (C.topDart j) ∈ Y
  have hedge : M.edge (C.topDart j) ∈ Γ.edges := hmemE j
  have h1 := (hΓY _).1 hedge
  by_contra hn
  have h2 : M.face (M.α (C.topDart j)) ∈ Y := by
    by_contra hm
    exact h1 (iff_of_false hn hm)
  have h3 : M.α (C.topDart j) = M.cor1 (C.r (posU C.W j)) := by simp [SimpleCycle.topDart]
  have h4 : M.face (M.α (C.topDart j)) = M.tri (C.r (posU C.W j)) := by
    rw [h3]; exact face_corN (c := 1) (by norm_num) _
  rw [h4] at h2
  have h5 := SimpleCycle.tri_t hlen hKK h hor (posU C.W j)
  have h6' := (mem_filter.1 h2).2
  omega

end CMap

end Ful

end
