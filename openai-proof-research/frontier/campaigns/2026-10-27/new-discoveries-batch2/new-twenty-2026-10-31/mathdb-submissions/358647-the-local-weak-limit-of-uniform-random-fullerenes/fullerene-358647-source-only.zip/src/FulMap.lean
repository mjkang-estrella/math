/-
FulMap: finite combinatorial maps (darts, a vertex rotation σ and a fixed-point-free
edge involution α).  Vertices, edges and faces are the cycle types of σ, α and φ = σ ∘ α.
-/
import Mathlib.GroupTheory.Perm.Cycle.Basic
import Mathlib.Algebra.Group.Subgroup.Lattice
import Mathlib.Combinatorics.SimpleGraph.Basic
import Mathlib.Data.Fintype.EquivFin

set_option linter.unusedSectionVars false

noncomputable section

namespace Ful

open Equiv Equiv.Perm

variable {D : Type*} [Fintype D] [DecidableEq D]

/-- The set of cycles of a permutation, as a quotient of its domain. -/
def Orb (p : Perm D) : Type _ := Quotient (SameCycle.setoid p)

namespace Orb

variable {p : Perm D}

/-- The cycle containing a point. -/
def mk (p : Perm D) (d : D) : Orb p := Quotient.mk (SameCycle.setoid p) d

theorem mk_surjective (p : Perm D) : Function.Surjective (mk p) := Quotient.mk_surjective

noncomputable instance instFintype (p : Perm D) : Fintype (Orb p) := by
  haveI : Finite (Orb p) := Finite.of_surjective _ (mk_surjective p)
  exact Fintype.ofFinite _

noncomputable instance instDecEq (p : Perm D) : DecidableEq (Orb p) := Classical.decEq _

theorem mk_eq_iff {x y : D} : mk p x = mk p y ↔ SameCycle p x y := Quotient.eq

@[simp] theorem mk_apply (x : D) : mk p (p x) = mk p x :=
  mk_eq_iff.2 (sameCycle_apply_left.2 (SameCycle.refl _ _))

/-- A `p`-invariant function is constant on every cycle of `p`. -/
theorem eq_of_sameCycle {X : Sort*} (g : D → X) (hg : ∀ d, g (p d) = g d) {x y : D}
    (h : SameCycle p x y) : g x = g y := by
  obtain ⟨n, -, hn⟩ := h.exists_pow_eq'
  subst hn
  clear h
  induction n with
  | zero => simp
  | succ n ih => rw [pow_succ', Perm.mul_apply, hg]; exact ih

theorem eq_of_mk_eq {X : Sort*} (g : D → X) (hg : ∀ d, g (p d) = g d) {x y : D}
    (h : mk p x = mk p y) : g x = g y :=
  eq_of_sameCycle g hg (mk_eq_iff.1 h)

/-- Descend a `p`-invariant function to the cycles of `p`. -/
def lift {X : Sort*} (g : D → X) (hg : ∀ d, g (p d) = g d) : Orb p → X :=
  Quotient.lift g (fun _ _ h => eq_of_sameCycle g hg h)

@[simp] theorem lift_mk {X : Sort*} (g : D → X) (hg : ∀ d, g (p d) = g d) (d : D) :
    lift g hg (mk p d) = g d := rfl

theorem ind {P : Orb p → Prop} (h : ∀ d, P (mk p d)) (a : Orb p) : P a := by
  obtain ⟨d, rfl⟩ := mk_surjective p a
  exact h d

/-- Conjugate permutations have equivalent cycle types. -/
def congr {D' : Type*} [Fintype D'] [DecidableEq D'] {q : Perm D'} (e : D ≃ D') (h : ∀ d, e (p d) = q (e d)) : Orb p ≃ Orb q where
  toFun := lift (fun d => mk q (e d)) (fun d => by simp only [h, mk_apply])
  invFun := lift (fun d => mk p (e.symm d)) (fun d => by
    have : e.symm (q d) = p (e.symm d) := by
      rw [Equiv.symm_apply_eq, h, Equiv.apply_symm_apply]
    simp only [this, mk_apply])
  left_inv := fun a => by
    obtain ⟨d, rfl⟩ := mk_surjective p a
    simp only [lift_mk, Equiv.symm_apply_apply]
  right_inv := fun a => by
    obtain ⟨d, rfl⟩ := mk_surjective q a
    simp only [lift_mk, Equiv.apply_symm_apply]

end Orb

/-- A finite combinatorial map on darts `D`. `σ` rotates the darts around their tail vertex,
`α` reverses a dart. -/
structure CMap (D : Type*) where
  σ : Perm D
  α : Perm D
  α_invol : ∀ d, α (α d) = d
  α_ne : ∀ d, α d ≠ d

namespace CMap

variable (M : CMap D)

/-- The face permutation: `φ d` is the dart following `d` along its face. -/
def φ : Perm D := M.σ * M.α

@[simp] theorem φ_apply (d : D) : M.φ d = M.σ (M.α d) := rfl

/-- Vertices are `σ`-cycles. -/
abbrev V : Type _ := Orb M.σ
/-- Edges are `α`-cycles. -/
abbrev E : Type _ := Orb M.α
/-- Faces are `φ`-cycles. -/
abbrev F : Type _ := Orb M.φ

/-- The tail vertex of a dart. -/
def tail (d : D) : M.V := Orb.mk M.σ d
/-- The edge of a dart. -/
def edge (d : D) : M.E := Orb.mk M.α d
/-- The face to which a dart belongs. -/
def face (d : D) : M.F := Orb.mk M.φ d

@[simp] theorem tail_σ (d : D) : M.tail (M.σ d) = M.tail d := Orb.mk_apply d
@[simp] theorem edge_α (d : D) : M.edge (M.α d) = M.edge d := Orb.mk_apply d
@[simp] theorem face_φ (d : D) : M.face (M.φ d) = M.face d := Orb.mk_apply d

@[simp] theorem α_α (d : D) : M.α (M.α d) = d := M.α_invol d

/-- The tail of the next dart along a face is the head of the dart. -/
theorem tail_φ (d : D) : M.tail (M.φ d) = M.tail (M.α d) := by
  rw [φ_apply, tail_σ]

/-- The two faces at an edge: the face of `α d` is the face of `σ d`. -/
theorem face_α (d : D) : M.face (M.α d) = M.face (M.σ d) := by
  rw [← M.face_φ (M.α d), φ_apply, α_α]

theorem edge_eq_iff {d d' : D} : M.edge d = M.edge d' ↔ d' = d ∨ d' = M.α d := by
  constructor
  · intro h
    have key : (d = d ∨ d = M.α d) = (d' = d ∨ d' = M.α d) :=
      Orb.eq_of_mk_eq (p := M.α) (fun x => x = d ∨ x = M.α d) (fun x => by
        apply propext
        constructor
        · rintro (h | h)
          · right; rw [← h, α_α]
          · left; exact M.α.injective h
        · rintro (h | h)
          · right; rw [h]
          · left; rw [h, α_α]) h
    exact key.mp (Or.inl rfl)
  · rintro (h | h)
    · rw [h]
    · rw [h, edge_α]

/-- A map is connected if it has a dart and its monodromy group acts transitively. -/
def Connected : Prop :=
  Nonempty D ∧ ∀ x y : D, ∃ g ∈ Subgroup.closure ({M.σ, M.α} : Set (Perm D)), g x = y

variable {M}

/-- A function invariant under `σ` and `α` on a connected map is constant. -/
theorem Connected.invariant (h : M.Connected) {X : Sort*} (g : D → X)
    (hσ : ∀ d, g (M.σ d) = g d) (hα : ∀ d, g (M.α d) = g d) (x y : D) : g x = g y := by
  obtain ⟨π, hπ, rfl⟩ := h.2 x y
  have key : ∀ d, g (π d) = g d := by
    induction hπ using Subgroup.closure_induction with
    | mem z hz =>
      intro d
      rcases hz with rfl | hz
      · exact hσ d
      · rw [Set.mem_singleton_iff.1 hz]; exact hα d
    | one => intro d; rfl
    | mul a b _ _ ha hb => intro d; rw [Perm.mul_apply, ha, hb]
    | inv a _ ha => intro d; simpa using (ha (a⁻¹ d)).symm
  exact (key x).symm

/-- A function invariant under `φ` and `α` on a connected map is constant. -/
theorem Connected.invariant_φ (h : M.Connected) {X : Sort*} (g : D → X)
    (hφ : ∀ d, g (M.φ d) = g d) (hα : ∀ d, g (M.α d) = g d) (x y : D) : g x = g y :=
  h.invariant g (fun d => by
    have := hφ (M.α d)
    rw [φ_apply, α_α] at this
    rw [this, hα]) hα x y

variable (M)

/-- The number of vertices. -/
noncomputable def numV : ℕ := Fintype.card M.V
/-- The number of edges. -/
noncomputable def numE : ℕ := Fintype.card M.E
/-- The number of faces. -/
noncomputable def numF : ℕ := Fintype.card M.F

/-- Genus zero, as the Euler count `V - E + F = 2` stated without subtraction. -/
def Genus0 : Prop := M.numV + M.numF = M.numE + 2

/-- The degree of a vertex: the number of darts with that tail. -/
def deg (v : M.V) : ℕ := (Finset.univ.filter (fun d => M.tail d = v)).card
/-- The length of a face: the number of its darts. -/
def faceLen (f : M.F) : ℕ := (Finset.univ.filter (fun d => M.face d = f)).card

/-- The dual map. Faces and vertices exchange; darts are unchanged. -/
def dual : CMap D where
  σ := M.φ
  α := M.α
  α_invol := M.α_invol
  α_ne := M.α_ne

@[simp] theorem dual_σ : M.dual.σ = M.φ := rfl
@[simp] theorem dual_α : M.dual.α = M.α := rfl

@[simp] theorem dual_φ : M.dual.φ = M.σ := by
  ext d
  show M.φ (M.α d) = M.σ d
  rw [φ_apply, α_α]

variable {M}

theorem Connected.dual (h : M.Connected) : M.dual.Connected := by
  refine ⟨h.1, fun x y => ?_⟩
  obtain ⟨g, hg, hgxy⟩ := h.2 x y
  refine ⟨g, ?_, hgxy⟩
  have hle : Subgroup.closure ({M.σ, M.α} : Set (Perm D)) ≤
      Subgroup.closure ({M.dual.σ, M.dual.α} : Set (Perm D)) := by
    rw [Subgroup.closure_le]
    rintro z (rfl | hz)
    · have hα : M.α ∈ Subgroup.closure ({M.dual.σ, M.dual.α} : Set (Perm D)) :=
        Subgroup.subset_closure (by simp)
      have hφ : M.φ ∈ Subgroup.closure ({M.dual.σ, M.dual.α} : Set (Perm D)) :=
        Subgroup.subset_closure (by simp)
      have heq : M.σ = M.φ * M.α := by
        ext d
        simp only [Perm.mul_apply, φ_apply, α_α]
      rw [heq]
      exact Subgroup.mul_mem _ hφ hα
    · rw [Set.mem_singleton_iff.1 hz]
      exact Subgroup.subset_closure (by simp)
  exact hle hg

theorem Genus0.dual (h : M.Genus0) : M.dual.Genus0 := by
  have hV : M.dual.numV = M.numF := rfl
  have hE : M.dual.numE = M.numE := rfl
  have hF : M.dual.numF = M.numV := by
    show Fintype.card (Orb M.dual.φ) = Fintype.card (Orb M.σ)
    rw [dual_φ]
  unfold Genus0 at *
  omega

variable (M)

/-- The dual of a map whose faces are triangles is cubic and conversely; this predicate says that
every face of `M` is a triangle, i.e. `M` is a (possibly degenerate) triangulation. -/
def IsTriangulation : Prop := ∀ d, M.φ (M.φ (M.φ d)) = d ∧ M.φ d ≠ d

/-- The underlying simple graph: distinct vertices joined by some dart. -/
def graph : SimpleGraph M.V :=
  SimpleGraph.fromRel (fun v w => ∃ d, M.tail d = v ∧ M.tail (M.α d) = w)

/-- No loops and no parallel edges. -/
def IsSimple : Prop :=
  (∀ d, M.tail d ≠ M.tail (M.α d)) ∧
    ∀ d d', M.tail d = M.tail d' → M.tail (M.α d) = M.tail (M.α d') → d = d'

/-- Fullerene maps: connected, genus zero, cubic, simple, all face lengths 5 or 6. -/
structure IsFullerene : Prop where
  connected : M.Connected
  genus : M.Genus0
  simple : M.IsSimple
  cubic : ∀ v, M.deg v = 3
  faces : ∀ f, M.faceLen f = 5 ∨ M.faceLen f = 6

end CMap

/-- An isomorphism of combinatorial maps: a bijection on darts commuting with `σ` and `α`.
Orientation reversal is handled by composing with the mirror map if a statement requires it. -/
structure MapIso {D' : Type*} [Fintype D'] [DecidableEq D'] (M : CMap D) (M' : CMap D') where
  e : D ≃ D'
  σ_comm : ∀ d, e (M.σ d) = M'.σ (e d)
  α_comm : ∀ d, e (M.α d) = M'.α (e d)

namespace MapIso

variable {D' : Type*} [Fintype D'] [DecidableEq D'] {M : CMap D} {M' : CMap D'}

theorem φ_comm (i : MapIso M M') (d : D) : i.e (M.φ d) = M'.φ (i.e d) := by
  simp only [CMap.φ_apply, i.σ_comm, i.α_comm]

theorem numV_eq (i : MapIso M M') : M.numV = M'.numV :=
  Fintype.card_congr (Orb.congr i.e i.σ_comm)

theorem numE_eq (i : MapIso M M') : M.numE = M'.numE :=
  Fintype.card_congr (Orb.congr i.e i.α_comm)

theorem numF_eq (i : MapIso M M') : M.numF = M'.numF :=
  Fintype.card_congr (Orb.congr i.e i.φ_comm)

theorem genus0_iff (i : MapIso M M') : M.Genus0 ↔ M'.Genus0 := by
  unfold CMap.Genus0
  rw [i.numV_eq, i.numE_eq, i.numF_eq]

end MapIso

end Ful

end
