/- Gate E controls: face permutation, Euler relation, an explicit fullerene and order bounds.
Reviewer-authored. The tables are computed separately and every property is checked here by `decide`. -/
import ControlBall

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false
set_option linter.unnecessarySeqFocus false
set_option maxRecDepth 100000

noncomputable section

namespace Control

open Ful Ful.Stmt SimpleGraph Equiv Equiv.Perm Finset

/-- An explicit cubic graph on `Fin n`, with a rotation and a list of face orbits. -/
structure Tbl (n k : ℕ) where
  rot : Fin n → Fin n × Fin n × Fin n
  orbs : List (List (Fin n × Fin n))
  root : Fin n
  par : Fin n → Fin n
  rk : Fin n → ℕ
  len : Fin k → ℕ
  hk : 0 < k
  numDarts : ℕ

namespace Tbl

variable {n k : ℕ} (T : Tbl n k)

def adj (u v : Fin n) : Bool := v == (T.rot u).1 || v == (T.rot u).2.1 || v == (T.rot u).2.2

def nxt (u v : Fin n) : Fin n :=
  if v = (T.rot u).1 then (T.rot u).2.1 else if v = (T.rot u).2.1 then (T.rot u).2.2 else (T.rot u).1

def prv (u v : Fin n) : Fin n :=
  if v = (T.rot u).2.1 then (T.rot u).1 else if v = (T.rot u).2.2 then (T.rot u).2.1 else (T.rot u).2.2

def fidN (u v : Fin n) : ℕ := T.orbs.findIdx (fun o => o.contains (u, v))
def fid (u v : Fin n) : Fin k := ⟨T.fidN u v % k, Nat.mod_lt _ T.hk⟩
def rep (c : Fin k) : Fin n × Fin n := (T.orbs.getD c.val []).headD (T.root, T.root)
def φp (p : Fin n × Fin n) : Fin n × Fin n := (p.2, T.nxt p.2 p.1)

structure Valid : Prop where
  symm : ∀ u v, T.adj u v = T.adj v u
  irr : ∀ u, T.adj u u = false
  deg3 : ∀ v, (Finset.univ.filter (fun w => T.adj v w = true)).card = 3
  nxt_adj : ∀ u v, T.adj u v = true → T.adj u (T.nxt u v) = true
  prv_adj : ∀ u v, T.adj u v = true → T.adj u (T.prv u v) = true
  prv_nxt : ∀ u v, T.adj u v = true → T.prv u (T.nxt u v) = v
  nxt_prv : ∀ u v, T.adj u v = true → T.nxt u (T.prv u v) = v
  rot3 : ∀ u v w, T.adj u v = true → T.adj u w = true →
    w = v ∨ w = T.nxt u v ∨ w = T.nxt u (T.nxt u v)
  rep_adj : ∀ c, T.adj (T.rep c).1 (T.rep c).2 = true
  rep_fid : ∀ c, T.fid (T.rep c).1 (T.rep c).2 = c
  fid_inv : ∀ u v, T.adj u v = true → T.fid v (T.nxt v u) = T.fid u v
  reach : ∀ u v, T.adj u v = true → ∃ i : Fin 9, (T.φp^[i.val]) (T.rep (T.fid u v)) = (u, v)
  faceCount : ∀ c, (Finset.univ.filter (fun p : Fin n × Fin n =>
    T.adj p.1 p.2 = true ∧ T.fid p.1 p.2 = c)).card = T.len c
  dartCount : (Finset.univ.filter (fun p : Fin n × Fin n => T.adj p.1 p.2 = true)).card = T.numDarts
  desc : ∀ v, v = T.root ∨ (T.adj v (T.par v) = true ∧ T.rk (T.par v) < T.rk v)

variable {T} (h : T.Valid)
include h

/-- The graph of a table. -/
def G : SimpleGraph (Fin n) where
  Adj u v := T.adj u v = true
  symm := ⟨fun u v huv => by rw [h.symm]; exact huv⟩
  loopless := ⟨fun u huu => by rw [h.irr] at huu; cases huu⟩

/-- The vertex rotation. -/
def sigma : Equiv.Perm (G h).Dart where
  toFun d := ⟨(d.fst, T.nxt d.fst d.snd), h.nxt_adj _ _ d.adj⟩
  invFun d := ⟨(d.fst, T.prv d.fst d.snd), h.prv_adj _ _ d.adj⟩
  left_inv d := Dart.ext _ _ (Prod.ext rfl (h.prv_nxt _ _ d.adj))
  right_inv d := Dart.ext _ _ (Prod.ext rfl (h.nxt_prv _ _ d.adj))

/-- The rotation system of the statement, built from the table. -/
def rotSys : RotationSystem (G h) where
  σ := sigma h
  tail_eq _ := rfl
  transitive d d' hd := by
    rcases h.rot3 d.fst d.snd d'.snd d.adj (by rw [hd]; exact d'.adj) with h1 | h1 | h1
    · exact ⟨(0 : ℤ), by rw [zpow_zero, Perm.one_apply]; exact Dart.ext _ _ (Prod.ext hd h1.symm)⟩
    · exact ⟨(1 : ℤ), by rw [zpow_one]; exact Dart.ext _ _ (Prod.ext hd h1.symm)⟩
    · exact ⟨(2 : ℤ), by rw [zpow_two, Perm.mul_apply]; exact Dart.ext _ _ (Prod.ext hd h1.symm)⟩

theorem φ_toProd (d : (G h).Dart) : ((rotSys h).φ d).toProd = T.φp d.toProd := rfl

theorem φ_pow (i : ℕ) (d : (G h).Dart) :
    (((rotSys h).φ ^ i) d).toProd = T.φp^[i] d.toProd := by
  induction i with
  | zero => simp
  | succ i ih =>
    rw [pow_succ', Perm.mul_apply, φ_toProd, ih]
    exact (Function.iterate_succ_apply' T.φp i d.toProd).symm

def qd (d : (G h).Dart) : Fin k := T.fid d.fst d.snd

theorem qd_φ (d : (G h).Dart) : qd h ((rotSys h).φ d) = qd h d :=
  h.fid_inv d.fst d.snd d.adj

def repD (c : Fin k) : (G h).Dart := ⟨T.rep c, h.rep_adj c⟩

theorem reach_rep (d : (G h).Dart) : (rotSys h).φ.SameCycle (repD h (qd h d)) d := by
  obtain ⟨i, hi⟩ := h.reach d.fst d.snd d.adj
  refine ⟨(i.val : ℤ), ?_⟩
  rw [zpow_natCast]
  apply Dart.ext
  rw [φ_pow]
  exact hi

theorem sameCycle_iff (d d' : (G h).Dart) :
    (rotSys h).φ.SameCycle d d' ↔ qd h d = qd h d' := by
  constructor
  · intro hs
    classical
    exact Orb.eq_of_sameCycle (qd h) (qd_φ h) hs
  · intro heq
    have h1 := reach_rep h d
    have h2 := reach_rep h d'
    rw [heq] at h1
    exact h1.symm.trans h2

theorem numFaces_eq : (rotSys h).numFaces = k := by
  unfold RotationSystem.numFaces
  let f : Quotient (SameCycle.setoid (rotSys h).φ) → Fin k :=
    Quotient.lift (qd h) (fun a b hab => (sameCycle_iff h a b).1 hab)
  have hf : Function.Bijective f := by
    constructor
    · intro a b hab
      induction a using Quotient.ind
      induction b using Quotient.ind
      exact Quotient.sound ((sameCycle_iff h _ _).2 hab)
    · intro c
      exact ⟨Quotient.mk _ (repD h c), h.rep_fid c⟩
  rw [Nat.card_congr (Equiv.ofBijective f hf)]
  simp

theorem faceLen_eq (d : (G h).Dart) : (rotSys h).faceLen d = T.len (qd h d) := by
  unfold RotationSystem.faceLen
  let e : {d' : (G h).Dart // (rotSys h).φ.SameCycle d d'} ≃
      {p : Fin n × Fin n // T.adj p.1 p.2 = true ∧ T.fid p.1 p.2 = qd h d} :=
    { toFun := fun x => ⟨x.1.toProd, x.1.adj, ((sameCycle_iff h d x.1).1 x.2).symm⟩
      invFun := fun y => ⟨⟨y.1, y.2.1⟩, (sameCycle_iff h d ⟨y.1, y.2.1⟩).2 y.2.2.symm⟩
      left_inv := fun x => Subtype.ext (Dart.ext _ _ rfl)
      right_inv := fun y => Subtype.ext rfl }
  rw [Nat.card_congr e, Nat.card_eq_fintype_card, Fintype.card_subtype]
  exact h.faceCount (qd h d)

theorem edge_card : 2 * Nat.card (G h).edgeSet = T.numDarts := by
  classical
  have h1 := (G h).dart_card_eq_twice_card_edges
  have h5 : Nat.card (G h).edgeSet = #(G h).edgeFinset := by
    rw [SimpleGraph.edgeFinset, Set.toFinset_card, Nat.card_eq_fintype_card]
  have h2 : Fintype.card (G h).Dart = T.numDarts := by
    let e : (G h).Dart ≃ {p : Fin n × Fin n // T.adj p.1 p.2 = true} :=
      { toFun := fun d => ⟨d.toProd, d.adj⟩
        invFun := fun y => ⟨y.1, y.2⟩
        left_inv := fun d => Dart.ext _ _ rfl
        right_inv := fun y => Subtype.ext rfl }
    rw [Fintype.card_congr e, Fintype.card_subtype]
    exact h.dartCount
  omega

theorem reachable_root (v : Fin n) : (G h).Reachable v T.root := by
  induction hr : T.rk v using Nat.strong_induction_on generalizing v with
  | _ r ih =>
    rcases h.desc v with rfl | ⟨ha, hlt⟩
    · exact Reachable.refl _
    · have hb := ih (T.rk (T.par v)) (by omega) (T.par v) rfl
      exact (Adj.reachable (G := G h) ha).trans hb

theorem connected : (G h).Connected := by
  have : Nonempty (Fin n) := ⟨T.root⟩
  exact ⟨fun v w => (reachable_root h v).trans (reachable_root h w).symm⟩

theorem cubic (v : Fin n) : Nat.card ((G h).neighborSet v) = 3 := by
  have e : (G h).neighborSet v ≃ {w : Fin n // T.adj v w = true} := Equiv.refl _
  rw [Nat.card_congr e, Nat.card_eq_fintype_card, Fintype.card_subtype]
  exact h.deg3 v

theorem euler_iff : Nat.card (Fin n) + (rotSys h).numFaces = Nat.card (G h).edgeSet + 2 ↔
    2 * (n + k) = T.numDarts + 4 := by
  have h1 := edge_card h
  have h2 := numFaces_eq h
  have h3 : Nat.card (Fin n) = n := by simp
  omega

/-- A table with Euler characteristic two and faces of length 5 or 6 is a fullerene graph. -/
theorem isFullerene (hE : 2 * (n + k) = T.numDarts + 4) (h56 : ∀ c, T.len c = 5 ∨ T.len c = 6) :
    IsFullerene (G h) :=
  ⟨connected h, cubic h, ⟨rotSys h, (euler_iff h).2 hE, fun d => by
    rw [faceLen_eq]
    exact h56 _⟩⟩

end Tbl


def k4Planar : Tbl 4 4 where
  rot u := match u.val with | 0 => (1,2,3) | 1 => (0,3,2) | 2 => (0,1,3) | 3 => (0,2,1) | _ => (0,0,0)
  orbs := [[(0,1),(1,3),(3,0)],[(0,2),(2,1),(1,0)],[(0,3),(3,2),(2,0)],[(1,2),(2,3),(3,1)]]
  root := 0
  par u := match u.val with | 0 => 0 | 1 => 0 | 2 => 0 | 3 => 0 | _ => 0
  rk u := match u.val with | 0 => 0 | 1 => 1 | 2 => 1 | 3 => 1 | _ => 0
  len c := match c.val with | 0 => 3 | 1 => 3 | 2 => 3 | 3 => 3 | _ => 0
  hk := by norm_num
  numDarts := 12

def k4Toroidal : Tbl 4 2 where
  rot u := match u.val with | 0 => (1,2,3) | 1 => (0,2,3) | 2 => (0,1,3) | 3 => (0,1,2) | _ => (0,0,0)
  orbs := [[(0,1),(1,2),(2,3),(3,0)],[(0,2),(2,1),(1,3),(3,2),(2,0),(0,3),(3,1),(1,0)]]
  root := 0
  par u := match u.val with | 0 => 0 | 1 => 0 | 2 => 0 | 3 => 0 | _ => 0
  rk u := match u.val with | 0 => 0 | 1 => 1 | 2 => 1 | 3 => 1 | _ => 0
  len c := match c.val with | 0 => 4 | 1 => 8 | _ => 0
  hk := by norm_num
  numDarts := 12

def dodecTbl : Tbl 20 12 where
  rot u := match u.val with | 0 => (1,5,4) | 1 => (2,6,0) | 2 => (3,7,1) | 3 => (4,8,2) | 4 => (9,3,0) | 5 => (10,14,0) | 6 => (11,10,1) | 7 => (2,12,11) | 8 => (3,13,12) | 9 => (13,4,14) | 10 => (6,15,5) | 11 => (7,16,6) | 12 => (7,8,17) | 13 => (8,9,18) | 14 => (19,9,5) | 15 => (16,19,10) | 16 => (11,17,15) | 17 => (12,18,16) | 18 => (17,13,19) | 19 => (18,14,15) | _ => (0,0,0)
  orbs := [[(0,1),(1,2),(2,3),(3,4),(4,0)],[(0,5),(5,10),(10,6),(6,1),(1,0)],[(0,4),(4,9),(9,14),(14,5),(5,0)],[(1,6),(6,11),(11,7),(7,2),(2,1)],[(2,7),(7,12),(12,8),(8,3),(3,2)],[(3,8),(8,13),(13,9),(9,4),(4,3)],[(5,14),(14,19),(19,15),(15,10),(10,5)],[(6,10),(10,15),(15,16),(16,11),(11,6)],[(7,11),(11,16),(16,17),(17,12),(12,7)],[(8,12),(12,17),(17,18),(18,13),(13,8)],[(9,13),(13,18),(18,19),(19,14),(14,9)],[(15,19),(19,18),(18,17),(17,16),(16,15)]]
  root := 0
  par u := match u.val with | 0 => 0 | 1 => 0 | 2 => 1 | 3 => 4 | 4 => 0 | 5 => 0 | 6 => 1 | 7 => 2 | 8 => 3 | 9 => 4 | 10 => 5 | 11 => 6 | 12 => 7 | 13 => 9 | 14 => 5 | 15 => 10 | 16 => 11 | 17 => 12 | 18 => 19 | 19 => 14 | _ => 0
  rk u := match u.val with | 0 => 0 | 1 => 1 | 2 => 2 | 3 => 2 | 4 => 1 | 5 => 1 | 6 => 2 | 7 => 3 | 8 => 3 | 9 => 2 | 10 => 2 | 11 => 3 | 12 => 4 | 13 => 3 | 14 => 2 | 15 => 3 | 16 => 4 | 17 => 5 | 18 => 4 | 19 => 3 | _ => 0
  len c := match c.val with | 0 => 5 | 1 => 5 | 2 => 5 | 3 => 5 | 4 => 5 | 5 => 5 | 6 => 5 | 7 => 5 | 8 => 5 | 9 => 5 | 10 => 5 | 11 => 5 | _ => 0
  hk := by norm_num
  numDarts := 60

/-- The hexagonal prism: outer hexagon 0..5, inner hexagon 6..11, spokes `i - (i+6)`, with its planar
rotation (six squares and two hexagons). -/
def prismTbl : Tbl 12 8 where
  rot u := match u.val with | 0 => (5,1,6) | 1 => (7,0,2) | 2 => (3,8,1) | 3 => (4,9,2) | 4 => (5,10,3) | 5 => (0,11,4) | 6 => (11,0,7) | 7 => (6,1,8) | 8 => (9,7,2) | 9 => (10,8,3) | 10 => (4,11,9) | 11 => (5,6,10) | _ => (0,0,0)
  orbs := [[(0,5),(5,11),(11,6),(6,0)],[(0,1),(1,2),(2,3),(3,4),(4,5),(5,0)],[(0,6),(6,7),(7,1),(1,0)],[(6,11),(11,10),(10,9),(9,8),(8,7),(7,6)],[(1,7),(7,8),(8,2),(2,1)],[(2,8),(8,9),(9,3),(3,2)],[(3,9),(9,10),(10,4),(4,3)],[(4,10),(10,11),(11,5),(5,4)]]
  root := 0
  par u := match u.val with | 0 => 0 | 1 => 0 | 2 => 1 | 3 => 4 | 4 => 5 | 5 => 0 | 6 => 0 | 7 => 1 | 8 => 7 | 9 => 10 | 10 => 11 | 11 => 5 | _ => 0
  rk u := match u.val with | 0 => 0 | 1 => 1 | 2 => 2 | 3 => 3 | 4 => 2 | 5 => 1 | 6 => 1 | 7 => 2 | 8 => 3 | 9 => 4 | 10 => 3 | 11 => 2 | _ => 0
  len c := match c.val with | 0 => 4 | 1 => 6 | 2 => 4 | 3 => 6 | 4 => 4 | 5 => 4 | 6 => 4 | 7 => 4 | _ => 0
  hk := by norm_num
  numDarts := 36

theorem k4Planar_valid : k4Planar.Valid := by constructor <;> decide +kernel
theorem k4Toroidal_valid : k4Toroidal.Valid := by constructor <;> decide +kernel
theorem dodec_valid : dodecTbl.Valid := by constructor <;> decide +kernel

/-! ### The face permutation. -/

/-- The planar rotation of `K₄` has four triangular faces and satisfies Euler's relation. -/
theorem k4Planar_faces : (Tbl.rotSys k4Planar_valid).numFaces = 4 := Tbl.numFaces_eq _
theorem k4Planar_len (d : (Tbl.G k4Planar_valid).Dart) : (Tbl.rotSys k4Planar_valid).faceLen d = 3 := by
  rw [Tbl.faceLen_eq]
  revert d
  have h : ∀ c : Fin 4, k4Planar.len c = 3 := by decide +kernel
  exact fun d => h _
theorem k4Planar_euler : Nat.card (Fin 4) + (Tbl.rotSys k4Planar_valid).numFaces =
    Nat.card (Tbl.G k4Planar_valid).edgeSet + 2 := (Tbl.euler_iff k4Planar_valid).2 (by decide +kernel)

/-- The toroidal rotation of `K₄` has only two faces (of lengths 4 and 8) and fails Euler's relation.
If the face permutation were the vertex rotation `σ`, this rotation would have four faces of length
three and would satisfy the relation. This is the control on the face permutation. -/
theorem k4Toroidal_faces : (Tbl.rotSys k4Toroidal_valid).numFaces = 2 := Tbl.numFaces_eq _
theorem k4Toroidal_no_euler : Nat.card (Fin 4) + (Tbl.rotSys k4Toroidal_valid).numFaces ≠
    Nat.card (Tbl.G k4Toroidal_valid).edgeSet + 2 := by
  intro h
  have := (Tbl.euler_iff k4Toroidal_valid).1 h
  revert this
  decide +kernel

/-! ### Positive control: the dodecahedron is a fullerene graph. -/

theorem dodec_isFullerene : IsFullerene (Tbl.G dodec_valid) :=
  Tbl.isFullerene dodec_valid (by decide +kernel) (by decide +kernel)

theorem twenty_is_order : (20 : ℕ) ∈ FullereneOrders :=
  ⟨Quotient.mk (fullereneSetoid 20) ⟨Tbl.G dodec_valid, dodec_isFullerene⟩⟩

/-! ### Negative controls: every fullerene has at least twenty vertices. -/

/-- Any `IsFullerene` graph on `Fin n` has `n ≥ 20` (twelve pentagons plus Euler). -/
theorem fullerene_ge_twenty {n : ℕ} {G : SimpleGraph (Fin n)} (hG : IsFullerene G) : 20 ≤ n := by
  classical
  obtain ⟨ρ, h1, h2⟩ := hG.embedding
  have hM := mapOf_isFullerene ρ hG ⟨h1, h2⟩
  have hp := CMap.card_pent hM.dual_tri hM.dual_genus hM.dual_deg
  have hle : (Finset.univ.filter (fun v => (mapOf ρ).dual.deg v ≠ 6)).card ≤
      (mapOf ρ).dual.numV := by
    unfold CMap.numV
    exact (Finset.card_le_card (Finset.filter_subset _ _)).trans (le_of_eq Finset.card_univ)
  have hFeq : (mapOf ρ).dual.numV = ρ.numFaces := by
    show Fintype.card (Orb (mapOf ρ).φ) = _
    unfold RotationSystem.numFaces
    rw [Nat.card_eq_fintype_card]
    exact Fintype.card_congr (Equiv.refl _)
  have hF : 12 ≤ ρ.numFaces := by omega
  have hd := dart_card hG
  have h3 := G.dart_card_eq_twice_card_edges
  have h5 : Nat.card G.edgeSet = #G.edgeFinset := by
    rw [SimpleGraph.edgeFinset, Set.toFinset_card, Nat.card_eq_fintype_card]
  have h6 : Nat.card (Fin n) = n := by simp
  omega

/-- `K₄` is cubic and planar but not a fullerene. -/
theorem k4_not_fullerene : ¬ IsFullerene (⊤ : SimpleGraph (Fin 4)) := fun h => by
  have := fullerene_ge_twenty h
  omega

theorem prism_valid : prismTbl.Valid := by constructor <;> decide +kernel

/-- The real prism is cubic, connected and planar: its rotation satisfies Euler's relation. -/
theorem prism_euler : Nat.card (Fin 12) + (Tbl.rotSys prism_valid).numFaces =
    Nat.card (Tbl.G prism_valid).edgeSet + 2 := (Tbl.euler_iff prism_valid).2 (by decide +kernel)

/-- It has a face of length four, so this embedding violates the 5-or-6 rule. -/
theorem prism_has_square : (Tbl.rotSys prism_valid).faceLen (Tbl.repD prism_valid 0) = 4 := by
  rw [Tbl.faceLen_eq]
  have h : prismTbl.fid (prismTbl.rep 0).1 (prismTbl.rep 0).2 = 0 := prism_valid.rep_fid 0
  show prismTbl.len (prismTbl.fid (prismTbl.rep 0).1 (prismTbl.rep 0).2) = 4
  rw [h]
  decide +kernel

/-- The hexagonal prism is not a fullerene (in any embedding). -/
theorem prism_not_fullerene : ¬ IsFullerene (Tbl.G prism_valid) := fun h => by
  have := fullerene_ge_twenty h
  omega

/-- A non-fullerene order: no fullerene has 18 vertices. -/
theorem no_order_18 : (18 : ℕ) ∉ FullereneOrders := by
  rintro ⟨c⟩
  obtain ⟨⟨G, hG⟩, -⟩ := Quotient.exists_rep c
  have := fullerene_ge_twenty hG
  omega

/-- The helical family gives a concrete fullerene on 92 vertices. -/
theorem helix_order_92 : (92 : ℕ) ∈ FullereneOrders := by
  have hc : Fintype.card (Helix.helix (s := 4) (m := 39) (by norm_num) (by norm_num)).T.dual.V = 92 := by
    rw [Helix.helix_card]
  exact ⟨Quotient.mk (fullereneSetoid 92)
    ⟨Helix.helixG (by norm_num) (by norm_num) hc, Helix.helixG_isFullerene _ _ _⟩⟩

end Control

end
