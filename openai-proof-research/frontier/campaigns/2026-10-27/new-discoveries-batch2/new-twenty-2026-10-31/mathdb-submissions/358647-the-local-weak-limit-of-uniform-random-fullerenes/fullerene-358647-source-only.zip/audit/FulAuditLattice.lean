import FulLatticeAut

#print axioms Ful.Stmt.hex_adj_iff
#print axioms Ful.Stmt.hexDist4_ge
#print axioms Ful.Stmt.hex_vertexTransitive
#print axioms Ful.Stmt.ballFraction_congr
