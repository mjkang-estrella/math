/-
FulBridge: a fullerene map has a triangulated dual with vertex degrees 5 and 6.
-/
import FulBall

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- The dual of a fullerene map is a triangulation. -/
theorem IsFullerene.dual_tri (h : M.IsFullerene) : M.dual.IsTriangulation := by
  intro d
  have h3 := pow_eq_self_iff_of_deg (h.cubic (M.tail d)) (by norm_num)
  have hc3 : (M.σ ^ 3) d = d := (h3 3).2 (dvd_refl 3)
  have hc1 : ¬ (M.σ ^ 1) d = d := fun hn => by
    have := (h3 1).1 hn
    omega
  rw [dual_φ]
  constructor
  · simpa only [pow_succ', pow_zero, mul_one, Perm.mul_apply] using hc3
  · simpa only [pow_one] using hc1

/-- Vertex degrees of the dual are the face lengths of the map. -/
theorem IsFullerene.dual_deg (h : M.IsFullerene) (v : M.dual.V) :
    M.dual.deg v = 5 ∨ M.dual.deg v = 6 := h.faces v

theorem IsFullerene.dual_deg_le (h : M.IsFullerene) (v : M.dual.V) : M.dual.deg v ≤ 6 := by
  rcases h.dual_deg v with h1 | h1 <;> omega

theorem IsFullerene.dual_connected (h : M.IsFullerene) : M.dual.Connected := h.connected.dual

theorem IsFullerene.dual_genus (h : M.IsFullerene) : M.dual.Genus0 := h.genus.dual

end CMap

end Ful

end
