/-
FulHelixE: the helical table as a `Table`, and the helical maps are fullerene maps.
-/
import FulHelixD
import Mathlib.Data.Int.Interval

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful.Helix

open Finset

open scoped Classical

macro "out_at" : tactic =>
  `(tactic| simp (disch := omega) only [Nb_int, Nb_zero, Nb_mid, Nb_m, Nb_intB, low_gen,
      low_cf, up_gen, up_cf, intA, ifT, ifF, cf_a, cf_b, cf_c, cf_d, cf_e, cf_f,
      List.cons_append, List.nil_append, List.map_cons, List.map_nil, List.nodup_cons,
      List.mem_cons, List.not_mem_nil, or_false, List.nodup_nil, and_true, Lp, not_false_eq_true])

variable {s m u : ℤ}

set_option maxHeartbeats 2000000 in
theorem Nb_nodup (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s) :
    (Nb s m u).Nodup := by
  have hLp : Lp s = 2 * s + 5 := rfl
  rcases classes hs hm h1 h2 with (hc | hc | ⟨hc1, hc2⟩) | hc | hc | (hc | hc | ⟨hc1, hc2⟩) |
    (hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc |
      hc | hc | hc | hc) <;> out_at <;> omega

theorem getD_inj {α : Type*} {l : List α} (hl : l.Nodup) {i j : ℕ} {d : α} (hi : i < l.length)
    (hj : j < l.length) (h : l.getD i d = l.getD j d) : i = j := by
  rw [List.getD_eq_getElem _ _ hi, List.getD_eq_getElem _ _ hj] at h
  exact (List.Nodup.getElem_inj_iff hl).1 h

theorem difT {α : Sort*} {c : Prop} [Decidable c] {t : c → α} {e : ¬c → α} (h : c) :
    dite c t e = t h := by simp [h]

/-- The number of vertices of the triangulation. -/
def V (s m : ℕ) : ℕ := m + 2 * s + 1

/-- The label of a vertex. -/
def lab {n : ℕ} (s : ℕ) (u : Fin n) : ℤ := (u.1 : ℤ) - s

/-- The vertex with a given label. -/
def unlab (s n : ℕ) (hn : 0 < n) (z : ℤ) : Fin n :=
  if h : 0 ≤ z + s ∧ z + s < n then ⟨(z + s).toNat, by omega⟩ else ⟨0, hn⟩

theorem lab_unlab {s n : ℕ} {hn : 0 < n} {z : ℤ} (h1 : 0 ≤ z + s) (h2 : z + s < n) :
    lab s (unlab s n hn z) = z := by
  unfold lab unlab
  rw [difT ⟨h1, h2⟩]
  simp only [Fin.val_mk]
  omega

theorem unlab_lab {s n : ℕ} {hn : 0 < n} (u : Fin n) : unlab s n hn (lab s u) = u := by
  unfold lab unlab
  have h : 0 ≤ ((u.1 : ℤ) - s) + s ∧ ((u.1 : ℤ) - s) + s < n := by
    have := u.2
    constructor <;> omega
  rw [difT h]
  apply Fin.ext
  simp only [Fin.val_mk]
  omega

variable {s m : ℕ}

theorem V_pos : 0 < V s m := by unfold V; omega

theorem lab_unlab' {z : ℤ} (h : -(s : ℤ) ≤ z ∧ z ≤ (m : ℤ) + s) :
    lab s (unlab s (V s m) V_pos z) = z :=
  lab_unlab (by omega) (by unfold V; omega)

theorem lab_range (u : Fin (V s m)) : -(s : ℤ) ≤ lab s u ∧ lab s u ≤ (m : ℤ) + s := by
  have := u.2
  unfold lab V at *
  constructor <;> omega

/-- The helical rotation table. -/
def helix (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) : Table (V s m) where
  deg u := len s m (lab s u)
  nb u k := unlab s (V s m) V_pos (nz s m (lab s u) k)
  ix u k := iz s m (lab s u) k
  deg_pos u := by
    have h := len_cases (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2
    rcases h with h | h <;> omega
  ix_lt u k hk := by
    have hlaw := law_all (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 hk
    unfold Law at hlaw
    obtain ⟨⟨r1, r2⟩, -, hlt, -, -⟩ := hlaw
    rw [lab_unlab' ⟨r1, r2⟩]
    exact hlt
  irr u k hk h := by
    have hlaw := law_all (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 hk
    unfold Law at hlaw
    obtain ⟨⟨r1, r2⟩, hne, -, -, -⟩ := hlaw
    have := congrArg (lab s) h
    rw [lab_unlab' ⟨r1, r2⟩] at this
    exact hne this
  nb_ix u k hk := by
    have hlaw := law_all (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 hk
    unfold Law at hlaw
    obtain ⟨⟨r1, r2⟩, -, -, hnb, -⟩ := hlaw
    rw [lab_unlab' ⟨r1, r2⟩, hnb, unlab_lab]
  inj u k k' hk hk' h := by
    have hlaw1 := law_all (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 hk
    have hlaw2 := law_all (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 hk'
    unfold Law at hlaw1 hlaw2
    obtain ⟨⟨r1, r2⟩, -⟩ := hlaw1
    obtain ⟨⟨r3, r4⟩, -⟩ := hlaw2
    have h2 := congrArg (lab s) h
    rw [lab_unlab' ⟨r1, r2⟩, lab_unlab' ⟨r3, r4⟩] at h2
    exact getD_inj (Nb_nodup (by exact_mod_cast hs) (by exact_mod_cast hm) (lab_range u).1
      (lab_range u).2) hk hk' h2
  tri u k hk := by
    have hlaw := law_all (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 hk
    unfold Law at hlaw
    obtain ⟨⟨r1, r2⟩, -, -, -, htri⟩ := hlaw
    show unlab s (V s m) V_pos (nz s m (lab s (unlab s (V s m) V_pos (nz s m (lab s u) k))) _) = _
    rw [lab_unlab' ⟨r1, r2⟩, htri]

variable (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m)

theorem helix_deg (u : Fin (V s m)) :
    (helix hs hm).deg u = 5 ∨ (helix hs hm).deg u = 6 := by
  have h := len_cases (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
    (lab_range u).1 (lab_range u).2
  rcases h with h | h
  · exact Or.inl h.1
  · exact Or.inr h.1

theorem helix_connected : (helix hs hm).T.Connected := by
  refine (helix hs hm).connected V_pos (fun u => (lab s u).natAbs) ?_ ?_
  · intro u v hu hv
    have h1 : lab s u = 0 := by simpa using hu
    have h2 : lab s v = 0 := by simpa using hv
    rw [← unlab_lab (hn := V_pos) u, ← unlab_lab (hn := V_pos) v, h1, h2]
  · intro u hu
    have h0 : lab s u ≠ 0 := by
      intro h
      apply hu
      simp [h]
    obtain ⟨k, hk, hlt⟩ := desc (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 h0
    refine ⟨k, hk, ?_⟩
    have hlaw := law_all (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2 hk
    unfold Law at hlaw
    obtain ⟨⟨r1, r2⟩, -⟩ := hlaw
    show (lab s (unlab s (V s m) V_pos (nz s m (lab s u) k))).natAbs < (lab s u).natAbs
    rw [lab_unlab' ⟨r1, r2⟩]
    exact hlt

/-- The set of the twelve labels of degree five. -/
def pentSet (s m : ℤ) : Finset ℤ :=
  {0, s, s + 1, s + 2, 2 * s + 2, 2 * s + 4, m, m - s, m - s - 1, m - s - 2, m - 2 * s - 2,
    m - 2 * s - 4}

theorem mem_pentSet {s m u : ℤ} : u ∈ pentSet s m ↔ Pent s m u := by
  simp only [pentSet, Pent, Finset.mem_insert, Finset.mem_singleton]

theorem card_pentSet {s m : ℤ} (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) :
    (pentSet s m).card = 12 := by
  unfold pentSet
  repeat rw [Finset.card_insert_of_notMem (by
    simp only [Finset.mem_insert, Finset.mem_singleton]
    omega)]
  rw [Finset.card_singleton]

theorem helix_sum : ∑ u, (6 - ((helix hs hm).deg u : ℤ)) = 12 := by
  have hdeg : ∀ u : Fin (V s m), 6 - ((helix hs hm).deg u : ℤ) =
      if Pent s m (lab s u) then 1 else 0 := by
    intro u
    have h := len_cases (s := s) (m := m) (by exact_mod_cast hs) (by exact_mod_cast hm)
      (lab_range u).1 (lab_range u).2
    show 6 - (len s m (lab s u) : ℤ) = _
    rcases h with ⟨h1, h2⟩ | ⟨h1, h2⟩
    · simp [h1, h2]
    · simp [h1, h2]
  simp only [hdeg]
  rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, mul_one]
  have himg : univ.filter (fun u : Fin (V s m) => Pent (s : ℤ) m (lab s u)) =
      (pentSet (s : ℤ) m).image (unlab s (V s m) V_pos) := by
    ext u
    simp only [mem_filter, mem_univ, true_and, mem_image, mem_pentSet]
    constructor
    · intro h
      exact ⟨lab s u, h, unlab_lab u⟩
    · rintro ⟨z, hz, rfl⟩
      have hz' := hz
      unfold Pent at hz'
      have hs1 : (4 : ℤ) ≤ s := by exact_mod_cast hs
      have hm1 : 3 * (2 * (s : ℤ) + 5) ≤ m := by exact_mod_cast hm
      have hz2 : -(s : ℤ) ≤ z ∧ z ≤ (m : ℤ) + s := by omega
      rw [lab_unlab' hz2]
      exact hz
  rw [himg, Finset.card_image_of_injOn]
  · rw [card_pentSet (by exact_mod_cast hs) (by exact_mod_cast hm)]
    rfl
  · intro a ha b hb hab
    have ha' := Finset.mem_coe.1 ha
    have hb' := Finset.mem_coe.1 hb
    rw [mem_pentSet] at ha' hb'
    have ha2 := ha'
    have hb2 := hb'
    unfold Pent at ha2 hb2
    have hs1 : (4 : ℤ) ≤ s := by exact_mod_cast hs
    have hm1 : 3 * (2 * (s : ℤ) + 5) ≤ m := by exact_mod_cast hm
    have hz2 : -(s : ℤ) ≤ a ∧ a ≤ (m : ℤ) + s := by omega
    have hz3 : -(s : ℤ) ≤ b ∧ b ≤ (m : ℤ) + s := by omega
    have h2 := congrArg (lab s) hab
    rw [lab_unlab' hz2, lab_unlab' hz3] at h2
    exact h2

/-- **The helical maps are fullerene maps.** -/
theorem helix_isFullerene : (helix hs hm).T.dual.IsFullerene :=
  (helix hs hm).dual_isFullerene (helix_deg hs hm) (helix_connected hs hm) (helix_sum hs hm)

end Ful.Helix

end
