/-
FulDisc: triangulated discs inside a sphere.  Counting identities and the ring identity
`t = l + k - 6`.
-/
import FulCut

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

/-- Counting a filtered set fibrewise over a map. -/
theorem count_fiber {Q : Type*} [Fintype Q] [DecidableEq Q] (q : D → Q) (p : D → Prop) [DecidablePred p] :
    (univ.filter p).card = ∑ b, (univ.filter (fun d => q d = b ∧ p d)).card := by
  simp only [Finset.card_filter]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun d _ => ?_
  by_cases hp : p d <;> simp [hp]

namespace CMap

variable {M : CMap D}

theorem IsTriangulation.face_eq_iff (hT : M.IsTriangulation) {x d : D} :
    M.face x = M.face d ↔ x = d ∨ x = M.φ d ∨ x = M.φ (M.φ d) := by
  constructor
  · intro h
    have hinv : ∀ y, (M.φ y = d ∨ M.φ y = M.φ d ∨ M.φ y = M.φ (M.φ d)) =
        (y = d ∨ y = M.φ d ∨ y = M.φ (M.φ d)) := by
      intro y
      apply propext
      have h3 := (hT d).1
      constructor
      · rintro (h1 | h1 | h1)
        · right; right
          apply M.φ.injective
          rw [h1, h3]
        · left; exact M.φ.injective h1
        · right; left; exact M.φ.injective h1
      · rintro (h1 | h1 | h1)
        · right; left; rw [h1]
        · right; right; rw [h1]
        · left; rw [h1, h3]
    have key := Orb.eq_of_mk_eq (p := M.φ) (fun y => y = d ∨ y = M.φ d ∨ y = M.φ (M.φ d)) hinv h
    exact key.mpr (Or.inl rfl)
  · rintro (rfl | rfl | rfl)
    · rfl
    · exact M.face_φ d
    · rw [M.face_φ, M.face_φ]

theorem IsTriangulation.ne1 (hT : M.IsTriangulation) (d : D) : M.φ d ≠ d := (hT d).2

theorem IsTriangulation.ne2 (hT : M.IsTriangulation) (d : D) : M.φ (M.φ d) ≠ d := by
  intro h
  have h3 := (hT d).1
  rw [h] at h3
  exact (hT d).2 h3

theorem IsTriangulation.ne3 (hT : M.IsTriangulation) (d : D) : M.φ (M.φ d) ≠ M.φ d :=
  fun h => (hT d).2 (M.φ.injective h)

/-- Counting a predicate on the three corners of a triangle. -/
theorem IsTriangulation.card_face_and (hT : M.IsTriangulation) (P : D → Prop) [DecidablePred P] (d0 : D) :
    (univ.filter (fun d => M.face d = M.face d0 ∧ P d)).card =
      (if P d0 then 1 else 0) + (if P (M.φ d0) then 1 else 0) +
        (if P (M.φ (M.φ d0)) then 1 else 0) := by
  have hset : univ.filter (fun d => M.face d = M.face d0 ∧ P d) =
      ({d0, M.φ d0, M.φ (M.φ d0)} : Finset D).filter P := by
    ext x
    simp only [mem_filter, mem_univ, true_and, mem_insert, mem_singleton]
    rw [hT.face_eq_iff]
  rw [hset, Finset.card_filter, Finset.sum_insert, Finset.sum_insert, Finset.sum_singleton,
    add_assoc]
  · simp only [mem_singleton]
    exact fun h => hT.ne3 d0 h.symm
  · simp only [mem_insert, mem_singleton, not_or]
    exact ⟨fun h => hT.ne1 d0 h.symm, fun h => hT.ne2 d0 h.symm⟩

/-- Counting a predicate on the two darts of an edge. -/
theorem card_edge_and (M : CMap D) (P : D → Prop) [DecidablePred P] (d0 : D) :
    (univ.filter (fun d => M.edge d = M.edge d0 ∧ P d)).card =
      (if P d0 then 1 else 0) + (if P (M.α d0) then 1 else 0) := by
  have hset : univ.filter (fun d => M.edge d = M.edge d0 ∧ P d) =
      (univ.filter (fun d => M.edge d = M.edge d0)).filter P := by
    rw [Finset.filter_filter]
  rw [hset, Finset.card_filter]
  exact M.sum_edge (fun d => if P d then 1 else 0) d0

variable {C : SimpleCycle M} {S : Finset M.F}

/-- Number of corners of `S` at a vertex. -/
def cornerAt (S : Finset M.F) (v : M.V) : ℕ :=
  (univ.filter (fun d => M.tail d = v ∧ M.face d ∈ S)).card

/-- The curvature inside a side: the sum of `6 - deg` over interior vertices. -/
def SimpleCycle.curv (C : SimpleCycle M) (S : Finset M.F) : ℤ :=
  ∑ v ∈ C.intV S, (6 - (M.deg v : ℤ))

/-- The number of corners of a face lying on the cycle. -/
def SimpleCycle.t (C : SimpleCycle M) (f : M.F) : ℕ :=
  (univ.filter (fun d => M.face d = f ∧ M.tail d ∈ C.verts)).card

theorem IsTriangulation.corners_card (hT : M.IsTriangulation) (S : Finset M.F) :
    (univ.filter (fun d => M.face d ∈ S)).card = 3 * S.card := by
  rw [count_fiber M.face]
  have h0 : ∀ f, f ∉ S → (univ.filter (fun d => M.face d = f ∧ M.face d ∈ S)).card = 0 := by
    intro f hf
    rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    rintro d - ⟨rfl, h2⟩
    exact hf h2
  rw [← Finset.sum_subset (Finset.subset_univ S) (fun f _ hf => h0 f hf)]
  have h3 : ∀ f ∈ S, (univ.filter (fun d => M.face d = f ∧ M.face d ∈ S)).card = 3 := by
    intro f hf
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    have hf' : M.face d ∈ S := hf
    have := hT.card_face_and (fun x => M.face x ∈ S) d
    simp only [M.face_φ, hf', ite_true] at this
    exact this
  rw [Finset.sum_congr rfl h3, Finset.sum_const, smul_eq_mul, mul_comm]

theorem IsSide.corners_by_edge (h : IsSide C S) :
    (univ.filter (fun d => M.face d ∈ S)).card = 2 * (C.intE S).card + C.len := by
  rw [count_fiber M.edge]
  have h0 : ∀ e, e ∉ clE S → (univ.filter (fun d => M.edge d = e ∧ M.face d ∈ S)).card = 0 := by
    intro e he
    rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    rintro d - ⟨rfl, h2⟩
    exact he (mem_clE.2 ⟨d, rfl, h2⟩)
  rw [← Finset.sum_subset (Finset.subset_univ (clE S)) (fun e _ he => h0 e he),
    ← Finset.sum_sdiff h.edges_subset]
  have h2 : ∀ e ∈ clE S \ C.edges,
      (univ.filter (fun d => M.edge d = e ∧ M.face d ∈ S)).card = 2 := by
    intro e he
    obtain ⟨hn, hall⟩ := h.mem_intE.1 he
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
    have h1 := hall d rfl
    have h2 := hall (M.α d) (M.edge_α d)
    have := card_edge_and M (fun x => M.face x ∈ S) d
    simp only [h1, h2, ite_true] at this
    exact this
  have h1 : ∀ e ∈ C.edges,
      (univ.filter (fun d => M.edge d = e ∧ M.face d ∈ S)).card = 1 := by
    intro e he
    obtain ⟨i, rfl⟩ := C.exists_of_edge_mem he
    have hx := (h (C.dart i)).1 he
    have := card_edge_and M (fun x => M.face x ∈ S) (C.dart i)
    rw [this]
    by_cases a : M.face (C.dart i) ∈ S <;> by_cases b : M.face (M.α (C.dart i)) ∈ S
    · exact absurd (iff_of_true a b) hx
    · simp only [a, b, ite_true, ite_false]
    · simp only [a, b, ite_true, ite_false]
    · exact absurd (iff_of_false a b) hx
  rw [Finset.sum_congr rfl h2, Finset.sum_congr rfl h1, Finset.sum_const, Finset.sum_const,
    smul_eq_mul, smul_eq_mul, C.card_edges, mul_one, mul_comm]
  rfl

theorem IsSide.corners_by_vertex (h : IsSide C S) :
    (univ.filter (fun d => M.face d ∈ S)).card =
      ∑ v ∈ C.intV S, M.deg v + ∑ v ∈ C.verts, cornerAt S v := by
  rw [count_fiber M.tail]
  have h0 : ∀ v, v ∉ clV S → (univ.filter (fun d => M.tail d = v ∧ M.face d ∈ S)).card = 0 := by
    intro v hv
    rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    rintro d - ⟨rfl, h2⟩
    exact hv (mem_clV.2 ⟨d, rfl, h2⟩)
  rw [← Finset.sum_subset (Finset.subset_univ (clV S)) (fun v _ hv => h0 v hv),
    ← Finset.sum_sdiff h.verts_subset]
  congr 1
  refine Finset.sum_congr rfl fun v hv => ?_
  obtain ⟨hn, hall⟩ := h.mem_intV.1 hv
  unfold deg
  congr 1
  ext d
  simp only [mem_filter, mem_univ, true_and]
  exact ⟨fun a => a.1, fun a => ⟨a, hall d a⟩⟩

/-- The number of triangles of a disc: `T + 2 = 2 I + l`. -/
theorem IsSide.tri_count (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (h : IsSide C S) : S.card + 2 = 2 * (C.intV S).card + C.len := by
  have e1 := IsSide.euler_int hc hg h
  have e2 := h.corners_by_edge
  rw [hT.corners_card] at e2
  omega

/-- **Corner identity.** The total number of `S`-corners on the boundary is `3 l - 6 + k`. -/
theorem IsSide.boundary_corners (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (h : IsSide C S) :
    ((∑ v ∈ C.verts, cornerAt S v : ℕ) : ℤ) = 3 * C.len - 6 + C.curv S := by
  have e1 := h.tri_count hT hc hg
  have e2 := h.corners_by_vertex
  rw [hT.corners_card] at e2
  have e3 : C.curv S = 6 * ((C.intV S).card : ℤ) - ((∑ v ∈ C.intV S, M.deg v : ℕ) : ℤ) := by
    unfold SimpleCycle.curv
    rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul, Nat.cast_sum, mul_comm]
  rw [e3]
  omega

/-- Double count of the corners of `S` on the cycle. -/
theorem IsSide.sum_t (hS : ∀ f ∈ S, True) :
    ∑ f ∈ S, C.t f = ∑ v ∈ C.verts, cornerAt S v := by
  have key : (univ.filter (fun d => M.face d ∈ S ∧ M.tail d ∈ C.verts)).card =
      ∑ f ∈ S, C.t f := by
    rw [count_fiber M.face]
    have h0 : ∀ f, f ∉ S →
        (univ.filter (fun d => M.face d = f ∧ M.face d ∈ S ∧ M.tail d ∈ C.verts)).card = 0 := by
      intro f hf
      rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
      rintro d - ⟨rfl, h2, -⟩
      exact hf h2
    rw [← Finset.sum_subset (Finset.subset_univ S) (fun f _ hf => h0 f hf)]
    refine Finset.sum_congr rfl fun f hf => ?_
    unfold SimpleCycle.t
    congr 1
    ext d
    simp only [mem_filter, mem_univ, true_and]
    constructor
    · rintro ⟨a, -, b⟩
      exact ⟨a, b⟩
    · rintro ⟨a, b⟩
      exact ⟨a, a ▸ hf, b⟩
  have key2 : (univ.filter (fun d => M.face d ∈ S ∧ M.tail d ∈ C.verts)).card =
      ∑ v ∈ C.verts, cornerAt S v := by
    rw [count_fiber M.tail]
    have h0 : ∀ v, v ∉ C.verts →
        (univ.filter (fun d => M.tail d = v ∧ M.face d ∈ S ∧ M.tail d ∈ C.verts)).card = 0 := by
      intro v hv
      rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
      rintro d - ⟨rfl, -, h2⟩
      exact hv h2
    rw [← Finset.sum_subset (Finset.subset_univ C.verts) (fun v _ hv => h0 v hv)]
    refine Finset.sum_congr rfl fun v hv => ?_
    unfold cornerAt
    congr 1
    ext d
    simp only [mem_filter, mem_univ, true_and]
    constructor
    · rintro ⟨a, b, -⟩
      exact ⟨a, b⟩
    · rintro ⟨a, b⟩
      exact ⟨a, b, a ▸ hv⟩
  rw [← key, key2]

/-- A chord-free side: every edge of the closed region with both ends on the cycle is a cycle
edge. -/
def ChordFree (C : SimpleCycle M) (S : Finset M.F) : Prop :=
  ∀ d, M.edge d ∈ clE S → M.tail d ∈ C.verts → M.tail (M.α d) ∈ C.verts → M.edge d ∈ C.edges

theorem IsTriangulation.t_face (hT : M.IsTriangulation) (C : SimpleCycle M) (d : D) :
    C.t (M.face d) = (if M.tail d ∈ C.verts then 1 else 0) +
      (if M.tail (M.φ d) ∈ C.verts then 1 else 0) +
      (if M.tail (M.φ (M.φ d)) ∈ C.verts then 1 else 0) :=
  hT.card_face_and (fun x => M.tail x ∈ C.verts) d

/-- With an interior vertex and no chord, no triangle of `S` has all three corners on the cycle. -/
theorem IsSide.t_le_two (hT : M.IsTriangulation) (hc : M.Connected) (h : IsSide C S)
    (hcf : ChordFree C S) (hI : (C.intV S).Nonempty) {f : M.F} (hf : f ∈ S) : C.t f ≤ 2 := by
  by_contra hle
  obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
  have hfS : M.face d ∈ S := hf
  have ht := hT.t_face C d
  change ¬ C.t (M.face d) ≤ 2 at hle
  have m1 : M.tail d ∈ C.verts := by
    by_contra hn
    rw [ite_eq_right hn] at ht
    split_ifs at ht <;> omega
  have m2 : M.tail (M.φ d) ∈ C.verts := by
    by_contra hn
    rw [ite_eq_right hn] at ht
    split_ifs at ht <;> omega
  have m3 : M.tail (M.φ (M.φ d)) ∈ C.verts := by
    by_contra hn
    rw [ite_eq_right hn] at ht
    split_ifs at ht <;> omega
  have hall : ∀ x, M.face x = M.face d → M.edge x ∈ C.edges ∧ M.tail x ∈ C.verts := by
    intro x hx
    have hcl : M.edge x ∈ clE S := mem_clE.2 ⟨x, rfl, hx ▸ hfS⟩
    rcases hT.face_eq_iff.1 hx with rfl | rfl | rfl
    · exact ⟨hcf _ hcl m1 (by rw [← M.tail_φ]; exact m2), m1⟩
    · exact ⟨hcf _ hcl m2 (by rw [← M.tail_φ]; exact m3), m2⟩
    · exact ⟨hcf _ hcl m3 (by rw [← M.tail_φ, (hT d).1]; exact m1), m3⟩
  have hsupp : ∀ e, e ∉ C.edges → M.d2.mulVec (indF {M.face d}) e = 0 := by
    intro e he
    obtain ⟨y, rfl⟩ := Orb.mk_surjective _ e
    show M.d2.mulVec (indF {M.face d}) (M.edge y) = 0
    rw [d2_mulVec_edge]
    have h1 : M.face y ≠ M.face d := fun hy => he (hall y hy).1
    have h2 : M.face (M.α y) ≠ M.face d := fun hy => he (by
      have := (hall (M.α y) hy).1
      rwa [M.edge_α] at this)
    simp only [indF, mem_singleton, h1, h2, ite_false, add_zero]
  obtain ⟨f0, hf0⟩ := (IsSide.exists_mem C h).2
  have hf0' : f0 ≠ M.face d := fun hn => mem_compl.1 hf0 (hn ▸ hfS)
  have hf0S : f0 ∉ S := mem_compl.1 hf0
  rcases C.eq_zero_or_ind _ hsupp (M.d1_d2 _) with h0 | h0
  · rcases hc.ker_d2 h0 with h1 | h1
    · have := congrFun h1 (M.face d)
      simp only [indF, mem_singleton, ite_true, Pi.zero_apply] at this
      exact one_ne_zero this
    · have := congrFun h1 f0
      simp only [indF, mem_singleton, hf0', ite_false, Pi.one_apply] at this
      exact zero_ne_one this
  · have hker : M.d2.mulVec (indF {M.face d} + indF S) = 0 := by
      rw [Matrix.mulVec_add, h0, h.d2_indF C]
      funext e
      exact F2.add_self _
    have hzero : (indF {M.face d} + indF S) f0 = 0 := by
      simp only [Pi.add_apply, indF, mem_singleton, hf0', hf0S, ite_false, add_zero]
    obtain ⟨v, hv⟩ := hI
    obtain ⟨hvn, hvall⟩ := h.mem_intV.1 hv
    obtain ⟨y, rfl⟩ := Orb.mk_surjective _ v
    have hyS : M.face y ∈ S := hvall y rfl
    rcases hc.ker_d2 hker with h1 | h1
    · have hval := congrFun h1 (M.face y)
      simp only [Pi.add_apply, Pi.zero_apply, indF, mem_singleton, hyS, ite_true] at hval
      by_cases hy : M.face y = M.face d
      · exact hvn (hall y hy).2
      · rw [ite_eq_right hy] at hval
        simp at hval
    · have := congrFun h1 f0
      rw [hzero] at this
      exact zero_ne_one this

/-- The darts lying along the boundary of `S`. -/
def bdDarts (C : SimpleCycle M) (S : Finset M.F) : Finset D :=
  univ.filter fun x => M.face x ∈ S ∧ M.tail x ∈ C.verts ∧ M.tail (M.φ x) ∈ C.verts

/-- There is exactly one boundary dart on each cycle edge. -/
theorem IsSide.card_bdDarts (h : IsSide C S) (hcf : ChordFree C S) :
    (bdDarts C S).card = C.len := by
  unfold bdDarts
  rw [count_fiber M.edge]
  have h0 : ∀ e, e ∉ C.edges → (univ.filter (fun d => M.edge d = e ∧
      (M.face d ∈ S ∧ M.tail d ∈ C.verts ∧ M.tail (M.φ d) ∈ C.verts))).card = 0 := by
    intro e he
    rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    rintro d - ⟨rfl, h1, h2, h3⟩
    rw [M.tail_φ] at h3
    exact he (hcf d (mem_clE.2 ⟨d, rfl, h1⟩) h2 h3)
  rw [← Finset.sum_subset (Finset.subset_univ C.edges) (fun e _ he => h0 e he)]
  have h1 : ∀ e ∈ C.edges, (univ.filter (fun d => M.edge d = e ∧
      (M.face d ∈ S ∧ M.tail d ∈ C.verts ∧ M.tail (M.φ d) ∈ C.verts))).card = 1 := by
    intro e he
    obtain ⟨i, rfl⟩ := C.exists_of_edge_mem he
    have hx := (h (C.dart i)).1 he
    have := card_edge_and M (fun x => M.face x ∈ S ∧ M.tail x ∈ C.verts ∧
      M.tail (M.φ x) ∈ C.verts) (C.dart i)
    rw [this]
    have ha1 := C.tail_mem i
    have ha2 : M.tail (M.φ (C.dart i)) ∈ C.verts := by rw [M.tail_φ]; exact C.head_mem i
    have ha3 : M.tail (M.α (C.dart i)) ∈ C.verts := C.head_mem i
    have ha4 : M.tail (M.φ (M.α (C.dart i))) ∈ C.verts := by
      rw [M.tail_φ, M.α_α]; exact ha1
    by_cases a : M.face (C.dart i) ∈ S <;> by_cases b : M.face (M.α (C.dart i)) ∈ S
    · exact absurd (iff_of_true a b) hx
    · simp only [a, b, ha1, ha2, ha3, ha4, and_self, and_true, and_false, false_and, ite_true,
        ite_false]
    · simp only [a, b, ha1, ha2, ha3, ha4, and_self, and_true, and_false, false_and, ite_true,
        ite_false]
    · exact absurd (iff_of_false a b) hx
  rw [Finset.sum_congr rfl h1, Finset.sum_const, smul_eq_mul, C.card_edges, mul_one]

/-- The triangles with exactly two corners on the cycle number `l`. -/
theorem IsSide.card_t_two (hT : M.IsTriangulation) (hc : M.Connected) (h : IsSide C S)
    (hcf : ChordFree C S) (hI : (C.intV S).Nonempty) :
    (S.filter (fun f => C.t f = 2)).card = C.len := by
  rw [← h.card_bdDarts hcf]
  unfold bdDarts
  rw [count_fiber M.face]
  have h0 : ∀ f, f ∉ S → (univ.filter (fun d => M.face d = f ∧
      (M.face d ∈ S ∧ M.tail d ∈ C.verts ∧ M.tail (M.φ d) ∈ C.verts))).card = 0 := by
    intro f hf
    rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    rintro d - ⟨rfl, h2, -⟩
    exact hf h2
  rw [← Finset.sum_subset (Finset.subset_univ S) (fun f _ hf => h0 f hf), Finset.card_filter]
  refine Finset.sum_congr rfl fun f hf => ?_
  obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
  have hfS : M.face d ∈ S := hf
  have hle := h.t_le_two hT hc hcf hI hf
  have ht := hT.t_face C d
  have hcount := hT.card_face_and (fun x => M.face x ∈ S ∧ M.tail x ∈ C.verts ∧
    M.tail (M.φ x) ∈ C.verts) d
  simp only [M.face_φ, hfS, true_and, (hT d).1] at hcount
  show _ = (univ.filter _).card
  change _ = (univ.filter (fun x => M.face x = M.face d ∧ (M.face x ∈ S ∧ M.tail x ∈ C.verts ∧
    M.tail (M.φ x) ∈ C.verts))).card
  rw [hcount]
  change C.t (M.face d) ≤ 2 at hle
  change (if C.t (M.face d) = 2 then 1 else 0) = _
  rw [ht] at hle ⊢
  by_cases a : M.tail d ∈ C.verts <;> by_cases b : M.tail (M.φ d) ∈ C.verts <;>
    by_cases c : M.tail (M.φ (M.φ d)) ∈ C.verts <;>
    simp [a, b, c, -CMap.φ_apply] at hle ⊢

/-- **Ring identity.** For a side with no chord and at least one interior vertex, the number of
triangles with exactly one corner on the cycle is `l + k - 6`. -/
theorem IsSide.ring_identity (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (h : IsSide C S) (hcf : ChordFree C S) (hI : (C.intV S).Nonempty) :
    ((S.filter (fun f => C.t f = 1)).card : ℤ) = C.len + C.curv S - 6 := by
  have e1 := h.boundary_corners hT hc hg
  rw [← IsSide.sum_t (fun _ _ => trivial)] at e1
  have e2 := h.card_t_two hT hc hcf hI
  have e3 : ∑ f ∈ S, C.t f =
      (S.filter (fun f => C.t f = 1)).card + 2 * (S.filter (fun f => C.t f = 2)).card := by
    rw [Finset.card_filter, Finset.card_filter, Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun f hf => ?_
    have hle := h.t_le_two hT hc hcf hI hf
    by_cases a : C.t f = 1
    · simp [a]
    · by_cases b : C.t f = 2
      · simp [b]
      · have : C.t f = 0 := by omega
        simp [this]
  rw [e3, e2] at e1
  push_cast at e1
  linarith

end CMap

end Ful

end
