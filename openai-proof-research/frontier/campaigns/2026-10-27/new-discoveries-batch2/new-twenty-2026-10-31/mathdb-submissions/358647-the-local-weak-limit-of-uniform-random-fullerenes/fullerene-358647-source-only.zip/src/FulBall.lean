/-
FulBall: the development is injective on balls, and a large flat ball without short essential
cycles is isomorphic to the explicit lattice ball.
-/
import FulInj

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

theorem ex_natAbs (u : ℕ) : (ex u).natAbs ≤ 1 := by
  unfold ex
  have h : u % 6 < 6 := Nat.mod_lt _ (by norm_num)
  interval_cases (u % 6) <;> simp [exT]

theorem ey_natAbs (u : ℕ) : (ey u).natAbs ≤ 1 := by
  unfold ey
  have h : u % 6 < 6 := Nat.mod_lt _ (by norm_num)
  interval_cases (u % 6) <;> simp [eyT]

/-- Every nonzero lattice vector lies in a sector spanned by two adjacent unit vectors. -/
theorem sector (dx dy : ℤ) (h : dx ≠ 0 ∨ dy ≠ 0) :
    ∃ u a b : ℕ, u < 6 ∧ 1 ≤ a + b ∧ a + b ≤ dx.natAbs + dy.natAbs ∧
      dx = a * ex u + b * ex ((u + 1) % 6) ∧ dy = a * ey u + b * ey ((u + 1) % 6) := by
  by_cases h0 : 0 ≤ dx ∧ 0 ≤ dy
  · refine ⟨0, dx.toNat, dy.toNat, by norm_num, by omega, by omega, ?_, ?_⟩ <;>
      simp [ex, ey, exT, eyT] <;> omega
  by_cases h1 : dx ≤ 0 ∧ 0 ≤ dx + dy
  · refine ⟨1, (dx + dy).toNat, (-dx).toNat, by norm_num, by omega, by omega, ?_, ?_⟩ <;>
      simp [ex, ey, exT, eyT] <;> omega
  by_cases h2 : 0 ≤ dy ∧ dx + dy ≤ 0
  · refine ⟨2, dy.toNat, (-dx - dy).toNat, by norm_num, by omega, by omega, ?_, ?_⟩ <;>
      simp [ex, ey, exT, eyT] <;> omega
  by_cases h3 : dx ≤ 0 ∧ dy ≤ 0
  · refine ⟨3, (-dx).toNat, (-dy).toNat, by norm_num, by omega, by omega, ?_, ?_⟩ <;>
      simp [ex, ey, exT, eyT] <;> omega
  by_cases h4 : 0 ≤ dx ∧ dx + dy ≤ 0
  · refine ⟨4, (-dx - dy).toNat, dx.toNat, by norm_num, by omega, by omega, ?_, ?_⟩ <;>
      simp [ex, ey, exT, eyT] <;> omega
  · refine ⟨5, (-dy).toNat, (dx + dy).toNat, by norm_num, by omega, by omega, ?_, ?_⟩ <;>
      simp [ex, ey, exT, eyT] <;> omega

/-- The explicit triangular-lattice ball. -/
inductive LReach : ℕ → ℤ × ℤ → Prop
  | zero : LReach 0 (0, 0)
  | stay {n : ℕ} {z : ℤ × ℤ} : LReach n z → LReach (n + 1) z
  | step {n : ℕ} {z : ℤ × ℤ} (u : ℕ) (hu : u < 6) :
      LReach n z → LReach (n + 1) (z.1 + ex u, z.2 + ey u)

theorem LReach.L1_le {n : ℕ} {z : ℤ × ℤ} (h : LReach n z) : L1 z ≤ 2 * n := by
  induction h with
  | zero => simp [L1]
  | stay _ ih => omega
  | step u _ _ ih =>
    have h1 := ex_natAbs u
    have h2 := ey_natAbs u
    simp only [L1] at ih ⊢
    omega

namespace CMap

variable {M : CMap D}

theorem pow_mod_of_eq {x : D} (hdeg : M.deg (M.tail x) = 6) {a b : ℕ}
    (h : (M.σ ^ a) x = (M.σ ^ b) x) : a % 6 = b % 6 := by
  have h6 := (pow_eq_self_iff_of_deg hdeg (by norm_num) 6).2 (dvd_refl 6)
  have ha := pow_mod_apply h6 a
  have hb := pow_mod_apply h6 b
  rw [← ha, ← hb] at h
  have hlta := Nat.mod_lt a (show 6 > 0 by norm_num)
  have hltb := Nat.mod_lt b (show 6 > 0 by norm_num)
  set p := a % 6
  set q := b % 6
  have key : ∀ {s t : ℕ}, s ≤ t → t < 6 → (M.σ ^ s) x = (M.σ ^ t) x → s = t := by
    intro s t hst ht hsx
    have h1 : (M.σ ^ (t - s)) ((M.σ ^ s) x) = (M.σ ^ s) x := by
      rw [← Perm.mul_apply, ← pow_add, show t - s + s = t by omega, ← hsx]
    have hd2 : M.deg (M.tail ((M.σ ^ s) x)) = 6 := by rw [tail_pow]; exact hdeg
    have hdvd := (pow_eq_self_iff_of_deg hd2 (by norm_num) _).1 h1
    obtain ⟨c, hc⟩ := hdvd
    omega
  rcases Nat.le_total p q with hpq | hpq
  · exact key hpq hltb h
  · exact (key hpq hlta h.symm).symm

/-- The head of a rotated development dart is the next lattice point. -/
theorem head_psi (hT : M.IsTriangulation) {d0 : D} {R : ℕ} (hF : M.FlatTo (M.tail d0) R)
    {z : ℤ × ℤ} {u : ℕ} (hu : u < 6) (h : L1 z + 6 ≤ R) :
    M.tail (M.α (M.psi d0 z u)) = M.tail (M.dev d0 (z.1 + ex u) (z.2 + ey u)) := by
  rw [← tail_stp, psi_E hT hF hu h, tail_psi]

/-- Injectivity along geodesics of the development. -/
theorem dev_tail_ne (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hs : M.IsSimple)
    (hdeg : ∀ v, M.deg v ≤ 6) {d0 : D} {R : ℕ} (hF : M.FlatTo (M.tail d0) R) {L0 : ℕ}
    (hsys : ∀ (C : SimpleCycle M) (S : Finset M.F), Essential C S → L0 < C.len) {Λ : ℕ}
    (hR : Λ + L0 + bnd L0 + 7 ≤ R) :
    ∀ n, n ≤ L0 → ∀ (x y : ℤ) (u a b : ℕ), u < 6 → a + b = n → 1 ≤ n →
      x.natAbs + y.natAbs + 2 * n ≤ Λ →
      M.tail (M.dev d0 x y) ≠ M.tail (M.dev d0 (x + a * ex u + b * ex ((u + 1) % 6))
        (y + a * ey u + b * ey ((u + 1) % 6))) := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  intro hnL x y u a b hu hab hn1 hbound hcl
  set u' := (u + 1) % 6 with hu'
  have hu'lt : u' < 6 := Nat.mod_lt _ (by norm_num)
  let p : ℕ → ℤ × ℤ := fun i =>
    (x + ((min i a : ℕ) : ℤ) * ex u + ((i - a : ℕ) : ℤ) * ex u',
     y + ((min i a : ℕ) : ℤ) * ey u + ((i - a : ℕ) : ℤ) * ey u')
  let v : ℕ → ℕ := fun i => if i < a then u else u'
  have hpLe : ∀ k, k ≤ a → p k = (x + (k : ℤ) * ex u, y + (k : ℤ) * ey u) := by
    intro k hk
    simp only [p, min_eq_left hk, Nat.sub_eq_zero_of_le hk]
    simp
  have hpGe : ∀ k, a ≤ k → p k =
      (x + (a : ℤ) * ex u + ((k - a : ℕ) : ℤ) * ex u',
       y + (a : ℤ) * ey u + ((k - a : ℕ) : ℤ) * ey u') := by
    intro k hk
    simp only [p, min_eq_right hk]
  have hstep : ∀ i, i < n → p (i + 1) = ((p i).1 + ex (v i), (p i).2 + ey (v i)) := by
    intro i _
    by_cases h1 : i < a
    · have e : v i = u := ite_eq_left h1
      rw [e, hpLe (i + 1) (by omega), hpLe i (by omega)]
      apply Prod.ext <;> simp only <;> push_cast <;> ring
    · have e : v i = u' := ite_eq_right h1
      rw [e, hpGe (i + 1) (by omega), hpGe i (by omega), show i + 1 - a = (i - a) + 1 by omega]
      apply Prod.ext <;> simp only <;> push_cast <;> ring
  have hL1 : ∀ i, i ≤ n → L1 (p i) ≤ x.natAbs + y.natAbs + 2 * i := by
    intro i
    induction i with
    | zero =>
      intro _
      rw [hpLe 0 (Nat.zero_le _)]
      simp [L1]
    | succ i ih' =>
      intro hi
      have h1 := ih' (by omega)
      rw [hstep i (by omega)]
      have h2 := ex_natAbs (v i)
      have h3 := ey_natAbs (v i)
      simp only [L1] at h1 ⊢
      omega
  have hreg : ∀ i, i ≤ n → L1 (p i) ≤ Λ := fun i hi => by
    have := hL1 i hi
    omega
  have hp0 : p 0 = (x, y) := by
    rw [hpLe 0 (Nat.zero_le _)]
    simp
  have hpn : p n = (x + a * ex u + b * ex u', y + a * ey u + b * ey u') := by
    rw [hpGe n (by omega), show n - a = b by omega]
  have hclose : M.tail (M.dev d0 (p n).1 (p n).2) = M.tail (M.dev d0 (p 0).1 (p 0).2) := by
    rw [hpn, hp0]
    exact hcl.symm
  have hv6 : ∀ i, v i < 6 := fun i => by
    show (if i < a then u else u') < 6
    split_ifs
    · exact hu
    · exact hu'lt
  have hE : ∀ i, i < n → M.tail (M.α (M.psi d0 (p i) (v i))) =
      M.tail (M.dev d0 (p (i + 1)).1 (p (i + 1)).2) := by
    intro i hi
    rw [head_psi hT hF (hv6 i) (by have := hreg i hi.le; omega), hstep i hi]
  have key : ∀ i j, i < j → j < n →
      M.tail (M.dev d0 (p i).1 (p i).2) ≠ M.tail (M.dev d0 (p j).1 (p j).2) := by
    intro i j hij hj heq
    have hbd := hL1 i (by omega)
    simp only [L1] at hbd
    by_cases h1 : j ≤ a
    · refine ih (j - i) (by omega) (by omega) (p i).1 (p i).2 u (j - i) 0 hu (by omega) (by omega)
        (by omega) ?_
      rw [heq, hpLe j h1, hpLe i (by omega)]
      congr 2 <;> push_cast [Nat.cast_sub hij.le] <;> ring
    · by_cases h2 : a ≤ i
      · refine ih (j - i) (by omega) (by omega) (p i).1 (p i).2 u' (j - i) 0 hu'lt (by omega)
          (by omega) (by omega) ?_
        rw [heq, hpGe j (by omega), hpGe i h2]
        have hsub : ((j - a : ℕ) : ℤ) = ((i - a : ℕ) : ℤ) + ((j - i : ℕ) : ℤ) := by omega
        rw [hsub]
        congr 2 <;> push_cast <;> ring
      · refine ih (j - i) (by omega) (by omega) (p i).1 (p i).2 u (a - i) (j - a) hu (by omega)
          (by omega) (by omega) ?_
        rw [heq, hpGe j (by omega), hpLe i (by omega)]
        have hsub : (a : ℤ) = (i : ℤ) + ((a - i : ℕ) : ℤ) := by omega
        congr 2
        · rw [hsub]; push_cast; ring
        · rw [hsub]; push_cast; ring
  by_cases hn3 : 3 ≤ n
  · exact collision_false hT hc hg hs hdeg hF hsys p v hn3 hnL hu (fun _ => rfl) hstep hreg hR
      (fun i j hi hj hq => by
        by_contra hne
        rcases Nat.lt_or_gt_of_ne hne with h | h
        · exact key i j h hj hq
        · exact key j i h hi hq.symm) hclose
  · have hreg0 := hreg 0 (Nat.zero_le _)
    by_cases hn1' : n = 1
    · subst hn1'
      apply hs.1 (M.psi d0 (p 0) (v 0))
      rw [tail_psi, hE 0 (by norm_num)]
      exact hclose.symm
    · have hn2 : n = 2 := by omega
      subst hn2
      have hreg1 := hreg 1 (by norm_num)
      have hhead1 := hE 1 (by norm_num)
      have hhead0 := hE 0 (by norm_num)
      have heq : M.α (M.psi d0 (p 0) (v 0)) = M.psi d0 (p 1) (v 1) := by
        apply hs.2
        · rw [hhead0, tail_psi]
        · rw [M.α_α, tail_psi, hhead1]
          exact hclose.symm
      have hflat1 : M.deg (M.tail (M.dev d0 (p 1).1 (p 1).2)) = 6 :=
        hF _ ((reach_dev (M := M) d0 (p 1).1 (p 1).2).mono (by simp only [L1] at hreg1; omega))
      have hfα : M.Fl (M.α (M.psi d0 (p 0) (v 0))) := by
        apply Fl_of_deg
        rw [hhead0]
        exact hflat1
      have hα := α_eq_of_Fl hfα
      rw [show M.stp (M.psi d0 (p 0) (v 0)) = M.psi d0 (p (0 + 1)) (v 0) from by
        rw [psi_E hT hF (hv6 0) (by have := hreg0; omega), hstep 0 (by norm_num)]] at hα
      rw [heq] at hα
      have hexp : (M.σ ^ (v 1)) (M.dev d0 (p 1).1 (p 1).2) =
          (M.σ ^ (3 + v 0)) (M.dev d0 (p 1).1 (p 1).2) := by
        have h' := hα
        simp only [psi, pow_add, Perm.mul_apply, pow_succ', pow_zero, mul_one, pow_one] at h' ⊢
        exact h'
      have hmod := pow_mod_of_eq hflat1 hexp
      have hv0 := hv6 0
      have hv1 := hv6 1
      have hu'def : u' = (u + 1) % 6 := rfl
      simp only [v] at hmod hv0 hv1
      split_ifs at hmod hv0 hv1 <;> omega

/-- Injectivity of the development on balls. -/
theorem dev_inj (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hs : M.IsSimple)
    (hdeg : ∀ v, M.deg v ≤ 6) {d0 : D} {R : ℕ} (hF : M.FlatTo (M.tail d0) R) {L0 : ℕ}
    (hsys : ∀ (C : SimpleCycle M) (S : Finset M.F), Essential C S → L0 < C.len) {Λ : ℕ}
    (hR : Λ + L0 + bnd L0 + 7 ≤ R) {z w : ℤ × ℤ} (hzw : L1 z + L1 w ≤ L0)
    (hbd : L1 z + 2 * L0 ≤ Λ)
    (h : M.tail (M.dev d0 z.1 z.2) = M.tail (M.dev d0 w.1 w.2)) : z = w := by
  by_contra hne
  have hd : w.1 - z.1 ≠ 0 ∨ w.2 - z.2 ≠ 0 := by
    by_contra hn
    push Not at hn
    exact hne (Prod.ext (by omega) (by omega))
  obtain ⟨u, a, b, hu, hab1, hab2, hdx, hdy⟩ := sector _ _ hd
  have hL1 : L1 z = z.1.natAbs + z.2.natAbs := rfl
  have hL2 : L1 w = w.1.natAbs + w.2.natAbs := rfl
  have hnL : a + b ≤ L0 := by omega
  refine dev_tail_ne hT hc hg hs hdeg hF hsys hR (a + b) hnL z.1 z.2 u a b hu rfl hab1
    (by omega) ?_
  have hx : z.1 + a * ex u + b * ex ((u + 1) % 6) = w.1 := by linarith
  have hy : z.2 + a * ey u + b * ey ((u + 1) % 6) = w.2 := by linarith
  rw [h, hx, hy]

/-- **The local structure lemma.** If there is no essential cycle of length at most `4 ρ + 4` and
every vertex within radius `R` of the root is flat, the development is an isomorphism of the
explicit lattice ball of radius `ρ` onto the radius-`ρ` ball of the map. -/
theorem local_ball (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0) (hs : M.IsSimple)
    (hdeg : ∀ v, M.deg v ≤ 6) (d0 : D) (ρ : ℕ)
    (hF : M.FlatTo (M.tail d0) (2 * ρ + 2 + 2 * (4 * ρ + 4) + (4 * ρ + 4) + bnd (4 * ρ + 4) + 7))
    (hsys : ∀ (C : SimpleCycle M) (S : Finset M.F), Essential C S → 4 * ρ + 4 < C.len) :
    (∀ z, LReach ρ z → M.Reach (M.tail d0) ρ (M.tail (M.dev d0 z.1 z.2))) ∧
    (∀ v, M.Reach (M.tail d0) ρ v → ∃ z, LReach ρ z ∧ M.tail (M.dev d0 z.1 z.2) = v) ∧
    (∀ z w, LReach (ρ + 1) z → LReach (ρ + 1) w →
      M.tail (M.dev d0 z.1 z.2) = M.tail (M.dev d0 w.1 w.2) → z = w) ∧
    (∀ z w, LReach ρ z → LReach ρ w →
      ((∃ u, u < 6 ∧ w = (z.1 + ex u, z.2 + ey u)) ↔
        ∃ d, M.tail d = M.tail (M.dev d0 z.1 z.2) ∧ M.tail (M.α d) = M.tail (M.dev d0 w.1 w.2))) := by
  set R := 2 * ρ + 2 + 2 * (4 * ρ + 4) + (4 * ρ + 4) + bnd (4 * ρ + 4) + 7 with hRdef
  have hinj : ∀ z w, LReach (ρ + 1) z → LReach (ρ + 1) w →
      M.tail (M.dev d0 z.1 z.2) = M.tail (M.dev d0 w.1 w.2) → z = w := by
    intro z w hz hw heq
    have h1 := hz.L1_le
    have h2 := hw.L1_le
    exact dev_inj hT hc hg hs hdeg hF hsys (Λ := 2 * ρ + 2 + 2 * (4 * ρ + 4)) (by omega) (by omega)
      (by omega) heq
  have hdart : ∀ {z : ℤ × ℤ} {d : D}, L1 z ≤ 2 * ρ → M.tail d = M.tail (M.dev d0 z.1 z.2) →
      ∃ u, u < 6 ∧ M.psi d0 z u = d := by
    intro z d hz ht
    have hdg : M.deg (M.tail (M.dev d0 z.1 z.2)) = 6 :=
      hF _ ((reach_dev (M := M) d0 z.1 z.2).mono (by simp only [L1] at hz; omega))
    have h6 := (pow_eq_self_iff_of_deg hdg (by norm_num) 6).2 (dvd_refl 6)
    obtain ⟨n, -, hn⟩ := (Orb.mk_eq_iff.1 ht.symm : SameCycle M.σ _ d).exists_pow_eq'
    refine ⟨n % 6, Nat.mod_lt _ (by norm_num), ?_⟩
    show (M.σ ^ (n % 6)) (M.dev d0 z.1 z.2) = d
    rw [pow_mod_apply h6, hn]
  refine ⟨?_, ?_, hinj, ?_⟩
  · have key : ∀ n z, LReach n z → n ≤ ρ → M.Reach (M.tail d0) n (M.tail (M.dev d0 z.1 z.2)) := by
      intro n z hz
      induction hz with
      | zero =>
        intro _
        simp only [dev, zpow_zero, Perm.one_apply]
        exact Reach.zero
      | stay _ ih =>
        intro hn
        exact Reach.stay (ih (by omega))
      | step u hu hz ih =>
        intro hn
        have h1 := hz.L1_le
        have h2 := Reach.step (M.psi d0 _ u) (tail_psi _ _ _) (ih (by omega))
        rwa [head_psi hT hF hu (by omega)] at h2
    intro z hz
    exact key ρ z hz le_rfl
  · have key : ∀ n v, M.Reach (M.tail d0) n v → n ≤ ρ →
        ∃ z, LReach n z ∧ M.tail (M.dev d0 z.1 z.2) = v := by
      intro n v hr
      induction hr with
      | zero =>
        intro _
        refine ⟨(0, 0), LReach.zero, ?_⟩
        simp only [dev, zpow_zero, Perm.one_apply]
      | stay _ ih =>
        intro hn
        obtain ⟨z, hz, ht⟩ := ih (by omega)
        exact ⟨z, LReach.stay hz, ht⟩
      | step d ht _ ih =>
        intro hn
        obtain ⟨z, hz, hzt⟩ := ih (by omega)
        have h1 := hz.L1_le
        obtain ⟨u, hu, hψ⟩ := hdart (by omega) (ht.trans hzt.symm)
        refine ⟨(z.1 + ex u, z.2 + ey u), LReach.step u hu hz, ?_⟩
        rw [← hψ]
        exact (head_psi hT hF hu (by omega)).symm
    intro v hv
    exact key ρ v hv le_rfl
  · intro z w hz hw
    have h1 := hz.L1_le
    constructor
    · rintro ⟨u, hu, rfl⟩
      exact ⟨M.psi d0 z u, tail_psi _ _ _, head_psi hT hF hu (by omega)⟩
    · rintro ⟨d, ht, hh⟩
      obtain ⟨u, hu, hψ⟩ := hdart (by omega) ht
      refine ⟨u, hu, hinj _ _ (LReach.stay hw) (LReach.step u hu hz) ?_⟩
      rw [← hψ] at hh
      rw [head_psi hT hF hu (by omega)] at hh
      exact hh.symm

end CMap

end Ful

end
