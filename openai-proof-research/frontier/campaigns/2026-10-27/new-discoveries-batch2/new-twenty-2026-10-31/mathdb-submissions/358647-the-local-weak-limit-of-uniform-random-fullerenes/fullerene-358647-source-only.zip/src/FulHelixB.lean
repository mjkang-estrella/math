/-
FulHelixB: the local laws of the helical rotation table for the remaining vertices.
-/
import FulHelixA

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace Ful.Helix

theorem get_mid {α} (a b : α) (l t : List α) : (a :: (l ++ b :: t)).getD (1 + l.length) a = b := by
  have : (1 + l.length) = (l.length + 1) := by omega
  rw [this, List.getD_cons_succ]
  induction l with
  | nil => rfl
  | cons x xs ih => simp

private theorem getD_of_len {α} (d : α) (l t : List α) (i : ℕ) :
    (l ++ t).getD (l.length + i) d = t.getD i d := by
  induction l with
  | nil => simp
  | cons x xs ih =>
    rw [List.length_cons, show xs.length + 1 + i = (xs.length + i) + 1 by omega]
    show ((x :: (xs ++ t)).getD ((xs.length + i) + 1) d) = _
    rw [List.getD_cons_succ]
    exact ih

theorem get_up0 {α} (a b : α) (l t : List α) (d : α) :
    (a :: (l ++ b :: t)).getD (2 + l.length) d = t.getD 0 d := by
  rw [show 2 + l.length = (l.length + 1) + 1 by omega, List.getD_cons_succ,
    show l.length + 1 = l.length + 1 from rfl, getD_of_len, List.getD_cons_succ]

theorem get_up1 {α} (a b : α) (l t : List α) (d : α) :
    (a :: (l ++ b :: t)).getD (3 + l.length) d = t.getD 1 d := by
  rw [show 3 + l.length = (l.length + 2) + 1 by omega, List.getD_cons_succ, getD_of_len,
    List.getD_cons_succ]

@[simp] theorem get_mid' {α} (a b : α) (l t : List α) (d : α) :
    (a :: (l ++ b :: t)).getD (1 + l.length) d = b := by
  rw [show 1 + l.length = l.length + 1 by omega, List.getD_cons_succ, ← Nat.add_zero l.length,
    getD_of_len]
  rfl

theorem get_up0' {α} (a b : α) (l t : List α) (d : α) :
    (a :: (l ++ b :: t)).getD (1 + l.length + 1) d = t.getD 0 d := by
  rw [show 1 + l.length + 1 = 2 + l.length by omega, get_up0]

theorem get_up1' {α} (a b : α) (l t : List α) (d : α) :
    (a :: (l ++ b :: t)).getD (2 + l.length + 1) d = t.getD 1 d := by
  rw [show 2 + l.length + 1 = 3 + l.length by omega, get_up1]

theorem mod_self_of_eq {a b : ℕ} (h : a = b) : a % b = 0 := by rw [h, Nat.mod_self]

macro "reduce_u" : tactic =>
  `(tactic| simp (disch := omega) only [nz, iz, len, Nb_int, Nb_zero, Nb_mid, Nb_m, Nb_intB, low_gen,
      low_cf, up_gen, up_cf, Ix_int, Ix_zero, Ix_mid, Ix_m, Ix_intB, intA, ifT, ifF, cf_a, cf_b, cf_c,
      cf_d, cf_e, cf_f, cfIx_a, cfIx_b0, cfIx_b1, cfIx_b2, cfIx_c, cfIx_d, cfIx_e, cfIx_f,
      List.length_cons, List.length_nil, List.length_append, List.cons_append, List.nil_append,
      List.map_cons, List.map_nil, get0, get1, get2, get3, get4, get5, get_mid', get_up0, get_up1,
      get_up0', get_up1', ifT, ifF, mod_self_of_eq, Nat.add_mod_right, Nat.mod_self, Nat.reduceAdd, Nat.reduceMod,
      Nat.reduceSub, Nat.zero_add, Nat.add_zero, Nat.mod_eq_of_lt, ↓reduceIte, ite_true, ite_false,
      and_true, true_and])

variable {s m u : ℤ} {k : ℕ}

theorem law_zero (hs : 2 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h0 : u = 0)
    (hk : k < len s m u) : Law s m u k := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hlen : len s m u = 5 := by
    show (Nb s m u).length = 5
    rw [Nb_zero h0]; rfl
  rw [hlen] at hk
  unfold Law
  interval_cases k <;> reduce_u <;> omega

theorem law_m (hs : 2 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h0 : u = m)
    (hk : k < len s m u) : Law s m u k := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hlen : len s m u = 5 := by
    show (Nb s m u).length = 5
    rw [Nb_m (by omega) h0]; rfl
  rw [hlen] at hk
  unfold Law
  interval_cases k <;> reduce_u <;> omega

theorem law_intB (hs : 2 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : m < u) (h2 : u ≤ m + s)
    (hk : k < len s m u) : Law s m u k := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hlen : len s m u = 6 := by
    show (Nb s m u).length = 6
    rw [Nb_intB (by omega) h1, List.length_map]; rfl
  rw [hlen] at hk
  have hc : u = m + 1 ∨ u = m + s ∨ (m + 1 < u ∧ u < m + s) := by omega
  unfold Law
  rcases hc with hc | hc | ⟨hc1, hc2⟩ <;> interval_cases k <;> reduce_u <;> omega

end Ful.Helix
