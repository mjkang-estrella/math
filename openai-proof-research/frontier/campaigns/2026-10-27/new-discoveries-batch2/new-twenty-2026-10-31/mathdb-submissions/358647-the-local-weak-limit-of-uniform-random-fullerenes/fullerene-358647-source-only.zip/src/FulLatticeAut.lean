/-
FulLatticeAut: the hexagonal lattice of Eq. (3) is vertex-transitive, and the ball fraction is
invariant under graph isomorphism (fidelity lemmas: the choice of root and of class representative
are immaterial).
-/
import FulEndpoint

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful.Stmt

open scoped Classical

theorem bit_not (c : Bool) : bit (!c) = 1 - bit c := by
  cases c <;> simp [bit]

/-- Translations of the lattice. -/
def hexTrans (a b : ℤ) : hexLattice ≃g hexLattice where
  toFun p := (p.1 + a, p.2.1 + b, p.2.2)
  invFun p := (p.1 - a, p.2.1 - b, p.2.2)
  left_inv p := by obtain ⟨x, y, c⟩ := p; simp
  right_inv p := by obtain ⟨x, y, c⟩ := p; simp
  map_rel_iff' {p q} := by
    show hexDist4 (p.1 + a, p.2.1 + b, p.2.2) (q.1 + a, q.2.1 + b, q.2.2) = 4 ↔ hexDist4 p q = 4
    have : hexDist4 (p.1 + a, p.2.1 + b, p.2.2) (q.1 + a, q.2.1 + b, q.2.2) = hexDist4 p q := by
      unfold hexDist4
      ring
    rw [this]

/-- The point reflection of the lattice swapping the sublattices. -/
def hexRefl : hexLattice ≃g hexLattice where
  toFun p := (-p.1, -p.2.1, !p.2.2)
  invFun p := (-p.1, -p.2.1, !p.2.2)
  left_inv p := by obtain ⟨x, y, c⟩ := p; simp
  right_inv p := by obtain ⟨x, y, c⟩ := p; simp
  map_rel_iff' {p q} := by
    show hexDist4 (-p.1, -p.2.1, !p.2.2) (-q.1, -q.2.1, !q.2.2) = 4 ↔ hexDist4 p q = 4
    have : hexDist4 (-p.1, -p.2.1, !p.2.2) (-q.1, -q.2.1, !q.2.2) = hexDist4 p q := by
      unfold hexDist4
      simp only [bit_not]
      ring
    rw [this]

/-- The hexagonal lattice is vertex-transitive, so the root in the statement is immaterial. -/
theorem hex_vertexTransitive (a b : ℤ × ℤ × Bool) : ∃ e : hexLattice ≃g hexLattice, e a = b := by
  by_cases hc : a.2.2 = b.2.2
  · refine ⟨hexTrans (b.1 - a.1) (b.2.1 - a.2.1), ?_⟩
    show (a.1 + (b.1 - a.1), a.2.1 + (b.2.1 - a.2.1), a.2.2) = b
    ext <;> simp [hc]
  · have hc' : (!a.2.2) = b.2.2 := by
      cases ha : a.2.2 <;> cases hb : b.2.2 <;> simp_all
    refine ⟨hexRefl.trans (hexTrans (b.1 + a.1) (b.2.1 + a.2.1)), ?_⟩
    show (-a.1 + (b.1 + a.1), -a.2.1 + (b.2.1 + a.2.1), !a.2.2) = b
    ext <;> simp [hc']

/-- Graph isomorphism preserves the ball fraction: `fullereneBallProb` is independent of the
choice of representatives of the classes. -/
theorem ballFraction_congr {n : ℕ} {G G' : SimpleGraph (Fin n)} (e : G ≃g G') (r : ℕ)
    {W : Type*} (K : SimpleGraph W) (o : W) :
    ballFraction G r K o = ballFraction G' r K o := by
  have key : ∀ v, RootedBallIso G' (e v) G v r := by
    intro v
    exact Ful.rootedBallIso_of_local (G := G') (H := G) (fun a => e a) v r
      (fun a b _ _ hab => e.map_adj_iff.2 hab)
      (fun a b _ _ hab => e.injective hab)
      (fun a _ w hw => ⟨e.symm w, by
        have := e.symm.map_adj_iff.2 hw
        simpa using this, by simp⟩)
  rw [Ful.ballFraction_eq, Ful.ballFraction_eq]
  congr 1
  have hcard : Ful.goodCount G r K o = Ful.goodCount G' r K o := by
    unfold Ful.goodCount
    apply Finset.card_bij (fun v _ => e v)
    · intro v hv
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hv ⊢
      exact Ful.RootedBallIso.trans (key v) hv
    · intro a _ b _ h
      exact e.injective h
    · intro w hw
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hw
      refine ⟨e.symm w, ?_, by simp⟩
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      have h1 : RootedBallIso G' w G (e.symm w) r := by
        have := key (e.symm w)
        simpa using this
      exact Ful.RootedBallIso.trans (Ful.RootedBallIso.symm h1) hw
  rw [hcard]

end Ful.Stmt

end
