/-
FulEuler: the mod-2 chain complex of a combinatorial map, the Euler inequality
`V + F ≤ E + 2` for connected maps, and vanishing of H₁ when equality holds.
No planarity or topology is assumed.
-/
import FulMap
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.LinearAlgebra.FiniteDimensional.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.Field.ZMod
import Mathlib.Data.Nat.Prime.Defs

set_option linter.unusedSectionVars false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module

/-- The two-element field. -/
abbrev F2 : Type := ZMod 2

theorem F2.add_self (a : F2) : a + a = 0 := by revert a; decide
theorem F2.eq_of_add_eq_zero {a b : F2} : a + b = 0 → a = b := by revert a b; decide
theorem F2.eq_zero_or_one (a : F2) : a = 0 ∨ a = 1 := by revert a; decide

/-- An abstract rank count for a two-step complex over `F2`. -/
theorem euler_abstract {X Y W : Type*} [Fintype X] [Fintype Y] [Fintype W]
    [DecidableEq X] [DecidableEq Y] [DecidableEq W]
    (P : Matrix X Y F2) (Q : Matrix Y W F2)
    (hPQ : ∀ x, P.mulVec (Q.mulVec x) = 0) {a b : ℕ}
    (ha : finrank F2 (LinearMap.ker Q.mulVecLin) ≤ a)
    (hb : finrank F2 (LinearMap.ker P.transpose.mulVecLin) ≤ b) :
    Fintype.card W + Fintype.card X ≤ Fintype.card Y + a + b := by
  have h1 := LinearMap.finrank_range_add_finrank_ker Q.mulVecLin
  have h2 := LinearMap.finrank_range_add_finrank_ker P.transpose.mulVecLin
  have h3 := LinearMap.finrank_range_add_finrank_ker P.mulVecLin
  rw [Module.finrank_fintype_fun_eq_card] at h1 h2 h3
  have h4 : finrank F2 (LinearMap.range Q.mulVecLin) ≤ finrank F2 (LinearMap.ker P.mulVecLin) := by
    apply Submodule.finrank_mono
    rintro _ ⟨x, rfl⟩
    simpa [LinearMap.mem_ker] using hPQ x
  have h5 : finrank F2 (LinearMap.range P.transpose.mulVecLin) =
      finrank F2 (LinearMap.range P.mulVecLin) := Matrix.rank_transpose P
  omega

/-- If the count is an equality with kernels of dimension at most one, exactness holds. -/
theorem exact_abstract {X Y W : Type*} [Fintype X] [Fintype Y] [Fintype W]
    [DecidableEq X] [DecidableEq Y] [DecidableEq W]
    (P : Matrix X Y F2) (Q : Matrix Y W F2)
    (hPQ : ∀ x, P.mulVec (Q.mulVec x) = 0)
    (ha : finrank F2 (LinearMap.ker Q.mulVecLin) ≤ 1)
    (hb : finrank F2 (LinearMap.ker P.transpose.mulVecLin) ≤ 1)
    (hc : Fintype.card W + Fintype.card X = Fintype.card Y + 2) (y : Y → F2)
    (hy : P.mulVec y = 0) : ∃ x, Q.mulVec x = y := by
  have h1 := LinearMap.finrank_range_add_finrank_ker Q.mulVecLin
  have h2 := LinearMap.finrank_range_add_finrank_ker P.transpose.mulVecLin
  have h3 := LinearMap.finrank_range_add_finrank_ker P.mulVecLin
  rw [Module.finrank_fintype_fun_eq_card] at h1 h2 h3
  have hle : LinearMap.range Q.mulVecLin ≤ LinearMap.ker P.mulVecLin := by
    rintro _ ⟨x, rfl⟩
    simpa [LinearMap.mem_ker] using hPQ x
  have h4 := Submodule.finrank_mono hle
  have h5 : finrank F2 (LinearMap.range P.transpose.mulVecLin) =
      finrank F2 (LinearMap.range P.mulVecLin) := Matrix.rank_transpose P
  have hrank : finrank F2 (LinearMap.range Q.mulVecLin) =
      finrank F2 (LinearMap.ker P.mulVecLin) := by omega
  have heq := Submodule.eq_of_le_of_finrank_eq hle hrank
  have hmem : y ∈ LinearMap.ker P.mulVecLin := by simpa [LinearMap.mem_ker] using hy
  rw [← heq] at hmem
  obtain ⟨x, hx⟩ := hmem
  exact ⟨x, hx⟩

/-- A subspace whose elements are all `0` or a fixed vector has dimension at most one. -/
theorem finrank_le_one_of_forall {U : Type*} [AddCommGroup U] [Module F2 U] [FiniteDimensional F2 U]
    (S : Submodule F2 U) (v : U) (h : ∀ x ∈ S, x = 0 ∨ x = v) : finrank F2 S ≤ 1 := by
  by_cases hv : v = 0
  · have hb : S = ⊥ := by
      rw [Submodule.eq_bot_iff]
      intro x hx
      rcases h x hx with h0 | h0
      · exact h0
      · rw [h0, hv]
    rw [hb, finrank_bot]
    omega
  · have hle : S ≤ Submodule.span F2 ({v} : Set U) := by
      intro x hx
      rcases h x hx with rfl | rfl
      · exact Submodule.zero_mem _
      · exact Submodule.mem_span_singleton_self _
    refine (Submodule.finrank_mono hle).trans ?_
    rw [finrank_span_singleton hv]

variable {D : Type*} [Fintype D] [DecidableEq D]

/-- The incidence matrix between the cycles of two permutations, mod 2. -/
def inc (p q : Perm D) : Matrix (Orb p) (Orb q) F2 :=
  Matrix.of fun a b => ∑ _d ∈ univ.filter (fun d => Orb.mk p d = a ∧ Orb.mk q d = b), (1 : F2)

theorem inc_transpose (p q : Perm D) : (inc p q).transpose = inc q p := by
  ext a b
  simp only [inc, Matrix.transpose_apply, Matrix.of_apply, and_comm]

theorem inc_mulVec (p q : Perm D) (x : Orb q → F2) (a : Orb p) :
    (inc p q).mulVec x a = ∑ d ∈ univ.filter (fun d => Orb.mk p d = a), x (Orb.mk q d) := by
  simp only [Matrix.mulVec, dotProduct, inc, Matrix.of_apply, Finset.sum_mul, one_mul]
  rw [← Finset.sum_fiberwise (univ.filter (fun d => Orb.mk p d = a)) (Orb.mk q)]
  refine Finset.sum_congr rfl fun b _ => ?_
  rw [Finset.filter_filter]
  refine Finset.sum_congr rfl fun d hd => ?_
  rw [(Finset.mem_filter.1 hd).2.2]

namespace CMap

variable (M : CMap D)

/-- The boundary from edges to vertices. -/
def d1 : Matrix M.V M.E F2 := inc M.σ M.α
/-- The boundary from faces to edges. -/
def d2 : Matrix M.E M.F F2 := inc M.α M.φ

theorem sum_edge {A : Type*} [AddCommMonoid A] (f : D → A) (d : D) :
    ∑ d' ∈ univ.filter (fun d' => M.edge d' = M.edge d), f d' = f d + f (M.α d) := by
  have : univ.filter (fun d' => M.edge d' = M.edge d) = {d, M.α d} := by
    ext x
    simp only [mem_filter, mem_univ, true_and, mem_insert, mem_singleton]
    rw [eq_comm]
    exact M.edge_eq_iff
  rw [this, Finset.sum_pair (M.α_ne d).symm]

/-- `d2` evaluated at an edge is the sum over its two sides. -/
theorem d2_mulVec_edge (x : M.F → F2) (d : D) :
    M.d2.mulVec x (M.edge d) = x (M.face d) + x (M.face (M.α d)) := by
  have := inc_mulVec M.α M.φ x (M.edge d)
  exact this.trans (M.sum_edge (fun d' => x (M.face d')) d)

/-- `d1` at a vertex is the sum over the darts leaving it. -/
theorem d1_mulVec (c : M.E → F2) (v : M.V) :
    M.d1.mulVec c v = ∑ d ∈ univ.filter (fun d => M.tail d = v), c (M.edge d) :=
  inc_mulVec M.σ M.α c v

theorem d1T_mulVec_edge (g : M.V → F2) (d : D) :
    M.d1.transpose.mulVec g (M.edge d) = g (M.tail d) + g (M.tail (M.α d)) := by
  have h : M.d1.transpose = inc M.α M.σ := inc_transpose M.σ M.α
  rw [h]
  have := inc_mulVec M.α M.σ g (M.edge d)
  exact this.trans (M.sum_edge (fun d' => g (M.tail d')) d)

/-- The rotation is a bijection on the fibre over a vertex. -/
theorem sum_tail_σ {A : Type*} [AddCommMonoid A] (h : D → A) (v : M.V) :
    ∑ d ∈ univ.filter (fun d => M.tail d = v), h (M.σ d) =
      ∑ d ∈ univ.filter (fun d => M.tail d = v), h d := by
  rw [Finset.sum_filter, Finset.sum_filter]
  have := Equiv.sum_comp M.σ (fun d => if M.tail d = v then h d else 0)
  simpa only [tail_σ] using this

/-- `∂∂ = 0`. -/
theorem d1_d2 (x : M.F → F2) : M.d1.mulVec (M.d2.mulVec x) = 0 := by
  funext v
  rw [d1_mulVec]
  simp only [d2_mulVec_edge, face_α]
  rw [Finset.sum_add_distrib, M.sum_tail_σ (fun d => x (M.face d))]
  exact F2.add_self _

variable {M}

/-- Zero boundary means equal values across every edge. -/
theorem d2_eq_zero_iff {x : M.F → F2} :
    M.d2.mulVec x = 0 ↔ ∀ d, x (M.face d) = x (M.face (M.α d)) := by
  constructor
  · intro h d
    have := congrFun h (M.edge d)
    rw [d2_mulVec_edge] at this
    exact F2.eq_of_add_eq_zero this
  · intro h
    funext e
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
    show M.d2.mulVec x (M.edge d) = 0
    rw [d2_mulVec_edge, h d]
    exact F2.add_self _

/-- On a connected map the kernel of `d2` is `{0, 1}`. -/
theorem Connected.ker_d2 (h : M.Connected) {x : M.F → F2} (hx : M.d2.mulVec x = 0) :
    x = 0 ∨ x = 1 := by
  have hconst : ∀ a b : D, x (M.face a) = x (M.face b) :=
    h.invariant_φ (fun d => x (M.face d)) (fun d => by simp only [face_φ])
      (fun d => (d2_eq_zero_iff.1 hx d).symm)
  obtain ⟨d0⟩ := h.1
  rcases F2.eq_zero_or_one (x (M.face d0)) with h0 | h0
  · left
    funext f
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    exact (hconst d d0).trans h0
  · right
    funext f
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    exact (hconst d d0).trans h0

/-- On a connected map the kernel of the coboundary is `{0, 1}`. -/
theorem Connected.ker_d1T (h : M.Connected) {g : M.V → F2} (hg : M.d1.transpose.mulVec g = 0) :
    g = 0 ∨ g = 1 := by
  have step : ∀ d, g (M.tail d) = g (M.tail (M.α d)) := fun d => by
    have := congrFun hg (M.edge d)
    rw [d1T_mulVec_edge] at this
    exact F2.eq_of_add_eq_zero this
  have hconst : ∀ a b : D, g (M.tail a) = g (M.tail b) :=
    h.invariant (fun d => g (M.tail d)) (fun d => by simp only [tail_σ]) (fun d => (step d).symm)
  obtain ⟨d0⟩ := h.1
  rcases F2.eq_zero_or_one (g (M.tail d0)) with h0 | h0
  · left
    funext f
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    exact (hconst d d0).trans h0
  · right
    funext f
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    exact (hconst d d0).trans h0

theorem Connected.finrank_ker_d2 (h : M.Connected) :
    finrank F2 (LinearMap.ker M.d2.mulVecLin) ≤ 1 :=
  finrank_le_one_of_forall _ 1 fun _ hx => h.ker_d2 (LinearMap.mem_ker.1 hx)

theorem Connected.finrank_ker_d1T (h : M.Connected) :
    finrank F2 (LinearMap.ker M.d1.transpose.mulVecLin) ≤ 1 :=
  finrank_le_one_of_forall _ 1 fun _ hx => h.ker_d1T (LinearMap.mem_ker.1 hx)

/-- **Euler inequality.** A connected combinatorial map satisfies `V + F ≤ E + 2`. -/
theorem Connected.euler_le (h : M.Connected) : M.numV + M.numF ≤ M.numE + 2 := by
  have := euler_abstract M.d1 M.d2 M.d1_d2 h.finrank_ker_d2 h.finrank_ker_d1T
  unfold numV numF numE
  omega

/-- **Vanishing of H₁ in genus zero.** On a connected genus-zero map every mod-2 cycle is the
boundary of a set of faces. -/
theorem Connected.exists_d2_eq (h : M.Connected) (hg : M.Genus0) (c : M.E → F2)
    (hc : M.d1.mulVec c = 0) : ∃ s, M.d2.mulVec s = c := by
  refine exact_abstract M.d1 M.d2 M.d1_d2 h.finrank_ker_d2 h.finrank_ker_d1T ?_ c hc
  unfold Genus0 numV numF numE at hg
  omega

end CMap

end Ful

end
