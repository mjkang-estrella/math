/-
FulFmap: the map on `Fin (3 n)` chosen for a fullerene graph on `Fin n`, the vertex map `τ`,
and graph isomorphisms from map isomorphisms.
-/
import FulMapFin

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt
open scoped Classical

universe u

variable {n : ℕ} {G : SimpleGraph (Fin n)}

theorem dart_card (hG : IsFullerene G) : Fintype.card G.Dart = 3 * n := by
  rw [G.dart_card_eq_sum_degrees]
  have hdeg : ∀ v, G.degree v = 3 := by
    intro v
    have h := hG.cubic v
    rw [Nat.card_eq_fintype_card] at h
    rw [← h, ← SimpleGraph.card_neighborFinset_eq_degree]
    exact Set.toFinset_card _
  simp [hdeg, Finset.sum_const, Finset.card_univ, Fintype.card_fin, mul_comm]

/-- The embedding chosen for a fullerene graph. -/
def embOf (hG : IsFullerene G) : RotationSystem G := Classical.choose hG.embedding

theorem embOf_spec (hG : IsFullerene G) :
    Nat.card (Fin n) + (embOf hG).numFaces = Nat.card G.edgeSet + 2 ∧
      ∀ d, (embOf hG).faceLen d = 5 ∨ (embOf hG).faceLen d = 6 :=
  Classical.choose_spec hG.embedding

/-- The numbering of darts. -/
def eDart (hG : IsFullerene G) : G.Dart ≃ Fin (3 * n) :=
  Fintype.equivFinOfCardEq (dart_card hG)

/-- The map on `Fin (3 n)`. -/
def fmap (hG : IsFullerene G) : CMap (Fin (3 * n)) := (mapOf (embOf hG)).map (eDart hG)

theorem fmap_isFullerene (hG : IsFullerene G) : (fmap hG).IsFullerene :=
  (mapOf_isFullerene (embOf hG) hG (embOf_spec hG)).map (eDart hG)

/-- The vertex of a dart. -/
def tauF (hG : IsFullerene G) (d : Fin (3 * n)) : Fin n := ((eDart hG).symm d).fst

theorem fmap_tail_iff (hG : IsFullerene G) {x y : Fin (3 * n)} :
    (fmap hG).tail x = (fmap hG).tail y ↔ tauF hG x = tauF hG y := by
  obtain ⟨a, rfl⟩ := (eDart hG).surjective x
  obtain ⟨b, rfl⟩ := (eDart hG).surjective y
  show ((mapOf (embOf hG)).map (eDart hG)).tail (eDart hG a) =
    ((mapOf (embOf hG)).map (eDart hG)).tail (eDart hG b) ↔ _
  rw [CMap.map_tail_iff, mapOf_tail_iff]
  simp [tauF]

theorem tauF_α (hG : IsFullerene G) (d : Fin (3 * n)) :
    tauF hG ((fmap hG).α d) = ((eDart hG).symm d).snd := by
  obtain ⟨a, rfl⟩ := (eDart hG).surjective d
  show ((eDart hG).symm (((mapOf (embOf hG)).map (eDart hG)).α (eDart hG a))).fst = _
  rw [CMap.map_α, Equiv.symm_apply_apply, Equiv.symm_apply_apply]
  rfl

/-- Dual: same-face criterion in the triangulation. -/
theorem fmapT_face_iff (hG : IsFullerene G) {x y : Fin (3 * n)} :
    (fmap hG).dual.face x = (fmap hG).dual.face y ↔ tauF hG x = tauF hG y := by
  rw [← fmap_tail_iff hG]
  show Orb.mk (fmap hG).dual.φ x = Orb.mk (fmap hG).dual.φ y ↔ Orb.mk (fmap hG).σ x = Orb.mk (fmap hG).σ y
  rw [Orb.mk_eq_iff, Orb.mk_eq_iff, (fmap hG).dual_φ]

theorem fmapT_adj (hG : IsFullerene G) (d : Fin (3 * n)) :
    G.Adj (tauF hG d) (tauF hG ((fmap hG).dual.α d)) := by
  show G.Adj _ (tauF hG ((fmap hG).α d))
  rw [tauF_α]
  exact ((eDart hG).symm d).adj

theorem tauF_surj (hG : IsFullerene G) (v : Fin n) : ∃ d, tauF hG d = v := by
  have h3 := hG.cubic v
  have hne : Nonempty (G.neighborSet v) := by
    by_contra hc
    rw [not_nonempty_iff] at hc
    have h4 : Nat.card (G.neighborSet v) = 0 := Nat.card_of_isEmpty
    omega
  obtain ⟨⟨w, hw⟩⟩ := hne
  refine ⟨eDart hG ⟨(v, w), hw⟩, ?_⟩
  simp [tauF]

theorem adj_complete (hG : IsFullerene G) {v w : Fin n} (h : G.Adj v w) :
    ∃ d, tauF hG d = v ∧ tauF hG ((fmap hG).α d) = w := by
  refine ⟨eDart hG ⟨(v, w), h⟩, by simp [tauF], ?_⟩
  rw [tauF_α]
  simp

theorem sameCycle_perm_comm {D D' : Type*} (e : D ≃ D') {p : Perm D} {q : Perm D'}
    (h : ∀ d, e (p d) = q (e d)) {x y : D} (hs : p.SameCycle x y) : q.SameCycle (e x) (e y) := by
  obtain ⟨i, hi⟩ := hs
  refine ⟨i, ?_⟩
  have hq : q = e.permCongr p := by
    apply Equiv.ext
    intro z
    obtain ⟨a, rfl⟩ := e.surjective z
    rw [← h, Equiv.permCongr_apply, Equiv.symm_apply_apply]
  subst hq
  have h2 : (e.permCongr p) ^ i = e.permCongr (p ^ i) := by
    have := map_zpow e.permCongrHom p i
    simpa [Equiv.permCongrHom_coe] using this.symm
  rw [h2, Equiv.permCongr_apply, Equiv.symm_apply_apply, hi]

/-- A map isomorphism between the dual triangulations gives a graph isomorphism. -/
theorem graphIso_of_mapIso {G' : SimpleGraph (Fin n)} (hG : IsFullerene G) (hG' : IsFullerene G')
    (i : MapIso (fmap hG).dual (fmap hG').dual) : Nonempty (G ≃g G') := by
  have hσ : ∀ d, i.e ((fmap hG).σ d) = (fmap hG').σ (i.e d) := by
    intro d
    have h1 : (fmap hG).σ d = (fmap hG).dual.φ d := by rw [(fmap hG).dual_φ]
    have h2 : ∀ x, (fmap hG').σ x = (fmap hG').dual.φ x := fun x => by rw [(fmap hG').dual_φ]
    rw [h1, i.φ_comm, h2]
  have hα : ∀ d, i.e ((fmap hG).α d) = (fmap hG').α (i.e d) := i.α_comm
  have hσ' : ∀ d, i.e.symm ((fmap hG').σ d) = (fmap hG).σ (i.e.symm d) := by
    intro d
    apply i.e.injective
    rw [Equiv.apply_symm_apply, hσ, Equiv.apply_symm_apply]
  have hfun : ∀ {x y}, tauF hG x = tauF hG y → tauF hG' (i.e x) = tauF hG' (i.e y) := by
    intro x y h
    rw [← fmap_tail_iff] at h ⊢
    exact Orb.mk_eq_iff.2 (sameCycle_perm_comm i.e hσ (Orb.mk_eq_iff.1 h))
  have hfun' : ∀ {x y}, tauF hG' x = tauF hG' y → tauF hG (i.e.symm x) = tauF hG (i.e.symm y) := by
    intro x y h
    rw [← fmap_tail_iff] at h ⊢
    exact Orb.mk_eq_iff.2 (sameCycle_perm_comm i.e.symm hσ' (Orb.mk_eq_iff.1 h))
  let dv : Fin n → Fin (3 * n) := fun v => Classical.choose (tauF_surj hG v)
  have hdv : ∀ v, tauF hG (dv v) = v := fun v => Classical.choose_spec (tauF_surj hG v)
  let dv' : Fin n → Fin (3 * n) := fun v => Classical.choose (tauF_surj hG' v)
  have hdv' : ∀ v, tauF hG' (dv' v) = v := fun v => Classical.choose_spec (tauF_surj hG' v)
  let f : Fin n → Fin n := fun v => tauF hG' (i.e (dv v))
  let g : Fin n → Fin n := fun w => tauF hG (i.e.symm (dv' w))
  have hfg : ∀ w, f (g w) = w := by
    intro w
    show tauF hG' (i.e (dv (tauF hG (i.e.symm (dv' w))))) = w
    have h1 : tauF hG (dv (tauF hG (i.e.symm (dv' w)))) = tauF hG (i.e.symm (dv' w)) := hdv _
    have h2 := hfun h1
    rw [Equiv.apply_symm_apply] at h2
    rw [h2, hdv']
  have hgf : ∀ v, g (f v) = v := by
    intro v
    show tauF hG (i.e.symm (dv' (tauF hG' (i.e (dv v))))) = v
    have h1 : tauF hG' (dv' (tauF hG' (i.e (dv v)))) = tauF hG' (i.e (dv v)) := hdv' _
    have h2 := hfun' h1
    rw [Equiv.symm_apply_apply] at h2
    rw [h2, hdv]
  have hadj1 : ∀ {v w}, G.Adj v w → G'.Adj (f v) (f w) := by
    intro v w hvw
    obtain ⟨d, h1, h2⟩ := adj_complete hG hvw
    have e1 : f v = tauF hG' (i.e d) := by
      show tauF hG' (i.e (dv v)) = _
      exact hfun ((hdv v).trans h1.symm)
    have e2 : f w = tauF hG' (i.e ((fmap hG).α d)) := by
      show tauF hG' (i.e (dv w)) = _
      exact hfun ((hdv w).trans h2.symm)
    rw [e1, e2, hα]
    exact fmapT_adj hG' (i.e d)
  have hadj2 : ∀ {v w}, G'.Adj v w → G.Adj (g v) (g w) := by
    intro v w hvw
    obtain ⟨d, h1, h2⟩ := adj_complete hG' hvw
    have e1 : g v = tauF hG (i.e.symm d) := by
      show tauF hG (i.e.symm (dv' v)) = _
      exact hfun' ((hdv' v).trans h1.symm)
    have e2 : g w = tauF hG (i.e.symm ((fmap hG').α d)) := by
      show tauF hG (i.e.symm (dv' w)) = _
      exact hfun' ((hdv' w).trans h2.symm)
    have hαs : i.e.symm ((fmap hG').α d) = (fmap hG).α (i.e.symm d) := by
      apply i.e.injective
      rw [Equiv.apply_symm_apply, hα, Equiv.apply_symm_apply]
    rw [e1, e2, hαs]
    exact fmapT_adj hG (i.e.symm d)
  let eV : Fin n ≃ Fin n :=
    { toFun := f, invFun := g, left_inv := hgf, right_inv := hfg }
  refine ⟨{ toEquiv := eV, map_rel_iff' := ?_ }⟩
  intro a b
  constructor
  · intro h
    have := hadj2 h
    show G.Adj a b
    have h3 : g (f a) = a := hgf a
    have h4 : g (f b) = b := hgf b
    rwa [show (eV a) = f a from rfl, show (eV b) = f b from rfl, h3, h4] at this
  · intro h
    exact hadj1 h

end Ful

end
