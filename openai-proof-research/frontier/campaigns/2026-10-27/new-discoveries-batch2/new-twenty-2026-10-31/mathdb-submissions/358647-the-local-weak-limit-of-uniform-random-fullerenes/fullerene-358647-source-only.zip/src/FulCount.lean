/-
FulCount: every tube has a finite code, and the isomorphism classes of maps with a code are
bounded independently of the number of darts.
-/
import FulChart
import Mathlib.Data.Fintype.Sigma
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Sum
import Mathlib.Logic.Equiv.Fin.Basic

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

/-- The parameter space of tubes of length at most `L` with caps of at most `N` darts: a length,
the two cap sizes, the two cap codes and the first word. -/
def Par (L N : ℕ) : Type :=
  Σ ℓ : Fin (L + 1), Σ a : Fin (N + 1), Σ b : Fin (N + 1),
    CapCode a.val ℓ.val × CapCode b.val ℓ.val × (Fin ℓ.val → Fin 7)

noncomputable instance (L N : ℕ) : Fintype (Par L N) := by
  unfold Par
  infer_instance

namespace CMap

variable {M : CMap D}

/-- Any face set with a boundary list inside it has a cap code. -/
theorem exists_capChart (M : CMap D) (A : Finset M.F) {ℓ : ℕ} (bdry : ℕ → D)
    (hb : ∀ j, M.face (bdry j) ∈ A) :
    ∃ (c : CapCode (univ.filter (fun d => M.face d ∈ A)).card ℓ), Nonempty (CapChart M A bdry c) := by
  classical
  have hcard : Fintype.card {d // M.face d ∈ A} = (univ.filter (fun d => M.face d ∈ A)).card :=
    Fintype.card_subtype _
  let e : {d // M.face d ∈ A} ≃ Fin (univ.filter (fun d => M.face d ∈ A)).card :=
    (Fintype.equivFin _).trans (finCongr hcard)
  let ι : Fin (univ.filter (fun d => M.face d ∈ A)).card → D := fun x => (e.symm x).val
  have hι : ∀ x, M.face (ι x) ∈ A := fun x => (e.symm x).2
  let ph : Fin (univ.filter (fun d => M.face d ∈ A)).card → Fin (univ.filter (fun d => M.face d ∈ A)).card :=
    fun x => e ⟨M.φ (ι x), by rw [M.face_φ]; exact hι x⟩
  let al : Fin (univ.filter (fun d => M.face d ∈ A)).card → Option (Fin (univ.filter (fun d => M.face d ∈ A)).card) :=
    fun x => if h : M.face (M.α (ι x)) ∈ A then some (e ⟨M.α (ι x), h⟩) else none
  let bd : Fin ℓ → Fin (univ.filter (fun d => M.face d ∈ A)).card :=
    fun j => e ⟨bdry j.val, hb j.val⟩
  have hsymm : ∀ (d : D) (h : M.face d ∈ A), ι (e ⟨d, h⟩) = d := fun d h => by
    show (e.symm (e ⟨d, h⟩)).val = d
    rw [Equiv.symm_apply_apply]
  refine ⟨⟨ph, al, bd⟩, ⟨⟨ι, ?_, hι, ?_, ?_, ?_, ?_, ?_⟩⟩⟩
  · intro x y hxy
    exact e.symm.injective (Subtype.ext hxy)
  · intro d hd
    exact ⟨e ⟨d, hd⟩, hsymm d hd⟩
  · intro x
    exact (hsymm _ _).symm
  · intro x y hxy
    simp only [al] at hxy
    by_cases h : M.face (M.α (ι x)) ∈ A
    · rw [dite_eq_left h] at hxy
      rw [← Option.some.inj hxy]
      exact (hsymm _ _).symm
    · rw [dite_eq_right h] at hxy
      exact absurd hxy (by simp)
  · intro x hx h
    simp only [al] at hx
    rw [dite_eq_left h] at hx
    exact absurd hx (by simp)
  · intro j
    exact hsymm _ _

variable {D' : Type*} [Fintype D'] [DecidableEq D']

/-- A map has parameter `p`: a tube of length `p.1` whose caps have codes `p.2.2.2.1` and
`p.2.2.2.2.1` and whose first word has first-return exponents `p.2.2.2.2.2`. -/
def HasPar {L N : ℕ} (M : CMap D) (p : Par L N) : Prop :=
  ∃ (H : ℕ) (T : Tube M p.1.val H),
    (∀ j : Fin p.1.val, ((T.C 0).K j.val : ℕ) = (p.2.2.2.2.2 j).val) ∧
    Nonempty (CapChart M (T.Q 0)ᶜ (fun j => M.α ((T.C 0).dart j)) p.2.2.2.1) ∧
    Nonempty (CapChart M (T.Q H) (fun j => (T.C H).dart j) p.2.2.2.2.1)

/-- Number of darts of a capped tube. -/
theorem card_of_tube {ℓ H a b : ℕ} (T : Tube M ℓ H) {cA : CapCode a ℓ} {cB : CapCode b ℓ}
    (A : CapChart M (T.Q 0)ᶜ (fun j => M.α ((T.C 0).dart j)) cA)
    (B : CapChart M (T.Q H) (fun j => (T.C H).dart j) cB) :
    Fintype.card D = a + H * (2 * ℓ) * 3 + b := by
  have h := Fintype.card_congr (Equiv.ofBijective (T.psi A B) Tube.psi_bij)
  simp only [Xc, Fintype.card_sum, Fintype.card_prod, Fintype.card_fin] at h
  omega

/-- Two maps on the same dart set with the same parameter are isomorphic. -/
theorem iso_of_hasPar {L N : ℕ} {M M' : CMap D} {p : Par L N} (h : HasPar M p) (h' : HasPar M' p) :
    Nonempty (MapIso M M') := by
  obtain ⟨H, T, hK, ⟨A⟩, ⟨B⟩⟩ := h
  obtain ⟨H', T', hK', ⟨A'⟩, ⟨B'⟩⟩ := h'
  have hc := card_of_tube T A B
  have hc' := card_of_tube T' A' B'
  have hHeq : H = H' := by
    have hpos : 0 < p.1.val * 2 * 3 := by have := T.ℓ_pos; omega
    have h1 : H * (2 * p.1.val) * 3 = H' * (2 * p.1.val) * 3 := by omega
    have h2 : H * (p.1.val * 2 * 3) = H' * (p.1.val * 2 * 3) := by
      calc H * (p.1.val * 2 * 3) = H * (2 * p.1.val) * 3 := by ring
        _ = H' * (2 * p.1.val) * 3 := h1
        _ = H' * (p.1.val * 2 * 3) := by ring
    exact Nat.eq_of_mul_eq_mul_right hpos h2
  subst hHeq
  have hmod : ∀ j, (T.C 0).K j = (T.C 0).K (j % p.1.val) := by
    intro j
    refine (Function.Periodic.map_mod_nat (f := (T.C 0).K) (a := p.1.val) (fun x => ?_) j).symm
    have := (T.C 0).K_add_len x
    rwa [T.len 0 (Nat.zero_le _)] at this
  have hmod' : ∀ j, (T'.C 0).K j = (T'.C 0).K (j % p.1.val) := by
    intro j
    refine (Function.Periodic.map_mod_nat (f := (T'.C 0).K) (a := p.1.val) (fun x => ?_) j).symm
    have := (T'.C 0).K_add_len x
    rwa [T'.len 0 (Nat.zero_le _)] at this
  have hKK : ∀ j, (T.C 0).K j = (T'.C 0).K j := by
    intro j
    rw [hmod j, hmod' j]
    have hlt := Nat.mod_lt j T.ℓ_pos
    rw [hK ⟨j % p.1.val, hlt⟩, hK' ⟨j % p.1.val, hlt⟩]
  exact Tube.iso T T' hKK A B A' B'

end CMap

/-- **The count of short-tube maps.** On any finite set of darts, a family of pairwise
non-isomorphic maps each admitting a parameter in `Par L N` has at most `card (Par L N)` members,
a bound that depends only on `L` and `N`, not on the number of darts. -/
theorem count_le_card_par {ι : Type*} [Fintype ι] {L N : ℕ} (f : ι → CMap D)
    (hpar : ∀ i, ∃ p : Par L N, (f i).HasPar p)
    (hinj : ∀ i j, Nonempty (MapIso (f i) (f j)) → i = j) :
    Fintype.card ι ≤ Fintype.card (Par L N) := by
  choose p hp using hpar
  apply Fintype.card_le_of_injective p
  intro i j hij
  have h1 := hp i
  have h2 := hp j
  rw [hij] at h1
  exact hinj i j (CMap.iso_of_hasPar h1 h2)

end Ful

end
