/-
FulHelixF: edge bound and the descent potential on the helical table.
-/
import FulHelixE
import Mathlib.Algebra.Order.Group.Unbundled.Abs

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
set_option linter.unreachableTactic false

namespace Ful.Helix

variable {s m u : ℤ} {k : ℕ}

set_option maxHeartbeats 3000000 in
/-- The label difference along an edge is at most the circumference. -/
theorem edge_bound (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s)
    (hk : k < len s m u) : -(Lp s) ≤ nz s m u k - u ∧ nz s m u k - u ≤ Lp s := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hle : len s m u ≤ 6 := by
    rcases len_cases hs hm h1 h2 with h | h <;> omega
  have hk6 : k < 6 := by omega
  rcases classes hs hm h1 h2 with (hc | hc | ⟨hc1, hc2⟩) | hc | hc | (hc | hc | ⟨hc1, hc2⟩) |
    (hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc |
      hc | hc | hc | hc) <;>
    (simp (disch := omega) only [len, Nb_int, Nb_zero, Nb_mid, Nb_m, Nb_intB, low_gen,
        low_cf, up_gen, up_cf, intA, ifT, ifF, cf_a, cf_b, cf_c, cf_d, cf_e, cf_f,
        List.length_cons, List.length_nil, List.length_append, List.cons_append, List.nil_append,
        List.map_cons, List.map_nil, List.length_map, Nat.reduceAdd, Nat.zero_add,
        Nat.add_zero] at hk) <;>
    interval_cases k <;> reduce_u <;> omega

/-- The descent potential to the label `0`. -/
def Bz (s m u : ℤ) : ℕ :=
  if u ≤ -1 then u.natAbs
  else if u ≤ m then u.toNat / (Lp s).toNat + u.toNat % (Lp s).toNat
  else (u - m).natAbs + m.toNat / (Lp s).toNat + m.toNat % (Lp s).toNat

theorem Bz_neg (h : u ≤ -1) : Bz s m u = u.natAbs := by
  unfold Bz; rw [ifT h]

theorem Bz_mid (h1 : 0 ≤ u) (h2 : u ≤ m) :
    Bz s m u = u.toNat / (Lp s).toNat + u.toNat % (Lp s).toNat := by
  unfold Bz; rw [ifF (by omega), ifT h2]

theorem Bz_top (h : m < u) (hm : 0 ≤ m) :
    Bz s m u = (u - m).natAbs + m.toNat / (Lp s).toNat + m.toNat % (Lp s).toNat := by
  unfold Bz; rw [ifF (by omega), ifF (by omega)]

theorem div_mod_shift (x L : ℕ) (hL : 0 < L) : (x + L) / L + (x + L) % L = x / L + x % L + 1 := by
  rw [Nat.add_div_right _ hL, Nat.add_mod_right]
  ring

theorem desc2 (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s) (h0 : u ≠ 0) :
    ∃ k, k < len s m u ∧ Bz s m (nz s m u k) + 1 ≤ Bz s m u := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hL0 : 0 < (Lp s).toNat := by omega
  have hc : (-s ≤ u ∧ u ≤ -2) ∨ u = -1 ∨ (0 < u ∧ u < Lp s) ∨ (Lp s ≤ u ∧ u < m) ∨ u = m ∨
      u = m + 1 ∨ (m + 2 ≤ u) := by omega
  have hl6 : len s m u = 5 ∨ len s m u = 6 := by
    rcases len_cases hs hm h1 h2 with h | h <;> omega
  have hsix : ¬ Pent s m u → len s m u = 6 := fun hp => by
    rcases len_cases hs hm h1 h2 with h | h
    · exact absurd h.2 hp
    · exact h.1
  rcases hc with ⟨h3, h4⟩ | h3 | ⟨h3, h4⟩ | ⟨h3, h4⟩ | h3 | h3 | h3
  · refine ⟨0, by omega, ?_⟩
    have ev : nz s m u 0 = u + 1 := by reduce_u <;> omega
    rw [ev, Bz_neg (u := u + 1) (by omega), Bz_neg (u := u) (by omega)]
    omega
  · refine ⟨5, ?_, ?_⟩
    · have := hsix (by unfold Pent; omega)
      omega
    · have ev : nz s m u 5 = 0 := by reduce_u <;> omega
      rw [ev, Bz_mid (u := (0 : ℤ)) (by omega) (by omega), Bz_neg (u := u) (by omega)]
      simp only [Int.toNat_zero, Nat.zero_div, Nat.zero_mod]
      omega
  · refine ⟨0, by omega, ?_⟩
    have h5 : u < m := by omega
    have ev : nz s m u 0 = u - 1 := by reduce_u <;> omega
    rw [ev, Bz_mid (u := u - 1) (by omega) (by omega), Bz_mid (u := u) (by omega) (by omega)]
    have e2 : u.toNat < (Lp s).toNat := by omega
    have e3 : (u - 1).toNat < (Lp s).toNat := by omega
    rw [Nat.div_eq_of_lt e3, Nat.mod_eq_of_lt e3, Nat.div_eq_of_lt e2, Nat.mod_eq_of_lt e2]
    omega
  · refine ⟨1, by omega, ?_⟩
    have ev : nz s m u 1 = u - Lp s := by reduce_u <;> omega
    rw [ev, Bz_mid (u := u - Lp s) (by omega) (by omega), Bz_mid (u := u) (by omega) (by omega)]
    have e1 : u.toNat = (u - Lp s).toNat + (Lp s).toNat := by omega
    rw [e1]
    exact Nat.le_of_eq (div_mod_shift _ _ hL0).symm
  · refine ⟨4, by omega, ?_⟩
    have ev : nz s m u 4 = m - Lp s := by reduce_u <;> omega
    rw [ev, h3, Bz_mid (u := m - Lp s) (by omega) (by omega), Bz_mid (u := m) (by omega) (by omega)]
    have e1 : m.toNat = (m - Lp s).toNat + (Lp s).toNat := by omega
    rw [e1]
    exact Nat.le_of_eq (div_mod_shift _ _ hL0).symm
  · refine ⟨5, ?_, ?_⟩
    · have := hsix (by unfold Pent; omega)
      omega
    · have ev : nz s m u 5 = m := by reduce_u <;> omega
      rw [ev, Bz_mid (u := m) (by omega) (by omega), Bz_top (u := u) (by omega) (by omega), h3]
      have e1 : ((m + 1) - m).natAbs = 1 := by omega
      rw [e1]
      generalize m.toNat / (Lp s).toNat = X
      generalize m.toNat % (Lp s).toNat = Y
      omega
  · refine ⟨0, ?_, ?_⟩
    · have := hsix (by unfold Pent; omega)
      omega
    · have ev : nz s m u 0 = u - 1 := by reduce_u <;> omega
      rw [ev, Bz_top (u := u - 1) (by omega) (by omega), Bz_top (u := u) (by omega) (by omega)]
      have e1 : (u - 1 - m).natAbs + 1 = (u - m).natAbs := by omega
      generalize m.toNat / (Lp s).toNat = X
      generalize m.toNat % (Lp s).toNat = Y
      omega

theorem Bz_bound (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s) :
    Bz s m u ≤ m.toNat / (Lp s).toNat + (Lp s).toNat + s.toNat := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hL0 : 0 < (Lp s).toNat := by omega
  have hc : u ≤ -1 ∨ (0 ≤ u ∧ u ≤ m) ∨ m < u := by omega
  rcases hc with h3 | ⟨h3, h4⟩ | h3
  · rw [Bz_neg h3]
    generalize m.toNat / (Lp s).toNat = X
    omega
  · rw [Bz_mid h3 h4]
    have e1 : u.toNat / (Lp s).toNat ≤ m.toNat / (Lp s).toNat := Nat.div_le_div_right (by omega)
    have e2 : u.toNat % (Lp s).toNat < (Lp s).toNat := Nat.mod_lt _ hL0
    generalize u.toNat / (Lp s).toNat = A at e1 ⊢
    generalize u.toNat % (Lp s).toNat = B at e2 ⊢
    generalize m.toNat / (Lp s).toNat = X at e1 ⊢
    omega
  · rw [Bz_top h3 (by omega)]
    have e2 : m.toNat % (Lp s).toNat < (Lp s).toNat := Nat.mod_lt _ hL0
    generalize m.toNat / (Lp s).toNat = X at e2 ⊢
    generalize m.toNat % (Lp s).toNat = Y at e2 ⊢
    omega

theorem Bz_eq_zero (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s)
    (h0 : Bz s m u = 0) : u = 0 := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hL0 : 0 < (Lp s).toNat := by omega
  have hc : u ≤ -1 ∨ (0 ≤ u ∧ u ≤ m) ∨ m < u := by omega
  rcases hc with h3 | ⟨h3, h4⟩ | h3
  · rw [Bz_neg h3] at h0
    omega
  · rw [Bz_mid h3 h4] at h0
    have e1 := Nat.div_add_mod u.toNat (Lp s).toNat
    have e2 : u.toNat / (Lp s).toNat = 0 := by
      generalize u.toNat / (Lp s).toNat = A at h0 ⊢
      generalize u.toNat % (Lp s).toNat = B at h0
      omega
    have e3 : u.toNat % (Lp s).toNat = 0 := by
      generalize u.toNat / (Lp s).toNat = A at h0
      generalize u.toNat % (Lp s).toNat = B at h0 ⊢
      omega
    rw [e2, e3] at e1
    simp at e1
    omega
  · rw [Bz_top h3 (by omega)] at h0
    generalize m.toNat / (Lp s).toNat = X at h0
    generalize m.toNat % (Lp s).toNat = Y at h0
    omega

end Ful.Helix
