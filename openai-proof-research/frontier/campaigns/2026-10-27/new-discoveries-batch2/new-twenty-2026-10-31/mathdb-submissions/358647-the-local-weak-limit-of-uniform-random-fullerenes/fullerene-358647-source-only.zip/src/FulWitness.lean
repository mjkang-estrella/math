/-
FulWitness: non-vacuity.  The tetrahedron is a concrete map satisfying every hypothesis of the
bounded-disc lemma, and it carries a simple cycle of length three.
-/
import FulBlock

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option maxRecDepth 8000

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset

/-- The rotation of the tetrahedron on its twelve darts. -/
def tetraσFun : Fin 12 → Fin 12 := ![2, 0, 1, 4, 5, 3, 8, 6, 7, 10, 11, 9]
/-- The inverse rotation. -/
def tetraσInv : Fin 12 → Fin 12 := ![1, 2, 0, 5, 3, 4, 7, 8, 6, 11, 9, 10]
/-- The edge involution of the tetrahedron. -/
def tetraαFun : Fin 12 → Fin 12 := ![3, 6, 9, 0, 7, 10, 1, 4, 11, 2, 5, 8]

/-- The tetrahedron as a combinatorial map. -/
def tetra : CMap (Fin 12) where
  σ := { toFun := tetraσFun, invFun := tetraσInv, left_inv := by decide, right_inv := by decide }
  α := { toFun := tetraαFun, invFun := tetraαFun, left_inv := by decide, right_inv := by decide }
  α_invol := by decide
  α_ne := by decide

/-- Vertex labels of the darts. -/
def tetraV : Fin 12 → Fin 4 := ![0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3]
/-- Edge labels of the darts. -/
def tetraE : Fin 12 → Fin 6 := ![0, 1, 2, 0, 3, 4, 1, 3, 5, 2, 4, 5]
/-- Face labels of the darts. -/
def tetraF : Fin 12 → Fin 4 := ![0, 1, 2, 2, 0, 3, 0, 3, 1, 1, 2, 3]

theorem tetraV_inv : ∀ d, tetraV (tetra.σ d) = tetraV d := by decide
theorem tetraF_inv : ∀ d, tetraF (tetra.φ d) = tetraF d := by decide
theorem tetraE_inv : ∀ d, tetraE (tetra.α d) = tetraE d := by decide

theorem tetra_triangulation : tetra.IsTriangulation := by
  unfold CMap.IsTriangulation
  decide

theorem tetra_connected : tetra.Connected := by
  refine ⟨⟨0⟩, ?_⟩
  have hσ : tetra.σ ∈ Subgroup.closure ({tetra.σ, tetra.α} : Set (Perm (Fin 12))) :=
    Subgroup.subset_closure (by simp)
  have hα : tetra.α ∈ Subgroup.closure ({tetra.σ, tetra.α} : Set (Perm (Fin 12))) :=
    Subgroup.subset_closure (by simp)
  have hw : ∀ x : Fin 12, ∃ g ∈ Subgroup.closure ({tetra.σ, tetra.α} : Set (Perm (Fin 12))),
      g 0 = x := by
    intro x
    have s := tetra.σ
    fin_cases x
    · exact ⟨1, Subgroup.one_mem _, by decide⟩
    · exact ⟨tetra.σ * tetra.σ, Subgroup.mul_mem _ hσ hσ, by decide⟩
    · exact ⟨tetra.σ, hσ, by decide⟩
    · exact ⟨tetra.α, hα, by decide⟩
    · exact ⟨tetra.σ * tetra.α, Subgroup.mul_mem _ hσ hα, by decide⟩
    · exact ⟨tetra.σ * tetra.σ * tetra.α, Subgroup.mul_mem _ (Subgroup.mul_mem _ hσ hσ) hα,
        by decide⟩
    · exact ⟨tetra.α * (tetra.σ * tetra.σ), Subgroup.mul_mem _ hα (Subgroup.mul_mem _ hσ hσ),
        by decide⟩
    · exact ⟨tetra.α * (tetra.σ * tetra.α), Subgroup.mul_mem _ hα (Subgroup.mul_mem _ hσ hα),
        by decide⟩
    · exact ⟨tetra.σ * (tetra.α * (tetra.σ * tetra.σ)),
        Subgroup.mul_mem _ hσ (Subgroup.mul_mem _ hα (Subgroup.mul_mem _ hσ hσ)), by decide⟩
    · exact ⟨tetra.α * tetra.σ, Subgroup.mul_mem _ hα hσ, by decide⟩
    · exact ⟨tetra.σ * (tetra.α * tetra.σ), Subgroup.mul_mem _ hσ (Subgroup.mul_mem _ hα hσ),
        by decide⟩
    · exact ⟨tetra.σ * tetra.σ * (tetra.α * tetra.σ),
        Subgroup.mul_mem _ (Subgroup.mul_mem _ hσ hσ) (Subgroup.mul_mem _ hα hσ), by decide⟩
  intro x y
  obtain ⟨a, ha, hax⟩ := hw x
  obtain ⟨b, hb, hby⟩ := hw y
  refine ⟨b * a⁻¹, Subgroup.mul_mem _ hb (Subgroup.inv_mem _ ha), ?_⟩
  rw [Perm.mul_apply, ← hax]
  simpa using hby

/-- The map carries four vertices, six edges and four faces, so it has genus zero. -/
theorem tetra_genus0 : tetra.Genus0 := by
  have hle := tetra_connected.euler_le
  have hV : 4 ≤ tetra.numV := by
    have hs : Function.Surjective (Orb.lift (p := tetra.σ) tetraV tetraV_inv) := by
      intro c
      have hd : ∃ d, tetraV d = c := by revert c; decide
      obtain ⟨d, rfl⟩ := hd
      exact ⟨Orb.mk _ d, rfl⟩
    have := Fintype.card_le_of_surjective _ hs
    simpa [CMap.numV] using this
  have hF : 4 ≤ tetra.numF := by
    have hs : Function.Surjective (Orb.lift (p := tetra.φ) tetraF tetraF_inv) := by
      intro c
      have hd : ∃ d, tetraF d = c := by revert c; decide
      obtain ⟨d, rfl⟩ := hd
      exact ⟨Orb.mk _ d, rfl⟩
    have := Fintype.card_le_of_surjective _ hs
    simpa [CMap.numF] using this
  have hE : tetra.numE ≤ 6 := by
    have hi : Function.Injective (Orb.lift (p := tetra.α) tetraE tetraE_inv) := by
      intro a b
      obtain ⟨x, rfl⟩ := Orb.mk_surjective _ a
      obtain ⟨y, rfl⟩ := Orb.mk_surjective _ b
      intro hxy
      have hxy' : tetraE x = tetraE y := hxy
      have h2 : ∀ x y : Fin 12, tetraE x = tetraE y → y = x ∨ y = tetra.α x := by decide
      exact tetra.edge_eq_iff.2 (h2 x y hxy')
    have := Fintype.card_le_of_injective _ hi
    simpa [CMap.numE] using this
  unfold CMap.Genus0
  omega

theorem tetra_tailV {d d' : Fin 12} (h : tetra.tail d = tetra.tail d') : tetraV d = tetraV d' :=
  Orb.eq_of_mk_eq tetraV tetraV_inv h

theorem tetra_simple : tetra.IsSimple := by
  constructor
  · intro d h
    have h2 : ∀ d : Fin 12, tetraV d ≠ tetraV (tetra.α d) := by decide
    exact h2 d (tetra_tailV h)
  · intro d d' h1 h2
    have h3 : ∀ d d' : Fin 12, tetraV d = tetraV d' → tetraV (tetra.α d) = tetraV (tetra.α d') →
        d = d' := by decide
    exact h3 d d' (tetra_tailV h1) (tetra_tailV h2)

theorem tetra_deg (v : tetra.V) : tetra.deg v ≤ 6 := by
  obtain ⟨x, rfl⟩ := Orb.mk_surjective _ v
  have hsub : (univ.filter fun d => tetra.tail d = Orb.mk tetra.σ x) ⊆
      univ.filter fun d => tetraV d = tetraV x := by
    intro d hd
    exact mem_filter.2 ⟨mem_univ _, tetra_tailV (mem_filter.1 hd).2⟩
  have h3 : ∀ c : Fin 4, (univ.filter fun d : Fin 12 => tetraV d = c).card ≤ 3 := by decide
  exact (Finset.card_le_card hsub).trans ((h3 _).trans (by omega))

/-- A simple cycle of length three in the tetrahedron. -/
def tetraCycle : tetra.SimpleCycle where
  len := 3
  len_pos := by omega
  dart := fun n => if n % 3 = 0 then 0 else if n % 3 = 1 then 4 else 6
  periodic := fun n => by simp only [Nat.add_mod_right]
  chain := by
    intro n
    have h0 : tetra.tail (tetra.α 0) = tetra.tail 4 := by
      rw [show tetra.α 0 = 3 by decide, show (4 : Fin 12) = tetra.σ 3 by decide, tetra.tail_σ]
    have h1 : tetra.tail (tetra.α 4) = tetra.tail 6 := by
      rw [show tetra.α 4 = 7 by decide, show (6 : Fin 12) = tetra.σ 7 by decide, tetra.tail_σ]
    have h2 : tetra.tail (tetra.α 6) = tetra.tail 0 := by
      rw [show tetra.α 6 = 1 by decide, show (0 : Fin 12) = tetra.σ 1 by decide, tetra.tail_σ]
    have hn : n % 3 = 0 ∨ n % 3 = 1 ∨ n % 3 = 2 := by omega
    rcases hn with h | h | h
    · have hs : (n + 1) % 3 = 1 := by omega
      simpa [h, hs] using h0
    · have hs : (n + 1) % 3 = 2 := by omega
      simpa [h, hs] using h1
    · have hs : (n + 1) % 3 = 0 := by omega
      simpa [h, hs] using h2
  tail_inj := by
    intro i j hi hj hij
    have h2 := tetra_tailV hij
    interval_cases i <;> interval_cases j <;> first | rfl | (exfalso; revert h2; decide)
  edge_inj := by
    intro i j hi hj hij
    have h2 : tetraE _ = tetraE _ := Orb.eq_of_mk_eq tetraE tetraE_inv hij
    interval_cases i <;> interval_cases j <;> first | rfl | (exfalso; revert h2; decide)

/-- **Non-vacuity.** Every hypothesis of the bounded-disc lemma holds on the tetrahedron. -/
theorem tetra_nonvacuous :
    tetra.IsTriangulation ∧ tetra.Connected ∧ tetra.Genus0 ∧ tetra.IsSimple ∧
      (∀ v, tetra.deg v ≤ 6) :=
  ⟨tetra_triangulation, tetra_connected, tetra_genus0, tetra_simple, tetra_deg⟩

/-- A consumer of the gate on the witness: the cycle has a side on the tetrahedron. -/
theorem tetra_cycle_has_side : ∃ S, CMap.IsSide tetraCycle S :=
  CMap.exists_isSide tetraCycle tetra_connected tetra_genus0

end Ful

end
