/-
FulTube: a stack of clean rings between two caps, its dart bijection, and the word recursion
across levels.
-/
import FulLevel

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- Corners of the triangle at a rung, by index. -/
def corN (M : CMap D) (c : ℕ) (r : D) : D :=
  match c with
  | 0 => M.cor0 r
  | 1 => M.cor1 r
  | _ => M.cor2 r

theorem face_corN {c : ℕ} (hc : c < 3) (r : D) : M.face (M.corN c r) = M.tri r := by
  interval_cases c
  · rfl
  · exact M.face_cor1 r
  · exact M.face_cor2 r

theorem corN_ne (hT : M.IsTriangulation) (r : D) {a b : ℕ} (ha : a < 3) (hb : b < 3)
    (h : M.corN a r = M.corN b r) : a = b := by
  interval_cases a <;> interval_cases b <;> first
    | rfl
    | (exfalso; exact M.cor1_ne_cor0 hT r h)
    | (exfalso; exact M.cor1_ne_cor0 hT r h.symm)
    | (exfalso; exact M.cor2_ne_cor0 hT r h)
    | (exfalso; exact M.cor2_ne_cor0 hT r h.symm)
    | (exfalso; exact M.cor2_ne_cor1 hT r h)
    | (exfalso; exact M.cor2_ne_cor1 hT r h.symm)

/-- `φ` advances the corner index. -/
theorem φ_corN (hT : M.IsTriangulation) {c : ℕ} (hc : c < 3) (r : D) :
    M.φ (M.corN c r) = M.corN ((c + 1) % 3) r := by
  interval_cases c
  · exact M.φ_cor0 r
  · exact M.φ_cor1 hT r
  · exact M.φ_cor2 r

/-- A stack of `H` clean rings: nested sides, each ring with `2 ℓ` triangles and with its top darts
forming the next cycle, every cycle vertex of degree six. -/
structure Tube (M : CMap D) (ℓ H : ℕ) where
  C : ℕ → SimpleCycle M
  Q : ℕ → Finset M.F
  hT : M.IsTriangulation
  hℓ : 2 ≤ ℓ
  hH : 0 < H
  len : ∀ i, i ≤ H → (C i).len = ℓ
  side : ∀ i, i ≤ H → IsSide (C i) (Q i)
  orient : ∀ i, i ≤ H → ∀ j, M.face ((C i).dart j) ∈ Q i
  K2 : ∀ i, i < H → ∀ j, 2 ≤ (C i).K j
  P_eq : ∀ i, i < H → (C i).P = 2 * ℓ
  ring : ∀ i, i < H → ((Q i).filter (fun f => 1 ≤ (C i).t f)).card = 2 * ℓ
  nest : ∀ i, i < H → Q (i + 1) = (Q i).filter (fun f => (C i).t f = 0)
  tops : ∀ i, i < H → ∀ k, (C (i + 1)).dart k = (C i).topDart k
  deg6 : ∀ i, i ≤ H → ∀ k, M.deg (M.tail ((C i).dart k)) = 6

namespace Tube

variable {ℓ H : ℕ} (T : Tube M ℓ H)

theorem hlen {i : ℕ} (hi : i ≤ H) : 2 ≤ (T.C i).len := by
  rw [T.len i hi]; exact T.hℓ

theorem ℓ_pos (T : Tube M ℓ H) : 0 < ℓ := by have := T.hℓ; omega

theorem P_pos {i : ℕ} (hi : i < H) : 0 < (T.C i).P := by
  rw [T.P_eq i hi]; have := T.ℓ_pos; omega

/-- Some block of each ring has a move `U`, so `U` positions are infinite. -/
theorem exists_U {i : ℕ} (hi : i < H) : ∃ m, (T.C i).W m = false := by
  by_contra hne
  push Not at hne
  have hK2 := T.K2 i hi
  have hall : ∀ j, (T.C i).K j = 2 := by
    intro j
    by_contra hj
    have h3 : 3 ≤ (T.C i).K j := by have := hK2 j; omega
    apply hne (blk (T.C i).K j + 1)
    have hne1 : ¬ (T.C i).W (blk (T.C i).K j + 1) = true := by
      rw [SimpleCycle.W, word_eq_true_iff]
      rintro ⟨j', hj'⟩
      have hmono := blk_mono hK2
      have h1 := hmono (Nat.lt_succ_self j)
      have h4 : blk (T.C i).K j' < blk (T.C i).K (j + 1) := by
        rw [hj', blk_succ]; omega
      have h5 : blk (T.C i).K j < blk (T.C i).K j' := by rw [hj']; omega
      have a := hmono.lt_iff_lt.1 h4
      have b := hmono.lt_iff_lt.1 h5
      omega
    simpa using hne1
  have hb : ∀ j, blk (T.C i).K j = j := by
    intro j
    induction j with
    | zero => rfl
    | succ j ih => rw [blk_succ, ih, hall]
  have hP := T.P_eq i hi
  rw [SimpleCycle.P, hb, T.len i (Nat.le_of_lt hi)] at hP
  have := T.ℓ_pos
  omega

theorem W_period {i : ℕ} (hi : i < H) (m : ℕ) : (T.C i).W (m + (T.C i).P) = (T.C i).W m :=
  SimpleCycle.hPeriod (T.hlen (Nat.le_of_lt hi)) (T.K2 i hi) m

theorem hinf {i : ℕ} (hi : i < H) : ({m | (T.C i).W m = false} : Set ℕ).Infinite := by
  obtain ⟨m, hm⟩ := T.exists_U hi
  exact infinite_U (T.P_pos hi) (T.W_period hi) hm

/-- Ring triangles at level `i` are on the side `Q i` and have a corner on `C i`. -/
theorem tri_ring {i : ℕ} (hi : i < H) (m : ℕ) :
    M.tri ((T.C i).r m) ∈ T.Q i ∧ 1 ≤ (T.C i).t (M.tri ((T.C i).r m)) :=
  ⟨SimpleCycle.tri_mem (T.hlen hi.le) (T.K2 i hi) (T.side i hi.le) (T.orient i hi.le) m,
   SimpleCycle.tri_t (T.hlen hi.le) (T.K2 i hi) (T.side i hi.le) (T.orient i hi.le) m⟩

theorem Q_succ_subset {i : ℕ} (hi : i < H) : T.Q (i + 1) ⊆ T.Q i := by
  rw [T.nest i hi]
  exact Finset.filter_subset _ _

theorem Q_subset {i j : ℕ} (hij : i ≤ j) (hj : j ≤ H) : T.Q j ⊆ T.Q i := by
  induction j, hij using Nat.le_induction with
  | base => exact Finset.Subset.refl _
  | succ j _ ih =>
    exact (T.Q_succ_subset (by omega)).trans (ih (by omega))

theorem tri_not_mem_succ {i : ℕ} (hi : i < H) (m : ℕ) : M.tri ((T.C i).r m) ∉ T.Q (i + 1) := by
  rw [T.nest i hi]
  intro h
  have h1 := (Finset.mem_filter.1 h).2
  have h2 := (T.tri_ring hi m).2
  omega

/-- Ring triangles at different levels are different. -/
theorem tri_level_inj {i j : ℕ} (hi : i < H) (hj : j < H) {m n : ℕ}
    (h : M.tri ((T.C i).r m) = M.tri ((T.C j).r n)) : i = j := by
  by_contra hne
  rcases Nat.lt_or_gt_of_ne hne with hlt | hlt
  · have h1 : M.tri ((T.C j).r n) ∈ T.Q (i + 1) := T.Q_subset hlt hj.le (T.tri_ring hj n).1
    rw [← h] at h1
    exact T.tri_not_mem_succ hi m h1
  · have h1 : M.tri ((T.C i).r m) ∈ T.Q (j + 1) := T.Q_subset hlt hi.le (T.tri_ring hi m).1
    rw [h] at h1
    exact T.tri_not_mem_succ hj n h1

theorem tri_pos_inj {i : ℕ} (hi : i < H) {a b : ℕ} (ha : a < 2 * ℓ) (hb : b < 2 * ℓ)
    (h : M.tri ((T.C i).r a) = M.tri ((T.C i).r b)) : a = b := by
  apply SimpleCycle.tri_inj (T.hlen hi.le) (T.K2 i hi) (T.side i hi.le) (T.orient i hi.le)
    (by have := T.hlen hi.le; omega) (by rw [T.ring i hi, T.P_eq i hi]) _ _ h
  · rw [T.P_eq i hi]; exact ha
  · rw [T.P_eq i hi]; exact hb

theorem r_mod2 {i : ℕ} (hi : i < H) (m : ℕ) : (T.C i).r (m % (2 * ℓ)) = (T.C i).r m := by
  rw [← T.P_eq i hi]
  exact SimpleCycle.r_mod (T.hlen hi.le) (T.K2 i hi) m

/-- Every dart whose face is between `Q 0` and `Q H` lies in a ring. -/
theorem exists_level {f : M.F} (h0 : f ∈ T.Q 0) (hH : f ∉ T.Q H) :
    ∃ i, i < H ∧ f ∈ T.Q i ∧ f ∉ T.Q (i + 1) := by
  by_contra hne
  push Not at hne
  have key : ∀ i, i ≤ H → f ∈ T.Q i := by
    intro i hi
    induction i with
    | zero => exact h0
    | succ i ih => exact hne i (by omega) (ih (by omega))
  exact hH (key H le_rfl)

theorem exists_cover {f : M.F} {i : ℕ} (hi : i < H) (hf : f ∈ T.Q i) (hn : f ∉ T.Q (i + 1)) :
    ∃ m, m < 2 * ℓ ∧ M.tri ((T.C i).r m) = f := by
  have ht : 1 ≤ (T.C i).t f := by
    rw [T.nest i hi] at hn
    by_contra h
    exact hn (Finset.mem_filter.2 ⟨hf, by omega⟩)
  obtain ⟨m, rfl⟩ := SimpleCycle.cover (T.hlen hi.le) (T.K2 i hi) (T.side i hi.le)
    (T.orient i hi.le) hf ht
  refine ⟨m % (2 * ℓ), Nat.mod_lt _ (by have := T.ℓ_pos; omega), ?_⟩
  rw [T.r_mod2 hi]

/-- The word recursion across levels. -/
theorem K_rec {i : ℕ} (hi : i < H) (k : ℕ) :
    (T.C (i + 1)).K k = 4 - gap (T.C i).W k := by
  have h := SimpleCycle.K_succ (C := T.C i) (Q' := T.Q (i + 1)) T.hT (T.hinf hi) (T.C (i + 1))
    (T.hlen hi) (T.tops i hi) (T.side _ hi) (T.orient _ hi) (T.deg6 _ hi)
    (T.tri_not_mem_succ hi) k
  omega

/-- The word of the next level is `Phi` of the word of this level. -/
theorem W_rec {i : ℕ} (hi : i < H) : (T.C (i + 1)).W = Phi (T.C i).W := by
  have h : (T.C (i + 1)).K = fun j => 4 - gap (T.C i).W j := by
    funext k
    exact T.K_rec hi k
  rw [SimpleCycle.W, h, Phi]

end Tube

end CMap

end Ful

end
