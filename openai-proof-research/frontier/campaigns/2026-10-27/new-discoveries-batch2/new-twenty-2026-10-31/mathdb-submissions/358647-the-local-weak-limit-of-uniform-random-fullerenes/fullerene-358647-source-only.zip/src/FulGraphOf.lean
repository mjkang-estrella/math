/-
FulGraphOf: the simple graph of a fullerene map, on any vertex type, is a fullerene graph
in the sense of `Ful.Stmt.IsFullerene`.
-/
import FulStatement
import FulDigon
import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.style.haveILetI false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt
open scoped Classical

universe u

variable {D : Type*} [Fintype D] [DecidableEq D] {V : Type u} [Fintype V] {M : CMap D}

/-- The simple graph of a loopless map, on a vertex type in bijection with its vertices. -/
def graphOf (M : CMap D) (e : M.V ≃ V) (hl : ∀ d, M.tail d ≠ M.tail (M.α d)) : SimpleGraph V where
  Adj v w := ∃ d, e (M.tail d) = v ∧ e (M.tail (M.α d)) = w
  symm := ⟨fun _ _ ⟨d, h1, h2⟩ => ⟨M.α d, h2, by rw [M.α_α]; exact h1⟩⟩
  loopless := ⟨fun _ ⟨d, h1, h2⟩ => hl d (e.injective (h1.trans h2.symm))⟩

section

variable (h : M.IsFullerene) (e : M.V ≃ V)

/-- Darts of the map and of its graph agree. -/
def dartE : D ≃ (graphOf M e h.simple.1).Dart :=
  Equiv.ofBijective (fun d => ⟨(e (M.tail d), e (M.tail (M.α d))), ⟨d, rfl, rfl⟩⟩) (by
    constructor
    · intro a b hab
      have h1 := congrArg SimpleGraph.Dart.toProd hab
      simp only [Prod.mk.injEq] at h1
      exact h.simple.2 a b (e.injective h1.1) (e.injective h1.2)
    · intro x
      obtain ⟨d, h1, h2⟩ := x.adj
      refine ⟨d, SimpleGraph.Dart.ext _ _ (Prod.ext h1 h2)⟩)

@[simp] theorem dartE_fst (d : D) : (dartE h e d).fst = e (M.tail d) := rfl
@[simp] theorem dartE_snd (d : D) : (dartE h e d).snd = e (M.tail (M.α d)) := rfl

theorem dartE_symm (d : D) : (dartE h e d).symm = dartE h e (M.α d) := by
  apply SimpleGraph.Dart.ext
  apply Prod.ext
  · rfl
  · show e (M.tail d) = e (M.tail (M.α (M.α d)))
    rw [M.α_α]

/-- The rotation system of the map, read on the graph. -/
def rotOf : RotationSystem (graphOf M e h.simple.1) where
  σ := (dartE h e).permCongr M.σ
  tail_eq x := by
    obtain ⟨d, rfl⟩ := (dartE h e).surjective x
    show (dartE h e (M.σ ((dartE h e).symm (dartE h e d)))).fst = (dartE h e d).fst
    rw [Equiv.symm_apply_apply, dartE_fst, dartE_fst, M.tail_σ]
  transitive x y hxy := by
    obtain ⟨a, rfl⟩ := (dartE h e).surjective x
    obtain ⟨b, rfl⟩ := (dartE h e).surjective y
    have hab : M.tail a = M.tail b := e.injective (by simpa using hxy)
    obtain ⟨i, hi⟩ := Orb.mk_eq_iff.1 hab
    refine ⟨i, ?_⟩
    have key : ((dartE h e).permCongr M.σ) ^ i = (dartE h e).permCongr (M.σ ^ i) := by
      have := map_zpow (dartE h e).permCongrHom M.σ i
      simpa [Equiv.permCongrHom_coe] using this.symm
    rw [key]
    show dartE h e ((M.σ ^ i) ((dartE h e).symm (dartE h e a))) = _
    rw [Equiv.symm_apply_apply, hi]

theorem rotOf_φ (d : D) : (rotOf h e).φ (dartE h e d) = dartE h e (M.φ d) := by
  show (rotOf h e).σ (dartE h e d).symm = _
  rw [dartE_symm]
  show dartE h e (M.σ ((dartE h e).symm (dartE h e (M.α d)))) = _
  rw [Equiv.symm_apply_apply]
  rfl

/-- The number of darts is twice the number of edges of the map. -/
theorem card_dart_two : Fintype.card D = 2 * M.numE := by
  have h1 := count_fiber (D := D) M.edge (fun _ => True)
  have h2 : ∀ e : M.E, (univ.filter (fun d => M.edge d = e ∧ True)).card = 2 := by
    intro e
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
    have := CMap.card_edge_and M (fun _ => True) d
    show (univ.filter (fun x => M.edge x = M.edge d ∧ True)).card = 2
    simpa using this
  simp only [h2] at h1
  simpa [CMap.numE, mul_comm] using h1

/-- **The simple graph of a fullerene map is a fullerene graph.** -/
theorem isFullerene_graphOf : IsFullerene (graphOf M e h.simple.1) := by
  have hcubic : ∀ v, Nat.card ((graphOf M e h.simple.1).neighborSet v) = 3 := by
    intro v
    obtain ⟨d0, hd0⟩ := Orb.mk_surjective _ (e.symm v)
    have hv : v = e (M.tail d0) := by
      rw [show M.tail d0 = e.symm v from hd0, Equiv.apply_symm_apply]
    subst hv
    let f : {d : D // M.tail d = M.tail d0} → (graphOf M e h.simple.1).neighborSet (e (M.tail d0)) :=
      fun d => ⟨e (M.tail (M.α d.1)), d.1, by rw [d.2], rfl⟩
    have hf : Function.Bijective f := by
      constructor
      · intro a b hab
        have h1 : e (M.tail (M.α a.1)) = e (M.tail (M.α b.1)) := congrArg Subtype.val hab
        exact Subtype.ext (h.simple.2 _ _ (a.2.trans b.2.symm) (e.injective h1))
      · rintro ⟨w, d, h1, h2⟩
        refine ⟨⟨d, e.injective h1⟩, Subtype.ext h2⟩
    rw [← Nat.card_congr (Equiv.ofBijective f hf), Nat.card_eq_fintype_card, Fintype.card_subtype]
    exact h.cubic (M.tail d0)
  refine ⟨?_, hcubic, rotOf h e, ?_, ?_⟩
  · haveI : Nonempty V := by
      obtain ⟨d0⟩ := h.connected.1
      exact ⟨e (M.tail d0)⟩
    refine ⟨fun v w => ?_⟩
    obtain ⟨a, ha⟩ := Orb.mk_surjective _ (e.symm v)
    obtain ⟨b, hb⟩ := Orb.mk_surjective _ (e.symm w)
    have ha' : e (M.tail a) = v := by rw [show M.tail a = e.symm v from ha, Equiv.apply_symm_apply]
    have hb' : e (M.tail b) = w := by rw [show M.tail b = e.symm w from hb, Equiv.apply_symm_apply]
    have hinv := h.connected.invariant
      (fun d => (graphOf M e h.simple.1).Reachable v (e (M.tail d)))
      (fun d => by simp only [M.tail_σ])
      (fun d => by
        have hadj : (graphOf M e h.simple.1).Adj (e (M.tail d)) (e (M.tail (M.α d))) :=
          ⟨d, rfl, rfl⟩
        apply propext
        exact ⟨fun r => r.trans hadj.symm.reachable, fun r => r.trans hadj.reachable⟩)
    have hr := hinv a b
    simp only [ha', hb', eq_iff_iff] at hr
    exact hr.1 (SimpleGraph.Reachable.refl v)
  · have hV : Nat.card V = M.numV := by
      rw [Nat.card_eq_fintype_card]
      exact (Fintype.card_congr e).symm
    have hFc : (rotOf h e).numFaces = M.numF := by
      have heq := Orb.congr (p := M.φ) (q := (rotOf h e).φ) (dartE h e) (fun d => (rotOf_φ h e d).symm)
      show Nat.card (Orb (rotOf h e).φ) = _
      rw [← Nat.card_congr heq, Nat.card_eq_fintype_card]
      rfl
    have hEd : Nat.card (graphOf M e h.simple.1).edgeSet = M.numE := by
      have h1 := (graphOf M e h.simple.1).dart_card_eq_twice_card_edges
      have h2 : Fintype.card (graphOf M e h.simple.1).Dart = Fintype.card D :=
        (Fintype.card_congr (dartE h e)).symm
      have h3 := card_dart_two (M := M)
      have h5 : Nat.card (graphOf M e h.simple.1).edgeSet = #(graphOf M e h.simple.1).edgeFinset := by
        rw [SimpleGraph.edgeFinset, Set.toFinset_card, Nat.card_eq_fintype_card]
      omega
    rw [hV, hFc, hEd]
    exact h.genus
  · intro x
    obtain ⟨d, rfl⟩ := (dartE h e).surjective x
    have hf := h.faces (M.face d)
    have hcount : (rotOf h e).faceLen (dartE h e d) = M.faceLen (M.face d) := by
      have hsame : ∀ a : D, SameCycle (rotOf h e).φ (dartE h e d) (dartE h e a) ↔
          SameCycle M.φ d a := by
        intro a
        have hk : ∀ i : ℤ, ((rotOf h e).φ ^ i) (dartE h e d) = dartE h e ((M.φ ^ i) d) := by
          intro i
          have key : (rotOf h e).φ = (dartE h e).permCongr M.φ := by
            apply Equiv.ext
            intro x
            obtain ⟨d', rfl⟩ := (dartE h e).surjective x
            rw [rotOf_φ]
            simp [Equiv.permCongr_apply]
          rw [key]
          have := map_zpow (dartE h e).permCongrHom M.φ i
          have h2 : ((dartE h e).permCongr M.φ) ^ i = (dartE h e).permCongr (M.φ ^ i) := by
            simpa [Equiv.permCongrHom_coe] using this.symm
          rw [h2]
          show dartE h e ((M.φ ^ i) ((dartE h e).symm (dartE h e d))) = _
          rw [Equiv.symm_apply_apply]
        constructor
        · rintro ⟨i, hi⟩
          exact ⟨i, (dartE h e).injective ((hk i).symm.trans hi)⟩
        · rintro ⟨i, hi⟩
          exact ⟨i, by rw [hk, hi]⟩
      show Nat.card {x // SameCycle (rotOf h e).φ (dartE h e d) x} = M.faceLen (M.face d)
      have hsub : {x // SameCycle (rotOf h e).φ (dartE h e d) x} ≃ {a // SameCycle M.φ d a} :=
        { toFun := fun x => ⟨(dartE h e).symm x.1, (hsame _).1 (by
            rw [Equiv.apply_symm_apply]; exact x.2)⟩
          invFun := fun a => ⟨dartE h e a.1, (hsame _).2 a.2⟩
          left_inv := fun x => Subtype.ext (Equiv.apply_symm_apply _ _)
          right_inv := fun a => Subtype.ext (Equiv.symm_apply_apply _ _) }
      rw [Nat.card_congr hsub, Nat.card_eq_fintype_card, Fintype.card_subtype]
      unfold CMap.faceLen
      congr 1
      ext x
      simp only [mem_filter, mem_univ, true_and]
      rw [show M.face x = M.face d ↔ SameCycle M.φ x d from Orb.mk_eq_iff, sameCycle_comm]
    rw [hcount]
    exact hf

end

end Ful

end
