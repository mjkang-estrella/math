/-
FulCycle: simple closed walks, their mod-2 chains, and the combinatorial Jordan statement:
a simple cycle in a connected genus-zero map has exactly two sides.
-/
import FulEuler
import Mathlib.Data.Nat.Periodic

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

/-- A simple closed walk of darts, indexed periodically by `ℕ`. Tails are distinct and edges
are distinct on one period.  Lengths 1 (loop) and 2 (digon) are allowed. -/
structure SimpleCycle (M : CMap D) where
  len : ℕ
  len_pos : 0 < len
  dart : ℕ → D
  periodic : ∀ i, dart (i + len) = dart i
  chain : ∀ i, M.tail (M.α (dart i)) = M.tail (dart (i + 1))
  tail_inj : ∀ i j, i < len → j < len → M.tail (dart i) = M.tail (dart j) → i = j
  edge_inj : ∀ i j, i < len → j < len → M.edge (dart i) = M.edge (dart j) → i = j

variable {M : CMap D}

namespace SimpleCycle

variable (C : SimpleCycle M)

/-- The edges of the cycle. -/
def edges : Finset M.E := (range C.len).image fun i => M.edge (C.dart i)
/-- The vertices of the cycle. -/
def verts : Finset M.V := (range C.len).image fun i => M.tail (C.dart i)

theorem dart_mod (n : ℕ) : C.dart (n % C.len) = C.dart n :=
  Function.Periodic.map_mod_nat (f := C.dart) (a := C.len) C.periodic n

theorem mod_lt (n : ℕ) : n % C.len < C.len := Nat.mod_lt _ C.len_pos

theorem edge_mem (n : ℕ) : M.edge (C.dart n) ∈ C.edges :=
  mem_image.2 ⟨n % C.len, mem_range.2 (C.mod_lt n), by simp only [dart_mod]⟩

theorem tail_mem (n : ℕ) : M.tail (C.dart n) ∈ C.verts :=
  mem_image.2 ⟨n % C.len, mem_range.2 (C.mod_lt n), by simp only [dart_mod]⟩

theorem head_mem (n : ℕ) : M.tail (M.α (C.dart n)) ∈ C.verts := by
  rw [C.chain]
  exact C.tail_mem _

theorem tail_eq_mod {m n : ℕ} (h : M.tail (C.dart m) = M.tail (C.dart n)) :
    m % C.len = n % C.len := by
  rw [← C.dart_mod m, ← C.dart_mod n] at h
  exact C.tail_inj _ _ (C.mod_lt m) (C.mod_lt n) h

theorem tail_mem_of_edge_mem {d : D} (h : M.edge d ∈ C.edges) : M.tail d ∈ C.verts := by
  obtain ⟨i, -, hi⟩ := mem_image.1 h
  rcases M.edge_eq_iff.1 hi with rfl | rfl
  · exact C.tail_mem i
  · exact C.head_mem i

theorem exists_of_edge_mem {e : M.E} (h : e ∈ C.edges) : ∃ i, M.edge (C.dart i) = e := by
  obtain ⟨i, -, hi⟩ := mem_image.1 h
  exact ⟨i, hi⟩

theorem exists_of_vert_mem {v : M.V} (h : v ∈ C.verts) : ∃ i, M.tail (C.dart i) = v := by
  obtain ⟨i, -, hi⟩ := mem_image.1 h
  exact ⟨i, hi⟩

theorem card_edges : C.edges.card = C.len := by
  rw [edges, card_image_of_injOn, card_range]
  intro a ha b hb hab
  exact C.edge_inj a b (mem_range.1 (by simpa using ha)) (mem_range.1 (by simpa using hb)) hab

theorem card_verts : C.verts.card = C.len := by
  rw [verts, card_image_of_injOn, card_range]
  intro a ha b hb hab
  exact C.tail_inj a b (mem_range.1 (by simpa using ha)) (mem_range.1 (by simpa using hb)) hab

/-- The mod-2 chain of the cycle. -/
def ind (e : M.E) : F2 := if e ∈ C.edges then 1 else 0

end SimpleCycle

/-- The entries of the edge-vertex incidence matrix. -/
theorem d1_entry (M : CMap D) (v : M.V) (d : D) :
    M.d1 v (M.edge d) =
      (if M.tail d = v then (1 : F2) else 0) + (if M.tail (M.α d) = v then (1 : F2) else 0) := by
  have h1 : M.d1 v (M.edge d) =
      ∑ d' ∈ univ.filter (fun d' => M.edge d' = M.edge d),
        (if M.tail d' = v then (1 : F2) else 0) := by
    rw [← Finset.sum_filter, Finset.filter_filter]
    simp only [d1, inc, Matrix.of_apply, tail, edge, and_comm]
  rw [h1]
  exact M.sum_edge (fun d' => if M.tail d' = v then (1 : F2) else 0) d

namespace SimpleCycle

variable (C : SimpleCycle M)

/-- Boundary of a chain supported on the cycle, as a sum along the cycle. -/
theorem d1_mulVec_of_support (z : M.E → F2) (hz : ∀ e, e ∉ C.edges → z e = 0) (v : M.V) :
    M.d1.mulVec z v = ∑ i ∈ range C.len, z (M.edge (C.dart i)) *
      ((if M.tail (C.dart i) = v then (1 : F2) else 0) +
        (if M.tail (C.dart (i + 1)) = v then (1 : F2) else 0)) := by
  simp only [Matrix.mulVec, dotProduct]
  rw [← Finset.sum_subset (Finset.subset_univ C.edges)
    (fun e _ he => by rw [hz e he, mul_zero]), edges, Finset.sum_image]
  · refine Finset.sum_congr rfl fun i _ => ?_
    rw [d1_entry, C.chain, mul_comm]
  · intro a ha b hb hab
    exact C.edge_inj a b (mem_range.1 (by simpa using ha)) (mem_range.1 (by simpa using hb)) hab

theorem sum_shift (h : ℕ → F2) (hp : h C.len = h 0) :
    ∑ i ∈ range C.len, h (i + 1) = ∑ i ∈ range C.len, h i := by
  have a := Finset.sum_range_succ h C.len
  have b := Finset.sum_range_succ' h C.len
  rw [hp] at a
  exact add_right_cancel (b.symm.trans a)

theorem dart_len : C.dart C.len = C.dart 0 := by
  have := C.periodic 0
  rwa [zero_add] at this

/-- A simple cycle is a mod-2 cycle. -/
theorem d1_ind : M.d1.mulVec C.ind = 0 := by
  funext v
  rw [C.d1_mulVec_of_support C.ind (fun e he => ite_eq_right he)]
  have h1 : ∀ i ∈ range C.len, C.ind (M.edge (C.dart i)) = 1 := fun i _ => ite_eq_left (C.edge_mem i)
  rw [Finset.sum_congr rfl (fun i hi => by rw [h1 i hi, one_mul]), Finset.sum_add_distrib]
  rw [C.sum_shift (fun i => if M.tail (C.dart i) = v then (1 : F2) else 0)
    (by simp only [dart_len])]
  exact F2.add_self _

/-- A mod-2 cycle supported on a simple cycle is empty or the whole cycle. -/
theorem eq_zero_or_ind (z : M.E → F2) (hz : ∀ e, e ∉ C.edges → z e = 0)
    (hc : M.d1.mulVec z = 0) : z = 0 ∨ z = C.ind := by
  set a : ℕ → F2 := fun i => z (M.edge (C.dart i)) with ha
  have ha_mod : ∀ n, a (n % C.len) = a n := fun n => by simp only [ha, dart_mod]
  have step : ∀ i, a (i + 1) = a i := by
    intro i
    have h := congrFun hc (M.tail (C.dart (i + 1)))
    rw [C.d1_mulVec_of_support z hz] at h
    simp only [mul_add] at h
    rw [Finset.sum_add_distrib, Finset.sum_eq_single ((i + 1) % C.len),
      Finset.sum_eq_single (i % C.len)] at h
    · rw [ite_eq_left (by rw [C.dart_mod]), ite_eq_left (by
        have : C.dart (i % C.len + 1) = C.dart (i + 1) := by
          rw [← C.dart_mod (i % C.len + 1), ← C.dart_mod (i + 1)]
          congr 1
          simp [Nat.add_mod]
        rw [this]), mul_one, mul_one] at h
      have h' : a ((i + 1) % C.len) + a (i % C.len) = 0 := h
      rw [ha_mod, ha_mod] at h'
      exact F2.eq_of_add_eq_zero h'
    · intro j hj hne
      rw [ite_eq_right, mul_zero]
      intro heq
      apply hne
      have h1 := C.tail_eq_mod heq
      have hjlt := mem_range.1 hj
      have h2 : (j + 1) ≡ (i + 1) [MOD C.len] := h1
      have h3 : j ≡ i [MOD C.len] := Nat.ModEq.add_right_cancel' 1 h2
      have h4 : j % C.len = i % C.len := h3
      rwa [Nat.mod_eq_of_lt hjlt] at h4
    · intro hn
      exact absurd (mem_range.2 (C.mod_lt i)) hn
    · intro j hj hne
      rw [ite_eq_right, mul_zero]
      intro heq
      apply hne
      have h1 := C.tail_eq_mod heq
      rwa [Nat.mod_eq_of_lt (mem_range.1 hj)] at h1
    · intro hn
      exact absurd (mem_range.2 (C.mod_lt (i + 1))) hn
  have hconst : ∀ i, a i = a 0 := by
    intro i
    induction i with
    | zero => rfl
    | succ n ih => rw [step, ih]
  rcases F2.eq_zero_or_one (a 0) with h0 | h0
  · left
    funext e
    by_cases he : e ∈ C.edges
    · obtain ⟨i, rfl⟩ := C.exists_of_edge_mem he
      exact (hconst i).trans h0
    · exact hz e he
  · right
    funext e
    unfold ind
    by_cases he : e ∈ C.edges
    · obtain ⟨i, rfl⟩ := C.exists_of_edge_mem he
      rw [ite_eq_left (C.edge_mem i)]
      exact (hconst i).trans h0
    · rw [ite_eq_right he]
      exact hz e he

end SimpleCycle

/-- The indicator function of a set of faces. -/
def indF (S : Finset M.F) (f : M.F) : F2 := if f ∈ S then 1 else 0

/-- `S` is a side of the simple cycle `C`: the cycle edges are exactly the edges with one side in
`S` and the other outside. -/
def IsSide (C : SimpleCycle M) (S : Finset M.F) : Prop :=
  ∀ d, M.edge d ∈ C.edges ↔ ¬ (M.face d ∈ S ↔ M.face (M.α d) ∈ S)

theorem d2_indF_edge (S : Finset M.F) (d : D) :
    M.d2.mulVec (indF S) (M.edge d) =
      if (M.face d ∈ S ↔ M.face (M.α d) ∈ S) then 0 else 1 := by
  rw [d2_mulVec_edge]
  unfold indF
  by_cases h1 : M.face d ∈ S <;> by_cases h2 : M.face (M.α d) ∈ S <;>
    simp only [h1, h2, ite_true, ite_false, iff_self, iff_true, iff_false, not_true, not_false_iff,
      add_zero, zero_add, true_iff, false_iff]
  all_goals exact F2.add_self _

variable (C : SimpleCycle M)

theorem IsSide.d2_indF {S : Finset M.F} (h : IsSide C S) : M.d2.mulVec (indF S) = C.ind := by
  funext e
  obtain ⟨d, rfl⟩ := Orb.mk_surjective _ e
  show M.d2.mulVec (indF S) (M.edge d) = C.ind (M.edge d)
  rw [d2_indF_edge]
  unfold SimpleCycle.ind
  by_cases h1 : M.edge d ∈ C.edges
  · rw [ite_eq_left h1, ite_eq_right ((h d).1 h1)]
  · rw [ite_eq_right h1, ite_eq_left]
    exact not_not.1 fun hn => h1 ((h d).2 hn)

theorem isSide_of_d2 {S : Finset M.F} (h : M.d2.mulVec (indF S) = C.ind) : IsSide C S := by
  intro d
  have := congrFun h (M.edge d)
  rw [d2_indF_edge] at this
  unfold SimpleCycle.ind at this
  by_cases h1 : M.edge d ∈ C.edges
  · rw [ite_eq_left h1] at this
    constructor
    · intro _ hi
      rw [ite_eq_left hi] at this
      exact zero_ne_one this
    · intro _
      exact h1
  · rw [ite_eq_right h1] at this
    constructor
    · exact fun h2 => absurd h2 h1
    · intro hn
      rw [ite_eq_right hn] at this
      exact absurd this one_ne_zero

theorem IsSide.compl {S : Finset M.F} (h : IsSide C S) : IsSide C Sᶜ := by
  intro d
  rw [h d]
  simp only [mem_compl, not_iff_not]

theorem IsSide.exists_mem {S : Finset M.F} (h : IsSide C S) :
    S.Nonempty ∧ Sᶜ.Nonempty := by
  have h0 := (h (C.dart 0)).1 (C.edge_mem 0)
  by_cases h1 : M.face (C.dart 0) ∈ S
  · refine ⟨⟨_, h1⟩, ⟨M.face (M.α (C.dart 0)), mem_compl.2 fun h2 => h0 ?_⟩⟩
    exact iff_of_true h1 h2
  · have h2 : M.face (M.α (C.dart 0)) ∈ S := by
      by_contra h2
      exact h0 (iff_of_false h1 h2)
    exact ⟨⟨_, h2⟩, ⟨_, mem_compl.2 h1⟩⟩

/-- **Discrete Jordan, existence.** Every simple cycle of a connected genus-zero map is the
boundary of a set of faces. -/
theorem exists_isSide (hc : M.Connected) (hg : M.Genus0) : ∃ S, IsSide C S := by
  obtain ⟨s, hs⟩ := hc.exists_d2_eq hg C.ind C.d1_ind
  refine ⟨univ.filter (fun f => s f = 1), isSide_of_d2 C ?_⟩
  have : indF (univ.filter (fun f => s f = 1)) = s := by
    funext f
    unfold indF
    rcases F2.eq_zero_or_one (s f) with h | h
    · rw [ite_eq_right (by simp [h]), h]
    · rw [ite_eq_left (by simp [h]), h]
  rw [this, hs]

/-- **Discrete Jordan, uniqueness.** A simple cycle has at most two sides, each the complement
of the other. -/
theorem IsSide.eq_or_eq_compl (hc : M.Connected) {S T : Finset M.F} (hS : IsSide C S)
    (hT : IsSide C T) : T = S ∨ T = Sᶜ := by
  have hker : M.d2.mulVec (indF S + indF T) = 0 := by
    rw [Matrix.mulVec_add, hS.d2_indF, hT.d2_indF]
    funext e
    exact F2.add_self _
  rcases hc.ker_d2 hker with h0 | h1
  · left
    ext f
    have := congrFun h0 f
    simp only [Pi.add_apply, Pi.zero_apply, indF] at this
    by_cases a : f ∈ S <;> by_cases b : f ∈ T <;> simp only [a, b, ite_true, ite_false] at this ⊢
    · exact absurd this (by decide)
    · exact absurd this (by decide)
  · right
    ext f
    have := congrFun h1 f
    simp only [Pi.add_apply, Pi.one_apply, indF] at this
    by_cases a : f ∈ S <;> by_cases b : f ∈ T <;>
      simp only [a, b, ite_true, ite_false, mem_compl, not_true, not_false_iff] at this ⊢
    · exact absurd this (by decide)
    · exact absurd this (by decide)

end CMap

end Ful

end
