/-
FulPsi: the developing map `psi` extended to arbitrary direction indices, with the face and reversal
relations in the flat region.
-/
import FulBall

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D} {d0 : D} {R : ℕ}

theorem L1_add (z : ℤ × ℤ) (u : ℕ) : L1 (z.1 + ex u, z.2 + ey u) ≤ L1 z + 2 := by
  have h1 := ex_natAbs u
  have h2 := ey_natAbs u
  simp only [L1]
  omega

theorem psi_mod (hF : M.FlatTo (M.tail d0) R) {z : ℤ × ℤ} (h : L1 z ≤ R) (u : ℕ) :
    M.psi d0 z u = M.psi d0 z (u % 6) := by
  have hfl : M.Fl (M.dev d0 z.1 z.2) := hF.fl (reach_dev d0 z.1 z.2) (by simpa [L1] using h)
  unfold psi
  exact (pow_mod_apply hfl.pow6 u).symm

theorem psi_E' (hT : M.IsTriangulation) (hF : M.FlatTo (M.tail d0) R) {z : ℤ × ℤ} (u : ℕ)
    (h : L1 z + 8 ≤ R) : M.stp (M.psi d0 z u) = M.psi d0 (z.1 + ex u, z.2 + ey u) u := by
  rw [psi_mod hF (by omega) u, psi_E hT hF (Nat.mod_lt _ (by norm_num)) (by omega)]
  have ex' : ex (u % 6) = ex u := by simp [ex]
  have ey' : ey (u % 6) = ey u := by simp [ey]
  rw [ex', ey', psi_mod hF (z := (z.1 + ex u, z.2 + ey u)) (by have := L1_add z u; omega) u]

theorem α_psi (hT : M.IsTriangulation) (hF : M.FlatTo (M.tail d0) R) {z : ℤ × ℤ} (u : ℕ)
    (h : L1 z + 8 ≤ R) :
    M.α (M.psi d0 z u) = M.psi d0 (z.1 + ex u, z.2 + ey u) (u + 3) := by
  have hfl : M.Fl (M.α (M.psi d0 z u)) := hF.fl_head (reach_psi d0 z u) (by omega)
  rw [α_eq_of_Fl hfl, psi_E' hT hF u h]
  unfold psi
  rw [add_comm u 3, pow_add, Perm.mul_apply]
  simp only [pow_succ', pow_zero, mul_one, Perm.mul_apply]

theorem φ_psi (hT : M.IsTriangulation) (hF : M.FlatTo (M.tail d0) R) {z : ℤ × ℤ} (u : ℕ)
    (h : L1 z + 8 ≤ R) :
    M.φ (M.psi d0 z u) = M.psi d0 (z.1 + ex u, z.2 + ey u) (u + 4) := by
  rw [φ_apply, α_psi hT hF u h]
  unfold psi
  rw [show u + 4 = (u + 3) + 1 by ring, pow_succ' M.σ (u + 3), Perm.mul_apply]

theorem psi_succ {z : ℤ × ℤ} (u : ℕ) : M.σ (M.psi d0 z u) = M.psi d0 z (u + 1) := by
  unfold psi
  rw [pow_succ', Perm.mul_apply]

/-- Darts at a flat vertex are distinct modulo six. -/
theorem psi_inj_mod (hF : M.FlatTo (M.tail d0) R) {z : ℤ × ℤ} (h : L1 z ≤ R) {a b : ℕ}
    (hab : M.psi d0 z a = M.psi d0 z b) : a % 6 = b % 6 := by
  have hdeg : M.deg (M.tail (M.dev d0 z.1 z.2)) = 6 :=
    hF _ ((reach_dev d0 z.1 z.2).mono (by simpa [L1] using h))
  exact pow_mod_of_eq hdeg hab

end CMap

end Ful

end
