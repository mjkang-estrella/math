/-
FulLattice: explicit neighbours of the hexagonal lattice of Eq. (3); nearest neighbours.
-/
import FulStatement
import Mathlib.Tactic.IntervalCases

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace Ful.Stmt

/-- The two integer parameters of the distance equation. -/
theorem sq_eq4 {A B : ℤ} (h : 3 * A ^ 2 + B ^ 2 = 4) :
    (A = 0 ∧ (B = 2 ∨ B = -2)) ∨ ((A = 1 ∨ A = -1) ∧ (B = 1 ∨ B = -1)) := by
  have h1 : A ^ 2 ≤ 1 := by nlinarith [sq_nonneg B]
  have h2 : B ^ 2 ≤ 4 := by nlinarith [sq_nonneg A]
  have hA1 : A ≤ 1 := by nlinarith
  have hA2 : -1 ≤ A := by nlinarith
  have hB1 : B ≤ 2 := by nlinarith
  have hB2 : -2 ≤ B := by nlinarith
  interval_cases A <;> interval_cases B <;> simp_all

/-- **Explicit neighbours of the hexagonal lattice.** -/
theorem hex_adj_iff (a b : ℤ × ℤ × Bool) :
    hexLattice.Adj a b ↔
      (a.2.2 = false ∧ b.2.2 = true ∧
        ((b.1 = a.1 ∧ b.2.1 = a.2.1) ∨ (b.1 = a.1 ∧ b.2.1 = a.2.1 - 1) ∨
          (b.1 = a.1 + 1 ∧ b.2.1 = a.2.1 - 1))) ∨
      (a.2.2 = true ∧ b.2.2 = false ∧
        ((b.1 = a.1 ∧ b.2.1 = a.2.1) ∨ (b.1 = a.1 ∧ b.2.1 = a.2.1 + 1) ∨
          (b.1 = a.1 - 1 ∧ b.2.1 = a.2.1 + 1))) := by
  obtain ⟨x, y, c⟩ := a
  obtain ⟨x', y', c'⟩ := b
  show hexDist4 (x, y, c) (x', y', c') = 4 ↔ _
  simp only [hexDist4]
  cases c <;> cases c' <;> simp only [bit, Bool.false_eq_true,
    Bool.true_eq_false, false_and, true_and, false_or, or_false, and_false, and_true, ite_true,
    ite_false, not_true_eq_false, not_false_eq_true]
  · constructor
    · intro h
      have := sq_eq4 h
      rcases this with ⟨h1, h2 | h2⟩ | ⟨h1 | h1, h2 | h2⟩ <;> omega
    · intro h; exact h.elim
  · constructor
    · intro h
      rcases sq_eq4 h with ⟨h1, h2 | h2⟩ | ⟨h1 | h1, h2 | h2⟩
      · exfalso; omega
      · left; constructor <;> omega
      · right; left; constructor <;> omega
      · exfalso; omega
      · right; right; constructor <;> omega
      · exfalso; omega
    · rintro (⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩) <;> ring
  · constructor
    · intro h
      rcases sq_eq4 h with ⟨h1, h2 | h2⟩ | ⟨h1 | h1, h2 | h2⟩
      · left; constructor <;> omega
      · exfalso; omega
      · exfalso; omega
      · right; right; constructor <;> omega
      · exfalso; omega
      · right; left; constructor <;> omega
    · rintro (⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩) <;> ring
  · constructor
    · intro h
      have := sq_eq4 h
      rcases this with ⟨h1, h2 | h2⟩ | ⟨h1 | h1, h2 | h2⟩ <;> omega
    · intro h; exact h.elim

/-- Four times the squared Euclidean distance between distinct vertices of `H` is at least `4`:
the three neighbours above are the nearest neighbours. -/
theorem hexDist4_ge {a b : ℤ × ℤ × Bool} (hne : a ≠ b) : 4 ≤ hexDist4 a b := by
  obtain ⟨x, y, c⟩ := a
  obtain ⟨x', y', c'⟩ := b
  simp only [hexDist4]
  by_contra hlt
  push Not at hlt
  have hA : (2 * (x - x') + (y - y')) ^ 2 ≤ 1 := by
    nlinarith [sq_nonneg (3 * (y - y') + 2 * (bit c - bit c'))]
  have h2 : (3 * (y - y') + 2 * (bit c - bit c')) ^ 2 ≤ 3 := by
    nlinarith [sq_nonneg (2 * (x - x') + (y - y'))]
  have hbit : ∀ b : Bool, bit b = 0 ∨ bit b = 1 := by
    intro b; cases b <;> simp [bit]
  have hc1 := hbit c
  have hc2 := hbit c'
  have hB1 : 3 * (y - y') + 2 * (bit c - bit c') ≤ 1 := by nlinarith
  have hB2 : -1 ≤ 3 * (y - y') + 2 * (bit c - bit c') := by nlinarith
  have hA1 : 2 * (x - x') + (y - y') ≤ 1 := by nlinarith
  have hA2 : -1 ≤ 2 * (x - x') + (y - y') := by nlinarith
  have hbc : (x = x' ∧ y = y' ∧ bit c = bit c') := by
    generalize hAe : 2 * (x - x') + (y - y') = A at hlt hA1 hA2
    generalize hBe : 3 * (y - y') + 2 * (bit c - bit c') = B at hlt hB1 hB2
    interval_cases A <;> interval_cases B <;> first | (norm_num at hlt; done) | omega
  apply hne
  have hcc : c = c' := by
    cases c <;> cases c' <;> simp [bit] at hbc ⊢
  obtain ⟨rfl, rfl, -⟩ := hbc
  subst hcc
  rfl

end Ful.Stmt
