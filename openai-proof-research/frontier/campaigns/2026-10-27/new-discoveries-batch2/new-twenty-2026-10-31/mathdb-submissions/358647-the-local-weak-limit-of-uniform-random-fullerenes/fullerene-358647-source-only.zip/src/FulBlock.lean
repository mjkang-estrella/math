/-
FulBlock: the blocks of a chord-free disc, and the bounded-disc lemma `a(D) ≤ 2 l (l - 2)`.
-/
import FulChord
import Mathlib.Logic.Relation
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

/-- The bounding function. -/
def bnd (l : ℕ) : ℕ := 2 * l * (l - 2)

theorem bnd_mono {a b : ℕ} (h : a ≤ b) : bnd a ≤ bnd b := by
  unfold bnd
  exact Nat.mul_le_mul (Nat.mul_le_mul_left 2 h) (Nat.sub_le_sub_right h 2)

theorem bnd_split (a b : ℕ) : bnd (2 + a) + bnd (2 + b) ≤ bnd (2 + a + b) := by
  unfold bnd
  rw [show 2 + a - 2 = a by omega, show 2 + b - 2 = b by omega,
    show 2 + a + b - 2 = a + b by omega]
  nlinarith [Nat.zero_le (a * b)]

theorem bnd_super (a b : ℕ) : bnd a + bnd b ≤ bnd (a + b) := by
  by_cases ha : a < 2
  · have : bnd a = 0 := by unfold bnd; rw [show a - 2 = 0 by omega, mul_zero]
    rw [this, zero_add]
    exact bnd_mono (by omega)
  by_cases hb : b < 2
  · have : bnd b = 0 := by unfold bnd; rw [show b - 2 = 0 by omega, mul_zero]
    rw [this, add_zero]
    exact bnd_mono (by omega)
  obtain ⟨a', rfl⟩ := Nat.exists_eq_add_of_le (show 2 ≤ a by omega)
  obtain ⟨b', rfl⟩ := Nat.exists_eq_add_of_le (show 2 ≤ b by omega)
  exact (bnd_split a' b').trans (bnd_mono (by omega))

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

theorem SimpleCycle.len_ge_three (hs : M.IsSimple) (C : SimpleCycle M) : 3 ≤ C.len := by
  by_contra hlt
  have hpos := C.len_pos
  have : C.len = 1 ∨ C.len = 2 := by omega
  rcases this with h | h
  · have h0 := C.chain 0
    have hp := C.periodic 0
    rw [h, zero_add] at hp
    rw [zero_add, hp] at h0
    exact hs.1 _ h0.symm
  · have h0 := C.chain 0
    have h1 := C.chain 1
    have hp := C.periodic 0
    rw [h, zero_add] at hp
    rw [zero_add] at h0
    rw [show 1 + 1 = 2 from rfl, hp] at h1
    have h2 := hs.2 (C.dart 1) (M.α (C.dart 0)) h0.symm (by rw [M.α_α]; exact h1)
    have he : M.edge (C.dart 0) = M.edge (C.dart 1) := by rw [h2, M.edge_α]
    have := C.edge_inj 0 1 (by omega) (by omega) he
    omega

variable {C : SimpleCycle M} {S : Finset M.F}

theorem curv_mono (hdeg : ∀ v, M.deg v ≤ 6) {C1 : SimpleCycle M} {S1 : Finset M.F}
    (hsub : C1.intV S1 ⊆ C.intV S) : C1.curv S1 ≤ C.curv S := by
  unfold SimpleCycle.curv
  exact Finset.sum_le_sum_of_subset_of_nonneg hsub (fun v _ _ => by have := hdeg v; omega)

theorem intV_sub_of_subset (h : IsSide C S) {C1 : SimpleCycle M} {S1 : Finset M.F}
    (h1 : IsSide C1 S1) (hsub : S1 ⊆ S) : C1.intV S1 ⊆ C.intV S := by
  intro v hv
  obtain ⟨hn, hall⟩ := h1.mem_intV.1 hv
  refine h.mem_intV.2 ⟨fun hmem => ?_, fun d hd => hsub (hall d hd)⟩
  obtain ⟨d, hd, hnS⟩ := mem_clV.1 ((IsSide.compl C h).verts_subset hmem)
  exact mem_compl.1 hnS (hsub (hall d hd))

theorem t_eq_zero_iff {f : M.F} : C.t f = 0 ↔ ∀ d, M.face d = f → M.tail d ∉ C.verts := by
  unfold SimpleCycle.t
  rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
  constructor
  · intro h d hd hm
    exact h (mem_univ d) ⟨hd, hm⟩
  · rintro h d - ⟨hd, hm⟩
    exact h d hd hm

/-- Faces of `S` with no corner on the cycle. -/
def SimpleCycle.Y (C : SimpleCycle M) (S : Finset M.F) : Finset M.F :=
  S.filter fun f => C.t f = 0

/-- Adjacency inside a set of faces. -/
def Adj (Y : Finset M.F) (g g' : M.F) : Prop :=
  g ∈ Y ∧ g' ∈ Y ∧ ∃ d, M.face d = g ∧ M.face (M.α d) = g'

theorem Adj.symm {Y : Finset M.F} {g g' : M.F} (h : Adj Y g g') : Adj Y g' g := by
  obtain ⟨h1, h2, d, rfl, rfl⟩ := h
  exact ⟨h2, h1, M.α d, rfl, by rw [M.α_α]⟩

/-- The strong component of a face inside a set of faces. -/
def comp (Y : Finset M.F) (f0 : M.F) : Finset M.F :=
  univ.filter fun g => Relation.ReflTransGen (Adj Y) f0 g

theorem mem_comp {Y : Finset M.F} {f0 g : M.F} :
    g ∈ comp Y f0 ↔ Relation.ReflTransGen (Adj Y) f0 g := by
  simp only [comp, mem_filter, mem_univ, true_and]

theorem self_mem_comp (Y : Finset M.F) (f0 : M.F) : f0 ∈ comp Y f0 :=
  mem_comp.2 Relation.ReflTransGen.refl

theorem comp_subset {Y : Finset M.F} {f0 : M.F} (hf0 : f0 ∈ Y) : comp Y f0 ⊆ Y := by
  intro g hg
  rcases Relation.ReflTransGen.cases_tail (mem_comp.1 hg) with rfl | ⟨b, -, hb⟩
  · exact hf0
  · exact hb.2.1

theorem comp_closed {Y : Finset M.F} {f0 g g' : M.F} (hg : g ∈ comp Y f0) (ha : Adj Y g g') :
    g' ∈ comp Y f0 :=
  mem_comp.2 ((mem_comp.1 hg).tail ha)

theorem comp_strong (Y : Finset M.F) (f0 : M.F) : StrongConn (comp Y f0) := by
  intro x hx
  have key : ∀ g ∈ comp Y f0, x g = x f0 := by
    intro g hg
    have hg' := mem_comp.1 hg
    induction hg' with
    | refl => rfl
    | tail hab hbc ih =>
      have hb := mem_comp.2 hab
      obtain ⟨-, -, d, rfl, rfl⟩ := hbc
      rw [← ih hb]
      exact (hx d hb hg).symm
  intro f hf f' hf'
  rw [key f hf, key f' hf']

/-- The edge boundary of a set of faces. -/
def bd (Z : Finset M.F) : Finset M.E :=
  univ.filter fun e => ∃ d, M.edge d = e ∧ M.face d ∈ Z ∧ M.face (M.α d) ∉ Z

theorem mem_bd {Z : Finset M.F} {e : M.E} :
    e ∈ bd Z ↔ ∃ d, M.edge d = e ∧ M.face d ∈ Z ∧ M.face (M.α d) ∉ Z := by
  simp only [bd, mem_filter, mem_univ, true_and]

theorem IsSide.edges_eq_bd {Γ : SimpleCycle M} {X : Finset M.F} (h : IsSide Γ X) :
    Γ.edges = bd X := by
  ext e
  rw [mem_bd]
  constructor
  · intro he
    obtain ⟨i, rfl⟩ := Γ.exists_of_edge_mem he
    have h0 := (h (Γ.dart i)).1 he
    by_cases h1 : M.face (Γ.dart i) ∈ X
    · exact ⟨_, rfl, h1, fun h2 => h0 (iff_of_true h1 h2)⟩
    · have h2 : M.face (M.α (Γ.dart i)) ∈ X := by
        by_contra h2
        exact h0 (iff_of_false h1 h2)
      exact ⟨M.α (Γ.dart i), M.edge_α _, h2, by rwa [M.α_α]⟩
  · rintro ⟨d, rfl, h1, h2⟩
    exact (h d).2 fun hi => h2 (hi.1 h1)

/-- Strong induction over unions of components. -/
theorem block_induct {Y : Finset M.F}
    (hblock : ∀ f0 ∈ Y, (comp Y f0).card ≤ bnd (bd (comp Y f0)).card) (Z : Finset M.F) :
    Z ⊆ Y → (∀ g ∈ Z, ∀ g', Adj Y g g' → g' ∈ Z) → Z.card ≤ bnd (bd Z).card := by
  refine Finset.strongInductionOn Z ?_
  intro Z ih hZY hcl
  rcases Z.eq_empty_or_nonempty with rfl | ⟨f0, hf0⟩
  · simp
  have hXZ : comp Y f0 ⊆ Z := by
    intro g hg
    have hg' := mem_comp.1 hg
    induction hg' with
    | refl => exact hf0
    | tail hab hbc ih' => exact hcl _ (ih' (mem_comp.2 hab)) _ hbc
  set X := comp Y f0 with hXdef
  have hsub : Z \ X ⊂ Z :=
    Finset.ssubset_def.2 ⟨sdiff_subset, fun hs => (mem_sdiff.1 (hs hf0)).2 (self_mem_comp Y f0)⟩
  have hZ'cl : ∀ g ∈ Z \ X, ∀ g', Adj Y g g' → g' ∈ Z \ X := by
    intro g hg g' ha
    refine mem_sdiff.2 ⟨hcl g (mem_sdiff.1 hg).1 g' ha, fun hmem => ?_⟩
    exact (mem_sdiff.1 hg).2 (comp_closed hmem ha.symm)
  have ih2 := ih _ hsub (fun g hg => hZY (mem_sdiff.1 hg).1) hZ'cl
  have ih1 := hblock f0 (hZY hf0)
  have hbdX : bd X ⊆ bd Z := by
    intro e he
    obtain ⟨d, rfl, h1, h2⟩ := mem_bd.1 he
    refine mem_bd.2 ⟨d, rfl, hXZ h1, fun h3 => h2 ?_⟩
    exact comp_closed h1 ⟨hZY (hXZ h1), hZY h3, d, rfl, rfl⟩
  have hbdZ' : bd (Z \ X) ⊆ bd Z := by
    intro e he
    obtain ⟨d, rfl, h1, h2⟩ := mem_bd.1 he
    refine mem_bd.2 ⟨d, rfl, (mem_sdiff.1 h1).1, fun h3 => ?_⟩
    have h4 : M.face (M.α d) ∈ X := by
      by_contra h4
      exact h2 (mem_sdiff.2 ⟨h3, h4⟩)
    have hadj : Adj Y (M.face (M.α d)) (M.face d) := by
      refine Adj.symm ⟨hZY (mem_sdiff.1 h1).1, hZY h3, d, rfl, rfl⟩
    exact (mem_sdiff.1 h1).2 (comp_closed h4 hadj)
  have hdisj : bd X ∩ bd (Z \ X) = ∅ := by
    rw [Finset.eq_empty_iff_forall_notMem]
    intro e he
    obtain ⟨d, rfl, h1, h2⟩ := mem_bd.1 (mem_inter.1 he).1
    obtain ⟨d', hd', h3, h4⟩ := mem_bd.1 (mem_inter.1 he).2
    rcases M.edge_eq_iff.1 hd'.symm with rfl | rfl
    · exact (mem_sdiff.1 h3).2 h1
    · -- `face (α d)` lies in `Z \ X`, adjacent to `face d` in `X`
      have hadj : Adj Y (M.face d) (M.face (M.α d)) :=
        ⟨hZY (hXZ h1), hZY (mem_sdiff.1 h3).1, d, rfl, rfl⟩
      exact (mem_sdiff.1 h3).2 (comp_closed h1 hadj)
  have hcard := card_union_add_card_inter (bd X) (bd (Z \ X))
  rw [hdisj, card_empty, add_zero] at hcard
  have hle := Finset.card_le_card (union_subset hbdX hbdZ')
  have hZ := card_sdiff_add_card_eq_card hXZ
  calc Z.card = (Z \ X).card + X.card := hZ.symm
    _ ≤ bnd (bd (Z \ X)).card + bnd (bd X).card := Nat.add_le_add ih2 ih1
    _ ≤ bnd ((bd (Z \ X)).card + (bd X).card) := bnd_super _ _
    _ ≤ bnd (bd Z).card := bnd_mono (by omega)

/-- The complement of a component is strongly connected: this is where holes are excluded. -/
theorem comp_compl_strong (hc : M.Connected) (h : IsSide C S) {f0 : M.F} (hf0 : f0 ∈ C.Y S) :
    StrongConn (comp (C.Y S) f0)ᶜ := by
  set Y := C.Y S with hYdef
  set X := comp Y f0 with hXdef
  have hXY : X ⊆ Y := comp_subset hf0
  have hYS : Y ⊆ S := filter_subset _ _
  have hXnot : ∀ d, M.face d ∈ X → M.tail d ∉ C.verts := by
    intro d hd
    exact t_eq_zero_iff.1 (mem_filter.1 (hXY hd)).2 d rfl
  intro x hx f hf f' hf'
  obtain ⟨f1, hf1⟩ := (IsSide.exists_mem C h).2
  have hf1S : f1 ∉ S := mem_compl.1 hf1
  have hcompl : ∀ g, g ∉ S → x g = x f1 := by
    intro g hg
    refine IsSide.face_const hc (IsSide.compl C h) x (fun d h1 h2 => ?_) (mem_compl.2 hg) hf1
    refine hx d (mem_compl.2 fun hn => ?_) (mem_compl.2 fun hn => ?_)
    · exact mem_compl.1 h1 (hYS (hXY hn))
    · exact mem_compl.1 h2 (hYS (hXY hn))
  have hrot : ∀ y, M.tail y ∈ C.verts → x (M.face (M.σ y)) = x (M.face y) := by
    intro y hy
    have h1 : M.face y ∈ Xᶜ := mem_compl.2 fun hn => hXnot y hn hy
    have h2 : M.face (M.α y) ∈ Xᶜ := by
      rw [M.face_α]
      exact mem_compl.2 fun hn => hXnot (M.σ y) hn (by rw [M.tail_σ]; exact hy)
    have h3 := hx y h1 h2
    rw [M.face_α] at h3
    exact h3.symm
  have hC : ∀ y, M.tail y ∈ C.verts → x (M.face y) = x f1 := by
    intro y hy
    obtain ⟨y', hy', hy'S⟩ := mem_clV.1 ((IsSide.compl C h).verts_subset hy)
    have hinv : ∀ z, (if M.tail (M.σ z) ∈ C.verts then x (M.face (M.σ z)) else 0) =
        (if M.tail z ∈ C.verts then x (M.face z) else 0) := by
      intro z
      rw [M.tail_σ]
      by_cases hz : M.tail z ∈ C.verts
      · rw [ite_eq_left hz, ite_eq_left hz, hrot z hz]
      · rw [ite_eq_right hz, ite_eq_right hz]
    have key : (if M.tail y ∈ C.verts then x (M.face y) else 0) =
        (if M.tail y' ∈ C.verts then x (M.face y') else 0) :=
      Orb.eq_of_mk_eq (p := M.σ) (fun z => if M.tail z ∈ C.verts then x (M.face z) else 0)
        hinv (hy'.symm)
    rw [ite_eq_left hy, ite_eq_left (hy' ▸ hy)] at key
    rw [key]
    exact hcompl _ (mem_compl.1 hy'S)
  set W : Finset M.F := univ.filter fun g => g ∉ X ∧ x g ≠ x f1 with hWdef
  have mem_W : ∀ {g}, g ∈ W ↔ g ∉ X ∧ x g ≠ x f1 := by
    intro g
    simp only [hWdef, mem_filter, mem_univ, true_and]
  have hWY : ∀ g ∈ W, g ∈ Y := by
    intro g hg
    obtain ⟨hgX, hgx⟩ := mem_W.1 hg
    have hgS : g ∈ S := by
      by_contra hn
      exact hgx (hcompl g hn)
    refine mem_filter.2 ⟨hgS, t_eq_zero_iff.2 fun d hd hm => hgx ?_⟩
    rw [← hd]
    exact hC d hm
  have hW : ∀ d, M.face d ∈ W → M.face (M.α d) ∈ W := by
    intro d hd
    obtain ⟨hgX, hgx⟩ := mem_W.1 hd
    have hgY := hWY _ hd
    have hg'X : M.face (M.α d) ∉ X := by
      intro hn
      have hadj : Adj Y (M.face (M.α d)) (M.face d) :=
        ⟨hXY hn, hgY, M.α d, rfl, by rw [M.α_α]⟩
      exact hgX (comp_closed hn hadj)
    refine mem_W.2 ⟨hg'X, fun hn => hgx ?_⟩
    rw [hx d (mem_compl.2 hgX) (mem_compl.2 hg'X)]
    exact hn
  have hker : M.d2.mulVec (indF W) = 0 := by
    refine d2_eq_zero_iff.2 fun d => ?_
    have h1 := hW d
    have h2 := hW (M.α d)
    rw [M.α_α] at h2
    unfold indF
    by_cases a : M.face d ∈ W
    · rw [ite_eq_left a, ite_eq_left (h1 a)]
    · have b : M.face (M.α d) ∉ W := fun b => a (h2 b)
      rw [ite_eq_right a, ite_eq_right b]
  have hallW : ∀ g, g ∉ W := by
    rcases hc.ker_d2 hker with h1 | h1
    · intro g hg
      have := congrFun h1 g
      simp only [indF, hg, ite_true, Pi.zero_apply] at this
      exact one_ne_zero this
    · exfalso
      have h3 := congrFun h1 f1
      by_cases hf1W : f1 ∈ W
      · exact (mem_W.1 hf1W).2 rfl
      · simp only [indF, hf1W, ite_false, Pi.one_apply] at h3
        exact zero_ne_one h3
  have hval : ∀ g, g ∉ X → x g = x f1 := by
    intro g hg
    by_contra hn
    exact hallW g (mem_W.2 ⟨hg, hn⟩)
  rw [hval f (mem_compl.1 hf), hval f' (mem_compl.1 hf')]

/-- The edges of the block region are injected into the ring triangles with one cycle corner. -/
theorem card_bd_Y_le (hT : M.IsTriangulation) (hc : M.Connected) (h : IsSide C S) :
    (bd (C.Y S)).card ≤ (S.filter fun f => C.t f = 1).card := by
  have : Nonempty D := hc.1
  have hpick : ∀ e ∈ bd (C.Y S), ∃ d, M.edge d = e ∧ M.face d ∈ C.Y S ∧
      M.face (M.α d) ∉ C.Y S := fun e he => mem_bd.1 he
  choose! pick hp1 hp2 hp3 using hpick
  have hprop : ∀ e ∈ bd (C.Y S), M.tail (M.α (pick e)) ∉ C.verts ∧
      M.tail (M.φ (M.α (pick e))) ∉ C.verts ∧ M.face (M.α (pick e)) ∈ S ∧
      M.tail (M.φ (M.φ (M.α (pick e)))) ∈ C.verts := by
    intro e he
    have hY := hp2 e he
    have h0 : ∀ y, M.face y = M.face (pick e) → M.tail y ∉ C.verts :=
      t_eq_zero_iff.1 (mem_filter.1 hY).2
    have hne : M.edge (pick e) ∉ C.edges := fun hm => h0 _ rfl (C.tail_mem_of_edge_mem hm)
    have hiff : M.face (pick e) ∈ S ↔ M.face (M.α (pick e)) ∈ S :=
      not_not.1 fun hn => hne ((h _).2 hn)
    have hS : M.face (M.α (pick e)) ∈ S := hiff.1 (mem_filter.1 hY).1
    have m1 : M.tail (M.α (pick e)) ∉ C.verts := by
      rw [← M.tail_φ]
      exact h0 _ (M.face_φ _)
    have m2 : M.tail (M.φ (M.α (pick e))) ∉ C.verts := by
      rw [M.tail_φ, M.α_α]
      exact h0 _ rfl
    refine ⟨m1, m2, hS, ?_⟩
    by_contra m3
    apply hp3 e he
    refine mem_filter.2 ⟨hS, ?_⟩
    rw [hT.t_face C (M.α (pick e)), ite_eq_right m1, ite_eq_right m2, ite_eq_right m3]
  refine Finset.card_le_card_of_injOn (fun e => M.face (M.α (pick e))) ?_ ?_
  · intro e he
    obtain ⟨m1, m2, hS, m3⟩ := hprop e he
    simp only [coe_filter, Set.mem_ofPred_eq]
    refine ⟨hS, ?_⟩
    rw [hT.t_face C (M.α (pick e)), ite_eq_right m1, ite_eq_right m2, ite_eq_left m3]
  · intro e1 he1 e2 he2 heq
    obtain ⟨a1, a2, -, a3⟩ := hprop e1 he1
    obtain ⟨b1, b2, -, b3⟩ := hprop e2 he2
    have heq' : M.face (M.α (pick e2)) = M.face (M.α (pick e1)) := (Eq.symm heq)
    rcases hT.face_eq_iff.1 heq' with h1 | h1 | h1
    · rw [← hp1 e1 he1, ← hp1 e2 he2, ← M.edge_α (pick e1), ← M.edge_α (pick e2), h1]
    · exfalso
      apply b2
      rw [h1]
      exact a3
    · exfalso
      apply b1
      rw [h1]
      exact a3

/-- **Bounded-disc lemma** (Lemma B). In a simple sphere triangulation with vertex degrees at most
six, a disc with boundary length `l` and interior curvature at most five has at most
`2 l (l - 2)` triangles. -/
theorem bounded_disc (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (hs : M.IsSimple) (hdeg : ∀ v, M.deg v ≤ 6) :
    ∀ (n : ℕ) (C : SimpleCycle M) (S : Finset M.F), S.card = n → IsSide C S →
      C.curv S ≤ 5 → S.card ≤ bnd C.len := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  intro C S hn h hk
  have hl := C.len_ge_three hs
  have htri := h.tri_count hT hc hg
  by_cases hI : (C.intV S).Nonempty
  swap
  · rw [Finset.not_nonempty_iff_eq_empty] at hI
    rw [hI, card_empty] at htri
    obtain ⟨m, hm⟩ := Nat.exists_eq_add_of_le hl
    rw [hm]
    unfold bnd
    rw [show 3 + m - 2 = 1 + m by omega]
    have : S.card = 1 + m := by omega
    rw [this]
    nlinarith
  by_cases hcf : ChordFree C S
  · -- chord-free case
    have hring := h.ring_identity hT hc hg hcf hI
    have hN2 := h.card_t_two hT hc hcf hI
    have hN1 : (S.filter fun f => C.t f = 1).card + 1 ≤ C.len := by
      have : ((S.filter fun f => C.t f = 1).card : ℤ) + 1 ≤ C.len := by
        rw [hring]
        linarith
      exact_mod_cast this
    have hpart : S.card = (C.Y S).card + (S.filter fun f => C.t f = 1).card + C.len := by
      rw [← hN2]
      unfold SimpleCycle.Y
      rw [Finset.card_filter, Finset.card_filter, Finset.card_filter, ← Finset.sum_add_distrib,
        ← Finset.sum_add_distrib, Finset.card_eq_sum_ones]
      refine Finset.sum_congr rfl fun f hf => ?_
      have hle := h.t_le_two hT hc hcf hI hf
      have h3 : C.t f = 0 ∨ C.t f = 1 ∨ C.t f = 2 := by omega
      rcases h3 with h3 | h3 | h3 <;> simp [h3]
    have hYlt : (C.Y S).card < n := by omega
    have hblock : ∀ f0 ∈ C.Y S, (comp (C.Y S) f0).card ≤ bnd (bd (comp (C.Y S) f0)).card := by
      intro f0 hf0
      have hXY : comp (C.Y S) f0 ⊆ C.Y S := comp_subset hf0
      have hYS : C.Y S ⊆ S := filter_subset _ _
      obtain ⟨f1, hf1⟩ := (IsSide.exists_mem C h).2
      have hcne : (comp (C.Y S) f0)ᶜ.Nonempty :=
        ⟨f1, mem_compl.2 fun hn => mem_compl.1 hf1 (hYS (hXY hn))⟩
      obtain ⟨Γ, hΓ⟩ := exists_cycle_of_strong hc hg ⟨f0, self_mem_comp _ _⟩ hcne
        (comp_strong _ _) (comp_compl_strong hc h hf0)
      have hcardlt : (comp (C.Y S) f0).card < n :=
        lt_of_le_of_lt (Finset.card_le_card hXY) hYlt
      have hcurv : Γ.curv (comp (C.Y S) f0) ≤ C.curv S := by
        refine curv_mono hdeg fun v hv => ?_
        obtain ⟨hn', hall⟩ := hΓ.mem_intV.1 hv
        refine h.mem_intV.2 ⟨?_, fun d hd => hYS (hXY (hall d hd))⟩
        obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
        exact t_eq_zero_iff.1 (mem_filter.1 (hXY (hall d rfl))).2 d rfl
      have hb := ih _ hcardlt Γ _ rfl hΓ (hcurv.trans hk)
      rwa [show Γ.len = (bd (comp (C.Y S) f0)).card by
        rw [← hΓ.edges_eq_bd, Γ.card_edges]] at hb
    have hYb := block_induct hblock (C.Y S) (Finset.Subset.refl _)
      (fun g _ g' ha => ha.2.1)
    have hbd := card_bd_Y_le hT hc h
    have hbnd : (C.Y S).card ≤ bnd (C.len - 1) :=
      hYb.trans (bnd_mono (by omega))
    obtain ⟨m, hm⟩ := Nat.exists_eq_add_of_le hl
    rw [hm] at hbnd hN1 hpart ⊢
    rw [show 3 + m - 1 = 2 + m by omega] at hbnd
    unfold bnd at hbnd ⊢
    rw [show 2 + m - 2 = m by omega] at hbnd
    rw [show 3 + m - 2 = 1 + m by omega]
    nlinarith
  · -- chord case
    unfold ChordFree at hcf
    push Not at hcf
    obtain ⟨x, hxS, t1, t2, hxe⟩ := hcf
    obtain ⟨C1, C2, S1, S2, hS1, hS2, hs1, hs2, hcard, hlen⟩ :=
      IsSide.chord_split hc hg h x hxe hxS t1 t2 (hs.1 x)
    have hS1pos : S1.Nonempty := (IsSide.exists_mem C1 hS1).1
    have hS2pos : S2.Nonempty := (IsSide.exists_mem C2 hS2).1
    have h1lt : S1.card < n := by
      have := Finset.card_pos.2 hS2pos
      omega
    have h2lt : S2.card < n := by
      have := Finset.card_pos.2 hS1pos
      omega
    have hk1 : C1.curv S1 ≤ 5 := (curv_mono hdeg (intV_sub_of_subset h hS1 hs1)).trans hk
    have hk2 : C2.curv S2 ≤ 5 := (curv_mono hdeg (intV_sub_of_subset h hS2 hs2)).trans hk
    have b1 := ih _ h1lt C1 S1 rfl hS1 hk1
    have b2 := ih _ h2lt C2 S2 rfl hS2 hk2
    have l1 := C1.len_ge_three hs
    have l2 := C2.len_ge_three hs
    obtain ⟨a, ha⟩ := Nat.exists_eq_add_of_le (show 2 ≤ C1.len by omega)
    obtain ⟨b, hb⟩ := Nat.exists_eq_add_of_le (show 2 ≤ C2.len by omega)
    have hlenC : C.len = 2 + a + b := by omega
    rw [ha] at b1
    rw [hb] at b2
    rw [hlenC]
    have := bnd_split a b
    omega

end CMap

end Ful

end
