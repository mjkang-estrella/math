import FulCut

#print axioms Ful.CMap.Connected.euler_le
#print axioms Ful.CMap.Connected.exists_d2_eq
#print axioms Ful.CMap.exists_isSide
#print axioms Ful.CMap.IsSide.eq_or_eq_compl
#print axioms Ful.CMap.IsSide.euler
#print axioms Ful.CMap.IsSide.euler_int
#print axioms Ful.CMap.IsSide.exists_side_subset
#print axioms Ful.CMap.isDisc_of_isSide
#print axioms Ful.CMap.cut_along_cycle
#print axioms Ful.CMap.cut_along_dual_cycle
#print axioms Ful.CMap.Genus0.dual
#print axioms Ful.MapIso.genus0_iff
