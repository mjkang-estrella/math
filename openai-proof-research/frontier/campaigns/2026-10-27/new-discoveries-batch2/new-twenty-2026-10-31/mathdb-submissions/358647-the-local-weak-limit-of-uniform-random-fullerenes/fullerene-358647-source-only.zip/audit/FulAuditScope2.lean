import FulHelixN

#print axioms Ful.Table.dual_isFullerene
#print axioms Ful.CMap.dual_simple_of
#print axioms Ful.Helix.helix_isFullerene
#print axioms Ful.Helix.helix_card
#print axioms Ful.isFullerene_graphOf
#print axioms Ful.Helix.helixG_isFullerene
#print axioms Ful.Helix.helixG_lower
#print axioms Ful.Helix.helixG_upper
#print axioms Ful.Helix.helixG_not_iso
#print axioms Ful.Helix.numFullerenes_ge
#print axioms Ful.Helix.even_of_order
#print axioms Ful.Helix.nonVacuous
