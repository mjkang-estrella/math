/-
FulBallIso: a map from a graph `H` to a graph `G` that is, on a large ball, an injective graph
morphism which is surjective on neighbours induces an isomorphism of the rooted balls.
-/
import FulStatement

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

noncomputable section

namespace Ful

open Stmt
open scoped Classical

universe u v

variable {V : Type u} {W : Type v}

/-- Membership in a ball through walks. -/
theorem mem_ballSet_iff {G : SimpleGraph V} {o a : V} {r : ℕ} :
    a ∈ ballSet G o r ↔ ∃ p : G.Walk o a, p.length < r := by
  constructor
  · intro h
    have h' : G.edist o a < (r : ℕ∞) := h
    have hne : G.edist o a ≠ ⊤ := ne_top_of_lt h'
    have hr : G.Reachable o a := SimpleGraph.edist_ne_top_iff_reachable.1 hne
    obtain ⟨p, hp⟩ := hr.exists_walk_length_eq_edist
    refine ⟨p, ?_⟩
    have : (p.length : ℕ∞) < r := by rw [hp]; exact h'
    exact_mod_cast this
  · rintro ⟨p, hp⟩
    show G.edist o a < (r : ℕ∞)
    calc G.edist o a ≤ p.length := SimpleGraph.edist_le p
      _ < r := by exact_mod_cast hp

variable {G : SimpleGraph V} {H : SimpleGraph W}

/-- A walk whose vertices lie in a set maps along a morphism on that set. -/
theorem map_walk (Ψ : W → V) (S : Set W) (h : ∀ a b, a ∈ S → b ∈ S → H.Adj a b → G.Adj (Ψ a) (Ψ b))
    {a b : W} (q : H.Walk a b) (hq : ∀ x ∈ q.support, x ∈ S) :
    ∃ p : G.Walk (Ψ a) (Ψ b), p.length = q.length := by
  induction q with
  | nil => exact ⟨SimpleGraph.Walk.nil, rfl⟩
  | @cons a b c hab q' ih =>
    obtain ⟨p', hp'⟩ := ih (fun x hx => hq x (by simp [hx]))
    refine ⟨SimpleGraph.Walk.cons (h a b (hq a (by simp)) (hq b (by simp)) hab) p', ?_⟩
    rw [SimpleGraph.Walk.length_cons, SimpleGraph.Walk.length_cons, hp']

/-- The rooted ball transfer. -/
theorem rootedBallIso_of_local (Ψ : W → V) (o : W) (r : ℕ)
    (hadj : ∀ a b, a ∈ ballSet H o (r + 1) → b ∈ ballSet H o (r + 1) → H.Adj a b → G.Adj (Ψ a) (Ψ b))
    (hinj : ∀ a b, a ∈ ballSet H o (r + 1) → b ∈ ballSet H o (r + 1) → Ψ a = Ψ b → a = b)
    (hsurj : ∀ a, a ∈ ballSet H o r → ∀ w, G.Adj (Ψ a) w → ∃ b, H.Adj a b ∧ Ψ b = w) :
    RootedBallIso G (Ψ o) H o r := by
  have hmono : ∀ {a : W} {i j : ℕ}, i ≤ j → a ∈ ballSet H o i → a ∈ ballSet H o j := by
    intro a i j hij ha
    obtain ⟨p, hp⟩ := mem_ballSet_iff.1 ha
    exact mem_ballSet_iff.2 ⟨p, by omega⟩
  -- forward: balls map into balls
  have hfwd : ∀ (a : W) (q : H.Walk a o), q.length < r + 1 →
      ∃ p : G.Walk (Ψ a) (Ψ o), p.length = q.length := by
    intro a q hq
    refine map_walk Ψ (ballSet H o (r + 1)) hadj q ?_
    intro x hx
    refine mem_ballSet_iff.2 ⟨(q.dropUntil x hx).reverse, ?_⟩
    rw [SimpleGraph.Walk.length_reverse]
    exact lt_of_le_of_lt (SimpleGraph.Walk.length_dropUntil_le_length _ _) hq
  -- backward: walks in `G` lift
  have hbwd : ∀ (x : V) (g : V) (q : G.Walk x g) (a : W) (m : ℕ), Ψ a = x → a ∈ ballSet H o m →
      m + q.length ≤ r → ∃ b, Ψ b = g ∧ b ∈ ballSet H o (m + q.length) := by
    intro x g q
    induction q with
    | nil =>
      intro a m hx ha hm
      exact ⟨a, hx, by simpa using ha⟩
    | @cons x y g hxy q' ih =>
      intro a m hx ha hm
      rw [SimpleGraph.Walk.length_cons] at hm ⊢
      obtain ⟨a', ha', rfl⟩ := hsurj a (hmono (by omega) ha) y (by rw [hx]; exact hxy)
      have hnext : a' ∈ ballSet H o (m + 1) := by
        obtain ⟨p, hp⟩ := mem_ballSet_iff.1 ha
        exact mem_ballSet_iff.2 ⟨p.concat ha', by
          rw [SimpleGraph.Walk.length_concat]; omega⟩
      obtain ⟨b, hb, hb2⟩ := ih a' (m + 1) rfl hnext (by omega)
      exact ⟨b, hb, by
        rw [show m + (q'.length + 1) = m + 1 + q'.length by omega]; exact hb2⟩
  -- the root
  have h0 : o ∈ ballSet H o 1 := mem_ballSet_iff.2 ⟨SimpleGraph.Walk.nil, by simp⟩
  -- build the equivalence from the `H` ball to the `G` ball
  have hin : ∀ a, a ∈ ballSet H o r → Ψ a ∈ ballSet G (Ψ o) r := by
    intro a ha
    obtain ⟨p, hp⟩ := mem_ballSet_iff.1 ha
    obtain ⟨q, hq⟩ := hfwd a p.reverse (by rw [SimpleGraph.Walk.length_reverse]; omega)
    exact mem_ballSet_iff.2 ⟨q.reverse, by
      rw [SimpleGraph.Walk.length_reverse, hq, SimpleGraph.Walk.length_reverse]; exact hp⟩
  have hsurj2 : ∀ g, g ∈ ballSet G (Ψ o) r → ∃ a, a ∈ ballSet H o r ∧ Ψ a = g := by
    intro g hg
    obtain ⟨q, hq⟩ := mem_ballSet_iff.1 hg
    rcases Nat.eq_zero_or_pos r with rfl | hr
    · omega
    obtain ⟨b, hb, hb2⟩ := hbwd _ g q o 1 rfl h0 (by omega)
    refine ⟨b, hmono (by omega) hb2, hb⟩
  let f : ballSet H o r → ballSet G (Ψ o) r := fun a => ⟨Ψ a.1, hin a.1 a.2⟩
  have hfinj : Function.Injective f := by
    intro a b hab
    apply Subtype.ext
    exact hinj _ _ (hmono (by omega) a.2) (hmono (by omega) b.2) (congrArg Subtype.val hab)
  have hfsurj : Function.Surjective f := by
    intro g
    obtain ⟨a, ha, h⟩ := hsurj2 g.1 g.2
    exact ⟨⟨a, ha⟩, Subtype.ext h⟩
  let e0 : ballSet H o r ≃ ballSet G (Ψ o) r := Equiv.ofBijective f ⟨hfinj, hfsurj⟩
  have hmap : ∀ a b, (H.induce (ballSet H o r)).Adj a b ↔
      (G.induce (ballSet G (Ψ o) r)).Adj (e0 a) (e0 b) := by
    intro a b
    constructor
    · intro hab
      exact hadj _ _ (hmono (by omega) a.2) (hmono (by omega) b.2) hab
    · intro hab
      have hab' : G.Adj (Ψ a.1) (Ψ b.1) := hab
      obtain ⟨b', hb', hb2⟩ := hsurj a.1 a.2 _ hab'
      have hb'in : b' ∈ ballSet H o (r + 1) := by
        obtain ⟨p, hp⟩ := mem_ballSet_iff.1 a.2
        exact mem_ballSet_iff.2 ⟨p.concat hb', by
          rw [SimpleGraph.Walk.length_concat]; omega⟩
      have hb3 : b' = b.1 := hinj _ _ hb'in (hmono (by omega) b.2) hb2
      show H.Adj a.1 b.1
      rw [← hb3]
      exact hb'
  let eI : H.induce (ballSet H o r) ≃g G.induce (ballSet G (Ψ o) r) :=
    { toEquiv := e0, map_rel_iff' := fun {a b} => (hmap a b).symm }
  refine ⟨eI.symm, fun h1 h2 => ?_⟩
  apply Subtype.ext
  have h3 : e0 ⟨o, h2⟩ = ⟨Ψ o, h1⟩ := Subtype.ext rfl
  show (e0.symm ⟨Ψ o, h1⟩ : ballSet H o r).1 = o
  rw [← h3, Equiv.symm_apply_apply]

end Ful

end
