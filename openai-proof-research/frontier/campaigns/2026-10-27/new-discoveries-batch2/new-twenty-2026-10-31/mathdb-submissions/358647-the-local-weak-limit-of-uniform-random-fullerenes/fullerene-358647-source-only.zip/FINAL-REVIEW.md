# Independent final formal review: MathDB 358647 (local weak limit of random fullerenes)

Claude Opus 5.5, high effort, done personally. Credit 0; campaign 60 of 80 unchanged. Root alone adjudicates.

## Recommendation

**TECHNICAL_PASS_ROOT_ADJUDICATION_PENDING.** I tried to break the claim and could not. `Ful.endpoint : LocalWeakConvergence ∧ NonVacuous` replays from an empty build. It depends only on `propext`, `Classical.choice` and `Quot.sound`. In my reading it is the exact statement of Conjecture 1 of arXiv 2306.01462 with Eq. (4), and of MathDB 358647. I found no defect affecting validity or fidelity. Significance is modest and is the real open question for root (Gate G).

| Gate | Result |
|---|---|
| A fresh replay | PASS: 50 of 50 compile and kernel-check, exit 0 |
| B source audit | PASS, with the reading depth stated below |
| C axioms | PASS: full closure walked, 27,127 constants |
| D statement fidelity | PASS: exact statement |
| E controls | PASS |
| F prior art | NO_MATCH_FOUND_BOUNDED_INCOMPLETE |
| G science | MODEST: not routine by the campaign's rule, exclusion defensible |

## Gate A: fresh extracted replay

The zip has 50 entries. None has an absolute path, parent reference or symlink, and all 50 match `packet/SOURCE-HASHES.json`. All 50 modules in `BUILD-ORDER.json` compiled and kernel-checked from the empty `build/`, with labels `fresh_compile_*` and `fresh_check_*`. No module produced warnings or extra output. Slowest compile: FulHelixC, 33.5 s. Details and olean hashes are in `results/FRESH-REPLAY.json`.

## Gate B: source audit

**How much I read.** Read in full, every line: FulStatement, FulMap, FulBallIso, FulLattice, FulLatticeAut, FulGraphOf, FulBridge, FulMapOf, FulMapFin, FulFmap, FulBad, FulTransfer, FulTransfer2, FulPsi, FulEndpoint, FulEuler, FulCycle. Read at declaration level, meaning every definition in full and every theorem statement with its hypotheses but not the proof scripts: the other 33 modules, through `results/DECL-DUMP.txt`. The extractor only captures declarations at column zero. As your brief allowed, the closest reading went to the statement, its definitions and the bridge. **I did not read the proof scripts of those 33 modules line by line.** That is less than TASK.txt's "read every source". For those scripts I rely on the token scans, the kernel and the axiom walk, all of which cover the complete text or the compiled constants.

**Token scans over all 50 files.** `sorry`, `admit`, `axiom`, `unsafe`, `opaque`, `implemented_by`, `extern`, `native_decide`, `ofReduceBool`, `notation`, `syntax`, `elab`, `run_cmd`, `open Lean`, `attribute [`, `priority`: none. `partial` occurs once, in a comment in FulChart.

- `macro`: 4 (`reduce_t`, `reduce_u`, `len_at`, `out_at`), all tactic abbreviations for `simp (disch := omega) only [...]`. They do not touch statements.
- `instance`: 6, all `Fintype` or `DecidableEq` on the packet's own types. No priority changes.
- `@[`: only `simp` (24) and `ext` (1).
- No declaration redefines a Mathlib name. All declarations sit inside `namespace Ful`.
- `set_option`: linters, and 4 `maxHeartbeats`.

**Conclusion-bearing hypotheses.** None. `Ful.endpoint` has no hypotheses. Internal theorems carry ordinary hypotheses that are discharged. In particular `transfer_ball` and `local_ball` take a systole hypothesis `hsys`, and `good_of_not_exc` discharges it from `¬ Exc`. Exceptional classes are then counted by `exc_card_le`. `helix_isFullerene` and `numFullerenes_ge` have only parameter constraints.

| Module | Role |
|---|---|
| FulMap | combinatorial maps: darts, σ, α, φ, orbits, Euler count, dual, `IsFullerene` (map level) |
| FulStatement | **the literal statement and all its definitions** |
| FulBallIso | local injective morphism gives a rooted ball isomorphism |
| FulEuler | mod-2 chain complex, `V+F ≤ E+2` for connected maps, H₁ vanishing in genus 0 |
| FulLattice | explicit neighbours of H and nearest-neighbour bound |
| FulCycle | simple cycles; existence and uniqueness of sides (discrete Jordan) |
| FulCut | cutting a genus-0 map along a cycle into two discs |
| FulDisc | triangulated disc counts, corner and ring identities |
| FulWalk | simple cycle from an even edge set; bond-cycle duality |
| FulChord | chord splitting |
| FulBlock | blocks; bounded-disc lemma `a(D) ≤ 2l(l-2)` |
| FulRung | ring walk and rungs |
| FulWitness | tetrahedron non-vacuity for the disc lemma |
| FulFan | first-return exponents at a cycle |
| FulWord | ring words and the map `Phi` |
| FulLevel | one clean ring, word recursion |
| FulTube | stack of clean rings |
| FulChart | capped-tube dart tables, whole-map determinism |
| FulCount | finite parameter space `Par`, bounded isomorphism count |
| FulEss | essential and shortest cycles, total curvature 12 |
| FulTops | top darts of a ring |
| FulPeel | peeling dichotomy for a shortest essential cycle |
| FulChain | iterated peeling, `count_short_essential` |
| FulDev | developing map on a flat region |
| FulLocal | closed sequences from developing, turning bounds |
| FulInj | no collision along geodesics of the development |
| FulBall | development injective on balls, `local_ball` |
| FulBridge | dual of a fullerene map is a triangulation of degrees 5 and 6 |
| FulPsi | developing map with direction indices |
| FulDigon | loops and digons excluded: `IsFullerene.dual_simple` |
| FulTransfer | hexagonal lattice to lattice triangles, adjacency |
| FulGraphOf | graph of a fullerene map satisfies `Stmt.IsFullerene` |
| FulMapOf | transport of maps along a dart bijection |
| FulTable | sphere triangulation from a rotation table |
| FulTransfer2 | `transfer_ball`: rooted isomorphism with the H ball |
| FulHelix | neighbour lists of the helical family |
| FulMapFin | **bridge: graph plus rotation system gives a fullerene map** |
| FulTableDist | distance bounds in table graphs |
| FulFmap | map on `Fin (3n)`; graph isomorphism from dual map isomorphism |
| FulHelixA–E | local laws, degrees, `helix_isFullerene` |
| FulBad | bad-vertex count `bad_bound` |
| FulHelixF, G | descent potential, distance bounds, non-isomorphism |
| FulHelixN | `numFullerenes_ge`, parity of orders, `nonVacuous` |
| FulEndpoint | exceptional classes, the limit, `Ful.endpoint` |
| FulLatticeAut | fidelity lemmas: H vertex-transitive, `ballFraction_congr` |

## Gate C: axioms and dependencies

`src/AuditAxioms.lean` compiled and kernel-checked with exit 0. `#print axioms` for all nine named theorems gives exactly `propext`, `Classical.choice`, `Quot.sound`. The worklist walk over types and values from those nine roots:

- Total 27,127 constants, 0 missing: 19,493 theorems, 6,192 definitions, 667 constructors, 584 inductives, 167 recursors, 17 opaque, 4 quotient, 3 axioms.
- Axioms: `Quot.sound`, `propext`, `Classical.choice`. `Lean.ofReduceBool` family: none.
- Unsafe: 0. Partial: 0.
- `implemented_by`: 5, all core (`Lean.Name.*`, `Nat.repr`, `List.attachWith`).
- `extern`: 57, all core arithmetic and arrays.
- Opaque: `String.Internal.append`, `Lean.opaqueId` and 15 `irreducible_def` wrappers from Mathlib.
- `Ful.*`: 3,955 constants in the closure, none opaque, unsafe, partial or axiom.

Limit: `leanchecker` replays each named module. Upstream Mathlib oleans are trusted, as PINS.json states. I did not hash or inspect the Mathlib checkout.

## Gate D: statement fidelity

I read `FulStatement.lean` myself against source Definition 2, Eq. (3), the ball definition, Eq. (4), Conjecture 1, Remark 5 and Section 4, and against `inputs/literal358647.json`.

**Fullerene.** `IsFullerene G` asks for connected, every vertex with exactly 3 neighbours, and some rotation system with `V + F = E + 2` and every face orbit of length 5 or 6. `SimpleGraph` supplies simplicity.

- *Rotation system.* σ is a permutation of darts that preserves tails, and any two darts with a common tail are in one σ-cycle. So σ restricts to a single cycle at each vertex. That is exactly a rotation system.
- *Face permutation.* `φ = σ * symmPerm`, so `φ(u→v) = σ(v→u)`, the dart leaving v next after the reversed dart. This is the standard face traversal. Orbit lengths are boundary-walk lengths, counted with multiplicity. Kernel evidence: my controls compute φ on explicit rotations and get the right faces; the packet's own `mapOf_isFullerene` uses this φ.
- *Genus.* For a connected graph with a rotation system, `V + F = E + 2` is exactly a sphere embedding.
- *"Faces of degrees both 5 and 6."* The source's own sentence just before says "one only allows faces with degree 5 or 6", so the formal "or" is the source's meaning. The formal class includes the dodecahedron (my `dodec_isFullerene`). A stricter reading excluding it would change only n = 20, since hexagons exist for every n ≥ 24 and no fullerene has 22 vertices. The limit is unaffected.
- The source's remark that the duals "must also be 3-connected" is a consequence, not part of Definition 2. The formal definition carries the same conditions as Definition 2.

**Hexagonal lattice.** `hexDist4` is four times the squared distance between Eq. (3) points `(√3 x + y√3/2, 3y/2 + c)`; the identity `3(2dx+dy)² + (3dy+2dc)²` is correct. Adjacency means distance 1, and `hexDist4_ge` proves 1 is the minimum over distinct points. `hex_adj_iff` gives exactly three neighbours. So this is the graph of Eq. (3) with its three nearest neighbours.

**Ball and rooted isomorphism.** `ballSet` is `edist o v < r`, the source's "smaller than r". `RootedBallIso` is a graph isomorphism of the induced subgraphs on the two balls, sending root to root whenever both roots lie in their balls, which holds for every r ≥ 1. At r = 0 both balls are empty, so the condition is vacuous and harmless. Quantifying over all K, including non-locally-finite K, is slightly stronger than the source.

**Probability.** `fullereneBallProb` is the mean over isomorphism classes of the fraction of roots with the given ball. `Fintype.card` and the sum do not depend on the instance. `Quotient.out` is harmless because `ballFraction_congr` proves the fraction is invariant under graph isomorphism. So this is a uniform isomorphism class followed by a uniform root.

**Isomorphism classes.** The source's "uniformly on the set of fullerenes with n vertices" means isomorphism classes: Section 4 counts them as `F(m)` of order m⁹ (Thurston), and Remark 5(ii) discusses generating all of them with Buckygen. The formal classes are graph isomorphism classes, matching root's recorded default of the graph-level reading. Mirror-image pairs are identified; counting them separately would change the weights by at most a factor of 2 and leave the limit unchanged.

**Limit along orders.** `fullereneLimit = atTop ⊓ 𝓟 FullereneOrders`, with `NonVacuous` proved. `F_n` is defined only for orders admitting a fullerene, so this is the right reading.

**Limit value.** `if RootedBallIso hexLattice hexRoot K o r then 1 else 0` is the Eq. (4) right side for the deterministic limit H. `hexRoot` is immaterial because `hex_vertexTransitive` is proved. Convergence for every K and r is equivalent to convergence in distribution of the ball, as the MathDB record puts it.

**Vacuity and universes.** `FullereneOrders` contains 20 and 92 (my controls), and `NonVacuous` holds. `LocalWeakConvergence.{v}` is universe polymorphic, and I instantiated it at `Type 3`.

**Labelled reading.** Under uniform labelled graphs a class has weight `n!/|Aut|`. The formal theorem does not cover this. It would follow from the same per-class bounds together with a uniform bound on `|Aut|`: the known `|Aut(G)| ≤ 120` gives `P_lab(exceptional) ≤ 120 A/F(n)`. That bound is not proved in Lean, and the source's meaning is isomorphism classes, so this is not a defect.

**Plain answer: yes, this is the exact MathDB statement**, under the graph-isomorphism-class reading the source intends.

## Gate E: semantic controls

Modules: `ControlBall`, `ControlFace`, `AuditControls`, all compiled and kernel-checked with exit 0. Axioms are within the allowed three. `decide +kernel` introduces no extra axiom.

| Control | Fact | Would fail if |
|---|---|---|
| `root_adj_iff`, `root_neighbor_card` | root has exactly the three neighbours of Eq. (3) | wrong adjacency |
| `hexDist4_triangular`, `root_not_adj_triangular` | `(1,0,false)` is at `hexDist4 = 12`, not adjacent | six-neighbour rule |
| `ball1`, `ball2`, `ball3`, `ball_counts` | balls of radius 1, 2, 3 have 1, 4, 10 vertices | `≤` in place of `<` (4, 10, 22) |
| `not_mem_strict` | neighbour not in radius-1 ball of a path | `≤` in place of `<` |
| `no_iso_0`, `no_iso_2` | wrong root on a path | root ignored |
| `no_iso_rooted` | same whole-path ball, rooted balls differ | rooting dropped |
| `no_iso_wrong_graph` | path versus triangle | wrong graph accepted |
| `fraction_P3` | `ballFraction = 1/3` | fraction miscomputed |
| `hex_root_iso`, `limit_value_one` | the two sublattices agree; limit value 1 at K = H | wrong limit |
| `k4Planar_faces`, `k4Planar_len`, `k4Planar_euler` | planar K₄: 4 triangular faces, Euler holds | wrong φ or Euler |
| `k4Toroidal_faces`, `k4Toroidal_no_euler` | toroidal K₄: 2 faces (4 and 8), Euler fails | φ = σ, which would give 4 faces and pass Euler |
| `dodec_isFullerene`, `twenty_is_order` | the dodecahedron is a fullerene, built directly from the definition | face or embedding condition wrong |
| `prism_euler`, `prism_has_square`, `prism_not_fullerene` | hexagonal prism: Euler holds, a face of length 4, not a fullerene | 5-or-6 rule absent |
| `fullerene_ge_twenty`, `k4_not_fullerene`, `no_order_18` | every fullerene has n ≥ 20 | face or Euler condition wrong |
| `helix_order_92` | packet family gives an explicit order | |
| `NegControl` | false adjacency and a `sorry` both rejected, exit 1 | checker too permissive |

Limits: `fullerene_ge_twenty` uses packet lemmas (`card_pent`). φ variants conjugate to the correct one, such as `α σ`, have the same cycle type, so no count can separate them, and none is needed. The K₄ tables are not separately proved equal to `⊤`.

## Gate F: live prior art

I read `inherited-denials.json` completely before any network use. Budget used: 2 of 2 calls and 2 of 4 strings, because the tool takes one query per call. Complete responses are in `search-response-1.txt` and `search-response-2.txt`. No page was fetched.

- No proof or disproof of Conjecture 1 surfaced. A later talk abstract by the same group is reported as listing it as open.
- Nothing on Benjamini-Schramm limits of triangulations with degrees at most 6 surfaced.
- Journal version: the HSE listing reports *J. Phys. A* 58(2) (2025) 025212. This is new relative to the qualification, which found none. I saw it only in a search summary and did not read the journal final.

**Result: NO_MATCH_FOUND_BOUNDED_INCOMPLETE.** This is not a novelty certificate. No citation index was available, the responses are tool summaries, and the Kardos habilitation and MATCH 71(1) 99-114 remain closed and unread.

## Gate G: science

**View: not routine under the campaign's rule, significance modest, and a root exclusion on significance would be defensible.**

- *Strongest case for credit.* The source poses this deliberately and names its obstacle: "no efficient bound for A(k,l,p) is known, and we could not extract it from Thurston's paper". The proof avoids estimating `A(k,l,p)` at all. Short-essential-cycle fullerenes have a count bounded independently of n, because a tube with given caps and circumference is rigid, and that beats only `F(n) → ∞`. I saw no complete reduction to a printed theorem, and the literal endpoint is now kernel-checked.
- *Strongest case against.* Sections 4.2 and 4.3 of the source already reduce the conjecture to excluding bottlenecks, so what remains is one rarity estimate. Everything is the discrete shadow of nonnegative curvature (Bol/Fiala/Alexandrov, cylinder and caps); the core needs only degrees at most 6. A Thurston-literate specialist could plausibly write a few pages, and the two-caps-and-cylinder picture is folklore-adjacent.
- *Does the formal route change this?* Little. The packet replaces Thurston/Rukhovich with an elementary helical family (`s_j = 30^(j+1)`, non-isomorphism from diameter bounds), avoids Whitney entirely, and uses a short digon descent. Those remove formal obstacles, but `F(n) → ∞` is not new. At 11,461 lines it came in under the 12.5k–22k estimate. The formal route confirms correctness; it does not raise significance.
- *Is the elementary core what a specialist would write?* The structure yes (thick/thin, flat development, cap-tube-cap). The execution no: a specialist would use cone metrics, not mod-2 chains, ring words and cap codes. That difference is one of technique and supports only modest methodological novelty.

## Defects

No defect affects validity or fidelity. Low or informational items:

1. Informational: the formal class includes the dodecahedron, while a strict reading of "both 5 and 6" would not. Only n = 20 changes.
2. Informational: the labelled reading is not formalized and would need a bound on `|Aut|`.
3. Low: comments in FulStatement and elsewhere refer to `FIDELITY.md`, which is not in the packet.
4. Low, documentary: the MathDB record's "as of June 2023" status predates the 2025 journal version; the qualification did not know of the journal version.

## What I did not check

- Proof scripts of 33 modules were not read line by line (Gate B).
- Upstream Mathlib oleans are trusted; revision not independently verified.
- The journal final, Thurston, the Kardos habilitation, MATCH 71(1) and any citation index were not read.
- The source was read as `pdftotext` output, passages only, with no page images. Eq. (3) and Eq. (4) were read from extracted text.
- `inputs/first-review-PROOF.md` and `inputs/author-candidate.md` were not read; TASK.txt did not ask for them.
- I did not compare this result against the 96 prior scopes.
- Same model family as the qualification reviewers.

## Process disclosures

- The first Lean batch produced a 48.7 KB display, over the 15,000-character cap. The harness saved it outside the lane, showed a 2 KB preview, and I did not open it. Later batches used two modules per call and then sent wrapper stdout to `/dev/null`, printing only the true exit; complete output is in each module's receipt.
- Several other displays exceeded 15,000 characters once the receipt JSON was appended: `read_endpoint_1`, `gen_control_face`, the near-cap source and denial chunks, and `control_face_1`.
- Patch scripts for controls ran under `run.py` with console output discarded; their receipts stand.
- Retained non-zero runs: `control_ball_1`, `control_face_1`, `control_face_3`, `control_face_check_3`, `audit_controls_2`, `audit_controls_check_2` (repaired by changed sources or following a changed source) and `neg_control_1` (intended).
- The denials file was read as a raw first chunk and then lossless compact JSON from an overlapping offset to the end.
