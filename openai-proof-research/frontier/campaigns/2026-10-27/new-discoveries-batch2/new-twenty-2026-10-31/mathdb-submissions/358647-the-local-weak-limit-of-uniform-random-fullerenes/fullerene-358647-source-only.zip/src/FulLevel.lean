/-
FulLevel: one clean ring read off from a simple cycle and a side: rung formulas, the period, the
ring faces, covering, injectivity of the ring faces, and the word recursion.
-/
import FulWord

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- A vertex of degree `N ≥ 2`: the rotation returns exactly at multiples of `N`. -/
theorem pow_eq_self_iff_of_deg {x : D} {N : ℕ} (hN : M.deg (M.tail x) = N) (hN1 : 2 ≤ N) (n : ℕ) :
    (M.σ ^ n) x = x ↔ N ∣ n := by
  have hx : M.σ x ≠ x := by
    intro hfix
    have hle : (univ.filter (fun d => M.tail d = M.tail x)).card ≤ 1 := by
      apply Finset.card_le_one.2
      intro a ha b hb
      have ha' := (mem_filter.1 ha).2
      have hb' := (mem_filter.1 hb).2
      have h1 : SameCycle M.σ x a := Orb.mk_eq_iff.1 ha'.symm
      have h2 : SameCycle M.σ x b := Orb.mk_eq_iff.1 hb'.symm
      obtain ⟨p, -, hp⟩ := h1.exists_pow_eq'
      obtain ⟨q, -, hq⟩ := h2.exists_pow_eq'
      have key : ∀ m, (M.σ ^ m) x = x := by
        intro m
        induction m with
        | zero => simp
        | succ m ih => rw [pow_succ', Perm.mul_apply, ih, hfix]
      rw [key] at hp hq
      rw [← hp, ← hq]
    unfold deg at hN
    omega
  have hcyc : (M.σ.cycleOf x).IsCycle := Equiv.Perm.isCycle_cycleOf _ hx
  have hsupp : (M.σ.cycleOf x).support = univ.filter (fun d => M.tail d = M.tail x) := by
    ext y
    simp only [Equiv.Perm.mem_support_cycleOf_iff, mem_filter, mem_univ, true_and]
    constructor
    · rintro ⟨h1, -⟩
      exact (Orb.mk_eq_iff.2 h1).symm
    · intro h1
      exact ⟨Orb.mk_eq_iff.1 h1.symm, Equiv.Perm.mem_support.2 hx⟩
  have hord : orderOf (M.σ.cycleOf x) = N := by
    rw [hcyc.orderOf, hsupp]
    exact hN
  constructor
  · intro h
    rw [← Equiv.Perm.cycleOf_pow_apply_self] at h
    have h1 := hcyc.pow_eq_one_iff.2 ⟨x, by rw [Equiv.Perm.cycleOf_apply_self]; exact hx, h⟩
    rw [← hord]
    exact orderOf_dvd_of_pow_eq_one h1
  · rintro ⟨c, rfl⟩
    rw [← Equiv.Perm.cycleOf_pow_apply_self, pow_mul, ← hord, pow_orderOf_eq_one, one_pow]
    rfl

namespace SimpleCycle

variable (C : SimpleCycle M)

/-- The move word of the ring on the `Q` side. -/
def W : ℕ → Bool := word C.K

/-- First rung of the ring. -/
def r0 : D := M.σ⁻¹ (C.dart 0)

/-- Rungs of the ring. -/
def r : ℕ → D := M.rung C.W C.r0

/-- The period of the ring. -/
def P : ℕ := blk C.K C.len

theorem K_period (j : ℕ) : C.K (j + C.len) = C.K j := C.K_add_len j

variable {C}

section walk

variable (hlen : 2 ≤ C.len) (hK : ∀ j, 2 ≤ C.K j)
include hlen hK

theorem r_mid {j : ℕ} (h : C.r (blk C.K j) = M.σ⁻¹ (C.dart j)) :
    ∀ s, s + 1 < C.K j → C.r (blk C.K j + 1 + s) = (M.σ ^ (s + 1)) (M.α (C.dart j)) := by
  intro s
  induction s with
  | zero =>
    intro _
    have hw : C.W (blk C.K j) = true := word_blk j
    have : C.r (blk C.K j + 1) = M.cor1 (C.r (blk C.K j)) := rung_succ_true hw
    rw [show blk C.K j + 1 + 0 = blk C.K j + 1 from rfl, this, h, zero_add, pow_one]
    simp [cor1, φ_apply]
  | succ s ih =>
    intro hs
    have h1 := ih (by omega)
    have hm1 : blk C.K j < blk C.K j + 1 + s := by omega
    have hm2 : blk C.K j + 1 + s < blk C.K (j + 1) := by
      rw [blk_succ]
      have := hK j
      omega
    have hw : C.W (blk C.K j + 1 + s) = false := word_of_mid hK hm1 hm2
    have h2 : C.r (blk C.K j + 1 + s + 1) = M.cor0 (C.r (blk C.K j + 1 + s)) := rung_succ_false hw
    rw [show blk C.K j + 1 + (s + 1) = blk C.K j + 1 + s + 1 from rfl, h2, h1, cor0, pow_succ' M.σ (s + 1),
      Perm.mul_apply]

theorem r_blk (j : ℕ) : C.r (blk C.K j) = M.σ⁻¹ (C.dart j) := by
  induction j with
  | zero => rfl
  | succ j ih =>
    have h1 := r_mid hlen hK ih (C.K j - 2) (by have := hK j; omega)
    have h2 : blk C.K (j + 1) = blk C.K j + 1 + (C.K j - 2) := by
      rw [blk_succ]
      have := hK j
      omega
    rw [h2, h1, Equiv.Perm.eq_inv_iff_eq, ← Perm.mul_apply, ← pow_succ',
      show C.K j - 2 + 1 + 1 = C.K j by have := hK j; omega]
    exact C.next_eq hlen j

theorem r_block (j s : ℕ) (hs : s + 1 < C.K j) :
    C.r (blk C.K j + 1 + s) = (M.σ ^ (s + 1)) (M.α (C.dart j)) :=
  r_mid hlen hK (r_blk hlen hK j) s hs

theorem σ_r_blk (j : ℕ) : M.σ (C.r (blk C.K j)) = C.dart j := by
  rw [r_blk hlen hK]
  exact M.σ.apply_symm_apply _

theorem σ_r_block (j s : ℕ) (hs : s + 1 < C.K j) :
    M.σ (C.r (blk C.K j + 1 + s)) = (M.σ ^ (s + 2)) (M.α (C.dart j)) := by
  rw [r_block hlen hK j s hs, ← Perm.mul_apply, ← pow_succ']

theorem hPeriod : ∀ m, C.W (m + C.P) = C.W m := fun m => word_add hK C.K_period m

theorem P_pos (hl : 0 < C.len) : 0 < C.P := by
  have := (blk_mono hK) hl
  simpa [P] using this

theorem r_add_P (m : ℕ) : C.r (m + C.P) = C.r m := by
  induction m with
  | zero =>
    rw [zero_add]
    show C.r (blk C.K C.len) = C.r 0
    rw [r_blk hlen hK, C.dart_len]
    rfl
  | succ m ih =>
    have h1 : m + 1 + C.P = (m + C.P) + 1 := by omega
    rw [h1]
    show M.rung C.W C.r0 ((m + C.P) + 1) = M.rung C.W C.r0 (m + 1)
    rw [rung_succ, rung_succ, show M.rung C.W C.r0 (m + C.P) = M.rung C.W C.r0 m from ih,
      show C.W (m + C.P) = C.W m from hPeriod hlen hK m]

theorem r_mod (m : ℕ) : C.r (m % C.P) = C.r m :=
  Function.Periodic.map_mod_nat (f := C.r) (a := C.P) (fun x => r_add_P hlen hK x) m

variable {Q : Finset M.F} (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q)

include h hor

/-- The ring triangles lie on the `Q` side. -/
theorem tri_mem (m : ℕ) : M.tri (C.r m) ∈ Q := by
  obtain ⟨j, h1, h2⟩ := exists_blk hK m
  rcases Nat.lt_or_ge (blk C.K j) m with h3 | h3
  · obtain ⟨s, rfl⟩ : ∃ s, m = blk C.K j + 1 + s := ⟨m - blk C.K j - 1, by omega⟩
    have hs : s + 1 < C.K j := by rw [blk_succ] at h2; have := hK j; omega
    unfold tri cor0
    rw [σ_r_block hlen hK j s hs]
    exact fan_side h (hor j) (s + 2) (by omega) (by omega)
  · have hm : m = blk C.K j := by omega
    subst hm
    unfold tri cor0
    rw [σ_r_blk hlen hK]
    exact hor j

/-- The first corner of a ring triangle lies on the cycle. -/
theorem tail_cor0_mem (m : ℕ) : M.tail (M.cor0 (C.r m)) ∈ C.verts := by
  obtain ⟨j, h1, h2⟩ := exists_blk hK m
  rcases Nat.lt_or_ge (blk C.K j) m with h3 | h3
  · obtain ⟨s, rfl⟩ : ∃ s, m = blk C.K j + 1 + s := ⟨m - blk C.K j - 1, by omega⟩
    have hs : s + 1 < C.K j := by rw [blk_succ] at h2; have := hK j; omega
    unfold cor0
    rw [σ_r_block hlen hK j s hs, tail_pow, C.chain]
    exact C.tail_mem _
  · have hm : m = blk C.K j := by omega
    subst hm
    unfold cor0
    rw [σ_r_blk hlen hK]
    exact C.tail_mem _

/-- Every triangle of the side with a corner on the cycle is a ring triangle. -/
theorem cover {f : M.F} (hf : f ∈ Q) (ht : 1 ≤ C.t f) : ∃ m, M.tri (C.r m) = f := by
  obtain ⟨x, hx⟩ := Finset.card_pos.1 ht
  obtain ⟨hxf, hxv⟩ := by simpa only [mem_filter, mem_univ, true_and] using hx
  obtain ⟨i, hi⟩ := C.exists_of_vert_mem hxv
  have hj : M.tail x = M.tail (C.dart (i + C.len - 1 + 1)) := by
    rw [show i + C.len - 1 + 1 = i + C.len by have := C.len_pos; omega, C.periodic]
    exact hi.symm
  obtain ⟨t, h0, hle, rfl⟩ := corner_cases hlen h hor (i + C.len - 1) hj (hxf ▸ hf)
  set j := i + C.len - 1 with hjdef
  by_cases ht1 : t = 1
  · subst ht1
    refine ⟨blk C.K j, ?_⟩
    unfold tri cor0
    rw [σ_r_blk hlen hK, ← hxf, pow_one, ← M.face_α, M.α_α]
  · obtain ⟨s, rfl⟩ : ∃ s, t = s + 2 := ⟨t - 2, by omega⟩
    refine ⟨blk C.K j + 1 + s, ?_⟩
    unfold tri cor0
    rw [σ_r_block hlen hK j s (by omega), hxf]

theorem tri_t (m : ℕ) : 1 ≤ C.t (M.tri (C.r m)) :=
  Finset.card_pos.2 ⟨M.cor0 (C.r m), by
    simp only [mem_filter, mem_univ, true_and]
    exact ⟨rfl, tail_cor0_mem hlen hK h hor m⟩⟩

/-- If the ring has as many faces as the period, the ring faces are distinct. -/
theorem tri_inj (hl : 0 < C.len)
    (hcard : (Q.filter (fun f => 1 ≤ C.t f)).card = C.P) {a b : ℕ}
    (ha : a < C.P) (hb : b < C.P) (hab : M.tri (C.r a) = M.tri (C.r b)) : a = b := by
  have himg : (range C.P).image (fun m => M.tri (C.r m)) = Q.filter (fun f => 1 ≤ C.t f) := by
    apply Finset.Subset.antisymm
    · intro f hf
      obtain ⟨m, -, rfl⟩ := Finset.mem_image.1 hf
      exact Finset.mem_filter.2 ⟨tri_mem hlen hK h hor m, tri_t hlen hK h hor m⟩
    · intro f hf
      obtain ⟨hfQ, hft⟩ := Finset.mem_filter.1 hf
      obtain ⟨m, rfl⟩ := cover hlen hK h hor hfQ hft
      refine Finset.mem_image.2 ⟨m % C.P, Finset.mem_range.2 (Nat.mod_lt _ (P_pos hlen hK hl)), ?_⟩
      show M.tri (C.r (m % C.P)) = M.tri (C.r m)
      rw [r_mod hlen hK]
  have hc : ((range C.P).image (fun m => M.tri (C.r m))).card = (range C.P).card := by
    rw [himg, hcard, Finset.card_range]
  have hinj := Finset.card_image_iff.1 hc
  exact hinj (by simpa using ha) (by simpa using hb) hab

end walk

/-! ### The top darts and the next cycle -/

/-- The top dart of the `k`-th move `U`, oriented along the ring. -/
def topDart (C : SimpleCycle M) (k : ℕ) : D := M.α (M.cor1 (C.r (posU C.W k)))

theorem σ_pow_top_succ (hT : M.IsTriangulation)
    (hinf : ({m | C.W m = false} : Set ℕ).Infinite) (k : ℕ) :
    (M.σ ^ (gap C.W k + 2)) (topDart C (k + 1)) = M.cor1 (C.r (posU C.W k)) := by
  have hgap := gap_eq hinf k
  have hp : C.W (posU C.W k) = false := posU_false hinf k
  have hmid : ∀ m, posU C.W k < m → m < posU C.W k + 1 + gap C.W k → C.W m = true :=
    fun m h1 h2 => between_true hinf h1 (hgap ▸ h2)
  have := M.σ_pow_top hT (W := C.W) (r0 := C.r0) hp hmid
  unfold topDart
  rw [hgap]
  exact this

/-- Consecutive top darts are incident. -/
theorem head_topDart (hT : M.IsTriangulation) (hinf : ({m | C.W m = false} : Set ℕ).Infinite)
    (k : ℕ) : M.tail (M.α (topDart C k)) = M.tail (topDart C (k + 1)) := by
  have h := σ_pow_top_succ hT hinf k
  rw [show M.α (topDart C k) = M.cor1 (C.r (posU C.W k)) by simp [topDart], ← h, tail_pow]

variable {Q Q' : Finset M.F}

/-- The faces met while turning at a top vertex from the next top dart back to the current one
are ring faces. -/
theorem face_turn (hT : M.IsTriangulation) (hinf : ({m | C.W m = false} : Set ℕ).Infinite)
    (k s : ℕ) (hs1 : 1 ≤ s) (hs2 : s ≤ gap C.W k + 2) :
    ∃ m, M.face ((M.σ ^ s) (topDart C (k + 1))) = M.tri (C.r m) := by
  have hgap := gap_eq hinf k
  set p := posU C.W k with hp
  set g := gap C.W k with hg
  have hmid : ∀ m, p < m → m < p + 1 + g → C.W m = true :=
    fun m h1 h2 => between_true hinf h1 (hgap ▸ h2)
  by_cases hs3 : s = g + 2
  · refine ⟨p, ?_⟩
    rw [hs3, σ_pow_top_succ hT hinf k]
    exact M.face_cor1 _
  · obtain ⟨a, rfl⟩ : ∃ a, s = a + 1 := ⟨s - 1, by omega⟩
    have ha : a ≤ g := by omega
    refine ⟨p + 1 + (g - a), ?_⟩
    have h1 : M.σ (topDart C (k + 1)) = M.α (C.r (posU C.W (k + 1))) := by
      unfold topDart
      exact M.σ_α_cor1 hT _
    rw [pow_succ, Perm.mul_apply, h1, hgap]
    have h2 := M.σ_pow_α_rung hT (W := C.W) (r0 := C.r0) (p + (g - a)) a (fun m h3 h4 =>
      hmid m (by omega) (by omega))
    rw [show p + (g - a) + 1 + a = p + 1 + g by omega] at h2
    rw [show M.rung C.W C.r0 (p + 1 + g) = C.r (p + 1 + g) from rfl] at h2
    show M.face ((M.σ ^ a) (M.α (C.r (p + 1 + g)))) = _
    rw [h2]
    show M.face (M.cor2 (C.r (p + (g - a) + 1))) = _
    rw [M.face_cor2]
    rw [show p + (g - a) + 1 = p + 1 + (g - a) by omega]
    rfl

/-- **The ring-word recursion.** If the top darts form a simple cycle whose vertices have degree
six, with its own side disjoint from the ring, then its first-return exponents are read off from
the gaps of the word. -/
theorem K_succ (hT : M.IsTriangulation) (hinf : ({m | C.W m = false} : Set ℕ).Infinite)
    (C' : SimpleCycle M) (hlen' : 2 ≤ C'.len) (hdart : ∀ k, C'.dart k = topDart C k)
    (hside : IsSide C' Q') (hor' : ∀ j, M.face (C'.dart j) ∈ Q')
    (hdeg : ∀ k, M.deg (M.tail (C'.dart k)) = 6)
    (hring : ∀ m, M.tri (C.r m) ∉ Q') (k : ℕ) :
    C'.K k + gap C.W k + 2 = 6 := by
  have hnext := C'.next_eq hlen' k
  rw [hdart k, show M.α (topDart C k) = M.cor1 (C.r (posU C.W k)) by simp [topDart], hdart (k + 1)]
    at hnext
  have hchain := σ_pow_top_succ (C := C) hT hinf k
  set z := M.cor1 (C.r (posU C.W k)) with hz
  set t := topDart C (k + 1) with ht
  have hzt : M.tail z = M.tail t := by rw [← hchain, tail_pow]
  have hdeg_t : M.deg (M.tail t) = 6 := by rw [ht, ← hdart]; exact hdeg _
  have hdeg_z : M.deg (M.tail z) = 6 := by rw [hzt]; exact hdeg_t
  have h6z := pow_eq_self_iff_of_deg (M := M) hdeg_z (by norm_num)
  have h6t := pow_eq_self_iff_of_deg (M := M) hdeg_t (by norm_num)
  -- orbit exponent is a multiple of 6
  have hsum : (M.σ ^ (gap C.W k + 2 + C'.K k)) z = z := by
    rw [pow_add, Perm.mul_apply, hnext, hchain]
  have hdvd := (h6z _).1 hsum
  have hK0 := C'.K_pos k
  have hzα : z = M.α (C'.dart k) := by
    rw [hdart k]
    simp [topDart, hz]
  -- bound
  have hbound : gap C.W k + 2 + C'.K k ≤ 6 := by
    by_contra hnot
    have hnot' : 7 ≤ gap C.W k + 2 + C'.K k := by omega
    have hft : M.face t ∈ Q' := by rw [ht, ← hdart]; exact hor' _
    by_cases hN : 6 ≤ gap C.W k + 2
    · obtain ⟨m, hm⟩ := face_turn hT hinf k 6 (by omega) hN
      rw [(h6t 6).2 (dvd_refl 6)] at hm
      rw [hm] at hft
      exact hring m hft
    · have hs1 : 1 ≤ 7 - (gap C.W k + 2) := by omega
      have hs2 : 7 - (gap C.W k + 2) ≤ C'.K k := by omega
      have hf := CMap.SimpleCycle.fan_side hside (hor' k) _ hs1 hs2
      rw [← hzα] at hf
      have h1 : (M.σ ^ (7 - (gap C.W k + 2))) z = (M.σ ^ 7) t := by
        rw [← hchain, ← Perm.mul_apply, ← pow_add]
        congr 2
        omega
      have h2 : (M.σ ^ 7) t = M.σ t := by
        rw [show 7 = 1 + 6 from rfl, pow_add, Perm.mul_apply, (h6t 6).2 (dvd_refl 6), pow_one]
      rw [h1, h2] at hf
      obtain ⟨m, hm⟩ := face_turn hT hinf k 1 le_rfl (by omega)
      rw [pow_one] at hm
      rw [hm] at hf
      exact hring m hf
  obtain ⟨c, hc⟩ := hdvd
  omega

end SimpleCycle

end CMap

end Ful

end
