/-
FulTransfer: on a flat region without short essential cycles, the triangles of the triangulation
around a dart form a ball isomorphic to the hexagonal lattice ball.
-/
import FulPsi
import FulLattice
import FulBallIso

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt CMap
open scoped Classical

universe u

/-- The lattice point of a vertex of `H`. -/
def pLat (a : ℤ × ℤ × Bool) : ℤ × ℤ := (-a.2.1, -a.1)
/-- The direction index of a vertex of `H`. -/
def uOf (c : Bool) : ℕ := if c then 2 else 1

/-! ### Lattice steps of the hexagonal lattice -/

theorem ex0 : ex 0 = 1 := rfl
theorem ey0 : ey 0 = 0 := rfl
theorem ex1 : ex 1 = 0 := rfl
theorem ey1 : ey 1 = 1 := rfl
theorem ex2 : ex 2 = -1 := rfl
theorem ey2 : ey 2 = 1 := rfl
theorem ex3 : ex 3 = -1 := rfl
theorem ey3 : ey 3 = 0 := rfl
theorem ex5 : ex 5 = 1 := rfl
theorem ey5 : ey 5 = -1 := rfl
theorem ex9 : ex 9 = -1 := rfl
theorem ey9 : ey 9 = 0 := rfl

theorem pLat_step {a b : ℤ × ℤ × Bool} (h : hexLattice.Adj a b) :
    pLat b = pLat a ∨ ∃ u, u < 6 ∧ pLat b = ((pLat a).1 + ex u, (pLat a).2 + ey u) := by
  rw [hex_adj_iff] at h
  obtain ⟨x, y, c⟩ := a
  obtain ⟨x', y', c'⟩ := b
  simp only [pLat] at h ⊢
  rcases h with ⟨h1, h2, ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩⟩ | ⟨h1, h2, ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩⟩
  · exact Or.inl rfl
  · exact Or.inr ⟨0, by norm_num, by rw [ex0, ey0]; congr 1 <;> ring⟩
  · exact Or.inr ⟨5, by norm_num, by rw [ex5, ey5]; congr 1 <;> ring⟩
  · exact Or.inl rfl
  · exact Or.inr ⟨3, by norm_num, by rw [ex3, ey3]; congr 1 <;> ring⟩
  · exact Or.inr ⟨2, by norm_num, by rw [ex2, ey2]; congr 1 <;> ring⟩

theorem lreach_stay {n : ℕ} {z : ℤ × ℤ} (h : LReach n z) : LReach (n + 1) z := LReach.stay h

theorem lreach_mono {m n : ℕ} (hmn : m ≤ n) {z : ℤ × ℤ} (h : LReach m z) : LReach n z := by
  induction n, hmn using Nat.le_induction with
  | base => exact h
  | succ n _ ih => exact lreach_stay ih

/-- A walk in `H` of length `n` ending at the root gives a lattice point within `n` steps. -/
theorem lreach_walk' {a b : ℤ × ℤ × Bool} (q : hexLattice.Walk a b) (hb : pLat b = (0, 0)) :
    LReach q.length (pLat a) := by
  induction q with
  | nil =>
    rw [hb]
    exact LReach.zero
  | @cons a b c hab q' ih =>
    rw [SimpleGraph.Walk.length_cons]
    have ih' := ih hb
    rcases pLat_step hab.symm with h | ⟨u, hu, h⟩
    · rw [h]
      exact lreach_stay ih'
    · rw [h]
      exact LReach.step u hu ih'

theorem lreach_walk {a : ℤ × ℤ × Bool} (q : hexLattice.Walk a hexRoot) :
    LReach q.length (pLat a) :=
  lreach_walk' q (by simp [pLat, hexRoot])

theorem lreach_ball {k : ℕ} {a : ℤ × ℤ × Bool} (h : a ∈ ballSet hexLattice hexRoot k) :
    LReach k (pLat a) := by
  obtain ⟨p, hp⟩ := mem_ballSet_iff.1 h
  have := lreach_walk p.reverse
  rw [SimpleGraph.Walk.length_reverse] at this
  exact lreach_mono (by omega) this

variable {D : Type*} [Fintype D] [DecidableEq D] {T : CMap D} {d0 : D} {R : ℕ}
variable {V : Type u} [Fintype V] {G : SimpleGraph V} {τ : D → V}

/-- The adjacency across each of the three edges of an up-triangle. -/
theorem Psi_ft (hT : T.IsTriangulation) (hF : T.FlatTo (T.tail d0) R)
    (hface : ∀ x y, T.face x = T.face y ↔ τ x = τ y)
    (hadj : ∀ d, G.Adj (τ d) (τ (T.α d))) {x y x' y' : ℤ}
    (hz : L1 (-y, -x) + 20 ≤ R)
    (hxy : (x' = x ∧ y' = y) ∨ (x' = x ∧ y' = y - 1) ∨ (x' = x + 1 ∧ y' = y - 1)) :
    G.Adj (τ (T.psi d0 (-y, -x) 1)) (τ (T.psi d0 (-y', -x') 2)) := by
  set z : ℤ × ℤ := (-y, -x) with hzdef
  set x0 := T.psi d0 z 1 with hx0
  have hLz1 : L1 (z.1 + ex 1, z.2 + ey 1) ≤ L1 z + 2 := L1_add z 1
  have hφ1 : T.φ x0 = T.psi d0 (z.1 + ex 1, z.2 + ey 1) 5 := φ_psi hT hF 1 (by omega)
  have hz1 : ((z.1 + ex 1, z.2 + ey 1) : ℤ × ℤ) = (-y, -x + 1) := by
    rw [ex1, ey1]; simp [hzdef]
  rw [hz1] at hφ1
  have hL2 : L1 ((-y : ℤ), (-x + 1 : ℤ)) ≤ L1 z + 2 := by rw [← hz1]; exact hLz1
  rcases hxy with ⟨hh1, hh2⟩ | ⟨hh1, hh2⟩ | ⟨hh1, hh2⟩
  · -- the edge at the tail
    rw [hh1, hh2]
    have h1 := hadj x0
    have h2 : τ (T.α x0) = τ (T.σ x0) := (hface _ _).1 (T.face_α x0)
    rw [h2, psi_succ] at h1
    exact h1
  · -- the edge of the third side
    rw [hh1, hh2]
    have h1 := hadj (T.φ x0)
    have h2 : τ (T.φ x0) = τ x0 := (hface _ _).1 (T.face_φ x0)
    rw [h2] at h1
    have h3 : T.α (T.φ x0) = T.psi d0 (-(y - 1), -x) 2 := by
      rw [hφ1, α_psi hT hF 5 (by omega)]
      have h4 : (((-y : ℤ) + ex 5, (-x + 1 : ℤ) + ey 5) : ℤ × ℤ) = (-(y - 1), -x) := by
        rw [ex5, ey5]; ext <;> simp <;> ring
      rw [h4, psi_mod hF (by
        have := L1_add (-y, -x + 1) 5
        rw [show ((-y : ℤ) + ex 5, (-x + 1 : ℤ) + ey 5) = (-(y - 1), -x) from h4] at this
        omega) (5 + 3)]
    rw [h3] at h1
    exact h1
  · -- the last edge
    rw [hh1, hh2]
    have h1 := hadj (T.φ (T.φ x0))
    have h2 : τ (T.φ (T.φ x0)) = τ x0 := by
      rw [(hface _ _).1 (T.face_φ (T.φ x0)), (hface _ _).1 (T.face_φ x0)]
    rw [h2] at h1
    have hφ2 : T.φ (T.φ x0) = T.psi d0 (-(y - 1), -x) 9 := by
      rw [hφ1, φ_psi hT hF 5 (by omega)]
      have h4 : (((-y : ℤ) + ex 5, (-x + 1 : ℤ) + ey 5) : ℤ × ℤ) = (-(y - 1), -x) := by
        rw [ex5, ey5]; ext <;> simp <;> ring
      rw [h4]
    have hL3 : L1 ((-(y - 1) : ℤ), (-x : ℤ)) ≤ L1 z + 4 := by
      have := L1_add ((-y : ℤ), (-x + 1 : ℤ)) 5
      rw [show ((-y : ℤ) + ex 5, (-x + 1 : ℤ) + ey 5) = (-(y - 1), -x) by
        rw [ex5, ey5]; ext <;> simp <;> ring] at this
      omega
    have h3 : T.α (T.φ (T.φ x0)) = T.psi d0 z 0 := by
      rw [hφ2, α_psi hT hF 9 (by omega)]
      have h4 : (((-(y - 1) : ℤ) + ex 9, (-x : ℤ) + ey 9) : ℤ × ℤ) = z := by
        rw [ex9, ey9, hzdef]; ext <;> simp <;> ring
      rw [h4, psi_mod hF (by omega) (9 + 3)]
    rw [h3] at h1
    have ht : τ (T.psi d0 (-(y - 1), -(x + 1)) 2) = τ (T.psi d0 z 0) := by
      have hb : L1 ((-(y - 1) : ℤ), (-(x + 1) : ℤ)) ≤ L1 z + 4 := by
        have h5 := L1_add z 5
        rw [show (z.1 + ex 5, z.2 + ey 5) = (-(y - 1), -(x + 1)) by
          rw [ex5, ey5, hzdef]; ext <;> simp <;> ring] at h5
        omega
      have hφt := φ_psi hT hF (z := ((-(y - 1) : ℤ), (-(x + 1) : ℤ))) 2 (by omega)
      have h6 : (((-(y - 1) : ℤ) + ex 2, (-(x + 1) : ℤ) + ey 2) : ℤ × ℤ) = z := by
        rw [ex2, ey2, hzdef]; ext <;> simp <;> ring
      rw [h6] at hφt
      have h7 : T.psi d0 z (2 + 4) = T.psi d0 z 0 := psi_mod hF (by omega) (2 + 4)
      rw [h7] at hφt
      calc τ (T.psi d0 (-(y - 1), -(x + 1)) 2)
          = τ (T.φ (T.psi d0 (-(y - 1), -(x + 1)) 2)) :=
            ((hface _ _).1 (T.face_φ _)).symm
        _ = τ (T.psi d0 z 0) := by rw [hφt]
    rw [ht]
    exact h1

end Ful

end
