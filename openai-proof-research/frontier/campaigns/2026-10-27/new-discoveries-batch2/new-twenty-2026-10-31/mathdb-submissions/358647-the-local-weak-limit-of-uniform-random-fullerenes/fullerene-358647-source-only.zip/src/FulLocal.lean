/-
FulLocal: injectivity of the development on balls.  A collision along a lattice geodesic gives a
simple cycle; if it is short it has a small flat side, and the corner identity contradicts the
bounded turning of a geodesic.
-/
import FulDev

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

/-- Lattice unit vectors, periodic in the direction index. -/
def exT : ℕ → ℤ
  | 0 => 1 | 1 => 0 | 2 => -1 | 3 => -1 | 4 => 0 | _ => 1
def eyT : ℕ → ℤ
  | 0 => 0 | 1 => 1 | 2 => 1 | 3 => 0 | 4 => -1 | _ => -1
def ex (u : ℕ) : ℤ := exT (u % 6)
def ey (u : ℕ) : ℤ := eyT (u % 6)

/-- The norm used for bookkeeping. -/
def L1 (z : ℤ × ℤ) : ℕ := z.1.natAbs + z.2.natAbs

namespace CMap

variable {M : CMap D}

/-- The rotated development. -/
def psi (M : CMap D) (d0 : D) (z : ℤ × ℤ) (u : ℕ) : D := (M.σ ^ u) (M.dev d0 z.1 z.2)

/-- Straight step in every direction. -/
theorem psi_E (hT : M.IsTriangulation) {d0 : D} {R : ℕ} (hF : M.FlatTo (M.tail d0) R) {z : ℤ × ℤ}
    {u : ℕ} (hu : u < 6) (h : L1 z + 6 ≤ R) :
    M.stp (M.psi d0 z u) = M.psi d0 (z.1 + ex u, z.2 + ey u) u := by
  obtain ⟨x, y⟩ := z
  simp only [L1] at h
  interval_cases u
  · have := dev_E0 hT hF (x := x) (y := y) (by omega)
    simpa [psi, ex, ey, exT, eyT] using this
  · have := dev_E1 (M := M) d0 x y
    simpa [psi, ex, ey, exT, eyT] using this
  · have := dev_E2 hT hF (x := x) (y := y) (by omega)
    simpa [psi, ex, ey, exT, eyT, pow_succ', Perm.mul_apply, sub_eq_add_neg] using this
  · have := dev_E3 hT hF (x := x) (y := y) (by omega)
    simpa [psi, ex, ey, exT, eyT, pow_succ', Perm.mul_apply, sub_eq_add_neg] using this
  · have := dev_E4 hF (x := x) (y := y) (by omega)
    simpa [psi, ex, ey, exT, eyT, pow_succ', Perm.mul_apply, sub_eq_add_neg] using this
  · have := dev_E5 hT hF (x := x) (y := y) (by omega)
    simpa [psi, ex, ey, exT, eyT, pow_succ', Perm.mul_apply, sub_eq_add_neg] using this

theorem tail_psi (d0 : D) (z : ℤ × ℤ) (u : ℕ) :
    M.tail (M.psi d0 z u) = M.tail (M.dev d0 z.1 z.2) := tail_pow _ _

theorem reach_psi (d0 : D) (z : ℤ × ℤ) (u : ℕ) :
    M.Reach (M.tail d0) (L1 z) (M.tail (M.psi d0 z u)) := by
  rw [tail_psi]
  exact reach_dev d0 z.1 z.2

/-- `α` in terms of the step, at a flat head. -/
theorem α_eq_of_Fl {x : D} (hf : M.Fl (M.α x)) : M.α x = M.σ (M.σ (M.σ (M.stp x))) := by
  simpa [stp_apply] using hf.symm

theorem pow6_congr {x : D} (h : (M.σ ^ 6) x = x) {a b : ℕ} (hab : a % 6 = b % 6) :
    (M.σ ^ a) x = (M.σ ^ b) x := by
  rw [← pow_mod_apply h a, ← pow_mod_apply h b, hab]

theorem Fl.pow6 {x : D} (h : M.Fl x) : (M.σ ^ 6) x = x := by
  have e : (M.σ ^ 6) x = M.σ (M.σ (M.σ (M.σ (M.σ (M.σ x))))) := by
    simp only [pow_succ', pow_zero, mul_one, Perm.mul_apply]
  rw [e]
  exact h

/-- A cycle from a closed sequence of darts with distinct tails. -/
theorem exists_cycle_of_seq {n : ℕ} (hn : 3 ≤ n) (Dt : ℕ → D)
    (hhead : ∀ i, i < n → M.tail (M.α (Dt i)) = M.tail (Dt ((i + 1) % n)))
    (hinj : ∀ i j, i < n → j < n → M.tail (Dt i) = M.tail (Dt j) → i = j) :
    ∃ C : SimpleCycle M, C.len = n ∧ ∀ j, C.dart j = Dt (j % n) := by
  have hmodlt : ∀ j, j % n < n := fun j => Nat.mod_lt _ (by omega)
  have hsucc : ∀ j, (j % n + 1) % n = (j + 1) % n := fun j => by
    rw [Nat.mod_add_mod]
  refine ⟨{ len := n
            len_pos := by omega
            dart := fun j => Dt (j % n)
            periodic := fun j => by simp only [Nat.add_mod_right]
            chain := fun j => by
              have := hhead (j % n) (hmodlt j)
              rw [hsucc] at this
              exact this
            tail_inj := fun i j hi hj hij => by
              simp only [Nat.mod_eq_of_lt hi, Nat.mod_eq_of_lt hj] at hij
              exact hinj i j hi hj hij
            edge_inj := fun i j hi hj hij => ?_ }, rfl, fun j => rfl⟩
  simp only [Nat.mod_eq_of_lt hi, Nat.mod_eq_of_lt hj] at hij
  rcases M.edge_eq_iff.1 hij with h | h
  · exact hinj i j hi hj (by rw [h])
  · exfalso
    have h1 := hinj j ((i + 1) % n) hj (hmodlt _) (by rw [h]; exact hhead i hi)
    have h2 := hinj i ((j + 1) % n) hi (hmodlt _) (by
      have := hhead j hj
      rw [h, M.α_α] at this
      exact this)
    by_cases h3 : i + 1 < n
    · rw [Nat.mod_eq_of_lt h3] at h1
      subst h1
      by_cases h4 : i + 1 + 1 < n
      · rw [Nat.mod_eq_of_lt h4] at h2
        omega
      · have : i + 1 + 1 = n := by omega
        rw [this, Nat.mod_self] at h2
        omega
    · have : i + 1 = n := by omega
      rw [this, Nat.mod_self] at h1
      subst h1
      rw [zero_add, Nat.mod_eq_of_lt (by omega)] at h2
      omega

/-- An exact first-return exponent. -/
theorem K_exact {C : SimpleCycle M} (hlen : 2 ≤ C.len) {j t : ℕ} (ht0 : 0 < t) (ht6 : t < 6)
    (hdeg : M.deg (M.tail (C.dart (j + 1))) = 6)
    (hp : (M.σ ^ t) (M.α (C.dart j)) = C.dart (j + 1)) : C.K j = t := by
  have hle : C.K j ≤ t := Nat.find_min' _ ⟨ht0, by rw [hp]; exact C.edge_mem _⟩
  have hn := C.next_eq hlen j
  have hsplit : (M.σ ^ (t - C.K j)) (C.dart (j + 1)) = C.dart (j + 1) := by
    conv_lhs => rw [← hn]
    rw [← Perm.mul_apply, ← pow_add, show t - C.K j + C.K j = t by omega, hp]
  have hdvd := (pow_eq_self_iff_of_deg hdeg (by norm_num) _).1 hsplit
  have hpos := C.K_pos j
  obtain ⟨c, hc⟩ := hdvd
  omega

theorem K_le_five {C : SimpleCycle M} (hlen : 2 ≤ C.len) {j : ℕ}
    (hdeg : M.deg (M.tail (M.α (C.dart j))) = 6) : C.K j ≤ 5 := by
  have h6 := (pow_eq_self_iff_of_deg hdeg (by norm_num) 6).2 (dvd_refl 6)
  have hle : C.K j ≤ 6 := Nat.find_min' _ ⟨by norm_num, by
    rw [h6, M.edge_α]; exact C.edge_mem _⟩
  by_contra hn
  have h66 : C.K j = 6 := by omega
  have hnext := C.next_eq hlen j
  rw [h66, h6] at hnext
  exact C.next_ne hlen j hnext.symm

/-- A region grows by one vertex per step until it is exhausted. -/
theorem reach_region (hc : M.Connected) {C : SimpleCycle M} {S : Finset M.F} (h : IsSide C S)
    {v0 : M.V} {R0 : ℕ} (h0 : ∀ v ∈ C.verts, M.Reach v0 R0 v) :
    ∀ v ∈ clV S, M.Reach v0 (R0 + (clV S).card) v := by
  have key : ∀ t, ((clV S).filter (M.Reach v0 (R0 + t))) = clV S ∨
      t + 1 ≤ ((clV S).filter (M.Reach v0 (R0 + t))).card := by
    intro t
    induction t with
    | zero =>
      right
      refine Finset.card_pos.2 ⟨M.tail (C.dart 0), mem_filter.2 ⟨h.verts_subset (C.tail_mem 0), ?_⟩⟩
      exact h0 _ (C.tail_mem 0)
    | succ t ih =>
      have hsub : ((clV S).filter (M.Reach v0 (R0 + t))) ⊆
          ((clV S).filter (M.Reach v0 (R0 + (t + 1)))) := by
        intro v hv
        obtain ⟨h1, h2⟩ := mem_filter.1 hv
        exact mem_filter.2 ⟨h1, Reach.stay h2⟩
      by_cases hall : ((clV S).filter (M.Reach v0 (R0 + t))) = clV S
      · left
        apply Finset.Subset.antisymm (filter_subset _ _)
        intro v hv
        have h3 : v ∈ (clV S).filter (M.Reach v0 (R0 + t)) := by rw [hall]; exact hv
        exact hsub h3
      · rcases ih with ih | ih
        · exact absurd ih hall
        right
        let g : M.V → F2 := fun v => if M.Reach v0 (R0 + t) v then 1 else 0
        have hnotconst : ¬ ∀ d, M.edge d ∈ clE S → g (M.tail d) = g (M.tail (M.α d)) := by
          intro hg
          apply hall
          apply Finset.Subset.antisymm (filter_subset _ _)
          intro v hv
          have hval := h.side_const hc g hg v hv
          have h1 : g (M.tail (C.dart 0)) = 1 := by
            simp only [g]
            exact ite_eq_left ((h0 _ (C.tail_mem 0)).mono (by omega))
          rw [h1] at hval
          refine mem_filter.2 ⟨hv, ?_⟩
          by_contra hn
          simp only [g, ite_eq_right hn] at hval
          exact zero_ne_one hval
        push Not at hnotconst
        obtain ⟨d, hdE, hne⟩ := hnotconst
        have hends : M.tail d ∈ clV S ∧ M.tail (M.α d) ∈ clV S := by
          obtain ⟨d', hd', hf⟩ := mem_clE.1 hdE
          have h1 : M.tail d' ∈ clV S := mem_clV.2 ⟨d', rfl, hf⟩
          have h2 : M.tail (M.α d') ∈ clV S := by
            rw [← M.tail_φ]
            exact mem_clV.2 ⟨_, rfl, by rw [M.face_φ]; exact hf⟩
          rcases M.edge_eq_iff.1 hd' with rfl | rfl
          · exact ⟨h1, h2⟩
          · rw [M.α_α]
            exact ⟨h2, h1⟩
        have hgrow : ∃ w ∈ clV S, M.Reach v0 (R0 + (t + 1)) w ∧ ¬ M.Reach v0 (R0 + t) w := by
          by_cases ha : M.Reach v0 (R0 + t) (M.tail d)
          · refine ⟨M.tail (M.α d), hends.2, Reach.step d rfl ha, fun hb => hne ?_⟩
            simp only [g]
            rw [ite_eq_left ha, ite_eq_left hb]
          · by_cases hb : M.Reach v0 (R0 + t) (M.tail (M.α d))
            · refine ⟨M.tail d, hends.1, ?_, ha⟩
              have := Reach.step (M.α d) rfl hb
              rwa [M.α_α] at this
            · exfalso
              apply hne
              simp only [g]
              rw [ite_eq_right ha, ite_eq_right hb]
        obtain ⟨w, hw1, hw2, hw3⟩ := hgrow
        have hstrict : ((clV S).filter (M.Reach v0 (R0 + t))) ⊂
            ((clV S).filter (M.Reach v0 (R0 + (t + 1)))) := by
          refine ⟨hsub, fun hb => hw3 ?_⟩
          exact (mem_filter.1 (hb (mem_filter.2 ⟨hw1, hw2⟩))).2
        have := Finset.card_lt_card hstrict
        omega
  intro v hv
  rcases key (clV S).card with h1 | h1
  · exact (mem_filter.1 (h1.symm ▸ hv)).2
  · exfalso
    have := Finset.card_le_card (filter_subset (M.Reach v0 (R0 + (clV S).card)) (clV S))
    omega

end CMap

end Ful

end
