import FulWitness

#print axioms Ful.CMap.IsSide.tri_count
#print axioms Ful.CMap.IsSide.boundary_corners
#print axioms Ful.CMap.IsSide.t_le_two
#print axioms Ful.CMap.IsSide.card_t_two
#print axioms Ful.CMap.IsSide.ring_identity
#print axioms Ful.CMap.exists_simpleCycle_of_even
#print axioms Ful.CMap.exists_cycle_of_strong
#print axioms Ful.CMap.IsSide.chord_split
#print axioms Ful.CMap.block_induct
#print axioms Ful.CMap.comp_compl_strong
#print axioms Ful.CMap.card_bd_Y_le
#print axioms Ful.CMap.bounded_disc
#print axioms Ful.tetra_nonvacuous
#print axioms Ful.tetra_cycle_has_side
