/-
FulStatement: the literal statement of MathDB 358647 (Conjecture 1 of Bille, Buchstaber, Coste,
Kuriki, Spodarev, arXiv:2306.01462), with the definitions of fullerene, hexagonal lattice, ball,
rooted isomorphism, uniform random fullerene and local weak convergence (Eq. (4) of the source).
No proof content.  See FIDELITY.md for every modelling decision.
-/
import Mathlib.Combinatorics.SimpleGraph.Metric
import Mathlib.Combinatorics.SimpleGraph.Dart
import Mathlib.Combinatorics.SimpleGraph.Maps
import Mathlib.GroupTheory.Perm.Cycle.Basic
import Mathlib.Basic.Real.Basic
import Mathlib.Data.Fintype.Quotient
import Mathlib.Topology.Instances.Real.Lemmas

set_option linter.unusedSectionVars false

noncomputable section

namespace Ful.Stmt

open SimpleGraph Filter Topology
open scoped Classical

universe u v

/-! ### Planar cubic graphs with faces of length 5 and 6 -/

/-- A rotation system on a simple graph: a permutation `σ` of the darts that preserves the tail
and whose cycles are exactly the sets of darts with a common tail. -/
structure RotationSystem {V : Type u} (G : SimpleGraph V) where
  σ : Equiv.Perm G.Dart
  tail_eq : ∀ d, (σ d).fst = d.fst
  transitive : ∀ d d' : G.Dart, d.fst = d'.fst → σ.SameCycle d d'

/-- Reversal of a dart as a permutation. -/
def symmPerm {V : Type u} (G : SimpleGraph V) : Equiv.Perm G.Dart :=
  Function.Involutive.toPerm Dart.symm Dart.symm_involutive

/-- The face permutation of a rotation system. -/
def RotationSystem.φ {V : Type u} {G : SimpleGraph V} (ρ : RotationSystem G) : Equiv.Perm G.Dart :=
  ρ.σ * symmPerm G

/-- The number of faces: the number of cycles of the face permutation. -/
def RotationSystem.numFaces {V : Type u} {G : SimpleGraph V} (ρ : RotationSystem G) : ℕ :=
  Nat.card (Quotient (Equiv.Perm.SameCycle.setoid ρ.φ))

/-- The length of the face containing a dart. -/
def RotationSystem.faceLen {V : Type u} {G : SimpleGraph V} (ρ : RotationSystem G) (d : G.Dart) :
    ℕ :=
  Nat.card {d' : G.Dart // ρ.φ.SameCycle d d'}

/-- A fullerene graph: finite, connected, 3-regular, simple (built in: `SimpleGraph`), admitting a
genus-zero rotation system all of whose faces have length 5 or 6. -/
structure IsFullerene {V : Type u} [Fintype V] (G : SimpleGraph V) : Prop where
  connected : G.Connected
  cubic : ∀ v, Nat.card (G.neighborSet v) = 3
  embedding : ∃ ρ : RotationSystem G,
    Nat.card V + ρ.numFaces = Nat.card G.edgeSet + 2 ∧ ∀ d, ρ.faceLen d = 5 ∨ ρ.faceLen d = 6

/-! ### Balls and rooted isomorphism (source p. 4) -/

/-- The vertices at graph distance strictly smaller than `r` from `o` (source p. 4). -/
def ballSet {V : Type u} (G : SimpleGraph V) (o : V) (r : ℕ) : Set V :=
  {v | G.edist o v < (r : ℕ∞)}

/-- The balls of radius `r` around the roots are isomorphic as rooted graphs. For `r = 0` both balls
are empty and the root condition is vacuous. -/
def RootedBallIso {V : Type u} {W : Type v} (G : SimpleGraph V) (o : V) (K : SimpleGraph W) (o' : W)
    (r : ℕ) : Prop :=
  ∃ e : G.induce (ballSet G o r) ≃g K.induce (ballSet K o' r),
    ∀ (h : o ∈ ballSet G o r) (h' : o' ∈ ballSet K o' r), e ⟨o, h⟩ = ⟨o', h'⟩

/-! ### The hexagonal lattice (source Eq. (3)) -/

/-- `Bool` as the coordinate `c ∈ {0,1}` of Eq. (3). -/
def bit (c : Bool) : ℤ := if c then 1 else 0

/-- Four times the squared Euclidean distance of the points of Eq. (3) with coordinates
`(x, y, c)` and `(x', y', c')`: the point is `(√3 x + y √3/2, 3y/2 + c)`, so the squared distance is
`3 (dx + dy/2)^2 + (3 dy/2 + dc)^2` with `dx = x - x'`, `dy = y - y'`, `dc = c - c'`. -/
def hexDist4 (p q : ℤ × ℤ × Bool) : ℤ :=
  3 * (2 * (p.1 - q.1) + (p.2.1 - q.2.1)) ^ 2 + (3 * (p.2.1 - q.2.1) + 2 * (bit p.2.2 - bit q.2.2)) ^ 2

/-- The planar hexagonal lattice `H` of Eq. (3): vertices `(x, y, c)`, two vertices adjacent when
their Euclidean distance is `1`, which is the minimal distance (`FulLattice` proves that the
neighbours are the three nearest ones and gives them explicitly). -/
def hexLattice : SimpleGraph (ℤ × ℤ × Bool) where
  Adj p q := hexDist4 p q = 4
  symm := ⟨fun p q h => by
    have : hexDist4 q p = hexDist4 p q := by
      unfold hexDist4
      ring
    rw [this]
    exact h⟩
  loopless := ⟨fun p h => by
    have h' : hexDist4 p p = 0 := by
      unfold hexDist4
      ring
    rw [h'] at h
    norm_num at h⟩

/-- The root of the hexagonal lattice. The lattice is vertex-transitive (`FulLattice`). -/
def hexRoot : ℤ × ℤ × Bool := (0, 0, false)

/-! ### The uniform random fullerene and Eq. (4) -/

/-- Labelled fullerene graphs on `n` vertices. -/
abbrev LabelledFullerene (n : ℕ) : Type := {G : SimpleGraph (Fin n) // IsFullerene G}

/-- Graph isomorphism as a setoid on labelled fullerenes. -/
def fullereneSetoid (n : ℕ) : Setoid (LabelledFullerene n) where
  r G G' := Nonempty (G.1 ≃g G'.1)
  iseqv := ⟨fun _ => ⟨Iso.refl⟩, fun ⟨e⟩ => ⟨e.symm⟩, fun ⟨e⟩ ⟨f⟩ => ⟨e.trans f⟩⟩

/-- Isomorphism classes of fullerene graphs on `n` vertices: the finite set from which `F_n` is
drawn uniformly. Isomorphism classes, not labelled graphs: see FIDELITY.md. -/
abbrev FullereneClass (n : ℕ) : Type := Quotient (fullereneSetoid n)

noncomputable instance (n : ℕ) : Fintype (FullereneClass n) := Fintype.ofFinite _

/-- The number of isomorphism classes of fullerene graphs on `n` vertices. -/
def numFullerenes (n : ℕ) : ℕ := Fintype.card (FullereneClass n)

/-- The fraction of vertices of `G` whose ball of radius `r` is rooted-isomorphic to the ball of
`(K, o)`: the probability for a uniformly chosen root. -/
def ballFraction {n : ℕ} (G : SimpleGraph (Fin n)) (r : ℕ) {W : Type v} (K : SimpleGraph W) (o : W) :
    ℝ :=
  (Nat.card {v : Fin n // RootedBallIso G v K o r} : ℝ) / n

/-- `P(B_{F_n}(o_n, r) ≅ B_K(o, r))`: expectation over the uniform isomorphism class, then the
uniform root. Well-defined on classes (`ballFraction` is invariant; see `FulEndpoint`). -/
def fullereneBallProb (n : ℕ) (r : ℕ) {W : Type v} (K : SimpleGraph W) (o : W) : ℝ :=
  (∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r K o) / (numFullerenes n : ℝ)

/-- The values of `n` with at least one fullerene: the sequence `F_n` is defined along these `n`. -/
def FullereneOrders : Set ℕ := {n | Nonempty (FullereneClass n)}

/-- The filter "n → ∞ along the n for which a fullerene exists". -/
def fullereneLimit : Filter ℕ := atTop ⊓ 𝓟 FullereneOrders

/-- **Conjecture 1 of arXiv:2306.01462, MathDB 358647.** Local weak convergence (Eq. (4)) of the
uniform random fullerene on `n` vertices to the hexagonal lattice: for every `r` and every fixed
rooted graph `(K, o)`, `P(B_{F_n}(o_n, r) ≅ B_K(o, r))` tends to `P(B_H(0, r) ≅ B_K(o, r))`, the
latter being `1` or `0` since `H` is deterministic. -/
def LocalWeakConvergence : Prop :=
  ∀ (r : ℕ) (W : Type v) (K : SimpleGraph W) (o : W),
    Tendsto (fun n => fullereneBallProb n r K o) fullereneLimit
      (𝓝 (if RootedBallIso hexLattice hexRoot K o r then 1 else 0))

/-- Non-vacuity: the limit filter is proper, so `LocalWeakConvergence` is not vacuous. -/
def NonVacuous : Prop := Filter.NeBot fullereneLimit

end Ful.Stmt
