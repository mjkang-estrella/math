/-
FulWord: words of a ring.  Blocks `A U^(K-2)`, the positions of the moves `U`, the gaps, and the
ring-word map `Phi`.
-/
import FulFan
import Mathlib.Data.Nat.Nth
import Mathlib.Data.Nat.Count

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open scoped Classical

/-- Start position of block `j` of the word with run data `K`. -/
def blk (K : ℕ → ℕ) : ℕ → ℕ
  | 0 => 0
  | j + 1 => blk K j + (K j - 1)

/-- The word with blocks `A U^(K j - 2)`. -/
def word (K : ℕ → ℕ) (m : ℕ) : Bool := decide (∃ j, blk K j = m)

variable {K : ℕ → ℕ}

@[simp] theorem blk_zero : blk K 0 = 0 := rfl
theorem blk_succ (j : ℕ) : blk K (j + 1) = blk K j + (K j - 1) := rfl

theorem blk_mono (hK : ∀ j, 2 ≤ K j) : StrictMono (blk K) :=
  strictMono_nat_of_lt_succ (fun j => by rw [blk_succ]; have := hK j; omega)

theorem word_blk (j : ℕ) : word K (blk K j) = true := by
  simp only [word, decide_eq_true_eq]
  exact ⟨j, rfl⟩

theorem word_eq_true_iff {m : ℕ} : word K m = true ↔ ∃ j, blk K j = m := by
  simp only [word, decide_eq_true_eq]

theorem word_of_mid (hK : ∀ j, 2 ≤ K j) {j m : ℕ} (h1 : blk K j < m) (h2 : m < blk K (j + 1)) :
    word K m = false := by
  rw [Bool.eq_false_iff]
  intro h
  obtain ⟨j', rfl⟩ := word_eq_true_iff.1 h
  have hm := blk_mono hK
  have a := hm.lt_iff_lt.1 h1
  have b := hm.lt_iff_lt.1 h2
  omega

/-- Every position lies in a block. -/
theorem exists_blk (hK : ∀ j, 2 ≤ K j) (m : ℕ) : ∃ j, blk K j ≤ m ∧ m < blk K (j + 1) := by
  have hex : ∃ j, m < blk K j := by
    refine ⟨m + 1, ?_⟩
    exact lt_of_lt_of_le (Nat.lt_succ_self m) ((blk_mono hK).id_le (m + 1))
  have hspec := Nat.find_spec hex
  have hne : Nat.find hex ≠ 0 := by
    intro h
    rw [h] at hspec
    simp at hspec
  obtain ⟨j, hj⟩ := Nat.exists_eq_succ_of_ne_zero hne
  refine ⟨j, ?_, ?_⟩
  · have := Nat.find_min hex (show j < Nat.find hex by omega)
    omega
  · rw [hj] at hspec
    exact hspec

variable {ℓ : ℕ}

theorem blk_add (hP : ∀ j, K (j + ℓ) = K j) (j : ℕ) : blk K (j + ℓ) = blk K j + blk K ℓ := by
  induction j with
  | zero => simp
  | succ j ih =>
    have : j + 1 + ℓ = j + ℓ + 1 := by omega
    rw [this, blk_succ, ih, blk_succ, hP]
    omega

theorem word_add (hK : ∀ j, 2 ≤ K j) (hP : ∀ j, K (j + ℓ) = K j) (m : ℕ) :
    word K (m + blk K ℓ) = word K m := by
  rw [Bool.eq_iff_iff, word_eq_true_iff, word_eq_true_iff]
  constructor
  · rintro ⟨j, hj⟩
    by_cases hlt : j < ℓ
    · have h1 := (blk_mono hK).lt_iff_lt.2 hlt
      omega
    · obtain ⟨j', rfl⟩ := Nat.exists_eq_add_of_le (not_lt.1 hlt)
      refine ⟨j', ?_⟩
      have h2 : blk K (ℓ + j') = blk K j' + blk K ℓ := by
        rw [add_comm]; exact blk_add hP j'
      omega
  · rintro ⟨j, rfl⟩
    exact ⟨j + ℓ, blk_add hP j⟩

/-! ### Positions of `U` -/

/-- Position of the `k`-th move `U`. -/
def posU (W : ℕ → Bool) (k : ℕ) : ℕ := Nat.nth (fun m => W m = false) k

/-- The set of `U` positions is infinite for a periodic word with at least one `U`. -/
theorem infinite_U {W : ℕ → Bool} {P : ℕ} (hP : 0 < P) (hper : ∀ m, W (m + P) = W m)
    {m0 : ℕ} (h0 : W m0 = false) : ({m | W m = false} : Set ℕ).Infinite := by
  have hmem : ∀ n, W (m0 + n * P) = false := by
    intro n
    induction n with
    | zero => simpa using h0
    | succ n ih =>
      rw [show m0 + (n + 1) * P = (m0 + n * P) + P by ring, hper, ih]
  apply Set.infinite_of_injective_forall_mem (f := fun n => m0 + n * P) _ hmem
  intro a b hab
  have := Nat.eq_of_mul_eq_mul_right hP (Nat.add_left_cancel hab)
  exact this

variable {W : ℕ → Bool}

theorem posU_false (hinf : ({m | W m = false} : Set ℕ).Infinite) (k : ℕ) :
    W (posU W k) = false := Nat.nth_mem_of_infinite hinf k

theorem posU_mono (hinf : ({m | W m = false} : Set ℕ).Infinite) : StrictMono (posU W) :=
  Nat.nth_strictMono hinf

/-- Between two consecutive `U`s all moves are `A`. -/
theorem between_true (hinf : ({m | W m = false} : Set ℕ).Infinite) {k m : ℕ}
    (h1 : posU W k < m) (h2 : m < posU W (k + 1)) : W m = true := by
  by_contra hne
  have hm : W m = false := by simpa using hne
  have hc := Nat.nth_count (p := fun x => W x = false) hm
  have hmono := posU_mono hinf
  have a : posU W k < posU W (Nat.count (fun x => W x = false) m) := by
    show posU W k < Nat.nth (fun x => W x = false) _
    rw [hc]
    exact h1
  have b : posU W (Nat.count (fun x => W x = false) m) < posU W (k + 1) := by
    show Nat.nth (fun x => W x = false) _ < posU W (k + 1)
    rw [hc]
    exact h2
  have a' := hmono.lt_iff_lt.1 a
  have b' := hmono.lt_iff_lt.1 b
  omega

/-- A `U` position is `posU` of its count. -/
theorem posU_count {m : ℕ} (hm : W m = false) :
    posU W (Nat.count (fun x => W x = false) m) = m :=
  Nat.nth_count (p := fun x => W x = false) hm

/-- The number of `A` moves between the `k`-th and `(k+1)`-st `U`. -/
def gap (W : ℕ → Bool) (k : ℕ) : ℕ := posU W (k + 1) - posU W k - 1

theorem gap_eq (hinf : ({m | W m = false} : Set ℕ).Infinite) (k : ℕ) :
    posU W (k + 1) = posU W k + 1 + gap W k := by
  have : posU W k < posU W (k + 1) := posU_mono hinf (Nat.lt_add_one k)
  unfold gap
  omega

/-- The ring-word map. -/
def Phi (W : ℕ → Bool) : ℕ → Bool := word (fun j => 4 - gap W j)

/-! ### Counting over a period -/

theorem count_add_period {p : ℕ → Prop} [DecidablePred p] {P : ℕ} (hper : ∀ m, p (m + P) ↔ p m) (a : ℕ) :
    Nat.count p (a + P) = Nat.count p a + Nat.count p P := by
  rw [Nat.count_add]
  congr 1
  induction a with
  | zero => simp
  | succ a ih =>
    rw [← ih]
    have h1 := Nat.count_succ (fun k => p (a + k)) P
    have h2 := Nat.count_succ' (fun k => p (a + k)) P
    have h3 : (if p (a + P) then 1 else 0) = (if p (a + 0) then 1 else 0) := by
      simp only [Nat.add_zero]
      split_ifs with h h' h' <;> simp_all
    simp only [show ∀ k, a + 1 + k = a + (k + 1) from fun k => by omega]
    omega

/-- Shifting `U` indices by the number of `U`s in a period. -/
theorem posU_add_period (hinf : ({m | W m = false} : Set ℕ).Infinite) {P : ℕ}
    (hper : ∀ m, W (m + P) = W m) (k : ℕ) :
    posU W (k + Nat.count (fun x => W x = false) P) = posU W k + P := by
  have hmem := posU_false hinf k
  have hp : W (posU W k + P) = false := by rw [hper, hmem]
  have h1 := Nat.nth_count (p := fun x => W x = false) hp
  have h2 : Nat.count (fun x => W x = false) (posU W k + P) =
      Nat.count (fun x => W x = false) (posU W k) + Nat.count (fun x => W x = false) P :=
    count_add_period (p := fun x => W x = false) (fun m => by simp only [hper]) _
  have h3 : Nat.count (fun x => W x = false) (posU W k) = k := by
    show Nat.count (fun x => W x = false) (Nat.nth (fun x => W x = false) k) = k
    exact Nat.count_nth_of_infinite hinf k
  rw [h2, h3] at h1
  exact h1

end Ful

end
