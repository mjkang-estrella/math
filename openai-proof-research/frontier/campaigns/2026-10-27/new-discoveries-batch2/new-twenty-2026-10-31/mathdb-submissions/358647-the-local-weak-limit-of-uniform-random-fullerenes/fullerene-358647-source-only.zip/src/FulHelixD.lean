/-
FulHelixD: injectivity and degrees of the helical table.
-/
import FulHelixC

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

namespace Ful.Helix

/-- The twelve vertices of degree five. -/
def Pent (s m u : ℤ) : Prop :=
  u = 0 ∨ u = s ∨ u = s + 1 ∨ u = s + 2 ∨ u = 2 * s + 2 ∨ u = 2 * s + 4 ∨ u = m ∨ u = m - s ∨
    u = m - s - 1 ∨ u = m - s - 2 ∨ u = m - 2 * s - 2 ∨ u = m - 2 * s - 4

variable {s m u : ℤ} {k k' : ℕ}

/-- The classes of a vertex in `[-s, m + s]`. -/
theorem classes (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s) :
    (u = -1 ∨ u = -s ∨ (-s < u ∧ u < -1)) ∨ u = 0 ∨ u = m ∨
      (u = m + 1 ∨ u = m + s ∨ (m + 1 < u ∧ u < m + s)) ∨
      (u = 1 ∨ (2 ≤ u ∧ u ≤ s - 2) ∨ u = s - 1 ∨ u = s ∨ u = s + 1 ∨ u = s + 2 ∨
        (s + 3 ≤ u ∧ u ≤ 2 * s) ∨ u = 2 * s + 1 ∨ u = 2 * s + 2 ∨ u = 2 * s + 3 ∨ u = 2 * s + 4 ∨
        u = 2 * s + 5 ∨ (2 * s + 5 < u ∧ u < m - (2 * s + 5)) ∨ u = m - (2 * s + 5) ∨
        (m - u = 2 * s + 4) ∨ (m - u = 2 * s + 3) ∨ (m - u = 2 * s + 2) ∨ (m - u = 2 * s + 1) ∨
        (s + 3 ≤ m - u ∧ m - u ≤ 2 * s) ∨ (m - u = s + 2) ∨ (m - u = s + 1) ∨ (m - u = s) ∨
        (m - u = s - 1) ∨ (2 ≤ m - u ∧ m - u ≤ s - 2) ∨ m - u = 1) := by
  omega

macro "len_at" : tactic =>
  `(tactic| simp (disch := omega) only [len, Nb_int, Nb_zero, Nb_mid, Nb_m, Nb_intB, low_gen,
      low_cf, up_gen, up_cf, intA, ifT, ifF, cf_a, cf_b, cf_c, cf_d, cf_e, cf_f,
      List.length_cons, List.length_nil, List.length_append, List.cons_append, List.nil_append,
      List.map_cons, List.map_nil, List.length_map, Nat.reduceAdd, Nat.zero_add, Nat.add_zero,
      Nat.reduceEqDiff, true_and, and_true, false_and, false_or, or_false])

set_option maxHeartbeats 2000000 in
theorem len_cases (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s) :
    (len s m u = 5 ∧ Pent s m u) ∨ (len s m u = 6 ∧ ¬ Pent s m u) := by
  have hLp : Lp s = 2 * s + 5 := rfl
  unfold Pent
  rcases classes hs hm h1 h2 with (hc | hc | ⟨hc1, hc2⟩) | hc | hc | (hc | hc | ⟨hc1, hc2⟩) |
    (hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc | hc |
      hc | hc | hc | hc) <;> len_at <;> omega

theorem law_all (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s)
    (hk : k < len s m u) : Law s m u k := by
  have hc : u ≤ -1 ∨ u = 0 ∨ (0 < u ∧ u < m) ∨ u = m ∨ m < u := by omega
  rcases hc with hc | hc | ⟨hc1, hc2⟩ | hc | hc
  · exact law_int (by omega) hm h1 hc hk
  · exact law_zero (by omega) hm hc hk
  · exact law_mid (by omega) hm hc1 hc2 hk
  · exact law_m (by omega) hm hc hk
  · exact law_intB (by omega) hm hc h2 hk

/-- Every vertex other than `0` has a neighbour strictly closer to `0`. -/
theorem desc (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ m + s) (h0 : u ≠ 0) :
    ∃ k, k < len s m u ∧ (nz s m u k).natAbs < u.natAbs := by
  have hLp : Lp s = 2 * s + 5 := rfl
  have hc : (-s ≤ u ∧ u ≤ -2) ∨ u = -1 ∨ (0 < u ∧ u < m) ∨ u = m ∨ u = m + 1 ∨ (m + 1 < u) := by
    omega
  rcases hc with ⟨h3, h4⟩ | h3 | ⟨h3, h4⟩ | h3 | h3 | h3
  · refine ⟨0, ?_, ?_⟩
    · have hl : len s m u = 6 := by
        rcases len_cases hs hm h1 h2 with h | h
        · exact absurd h.2 (by unfold Pent; omega)
        · exact h.1
      omega
    · reduce_u; omega
  · refine ⟨5, ?_, ?_⟩
    · have hl : len s m u = 6 := by
        rcases len_cases hs hm h1 h2 with h | h
        · exact absurd h.2 (by unfold Pent; omega)
        · exact h.1
      omega
    · reduce_u; omega
  · refine ⟨0, ?_, ?_⟩
    · rcases len_cases hs hm h1 h2 with h | h <;> omega
    · reduce_u; omega
  · refine ⟨3, ?_, ?_⟩
    · rcases len_cases hs hm h1 h2 with h | h <;> omega
    · reduce_u; omega
  · refine ⟨5, ?_, ?_⟩
    · have hl : len s m u = 6 := by
        rcases len_cases hs hm h1 h2 with h | h
        · exact absurd h.2 (by unfold Pent; omega)
        · exact h.1
      omega
    · reduce_u; omega
  · refine ⟨0, ?_, ?_⟩
    · have hl : len s m u = 6 := by
        rcases len_cases hs hm h1 h2 with h | h
        · exact absurd h.2 (by unfold Pent; omega)
        · exact h.1
      omega
    · reduce_u; omega

end Ful.Helix
