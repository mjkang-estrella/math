/-
FulHelixA: the local laws of the helical rotation table, interior cap vertices of the first cap.
-/
import FulHelix

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

namespace Ful.Helix

/-- Entry of a rotation. -/
def nz (s m u : ℤ) (k : ℕ) : ℤ := (Nb s m u).getD k 0
/-- Reverse index. -/
def iz (s m u : ℤ) (k : ℕ) : ℕ := (Ix s m u).getD k 0
/-- Length of the rotation. -/
def len (s m u : ℤ) : ℕ := (Nb s m u).length

@[simp] theorem get0 {α} (x : α) (l : List α) (d : α) : (x :: l).getD 0 d = x := rfl
@[simp] theorem get1 {α} (x y : α) (l : List α) (d : α) : (x :: y :: l).getD 1 d = y := rfl
@[simp] theorem get2 {α} (x y z : α) (l : List α) (d : α) : (x :: y :: z :: l).getD 2 d = z := rfl
@[simp] theorem get3 {α} (x y z w : α) (l : List α) (d : α) :
    (x :: y :: z :: w :: l).getD 3 d = w := rfl
@[simp] theorem get4 {α} (x y z w v : α) (l : List α) (d : α) :
    (x :: y :: z :: w :: v :: l).getD 4 d = v := rfl
@[simp] theorem get5 {α} (x y z w v u : α) (l : List α) (d : α) :
    (x :: y :: z :: w :: v :: u :: l).getD 5 d = u := rfl

/-- The local laws of the table at a dart. -/
def Law (s m u : ℤ) (k : ℕ) : Prop :=
  (-s ≤ nz s m u k ∧ nz s m u k ≤ m + s) ∧ nz s m u k ≠ u ∧
    iz s m u k < len s m (nz s m u k) ∧ nz s m (nz s m u k) (iz s m u k) = u ∧
    nz s m (nz s m u k) ((iz s m u k + 1) % len s m (nz s m u k)) =
      nz s m u ((k + len s m u - 1) % len s m u)

macro "reduce_t" : tactic =>
  `(tactic| simp (disch := omega) only [nz, iz, len, Nb_int, Nb_zero, Nb_mid, Nb_m, Nb_intB, low_gen,
      low_cf, up_gen, up_cf, Ix_int, Ix_zero, Ix_mid, Ix_m, Ix_intB, intA, ifT, ifF, cf_a, cf_b, cf_c,
      cf_d, cf_e, cf_f, cfIx_a, cfIx_b0, cfIx_b1, cfIx_b2, cfIx_c, cfIx_d, cfIx_e, cfIx_f,
      List.length_cons, List.length_nil, List.length_append, List.cons_append, List.nil_append,
      List.map_cons, List.map_nil, get0, get1, get2, get3, get4, get5, ifT, ifF,
      Nat.add_mod_right, Nat.mod_self, Nat.reduceAdd, Nat.reduceMod, Nat.reduceSub, Nat.zero_add,
      Nat.add_zero])

variable {s m u : ℤ} {k : ℕ}

theorem law_int (hs : 2 ≤ s) (hm : 3 * (2 * s + 5) ≤ m) (h1 : -s ≤ u) (h2 : u ≤ -1)
    (hk : k < len s m u) : Law s m u k := by
  have hlen : len s m u = 6 := by
    show (Nb s m u).length = 6
    rw [Nb_int (by omega)]; rfl
  rw [hlen] at hk
  have hc : u = -1 ∨ u = -s ∨ (-s < u ∧ u < -1) := by omega
  have hLp : Lp s = 2 * s + 5 := rfl
  unfold Law
  rcases hc with hc | hc | ⟨hc1, hc2⟩ <;> interval_cases k <;> reduce_t <;> omega

end Ful.Helix
