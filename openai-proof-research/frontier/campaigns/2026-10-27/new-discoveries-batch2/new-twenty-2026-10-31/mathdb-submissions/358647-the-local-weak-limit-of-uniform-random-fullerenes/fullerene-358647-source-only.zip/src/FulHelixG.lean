/-
FulHelixG: the fullerene graphs of the helical family, the distance bounds, and
non-isomorphism of members with very different circumference.
-/
import FulHelixF
import FulTableDist

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

noncomputable section

namespace Ful.Helix

open Finset Table
open scoped Classical

variable {s m : ℕ} (hs : 4 ≤ s) (hm : 3 * (2 * s + 5) ≤ m)

theorem Lp_toNat : (Lp (s : ℤ)).toNat = 2 * s + 5 := by
  have : Lp (s : ℤ) = 2 * s + 5 := rfl
  omega

/-- The vertex count of the fullerene graph. -/
theorem helix_card : Fintype.card (helix hs hm).T.dual.V = 2 * m + 4 * s - 2 := by
  set A := helix hs hm with hA
  have hF : Fintype.card A.Dart = 3 * Fintype.card A.T.F := by
    have h := A.isTriangulation.corners_card (univ : Finset A.T.F)
    simpa using h
  have hD : Fintype.card A.Dart = ∑ u, A.deg u := A.card_dart
  have hsum : ∑ u, (6 - (A.deg u : ℤ)) = 12 := helix_sum hs hm
  have hsum2 : (6 * ((V s m : ℕ) : ℤ)) - ∑ u, (A.deg u : ℤ) = 12 := by
    rw [← hsum, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin]
    simp only [nsmul_eq_mul]
    ring
  have hsum3 : ∑ u, (A.deg u : ℤ) = ((∑ u, A.deg u : ℕ) : ℤ) := by push_cast; rfl
  rw [hsum3, ← hD] at hsum2
  have hV : Fintype.card A.T.dual.V = Fintype.card A.T.F := rfl
  rw [hV]
  have hVm : ((V s m : ℕ) : ℤ) = m + 2 * s + 1 := by unfold V; push_cast; ring
  omega

theorem helix_deg6 (u : Fin (V s m)) : (helix hs hm).deg u ≤ 6 := by
  rcases helix_deg hs hm u with h | h <;> omega

/-- Edge bound for the labels. -/
theorem helix_Lam (u : Fin (V s m)) (k : ℕ) (hk : k < (helix hs hm).deg u) :
    |lab s ((helix hs hm).nb u k) - lab s u| ≤ 2 * (s : ℤ) + 5 := by
  have hs' : (4 : ℤ) ≤ s := by exact_mod_cast hs
  have hm' : 3 * (2 * (s : ℤ) + 5) ≤ m := by exact_mod_cast hm
  have hb := edge_bound (s := s) (m := m) hs' hm' (lab_range u).1 (lab_range u).2 hk
  have hlaw := law_all (s := s) (m := m) hs' hm' (lab_range u).1 (lab_range u).2 hk
  unfold Law at hlaw
  obtain ⟨⟨r1, r2⟩, -⟩ := hlaw
  have hLpdef : Lp (s : ℤ) = 2 * s + 5 := rfl
  show |lab s (unlab s (V s m) V_pos (nz s m (lab s u) k)) - lab s u| ≤ _
  rw [lab_unlab' ⟨r1, r2⟩, abs_le]
  constructor <;> omega

variable {n : ℕ} (hcard : Fintype.card (helix hs hm).T.dual.V = n)

/-- The fullerene graph of the helical family, on `Fin n`. -/
def helixG : SimpleGraph (Fin n) :=
  graphOf (helix hs hm).T.dual (Fintype.equivFinOfCardEq hcard) (helix_isFullerene hs hm).simple.1

theorem helixG_isFullerene : Stmt.IsFullerene (helixG hs hm hcard) :=
  isFullerene_graphOf (helix_isFullerene hs hm) _

/-- **Lower bound on distances.** -/
theorem helixG_lower : ∃ x y : Fin n, ∀ p : (helixG hs hm hcard).Walk x y,
    3 * (m : ℤ) + 6 * s - 4 * (2 * s + 5) ≤ p.length * (2 * (2 * s + 5)) := by
  have h := helix_isFullerene hs hm
  set e := Fintype.equivFinOfCardEq hcard with he
  have hs' : (4 : ℤ) ≤ s := by exact_mod_cast hs
  have hm' : 3 * (2 * (s : ℤ) + 5) ≤ m := by exact_mod_cast hm
  have hLam := helix_Lam hs hm
  obtain ⟨p0, ht0⟩ : ∃ p0 : (helix hs hm).Dart, lab s p0.1.1 = -(s : ℤ) :=
    ⟨⟨(unlab s (V s m) V_pos (-(s : ℤ)), 0), (helix hs hm).deg_pos _⟩,
      lab_unlab' (by constructor <;> omega)⟩
  obtain ⟨p1, ht1⟩ : ∃ p1 : (helix hs hm).Dart, lab s p1.1.1 = (m : ℤ) + s :=
    ⟨⟨(unlab s (V s m) V_pos ((m : ℤ) + s), 0), (helix hs hm).deg_pos _⟩,
      lab_unlab' (by constructor <;> omega)⟩
  refine ⟨Fv e p0, Fv e p1, fun p => ?_⟩
  have h1 : |height e (lab s) (Fv e p1) - height e (lab s) (Fv e p0)| ≤
      (p.length : ℤ) * (2 * (2 * (s : ℤ) + 5)) := height_walk h e (lab s) _ hLam p
  rw [height_Fv, height_Fv] at h1
  have c0 := lam_corner (lab s) _ hLam p0
  have c1 := lam_corner (lab s) _ hLam p1
  unfold corners at h1
  rw [ht0] at c0 h1
  rw [ht1] at c1 h1
  simp only [abs_le] at c0 c1 h1
  have hnn : (0:ℤ) ≤ 2 * s + 5 := by omega
  obtain ⟨⟨a1, a2⟩, ⟨a3, a4⟩⟩ := c0
  obtain ⟨⟨b1, b2⟩, ⟨b3, b4⟩⟩ := c1
  obtain ⟨h2, h3⟩ := h1
  linarith [a2, a4, b1, b3, h3]

/-- **Upper bound on distances.** -/
theorem helixG_upper (x y : Fin n) : ∃ p : (helixG hs hm hcard).Walk x y,
    p.length ≤ 12 * (m / (2 * s + 5) + (2 * s + 5) + s) + 5 := by
  have h := helix_isFullerene hs hm
  set e := Fintype.equivFinOfCardEq hcard with he
  have hs' : (4 : ℤ) ≤ s := by exact_mod_cast hs
  have hm' : 3 * (2 * (s : ℤ) + 5) ≤ m := by exact_mod_cast hm
  let B : Fin (V s m) → ℕ := fun u => Bz s m (lab s u)
  let c : Fin (V s m) := unlab s (V s m) V_pos 0
  have hc : ∀ u, B u = 0 → u = c := by
    intro u hu
    have h0 : lab s u = 0 := Bz_eq_zero hs' hm' (lab_range u).1 (lab_range u).2 hu
    rw [← unlab_lab (hn := V_pos) u, h0]
  have hstep : ∀ u, B u ≠ 0 → ∃ k, k < (helix hs hm).deg u ∧ B ((helix hs hm).nb u k) + 1 ≤ B u := by
    intro u hu
    have hl0 : lab s u ≠ 0 := by
      intro h0
      apply hu
      show Bz s m (lab s u) = 0
      rw [h0, Bz_mid le_rfl (by omega)]
      simp
    obtain ⟨k, hk, hlt⟩ := desc2 hs' hm' (lab_range u).1 (lab_range u).2 hl0
    refine ⟨k, hk, ?_⟩
    have hlaw := law_all (s := s) (m := m) hs' hm' (lab_range u).1 (lab_range u).2 hk
    unfold Law at hlaw
    obtain ⟨⟨r1, r2⟩, -⟩ := hlaw
    show Bz s m (lab s (unlab s (V s m) V_pos (nz s m (lab s u) k))) + 1 ≤ _
    rw [lab_unlab' ⟨r1, r2⟩]
    exact hlt
  have hN : ∀ u, B u ≤ m / (2 * s + 5) + (2 * s + 5) + s := by
    intro u
    have := Bz_bound hs' hm' (lab_range u).1 (lab_range u).2
    show Bz s m (lab s u) ≤ _
    have e1 : ((m : ℤ)).toNat = m := by simp
    have e2 : ((s : ℤ)).toNat = s := by simp
    rw [e1, Lp_toNat, e2] at this
    exact this
  exact diam_le h e (helix_deg6 hs hm) B c _ hc hstep hN x y

/-- Non-isomorphism of two helical graphs with very different circumference. -/
theorem helixG_not_iso {s' m' : ℕ} (hs' : 4 ≤ s') (hm' : 3 * (2 * s' + 5) ≤ m')
    (hcard' : Fintype.card (helix hs' hm').T.dual.V = n)
    (hL : 24 * (2 * s + 5) ≤ 2 * s' + 5) (hmm : m' ≤ m)
    (hlarge : 24 * (2 * s + 5) * ((2 * s' + 5) + s') + 14 * (2 * s + 5) ≤ 2 * m) :
    IsEmpty ((helixG hs hm hcard) ≃g (helixG hs' hm' hcard')) := by
  refine ⟨fun i => ?_⟩
  obtain ⟨x, y, hxy⟩ := helixG_lower hs hm hcard
  obtain ⟨q, hq⟩ := helixG_upper hs' hm' hcard' (i x) (i y)
  let p : (helixG hs hm hcard).Walk x y :=
    (q.map i.symm.toHom).copy (by simp) (by simp)
  have hp : p.length ≤ 12 * (m' / (2 * s' + 5) + (2 * s' + 5) + s') + 5 := by
    show ((q.map i.symm.toHom).copy _ _).length ≤ _
    rw [SimpleGraph.Walk.length_copy, SimpleGraph.Walk.length_map]
    exact hq
  have hb := hxy p
  set X := m' / (2 * s' + 5) with hX
  have hX1 : X * (2 * s' + 5) ≤ m' := Nat.div_mul_le_self m' (2 * s' + 5)
  -- `24 L X ≤ m`
  have h1 : 24 * (2 * s + 5) * X ≤ m := by
    have : 24 * (2 * s + 5) * X ≤ (2 * s' + 5) * X := Nat.mul_le_mul_right _ hL
    have h2 : (2 * s' + 5) * X = X * (2 * s' + 5) := Nat.mul_comm _ _
    omega
  -- bound the length
  have hplen : (p.length : ℤ) ≤ 12 * ((X : ℤ) + (2 * s' + 5) + s') + 5 := by exact_mod_cast hp
  have hLnn : (0 : ℤ) ≤ 2 * (2 * s + 5) := by omega
  have h3 : ((p.length : ℤ)) * (2 * (2 * s + 5)) ≤
      (12 * ((X : ℤ) + (2 * s' + 5) + s') + 5) * (2 * (2 * s + 5)) :=
    mul_le_mul_of_nonneg_right hplen hLnn
  have h1' : 24 * (2 * (s : ℤ) + 5) * X ≤ m := by exact_mod_cast h1
  have hlarge' : 24 * (2 * (s : ℤ) + 5) * ((2 * s' + 5) + s') + 14 * (2 * s + 5) ≤ 2 * m := by
    exact_mod_cast hlarge
  have hsnn : (4 : ℤ) ≤ s := by exact_mod_cast hs
  nlinarith [hb, h3, h1', hlarge', hsnn]

end Ful.Helix

end
