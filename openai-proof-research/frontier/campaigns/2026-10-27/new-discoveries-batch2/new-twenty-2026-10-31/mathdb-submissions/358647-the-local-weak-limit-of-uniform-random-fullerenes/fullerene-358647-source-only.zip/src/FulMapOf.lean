/-
FulMapOf: the combinatorial map of a fullerene graph with a rotation system; transport to `Fin m`.
-/
import FulDigon
import FulStatement
import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.style.haveILetI false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt
open scoped Classical

universe u

variable {D : Type*} [Fintype D] [DecidableEq D] {D' : Type*} [Fintype D'] [DecidableEq D']

namespace CMap

/-- Transport of a map along a bijection of darts. -/
def map (M : CMap D) (e : D ≃ D') : CMap D' where
  σ := e.permCongr M.σ
  α := e.permCongr M.α
  α_invol d := by simp [Equiv.permCongr_apply, M.α_invol]
  α_ne d h := by
    have h1 : M.α (e.symm d) = e.symm d := by
      have h2 := congrArg e.symm h
      simpa [Equiv.permCongr_apply] using h2
    exact M.α_ne _ h1

variable {M : CMap D} (e : D ≃ D')

theorem map_σ (d : D) : (M.map e).σ (e d) = e (M.σ d) := by
  simp [map, Equiv.permCongr_apply]

theorem map_α (d : D) : (M.map e).α (e d) = e (M.α d) := by
  simp [map, Equiv.permCongr_apply]

/-- The bijection is a map isomorphism. -/
def mapIso : MapIso M (M.map e) where
  e := e
  σ_comm d := (map_σ e d).symm
  α_comm d := (map_α e d).symm

theorem map_φ (d : D) : (M.map e).φ (e d) = e (M.φ d) := (mapIso e).φ_comm d |>.symm

theorem map_tail_iff {a b : D} : (M.map e).tail (e a) = (M.map e).tail (e b) ↔ M.tail a = M.tail b := by
  have h : ∀ (i : ℤ) (x : D), (((M.map e).σ) ^ i) (e x) = e ((M.σ ^ i) x) := by
    intro i x
    have key : (M.map e).σ = e.permCongr M.σ := rfl
    have h2 : (e.permCongr M.σ) ^ i = e.permCongr (M.σ ^ i) := by
      have := map_zpow e.permCongrHom M.σ i
      simpa [Equiv.permCongrHom_coe] using this.symm
    rw [key, h2, Equiv.permCongr_apply, Equiv.symm_apply_apply]
  constructor
  · intro hab
    obtain ⟨i, hi⟩ := Orb.mk_eq_iff.1 hab
    refine Orb.mk_eq_iff.2 ⟨i, ?_⟩
    apply e.injective
    rw [← h i a, hi]
  · intro hab
    obtain ⟨i, hi⟩ := Orb.mk_eq_iff.1 hab
    refine Orb.mk_eq_iff.2 ⟨i, ?_⟩
    rw [h i a, hi]

theorem map_deg (a : D) : (M.map e).deg ((M.map e).tail (e a)) = M.deg (M.tail a) := by
  unfold deg
  apply Finset.card_bij (fun x _ => e.symm x)
  · intro x hx
    simp only [mem_filter, mem_univ, true_and] at hx ⊢
    have h1 : (M.map e).tail (e (e.symm x)) = (M.map e).tail (e a) := by
      rw [Equiv.apply_symm_apply]; exact hx
    exact (map_tail_iff e).1 h1
  · intro x _ y _ h
    exact e.symm.injective h
  · intro x hx
    simp only [mem_filter, mem_univ, true_and] at hx
    refine ⟨e x, ?_, by simp⟩
    simp only [mem_filter, mem_univ, true_and]
    exact (map_tail_iff e).2 hx

theorem map_faceLen (a : D) :
    (M.map e).faceLen ((M.map e).face (e a)) = M.faceLen (M.face a) := by
  have hface : ∀ {x y : D}, (M.map e).face (e x) = (M.map e).face (e y) ↔ M.face x = M.face y := by
    intro x y
    have h : ∀ (i : ℤ) (z : D), (((M.map e).φ) ^ i) (e z) = e ((M.φ ^ i) z) := by
      intro i z
      have key : (M.map e).φ = e.permCongr M.φ := by
        apply Equiv.ext
        intro w
        obtain ⟨u, rfl⟩ := e.surjective w
        rw [map_φ, Equiv.permCongr_apply, Equiv.symm_apply_apply]
      have h2 : (e.permCongr M.φ) ^ i = e.permCongr (M.φ ^ i) := by
        have := map_zpow e.permCongrHom M.φ i
        simpa [Equiv.permCongrHom_coe] using this.symm
      rw [key, h2, Equiv.permCongr_apply, Equiv.symm_apply_apply]
    constructor
    · intro hab
      obtain ⟨i, hi⟩ := Orb.mk_eq_iff.1 hab
      refine Orb.mk_eq_iff.2 ⟨i, ?_⟩
      apply e.injective
      rw [← h i x, hi]
    · intro hab
      obtain ⟨i, hi⟩ := Orb.mk_eq_iff.1 hab
      refine Orb.mk_eq_iff.2 ⟨i, ?_⟩
      rw [h i x, hi]
  unfold faceLen
  apply Finset.card_bij (fun x _ => e.symm x)
  · intro x hx
    simp only [mem_filter, mem_univ, true_and] at hx ⊢
    have h1 : (M.map e).face (e (e.symm x)) = (M.map e).face (e a) := by
      rw [Equiv.apply_symm_apply]; exact hx
    exact hface.1 h1
  · intro x _ y _ h
    exact e.symm.injective h
  · intro x hx
    simp only [mem_filter, mem_univ, true_and] at hx
    refine ⟨e x, ?_, by simp⟩
    simp only [mem_filter, mem_univ, true_and]
    exact hface.2 hx

theorem Connected.map (h : M.Connected) : (M.map e).Connected := by
  obtain ⟨⟨d0⟩, hd⟩ := h
  refine ⟨⟨e d0⟩, fun x y => ?_⟩
  obtain ⟨g, hg, hgxy⟩ := hd (e.symm x) (e.symm y)
  have hmem : ∀ g ∈ Subgroup.closure ({M.σ, M.α} : Set (Perm D)),
      e.permCongr g ∈ Subgroup.closure ({(M.map e).σ, (M.map e).α} : Set (Perm D')) := by
    intro g hg
    induction hg using Subgroup.closure_induction with
    | mem z hz =>
      apply Subgroup.subset_closure
      rcases hz with rfl | hz
      · exact Or.inl rfl
      · rw [Set.mem_singleton_iff.1 hz]
        exact Or.inr rfl
    | one =>
      have : e.permCongr (1 : Perm D) = 1 := by
        ext x; simp [Equiv.permCongr_apply]
      rw [this]
      exact Subgroup.one_mem _
    | mul a b _ _ ha hb =>
      have : e.permCongr (a * b) = e.permCongr a * e.permCongr b := map_mul e.permCongrHom a b
      rw [this]
      exact Subgroup.mul_mem _ ha hb
    | inv a _ ha =>
      have : e.permCongr a⁻¹ = (e.permCongr a)⁻¹ := map_inv e.permCongrHom a
      rw [this]
      exact Subgroup.inv_mem _ ha
  refine ⟨e.permCongr g, hmem g hg, ?_⟩
  rw [Equiv.permCongr_apply, hgxy, Equiv.apply_symm_apply]

/-- `IsFullerene` is invariant under transport. -/
theorem IsFullerene.map (h : M.IsFullerene) : (M.map e).IsFullerene := by
  refine ⟨h.connected.map e, (mapIso e).genus0_iff.1 h.genus, ⟨?_, ?_⟩, ?_, ?_⟩
  · intro d hd
    obtain ⟨a, rfl⟩ := e.surjective d
    rw [map_α] at hd
    exact h.simple.1 a ((map_tail_iff e).1 hd)
  · intro d d' h1 h2
    obtain ⟨a, rfl⟩ := e.surjective d
    obtain ⟨b, rfl⟩ := e.surjective d'
    rw [map_α, map_α] at h2
    rw [h.simple.2 a b ((map_tail_iff e).1 h1) ((map_tail_iff e).1 h2)]
  · intro v
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ v
    obtain ⟨a, rfl⟩ := e.surjective d
    show (M.map e).deg ((M.map e).tail (e a)) = 3
    rw [map_deg]
    exact h.cubic _
  · intro f
    obtain ⟨d, rfl⟩ := Orb.mk_surjective _ f
    obtain ⟨a, rfl⟩ := e.surjective d
    show (M.map e).faceLen ((M.map e).face (e a)) = 5 ∨ (M.map e).faceLen ((M.map e).face (e a)) = 6
    rw [map_faceLen]
    exact h.faces _

end CMap

end Ful

end
