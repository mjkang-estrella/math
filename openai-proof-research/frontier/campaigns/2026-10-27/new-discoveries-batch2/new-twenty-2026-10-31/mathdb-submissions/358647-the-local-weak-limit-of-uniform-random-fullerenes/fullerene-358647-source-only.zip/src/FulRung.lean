/-
FulRung: the ring walk.  A clean ring is a cyclic strip of triangles, parametrized by its rungs
and a move word.  `true` is a move `A` (the triangle has its base on the inner cycle), `false` is
a move `U` (the triangle has its top on the outer cycle).
-/
import FulBlock

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable (M : CMap D)

/-- One step of the ring walk. -/
def mv (b : Bool) (r : D) : D := if b then M.φ (M.σ r) else M.σ r

/-- The rungs of the ring walk. -/
def rung (W : ℕ → Bool) (r0 : D) : ℕ → D
  | 0 => r0
  | n + 1 => M.mv (W n) (rung W r0 n)

/-- The three corners of the triangle at a rung. -/
def cor0 (r : D) : D := M.σ r
def cor1 (r : D) : D := M.φ (M.σ r)
def cor2 (r : D) : D := M.α r

variable {M}

@[simp] theorem rung_zero (W : ℕ → Bool) (r0 : D) : M.rung W r0 0 = r0 := rfl

theorem rung_succ (W : ℕ → Bool) (r0 : D) (n : ℕ) :
    M.rung W r0 (n + 1) = M.mv (W n) (M.rung W r0 n) := rfl

theorem rung_succ_true {W : ℕ → Bool} {r0 : D} {n : ℕ} (h : W n = true) :
    M.rung W r0 (n + 1) = M.cor1 (M.rung W r0 n) := by
  simp [rung_succ, mv, h, cor1]

theorem rung_succ_false {W : ℕ → Bool} {r0 : D} {n : ℕ} (h : W n = false) :
    M.rung W r0 (n + 1) = M.cor0 (M.rung W r0 n) := by
  simp [rung_succ, mv, h, cor0]

theorem φ_cor0 (r : D) : M.φ (M.cor0 r) = M.cor1 r := rfl

theorem φ_cor2 (r : D) : M.φ (M.cor2 r) = M.cor0 r := by
  simp [cor2, cor0, φ_apply]

theorem φ_cor1 (hT : M.IsTriangulation) (r : D) : M.φ (M.cor1 r) = M.cor2 r := by
  have h := (hT (M.α r)).1
  rw [show M.φ (M.α r) = M.σ r by simp [φ_apply]] at h
  simpa [cor1, cor2] using h

theorem σ_α_cor1 (hT : M.IsTriangulation) (r : D) : M.σ (M.α (M.cor1 r)) = M.cor2 r := by
  have h := M.φ_cor1 hT r
  simpa [φ_apply] using h

theorem face_cor1 (r : D) : M.face (M.cor1 r) = M.face (M.cor0 r) := by
  exact M.face_φ _

theorem face_cor2 (r : D) : M.face (M.cor2 r) = M.face (M.cor0 r) := by
  rw [← M.face_φ (M.cor2 r), φ_cor2]

theorem cor2_ne_cor0 (hT : M.IsTriangulation) (r : D) : M.cor2 r ≠ M.cor0 r := by
  intro h
  have h1 := M.φ_cor2 r
  rw [h] at h1
  exact hT.ne1 _ h1

theorem cor1_ne_cor0 (hT : M.IsTriangulation) (r : D) : M.cor1 r ≠ M.cor0 r :=
  hT.ne1 _

theorem cor2_ne_cor1 (hT : M.IsTriangulation) (r : D) : M.cor2 r ≠ M.cor1 r := by
  intro h
  have h1 := M.φ_cor1 hT r
  rw [h] at h1
  exact hT.ne1 _ h1

/-- The face of the triangle at a rung. -/
def tri (r : D) : M.F := M.face (M.cor0 r)

theorem eq_cor_of_face (hT : M.IsTriangulation) {r x : D} (h : M.face x = M.tri r) :
    x = M.cor0 r ∨ x = M.cor1 r ∨ x = M.cor2 r := by
  rw [tri, hT.face_eq_iff] at h
  rcases h with h | h | h
  · exact Or.inl h
  · exact Or.inr (Or.inl h)
  · refine Or.inr (Or.inr ?_)
    rw [h]
    exact M.φ_cor1 hT r

/-! ### α on rungs -/

theorem α_cor2 (r : D) : M.α (M.cor2 r) = r := by simp [cor2]

theorem α_cor1_of_true {W : ℕ → Bool} {r0 : D} {n : ℕ} (h : W n = true) :
    M.α (M.cor1 (M.rung W r0 n)) = M.cor2 (M.rung W r0 (n + 1)) := by
  rw [rung_succ_true h, cor2]

theorem α_cor0_of_false {W : ℕ → Bool} {r0 : D} {n : ℕ} (h : W n = false) :
    M.α (M.cor0 (M.rung W r0 n)) = M.cor2 (M.rung W r0 (n + 1)) := by
  rw [rung_succ_false h, cor2]

/-! ### σ along the rungs -/

/-- After an `A` move, turning at the common top vertex recovers the previous rung. -/
theorem σ_α_rung_true (hT : M.IsTriangulation) {W : ℕ → Bool} {r0 : D} {n : ℕ}
    (h : W n = true) : M.σ (M.α (M.rung W r0 (n + 1))) = M.α (M.rung W r0 n) := by
  rw [rung_succ_true h]
  exact M.σ_α_cor1 hT _

/-- After a `U` move, turning at the new top vertex gives the top dart of the triangle. -/
theorem σ_α_rung_false {W : ℕ → Bool} {r0 : D} {n : ℕ} (h : W n = false) :
    M.σ (M.α (M.rung W r0 (n + 1))) = M.cor1 (M.rung W r0 n) := by
  rw [rung_succ_false h]
  rfl

theorem tail_α_rung_true (hT : M.IsTriangulation) {W : ℕ → Bool} {r0 : D} {n : ℕ}
    (h : W n = true) : M.tail (M.α (M.rung W r0 (n + 1))) = M.tail (M.α (M.rung W r0 n)) := by
  rw [← M.σ_α_rung_true hT h, M.tail_σ]

/-- The reversed rung iterated across a run of `A` moves. -/
theorem σ_pow_α_rung (hT : M.IsTriangulation) {W : ℕ → Bool} {r0 : D} (p : ℕ) :
    ∀ a, (∀ m, p < m → m < p + 1 + a → W m = true) →
      (M.σ ^ a) (M.α (M.rung W r0 (p + 1 + a))) = M.α (M.rung W r0 (p + 1)) := by
  intro a
  induction a with
  | zero => intro _; simp
  | succ a ih =>
    intro h
    have h1 := ih (fun m hm hm2 => h m hm (by omega))
    have h2 := h (p + 1 + a) (by omega) (by omega)
    have h3 : M.σ (M.α (M.rung W r0 (p + 1 + (a + 1)))) = M.α (M.rung W r0 (p + 1 + a)) := by
      have := M.σ_α_rung_true hT (r0 := r0) h2
      simpa [Nat.add_assoc] using this
    rw [pow_succ, Perm.mul_apply, h3, h1]

/-- **The vertex chain.** Consecutive `U` moves at `p < q` with only `A` moves between them. -/
theorem σ_pow_top (hT : M.IsTriangulation) {W : ℕ → Bool} {r0 : D} {p a : ℕ}
    (hp : W p = false)
    (hmid : ∀ m, p < m → m < p + 1 + a → W m = true) :
    (M.σ ^ (a + 2)) (M.α (M.cor1 (M.rung W r0 (p + 1 + a)))) = M.cor1 (M.rung W r0 p) := by
  have h1 : M.σ (M.α (M.cor1 (M.rung W r0 (p + 1 + a)))) = M.α (M.rung W r0 (p + 1 + a)) :=
    M.σ_α_cor1 hT _
  have h2 := M.σ_pow_α_rung hT (r0 := r0) p a hmid
  have h3 : M.σ (M.α (M.rung W r0 (p + 1))) = M.cor1 (M.rung W r0 p) :=
    M.σ_α_rung_false (r0 := r0) hp
  rw [show a + 2 = (a + 1) + 1 from rfl, pow_succ', pow_succ, Perm.mul_apply, Perm.mul_apply, h1, h2,
    h3]

end CMap

end Ful

end
