/-
FulFan: the fan of a simple cycle at a vertex: the first-return exponent `K`, the next dart of the
cycle as a power of `σ`, coherence of the side, and the corner count.
-/
import FulRung

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

/-- Reduction of an exponent modulo a period. -/
theorem pow_mod_apply {p : Perm D} {x : D} {K : ℕ} (hK : (p ^ K) x = x) (n : ℕ) :
    (p ^ (n % K)) x = (p ^ n) x := by
  have key : ∀ q, (p ^ (K * q)) x = x := by
    intro q
    induction q with
    | zero => simp
    | succ q ih => rw [Nat.mul_succ, pow_add, Perm.mul_apply, hK, ih]
  conv_rhs => rw [← Nat.mod_add_div n K, pow_add, Perm.mul_apply, key]

namespace CMap

variable {M : CMap D}

theorem tail_pow (t : ℕ) (x : D) : M.tail ((M.σ ^ t) x) = M.tail x := by
  induction t with
  | zero => simp
  | succ t ih => rw [pow_succ', Perm.mul_apply, M.tail_σ, ih]

namespace SimpleCycle

variable (C : SimpleCycle M)

theorem exists_ret (j : ℕ) : ∃ t, 0 < t ∧ M.edge ((M.σ ^ t) (M.α (C.dart j))) ∈ C.edges := by
  refine ⟨orderOf M.σ, orderOf_pos _, ?_⟩
  rw [pow_orderOf_eq_one, Perm.one_apply, M.edge_α]
  exact C.edge_mem j

/-- First return of the rotation at the head of a cycle dart to the cycle: the number of corners
on the `Q` side at that vertex. -/
def K (j : ℕ) : ℕ := Nat.find (C.exists_ret j)

theorem K_pos (j : ℕ) : 0 < C.K j := (Nat.find_spec (C.exists_ret j)).1

theorem K_edge (j : ℕ) : M.edge ((M.σ ^ C.K j) (M.α (C.dart j))) ∈ C.edges :=
  (Nat.find_spec (C.exists_ret j)).2

theorem K_min {j t : ℕ} (h0 : 0 < t) (ht : t < C.K j) :
    M.edge ((M.σ ^ t) (M.α (C.dart j))) ∉ C.edges :=
  fun h => Nat.find_min (C.exists_ret j) ht ⟨h0, h⟩

theorem K_add_len (j : ℕ) : C.K (j + C.len) = C.K j := by
  have hp : ∀ t, M.edge ((M.σ ^ t) (M.α (C.dart (j + C.len)))) =
      M.edge ((M.σ ^ t) (M.α (C.dart j))) := fun t => by rw [C.periodic]
  unfold K
  apply le_antisymm
  · exact Nat.find_min' _ ⟨(Nat.find_spec (C.exists_ret j)).1, by
      rw [hp]; exact (Nat.find_spec (C.exists_ret j)).2⟩
  · exact Nat.find_min' _ ⟨(Nat.find_spec (C.exists_ret (j + C.len))).1, by
      rw [← hp]; exact (Nat.find_spec (C.exists_ret (j + C.len))).2⟩

/-- The darts on the cycle at a cycle vertex are the two expected ones. -/
theorem dart_cases {x : D} {j : ℕ} (ht : M.tail x = M.tail (C.dart (j + 1)))
    (he : M.edge x ∈ C.edges) : x = C.dart (j + 1) ∨ x = M.α (C.dart j) := by
  obtain ⟨i, hi⟩ := C.exists_of_edge_mem he
  rcases M.edge_eq_iff.1 hi with rfl | rfl
  · left
    rw [← C.dart_mod i, ← C.dart_mod (j + 1), C.tail_eq_mod ht]
  · right
    rw [C.chain] at ht
    have h1 := C.tail_eq_mod ht
    have h2 : i ≡ j [MOD C.len] := Nat.ModEq.add_right_cancel' 1 h1
    rw [← C.dart_mod i, ← C.dart_mod j, show i % C.len = j % C.len from h2]

theorem next_ne (hlen : 2 ≤ C.len) (j : ℕ) : C.dart (j + 1) ≠ M.α (C.dart j) := by
  intro h
  have he : M.edge (C.dart j) = M.edge (C.dart (j + 1)) := by rw [h, M.edge_α]
  have h1 : j ≡ j + 1 [MOD C.len] := C.edge_eq_mod he
  have h2 := (Nat.modEq_iff_dvd' (Nat.le_succ j)).1 h1
  rw [show j + 1 - j = 1 by omega] at h2
  exact absurd (Nat.le_of_dvd one_pos h2) (by omega)

/-- The next dart of the cycle is a power of the rotation applied to the reversed dart. -/
theorem next_eq (hlen : 2 ≤ C.len) (j : ℕ) :
    (M.σ ^ C.K j) (M.α (C.dart j)) = C.dart (j + 1) := by
  have ht0 : M.tail (M.α (C.dart j)) = M.tail (C.dart (j + 1)) := C.chain j
  rcases C.dart_cases (j := j) (by rw [tail_pow, ht0]) (C.K_edge j) with h | h
  · exact h
  · exfalso
    have hsc : SameCycle M.σ (M.α (C.dart j)) (C.dart (j + 1)) := Orb.mk_eq_iff.1 ht0
    obtain ⟨n, -, hn⟩ := hsc.exists_pow_eq'
    have hmod := pow_mod_apply h n
    rw [hn] at hmod
    have hlt : n % C.K j < C.K j := Nat.mod_lt _ (C.K_pos j)
    by_cases h0 : n % C.K j = 0
    · rw [h0, pow_zero, Perm.one_apply] at hmod
      exact C.next_ne hlen j hmod.symm
    · have h1 := C.K_min (j := j) (Nat.pos_of_ne_zero h0) hlt
      apply h1
      rw [hmod]
      exact C.edge_mem _

variable {C} {Q : Finset M.F}

theorem fan_side (h : IsSide C Q) {j : ℕ} (hj : M.face (C.dart j) ∈ Q) :
    ∀ t, 0 < t → t ≤ C.K j → M.face ((M.σ ^ t) (M.α (C.dart j))) ∈ Q := by
  intro t
  induction t with
  | zero => intro h0; omega
  | succ t ih =>
    intro _ hle
    by_cases ht : t = 0
    · subst ht
      simp only [zero_add, pow_one]
      rw [← M.face_α (M.α (C.dart j)), M.α_α]
      exact hj
    · have h0 : 0 < t := Nat.pos_of_ne_zero ht
      have hmem := ih h0 (by omega)
      have hne := C.K_min (j := j) h0 (by omega)
      have hiff : M.face ((M.σ ^ t) (M.α (C.dart j))) ∈ Q ↔
          M.face (M.α ((M.σ ^ t) (M.α (C.dart j)))) ∈ Q :=
        not_not.1 fun hn => hne ((h _).2 hn)
      rw [pow_succ', Perm.mul_apply, ← M.face_α]
      exact hiff.1 hmem

theorem orient_succ (hlen : 2 ≤ C.len) (h : IsSide C Q) {j : ℕ} (hj : M.face (C.dart j) ∈ Q) :
    M.face (C.dart (j + 1)) ∈ Q := by
  have := fan_side h hj (C.K j) (C.K_pos j) le_rfl
  rwa [C.next_eq hlen] at this

/-- Coherence: a side contains the left faces of all the darts of the cycle, or of none. -/
theorem orient (hlen : 2 ≤ C.len) (h : IsSide C Q) (h0 : M.face (C.dart 0) ∈ Q) (j : ℕ) :
    M.face (C.dart j) ∈ Q := by
  induction j with
  | zero => exact h0
  | succ j ih => exact orient_succ hlen h ih

/-- Every corner of `Q` at a cycle vertex is in the fan. -/
theorem corner_cases (hlen : 2 ≤ C.len) (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q) (j : ℕ)
    {x : D} (ht : M.tail x = M.tail (C.dart (j + 1))) (hx : M.face x ∈ Q) :
    ∃ t, 0 < t ∧ t ≤ C.K j ∧ x = (M.σ ^ t) (M.α (C.dart j)) := by
  have hsc : SameCycle M.σ (M.α (C.dart j)) x := Orb.mk_eq_iff.1 ((C.chain j).trans ht.symm)
  obtain ⟨n0, -, hn0⟩ := hsc.exists_pow_eq'
  have hex : ∃ n, 0 < n ∧ (M.σ ^ n) (M.α (C.dart j)) = x := by
    refine ⟨n0 + orderOf M.σ, by have := orderOf_pos M.σ; omega, ?_⟩
    rw [pow_add, pow_orderOf_eq_one, mul_one]
    exact hn0
  set n := Nat.find hex with hn
  have hn1 : 0 < n := (Nat.find_spec hex).1
  have hn2 : (M.σ ^ n) (M.α (C.dart j)) = x := (Nat.find_spec hex).2
  have hmin : ∀ m, 0 < m → m < n → (M.σ ^ m) (M.α (C.dart j)) ≠ x := fun m h0 hm h1 =>
    Nat.find_min hex hm ⟨h0, h1⟩
  by_cases hle : n ≤ C.K j
  · exact ⟨n, hn1, hle, hn2.symm⟩
  · exfalso
    have hrem : ∀ s, C.K j < s → s ≤ n → M.face ((M.σ ^ s) (M.α (C.dart j))) ∉ Q := by
      intro s
      induction s with
      | zero => intro h0; omega
      | succ s ih =>
        intro hs1 hs2
        by_cases hsK : s = C.K j
        · subst hsK
          rw [pow_succ', Perm.mul_apply, C.next_eq hlen, ← M.face_α]
          have h1 := hor (j + 1)
          intro h2
          have h3 := (h (C.dart (j + 1))).1 (C.edge_mem _)
          exact h3 (iff_of_true h1 h2)
        · have hs3 : C.K j < s := by omega
          have hs4 := ih hs3 (by omega)
          have hsn : s < n := by omega
          have hed : M.edge ((M.σ ^ s) (M.α (C.dart j))) ∉ C.edges := by
            intro hed
            rcases C.dart_cases (j := j) (by rw [tail_pow]; exact C.chain j) hed with h1 | h1
            · apply hmin (n - s + C.K j) (by have := C.K_pos j; omega) (by omega)
              have h2 : M.σ ^ (n - s + C.K j) = M.σ ^ (n - s) * M.σ ^ C.K j := pow_add _ _ _
              rw [h2, Perm.mul_apply, C.next_eq hlen, ← h1, ← Perm.mul_apply, ← pow_add,
                show n - s + s = n by omega]
              exact hn2
            · apply hmin (n - s) (by omega) (by omega)
              have h3 : (M.σ ^ (n - s)) ((M.σ ^ s) (M.α (C.dart j))) = x := by
                rw [← Perm.mul_apply, ← pow_add, show n - s + s = n by omega]
                exact hn2
              rwa [h1] at h3
          have hiff : M.face ((M.σ ^ s) (M.α (C.dart j))) ∈ Q ↔
              M.face (M.α ((M.σ ^ s) (M.α (C.dart j)))) ∈ Q :=
            not_not.1 fun hn => hed ((h _).2 hn)
          rw [pow_succ', Perm.mul_apply, ← M.face_α]
          exact fun hm => hs4 (hiff.2 hm)
    have h1 := hrem n (by omega) le_rfl
    rw [hn2] at h1
    exact h1 hx

/-- The fan darts in a first-return window are distinct. -/
theorem fan_inj (hlen : 2 ≤ C.len) {j a b : ℕ} (ha : 0 < a) (hab : a < b) (hb : b ≤ C.K j) :
    (M.σ ^ a) (M.α (C.dart j)) ≠ (M.σ ^ b) (M.α (C.dart j)) := by
  intro he
  have h1 : (M.σ ^ (a + (C.K j - b))) (M.α (C.dart j)) = C.dart (j + 1) := by
    rw [add_comm, pow_add, Perm.mul_apply, he, ← Perm.mul_apply, ← pow_add,
      show C.K j - b + b = C.K j by omega]
    exact C.next_eq hlen j
  have h2 := C.K_min (j := j) (t := a + (C.K j - b)) (by omega) (by omega)
  apply h2
  rw [h1]
  exact C.edge_mem _

/-- The corners of a side at a cycle vertex are counted by the first-return exponent. -/
theorem cornerAt_eq (hlen : 2 ≤ C.len) (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q) (j : ℕ) :
    cornerAt Q (M.tail (C.dart (j + 1))) = C.K j := by
  unfold cornerAt
  have hset : univ.filter (fun d => M.tail d = M.tail (C.dart (j + 1)) ∧ M.face d ∈ Q) =
      (Finset.Icc 1 (C.K j)).image (fun t => (M.σ ^ t) (M.α (C.dart j))) := by
    ext x
    simp only [mem_filter, mem_univ, true_and, mem_image, Finset.mem_Icc]
    constructor
    · rintro ⟨h1, h2⟩
      obtain ⟨t, h3, h4, rfl⟩ := corner_cases hlen h hor j h1 h2
      exact ⟨t, ⟨h3, h4⟩, rfl⟩
    · rintro ⟨t, ⟨h3, h4⟩, rfl⟩
      exact ⟨by rw [tail_pow]; exact C.chain j, fan_side h (hor j) t h3 h4⟩
  rw [hset, Finset.card_image_of_injOn, Nat.card_Icc]
  · omega
  · intro a ha b hb hab
    simp only [Finset.coe_Icc, Set.mem_Icc] at ha hb
    rcases lt_trichotomy a b with hlt | heq | hlt
    · exact absurd hab (fan_inj hlen (by omega) hlt hb.2)
    · exact heq
    · exact absurd hab.symm (fan_inj hlen (by omega) hlt ha.2)

/-- Summing the first-return exponents along the cycle counts the corners of the side. -/
theorem sum_K (hlen : 2 ≤ C.len) (h : IsSide C Q) (hor : ∀ j, M.face (C.dart j) ∈ Q) :
    ∑ j ∈ range C.len, C.K j = ∑ v ∈ C.verts, cornerAt Q v := by
  have hinj : Set.InjOn (fun i => M.tail (C.dart i)) (range C.len : Finset ℕ) := by
    intro a ha b hb hab
    exact C.tail_inj a b (mem_range.1 (by simpa using ha)) (mem_range.1 (by simpa using hb)) hab
  rw [verts, Finset.sum_image hinj]
  have hk : ∑ j ∈ range C.len, cornerAt Q (M.tail (C.dart (j + 1))) =
      ∑ j ∈ range C.len, cornerAt Q (M.tail (C.dart j)) := by
    have a := Finset.sum_range_succ (fun i => cornerAt Q (M.tail (C.dart i))) C.len
    have b := Finset.sum_range_succ' (fun i => cornerAt Q (M.tail (C.dart i))) C.len
    rw [show C.dart C.len = C.dart 0 from C.dart_len] at a
    omega
  rw [← hk]
  exact Finset.sum_congr rfl fun j _ => (cornerAt_eq hlen h hor j).symm

end SimpleCycle

end CMap

end Ful

end
