import FulEndpoint

#print axioms Ful.endpoint
#print axioms Ful.localWeakConvergence
#print axioms Ful.Helix.nonVacuous
#print axioms Ful.Helix.numFullerenes_ge
#print axioms Ful.bad_bound
#print axioms Ful.exc_card_le
#print axioms Ful.transfer_ball
#print axioms Ful.ball_of_flat
#print axioms Ful.graphIso_of_mapIso
#print axioms Ful.mapOf_isFullerene
