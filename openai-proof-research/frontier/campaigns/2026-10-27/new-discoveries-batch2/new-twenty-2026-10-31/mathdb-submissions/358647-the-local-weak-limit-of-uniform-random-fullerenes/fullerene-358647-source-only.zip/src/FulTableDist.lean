/-
FulTableDist: distances in the fullerene graph of a rotation table: a Lipschitz height on triangles
(lower bound on walks) and walks along the table (upper bound).
-/
import FulGraphOf
import FulTable

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.style.haveILetI false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset
open scoped Classical

namespace Table

universe u

variable {n : ℕ} {A : Table n} {V : Type u} [Fintype V]
variable (h : A.T.dual.IsFullerene) (e : A.T.dual.V ≃ V)

/-- The fullerene graph of a table. -/
abbrev Gr : SimpleGraph V := graphOf A.T.dual e h.simple.1

/-- The fullerene vertex of a dart. -/
def Fv (d : A.Dart) : V := e (A.T.dual.tail d)

theorem Fv_adj (d : A.Dart) : (Gr h e).Adj (Fv e d) (Fv e (A.T.α d)) := ⟨d, rfl, rfl⟩

theorem Fv_σ (d : A.Dart) : Fv e (A.T.σ d) = Fv e (A.T.α d) := by
  show e (A.T.face (A.T.σ d)) = e (A.T.face (A.T.α d))
  rw [A.T.face_α]

theorem Fv_surj (v : V) : ∃ d, Fv e d = v := by
  obtain ⟨d, hd⟩ := Orb.mk_surjective A.T.dual.σ (e.symm v)
  exact ⟨d, by show e (Orb.mk A.T.dual.σ d) = v; rw [hd, Equiv.apply_symm_apply]⟩

/-- `Rw x y k`: a walk of length at most `k` in the fullerene graph. -/
def Rw (x y : V) (k : ℕ) : Prop := ∃ p : (Gr h e).Walk x y, p.length ≤ k

theorem Rw.refl (x : V) : Rw h e x x 0 := ⟨SimpleGraph.Walk.nil, by simp⟩

theorem Rw.trans {x y z : V} {a b : ℕ} (h1 : Rw h e x y a) (h2 : Rw h e y z b) :
    Rw h e x z (a + b) := by
  obtain ⟨p, hp⟩ := h1
  obtain ⟨q, hq⟩ := h2
  exact ⟨p.append q, by rw [SimpleGraph.Walk.length_append]; omega⟩

theorem Rw.mono {x y : V} {a b : ℕ} (hab : a ≤ b) (h1 : Rw h e x y a) : Rw h e x y b := by
  obtain ⟨p, hp⟩ := h1
  exact ⟨p, hp.trans hab⟩

theorem Rw.step (d : A.Dart) : Rw h e (Fv e d) (Fv e (A.T.α d)) 1 :=
  ⟨SimpleGraph.Walk.cons (Fv_adj h e d) SimpleGraph.Walk.nil, by simp⟩

theorem Rw.rot (d : A.Dart) (a : ℕ) : Rw h e (Fv e d) (Fv e ((A.T.σ ^ a) d)) a := by
  induction a with
  | zero => simpa using Rw.refl h e (Fv e d)
  | succ a ih =>
    have h1 := Rw.step h e ((A.T.σ ^ a) d)
    rw [← Fv_σ] at h1
    have h2 := ih.trans h e h1
    rwa [← Perm.mul_apply, ← pow_succ'] at h2

/-- Rotation around a vertex costs at most `deg - 1 ≤ 5` steps. -/
theorem Rw.around (hd6 : ∀ u, A.deg u ≤ 6) (p q : A.Dart) (hpq : p.1.1 = q.1.1) :
    Rw h e (Fv e p) (Fv e q) 5 := by
  have hdp := p.2
  have hdq := q.2
  rw [hpq] at hdp
  by_cases hle : p.1.2 ≤ q.1.2
  · have ha : q.1.2 - p.1.2 ≤ 5 := by have := hd6 q.1.1; omega
    have hq : (A.T.σ ^ (q.1.2 - p.1.2)) p = q := by
      apply Subtype.ext
      rw [A.σ_pow]
      apply Prod.ext
      · exact hpq
      · show (p.1.2 + (q.1.2 - p.1.2)) % A.deg p.1.1 = q.1.2
        rw [show p.1.2 + (q.1.2 - p.1.2) = q.1.2 by omega, hpq, Nat.mod_eq_of_lt q.2]
    have := Rw.rot h e p (q.1.2 - p.1.2)
    rw [hq] at this
    exact this.mono h e ha
  · have ha : A.deg p.1.1 - (p.1.2 - q.1.2) ≤ 5 := by
      have := hd6 p.1.1
      omega
    have hq : (A.T.σ ^ (A.deg p.1.1 - (p.1.2 - q.1.2))) p = q := by
      apply Subtype.ext
      rw [A.σ_pow]
      apply Prod.ext
      · exact hpq
      · show (p.1.2 + (A.deg p.1.1 - (p.1.2 - q.1.2))) % A.deg p.1.1 = q.1.2
        have hdp' := p.2
        have e1 : p.1.2 + (A.deg p.1.1 - (p.1.2 - q.1.2)) = q.1.2 + A.deg p.1.1 := by omega
        rw [e1, Nat.add_mod_right, Nat.mod_eq_of_lt (by rw [hpq]; exact hdq)]
    have := Rw.rot h e p (A.deg p.1.1 - (p.1.2 - q.1.2))
    rw [hq] at this
    exact this.mono h e ha

/-- From a dart at `u` to a dart at the neighbour `nb u k`: at most six steps. -/
theorem Rw.nb (hd6 : ∀ u, A.deg u ≤ 6) (p : A.Dart) (k : ℕ) (hk : k < A.deg p.1.1) :
    ∃ q : A.Dart, q.1.1 = A.nb p.1.1 k ∧ Rw h e (Fv e p) (Fv e q) 6 := by
  let x : A.Dart := ⟨(p.1.1, k), hk⟩
  refine ⟨A.T.α x, rfl, ?_⟩
  have h1 := Rw.around h e hd6 p x rfl
  exact h1.trans h e (Rw.step h e x)

/-- Descending along a table to a base vertex. -/
theorem Rw.descend (hd6 : ∀ u, A.deg u ≤ 6) (B : Fin n → ℕ) (c : Fin n)
    (hc : ∀ u, B u = 0 → u = c)
    (hstep : ∀ u, B u ≠ 0 → ∃ k, k < A.deg u ∧ B (A.nb u k) + 1 ≤ B u) :
    ∀ (N : ℕ) (p : A.Dart), B p.1.1 ≤ N → ∃ q : A.Dart, q.1.1 = c ∧ Rw h e (Fv e p) (Fv e q) (6 * N) := by
  intro N
  induction N with
  | zero =>
    intro p hp
    exact ⟨p, hc _ (by omega), by simpa using Rw.refl h e (Fv e p)⟩
  | succ N ih =>
    intro p hp
    by_cases h0 : B p.1.1 = 0
    · exact ⟨p, hc _ h0, by
        have := Rw.refl h e (Fv e p)
        exact this.mono h e (by omega)⟩
    · obtain ⟨k, hk, hlt⟩ := hstep _ h0
      obtain ⟨q1, hq1, hr1⟩ := Rw.nb h e hd6 p k hk
      obtain ⟨q, hq, hr⟩ := ih q1 (by rw [hq1]; omega)
      exact ⟨q, hq, by
        have := hr1.trans h e hr
        exact this.mono h e (by omega)⟩

/-- Any two fullerene vertices are within `12 N + 5` steps. -/
theorem diam_le (hd6 : ∀ u, A.deg u ≤ 6) (B : Fin n → ℕ) (c : Fin n) (N : ℕ)
    (hc : ∀ u, B u = 0 → u = c)
    (hstep : ∀ u, B u ≠ 0 → ∃ k, k < A.deg u ∧ B (A.nb u k) + 1 ≤ B u)
    (hN : ∀ u, B u ≤ N) (x y : V) : Rw h e x y (12 * N + 5) := by
  obtain ⟨p, rfl⟩ := Fv_surj (e := e) x
  obtain ⟨q, rfl⟩ := Fv_surj (e := e) y
  obtain ⟨p1, hp1, h1⟩ := Rw.descend h e hd6 B c hc hstep N p (hN _)
  obtain ⟨q1, hq1, h2⟩ := Rw.descend h e hd6 B c hc hstep N q (hN _)
  have h3 := Rw.around h e hd6 p1 q1 (by rw [hp1, hq1])
  have h4 : Rw h e (Fv e q1) (Fv e q) (6 * N) := by
    obtain ⟨w, hw⟩ := h2
    exact ⟨w.reverse, by rw [SimpleGraph.Walk.length_reverse]; exact hw⟩
  have := (h1.trans h e h3).trans h e h4
  exact this.mono h e (by omega)

/-! ### Height -/

variable (lam : Fin n → ℤ) (Lam : ℤ)
  (hLam : ∀ u k, k < A.deg u → |lam (A.nb u k) - lam u| ≤ Lam)

/-- The sum of the labels of the three corners of the triangle of a dart. -/
def corners (d : A.Dart) : ℤ := lam d.1.1 + lam (A.T.φ d).1.1 + lam (A.T.φ (A.T.φ d)).1.1

theorem corners_φ (d : A.Dart) : corners lam (A.T.φ d) = corners lam d := by
  unfold corners
  have := (A.isTriangulation d).1
  rw [this]
  ring

/-- Height of a fullerene vertex. -/
def height (v : V) : ℤ :=
  Orb.lift (corners lam) (corners_φ lam) (e.symm v)

theorem height_Fv (d : A.Dart) : height e lam (Fv e d) = corners lam d := by
  show Orb.lift (corners lam) (corners_φ lam) (e.symm (e (A.T.dual.tail d))) = _
  rw [Equiv.symm_apply_apply]
  rfl

include hLam

/-- `|l(d) - l(αd)| ≤ Λ`. -/
theorem lam_α (d : A.Dart) : |lam (A.T.α d).1.1 - lam d.1.1| ≤ Lam :=
  hLam _ _ d.2

/-- A corner of the triangle of `d` is within `Λ` of the tail of `d`. -/
theorem lam_corner (d : A.Dart) :
    |lam (A.T.φ d).1.1 - lam d.1.1| ≤ Lam ∧ |lam (A.T.φ (A.T.φ d)).1.1 - lam d.1.1| ≤ Lam := by
  have h1 : (A.T.φ d).1.1 = (A.T.α d).1.1 := rfl
  have h2 : |lam (A.T.φ d).1.1 - lam d.1.1| ≤ Lam := by
    rw [h1]
    exact lam_α lam Lam hLam d
  refine ⟨h2, ?_⟩
  have h3 := lam_α lam Lam hLam (A.T.φ (A.T.φ d))
  have h4 : (A.T.α (A.T.φ (A.T.φ d))).1.1 = (A.T.φ (A.T.φ (A.T.φ d))).1.1 := rfl
  rw [h4, (A.isTriangulation d).1] at h3
  rw [abs_sub_comm]
  exact h3

/-- Lipschitz bound along an edge of the fullerene graph. -/
theorem height_adj {v w : V} (hadj : (Gr h e).Adj v w) :
    |height e lam w - height e lam v| ≤ 2 * Lam := by
  obtain ⟨d, rfl, rfl⟩ := hadj
  show |height e lam (Fv e (A.T.α d)) - height e lam (Fv e d)| ≤ _
  rw [height_Fv, height_Fv]
  have ha : (A.T.φ (A.T.α d)).1.1 = d.1.1 := by
    show (A.T.σ (A.T.α (A.T.α d))).1.1 = _
    rw [A.T.α_α]
    rfl
  have h1 := lam_corner lam Lam hLam d
  have h2 := lam_corner lam Lam hLam (A.T.α d)
  have h3 : (A.T.φ d).1.1 = (A.T.α d).1.1 := rfl
  have h4 := lam_corner lam Lam hLam (A.T.φ (A.T.α d))
  unfold corners
  rw [ha, h3]
  rw [ha] at h2 h4
  rw [h3] at h1
  simp only [abs_le] at h1 h2 h4 ⊢
  constructor <;> linarith [h1.1.1, h1.1.2, h1.2.1, h1.2.2, h2.1.1, h2.1.2, h2.2.1, h2.2.2,
    h4.1.1, h4.1.2, h4.2.1, h4.2.2]

/-- Lipschitz bound along a walk. -/
theorem height_walk {v w : V} (p : (Gr h e).Walk v w) :
    |height e lam w - height e lam v| ≤ p.length * (2 * Lam) := by
  induction p with
  | nil => simp
  | @cons a b c hadj q ih =>
    have h1 := height_adj h e lam Lam hLam hadj
    have h2 := abs_sub_le (height e lam c) (height e lam b) (height e lam a)
    rw [SimpleGraph.Walk.length_cons]
    push_cast
    have h3 : ((q.length : ℤ) + 1) * (2 * Lam) = q.length * (2 * Lam) + 2 * Lam := by ring
    rw [h3]
    linarith [h1, ih, h2]

end Table

end Ful

end
