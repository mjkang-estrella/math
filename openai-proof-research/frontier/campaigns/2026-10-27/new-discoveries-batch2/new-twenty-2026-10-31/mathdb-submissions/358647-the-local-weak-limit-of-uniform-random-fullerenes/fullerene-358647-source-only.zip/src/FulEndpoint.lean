/-
FulEndpoint: the literal statement of MathDB 358647, proved.
-/
import FulBad
import FulHelixN
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Topology.Order.Basic
import Mathlib.Topology.MetricSpace.Pseudo.Defs
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option linter.unnecessarySeqFocus false
set_option linter.unusedTactic false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Stmt CMap Filter Topology
open scoped Classical

universe v

/-! ### Rooted isomorphism is an equivalence -/

theorem RootedBallIso.symm {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W} {a : V} {b : W}
    {r : ℕ} (h : RootedBallIso G a H b r) : RootedBallIso H b G a r := by
  obtain ⟨e, he⟩ := h
  refine ⟨e.symm, fun h1 h2 => ?_⟩
  have := he h2 h1
  rw [← this]
  exact e.toEquiv.symm_apply_apply ⟨a, h2⟩

theorem RootedBallIso.trans {V W U : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    {K : SimpleGraph U} {a : V} {b : W} {c : U} {r : ℕ} (h1 : RootedBallIso G a H b r)
    (h2 : RootedBallIso H b K c r) : RootedBallIso G a K c r := by
  obtain ⟨e1, he1⟩ := h1
  obtain ⟨e2, he2⟩ := h2
  refine ⟨e1.trans e2, fun ha hc => ?_⟩
  have hb : b ∈ ballSet H b r := by
    by_cases hr : r = 0
    · subst hr
      have : a ∈ ballSet G a 0 := ha
      exact absurd this (by simp [ballSet])
    · show H.edist b b < (r : ℕ∞)
      rw [SimpleGraph.edist_self]
      exact_mod_cast Nat.pos_of_ne_zero hr
  show e2 (e1 ⟨a, ha⟩) = ⟨c, hc⟩
  rw [he1 ha hb, he2 hb hc]

/-! ### The fraction of good roots -/

/-- The count of roots with a hexagonal ball. -/
def goodCount {n : ℕ} (G : SimpleGraph (Fin n)) (r : ℕ) {W : Type v} (K : SimpleGraph W) (o : W) : ℕ :=
  (univ.filter (fun v : Fin n => RootedBallIso G v K o r)).card

theorem ballFraction_eq {n : ℕ} (G : SimpleGraph (Fin n)) (r : ℕ) {W : Type v} (K : SimpleGraph W)
    (o : W) : ballFraction G r K o = (goodCount G r K o : ℝ) / n := by
  unfold ballFraction goodCount
  congr 2
  rw [Nat.card_eq_fintype_card, Fintype.card_subtype]

theorem goodCount_le {n : ℕ} (G : SimpleGraph (Fin n)) (r : ℕ) {W : Type v} (K : SimpleGraph W)
    (o : W) : goodCount G r K o ≤ n := by
  unfold goodCount
  calc _ ≤ (univ : Finset (Fin n)).card := Finset.card_filter_le _ _
    _ = n := by simp

/-! ### Exceptional classes -/

variable {n : ℕ}

/-- A class is exceptional if its chosen embedding has a short essential cycle. -/
def Exc (L : ℕ) (c : FullereneClass n) : Prop :=
  ∃ (C : SimpleCycle (fmap (Quotient.out c).2).dual) (S : Finset (fmap (Quotient.out c).2).dual.F),
    Essential C S ∧ C.len ≤ L

theorem exc_card_le (L : ℕ) (hL : 3 * (2 * (2 * L + bnd L)) < 3 * n) :
    (univ.filter (Exc (n := n) L)).card ≤ Fintype.card (Par L (3 * (2 * L + bnd L))) := by
  let ι := {c : FullereneClass n // Exc L c}
  let f : ι → CMap (Fin (3 * n)) := fun c => (fmap (Quotient.out c.1).2).dual
  have hcard : Fintype.card ι ≤ Fintype.card (Par L (3 * (2 * L + bnd L))) := by
    apply count_short_essential (D := Fin (3 * n)) f
    · simpa using hL
    · intro i; exact (fmap_isFullerene _).dual_tri
    · intro i; exact (fmap_isFullerene _).dual_connected
    · intro i; exact (fmap_isFullerene _).dual_genus
    · intro i; exact (fmap_isFullerene _).dual_simple
    · intro i v; exact (fmap_isFullerene _).dual_deg_le v
    · intro i; exact i.2
    · intro i j ⟨iso⟩
      obtain ⟨giso⟩ := graphIso_of_mapIso _ _ iso
      apply Subtype.ext
      have heq : (Quotient.mk (fullereneSetoid n) (Quotient.out i.1) : FullereneClass n) =
          Quotient.mk (fullereneSetoid n) (Quotient.out j.1) := Quotient.sound ⟨giso⟩
      rwa [Quotient.out_eq, Quotient.out_eq] at heq
  have : Fintype.card ι = (univ.filter (Exc (n := n) L)).card := Fintype.card_subtype _
  omega

/-- The hexagonal fraction of a non-exceptional class. -/
theorem good_of_not_exc {r : ℕ} {c : FullereneClass n} (hc : ¬ Exc (4 * (r + 2) + 4) c) :
    n ≤ goodCount (Quotient.out c).1 r hexLattice hexRoot + 72 * 7 ^ Rad r := by
  have hsys : ∀ (C : SimpleCycle (fmap (Quotient.out c).2).dual)
      (S : Finset (fmap (Quotient.out c).2).dual.F), Essential C S → 4 * (r + 2) + 4 < C.len := by
    intro C S hE
    by_contra hlt
    exact hc ⟨C, S, hE, by omega⟩
  have hb := bad_bound (Quotient.out c).2 r hsys
  have h1 : (univ.filter (fun v : Fin n => RootedBallIso (Quotient.out c).1 v hexLattice hexRoot r)).card +
      (univ.filter (fun v : Fin n => ¬ RootedBallIso (Quotient.out c).1 v hexLattice hexRoot r)).card = n := by
    have := Finset.card_filter_add_card_filter_not (s := (univ : Finset (Fin n)))
      (fun v : Fin n => RootedBallIso (Quotient.out c).1 v hexLattice hexRoot r)
    simpa using this
  unfold goodCount
  omega

/-! ### The limit -/

theorem frac_le_one {n : ℕ} (hn : 0 < n) (G : SimpleGraph (Fin n)) (r : ℕ) {W : Type v}
    (K : SimpleGraph W) (o : W) : ballFraction G r K o ≤ 1 := by
  rw [ballFraction_eq]
  have h1 : (goodCount G r K o : ℝ) ≤ n := by exact_mod_cast goodCount_le G r K o
  have h2 : (0 : ℝ) < n := by exact_mod_cast hn
  rwa [div_le_one h2]

theorem frac_nonneg {n : ℕ} (G : SimpleGraph (Fin n)) (r : ℕ) {W : Type v}
    (K : SimpleGraph W) (o : W) : 0 ≤ ballFraction G r K o := by
  rw [ballFraction_eq]
  positivity

/-- The hexagonal lower bound. -/
theorem prob_hex_lower (r L A B : ℕ) (hn : 0 < n) (hF : 0 < numFullerenes n)
    (hExc0 : (univ.filter (Exc (n := n) L)).card ≤ A)
    (hgc : ∀ c : FullereneClass n, ¬ Exc L c →
      n ≤ goodCount (Quotient.out c).1 r hexLattice hexRoot + B) :
    1 - (A : ℝ) / (numFullerenes n : ℝ) - (B : ℝ) / n ≤
      fullereneBallProb n r hexLattice hexRoot := by
  set F : ℝ := (numFullerenes n : ℝ) with hFdef
  have hFpos : 0 < F := by rw [hFdef]; exact_mod_cast hF
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn
  have hAnn : (0 : ℝ) ≤ A := Nat.cast_nonneg A
  have hBnn : (0 : ℝ) ≤ B := Nat.cast_nonneg B
  set g : FullereneClass n → ℝ := fun c => ballFraction (Quotient.out c).1 r hexLattice hexRoot with hg
  have hg0 : ∀ c, 0 ≤ g c := fun c => frac_nonneg _ _ _ _
  set b : ℝ := (B : ℝ) / n with hb
  have hb0 : 0 ≤ b := by rw [hb]; positivity
  have hgood : ∀ c, ¬ Exc L c → 1 - b ≤ g c := by
    intro c hc
    have h1 : (n : ℝ) ≤ goodCount (Quotient.out c).1 r hexLattice hexRoot + B := by
      exact_mod_cast hgc c hc
    show 1 - b ≤ ballFraction (Quotient.out c).1 r hexLattice hexRoot
    rw [ballFraction_eq, hb, show (1 : ℝ) - (B : ℝ) / n = ((n : ℝ) - B) / n by field_simp]
    gcongr
    linarith
  set Ex := univ.filter (Exc (n := n) L) with hEx
  have hExc : (Ex.card : ℝ) ≤ A := by exact_mod_cast hExc0
  have hsumsplit : ∑ c, g c = ∑ c ∈ Ex, g c + ∑ c ∈ univ.filter (fun c => ¬ Exc L c), g c := by
    rw [hEx]
    exact (Finset.sum_filter_add_sum_filter_not univ _ _).symm
  have hFcard : F = Ex.card + (univ.filter (fun c => ¬ Exc (n := n) L c)).card := by
    have := Finset.card_filter_add_card_filter_not (s := (univ : Finset (FullereneClass n)))
      (fun c => Exc L c)
    rw [hFdef, numFullerenes, ← Finset.card_univ, ← this]
    push_cast
    rfl
  have hEcomp : ((univ.filter (fun c => ¬ Exc (n := n) L c)).card : ℝ) * (1 - b) ≤
      ∑ c ∈ univ.filter (fun c => ¬ Exc L c), g c := by
    have := Finset.card_nsmul_le_sum (univ.filter (fun c => ¬ Exc (n := n) L c)) g (1 - b)
      (fun c hc => hgood c (by simpa using hc))
    simpa [nsmul_eq_mul] using this
  have hsum1 : 0 ≤ ∑ c ∈ Ex, g c := Finset.sum_nonneg (fun c _ => hg0 c)
  have hsum2 : ∑ c, g c ≥ 0 := Finset.sum_nonneg (fun c _ => hg0 c)
  show 1 - (A : ℝ) / F - b ≤ (∑ c, g c) / F
  by_cases hb1 : b ≤ 1
  · have hAF : (A : ℝ) / F ≥ 0 := by positivity
    have hEF : (Ex.card : ℝ) / F ≤ (A : ℝ) / F := by gcongr
    have hkey : (∑ c, g c) ≥ (F - Ex.card) * (1 - b) := by
      rw [hsumsplit]
      have h7 := hFcard
      nlinarith [hsum1, hEcomp]
    have hkey2 : (∑ c, g c) / F ≥ (1 - Ex.card / F) * (1 - b) := by
      rw [ge_iff_le, le_div_iff₀ hFpos]
      have h3 : (1 - (Ex.card : ℝ) / F) * (1 - b) * F = (F - Ex.card) * (1 - b) := by
        field_simp
      linarith
    have h4 : (1 - (Ex.card : ℝ) / F) * (1 - b) ≥ 1 - (A : ℝ) / F - b := by
      nlinarith [mul_nonneg hAF hb0, mul_nonneg (div_nonneg (Nat.cast_nonneg (α := ℝ) Ex.card) hFpos.le) hb0,
        hEF]
    linarith
  · have h5 : 1 - (A : ℝ) / F - b ≤ 0 := by
      have : (A : ℝ) / F ≥ 0 := by positivity
      push Not at hb1
      linarith
    have h6 : 0 ≤ (∑ c, g c) / F := div_nonneg hsum2 hFpos.le
    linarith

/-- Reduction to the hexagonal lower bound. -/
theorem prob_compare (r : ℕ) (hn : 0 < n) (hF : 0 < numFullerenes n) {W : Type v}
    (K : SimpleGraph W) (o : W) :
    |fullereneBallProb n r K o - if RootedBallIso hexLattice hexRoot K o r then 1 else 0| ≤
      1 - fullereneBallProb n r hexLattice hexRoot := by
  set F : ℝ := (numFullerenes n : ℝ) with hFdef
  have hFpos : 0 < F := by rw [hFdef]; exact_mod_cast hF
  have hnpos : (0 : ℝ) < n := by exact_mod_cast hn
  set p := fullereneBallProb n r hexLattice hexRoot with hp
  set q := fullereneBallProb n r K o with hq
  have hsumcard : ∑ _c : FullereneClass n, (1 : ℝ) = F := by
    simp [hFdef, numFullerenes, Finset.card_univ]
  have hq0 : 0 ≤ q := by
    rw [hq]
    apply div_nonneg _ hFpos.le
    exact Finset.sum_nonneg (fun c _ => frac_nonneg _ _ _ _)
  have hp1 : p ≤ 1 := by
    rw [hp, fullereneBallProb, div_le_one hFpos]
    calc ∑ c, ballFraction (Quotient.out c).1 r hexLattice hexRoot ≤ ∑ _c : FullereneClass n, (1 : ℝ) :=
          Finset.sum_le_sum (fun c _ => frac_le_one hn _ _ _ _)
      _ = F := hsumcard
  by_cases hK : RootedBallIso hexLattice hexRoot K o r
  · rw [Helix.ifT hK]
    have hle : p ≤ q := by
      rw [hp, hq, fullereneBallProb, fullereneBallProb]
      apply div_le_div_of_nonneg_right _ hFpos.le
      apply Finset.sum_le_sum
      intro c _
      rw [ballFraction_eq, ballFraction_eq]
      apply div_le_div_of_nonneg_right _ hnpos.le
      have hsub : univ.filter (fun v => RootedBallIso (Quotient.out c).1 v hexLattice hexRoot r) ⊆
          univ.filter (fun v => RootedBallIso (Quotient.out c).1 v K o r) := by
        intro v hv
        simp only [mem_filter, mem_univ, true_and] at hv ⊢
        exact Ful.RootedBallIso.trans hv hK
      exact_mod_cast Finset.card_le_card hsub
    have hq1 : q ≤ 1 := by
      rw [hq, fullereneBallProb, div_le_one hFpos]
      calc ∑ c, ballFraction (Quotient.out c).1 r K o ≤ ∑ _c : FullereneClass n, (1 : ℝ) :=
            Finset.sum_le_sum (fun c _ => frac_le_one hn _ _ _ _)
        _ = F := hsumcard
    rw [abs_le]
    constructor <;> linarith
  · rw [Helix.ifF hK, sub_zero, abs_of_nonneg hq0]
    have hdisj : ∀ c : FullereneClass n,
        ballFraction (Quotient.out c).1 r K o ≤
          1 - ballFraction (Quotient.out c).1 r hexLattice hexRoot := by
      intro c
      rw [ballFraction_eq, ballFraction_eq]
      have hdis : Disjoint
          (univ.filter (fun v => RootedBallIso (Quotient.out c).1 v K o r))
          (univ.filter (fun v => RootedBallIso (Quotient.out c).1 v hexLattice hexRoot r)) := by
        rw [Finset.disjoint_filter]
        intro v _ h1 h2
        exact hK (Ful.RootedBallIso.trans (Ful.RootedBallIso.symm h2) h1)
      have hle : goodCount (Quotient.out c).1 r K o +
          goodCount (Quotient.out c).1 r hexLattice hexRoot ≤ n := by
        unfold goodCount
        rw [← Finset.card_union_of_disjoint hdis]
        calc _ ≤ (univ : Finset (Fin n)).card := Finset.card_le_univ _
          _ = n := by simp
      have hle' : (goodCount (Quotient.out c).1 r K o : ℝ) +
          goodCount (Quotient.out c).1 r hexLattice hexRoot ≤ n := by exact_mod_cast hle
      rw [le_sub_iff_add_le, ← add_div, div_le_one hnpos]
      linarith
    have hqle : q ≤ 1 - p := by
      have h1 : ∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r K o ≤
          ∑ c : FullereneClass n, (1 - ballFraction (Quotient.out c).1 r hexLattice hexRoot) :=
        Finset.sum_le_sum (fun c _ => hdisj c)
      rw [Finset.sum_sub_distrib, hsumcard] at h1
      have hqe : q = (∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r K o) / F := rfl
      have hpe : p = (∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r hexLattice hexRoot) / F := rfl
      rw [hqe, hpe]
      have h2 : (∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r K o) / F ≤
          (F - ∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r hexLattice hexRoot) / F := by
        gcongr
      have h3 : (F - ∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r hexLattice hexRoot) / F =
          1 - (∑ c : FullereneClass n, ballFraction (Quotient.out c).1 r hexLattice hexRoot) / F := by
        field_simp
      linarith
    linarith

/-- **Local weak convergence of random fullerenes to the hexagonal lattice** (MathDB 358647,
Conjecture 1 of arXiv:2306.01462). -/
theorem localWeakConvergence : LocalWeakConvergence.{v} := by
  intro r W K o
  set L := 4 * (r + 2) + 4 with hLdef
  obtain ⟨A, hA⟩ : ∃ A : ℕ, A = Fintype.card (Par L (3 * (2 * L + bnd L))) := ⟨_, rfl⟩
  obtain ⟨B, hB⟩ : ∃ B : ℕ, B = 72 * 7 ^ Rad r := ⟨_, rfl⟩
  rw [Metric.tendsto_nhds]
  intro ε hε
  rw [fullereneLimit, Filter.eventually_inf_principal, Filter.eventually_atTop]
  -- thresholds
  set M : ℕ := Nat.ceil (3 * (A : ℝ) / ε) + 1 with hM
  obtain ⟨N1, hN1⟩ := Helix.numFullerenes_ge M
  set N2 : ℕ := Nat.ceil (3 * (B : ℝ) / ε) + 1 with hN2
  set N3 : ℕ := 2 * (2 * L + bnd L) + 1 with hN3
  refine ⟨max (max N1 N2) N3, fun n hn hord => ?_⟩
  have hnN1 : N1 ≤ n := le_trans (le_trans (le_max_left _ _) (le_max_left _ _)) hn
  have hnN2 : N2 ≤ n := le_trans (le_trans (le_max_right _ _) (le_max_left _ _)) hn
  have hnN3 : N3 ≤ n := le_trans (le_max_right _ _) hn
  have heven : Even n := Helix.even_of_order hord
  have hFM : M ≤ numFullerenes n := hN1 n hnN1 heven
  have hFpos : 0 < numFullerenes n := by omega
  have hnpos : 0 < n := by omega
  have hL3 : 3 * (2 * (2 * L + bnd L)) < 3 * n := by omega
  have hlow := prob_hex_lower (n := n) r L A B hnpos hFpos (by rw [hA]; exact exc_card_le L hL3)
    (fun c hc => by rw [hB]; exact good_of_not_exc hc)
  have hcmp := prob_compare (n := n) r hnpos hFpos K o
  rw [Real.dist_eq]
  have hFR : (0 : ℝ) < numFullerenes n := by exact_mod_cast hFpos
  have hnR : (0 : ℝ) < n := by exact_mod_cast hnpos
  have hA3 : ((A : ℝ)) / numFullerenes n ≤ ε / 3 := by
    rw [div_le_iff₀ hFR]
    have h1 : 3 * (A : ℝ) / ε ≤ (M : ℝ) := by
      calc 3 * (A : ℝ) / ε ≤ (Nat.ceil (3 * (A : ℝ) / ε) : ℝ) := Nat.le_ceil _
        _ ≤ (M : ℝ) := by rw [hM]; push_cast; linarith
    have h2 : (M : ℝ) ≤ numFullerenes n := by exact_mod_cast hFM
    have h3 : 3 * (A : ℝ) / ε ≤ numFullerenes n := h1.trans h2
    rw [div_le_iff₀ hε] at h3
    linarith
  have hB3 : ((B : ℝ)) / n ≤ ε / 3 := by
    rw [div_le_iff₀ hnR]
    have h1 : 3 * (B : ℝ) / ε ≤ (N2 : ℝ) := by
      calc 3 * (B : ℝ) / ε ≤ (Nat.ceil (3 * (B : ℝ) / ε) : ℝ) := Nat.le_ceil _
        _ ≤ (N2 : ℝ) := by rw [hN2]; push_cast; linarith
    have h2 : (N2 : ℝ) ≤ n := by exact_mod_cast hnN2
    have h3 : 3 * (B : ℝ) / ε ≤ n := h1.trans h2
    rw [div_le_iff₀ hε] at h3
    linarith
  calc |fullereneBallProb n r K o - if RootedBallIso hexLattice hexRoot K o r then 1 else 0|
      ≤ 1 - fullereneBallProb n r hexLattice hexRoot := hcmp
    _ ≤ (A : ℝ) / numFullerenes n + (B : ℝ) / n := by linarith
    _ ≤ ε / 3 + ε / 3 := add_le_add hA3 hB3
    _ < ε := by linarith

/-- The endpoint: the literal statement of MathDB 358647 together with the non-vacuity of the
limit filter. -/
theorem endpoint : LocalWeakConvergence.{v} ∧ NonVacuous := ⟨localWeakConvergence, Helix.nonVacuous⟩

end Ful

end
