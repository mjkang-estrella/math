/-
FulInj: a collision of the development along a lattice geodesic is impossible when essential
cycles are long and a large ball is flat.
-/
import FulLocal

set_option linter.unusedSectionVars false
set_option linter.unusedSimpArgs false

noncomputable section

namespace Ful

open Equiv Equiv.Perm Finset Module
open scoped Classical

variable {D : Type*} [Fintype D] [DecidableEq D]

namespace CMap

variable {M : CMap D}

/-- A geodesic-shaped closed sequence in the development cannot close up. -/
theorem collision_false (hT : M.IsTriangulation) (hc : M.Connected) (hg : M.Genus0)
    (hs : M.IsSimple) (hdeg : ∀ v, M.deg v ≤ 6) {d0 : D} {R : ℕ} (hF : M.FlatTo (M.tail d0) R)
    {L0 : ℕ} (hsys : ∀ (C : SimpleCycle M) (S : Finset M.F), Essential C S → L0 < C.len)
    {n Λ a u : ℕ} (p : ℕ → ℤ × ℤ) (v : ℕ → ℕ) (hn3 : 3 ≤ n) (hnL : n ≤ L0) (hu : u < 6)
    (hv : ∀ i, v i = if i < a then u else (u + 1) % 6)
    (hstep : ∀ i, i < n → p (i + 1) = ((p i).1 + ex (v i), (p i).2 + ey (v i)))
    (hreg : ∀ i, i ≤ n → L1 (p i) ≤ Λ) (hR : Λ + L0 + bnd L0 + 7 ≤ R)
    (hdist : ∀ i j, i < n → j < n →
      M.tail (M.dev d0 (p i).1 (p i).2) = M.tail (M.dev d0 (p j).1 (p j).2) → i = j)
    (hclose : M.tail (M.dev d0 (p n).1 (p n).2) = M.tail (M.dev d0 (p 0).1 (p 0).2)) : False := by
  have hv6 : ∀ i, v i < 6 := by
    intro i
    rw [hv]
    split_ifs
    · exact hu
    · exact Nat.mod_lt _ (by norm_num)
  set Dt : ℕ → D := fun i => M.psi d0 (p i) (v i) with hDt
  have htailDt : ∀ i, M.tail (Dt i) = M.tail (M.dev d0 (p i).1 (p i).2) := fun i => tail_psi _ _ _
  have hE : ∀ i, i < n → M.stp (Dt i) = M.psi d0 (p (i + 1)) (v i) := by
    intro i hi
    have h1 := psi_E hT hF (z := p i) (hv6 i) (by have := hreg i hi.le; omega)
    rw [hstep i hi]
    exact h1
  have hhead0 : ∀ i, i < n → M.tail (M.α (Dt i)) = M.tail (M.dev d0 (p (i + 1)).1 (p (i + 1)).2) := by
    intro i hi
    rw [← tail_stp, hE i hi, tail_psi]
  have hhead : ∀ i, i < n → M.tail (M.α (Dt i)) = M.tail (Dt ((i + 1) % n)) := by
    intro i hi
    rw [hhead0 i hi, htailDt]
    by_cases h1 : i + 1 < n
    · rw [Nat.mod_eq_of_lt h1]
    · have h2 : i + 1 = n := by omega
      rw [h2, Nat.mod_self]
      exact hclose
  obtain ⟨C, hlen, hdart⟩ := exists_cycle_of_seq hn3 Dt hhead (fun i j hi hj hij =>
    hdist i j hi hj (by rw [← htailDt, ← htailDt]; exact hij))
  have hlen2 : 2 ≤ C.len := by omega
  have hreach : ∀ i, i ≤ n → M.Reach (M.tail d0) Λ (M.tail (M.dev d0 (p i).1 (p i).2)) := by
    intro i hi
    have := reach_dev (M := M) d0 (p i).1 (p i).2
    exact this.mono (hreg i hi)
  have hflatP : ∀ i, i ≤ n → M.deg (M.tail (M.dev d0 (p i).1 (p i).2)) = 6 := fun i hi =>
    hF _ ((hreach i hi).mono (by omega))
  have hdartmod : ∀ i, i < n → C.dart i = Dt i := by
    intro i hi
    rw [hdart, Nat.mod_eq_of_lt hi]
  have hmodlt : ∀ j, j % n < n := fun j => Nat.mod_lt _ (by omega)
  have hdegC : ∀ k, M.deg (M.tail (C.dart k)) = 6 := by
    intro k
    rw [hdart, htailDt]
    exact hflatP _ (hmodlt k).le
  have hvert : ∀ w ∈ C.verts, M.deg w = 6 := by
    intro w hw
    obtain ⟨i, rfl⟩ := C.exists_of_vert_mem hw
    exact hdegC i
  obtain ⟨S, hS⟩ := exists_isSide C hc hg
  obtain ⟨S', hS', hcurv⟩ : ∃ S', IsSide C S' ∧ C.curv S' ≤ 5 := by
    by_cases h1 : C.curv S ≤ 5
    · exact ⟨S, hS, h1⟩
    · by_cases h2 : C.curv Sᶜ ≤ 5
      · exact ⟨Sᶜ, IsSide.compl C hS, h2⟩
      · exfalso
        have := hsys C S ⟨hS, by omega, by omega⟩
        omega
  have hb := bounded_disc hT hc hg hs hdeg _ C S' rfl hS' hcurv
  have hbm := bnd_mono (show C.len ≤ L0 by omega)
  have h0 : ∀ w ∈ C.verts, M.Reach (M.tail d0) Λ w := by
    intro w hw
    obtain ⟨i, rfl⟩ := C.exists_of_vert_mem hw
    rw [hdart, htailDt]
    exact hreach _ (hmodlt i).le
  have hreg2 := reach_region hc hS' h0
  have hcardV : (clV S').card ≤ bnd L0 + L0 := by
    have h1 := hS'.card_intV
    have h2 := hS'.tri_count hT hc hg
    omega
  have hflatS : ∀ w ∈ C.intV S', M.deg w = 6 := by
    intro w hw
    have h1 := hreg2 w (Finset.mem_sdiff.1 hw).1
    exact hF _ (h1.mono (by omega))
  have hc0 : C.curv S' = 0 := by
    unfold SimpleCycle.curv
    refine Finset.sum_eq_zero fun w hw => ?_
    rw [hflatS w hw]
    norm_num
  have hsumV : ∑ w ∈ C.verts, (6 - (M.deg w : ℤ)) = 0 := by
    refine Finset.sum_eq_zero fun w hw => ?_
    rw [hvert w hw]
    norm_num
  have hsplit := hS'.curv_split hT hg
  rw [hc0, hsumV] at hsplit
  have hc12 : C.curv S'ᶜ = 12 := by omega
  obtain ⟨Q, hQ, hface, hcurvQ⟩ : ∃ Q, IsSide C Q ∧ M.face (C.dart 0) ∈ Q ∧
      (C.curv Q = 0 ∨ C.curv Q = 12) := by
    by_cases h1 : M.face (C.dart 0) ∈ S'
    · exact ⟨S', hS', h1, Or.inl hc0⟩
    · exact ⟨S'ᶜ, IsSide.compl C hS', mem_compl.2 h1, Or.inr hc12⟩
  have hor := SimpleCycle.orient hlen2 hQ hface
  have hsumK := SimpleCycle.sum_K hlen2 hQ hor
  have hbc := hQ.boundary_corners hT hc hg
  -- first-return exponents along the geodesic
  have hKval : ∀ i, i + 1 < n → C.K i = 3 + (if i + 1 = a then 1 else 0) := by
    intro i hi
    have hi' : i < n := by omega
    have hflatα : M.Fl (M.α (Dt i)) := by
      apply Fl_of_deg
      rw [hhead0 i hi']
      exact hflatP _ hi.le
    have hαD := α_eq_of_Fl hflatα
    rw [hE i hi'] at hαD
    set x := M.dev d0 (p (i + 1)).1 (p (i + 1)).2 with hx
    have hxF : (M.σ ^ 6) x = x := (Fl_of_deg (hflatP (i + 1) hi.le)).pow6
    have hDi : M.α (Dt i) = (M.σ ^ (3 + v i)) x := by
      rw [hαD]
      show _ = (M.σ ^ (3 + v i)) x
      simp only [psi, pow_add, Perm.mul_apply, pow_succ', pow_zero, mul_one, pow_one]
      rfl
    have hDs : Dt (i + 1) = (M.σ ^ (v (i + 1))) x := rfl
    have hexp : (3 + (if i + 1 = a then 1 else 0) + (3 + v i)) % 6 = v (i + 1) % 6 := by
      by_cases h1 : i + 1 = a
      · have e1 : v i = u := by rw [hv, ite_eq_left (by omega)]
        have e2 : v (i + 1) = (u + 1) % 6 := by rw [hv, ite_eq_right (by omega)]
        rw [ite_eq_left h1, e1, e2]
        omega
      · by_cases h2 : i < a
        · have e1 : v i = u := by rw [hv, ite_eq_left h2]
          have e2 : v (i + 1) = u := by rw [hv, ite_eq_left (by omega)]
          rw [ite_eq_right h1, e1, e2]
          omega
        · have e1 : v i = (u + 1) % 6 := by rw [hv, ite_eq_right h2]
          have e2 : v (i + 1) = (u + 1) % 6 := by rw [hv, ite_eq_right (by omega)]
          rw [ite_eq_right h1, e1, e2]
          omega
    have hpow : (M.σ ^ (3 + (if i + 1 = a then 1 else 0))) (M.α (C.dart i)) = C.dart (i + 1) := by
      rw [hdartmod i hi', hdartmod (i + 1) hi, hDi, hDs, ← Perm.mul_apply, ← pow_add]
      exact pow6_congr hxF hexp
    apply K_exact hlen2 (by omega) (by split_ifs <;> omega) _ hpow
    exact hdegC _
  obtain ⟨m, hm⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  have hsumsplit : ∑ j ∈ range n, C.K j = ∑ j ∈ range m, C.K j + C.K m := by
    rw [hm, Finset.sum_range_succ]
  have hsumM : ∑ j ∈ range m, C.K j = 3 * m + (range m |>.filter (fun j => j + 1 = a)).card := by
    rw [Finset.sum_congr rfl (fun j hj => hKval j (by have := mem_range.1 hj; omega)),
      Finset.sum_add_distrib, Finset.sum_const, Finset.card_range, smul_eq_mul, Finset.card_filter,
      mul_comm]
  have hle1 : ((range m).filter (fun j => j + 1 = a)).card ≤ 1 :=
    Finset.card_le_one.2 (fun x hx y hy => by
      have h1 := (mem_filter.1 hx).2
      have h2 := (mem_filter.1 hy).2
      omega)
  have hKm1 := C.K_pos m
  have hKm2 : C.K m ≤ 5 := by
    apply K_le_five hlen2
    rw [C.chain]
    exact hdegC _
  rw [hlen] at hsumK
  rw [hlen] at hbc
  rcases hcurvQ with h1 | h1 <;> rw [h1] at hbc <;> omega

end CMap

end Ful

end
