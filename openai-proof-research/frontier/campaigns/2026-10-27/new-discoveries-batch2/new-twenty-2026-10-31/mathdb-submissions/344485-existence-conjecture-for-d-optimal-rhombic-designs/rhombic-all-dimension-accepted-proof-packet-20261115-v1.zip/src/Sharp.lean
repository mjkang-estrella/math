import MomentBound

noncomputable section
open scoped BigOperators
open Matrix
namespace Rhombic

theorem lift_intercept {K : ℕ} (M : Matrix (Option (Fin K)) (Option (Fin K)) ℝ)
    (U : Matrix (Fin K) (Fin K) ℝ) :
    ((liftOrthogonal U)ᴴ * M * liftOrthogonal U) none none = M none none := by
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, Fintype.sum_option]
  simp [liftOrthogonal]

theorem lift_slope_diagonal {K : ℕ} (M : Matrix (Option (Fin K)) (Option (Fin K)) ℝ)
    (U : Matrix (Fin K) (Fin K) ℝ) (i : Fin K) :
    ((liftOrthogonal U)ᴴ * M * liftOrthogonal U) (some i) (some i) =
      ∑ j, ∑ k, U j i * M (some j) (some k) * U k i := by
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, Fintype.sum_option]
  simp only [liftOrthogonal, star_trivial, zero_mul, mul_zero, zero_add,
    Finset.sum_mul]
  rw [Finset.sum_comm]

theorem flat_diagonal {K : ℕ} (hK : 2 ≤ K)
    (M : Matrix (Option (Fin K)) (Option (Fin K)) ℝ)
    (U : Matrix (Fin K) (Fin K) ℝ)
    (hflat : ∀ j, U j ⟨0, by omega⟩ = 1 / Real.sqrt (K:ℝ)) :
    ((liftOrthogonal U)ᴴ * M * liftOrthogonal U) (some ⟨0, by omega⟩) (some ⟨0, by omega⟩) =
      (∑ j, ∑ k, M (some j) (some k)) / (K:ℝ) := by
  rw [lift_slope_diagonal]
  simp only [hflat]
  have hk : (0:ℝ) < K := by exact_mod_cast (show 0 < K by omega)
  have hs := Real.sq_sqrt hk.le
  have hz : Real.sqrt (K:ℝ) ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr hk)
  simp only [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro k _
  field_simp
  rw [hs]
  ring

theorem sharp_psd_bound (K : ℕ) (hK : 2 ≤ K)
    (M : Matrix (Option (Fin K)) (Option (Fin K)) ℝ) (hM : M.PosSemidef) :
    M.det ≤ M none none * ((∑ j, ∑ k, M (some j) (some k))/(K:ℝ)) *
      (((∑ j, M (some j) (some j)) -
        (∑ j, ∑ k, M (some j) (some k))/(K:ℝ)) / ((K:ℝ)-1))^(K-1) := by
  classical
  obtain ⟨U,hU,hflat⟩ := exists_flat_orthogonal K hK
  let Q := liftOrthogonal U
  let T := Qᴴ * M * Q
  let i0 : Fin K := ⟨0, by omega⟩
  let s := (Finset.univ : Finset (Fin K)).erase i0
  have hQ := liftOrthogonal_mul U hU
  have hT : T.PosSemidef := hM.conjTranspose_mul_mul_same Q
  have h0 : T none none = M none none := lift_intercept M U
  have hf : T (some i0) (some i0) =
      (∑ j, ∑ k, M (some j) (some k))/(K:ℝ) := flat_diagonal hK M U hflat
  have hcard : s.card = K-1 := by simp [s]
  have hs : s.Nonempty := Finset.card_pos.mp (by rw [hcard]; omega)
  have ht := transformed_trace M Q hQ
  have hsum : (∑ i ∈ s, T (some i) (some i)) =
      (∑ j, M (some j) (some j)) - T (some i0) (some i0) := by
    have he := Finset.sum_erase_add (s := (Finset.univ : Finset (Fin K)))
      (f := fun i => T (some i) (some i)) (Finset.mem_univ i0)
    simp only [Matrix.trace, Fintype.sum_option] at ht
    change T none none + (∑ i, T (some i) (some i)) =
      M none none + (∑ i, M (some i) (some i)) at ht
    rw [h0] at ht
    dsimp [s]
    linarith
  have hp := finite_amgm s hs (fun i => T (some i) (some i))
    (fun i _ => hT.diag_nonneg)
  have hkcast : ((K-1:ℕ):ℝ) = (K:ℝ)-1 := by simpa using (Nat.cast_sub (R := ℝ) (show 1 ≤ K by omega))
  have hprod : (∏ i, T (some i) (some i)) ≤
      T (some i0) (some i0) *
        (((∑ j, M (some j) (some j)) - T (some i0) (some i0))/((K:ℝ)-1))^(K-1) := by
    rw [← Finset.mul_prod_erase _ _ (Finset.mem_univ i0)]
    apply mul_le_mul_of_nonneg_left _ hT.diag_nonneg
    simpa only [hsum, hcard, hkcast] using hp
  have hb := orthogonal_psd_bound M Q hM hQ
  change M.det ≤ ∏ i, T i i at hb
  rw [Fintype.prod_option, h0] at hb
  calc
    M.det ≤ M none none * ∏ i, T (some i) (some i) := hb
    _ ≤ M none none * (T (some i0) (some i0) *
      (((∑ j, M (some j) (some j)) - T (some i0) (some i0))/((K:ℝ)-1))^(K-1)) :=
        mul_le_mul_of_nonneg_left hprod hM.diag_nonneg
    _ = _ := by rw [hf]; ring

#print axioms sharp_psd_bound
end Rhombic
