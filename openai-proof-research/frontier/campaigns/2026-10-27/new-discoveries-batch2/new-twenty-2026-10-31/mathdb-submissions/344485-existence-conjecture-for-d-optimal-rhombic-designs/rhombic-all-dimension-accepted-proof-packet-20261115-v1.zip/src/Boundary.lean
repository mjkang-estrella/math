import Scalar
noncomputable section
namespace Rhombic

theorem scalar_positive_interior {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 r t : ℝ}
    (hz : (r,t) ∈ triangle K) (hp : 0 < scalarF K d0 d1 d2 r t) :
    0 < r ∧ 0 < t ∧ t < (K:ℝ)*r := by
  have hk : 0 < K-1 := by omega
  have ht0 : t ≠ 0 := by
    intro ht
    simp [scalarF,ht] at hp
  have htr : t ≠ (K:ℝ)*r := by
    intro ht
    have hd : (K:ℝ) ≠ 0 := by exact_mod_cast (show K ≠ 0 by omega)
    have he : r-t/(K:ℝ) = 0 := by rw [ht]; field_simp; ring
    simp [scalarF,he,ne_of_gt hk] at hp
  have ht : 0 < t := lt_of_le_of_ne hz.2.2.1 (Ne.symm ht0)
  have hlt : t < (K:ℝ)*r := lt_of_le_of_ne hz.2.2.2 htr
  have hr : 0 < r := by
    have hK0 : (0:ℝ) ≤ K := by positivity
    by_contra hn
    have he : r=0 := le_antisymm (le_of_not_gt hn) hz.1
    rw [he,mul_zero] at hlt
    linarith
  exact ⟨hr,ht,hlt⟩

theorem exists_positive_interior_maximum {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) :
    ∃ r t : ℝ, 0 < r ∧ r ≤ (K:ℝ) ∧ 0 < t ∧ t < (K:ℝ)*r ∧
      ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 r t := by
  obtain ⟨⟨r,t⟩,hz,hp,hm⟩ := exists_scalar_maximum hK hc
  obtain ⟨hr,ht,htr⟩ := scalar_positive_interior hK hz hp
  exact ⟨r,t,hr,hz.2.1,ht,htr,hm⟩

#print axioms scalar_positive_interior
#print axioms exists_positive_interior_maximum
end Rhombic
