import OrbitInformationR3
noncomputable section
open scoped BigOperators
namespace Rhombic
open OrbitR3

theorem exists_rhombic_attaining_scalarF {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 r t : ℝ}
    (hc : Cone K d0 d1 d2) (hr : 0 < r) (hrK : r ≤ (K:ℝ))
    (ht : 0 < t) (htr : t < (K:ℝ)*r) (hf : Even K ∨ 1/(K:ℝ) ≤ t/r) :
    ∃ ξ : ApproxDesign K, RhombicDesign ξ ∧
      (information d0 d1 d2 ξ).det = scalarF K d0 d1 d2 r t := by
  have hk : (0:ℝ)<K := by exact_mod_cast (show 0<K by omega)
  have hk2 : (2:ℝ)≤K := by exact_mod_cast hK
  let ρ := Real.sqrt (r/(K:ℝ))
  have hρ : 0 < ρ := Real.sqrt_pos.mpr (div_pos hr hk)
  have hρsq : ρ^2 = r/(K:ℝ) := Real.sq_sqrt (div_nonneg hr.le hk.le)
  have hρ1 : ρ ≤ 1 := by
    have hh : r/(K:ℝ) ≤ 1 := (div_le_one hk).mpr hrK
    nlinarith
  have hR : (K:ℝ)*ρ^2 = r := by rw [hρsq]; field_simp
  have hs : ((K:ℝ)*ρ)^2 = (K:ℝ)*r := by
    calc
      ((K:ℝ)*ρ)^2 = (K:ℝ)*((K:ℝ)*ρ^2) := by ring
      _ = (K:ℝ)*r := by rw [hR]
  by_cases he : Even K
  · let l := (t/r)/(K:ℝ)
    have hl : 0 ≤ l := le_of_lt (div_pos (div_pos ht hr) hk)
    have hl1 : l ≤ 1 := by
      apply (div_le_one hk).mpr
      exact (div_le_iff₀ hr).mpr htr.le
    apply untilt_law_attainment hK hc hr hrK ht htr hρ hρ1 hl hl1 hR
    rw [avg_sum_sq,seeds_true_sum]
    change l*((K:ℝ)*ρ)^2+(1-l)*(∑ i,balanced K ρ i)^2 = t
    rw [balanced_even he,hs]
    dsimp [l]
    field_simp
    all_goals ring
  · have ho : Odd K := (Nat.even_or_odd K).resolve_left he
    have hh : 1/(K:ℝ) ≤ t/r := hf.resolve_left he
    have hden : 0 < (K:ℝ)^2-1 := by nlinarith
    have hh0 : 1 ≤ (K:ℝ)*(t/r) := by
      have h := (div_le_iff₀ hk).mp hh
      nlinarith
    have hh1 : t/r < (K:ℝ) := (div_lt_iff₀ hr).mpr htr
    let l := ((K:ℝ)*(t/r)-1)/((K:ℝ)^2-1)
    have hl : 0 ≤ l := div_nonneg (by linarith) hden.le
    have hl1 : l ≤ 1 := by
      apply (div_le_one hden).mpr
      nlinarith
    apply untilt_law_attainment hK hc hr hrK ht htr hρ hρ1 hl hl1 hR
    rw [avg_sum_sq,seeds_true_sum]
    change l*((K:ℝ)*ρ)^2+(1-l)*(∑ i,balanced K ρ i)^2 = t
    rw [balanced_odd ho,neg_sq,hs,hρsq]
    dsimp [l]
    field_simp
    all_goals ring

#print axioms exists_rhombic_attaining_scalarF
end Rhombic
