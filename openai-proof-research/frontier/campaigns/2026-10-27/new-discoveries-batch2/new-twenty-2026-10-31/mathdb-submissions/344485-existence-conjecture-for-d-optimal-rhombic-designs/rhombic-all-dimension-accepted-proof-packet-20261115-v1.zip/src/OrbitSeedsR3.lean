import OrbitExpectationR3
import Mathlib.Algebra.BigOperators.Fin
noncomputable section
open scoped BigOperators
namespace Rhombic.OrbitR3

def balanced (K : ℕ) (ρ : ℝ) : Point K := fun i => if i.val < K/2 then ρ else -ρ

def seeds (K : ℕ) (ρ : ℝ) (b : Bool) : Point K := if b then fun _ => ρ else balanced K ρ

theorem step_sum (m n : ℕ) (ρ : ℝ) :
    (∑ i : Fin (m+n), if i.val < m then ρ else -ρ) = ((m:ℝ)-(n:ℝ))*ρ := by
  rw [Fin.sum_univ_add]
  have h1 : (∑ i : Fin m, if (Fin.castAdd n i).val < m then ρ else -ρ) = (m:ℝ)*ρ := by simp
  have h2 : (∑ i : Fin n, if (Fin.natAdd m i).val < m then ρ else -ρ) = (n:ℝ)*(-ρ) := by
    simp
  rw [h1,h2]
  ring

theorem threshold_sum (K m : ℕ) (hm : m ≤ K) (ρ : ℝ) :
    (∑ i : Fin K, if i.val < m then ρ else -ρ) = (2*(m:ℝ)-(K:ℝ))*ρ := by
  obtain ⟨n,rfl⟩ := Nat.exists_eq_add_of_le hm
  rw [step_sum, Nat.cast_add]
  ring

theorem balanced_sum (K : ℕ) (ρ : ℝ) :
    (∑ i, balanced K ρ i) = (2*(K/2:ℕ)-(K:ℝ))*ρ := by
  exact threshold_sum K (K/2) (Nat.div_le_self K 2) ρ

theorem balanced_even {K : ℕ} (h : Even K) (ρ : ℝ) : ∑ i, balanced K ρ i = 0 := by
  obtain ⟨m,hm⟩ := h
  have he : K/2 = m := by omega
  rw [balanced_sum,he]
  have hk : (K:ℝ) = 2*(m:ℝ) := by exact_mod_cast (show K=2*m by omega)
  rw [hk]; ring

theorem balanced_odd {K : ℕ} (h : Odd K) (ρ : ℝ) : ∑ i, balanced K ρ i = -ρ := by
  obtain ⟨m,hm⟩ := h
  have he : K/2 = m := by omega
  rw [balanced_sum,he]
  have hk : (K:ℝ) = 2*(m:ℝ)+1 := by exact_mod_cast (show K=2*m+1 by omega)
  rw [hk]; ring

theorem seeds_abs (K : ℕ) {ρ : ℝ} (hρ : 0 ≤ ρ) (b : Bool) (i : Fin K) :
    |seeds K ρ b i| = ρ := by
  cases b with
  | true => exact abs_of_nonneg hρ
  | false =>
    change |if i.val < K/2 then ρ else -ρ| = ρ
    split_ifs <;> simp [abs_of_nonneg hρ]

theorem seeds_cube (K : ℕ) {ρ : ℝ} (hρ : 0 ≤ ρ) (hρ1 : ρ ≤ 1) :
    ∀ b i, -1 ≤ seeds K ρ b i ∧ seeds K ρ b i ≤ 1 := by
  intro b i
  have h := seeds_abs K hρ b i
  have hh := abs_le.mp (h.trans_le hρ1)
  exact hh

theorem seeds_norm (K : ℕ) (ρ : ℝ) (b : Bool) :
    (∑ i, seeds K ρ b i ^ 2) = (K:ℝ)*ρ^2 := by
  have h : ∀ i, seeds K ρ b i ^ 2 = ρ^2 := by
    intro i
    cases b with
    | true => rfl
    | false =>
      change (if i.val < K/2 then ρ else -ρ)^2 = ρ^2
      split_ifs <;> simp
  simp [h]

theorem seeds_true_sum (K : ℕ) (ρ : ℝ) : (∑ i, seeds K ρ true i) = (K:ℝ)*ρ := by
  simp [seeds]

#print axioms balanced_even
#print axioms balanced_odd
#print axioms seeds_abs
#print axioms seeds_cube
#print axioms seeds_norm
#print axioms seeds_true_sum
end Rhombic.OrbitR3
