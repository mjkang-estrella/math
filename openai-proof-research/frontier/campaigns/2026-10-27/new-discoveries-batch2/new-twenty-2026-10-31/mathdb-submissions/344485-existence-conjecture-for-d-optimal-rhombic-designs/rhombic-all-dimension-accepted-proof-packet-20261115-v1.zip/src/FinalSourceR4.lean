import OrbitPackagingR3
import OddFeasible

/-! MathDB 344485, final unconditional assembly (r4).
`OrbitPackagingR3` supplies the actual finite rhombic orbit attainment and the global
comparison packaging; `OddFeasible` supplies the unconditional scalar feasible maximum.
No hypothesis beyond the source quantifiers remains. -/

noncomputable section
open scoped BigOperators
namespace Rhombic
namespace FinalR4

/-- The scalar supply required by the orbit packaging, proved unconditionally. -/
theorem feasible_scalar_maxima : FeasibleScalarMaximaR3 := by
  intro K hK d0 d1 d2 hc hpar
  obtain ⟨r, t, hmem, hr, ht, htr, hodd, hmax⟩ :=
    exists_rhombic_feasible_scalar_maximum hK hc hpar
  have htri : 0 ≤ r ∧ r ≤ (K:ℝ) ∧ 0 ≤ t ∧ t ≤ (K:ℝ) * r := hmem
  refine ⟨r, t, hr, htri.2.1, ht, htr, ?_, hmax⟩
  rcases Nat.even_or_odd K with he | ho
  · exact Or.inl he
  · exact Or.inr (hodd ho).2

/-- The literal source target, unconditionally. -/
theorem source_target : SourceTarget :=
  source_target_of_feasible_scalar_maxima feasible_scalar_maxima

/-- Expanded endpoint: literal cone and all four rhombic clauses inlined. -/
theorem expanded_source_target :
    ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ,
      (0 < d0 ∧ 0 < d1 ∧ -d1/((K:ℝ)-1) ≤ d2 ∧ d2 ≤ d1) →
      (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
      ∃ ξ : ApproxDesign K,
        (∀ p : Equiv.Perm (Fin K), ∀ x, ξ.mass (x ∘ p) = ξ.mass x) ∧
        (∀ x, ξ.mass (-x) = ξ.mass x) ∧
        (∀ x ∈ ξ.mass.support, ∃ ρ : ℝ, 0 < ρ ∧ ∀ i, |x i| = ρ) ∧
        (∀ x ∈ ξ.mass.support, ∀ y ∈ ξ.mass.support,
          (∃ c : ℝ, c ≠ 0 ∧ y = c • x) → y = x ∨ y = -x) ∧
        ∀ η : ApproxDesign K, (information d0 d1 d2 η).det ≤ (information d0 d1 d2 ξ).det :=
  expanded_source_target_of_feasible_scalar_maxima feasible_scalar_maxima

/-- Fully literal endpoint: additionally the information matrix and the variance
`d0 + (d1-d2) Σ x_k^2 + d2 (Σ x_k)^2` are inlined (no covariance inverse anywhere). -/
theorem literal_source_target :
    ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ,
      (0 < d0 ∧ 0 < d1 ∧ -d1/((K:ℝ)-1) ≤ d2 ∧ d2 ≤ d1) →
      (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
      ∃ ξ : ApproxDesign K,
        (∀ p : Equiv.Perm (Fin K), ∀ x, ξ.mass (x ∘ p) = ξ.mass x) ∧
        (∀ x, ξ.mass (-x) = ξ.mass x) ∧
        (∀ x ∈ ξ.mass.support, ∃ ρ : ℝ, 0 < ρ ∧ ∀ i, |x i| = ρ) ∧
        (∀ x ∈ ξ.mass.support, ∀ y ∈ ξ.mass.support,
          (∃ c : ℝ, c ≠ 0 ∧ y = c • x) → y = x ∨ y = -x) ∧
        ∀ η : ApproxDesign K,
          Matrix.det ((fun i j => η.mass.sum (fun x w =>
              w * regressor x i * regressor x j /
                (d0 + (d1-d2) * (∑ k, x k ^ 2) + d2 * (∑ k, x k) ^ 2))) :
              Option (Fin K) → Option (Fin K) → ℝ) ≤
          Matrix.det ((fun i j => ξ.mass.sum (fun x w =>
              w * regressor x i * regressor x j /
                (d0 + (d1-d2) * (∑ k, x k ^ 2) + d2 * (∑ k, x k) ^ 2))) :
              Option (Fin K) → Option (Fin K) → ℝ) :=
  expanded_source_target

#check @feasible_scalar_maxima
#check @source_target
#check @literal_source_target
#print axioms feasible_scalar_maxima
#print axioms source_target
#print axioms expanded_source_target
#print axioms literal_source_target

end FinalR4
end Rhombic
