import Semantics
import Mathlib.LinearAlgebra.Matrix.Reindex

noncomputable section
open scoped BigOperators
open Matrix
namespace Rhombic

theorem variance_covariance {K : ℕ} (d0 d1 d2 : ℝ) (x : Point K) :
    variance d0 d1 d2 x =
      ∑ i, ∑ j, regressor x i * covariance K d0 d1 d2 i j * regressor x j := by
  classical
  simp [Fintype.sum_option, regressor, covariance, variance,
    mul_add, add_mul, Finset.sum_add_distrib, Finset.mul_sum, Finset.sum_mul,
    mul_ite, ite_mul, pow_two]
  ring_nf
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  ring

theorem orthogonal_psd_bound {n : Type*} [Fintype n] [DecidableEq n]
    (M Q : Matrix n n ℝ) (hM : M.PosSemidef) (hQ : Qᴴ * Q = 1) :
    M.det ≤ ∏ i, (Qᴴ * M * Q) i i := by
  have hd : Q.det * Q.det = 1 := by
    have h := congrArg Matrix.det hQ
    simpa using h
  have he : (Qᴴ * M * Q).det = M.det := by
    simp only [Matrix.det_mul, Matrix.det_conjTranspose, star_trivial]
    calc
      Q.det * M.det * Q.det = M.det * (Q.det * Q.det) := by ring
      _ = M.det := by rw [hd, mul_one]
  rw [← he]
  exact psd_hadamard n _ (hM.conjTranspose_mul_mul_same Q)

theorem information_orthogonal_bound {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K)
    (Q : Matrix (Option (Fin K)) (Option (Fin K)) ℝ) (hQ : Qᴴ * Q = 1) :
    (information d0 d1 d2 η).det ≤
      ∏ i, (Qᴴ * information d0 d1 d2 η * Q) i i :=
  orthogonal_psd_bound _ Q (information_psd hK hc η) hQ

theorem information_coordinate_bound {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    (information d0 d1 d2 η).det ≤
      information d0 d1 d2 η none none *
        ∏ i, information d0 d1 d2 η (some i) (some i) := by
  have h := psd_hadamard _ _ (information_psd hK hc η)
  simpa only [Fintype.prod_option] using h

#print axioms variance_covariance
#print axioms information_orthogonal_bound
#print axioms information_coordinate_bound
end Rhombic
