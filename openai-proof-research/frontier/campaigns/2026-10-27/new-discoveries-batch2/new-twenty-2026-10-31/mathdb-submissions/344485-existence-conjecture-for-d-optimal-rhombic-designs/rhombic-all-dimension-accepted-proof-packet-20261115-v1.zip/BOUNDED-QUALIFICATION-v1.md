# Independent qualification of MathDB 344485 — v1

Review date: 2026-11-16 UTC (2026-11-15 America/Los_Angeles). Reviewer role, no children. Current count 74/80 NEW, 113 total; credit added 0.

**Scientific verdict: ordinary v2 proof PASS UNCHANGED; source fidelity PASS in the native multiple-regression domain K>=2; bounded contribution SUBSTANTIAL, with explicit unread prior risk; full literal formalization route feasible but entirely unpaid. Recommendation: root may consider a full-endpoint formal implementation, not acceptance or helper-only credit. Process is NOT clean: the deviations below remain UNWAIVED.** No Lean execution, query, version check, probe or compilation occurred. This is an independent mathematical judgment, not a repetition of the producer's label or a formal certificate.

## 1. Authentication and exact endpoint

The owned target-only JSONL identifies MathDB 344485, UUID 06c61365-9900-48da-926e-a1b65b8d14ac, with solutions=[] and solution_count=0. Its owned provenance attests raw line 3863, raw-line SHA256 e6b158ccc7a8578afcd9acd62c5e7a3c64aaf2f8cf0e0d5eed474f85702e51d7 and projected-chunk SHA256 1dd3c17314e7e62aa885f671966b45b8792ff8509b6186b2da18e52a7715ab88. I personally read the complete target projection and provenance; I did not reopen the parent raw corpus. Those bytes and the source model, not the open label, bind this review.

Primary: Ulrike Graßhoff (Grasshoff), Heinz Holling, Frank Röttger (Roettger/Rottger), Rainer Schwabe, *Optimality regions for designs in multiple linear regression models with correlated random coefficients*, arXiv:1911.05538v1, 13 November 2019. Personally read §2 model, information and approximate-design convention; §3 model cone and Definition 3.2; Lemma 3.4; actual Theorems 4.1 and 4.4 statements and inspected proof passages; Corollary 4.5/Remark 4.6; §6 discussion and Conjecture 6.1. Rendered and visually inspected complete PDF pages 2,3,4,15. Remaining small-dimensional calculations, reference bodies and the rest of the paper were not comprehensively read.

The literal cone is

C_K={(d0,d1,d2) in R^3: d0>0, d1>0, -d1/(K-1)<=d2<=d1}.

The design region is [-1,1]^K; f(x)=(1,x). With A=d1-d2, B=d2, C=d1+(K-1)d2=A+KB,

D=diag(d0,A I_K+B J_K),  A>=0, C>=0,
V(x)=f(x)^T D f(x)=d0+A ||x||²+B(sum x_i)²,
M(ξ)=sum_x ξ(x) f(x)f(x)^T/V(x).

Finite approximate designs have arbitrary nonnegative real weights summing to one, with arbitrary finite support. The source relaxes exact integer sample-size weights. This is not a theorem for fixed sample size. It does not require Borel measures as its literal competitor convention. The same comparison extends to probability measures by integrating bounded continuous matrix entries, but that extension is not used to replace the finite endpoint.

A rhombic design is invariant under coordinate permutations and simultaneous global sign reversal; its support is on space diagonals, excludes the origin, and contains at most two points on each diagonal. The group is NOT independent coordinate sign changes when B!=0. The source orbit O_l(ρ) has l or K-l negative coordinates, all coordinates of magnitude ρ>0; its size is 2 choose(K,l), except for even l=K/2 where it is choose(K,l). Zero-mass orbits may be omitted.

Endpoint: for every source-admissible K and every cone parameter, if K is even, or K is odd and d2<=d1/2, there exists a rhombic approximate design maximizing det M against ALL finite approximate designs on the cube. Positive determinant makes this equivalent to the source log-det objective.

Dimension fidelity: the source works with multiple regression, the cone uses division by K-1, and the analyzed dimensions begin at 2. The PDF does not expressly print “K>=2” beside Conjecture 6.1. K>=2 is the contextual, well-defined multivariate cone domain, not an extra strict-rank assumption. K=1 has an undefined displayed cone bound; it must not be silently read using Lean's totalized division. Under the separately defined one-factor diagonal model, symmetric ±sqrt(min(1,d0/d1)) is optimal by the same two-moment calculation. K=0 is not the source model; a literal extension of the nonorigin support predicate there is impossible. Neither is a credited refutation or domain repair. A formal statement-fidelity reviewer must make this contextual convention explicit.

## 2. Independent ordinary proof

I read the entire producer-v2 proof, offsets 2012 through 7420, and rederived the following argument. No source code or old experiment was replayed.

### 2.1 Variance, global averaging, and moments

For every x, write r_x=||x||², t_x=(sum x_i)². Then 0<=t_x<=K r_x and r_x<=K. If B<0, A r_x+B t_x >= (A+KB)r_x=C r_x>=0; if B>=0, positivity follows from A>=0. Thus V(x)>=d0>0 even when D is singular.

For g a coordinate permutation or global negation, the induced orthogonal Q_g=diag(1,P_g) preserves D and V, and M(gξ)=Q_g M(ξ) Q_g^T. The finite group average ξbar is still a finite approximate design, invariant, and its information is the arithmetic average of these matrices. For positive definite M, log-det concavity proves det M<=det Mbar. To include singular competitors rigorously, apply the inequality to all Q_g(M+εI)Q_g^T, ε>0. Their average is Mbar+εI; take ε down to zero using polynomial continuity of determinant. No inverse of D is involved. Every competitor information is PSD, and a positive-determinant example exists, for instance a full cube factorial with strictly positive masses. Thus singular information cannot be used to exclude a competitor from the quantifier.

For invariant ξ set a=sum ξ(x)/V(x)>0 and q_x=ξ(x)/(a V(x)). The q_x are probabilities. Put r=sum q_x r_x and t=sum q_x t_x. Then

0<=r<=K, 0<=t<=Kr, 1=a S, S=d0+A r+B t.

Sign invariance kills the intercept-slope block. Permutation invariance gives equal diagonal slope moments b=a r/K and equal offdiagonal moments c=a(t-r)/(K(K-1)). The slope eigenvalues are

u=b-c=a(Kr-t)/(K(K-1)), multiplicity K-1,
v=b+(K-1)c=a t/K, multiplicity 1.

Consequently det M equals

F(r,t)=t (Kr-t)^(K-1) / [K^K (K-1)^(K-1) S^(K+1)].

The intercept contributes one additional factor a, explaining the crucial exponent K+1. This holds algebraically on singular information boundaries as well.

The triangle T={0<=r<=K, 0<=t<=Kr} is compact. S>=d0 throughout T by the same B sign argument, so F is continuous. A point such as r=K/2,t=r has F>0 for K>=2. Hence F has a positive maximum, and every maximizing point has r>0, 0<t<Kr. T is only a relaxation; it is emphatically not the full cube moment set. The remaining task is to attain a maximum of that relaxation by an admissible rhombic design.

Independent alternative global determinant proof, useful for formalization: for an arbitrary, unaveraged competitor use an orthonormal slope basis whose first vector is 1/sqrt(K). Adjoin the intercept vector. The corresponding diagonal entries are a, a t/K, and K-1 nonnegative numbers with sum a(r-t/K). The PSD Hadamard inequality and AM-GM bound their determinant by exactly F(r,t). The invariant group average has that same r,t and determinant F. This also proves averaging dominance directly for singular competitors. It avoids assuming an unimplemented log-det theorem or a Kiefer-Wolfowitz oracle. This is an alternative proof, not a repair to v2.

### 2.2 Even dimensions and actual weights

Let (r,t) maximize F and h=t/r in (0,K), ρ=sqrt(r/K) in (0,1]. Let O0 consist of the all-positive point and its antipode. Let O* be the even balanced orbit with K/2 plus signs. Each point has squared norm r; squared coordinate sums are Kr on O0 and 0 on O*. Take tilted orbit probabilities λ=h/K and 1-λ. Set V0=d0+A r+B Kr, V*=d0+A r and a=1/S. The ACTUAL orbit masses are

w0=a λ V0, w*=a(1-λ)V*.

These are nonnegative, add to a[d0+A r+B λKr]=1, and after uniform division by orbit cardinalities their inverse-variance tilt is exactly the selected tilted law. Thus they realize a,r,t and F(r,t). Using λ as an actual orbit mass would in general be wrong.

Every coordinate has magnitude ρ>0. A space diagonal intersects this common-radius support in at most the antipodal pair; the two orbits are disjoint for K>=2. Invariance and finite support are explicit. The construction therefore meets the full source rhombic predicate and attains a determinant upper bound for every competitor. It proves the even assertion throughout the closed PSD cone endpoints.

### 2.3 Odd maximum and feasibility

For odd K>=3 assume B<=d1/2, equivalently B<=A. With t=rh the determinant, up to a positive K-only constant, is

H(r,h)=r^K h(K-h)^(K-1)/[d0+(A+Bh)r]^(K+1).

Write E=A+Bh>=0. For 0<h<K and r>0,

∂r log H=(K d0-E r)/(r(d0+E r)).

Thus the radial maximum is R(h)=min(K,K d0/E) for E>0 and R(h)=K for E=0. The latter is a genuine increasing-r branch, not division by zero. At a positive maximum the endpoints h=0,K are impossible.

Let G(h)=H(R(h),h). I independently checked it is strictly increasing for 0<h<1/K. If B<=0, at every fixed positive r,

∂h log H=K(1-h)/(h(K-h))-(K+1)B r/(d0+E r)>0.

Strict increase is preserved by evaluating at the first h's optimizing radius before maximizing at the second. This argument includes E=0 without a division by E.

If B>0, B<=A implies A>=B>0, hence E>0. Since R<=K d0/E,

R/(d0+ER)<=K/((K+1)E),
∂h log H(R,h)>=K[A-(A+(K-1)B)h]/[h(K-h)E]>0

for h<1/K, using A+(K-1)B<=KA. On the R=K branch the derivative of R is zero. On the R=K d0/E branch the partial r derivative of H is zero, so the envelope derivative has exactly the indicated sign. There is at most one switch E=d0 (B>0); R and H are continuous there and the radial derivative is zero at the switch, so the one-sided derivatives agree. This proves strict increase across the switch, not just on a generic smooth branch. A maximum below 1/K is impossible (compare with a slightly larger h still below 1/K). Therefore a relaxed maximum satisfies 1/K<=h<K.

For odd O*, take (K+1)/2 plus and (K-1)/2 minus signs, together with antipodes. Its squared coordinate sum is ρ²=r/K, so h*=1/K, not 1. Choose

λ=(K h-1)/(K²-1) in [0,1).

Then λ Kr+(1-λ)r/K=rh. Convert tilted masses into actual masses using w_i=λ_i V_i/S as before, with V*=d0+A r+B r/K. All weights normalize; uniform orbit distributions give the exact maximizing moments. If λ=0, omit O0: the remaining orbit has both slope eigenvalues positive, because 0<1/K<K. Common positive radius again gives at most two points per diagonal. This proves global optimality and the odd assertion.

### 2.4 Boundary audit

No D inverse occurs. A=0 (d2=d1) is allowed in the even result; C=0 (d2=-d1/(K-1)) is allowed in both results; B=0 is allowed; equality B=A is allowed in the odd result. At B=A the derivative estimate is still strict on h<1/K and may become equality at the lower feasible endpoint, which is permitted. At E=0 use R=K. T's zero-determinant edges cannot maximize. r=K is explicitly permitted, while r=0 is excluded by positivity of the maximum, not by an arbitrary support restriction. K=2 has distinct allsame and balanced orbits; K=3's odd balanced orbit is not rank deficient. Generic-rank, strict-PD covariance, finite competitor sets, and within-class optimality assumptions are nowhere needed.

**Conclusion:** no correction to the 344485 v2 proof is required. Its analytic core is complete in the native scope. The alternative determinant bound strengthens the closure plan but does not change the theorem or its hypotheses.

## 3. Preserved errors and hostile SELF

Producer v1 and v2 remain immutable. The visible v1 correction is in the unrelated 317628 tail-law discussion: v1 called the uniform law on {0,1/2,1} stationary and gave value 14/27; v2 records actual value 10/27 and the stationarity obstruction 10u²-6u+1=0 with discriminant -4. I did not independently qualify that other target. The complete version diff is retained. It does not alter the 344485 proof. This is not evidence of a flawless producer process.

Hostile objections and resolutions:

- “All cube moments form T.” False. Only an upper bound is claimed; orbit attainment is separately proved at the maximizer.
- “Tilted masses can be used as design weights.” False. The explicit V_i/S correction is indispensable.
- “Odd two-orbit mixtures have h>=1.” False. The minimum is 1/K, derived from the actual sign imbalance and norm.
- “A global optimum might be at the prohibited origin.” F=0 there, whereas an interior triangle value is positive.
- “Concavity silently drops singular matrices.” Regularization above handles them; the direct PSD bound provides an independent alternative.
- “The symmetry group contains all sign changes.” It does not. Only permutations and global reversal are used.
- “Every source interior theorem permits singular D inversion.” No. The main proof never imports that inverse statement at singular D.
- “Small exact checks certify all K.” They do not. They only check implementation algebra after the uniform derivation.
- “Open metadata proves novelty.” It does not. The significance comparison and unread risks below are independent gates.
- “An opaque global criterion is enough for Lean.” It is not. The full determinant bound, actual design predicate, weights and maximizer have to be proved.

## 4. Classical-method and bounded current-prior comparison

Current journal identity: same title/authors, Journal of Statistical Planning and Inference 209 (2020), 267–279, DOI 10.1016/j.jspi.2020.04.004. Current institutional publication search metadata corroborates this identity; it is not a personally read journal theorem. I requested ScienceDirect robots, HTTP200, which gives User-agent:* Disallow:/. No journal body was requested, nor was any alternate body route used to recover it. Accordingly I cannot claim the final still contains Conjecture 6.1 unchanged or lacks a later proof.

The exact dissertation is Frank Röttger, *Geometry of Optimal Design* (2020 dissertation filename/metadata lead). Its owned access control records an Anubis challenge returned at opendata.uni-halle.de/robots.txt, HTTP200, not usable robots. Body STOP remains binding: no challenge retry, mirror, cache, alternate endpoint or alternate host recovery. The current general search returned indexed Conjecture 4.14 text; that is an index lead only, not a read theorem body, and was not followed. Its wording points to the same existence conjecture and further work; it does not supply an authenticated proof. No exact dissertation result is claimed. This is not an author-wide ban: the independently owned arXiv v1 remains lawful.

Fresh arXiv robots was acquired and its 15-second crawl-delay respected before /abs/1911.05538. Current submission-history metadata displays only v1, dated 13 November 2019. This confirms a current version lead, not worldwide priority. Own v1 body is the primary theorem text actually inspected.

Three fresh search calls, six queries, covering exact title/journal DOI and rhombic/even/odd existence/proof terminology, are preserved in prior-search-1/2/3.json. The queries did not name the restricted public registry. Search misses are not proof of absence; irrelevant broad optimal-design hits were not treated as theorem evidence. No subscription index or worldwide/non-English search was performed. The full source-sensitive records, own custody hashes and fresh request metadata are in the evidence index.

Strongest routine/native case: permutation averaging, equicorrelation diagonalization, compact maximization, inverse-variance tilting and one-variable differentiation are classical. Source §3 already makes invariant designs essentially complete; Lemma 3.4 already supplies the block form. Theorem 4.1 gives a sufficient vertex criterion Γ=diag(γ0,-γ0/K I), γ0>=0, with an odd-single-balanced-orbit qualification in its equivalence. Theorem 4.4 gives the interior criterion M=D^-1/(K+1) where invertibility is meaningful. Neither inspected theorem asserts feasibility of nonnegative rhombic weights for every K and every allowed cone parameter.

Complete bridge against that contrary case: on an interior-radius stationary branch, optimizing h gives h=A/[A+(K-1)B] when that branch applies. Substitution gives a=1/((K+1)d0), u=1/((K+1)A), v=1/((K+1)C), precisely the native interior criterion when A,C>0. On the vertex branch r=K, the h stationarity and radial one-sided inequality translate into zero offdiagonal Γ coefficient and the native γ0>=0 criterion. Thus the scalar optimum is compatible with the old criteria; these calculations by themselves do not construct feasible orbit masses. The all-K addition is the two-extreme-orbit projective moment realization, actual untilting, and the odd envelope exclusion below 1/K including the branch junction and PSD boundaries. The source's small-K Resolve/RegionPlot calculations do not supply that uniform feasibility bridge. I found no inspected old theorem whose complete specialization already supplies it.

My bounded contribution judgment is SUBSTANTIAL as one all-dimensional resolution of this particular existence endpoint, though the method uses classical tools and may admit a short proof. It is not a new general framework. There is no authenticated PUBLIC0 evidence or demonstrated routine full specialization within the read material. Conversely no absolute new-to-literature claim is warranted. The unread journal final and dissertation are material risks, but neither is a mathematical dependency of this proof, nor did the acquired metadata actually identify a duplicate proof. I therefore do not impose an automatic inaccessible-body HOLD. A newly authenticated exact duplicate would change this verdict to PUBLIC0; a complete old uniform specialization would change it to TECHNICAL0. Formal difficulty and an open label play no role in this judgment.

## 5. Released-field comparison: 113 / 14 / 373

comparison-screen.json machine-screened ALL released JSON fields of 113 acceptance records, all 14 supplements and all 373 dated catalogue groups; 66 broad keyword matches were retained, including false positives. This is a field comparison, not access to original registry proofs. I personally read all 113+14 released headings in six bounded reads; for the 373 catalogue, personal coverage is the 42 matched group heading/statement prefixes, not all 373 full statements. I personally read full released scopes for the closest matrix cases (indices 67,71,72,74,75,107 in the 113 release), and the full catalogue predicates for families 140,262,325. Scope fields are bounded projections, not full original theorem definitions. No claim of complete technical corpus review is made.

Nearest substantive comparisons:

- Vendi–LCR arbitrary-rank negative-order comparison concerns finite PSD spectral power sums; it contains no cube-design existence or rhombic witness predicate.
- Novak positivity and the cubic C*-moment refutations concern specific finite operator matrices and nonPSD defects. They do not maximize information determinants.
- Positive-diagonal concavity refutation (338076) concerns an elementary-symmetric polynomial fourth root, not a design covariance or orbit feasibility theorem.
- The 3x3 permanental Koteljanskii theorem concerns sharp permanent ratios on strictly TP3 matrices, not arbitrary-K equicorrelated regression.
- The uniform-matroid weighted finite multiplier theorem preserves real-rootedness of real polynomials; “multiplier” is unrelated to design weights.
- Catalogue family 140 is memory/sample complexity for Gaussian inference; 262 is finite-matrix Lieb–Thirring spectral bounds for matrix potentials; 325 is the complete Crouzeix operator-polynomial inequality. Their full displayed predicates do not assert this design endpoint or its negation. Other matched headings concerned determinant complexity, SLn fixed determinant, crossing numbers, games, transport and unrelated optimality.

No matching endpoint or already-credited rhombic-design family was found within this stated coverage. This is a bounded nonoverlap result, not a worldwide absence theorem. All 14 supplements were screened and their headings read; none was a plausible design-specific predicate requiring protected original-body access. Catalogue blob/date and current registry HEAD are custody/context only. The owned refresh reports HEAD 4eaee87548250b2682affda7d05d947c05554bae at 2026-11-16T00:05:37Z; no original registry body was requested or read.

## 6. Literal Lean readiness (SOURCE TEXT ONLY)

Pinned STANDARD release: mathlib d13f23b723b8a846827a245b89c10fc7d3f11612; supplied Lean version metadata 4.34.1. No tool was invoked to verify versions or query Lean. Only released source text/path metadata were read. The full plan and actual interface table are in FORMAL-ENDPOINT-PLAN.md. A feasible route exists, but every new bridge is still unpaid. There is no compiled statement, theorem, axiom audit or replay.

Required endpoint is global existence for arbitrary K>=2 and all cone parameters with Even K or the odd inequality, quantifying over ALL source finite approximate competitors. Definitions must include the finite real weights, information denominator, cube bounds, invariance, space-diagonal support, nonorigin support and at most two points per diagonal. They must not encode a global-optimality helper as an assumed premise.

Recommended closure order: finite design definitions and positivity; full PSD determinant comparison; finite group and moment block identities; compact maximum and positive determinant; even/odd sign orbit moments/counts; actual weights; radial/odd envelope calculus with boundary cases; assemble the literal existence endpoint; independent statement review and only then strict axiom audit and extracted rebuild. These are stages of one full closure, not separately credited results.

A custom PSD Hadamard inequality can be proved by dimension induction using the actual Schur-complement determinant API, with a zero-pivot row-vanishing branch. This avoids unavailable log-det concavity APIs and singular inverses. Explicit Helmert vectors supply an orthogonal basis, avoiding an assumed basis-extension helper. The scalar calculus and finite sums are routine implementation once exact definitions are fixed. Estimated effort is several thousand Lean lines (roughly 3,000–8,000, uncertainty substantial), dominated by matrix inequality, moment/group/orbit bookkeeping and full scalar boundary analysis. This is a realistic multi-stage implementation, not a tiny certificate. No genuine mathematical blocker was found; the strongest engineering risk is an expensive matrix-inequality/basis proof. No helper-only GO is given.

## 7. Read/resource/failure/process map and handoff

The machine evidence and process maps are in evidence-index.json and review-maps.json. Inputs were frozen-before checked 63/63, zero mismatches; affinity bootstrap [0,1]. All writes stayed in this lane. Capped runner documentary receipts retain commands, outputs, stderr, group sampled RSS and CPU/wall information. The exact run additionally lowered child CPU to 90 seconds and was wrapped by timeout110; 6GiB AS/RSS guards and [0,1] affinity applied. One own exact run, 60 rational cases K=2..6, radius1/2, d0=2/3,d1=1,d2=-1/(K-1),0,1/2,1, tilted λ=0,1/3,2/3. Direct finite orbit enumeration and rational Gaussian elimination matched weights/cardinalities/formula in every case. It used about 0.054426 child CPU seconds (scientific inner CPU 0.039931), wall0.065466 seconds, sampled peak12,849,152 bytes. Remaining exact run was unused. No numerical optimizer or finite-as-uniform inference occurred.

Fresh direct GET hops=3: ScienceDirect robots, arXiv robots, arXiv abstract. Search=3 calls/6 queries. No redirects, journal body, dissertation request, registry request, source script, installation, child, credit, ledger, git, publication, upload, external message or account action. The journal robots prohibition is preserved prospectively. Prior producer budgets are historical and were not reset.

UNWAIVED deviations in THIS review: the initial inventory shell preceded bootstrap; the initial combined TASK/control/script read exceeded the <6000-character response ceiling and logical/payload slice limits. Several later aggregate reads also exceeded logical2000 and/or payload2400; an early controls-index tool display was truncated and was not called personal full reading. The exhaustive JSON screen and later exact read inventory do not retroactively waive these failures. The AGENTS bodies were personally read after frozen-before. The alias screening occurred before scientific body reads for the restored arXiv target/authors, but newly discovered DOI/ScienceDirect identity screening was not separately documented before that robots request; this ordering defect remains unwaived. Two standard source paths were initially guessed in a source-text search, one nonexistent; later actual inventory corrected the route, not the historical failure. There were no Lean probes. The payload audit in review-maps.json enumerates runner outputs over2400; initial direct-shell displays remain additionally listed there.

Preserved failures: agents-2 exited1 due to an incorrect relative AGENTS path; agents-2-fixed succeeded. standard-hadamard searched a nonexistent Analysis/Matrix/Hadamard.lean (the real LinearAlgebra file is unrelated entrywise products); no false Hadamard-inequality API is claimed. Searches for sqrt in deprecated Data/Real/Sqrt.lean initially found none; its actual import redirected the read to Analysis/Real/Sqrt.lean. These were documentary source-text reads, not formal tool queries. All producer UNWAIVED history remains preserved, including its late rescreen and initial sequencing/display failures. Unrelated historical bodies were not blanket-read or followed; machine screening is not personal reading.

Final handoff: scientific ordinary PASS UNCHANGED, bounded substantial contribution, explicit source/prior limits and unexecuted full formal route. Root retains all acceptance authority. Count remains 74/80 NEW and 113 total. Process-clean acceptance is NOT claimed. After all artifacts are written, run standalone frozen-after, then exhaustive terminal seal excluding exactly the manifest and its generating runner receipt/stdout; no subsequent commands or writes.

Final documentary addendum: final-recursive-screen.json screens all39 frozen JSONs (8532 scalars); this late comprehensive pass does not cure ordering defects. final-screen-narratives printed9192 characters and was truncated in the tool display, another UNWAIVED cap failure; it is machine output, not claimed full personal reading. The relevant publisher-policy context was then read separately: the inherited Kuszmaul–Zhou restriction is exact-work-specific, not a hostwide historical closure, while current wildcard ScienceDirect robots independently forbids this review body request. standard-text-custody.json binds the actual read STANDARD source files. review-maps.json preserves the full output-size audit.
