import OrbitAttainmentR3
noncomputable section
namespace Rhombic

def FeasibleScalarMaximaR3 : Prop :=
  ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ, Cone K d0 d1 d2 →
    (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
    ∃ r t : ℝ, 0 < r ∧ r ≤ (K:ℝ) ∧ 0 < t ∧ t < (K:ℝ)*r ∧
      (Even K ∨ 1/(K:ℝ) ≤ t/r) ∧
      ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 r t

theorem actual_global_of_feasible_scalar_maximum {K : ℕ} (hK : 2 ≤ K)
    {d0 d1 d2 r t : ℝ} (hc : Cone K d0 d1 d2)
    (hr : 0 < r) (hrK : r ≤ (K:ℝ)) (ht : 0 < t) (htr : t < (K:ℝ)*r)
    (hf : Even K ∨ 1/(K:ℝ) ≤ t/r)
    (hm : ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 r t) :
    ∃ ξ : ApproxDesign K, RhombicDesign ξ ∧
      ∀ η : ApproxDesign K, (information d0 d1 d2 η).det ≤ (information d0 d1 d2 ξ).det := by
  obtain ⟨ξ,hξ,hd⟩ := exists_rhombic_attaining_scalarF hK hc hr hrK ht htr hf
  refine ⟨ξ,hξ,fun η => ?_⟩
  rw [hd]
  exact (source_scalar_bound hK hc η).trans
    (hm (tiltR d0 d1 d2 η,tiltT d0 d1 d2 η) (tilted_triangle hK hc η))

theorem source_target_of_feasible_scalar_maxima (supply : FeasibleScalarMaximaR3) : SourceTarget := by
  intro K hK d0 d1 d2 hc hregion
  obtain ⟨r,t,hr,hrK,ht,htr,hf,hm⟩ := supply K hK d0 d1 d2 hc hregion
  exact actual_global_of_feasible_scalar_maximum hK hc hr hrK ht htr hf hm

theorem expanded_source_target_of_feasible_scalar_maxima (supply : FeasibleScalarMaximaR3) :
    ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ,
      (0 < d0 ∧ 0 < d1 ∧ -d1/((K:ℝ)-1) ≤ d2 ∧ d2 ≤ d1) →
      (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
      ∃ ξ : ApproxDesign K,
        (∀ p : Equiv.Perm (Fin K), ∀ x, ξ.mass (x ∘ p) = ξ.mass x) ∧
        (∀ x, ξ.mass (-x) = ξ.mass x) ∧
        (∀ x ∈ ξ.mass.support, ∃ ρ : ℝ, 0 < ρ ∧ ∀ i, |x i| = ρ) ∧
        (∀ x ∈ ξ.mass.support, ∀ y ∈ ξ.mass.support,
          (∃ c : ℝ, c ≠ 0 ∧ y = c • x) → y = x ∨ y = -x) ∧
        ∀ η : ApproxDesign K, (information d0 d1 d2 η).det ≤ (information d0 d1 d2 ξ).det := by
  intro K hK d0 d1 d2 hc hregion
  obtain ⟨ξ,hξ,hm⟩ := source_target_of_feasible_scalar_maxima supply K hK d0 d1 d2 hc hregion
  exact ⟨ξ,hξ.1,hξ.2.1,hξ.2.2.1,hξ.2.2.2,hm⟩

#print axioms FeasibleScalarMaximaR3
#print axioms actual_global_of_feasible_scalar_maximum
#print axioms source_target_of_feasible_scalar_maxima
#print axioms expanded_source_target_of_feasible_scalar_maxima
end Rhombic
