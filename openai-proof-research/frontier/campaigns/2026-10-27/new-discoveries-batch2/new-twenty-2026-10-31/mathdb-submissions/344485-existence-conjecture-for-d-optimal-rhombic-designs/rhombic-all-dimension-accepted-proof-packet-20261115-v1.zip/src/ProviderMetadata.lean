import Lean
#eval (do
  let r ← IO.Process.output {cmd := "python3", args := #["-I", "-B", "/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/provider_map.py"]}
  IO.println r.stdout
  if r.exitCode != 0 then throw (IO.userError r.stderr)
  : IO Unit)
