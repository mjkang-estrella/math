import Geometry
import Mathlib.GroupTheory.Perm.Fin
noncomputable section
open scoped BigOperators
namespace Rhombic.OrbitR3

abbrev Index (K : ℕ) := Bool × Equiv.Perm (Fin K) × Bool

def point {K : ℕ} (v : Bool → Rhombic.Point K) (a : Index K) : Rhombic.Point K :=
  fun i => if a.2.2 then v a.1 (a.2.1 i) else -v a.1 (a.2.1 i)

def weight (K : ℕ) (l : ℝ) (a : Index K) : ℝ :=
  (if a.1 then l else 1-l) / (2 * Fintype.card (Equiv.Perm (Fin K)))

theorem weight_nonneg {K : ℕ} {l : ℝ} (hl : 0 ≤ l) (hl1 : l ≤ 1) (a : Index K) :
    0 ≤ weight K l a := by
  unfold weight
  apply div_nonneg
  · split_ifs <;> linarith
  · positivity

theorem weight_total (K : ℕ) (l : ℝ) : ∑ a : Index K, weight K l a = 1 := by
  have hn : (Fintype.card (Equiv.Perm (Fin K)) : ℝ) ≠ 0 := by positivity
  simp [weight, Fintype.sum_prod_type ]
  field_simp
  ring

def law {K : ℕ} (v : Bool → Rhombic.Point K) (l : ℝ)
    (hl : 0 ≤ l) (hl1 : l ≤ 1)
    (hv : ∀ a i, -1 ≤ v a i ∧ v a i ≤ 1) : Rhombic.ApproxDesign K :=
  Rhombic.designOfFinite Finset.univ (point v) (weight K l)
    (fun a _ => weight_nonneg hl hl1 a)
    (by simpa using weight_total K l)
    (by
      intro a _ i
      dsimp [point]
      split_ifs
      · exact hv a.1 (a.2.1 i)
      · constructor <;> linarith [(hv a.1 (a.2.1 i)).1, (hv a.1 (a.2.1 i)).2])

theorem law_sum {K : ℕ} (v : Bool → Rhombic.Point K) (l : ℝ)
    (hl : 0 ≤ l) (hl1 : l ≤ 1)
    (hv : ∀ a i, -1 ≤ v a i ∧ v a i ≤ 1) (g : Rhombic.Point K → ℝ) :
    (law v l hl hl1 hv).mass.sum (fun y w => w*g y) =
      ∑ a : Index K, weight K l a * g (point v a) := by
  exact Rhombic.consolidate_sum _ _ _ _

#print axioms weight_nonneg
#print axioms weight_total
#print axioms law
#print axioms law_sum
end Rhombic.OrbitR3
