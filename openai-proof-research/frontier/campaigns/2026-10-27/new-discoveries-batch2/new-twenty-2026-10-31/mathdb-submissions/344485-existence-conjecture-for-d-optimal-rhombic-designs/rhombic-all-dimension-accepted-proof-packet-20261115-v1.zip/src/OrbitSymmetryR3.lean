import OrbitAverageR3
noncomputable section
open scoped BigOperators
namespace Rhombic.OrbitR3

theorem consolidate_invariant {ι : Type*} [Fintype ι] {K : ℕ}
    (x : ι → Point K) (w : ι → ℝ) (e : ι ≃ ι) (T : Point K ≃ Point K)
    (hx : ∀ a, x (e a) = T (x a)) (hw : ∀ a, w (e a) = w a) (y : Point K) :
    consolidate Finset.univ x w (T y) = consolidate Finset.univ x w y := by
  classical
  simp only [consolidate, Finsupp.finsetSum_apply]
  rw [← Equiv.sum_comp e (fun a => (Finsupp.single (x a) (w a) : Point K →₀ ℝ) (T y))]
  apply Finset.sum_congr rfl
  intro a _
  rw [hx,hw]
  simp only [Finsupp.single_apply, T.injective.eq_iff]

def permPoint {K : ℕ} (p : Equiv.Perm (Fin K)) : Point K ≃ Point K where
  toFun y := y ∘ p
  invFun y := y ∘ p.symm
  left_inv y := by ext i; simp
  right_inv y := by ext i; simp

def negPoint (K : ℕ) : Point K ≃ Point K where
  toFun y := -y
  invFun y := -y
  left_inv y := neg_neg y
  right_inv y := neg_neg y

def notBool : Bool ≃ Bool where
  toFun := Bool.not
  invFun := Bool.not
  left_inv := Bool.not_not
  right_inv := Bool.not_not

theorem law_permutation {K : ℕ} (v : Bool → Point K) (l : ℝ)
    (hl : 0 ≤ l) (hl1 : l ≤ 1)
    (hv : ∀ a i, -1 ≤ v a i ∧ v a i ≤ 1)
    (p : Equiv.Perm (Fin K)) (y : Point K) :
    (law v l hl hl1 hv).mass (y ∘ p) = (law v l hl hl1 hv).mass y := by
  let e : Index K ≃ Index K := Equiv.prodCongr (Equiv.refl Bool)
    (Equiv.prodCongr (Equiv.mulRight p) (Equiv.refl Bool))
  apply consolidate_invariant (point v) (weight K l) e (permPoint p)
  · intro a; ext i; rfl
  · intro a; rfl

theorem law_neg {K : ℕ} (v : Bool → Point K) (l : ℝ)
    (hl : 0 ≤ l) (hl1 : l ≤ 1)
    (hv : ∀ a i, -1 ≤ v a i ∧ v a i ≤ 1) (y : Point K) :
    (law v l hl hl1 hv).mass (-y) = (law v l hl hl1 hv).mass y := by
  let e : Index K ≃ Index K := Equiv.prodCongr (Equiv.refl Bool)
    (Equiv.prodCongr (Equiv.refl _) notBool)
  apply consolidate_invariant (point v) (weight K l) e (negPoint K)
  · intro a; ext i
    change (if !a.2.2 then v a.1 (a.2.1 i) else -v a.1 (a.2.1 i)) =
      -(if a.2.2 then v a.1 (a.2.1 i) else -v a.1 (a.2.1 i))
    cases a.2.2 <;> simp
  · intro a; rfl

theorem law_radius {K : ℕ} (v : Bool → Point K) (l : ℝ)
    (hl : 0 ≤ l) (hl1 : l ≤ 1)
    (hv : ∀ a i, -1 ≤ v a i ∧ v a i ≤ 1) {ρ : ℝ}
    (hr : ∀ a i, |v a i| = ρ) (y : Point K)
    (hy : y ∈ (law v l hl hl1 hv).mass.support) : ∀ i, |y i| = ρ := by
  obtain ⟨a,_,rfl⟩ := consolidate_support _ _ _ hy
  intro i
  dsimp [point]
  split_ifs <;> simp [hr]

theorem law_rhombic {K : ℕ} (hK : 0 < K) (v : Bool → Point K) (l : ℝ)
    (hl : 0 ≤ l) (hl1 : l ≤ 1)
    (hv : ∀ a i, -1 ≤ v a i ∧ v a i ≤ 1) {ρ : ℝ} (hρ : 0 < ρ)
    (hr : ∀ a i, |v a i| = ρ) : RhombicDesign (law v l hl hl1 hv) :=
  common_radius_rhombic hK _ (law_permutation v l hl hl1 hv)
    (law_neg v l hl hl1 hv) hρ (law_radius v l hl hl1 hv hr)

#print axioms consolidate_invariant
#print axioms law_permutation
#print axioms law_neg
#print axioms law_radius
#print axioms law_rhombic
end Rhombic.OrbitR3
