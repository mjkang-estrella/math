import Basis
import Mathlib.Analysis.MeanInequalities
import Mathlib.LinearAlgebra.Matrix.Trace

noncomputable section
open scoped BigOperators
open Matrix
namespace Rhombic

theorem finite_amgm {ι : Type*} (s : Finset ι) (hs : s.Nonempty)
    (z : ι → ℝ) (hz : ∀ i ∈ s, 0 ≤ z i) :
    ∏ i ∈ s, z i ≤ ((∑ i ∈ s, z i)/(s.card:ℝ))^s.card := by
  have hn : s.card ≠ 0 := ne_of_gt (Finset.card_pos.mpr hs)
  have hn' : (0:ℝ) < s.card := by exact_mod_cast (Finset.card_pos.mpr hs)
  have h := Real.geom_mean_le_arith_mean s (fun _ => 1) z
    (fun _ _ => by norm_num) (by simpa using hn') hz
  simp only [Real.rpow_one, Finset.sum_const, nsmul_eq_mul, mul_one,
    Finset.sum_congr rfl (fun i hi => one_mul (z i))] at h
  have hp := pow_le_pow_left₀ (Real.rpow_nonneg (Finset.prod_nonneg hz) _) h s.card
  simpa only [Real.rpow_inv_natCast_pow (Finset.prod_nonneg hz) hn] using hp

def liftOrthogonal {K : ℕ} (U : Matrix (Fin K) (Fin K) ℝ) :
    Matrix (Option (Fin K)) (Option (Fin K)) ℝ
  | none, none => 1
  | some i, some j => U i j
  | _, _ => 0

theorem liftOrthogonal_mul {K : ℕ} (U : Matrix (Fin K) (Fin K) ℝ)
    (hU : Uᴴ * U = 1) : (liftOrthogonal U)ᴴ * liftOrthogonal U = 1 := by
  ext i j
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, Fintype.sum_option]
  cases i with
  | none => cases j <;> simp [liftOrthogonal]
  | some i => cases j with
    | none => simp [liftOrthogonal]
    | some j =>
      have h := congrFun (congrFun hU i) j
      simpa [liftOrthogonal, Matrix.mul_apply, Matrix.conjTranspose_apply, Matrix.one_apply] using h

theorem transformed_trace {n : Type*} [Fintype n] [DecidableEq n]
    (M Q : Matrix n n ℝ) (hQ : Qᴴ * Q = 1) :
    (Qᴴ * M * Q).trace = M.trace := by
  have hQ' : Q * Qᴴ = 1 := mul_eq_one_comm.mp hQ
  rw [Matrix.trace_mul_cycle, hQ', Matrix.one_mul]

#print axioms finite_amgm
#print axioms liftOrthogonal_mul
#print axioms transformed_trace
end Rhombic
