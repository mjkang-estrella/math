import FinalSourceR4
import OrbitCompleteAuditR3

-- Counted runtime metadata (not proof).
#eval Lean.versionString
#eval Lean.githash

#print axioms Rhombic.Point
#print axioms Rhombic.ApproxDesign
#print axioms Rhombic.regressor
#print axioms Rhombic.covariance
#print axioms Rhombic.variance
#print axioms Rhombic.information
#print axioms Rhombic.Cone
#print axioms Rhombic.SameDiagonal
#print axioms Rhombic.RhombicDesign
#print axioms Rhombic.SourceTarget
#print axioms Rhombic.psd_hadamard
#print axioms Rhombic.cone_coefficients
#print axioms Rhombic.cone_moment_nonneg
#print axioms Rhombic.sum_square_bound
#print axioms Rhombic.variance_ge_d0
#print axioms Rhombic.variance_pos
#print axioms Rhombic.outer_psd
#print axioms Rhombic.finite_sum_psd
#print axioms Rhombic.information_psd
#print axioms Rhombic.variance_covariance
#print axioms Rhombic.orthogonal_psd_bound
#print axioms Rhombic.information_orthogonal_bound
#print axioms Rhombic.information_coordinate_bound
#print axioms Rhombic.flatVector
#print axioms Rhombic.flat_inner
#print axioms Rhombic.exists_flat_basis
#print axioms Rhombic.exists_flat_orthogonal
#print axioms Rhombic.finite_amgm
#print axioms Rhombic.liftOrthogonal
#print axioms Rhombic.liftOrthogonal_mul
#print axioms Rhombic.transformed_trace
#print axioms Rhombic.lift_intercept
#print axioms Rhombic.lift_slope_diagonal
#print axioms Rhombic.flat_diagonal
#print axioms Rhombic.sharp_psd_bound
#print axioms Rhombic.source_global_bound
#print axioms Rhombic.ExpandedSourceTarget
#print axioms Rhombic.target_expansion
#print axioms Rhombic.tiltA
#print axioms Rhombic.tiltQ
#print axioms Rhombic.tiltR
#print axioms Rhombic.tiltT
#print axioms Rhombic.tiltA_pos
#print axioms Rhombic.tiltQ_nonneg
#print axioms Rhombic.tiltQ_total
#print axioms Rhombic.cube_norm_bound
#print axioms Rhombic.tilted_triangle
#print axioms Rhombic.tilt_normalization
#print axioms Rhombic.scalarS
#print axioms Rhombic.scalarF
#print axioms Rhombic.information_intercept
#print axioms Rhombic.tilt_weighted_sum
#print axioms Rhombic.information_slope_trace
#print axioms Rhombic.information_slope_sum
#print axioms Rhombic.tiltA_eq_inv
#print axioms Rhombic.source_scalar_bound
#print axioms Rhombic.triangle
#print axioms Rhombic.scalarS_pos
#print axioms Rhombic.triangle_compact
#print axioms Rhombic.scalarF_continuous
#print axioms Rhombic.scalarF_positive_point
#print axioms Rhombic.exists_scalar_maximum
#print axioms Rhombic.scalar_positive_interior
#print axioms Rhombic.exists_positive_interior_maximum
#print axioms Rhombic.meanVariance
#print axioms Rhombic.meanVariance_pos
#print axioms Rhombic.untiltMass
#print axioms Rhombic.untiltMass_apply
#print axioms Rhombic.untiltDesign
#print axioms Rhombic.untilt_support
#print axioms Rhombic.untilt_information
#print axioms Rhombic.consolidate
#print axioms Rhombic.consolidate_sum
#print axioms Rhombic.consolidate_nonneg
#print axioms Rhombic.consolidate_support
#print axioms Rhombic.designOfFinite
#print axioms Rhombic.designOfFinite_information
#print axioms Rhombic.finite_enumeration
#print axioms Rhombic.diagonal_antipodes
#print axioms Rhombic.common_radius_rhombic
#print axioms Rhombic.variance_permutation
#print axioms Rhombic.variance_neg
#print axioms Rhombic.untilt_rhombic
#print axioms Rhombic.OrbitR3.Index
#print axioms Rhombic.OrbitR3.point
#print axioms Rhombic.OrbitR3.weight
#print axioms Rhombic.OrbitR3.weight_nonneg
#print axioms Rhombic.OrbitR3.weight_total
#print axioms Rhombic.OrbitR3.law
#print axioms Rhombic.OrbitR3.law_sum
#print axioms Rhombic.OrbitR3.consolidate_invariant
#print axioms Rhombic.OrbitR3.permPoint
#print axioms Rhombic.OrbitR3.negPoint
#print axioms Rhombic.OrbitR3.notBool
#print axioms Rhombic.OrbitR3.law_permutation
#print axioms Rhombic.OrbitR3.law_neg
#print axioms Rhombic.OrbitR3.law_radius
#print axioms Rhombic.OrbitR3.law_rhombic
#print axioms Rhombic.OrbitR3.avg
#print axioms Rhombic.OrbitR3.avg_perm
#print axioms Rhombic.OrbitR3.avg_seed
#print axioms Rhombic.OrbitR3.avg_first
#print axioms Rhombic.OrbitR3.avg_norm
#print axioms Rhombic.OrbitR3.avg_sum_sq
#print axioms Rhombic.OrbitR3.avg_sum
#print axioms Rhombic.OrbitR3.avg_one
#print axioms Rhombic.OrbitR3.balanced
#print axioms Rhombic.OrbitR3.seeds
#print axioms Rhombic.OrbitR3.step_sum
#print axioms Rhombic.OrbitR3.threshold_sum
#print axioms Rhombic.OrbitR3.balanced_sum
#print axioms Rhombic.OrbitR3.balanced_even
#print axioms Rhombic.OrbitR3.balanced_odd
#print axioms Rhombic.OrbitR3.seeds_abs
#print axioms Rhombic.OrbitR3.seeds_cube
#print axioms Rhombic.OrbitR3.seeds_norm
#print axioms Rhombic.OrbitR3.seeds_true_sum
#print axioms Rhombic.OrbitR3.avg_cross_equal
#print axioms Rhombic.OrbitR3.avg_diagonal
#print axioms Rhombic.OrbitR3.avg_cross_formula
#print axioms Rhombic.OrbitR3.avg_add
#print axioms Rhombic.OrbitR3.avg_const_mul
#print axioms Rhombic.OrbitR3.avg_const
#print axioms Rhombic.OrbitR3.equi
#print axioms Rhombic.OrbitR3.det_equi
#print axioms Rhombic.OrbitR3.det_option_block
#print axioms Rhombic.OrbitR3.untilt_law_attainment
#print axioms Rhombic.exists_rhombic_attaining_scalarF
#print axioms Rhombic.FeasibleScalarMaximaR3
#print axioms Rhombic.actual_global_of_feasible_scalar_maximum
#print axioms Rhombic.source_target_of_feasible_scalar_maxima
#print axioms Rhombic.expanded_source_target_of_feasible_scalar_maxima
#print axioms Rhombic.ApproxDesign.mk
#print axioms Rhombic.ApproxDesign.mass
#print axioms Rhombic.ApproxDesign.nonneg
#print axioms Rhombic.ApproxDesign.total
#print axioms Rhombic.ApproxDesign.cube
#print axioms Rhombic.psd_zero_diagonal_column
#print axioms Rhombic.psd_zero_diagonal_det
#print axioms Rhombic.hadamard_block_step
#print axioms Rhombic.OddFeasible.amgm_pow
#print axioms Rhombic.OddFeasible.formula_aux
#print axioms Rhombic.OddFeasible.scalarF_formula
#print axioms Rhombic.OddFeasible.scalarF_le_of
#print axioms Rhombic.OddFeasible.nonpos_numerator
#print axioms Rhombic.OddFeasible.pos_numerator
#print axioms Rhombic.OddFeasible.nonpos_step
#print axioms Rhombic.OddFeasible.pos_step
#print axioms Rhombic.OddFeasible.exists_feasible_max_of_half
#print axioms Rhombic.exists_rhombic_feasible_scalar_maximum
#print axioms Rhombic.OddFeasible.FeasibleScalarComponent
#print axioms Rhombic.OddFeasible.feasibleScalarComponent
#print axioms Rhombic.FinalR4.feasible_scalar_maxima
#print axioms Rhombic.FinalR4.source_target
#print axioms Rhombic.FinalR4.expanded_source_target
#print axioms Rhombic.FinalR4.literal_source_target

-- Literal definitions behind the final endpoint.
#print Rhombic.ApproxDesign
#print Rhombic.regressor
#print Rhombic.variance
#print Rhombic.information
#print Rhombic.Cone
#print Rhombic.SameDiagonal
#print Rhombic.RhombicDesign
#print Rhombic.SourceTarget
#print Rhombic.FeasibleScalarMaximaR3
#print Rhombic.triangle
#print Rhombic.scalarS
#print Rhombic.scalarF
#check @Rhombic.FinalR4.expanded_source_target
#check @Rhombic.FinalR4.literal_source_target
