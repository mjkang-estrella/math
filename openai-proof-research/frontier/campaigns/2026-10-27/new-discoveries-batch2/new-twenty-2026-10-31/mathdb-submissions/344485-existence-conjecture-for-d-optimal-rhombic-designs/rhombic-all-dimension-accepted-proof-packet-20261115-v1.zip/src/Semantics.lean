import Source
import Hadamard
import Mathlib.Algebra.Order.Chebyshev
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

noncomputable section
open scoped BigOperators
open Matrix
namespace Rhombic

theorem cone_coefficients {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) :
    0 ≤ d1-d2 ∧ 0 ≤ d1-d2+(K:ℝ)*d2 := by
  have hk1 : (1:ℝ) < K := by exact_mod_cast (show (1:ℕ) < K by omega)
  have hk : 0 < (K:ℝ)-1 := sub_pos.mpr hk1
  have hb := (div_le_iff₀ hk).mp hc.2.2.1
  constructor
  · linarith [hc.2.2.2]
  · nlinarith

theorem cone_moment_nonneg {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 r t : ℝ}
    (hc : Cone K d0 d1 d2) (hr : 0 ≤ r) (ht : 0 ≤ t) (htr : t ≤ K*r) :
    0 ≤ (d1-d2)*r+d2*t := by
  obtain ⟨ha,hc'⟩ := cone_coefficients hK hc
  by_cases hb : 0 ≤ d2
  · exact add_nonneg (mul_nonneg ha hr) (mul_nonneg hb ht)
  · have h := mul_le_mul_of_nonpos_left htr (le_of_not_ge hb)
    have h' := mul_nonneg hc' hr
    nlinarith

theorem sum_square_bound {K : ℕ} (x : Point K) :
    (∑ i, x i)^2 ≤ (K:ℝ)*(∑ i, x i^2) := by
  simpa using (sq_sum_le_card_mul_sum_sq (s := Finset.univ) (f := x))

theorem variance_ge_d0 {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (x : Point K) : d0 ≤ variance d0 d1 d2 x := by
  have hr : 0 ≤ ∑ i, x i ^ 2 := Finset.sum_nonneg (fun i _ => sq_nonneg (x i))
  have h := cone_moment_nonneg hK hc hr (sq_nonneg (∑ i, x i)) (sum_square_bound x)
  dsimp [variance]
  linarith

theorem variance_pos {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (x : Point K) : 0 < variance d0 d1 d2 x :=
  lt_of_lt_of_le hc.1 (variance_ge_d0 hK hc x)

theorem outer_psd {n : Type*} [Fintype n] (v : n → ℝ) :
    Matrix.PosSemidef (fun i j => v i * v j : Matrix n n ℝ) := by
  let B : Matrix PUnit.{1} n ℝ := fun _ i => v i
  have h := Matrix.posSemidef_conjTranspose_mul_self B
  have he : Bᴴ * B = Matrix.of (fun i j => v i * v j) := by
    ext i j
    rw [Matrix.mul_apply]
    simp only [Fintype.sum_unique]
    change star (v i) * v j = v i * v j
    simp
  rw [he] at h
  exact h

theorem finite_sum_psd {α n : Type*} [Fintype n] (s : Finset α)
    (M : α → Matrix n n ℝ) (h : ∀ x ∈ s, Matrix.PosSemidef (M x)) :
    (∑ x ∈ s, M x).PosSemidef := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using (Matrix.PosSemidef.zero : (0 : Matrix n n ℝ).PosSemidef)
  | @insert a s ha ih =>
    rw [Finset.sum_insert ha]
    exact (h a (by simp)).add (ih (fun x hx => h x (by simp [hx])))

theorem information_psd {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (ξ : ApproxDesign K) :
    (information d0 d1 d2 ξ).PosSemidef := by
  classical
  let M : Point K → Matrix (Option (Fin K)) (Option (Fin K)) ℝ := fun x => (ξ.mass x / variance d0 d1 d2 x) •
    (fun i j => regressor x i * regressor x j : Matrix (Option (Fin K)) (Option (Fin K)) ℝ)
  have h : ∀ x ∈ ξ.mass.support, Matrix.PosSemidef (M x) := by
    intro x _
    exact (outer_psd (regressor x)).smul (div_nonneg (ξ.nonneg x) (variance_pos hK hc x).le)
  have heq : information d0 d1 d2 ξ = ∑ x ∈ ξ.mass.support, M x := by
    ext i j
    rw [Matrix.sum_apply]
    simp only [information, Finsupp.sum]
    apply Finset.sum_congr rfl
    intro x _
    change ξ.mass x * regressor x i * regressor x j / variance d0 d1 d2 x =
      (ξ.mass x / variance d0 d1 d2 x) * (regressor x i * regressor x j)
    ring
  rw [heq]
  exact finite_sum_psd _ _ h

#print axioms cone_coefficients
#print axioms variance_pos
#print axioms information_psd
end Rhombic
