import OrbitSeedsR3
import Mathlib.Logic.Equiv.Fintype
noncomputable section
open scoped BigOperators
namespace Rhombic.OrbitR3

theorem avg_cross_equal {K : ℕ} (s : Bool → Point K) (l : ℝ)
    (i j u v : Fin K) (hij : i ≠ j) (huv : u ≠ v) :
    avg s l (fun x => x i * x j) = avg s l (fun x => x u * x v) := by
  let f : Bool → Fin K := fun b => if b then i else j
  let g : Bool → Fin K := fun b => if b then u else v
  have hf : Function.Injective f := by intro a b h; cases a <;> cases b <;> simp_all [f]
  have hg : Function.Injective g := by intro a b h; cases a <;> cases b <;> simp_all [g]
  obtain ⟨p,hp⟩ := Equiv.Perm.exists_extending_pair f g hf hg
  have hi : p i = u := by simpa [f,g] using hp true
  have hj : p j = v := by simpa [f,g] using hp false
  have h := avg_perm s l (fun x => x i*x j) p
  simpa [Function.comp_apply,hi,hj] using h.symm

theorem avg_diagonal (K : ℕ) (ρ l : ℝ) (i : Fin K) :
    avg (seeds K ρ) l (fun x => x i*x i) = ρ^2 := by
  have h : ∀ a : Index K, point (seeds K ρ) a i * point (seeds K ρ) a i = ρ^2 := by
    intro a
    have hs : seeds K ρ a.1 (a.2.1 i)^2 = ρ^2 := by
      cases a.1 with
      | true => rfl
      | false =>
        change (if (a.2.1 i).val < K/2 then ρ else -ρ)^2 = ρ^2
        split_ifs <;> simp
    dsimp [point]
    cases a.2.2 <;> simpa [pow_two] using hs
  simp only [avg,h]
  rw [← Finset.sum_mul, weight_total, one_mul]

theorem avg_cross_formula {K : ℕ} (hK : 2 ≤ K) (ρ l t : ℝ)
    (ht : avg (seeds K ρ) l (fun x => (∑ i, x i)^2) = t) (i j : Fin K) (hij : i ≠ j) :
    avg (seeds K ρ) l (fun x => x i*x j) =
      (t-(K:ℝ)*ρ^2)/((K:ℝ)*((K:ℝ)-1)) := by
  classical
  let c := avg (seeds K ρ) l (fun x => x i*x j)
  have he : ∀ u v : Fin K, avg (seeds K ρ) l (fun x => x u*x v) =
      (if u=v then ρ^2-c else 0)+c := by
    intro u v
    by_cases h : u=v
    · subst v; rw [avg_diagonal]; simp
    · rw [avg_cross_equal _ _ u v i j h hij]; simp [h,c]
  have hs : (∑ u : Fin K, ∑ v : Fin K, avg (seeds K ρ) l (fun x => x u*x v)) = t := by
    have ha : ∀ {ι : Type} [Fintype ι] (g : ι → Point K → ℝ),
        (∑ i, avg (seeds K ρ) l (g i)) = avg (seeds K ρ) l (fun x => ∑ i, g i x) := by
      intro ι _ g
      simp only [avg,Finset.mul_sum]
      exact Finset.sum_comm
    simp_rw [ha]
    convert ht using 1
    congr 1; ext x
    simp only [pow_two,Finset.sum_mul,Finset.mul_sum]
    exact Finset.sum_comm
  simp only [he,Finset.sum_add_distrib] at hs
  simp at hs
  have hk : (0:ℝ)<K := by exact_mod_cast (show 0<K by omega)
  have hk1 : (0:ℝ)<(K:ℝ)-1 := by
    have hh : (2:ℝ)≤K := by exact_mod_cast hK
    linarith
  apply (eq_div_iff (ne_of_gt (mul_pos hk hk1))).mpr
  dsimp [c] at hs ⊢
  nlinarith [hs]

theorem avg_add {K : ℕ} (s : Bool → Point K) (l : ℝ) (f g : Point K → ℝ) :
    avg s l (fun x => f x+g x) = avg s l f+avg s l g := by
  simp [avg,mul_add,Finset.sum_add_distrib]

theorem avg_const_mul {K : ℕ} (s : Bool → Point K) (l c : ℝ) (f : Point K → ℝ) :
    avg s l (fun x => c*f x) = c*avg s l f := by
  simp [avg,Finset.mul_sum,mul_left_comm]

theorem avg_const {K : ℕ} (s : Bool → Point K) (l c : ℝ) : avg s l (fun _ => c) = c := by
  simp only [avg,← Finset.sum_mul,weight_total,one_mul]

#print axioms avg_cross_equal
#print axioms avg_diagonal
#print axioms avg_cross_formula
#print axioms avg_add
#print axioms avg_const_mul
#print axioms avg_const
end Rhombic.OrbitR3
