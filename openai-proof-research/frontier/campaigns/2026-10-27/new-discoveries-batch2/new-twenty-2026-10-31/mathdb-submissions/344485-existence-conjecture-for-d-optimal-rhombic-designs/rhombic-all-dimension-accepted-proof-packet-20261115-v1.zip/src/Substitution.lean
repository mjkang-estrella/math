import Moments
noncomputable section
open scoped BigOperators
namespace Rhombic

def scalarS (d0 d1 d2 r t : ℝ) : ℝ := d0 + (d1-d2)*r+d2*t

def scalarF (K : ℕ) (d0 d1 d2 r t : ℝ) : ℝ :=
  (1 / scalarS d0 d1 d2 r t) * (t / ((K:ℝ)*scalarS d0 d1 d2 r t)) *
    ((r-t/(K:ℝ)) / (((K:ℝ)-1)*scalarS d0 d1 d2 r t))^(K-1)

theorem information_intercept {K : ℕ} (d0 d1 d2 : ℝ) (η : ApproxDesign K) :
    information d0 d1 d2 η none none = tiltA d0 d1 d2 η := by
  simp only [information, regressor, mul_one, tiltA, Finsupp.sum]

theorem tilt_weighted_sum {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) (g : Point K → ℝ) :
    tiltA d0 d1 d2 η * (∑ x ∈ η.mass.support, tiltQ d0 d1 d2 η x * g x) =
      ∑ x ∈ η.mass.support, η.mass x / variance d0 d1 d2 x * g x := by
  classical
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  dsimp [tiltQ]
  field_simp [ne_of_gt (tiltA_pos hK hc η)]

theorem information_slope_trace {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    (∑ i, information d0 d1 d2 η (some i) (some i)) =
      tiltA d0 d1 d2 η * tiltR d0 d1 d2 η := by
  classical
  rw [tiltR, tilt_weighted_sum hK hc]
  simp only [information, Finsupp.sum, regressor]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  ring

theorem information_slope_sum {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    (∑ i, ∑ j, information d0 d1 d2 η (some i) (some j)) =
      tiltA d0 d1 d2 η * tiltT d0 d1 d2 η := by
  classical
  rw [tiltT, tilt_weighted_sum hK hc]
  simp only [information, Finsupp.sum, regressor]
  trans ∑ x ∈ η.mass.support, ∑ i, ∑ j, η.mass x * x i * x j / variance d0 d1 d2 x
  · conv_lhs =>
      arg 2
      ext i
      rw [Finset.sum_comm]
    rw [Finset.sum_comm]
  ·
    apply Finset.sum_congr rfl
    intro x _
    simp only [pow_two, Finset.sum_mul, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    apply Finset.sum_congr rfl
    intro j _
    ring

theorem tiltA_eq_inv {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    tiltA d0 d1 d2 η = 1 / scalarS d0 d1 d2 (tiltR d0 d1 d2 η) (tiltT d0 d1 d2 η) := by
  have h := tilt_normalization hK hc η
  have hs : scalarS d0 d1 d2 (tiltR d0 d1 d2 η) (tiltT d0 d1 d2 η) ≠ 0 := by
    intro hz
    change tiltA d0 d1 d2 η * scalarS d0 d1 d2 (tiltR d0 d1 d2 η) (tiltT d0 d1 d2 η) = 1 at h
    rw [hz, mul_zero] at h
    norm_num at h
  apply (eq_div_iff hs).mpr
  exact h

theorem source_scalar_bound {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    (information d0 d1 d2 η).det ≤
      scalarF K d0 d1 d2 (tiltR d0 d1 d2 η) (tiltT d0 d1 d2 η) := by
  have h := source_global_bound K hK d0 d1 d2 hc η
  rw [information_intercept, information_slope_trace hK hc, information_slope_sum hK hc,
    tiltA_eq_inv hK hc] at h
  apply h.trans_eq
  dsimp [scalarF]
  simp only [div_eq_mul_inv, mul_inv_rev]
  congr 1
  · ring
  · congr 1
    ring

#print axioms information_intercept
#print axioms tilt_weighted_sum
#print axioms information_slope_trace
#print axioms information_slope_sum
#print axioms tiltA_eq_inv
#print axioms source_scalar_bound
end Rhombic
