import Untilt
noncomputable section
open scoped BigOperators
namespace Rhombic

def consolidate {ι : Type*} {K : ℕ} (s : Finset ι) (x : ι → Point K) (w : ι → ℝ) : Point K →₀ ℝ :=
  ∑ i ∈ s, Finsupp.single (x i) (w i)

theorem consolidate_sum {ι : Type*} {K : ℕ} (s : Finset ι) (x : ι → Point K)
    (w : ι → ℝ) (g : Point K → ℝ) :
    (consolidate s x w).sum (fun y v => v*g y) = ∑ i ∈ s, w i * g (x i) := by
  classical
  rw [consolidate, ← Finsupp.sum_finsetSum_index (by simp) (by intros; ring)]
  apply Finset.sum_congr rfl
  intro i _
  exact Finsupp.sum_single_index (by simp)

theorem consolidate_nonneg {ι : Type*} {K : ℕ} (s : Finset ι) (x : ι → Point K)
    (w : ι → ℝ) (hw : ∀ i ∈ s, 0 ≤ w i) (y : Point K) :
    0 ≤ consolidate s x w y := by
  classical
  simp only [consolidate, Finsupp.finsetSum_apply, Finsupp.single_apply]
  exact Finset.sum_nonneg (fun i hi => by split_ifs <;> simp_all)

theorem consolidate_support {ι : Type*} {K : ℕ} (s : Finset ι) (x : ι → Point K)
    (w : ι → ℝ) {y : Point K} (hy : y ∈ (consolidate s x w).support) :
    ∃ i ∈ s, y = x i := by
  classical
  by_contra hn
  have he : consolidate s x w y = 0 := by
    simp only [consolidate, Finsupp.finsetSum_apply, Finsupp.single_apply]
    apply Finset.sum_eq_zero
    intro i hi
    rw [ite_eq_right]
    intro h
    exact hn ⟨i,hi,h.symm⟩
  exact Finsupp.mem_support_iff.mp hy he

def designOfFinite {ι : Type*} {K : ℕ} (s : Finset ι) (x : ι → Point K)
    (w : ι → ℝ) (hw : ∀ i ∈ s, 0 ≤ w i) (ht : ∑ i ∈ s, w i = 1)
    (hx : ∀ i ∈ s, ∀ j, -1 ≤ x i j ∧ x i j ≤ 1) : ApproxDesign K where
  mass := consolidate s x w
  nonneg := consolidate_nonneg s x w hw
  total := by simpa using (consolidate_sum s x w (fun _ => 1)).trans (by simpa using ht)
  cube := by
    intro y hy
    obtain ⟨i,hi,rfl⟩ := consolidate_support s x w hy
    exact hx i hi

theorem designOfFinite_information {ι : Type*} {K : ℕ} (s : Finset ι) (x : ι → Point K)
    (w : ι → ℝ) (hw : ∀ i ∈ s, 0 ≤ w i) (ht : ∑ i ∈ s, w i = 1)
    (hx : ∀ i ∈ s, ∀ j, -1 ≤ x i j ∧ x i j ≤ 1) (d0 d1 d2 : ℝ) (a b : Option (Fin K)) :
    information d0 d1 d2 (designOfFinite s x w hw ht hx) a b =
      ∑ i ∈ s, w i * regressor (x i) a * regressor (x i) b / variance d0 d1 d2 (x i) := by
  have h := consolidate_sum s x w (fun y => regressor y a * regressor y b / variance d0 d1 d2 y)
  simpa only [information, designOfFinite, mul_div_assoc, mul_assoc] using h

theorem finite_enumeration {K : ℕ} (η : ApproxDesign K) :
    consolidate η.mass.support (fun x => x) (fun x => η.mass x) = η.mass := by
  classical
  exact Finsupp.sum_single η.mass

#print axioms consolidate
#print axioms consolidate_sum
#print axioms consolidate_nonneg
#print axioms consolidate_support
#print axioms designOfFinite
#print axioms designOfFinite_information
#print axioms finite_enumeration
end Rhombic
