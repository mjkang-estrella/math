import Finite
noncomputable section
open scoped BigOperators
namespace Rhombic

theorem diagonal_antipodes {K : ℕ} (hK : 0 < K) {x y : Point K} {ρ : ℝ}
    (hρ : 0 < ρ) (hx : ∀ i, |x i| = ρ) (hy : ∀ i, |y i| = ρ)
    (hxy : SameDiagonal x y) : y = x ∨ y = -x := by
  obtain ⟨c,hc,rfl⟩ := hxy
  let i : Fin K := ⟨0,hK⟩
  have h : |c| * ρ = ρ := by simpa only [Pi.smul_apply, smul_eq_mul, abs_mul, hx] using hy i
  have he : |c| = |(1:ℝ)| := by rw [abs_one]; nlinarith
  rcases abs_eq_abs.mp he with h | h
  · left; simp [h]
  · right; simp [h]

theorem common_radius_rhombic {K : ℕ} (hK : 0 < K) (ξ : ApproxDesign K)
    (hp : ∀ p : Equiv.Perm (Fin K), ∀ x, ξ.mass (x ∘ p) = ξ.mass x)
    (hn : ∀ x, ξ.mass (-x) = ξ.mass x) {ρ : ℝ} (hρ : 0 < ρ)
    (hr : ∀ x ∈ ξ.mass.support, ∀ i, |x i| = ρ) : RhombicDesign ξ := by
  refine ⟨hp,hn,fun x hx => ⟨ρ,hρ,hr x hx⟩,?_⟩
  intro x hx y hy hd
  exact diagonal_antipodes hK hρ (hr x hx) (hr y hy) hd

theorem variance_permutation {K : ℕ} (d0 d1 d2 : ℝ) (x : Point K)
    (p : Equiv.Perm (Fin K)) : variance d0 d1 d2 (x ∘ p) = variance d0 d1 d2 x := by
  unfold variance
  simp only [Function.comp_apply]
  rw [Equiv.sum_comp p (fun i => x i ^ 2), Equiv.sum_comp p x]

theorem variance_neg {K : ℕ} (d0 d1 d2 : ℝ) (x : Point K) :
    variance d0 d1 d2 (-x) = variance d0 d1 d2 x := by
  simp [variance, Finset.sum_neg_distrib]

theorem untilt_rhombic {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (q : ApproxDesign K) (hq : RhombicDesign q) :
    RhombicDesign (untiltDesign hK hc q) := by
  refine ⟨?_,?_,?_,?_⟩
  · intro p x
    change untiltMass d0 d1 d2 q (x ∘ p) = untiltMass d0 d1 d2 q x
    rw [untiltMass_apply,untiltMass_apply,hq.1 p x,variance_permutation]
  · intro x
    change untiltMass d0 d1 d2 q (-x) = untiltMass d0 d1 d2 q x
    rw [untiltMass_apply,untiltMass_apply,hq.2.1 x,variance_neg]
  · rw [untilt_support hK hc]
    exact hq.2.2.1
  · rw [untilt_support hK hc]
    exact hq.2.2.2

#print axioms diagonal_antipodes
#print axioms common_radius_rhombic
#print axioms variance_permutation
#print axioms variance_neg
#print axioms untilt_rhombic
end Rhombic
