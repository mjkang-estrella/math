import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Algebra.Order.Star.Real
import Mathlib.LinearAlgebra.Matrix.SchurComplement
import Mathlib.Data.Fintype.Option
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

noncomputable section
open scoped BigOperators
open Matrix
namespace Rhombic

 theorem psd_zero_diagonal_column {n : Type*} [Fintype n] [DecidableEq n]
    {M : Matrix n n ℝ} (hM : M.PosSemidef) (j : n) (hj : M j j = 0) :
    ∀ i, M i j = 0 := by
  have hq : star (Pi.single j (1 : ℝ)) ⬝ᵥ M *ᵥ Pi.single j 1 = 0 := by
    simpa using hj
  have hz := hM.dotProduct_mulVec_zero_iff.mp hq
  intro i
  simpa using congrFun hz i

 theorem psd_zero_diagonal_det {n : Type*} [Fintype n] [DecidableEq n]
    {M : Matrix n n ℝ} (hM : M.PosSemidef) (j : n) (hj : M j j = 0) :
    M.det = 0 := by
  exact det_eq_zero_of_column_eq_zero j (psd_zero_diagonal_column hM j hj)

 theorem hadamard_block_step {n : Type*} [Fintype n] [DecidableEq n]
    (ih : ∀ S : Matrix n n ℝ, S.PosSemidef → S.det ≤ ∏ i, S i i)
    (a : ℝ) (b : Matrix PUnit n ℝ) (D : Matrix n n ℝ)
    (hM : (fromBlocks (diagonal (fun _ : PUnit => a)) b bᴴ D).PosSemidef) :
    (fromBlocks (diagonal (fun _ : PUnit => a)) b bᴴ D).det ≤
      a * ∏ i, D i i := by
  have ha : 0 ≤ a := by simpa using hM.diag_nonneg (i := Sum.inl PUnit.unit)
  by_cases haz : a = 0
  · have hz := psd_zero_diagonal_det hM (Sum.inl PUnit.unit) (by simpa using haz)
    rw [hz, haz]
    simp
  · have hap : 0 < a := lt_of_le_of_ne ha (Ne.symm haz)
    let A : Matrix PUnit PUnit ℝ := diagonal (fun _ => a)
    have hA : A.PosDef := by
      apply Matrix.posDef_diagonal_iff.mpr
      intro i
      exact hap
    let : Invertible A := invertibleOfIsUnitDet A (by simpa [A] using (isUnit_iff_ne_zero.mpr haz))
    have hinv : A⁻¹ = diagonal (fun _ : PUnit => a⁻¹) := by
      apply Matrix.inv_eq_left_inv
      ext i j
      simp [A, haz]
    have hS : (D - bᴴ * A⁻¹ * b).PosSemidef :=
      (Matrix.PosDef.fromBlocks₁₁ b D hA).mp hM
    have hdiag : ∀ i, (D - bᴴ * A⁻¹ * b) i i ≤ D i i := by
      intro i
      simp only [Matrix.sub_apply]
      apply sub_le_self
      simp only [hinv, Matrix.mul_apply, Fintype.sum_unique,
        Matrix.conjTranspose_apply, star_trivial, Matrix.diagonal_apply_eq]
      convert mul_nonneg (sq_nonneg (b PUnit.unit i)) (inv_nonneg.mpr ha) using 1
      ring
    have hprod : (∏ i, (D - bᴴ * A⁻¹ * b) i i) ≤ ∏ i, D i i := by
      apply Finset.prod_le_prod₀
      · intro i _
        exact hS.diag_nonneg
      · intro i _
        exact hdiag i
    calc
      (fromBlocks A b bᴴ D).det = a * (D - bᴴ * A⁻¹ * b).det := by
        rw [det_fromBlocks₁₁, invOf_eq_nonsing_inv]
        simp [A]
      _ ≤ a * ∏ i, (D - bᴴ * A⁻¹ * b) i i := mul_le_mul_of_nonneg_left (ih _ hS) ha
      _ ≤ a * ∏ i, D i i := mul_le_mul_of_nonneg_left hprod ha

universe u
theorem psd_hadamard (n : Type u) [Fintype n] [DecidableEq n]
    (M : Matrix n n ℝ) (hM : M.PosSemidef) : M.det ≤ ∏ i, M i i := by
  classical
  let P := fun (α : Type u) [Fintype α] =>
    ∀ A : Matrix α α ℝ, A.PosSemidef → A.det ≤ ∏ i, A i i
  have h : P n := by
    apply Fintype.induction_empty_option (P := P)
    · intro α β _ e ih A hA
      let : Fintype α := Fintype.ofEquiv β e.symm
      have hb := ih (A.submatrix e e) (hA.submatrix e)
      rw [← e.prod_comp (fun i => A i i)]
      simpa only [Matrix.det_submatrix_equiv_self, Matrix.submatrix_apply] using hb
    · intro A _
      simp
    · intro α _ ih A hA
      let e : PUnit.{1} ⊕ α ≃ Option α :=
        (Equiv.sumComm PUnit.{1} α).trans (Equiv.optionEquivSumPUnit α).symm
      let T := A.submatrix e e
      have hT := hA.submatrix e
      let b : Matrix PUnit.{1} α ℝ := fun _ i => A none (some i)
      let D : Matrix α α ℝ := fun i j => A (some i) (some j)
      have ht : T = fromBlocks (diagonal (fun _ : PUnit.{1} => A none none)) b bᴴ D := by
        ext i j
        cases i with
        | inl i => cases j <;> simp [T, e, b, D, Matrix.fromBlocks]
        | inr i => cases j with
          | inl j =>
            change A (some i) none = star (A none (some i))
            simpa using (hA.isHermitian.apply (some i) none).symm
          | inr j => simp [T, e, b, D, Matrix.fromBlocks]
      have hb := hadamard_block_step ih (A none none) b D (ht ▸ hT)
      rw [← ht, Matrix.det_submatrix_equiv_self] at hb
      simp only [D, Fintype.prod_option] at hb ⊢
      convert! hb
  convert! h M hM

#print axioms psd_zero_diagonal_column
#print axioms psd_zero_diagonal_det
#print axioms hadamard_block_step
#print axioms psd_hadamard
end Rhombic
