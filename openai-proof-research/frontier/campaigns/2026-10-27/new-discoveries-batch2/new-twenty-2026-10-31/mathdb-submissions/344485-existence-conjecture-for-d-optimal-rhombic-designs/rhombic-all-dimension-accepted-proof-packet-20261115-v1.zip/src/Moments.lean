import SourceBound

noncomputable section
open scoped BigOperators
namespace Rhombic

def tiltA {K : ℕ} (d0 d1 d2 : ℝ) (η : ApproxDesign K) : ℝ :=
  ∑ x ∈ η.mass.support, η.mass x / variance d0 d1 d2 x

def tiltQ {K : ℕ} (d0 d1 d2 : ℝ) (η : ApproxDesign K) (x : Point K) : ℝ :=
  (η.mass x / variance d0 d1 d2 x) / tiltA d0 d1 d2 η

def tiltR {K : ℕ} (d0 d1 d2 : ℝ) (η : ApproxDesign K) : ℝ :=
  ∑ x ∈ η.mass.support, tiltQ d0 d1 d2 η x * ∑ i, x i ^ 2

def tiltT {K : ℕ} (d0 d1 d2 : ℝ) (η : ApproxDesign K) : ℝ :=
  ∑ x ∈ η.mass.support, tiltQ d0 d1 d2 η x * (∑ i, x i)^2

theorem tiltA_pos {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) : 0 < tiltA d0 d1 d2 η := by
  classical
  have hn : ∀ x ∈ η.mass.support, 0 ≤ η.mass x := fun x _ => η.nonneg x
  have hp : 0 < ∑ x ∈ η.mass.support, η.mass x := by
    have ht : (∑ x ∈ η.mass.support, η.mass x) = 1 := η.total
    rw [ht]
    norm_num
  obtain ⟨x,hx,hp⟩ := (Finset.sum_pos_iff_of_nonneg hn).mp hp
  apply (Finset.sum_pos_iff_of_nonneg (fun x _ => div_nonneg (η.nonneg x) (variance_pos hK hc x).le)).mpr
  exact ⟨x,hx,div_pos hp (variance_pos hK hc x)⟩

theorem tiltQ_nonneg {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) (x : Point K) :
    0 ≤ tiltQ d0 d1 d2 η x :=
  div_nonneg (div_nonneg (η.nonneg x) (variance_pos hK hc x).le) (tiltA_pos hK hc η).le

theorem tiltQ_total {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    (∑ x ∈ η.mass.support, tiltQ d0 d1 d2 η x) = 1 := by
  classical
  simp only [tiltQ, ← Finset.sum_div]
  exact div_self (ne_of_gt (tiltA_pos hK hc η))

theorem cube_norm_bound {K : ℕ} (η : ApproxDesign K) (x : Point K)
    (hx : x ∈ η.mass.support) : (∑ i, x i ^ 2) ≤ (K:ℝ) := by
  have h : ∀ i, x i ^ 2 ≤ (1:ℝ) := by
    intro i
    obtain ⟨hl,hu⟩ := η.cube x hx i
    nlinarith
  simpa using Finset.sum_le_sum (s := Finset.univ) (fun i _ => h i)

theorem tilted_triangle {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    0 ≤ tiltR d0 d1 d2 η ∧ tiltR d0 d1 d2 η ≤ (K:ℝ) ∧
    0 ≤ tiltT d0 d1 d2 η ∧ tiltT d0 d1 d2 η ≤ (K:ℝ)*tiltR d0 d1 d2 η := by
  classical
  have hq := tiltQ_nonneg hK hc η
  have htot := tiltQ_total hK hc η
  refine ⟨Finset.sum_nonneg (fun x _ => mul_nonneg (hq x) (Finset.sum_nonneg (fun i _ => sq_nonneg (x i)))), ?_,
    Finset.sum_nonneg (fun x _ => mul_nonneg (hq x) (sq_nonneg _)), ?_⟩
  · calc
      tiltR d0 d1 d2 η ≤ ∑ x ∈ η.mass.support, tiltQ d0 d1 d2 η x * (K:ℝ) :=
        Finset.sum_le_sum (fun x hx => mul_le_mul_of_nonneg_left (cube_norm_bound η x hx) (hq x))
      _ = (K:ℝ) := by rw [← Finset.sum_mul, htot, one_mul]
  · dsimp [tiltT, tiltR]
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro x _
    have h := mul_le_mul_of_nonneg_left (sum_square_bound x) (hq x)
    nlinarith

theorem tilt_normalization {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    tiltA d0 d1 d2 η * (d0 + (d1-d2)*tiltR d0 d1 d2 η + d2*tiltT d0 d1 d2 η) = 1 := by
  classical
  have ha := ne_of_gt (tiltA_pos hK hc η)
  have hq := tiltQ_total hK hc η
  have hv : ∀ x, tiltA d0 d1 d2 η * tiltQ d0 d1 d2 η x * variance d0 d1 d2 x = η.mass x := by
    intro x
    dsimp [tiltQ]
    field_simp [ha, ne_of_gt (variance_pos hK hc x)]
  calc
    _ = ∑ x ∈ η.mass.support, tiltA d0 d1 d2 η * tiltQ d0 d1 d2 η x * variance d0 d1 d2 x := by
      have hsum : (∑ x ∈ η.mass.support, tiltQ d0 d1 d2 η x * variance d0 d1 d2 x) =
          d0 + (d1-d2)*tiltR d0 d1 d2 η + d2*tiltT d0 d1 d2 η := by
        simp only [variance, mul_add, Finset.sum_add_distrib]
        simp_rw [mul_comm (tiltQ d0 d1 d2 η _) d0, mul_left_comm (tiltQ d0 d1 d2 η _) (d1-d2),
          mul_left_comm (tiltQ d0 d1 d2 η _) d2]
        rw [← Finset.mul_sum, ← Finset.mul_sum, ← Finset.mul_sum, hq, mul_one]
        rfl
      rw [← hsum, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x _
      ring
    _ = ∑ x ∈ η.mass.support, η.mass x := Finset.sum_congr rfl (fun x _ => hv x)
    _ = 1 := η.total

#print axioms tiltA_pos
#print axioms tiltQ_nonneg
#print axioms tiltQ_total
#print axioms cube_norm_bound
#print axioms tilted_triangle
#print axioms tilt_normalization
end Rhombic
