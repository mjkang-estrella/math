import Substitution
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Analysis.Calculus.Deriv.MeanValue
noncomputable section
open scoped BigOperators
namespace Rhombic

def triangle (K : ℕ) : Set (ℝ × ℝ) :=
  {z | 0 ≤ z.1 ∧ z.1 ≤ (K:ℝ) ∧ 0 ≤ z.2 ∧ z.2 ≤ (K:ℝ)*z.1}

theorem scalarS_pos {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) {z : ℝ × ℝ} (hz : z ∈ triangle K) :
    0 < scalarS d0 d1 d2 z.1 z.2 := by
  have hn := cone_moment_nonneg hK hc hz.1 hz.2.2.1 hz.2.2.2
  dsimp [scalarS]
  linarith [hc.1]

theorem triangle_compact (K : ℕ) : IsCompact (triangle K) := by
  have hc : IsClosed (triangle K) := by
    apply IsClosed.inter
    · exact isClosed_le continuous_const continuous_fst
    · apply IsClosed.inter
      · exact isClosed_le continuous_fst continuous_const
      · apply IsClosed.inter
        · exact isClosed_le continuous_const continuous_snd
        · exact isClosed_le continuous_snd (continuous_const.mul continuous_fst)
  apply IsCompact.of_isClosed_subset (isCompact_Icc : IsCompact (Set.Icc (0,0) ((K:ℝ),(K:ℝ)^2))) hc
  intro z hz
  exact ⟨⟨hz.1,hz.2.2.1⟩,⟨hz.2.1,by nlinarith [hz.2.2.2, mul_le_mul_of_nonneg_left hz.2.1 (show (0:ℝ) ≤ K by positivity)]⟩⟩

theorem scalarF_continuous {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) : ContinuousOn (fun z : ℝ × ℝ => scalarF K d0 d1 d2 z.1 z.2) (triangle K) := by
  have hs : Continuous (fun z : ℝ × ℝ => scalarS d0 d1 d2 z.1 z.2) := by
    unfold scalarS
    fun_prop
  have hk : (K:ℝ) ≠ 0 := by exact_mod_cast (show K ≠ 0 by omega)
  have hk1 : (K:ℝ)-1 ≠ 0 := by
    have h : (1:ℝ) < K := by exact_mod_cast (show 1 < K by omega)
    linarith
  unfold scalarF
  apply ContinuousOn.mul
  · apply ContinuousOn.mul
    · exact continuousOn_const.div hs.continuousOn (fun z hz => ne_of_gt (scalarS_pos hK hc hz))
    · exact continuous_snd.continuousOn.div (continuous_const.mul hs).continuousOn
        (fun z hz => mul_ne_zero hk (ne_of_gt (scalarS_pos hK hc hz)))
  · apply ContinuousOn.pow
    exact (continuous_fst.sub (continuous_snd.div_const _)).continuousOn.div
      (continuous_const.mul hs).continuousOn
      (fun z hz => mul_ne_zero hk1 (ne_of_gt (scalarS_pos hK hc hz)))

theorem scalarF_positive_point {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) :
    (1,1) ∈ triangle K ∧ 0 < scalarF K d0 d1 d2 1 1 := by
  have hk : (1:ℝ) < K := by exact_mod_cast (show 1 < K by omega)
  have hz : (1,1) ∈ triangle K := by
    change 0 ≤ (1:ℝ) ∧ (1:ℝ) ≤ (K:ℝ) ∧ 0 ≤ (1:ℝ) ∧ 1 ≤ (K:ℝ)*1
    norm_num
    linarith
  refine ⟨hz, ?_⟩
  have hs := scalarS_pos hK hc hz
  have hsub : 0 < 1-1/(K:ℝ) := by
    have hdiv : 1/(K:ℝ) < 1 := (div_lt_one (by linarith)).mpr hk
    linarith
  unfold scalarF
  exact mul_pos (mul_pos (one_div_pos.mpr hs) (div_pos zero_lt_one (mul_pos (by linarith) hs)))
    (pow_pos (div_pos hsub (mul_pos (by linarith) hs)) _)

theorem exists_scalar_maximum {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) :
    ∃ z ∈ triangle K, 0 < scalarF K d0 d1 d2 z.1 z.2 ∧
      ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 z.1 z.2 := by
  obtain ⟨hz,hp⟩ := scalarF_positive_point hK hc
  obtain ⟨z,hz',hm⟩ := (triangle_compact K).exists_isMaxOn ⟨(1,1),hz⟩ (scalarF_continuous hK hc)
  exact ⟨z,hz',lt_of_lt_of_le hp (hm hz),fun y hy => hm hy⟩

#print axioms scalarS_pos
#print axioms triangle_compact
#print axioms scalarF_continuous
#print axioms scalarF_positive_point
#print axioms exists_scalar_maximum
end Rhombic
