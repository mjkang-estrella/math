import OrbitDetR3
noncomputable section
open scoped BigOperators
namespace Rhombic.OrbitR3

theorem untilt_law_attainment {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 r t ρ l : ℝ}
    (hc : Cone K d0 d1 d2) (hr : 0 < r) (hrK : r ≤ (K:ℝ))
    (ht : 0 < t) (htr : t < (K:ℝ)*r)
    (hρ : 0 < ρ) (hρ1 : ρ ≤ 1) (hl : 0 ≤ l) (hl1 : l ≤ 1)
    (hR : (K:ℝ)*ρ^2 = r)
    (hT : avg (seeds K ρ) l (fun x => (∑ i, x i)^2) = t) :
    ∃ ξ : ApproxDesign K, RhombicDesign ξ ∧
      (information d0 d1 d2 ξ).det = scalarF K d0 d1 d2 r t := by
  classical
  let v := seeds K ρ
  let hv := seeds_cube K hρ.le hρ1
  let q := law v l hl hl1 hv
  let ξ := untiltDesign hK hc q
  have hq : RhombicDesign q := law_rhombic (by omega) v l hl hl1 hv hρ (seeds_abs K hρ.le)
  refine ⟨ξ,untilt_rhombic hK hc q hq,?_⟩
  have hk : (0:ℝ)<K := by exact_mod_cast (show 0<K by omega)
  have hk1 : (0:ℝ)<(K:ℝ)-1 := by
    have hh : (2:ℝ)≤K := by exact_mod_cast hK
    linarith
  let S := scalarS d0 d1 d2 r t
  have hS : 0 < S := scalarS_pos hK hc (z := (r,t)) ⟨hr.le,hrK,ht.le,htr.le⟩
  have hm : meanVariance d0 d1 d2 q = S := by
    change q.mass.sum (fun x w => w*variance d0 d1 d2 x) = S
    rw [law_sum]
    change avg v l (fun x => d0+(d1-d2)*(∑ i,x i^2)+d2*(∑ i,x i)^2) = S
    rw [avg_add,avg_add,avg_const,avg_const_mul,avg_const_mul]
    change d0+(d1-d2)*avg (seeds K ρ) l (fun x => ∑ i,x i^2)+
      d2*avg (seeds K ρ) l (fun x => (∑ i,x i)^2) = S
    rw [avg_norm,seeds_norm,seeds_norm,hT]
    dsimp [S,scalarS]
    rw [hR]
    ring
  have hi : ∀ i j, information d0 d1 d2 ξ i j =
      avg v l (fun x => regressor x i*regressor x j)/S := by
    intro i j
    rw [untilt_information,hm]
    have he := law_sum v l hl hl1 hv (fun x => regressor x i*regressor x j)
    simpa only [Finsupp.sum,mul_assoc,q,avg] using congrArg (fun z : ℝ => z/S) he
  let c := (t-(K:ℝ)*ρ^2)/((K:ℝ)*((K:ℝ)-1))
  let a := (ρ^2-c)/S
  let b := c/S
  have hca : c*((K:ℝ)*((K:ℝ)-1)) = t-(K:ℝ)*ρ^2 := by
    dsimp [c]; exact div_mul_cancel₀ _ (ne_of_gt (mul_pos hk hk1))
  have haeq : a = (r-t/(K:ℝ))/(((K:ℝ)-1)*S) := by
    dsimp [a]
    field_simp
    nlinarith [hca,hR]
  have hbeq : a+(K:ℝ)*b = t/((K:ℝ)*S) := by
    dsimp [a,b]
    field_simp
    nlinarith [hca]
  have hap : 0 < a := by
    rw [haeq]
    apply div_pos
    · have hh := (div_lt_iff₀ hk).mpr (by simpa [mul_comm] using htr)
      linarith
    · exact mul_pos hk1 hS
  have hd := det_option_block (information d0 d1 d2 ξ) (1/S) a b (by omega) (ne_of_gt hap)
    (by rw [hi]; simpa [regressor] using congrArg (fun z : ℝ => z/S) (avg_one v l))
    (by intro i; rw [hi]; simpa [regressor] using congrArg (fun z : ℝ => z/S) (avg_first v l i))
    (by intro i; rw [hi]; simpa [regressor] using congrArg (fun z : ℝ => z/S) (avg_first v l i))
    (by
      intro i j
      rw [hi]
      change avg (seeds K ρ) l (fun x => x i*x j)/S = equi K a b i j
      by_cases hij : i=j
      · subst j
        rw [avg_diagonal]
        simp only [equi,ite_true]
        dsimp [a,b]; ring
      · rw [avg_cross_formula hK ρ l t hT i j hij]
        simp [equi,hij,a,b,c])
  rw [hd,hbeq,haeq]
  rfl

#print axioms untilt_law_attainment
end Rhombic.OrbitR3
