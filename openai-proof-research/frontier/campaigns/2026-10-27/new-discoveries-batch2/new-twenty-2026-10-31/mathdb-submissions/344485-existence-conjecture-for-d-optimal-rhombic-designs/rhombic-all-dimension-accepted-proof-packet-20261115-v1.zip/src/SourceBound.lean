import Sharp

noncomputable section
open scoped BigOperators
namespace Rhombic

theorem source_global_bound (K : ℕ) (hK : 2 ≤ K) (d0 d1 d2 : ℝ)
    (hc : Cone K d0 d1 d2) (η : ApproxDesign K) :
    (information d0 d1 d2 η).det ≤ information d0 d1 d2 η none none *
      ((∑ j, ∑ k, information d0 d1 d2 η (some j) (some k))/(K:ℝ)) *
      (((∑ j, information d0 d1 d2 η (some j) (some j)) -
        (∑ j, ∑ k, information d0 d1 d2 η (some j) (some k))/(K:ℝ)) /
          ((K:ℝ)-1))^(K-1) :=
  sharp_psd_bound K hK _ (information_psd hK hc η)

-- Literal expanded existential obligation: a proposition, deliberately not a theorem.
-- The arbitrary finite real-mass competitor quantifier is unchanged.
def ExpandedSourceTarget : Prop :=
  ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ,
    0 < d0 → 0 < d1 → -d1/((K:ℝ)-1) ≤ d2 → d2 ≤ d1 →
    (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
    ∃ ξ : ApproxDesign K,
      (∀ p : Equiv.Perm (Fin K), ∀ x, ξ.mass (x ∘ p) = ξ.mass x) ∧
      (∀ x, ξ.mass (-x) = ξ.mass x) ∧
      (∀ x ∈ ξ.mass.support, ∃ ρ : ℝ, 0 < ρ ∧ ∀ i, |x i| = ρ) ∧
      (∀ x ∈ ξ.mass.support, ∀ y ∈ ξ.mass.support,
        (∃ c : ℝ, c ≠ 0 ∧ y = c • x) → y = x ∨ y = -x) ∧
      ∀ η : ApproxDesign K,
        (information d0 d1 d2 η).det ≤ (information d0 d1 d2 ξ).det

theorem target_expansion : SourceTarget ↔ ExpandedSourceTarget := by
  unfold SourceTarget ExpandedSourceTarget Cone RhombicDesign SameDiagonal
  constructor
  · intro h K hK d0 d1 d2 h0 h1 hl hu hr
    simpa only [and_assoc] using h K hK d0 d1 d2 ⟨h0,h1,hl,hu⟩ hr
  · intro h K hK d0 d1 d2 hc hr
    simpa only [and_assoc] using h K hK d0 d1 d2 hc.1 hc.2.1 hc.2.2.1 hc.2.2.2 hr

#print axioms source_global_bound
#print axioms target_expansion
end Rhombic
