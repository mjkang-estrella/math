import FinalAuditR4
import Lean
noncomputable section
open scoped BigOperators
namespace IndependentAudit

theorem expanded_actual :
    ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ,
      (0 < d0 ∧ 0 < d1 ∧ -d1/((K:ℝ)-1) ≤ d2 ∧ d2 ≤ d1) →
      (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
      ∃ w : (Fin K → ℝ) →₀ ℝ,
        (∀ x, 0 ≤ w x) ∧
        w.sum (fun _ a => a) = 1 ∧
        (∀ x ∈ w.support, ∀ i, -1 ≤ x i ∧ x i ≤ 1) ∧
        (∀ p : Equiv.Perm (Fin K), ∀ x, w (x ∘ p) = w x) ∧
        (∀ x, w (-x) = w x) ∧
        (∀ x ∈ w.support, ∃ ρ : ℝ, 0 < ρ ∧ ∀ i, |x i| = ρ) ∧
        (∀ x ∈ w.support, ∀ y ∈ w.support,
          (∃ c : ℝ, c ≠ 0 ∧ y = c • x) → y = x ∨ y = -x) ∧
        ∀ u : (Fin K → ℝ) →₀ ℝ,
          (∀ x, 0 ≤ u x) → u.sum (fun _ a => a) = 1 →
          (∀ x ∈ u.support, ∀ i, -1 ≤ x i ∧ x i ≤ 1) →
          Matrix.det ((fun i j => u.sum (fun x a =>
            a * (match i with | none => 1 | some k => x k) *
                (match j with | none => 1 | some k => x k) /
              (d0 + (d1-d2) * (∑ k, x k ^ 2) + d2 * (∑ k, x k) ^ 2))) :
            Option (Fin K) → Option (Fin K) → ℝ) ≤
          Matrix.det ((fun i j => w.sum (fun x a =>
            a * (match i with | none => 1 | some k => x k) *
                (match j with | none => 1 | some k => x k) /
              (d0 + (d1-d2) * (∑ k, x k ^ 2) + d2 * (∑ k, x k) ^ 2))) :
            Option (Fin K) → Option (Fin K) → ℝ) := by
  intro K hK d0 d1 d2 hc hp
  obtain ⟨ξ, hperm, hneg, hdiag, hpair, hmax⟩ :=
    Rhombic.FinalR4.literal_source_target K hK d0 d1 d2 hc hp
  refine ⟨ξ.mass, ξ.nonneg, ξ.total, ξ.cube, hperm, hneg, hdiag, hpair, ?_⟩
  intro u hu ht hcub
  exact hmax ⟨u, hu, ht, hcub⟩

theorem admissible_two :
    (0 < (1:ℝ) ∧ 0 < (1:ℝ) ∧ -(1:ℝ)/((2:ℝ)-1) ≤ 0 ∧ (0:ℝ) ≤ 1) ∧ Even (2:ℕ) := by
  constructor
  · norm_num
  · exact ⟨1, rfl⟩

#print expanded_actual
#print axioms expanded_actual
#print axioms admissible_two
end IndependentAudit

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for name in env.header.moduleNames do
    logInfo m!"PROVIDER_MODULE|{name}"
  for (name, _) in env.constants.toList do
    let s := name.toString
    if s.startsWith "Rhombic." || s.startsWith "IndependentAudit." ||
       (s.startsWith "_private.Source." || s.startsWith "_private.Hadamard." || s.startsWith "_private.Semantics." || s.startsWith "_private.Global." || s.startsWith "_private.Basis." || s.startsWith "_private.MomentBound." || s.startsWith "_private.Sharp." || s.startsWith "_private.SourceBound." || s.startsWith "_private.Audit." || s.startsWith "_private.Moments." || s.startsWith "_private.Substitution." || s.startsWith "_private.Scalar." || s.startsWith "_private.Boundary." || s.startsWith "_private.Untilt." || s.startsWith "_private.Finite." || s.startsWith "_private.Geometry." || s.startsWith "_private.FinalAudit." || s.startsWith "_private.OrbitAverageR3." || s.startsWith "_private.OrbitSymmetryR3." || s.startsWith "_private.OrbitExpectationR3." || s.startsWith "_private.OrbitSeedsR3." || s.startsWith "_private.OrbitCrossR3." || s.startsWith "_private.OrbitDetR3." || s.startsWith "_private.OrbitInformationR3." || s.startsWith "_private.OrbitAttainmentR3." || s.startsWith "_private.OrbitPackagingR3." || s.startsWith "_private.OrbitCompleteAuditR3." || s.startsWith "_private.OddFeasible." || s.startsWith "_private.FinalSourceR4." || s.startsWith "_private.FinalAuditR4." || s.startsWith "_private.IndependentAudit.") then
      let axs ← Lean.collectAxioms name
      logInfo m!"ENVROOT|{name}|{axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError m!"FORBIDDEN AXIOM {name}: {ax}"
