import Lean
#eval Lean.versionString
#eval (do
  let r ← IO.Process.output {cmd := "sha256sum", args := #["/home/mj-kang/Documents/Dev/math/dlp-research/.tools/lean-4.34.1-linux/bin/lean", "/home/mj-kang/Documents/Dev/math/dlp-research/.tools/lean-4.34.1-linux/bin/leanchecker", "/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-14/formal/.lake/packages/mathlib/Mathlib.lean", "/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-14/formal/.lake/packages/mathlib/lake-manifest.json"]}
  IO.println r.stdout
  if r.exitCode != 0 then throw (IO.userError "metadata hash failure")
  : IO Unit)
