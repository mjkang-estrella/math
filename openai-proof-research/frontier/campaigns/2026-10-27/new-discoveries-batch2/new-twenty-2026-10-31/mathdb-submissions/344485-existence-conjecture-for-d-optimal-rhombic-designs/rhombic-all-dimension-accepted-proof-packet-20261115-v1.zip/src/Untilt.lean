import Boundary
noncomputable section
open scoped BigOperators
namespace Rhombic

def meanVariance {K : ℕ} (d0 d1 d2 : ℝ) (q : ApproxDesign K) : ℝ :=
  ∑ x ∈ q.mass.support, q.mass x * variance d0 d1 d2 x

theorem meanVariance_pos {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (q : ApproxDesign K) :
    0 < meanVariance d0 d1 d2 q := by
  have hn : ∀ x ∈ q.mass.support, 0 ≤ q.mass x := fun x _ => q.nonneg x
  have hp : 0 < ∑ x ∈ q.mass.support, q.mass x := by
    have ht : (∑ x ∈ q.mass.support, q.mass x) = 1 := q.total
    rw [ht]; norm_num
  obtain ⟨x,hx,hp⟩ := (Finset.sum_pos_iff_of_nonneg hn).mp hp
  apply (Finset.sum_pos_iff_of_nonneg (fun x _ => mul_nonneg (q.nonneg x) (variance_pos hK hc x).le)).mpr
  exact ⟨x,hx,mul_pos hp (variance_pos hK hc x)⟩

def untiltMass {K : ℕ} (d0 d1 d2 : ℝ) (q : ApproxDesign K) : Point K →₀ ℝ :=
  Finsupp.onFinset q.mass.support
    (fun x => q.mass x * variance d0 d1 d2 x / meanVariance d0 d1 d2 q)
    (by
      intro x hx
      apply Finsupp.mem_support_iff.mpr
      intro hz
      simp [hz] at hx)

theorem untiltMass_apply {K : ℕ} (d0 d1 d2 : ℝ) (q : ApproxDesign K) (x : Point K) :
    untiltMass d0 d1 d2 q x = q.mass x * variance d0 d1 d2 x / meanVariance d0 d1 d2 q := rfl

def untiltDesign {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (q : ApproxDesign K) : ApproxDesign K where
  mass := untiltMass d0 d1 d2 q
  nonneg x := div_nonneg (mul_nonneg (q.nonneg x) (variance_pos hK hc x).le) (meanVariance_pos hK hc q).le
  total := by
    rw [untiltMass, Finsupp.sum_onFinset _ _ _ _ (by intros; rfl)]
    rw [← Finset.sum_div]
    exact div_self (ne_of_gt (meanVariance_pos hK hc q))
  cube := by
    intro x hx
    apply q.cube x
    apply Finsupp.mem_support_iff.mpr
    intro hz
    have h : untiltMass d0 d1 d2 q x ≠ 0 := Finsupp.mem_support_iff.mp hx
    simp [untiltMass_apply, hz] at h

theorem untilt_support {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (q : ApproxDesign K) :
    (untiltDesign hK hc q).mass.support = q.mass.support := by
  classical
  ext x
  simp only [Finsupp.mem_support_iff, untiltDesign, untiltMass_apply]
  exact ⟨fun h hz => h (by simp [hz]), fun h => div_ne_zero (mul_ne_zero h (ne_of_gt (variance_pos hK hc x))) (ne_of_gt (meanVariance_pos hK hc q))⟩

theorem untilt_information {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (q : ApproxDesign K) (i j : Option (Fin K)) :
    information d0 d1 d2 (untiltDesign hK hc q) i j =
      (∑ x ∈ q.mass.support, q.mass x * regressor x i * regressor x j) / meanVariance d0 d1 d2 q := by
  classical
  simp only [information, Finsupp.sum]
  rw [untilt_support hK hc, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro x _
  change (q.mass x * variance d0 d1 d2 x / meanVariance d0 d1 d2 q) * regressor x i * regressor x j / variance d0 d1 d2 x = _
  field_simp [ne_of_gt (variance_pos hK hc x)]

#print axioms meanVariance
#print axioms meanVariance_pos
#print axioms untiltMass
#print axioms untiltMass_apply
#print axioms untiltDesign
#print axioms untilt_support
#print axioms untilt_information
end Rhombic
