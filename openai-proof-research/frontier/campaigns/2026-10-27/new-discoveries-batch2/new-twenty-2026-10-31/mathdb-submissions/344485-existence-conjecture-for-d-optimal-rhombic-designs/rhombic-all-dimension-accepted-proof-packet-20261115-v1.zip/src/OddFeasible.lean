import Boundary
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.Ring.Parity
import Mathlib.Algebra.Order.GroupWithZero.Basic
import Mathlib.Tactic.LinearCombination
noncomputable section
namespace Rhombic
namespace OddFeasible

/-- Two-value AM-GM in Bernoulli form: `X * Y^n ≤ ((X + n Y)/(n+1))^(n+1)`. -/
theorem amgm_pow {X Y : ℝ} (hX : 0 ≤ X) (hY : 0 ≤ Y) (n : ℕ) :
    X * Y ^ n ≤ ((X + (n:ℝ) * Y) / ((n:ℝ) + 1)) ^ (n + 1) := by
  have hn : (0:ℝ) < (n:ℝ) + 1 := by positivity
  rcases eq_or_lt_of_le hY with h0 | hpos
  · subst h0
    rcases n with _ | m
    · simp
    · have hz : (0:ℝ) ^ (m + 1) = 0 := zero_pow (by omega)
      rw [hz, mul_zero]
      apply pow_nonneg
      refine div_nonneg ?_ hn.le
      rw [mul_zero, add_zero]
      exact hX
  · have hn0 : (0:ℝ) ≤ (n:ℝ) := Nat.cast_nonneg n
    have hden : 0 < ((n:ℝ) + 1) * Y := mul_pos hn hpos
    obtain ⟨a, ha⟩ : ∃ a : ℝ, a = (X - Y) / (((n:ℝ) + 1) * Y) := ⟨_, rfl⟩
    have hamul : a * (((n:ℝ) + 1) * Y) = X - Y := by
      rw [ha]
      exact div_mul_cancel₀ (X - Y) hden.ne'
    have ha2 : (-2:ℝ) ≤ a := by
      rw [ha, le_div_iff₀ hden]
      nlinarith [hX, hpos, mul_nonneg hn0 hY]
    have hb := one_add_mul_le_pow ha2 (n + 1)
    have hm : (X + (n:ℝ) * Y) / ((n:ℝ) + 1) = (1 + a) * Y := by
      rw [div_eq_iff hn.ne']
      linear_combination (-1:ℝ) * hamul
    have key : X * Y ^ n = (1 + ((n + 1 : ℕ) : ℝ) * a) * Y ^ (n + 1) := by
      push_cast
      linear_combination (-1:ℝ) * Y ^ n * hamul
    rw [hm, mul_pow, key]
    exact mul_le_mul_of_nonneg_right hb (pow_nonneg hY _)

/-- Pure rational rewriting of the paid scalar objective (no nonvanishing hypothesis). -/
theorem formula_aux (K S t u : ℝ) (m : ℕ) :
    1 / S * (t / (K * S)) * (u / ((K - 1) * S)) ^ m =
      t * u ^ m / (K * (K - 1) ^ m * S ^ (m + 2)) := by
  rw [div_pow, mul_pow, div_mul_div_comm, div_mul_div_comm, one_mul]
  rw [show S * (K * S) * ((K - 1) ^ m * S ^ m) = K * (K - 1) ^ m * S ^ (m + 2) by ring]

theorem scalarF_formula {K : ℕ} (hK : 2 ≤ K) (d0 d1 d2 r t : ℝ) :
    scalarF K d0 d1 d2 r t =
      t * (r - t / (K:ℝ)) ^ (K - 1) /
        ((K:ℝ) * ((K:ℝ) - 1) ^ (K - 1) * scalarS d0 d1 d2 r t ^ (K + 1)) := by
  obtain ⟨m, hm⟩ : ∃ m, K - 1 = m := ⟨_, rfl⟩
  have hm2 : K + 1 = m + 2 := by omega
  unfold scalarF
  rw [hm, hm2]
  exact formula_aux (K:ℝ) (scalarS d0 d1 d2 r t) t (r - t / (K:ℝ)) m

/-- Comparison of objective values from numerator and covariance-denominator comparisons. -/
theorem scalarF_le_of {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 r t r' t' : ℝ}
    (hs' : 0 < scalarS d0 d1 d2 r' t')
    (hss : scalarS d0 d1 d2 r' t' ≤ scalarS d0 d1 d2 r t)
    (hN0 : 0 ≤ t * (r - t / (K:ℝ)) ^ (K - 1))
    (hN : t * (r - t / (K:ℝ)) ^ (K - 1) ≤ t' * (r' - t' / (K:ℝ)) ^ (K - 1)) :
    scalarF K d0 d1 d2 r t ≤ scalarF K d0 d1 d2 r' t' := by
  rw [scalarF_formula hK d0 d1 d2 r t, scalarF_formula hK d0 d1 d2 r' t']
  have hk : (0:ℝ) < (K:ℝ) := by exact_mod_cast (show 0 < K by omega)
  have hk1 : (0:ℝ) < (K:ℝ) - 1 := by
    have h : (1:ℝ) < (K:ℝ) := by exact_mod_cast (show 1 < K by omega)
    linarith
  apply div_le_div₀ (le_trans hN0 hN) hN
  · exact mul_pos (mul_pos hk (pow_pos hk1 _)) (pow_pos hs' _)
  · exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hs'.le hss _)
      (mul_nonneg hk.le (pow_nonneg hk1.le _))

/-- Fixed-radius numerator comparison `N(r,t) ≤ N(r,r)` (`k = n+1`). -/
theorem nonpos_numerator {n : ℕ} (hn : 1 ≤ n) {k r t : ℝ} (hk : k = (n:ℝ) + 1)
    (ht : 0 ≤ t) (htr : t ≤ k * r) :
    t * (r - t / k) ^ n ≤ r * (r - r / k) ^ n := by
  subst hk
  have hn1 : (0:ℝ) < (n:ℝ) + 1 := by positivity
  have hn0 : (0:ℝ) < (n:ℝ) := by exact_mod_cast hn
  obtain ⟨u, hu⟩ : ∃ u : ℝ, u = t / ((n:ℝ) + 1) := ⟨_, rfl⟩
  obtain ⟨v, hv⟩ : ∃ v : ℝ, v = r / ((n:ℝ) + 1) := ⟨_, rfl⟩
  have hun : u * ((n:ℝ) + 1) = t := by
    rw [hu]
    exact div_mul_cancel₀ t hn1.ne'
  have hvn : v * ((n:ℝ) + 1) = r := by
    rw [hv]
    exact div_mul_cancel₀ r hn1.ne'
  rw [← hu, ← hv]
  have hu0 : 0 ≤ u := by nlinarith [hun, ht, hn1]
  have hY : 0 ≤ r - u := by nlinarith [hun, htr, hn1]
  have h := amgm_pow (mul_nonneg hn0.le hu0) hY n
  have hsum : ((n:ℝ) * u + (n:ℝ) * (r - u)) / ((n:ℝ) + 1) = (n:ℝ) * v := by
    rw [div_eq_iff hn1.ne']
    linear_combination (-(n:ℝ)) * hvn
  rw [hsum] at h
  have hrv : r - v = (n:ℝ) * v := by linear_combination (-1:ℝ) * hvn
  have key : (n:ℝ) * (t * (r - u) ^ n) ≤ (n:ℝ) * (r * (r - v) ^ n) := by
    calc (n:ℝ) * (t * (r - u) ^ n)
        = ((n:ℝ) + 1) * ((n:ℝ) * u * (r - u) ^ n) := by
          rw [← hun]
          ring
      _ ≤ ((n:ℝ) + 1) * (((n:ℝ) * v) ^ (n + 1)) := mul_le_mul_of_nonneg_left h hn1.le
      _ = (n:ℝ) * (r * (r - v) ^ n) := by
          rw [hrv, ← hvn]
          ring
  exact le_of_mul_le_mul_left key hn0

/-- Constant-covariance-line numerator comparison towards `h* = A/(A+(k-1)B)` (`k = n+1`). -/
theorem pos_numerator {n : ℕ} (hn : 1 ≤ n) {k A B r t t' q : ℝ} (hk : k = (n:ℝ) + 1)
    (hA : 0 < A) (hB : 0 ≤ B) (ht : 0 ≤ t) (htr : t ≤ k * r)
    (ht' : t' = (A * r + B * t) / (A + k * B)) (hq : q = (A + (k - 1) * B) / A) :
    t * (r - t / k) ^ n ≤ t' * (t' * q - t' / k) ^ n := by
  subst hk
  have hn1 : (0:ℝ) < (n:ℝ) + 1 := by positivity
  have hn0 : (0:ℝ) < (n:ℝ) := by exact_mod_cast hn
  have hE : 0 < A + ((n:ℝ) + 1) * B := add_pos_of_pos_of_nonneg hA (mul_nonneg hn1.le hB)
  have htE : t' * (A + ((n:ℝ) + 1) * B) = A * r + B * t := by
    rw [ht']
    exact div_mul_cancel₀ _ hE.ne'
  have hqA : q * A = A + ((n:ℝ) + 1 - 1) * B := by
    rw [hq]
    exact div_mul_cancel₀ _ hA.ne'
  obtain ⟨u, hu⟩ : ∃ u : ℝ, u = t / ((n:ℝ) + 1) := ⟨_, rfl⟩
  obtain ⟨s, hs⟩ : ∃ s : ℝ, s = t' / ((n:ℝ) + 1) := ⟨_, rfl⟩
  have hun : u * ((n:ℝ) + 1) = t := by
    rw [hu]
    exact div_mul_cancel₀ t hn1.ne'
  have hsn : s * ((n:ℝ) + 1) = t' := by
    rw [hs]
    exact div_mul_cancel₀ t' hn1.ne'
  obtain ⟨c, hc⟩ : ∃ c : ℝ, c = (n:ℝ) * (A * r + B * t) / ((n:ℝ) + 1) := ⟨_, rfl⟩
  have hcn : c * ((n:ℝ) + 1) = (n:ℝ) * (A * r + B * t) := by
    rw [hc]
    exact div_mul_cancel₀ _ hn1.ne'
  rw [← hu, ← hs]
  have hu0 : 0 ≤ u := by nlinarith [hun, ht, hn1]
  have hY : 0 ≤ A * (r - u) := mul_nonneg hA.le (by nlinarith [hun, htr, hn1])
  have hX : 0 ≤ (n:ℝ) * (A + ((n:ℝ) + 1) * B) * u := mul_nonneg (mul_nonneg hn0.le hE.le) hu0
  have h := amgm_pow hX hY n
  have hsum : ((n:ℝ) * (A + ((n:ℝ) + 1) * B) * u + (n:ℝ) * (A * (r - u))) / ((n:ℝ) + 1)
      = c := by
    rw [div_eq_iff hn1.ne']
    linear_combination (-1:ℝ) * hcn + (n:ℝ) * B * hun
  rw [hsum] at h
  have hX' : (n:ℝ) * (A + ((n:ℝ) + 1) * B) * s = c := by
    apply mul_right_cancel₀ hn1.ne'
    linear_combination (n:ℝ) * (A + ((n:ℝ) + 1) * B) * hsn + (n:ℝ) * htE - hcn
  have hY' : A * (t' * q - s) = c := by
    apply mul_right_cancel₀ hn1.ne'
    linear_combination t' * ((n:ℝ) + 1) * hqA - A * hsn + (n:ℝ) * htE - hcn
  have hM : 0 < (n:ℝ) * (A + ((n:ℝ) + 1) * B) * A ^ n := mul_pos (mul_pos hn0 hE) (pow_pos hA n)
  have key : (n:ℝ) * (A + ((n:ℝ) + 1) * B) * A ^ n * (t * (r - u) ^ n) ≤
      (n:ℝ) * (A + ((n:ℝ) + 1) * B) * A ^ n * (t' * (t' * q - s) ^ n) := by
    calc (n:ℝ) * (A + ((n:ℝ) + 1) * B) * A ^ n * (t * (r - u) ^ n)
        = ((n:ℝ) + 1) * ((n:ℝ) * (A + ((n:ℝ) + 1) * B) * u * (A * (r - u)) ^ n) := by
          rw [← hun, mul_pow]
          ring
      _ ≤ ((n:ℝ) + 1) * c ^ (n + 1) := mul_le_mul_of_nonneg_left h hn1.le
      _ = ((n:ℝ) + 1) * ((n:ℝ) * (A + ((n:ℝ) + 1) * B) * s * (A * (t' * q - s)) ^ n) := by
          rw [hX', hY']
          ring
      _ = (n:ℝ) * (A + ((n:ℝ) + 1) * B) * A ^ n * (t' * (t' * q - s) ^ n) := by
          rw [← hsn, mul_pow]
          ring
  exact le_of_mul_le_mul_left key hM

/-- Case `d2 ≤ 0`: the point `(r,r)` is at least as good as `(r,t)` when `t ≤ r`. -/
theorem nonpos_step {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 r t : ℝ} (hc : Cone K d0 d1 d2)
    (hd2 : d2 ≤ 0) (hz : (r, t) ∈ triangle K) (htr : t ≤ r) :
    (r, r) ∈ triangle K ∧ scalarF K d0 d1 d2 r t ≤ scalarF K d0 d1 d2 r r := by
  have hk1 : (1:ℝ) ≤ (K:ℝ) := by exact_mod_cast (show 1 ≤ K by omega)
  have hk0 : (0:ℝ) < (K:ℝ) := by linarith
  have hr : 0 ≤ r := hz.1
  have hrK : r ≤ (K:ℝ) := hz.2.1
  have ht : 0 ≤ t := hz.2.2.1
  have htK : t ≤ (K:ℝ) * r := hz.2.2.2
  have hz' : (r, r) ∈ triangle K := by
    show 0 ≤ r ∧ r ≤ (K:ℝ) ∧ 0 ≤ r ∧ r ≤ (K:ℝ) * r
    exact ⟨hr, hrK, hr, by nlinarith [mul_le_mul_of_nonneg_right hk1 hr]⟩
  refine ⟨hz', ?_⟩
  have hs' : 0 < scalarS d0 d1 d2 r r := scalarS_pos hK hc hz'
  apply scalarF_le_of hK hs'
  · unfold scalarS
    linarith [mul_le_mul_of_nonpos_left htr hd2]
  · apply mul_nonneg ht
    apply pow_nonneg
    rw [sub_nonneg, div_le_iff₀ hk0]
    linarith [htK]
  · obtain ⟨n, hn⟩ : ∃ n, K - 1 = n := ⟨_, rfl⟩
    have hkn : (K:ℝ) = (n:ℝ) + 1 := by exact_mod_cast (show K = n + 1 by omega)
    rw [hn]
    exact nonpos_numerator (by omega) hkn ht htK

/-- Case `0 < d2 ≤ d1/2`: move along the constant-covariance line to `t/r = h* ≥ 1/K`. -/
theorem pos_step {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 r t : ℝ} (hc : Cone K d0 d1 d2)
    (hd2 : 0 < d2) (hhalf : d2 ≤ d1 / 2) (hz : (r, t) ∈ triangle K)
    (hsmall : (K:ℝ) * t ≤ r) :
    ∃ r' t' : ℝ, (r', t') ∈ triangle K ∧ r' / (K:ℝ) ≤ t' ∧
      scalarF K d0 d1 d2 r t ≤ scalarF K d0 d1 d2 r' t' := by
  have hk1 : (1:ℝ) ≤ (K:ℝ) := by exact_mod_cast (show 1 ≤ K by omega)
  have hk0 : (0:ℝ) < (K:ℝ) := by linarith
  have hr : 0 ≤ r := hz.1
  have hrK : r ≤ (K:ℝ) := hz.2.1
  have ht : 0 ≤ t := hz.2.2.1
  have htK : t ≤ (K:ℝ) * r := hz.2.2.2
  have hA : 0 < d1 - d2 := by linarith [hhalf, hc.2.1]
  have hBA : d2 ≤ d1 - d2 := by linarith [hhalf]
  have hE : 0 < (d1 - d2) + (K:ℝ) * d2 := by linarith [mul_pos hk0 hd2]
  obtain ⟨t', ht'⟩ : ∃ t' : ℝ, t' = ((d1 - d2) * r + d2 * t) / ((d1 - d2) + (K:ℝ) * d2) :=
    ⟨_, rfl⟩
  obtain ⟨q, hq⟩ : ∃ q : ℝ, q = ((d1 - d2) + ((K:ℝ) - 1) * d2) / (d1 - d2) := ⟨_, rfl⟩
  have htE : t' * ((d1 - d2) + (K:ℝ) * d2) = (d1 - d2) * r + d2 * t := by
    rw [ht']
    exact div_mul_cancel₀ _ hE.ne'
  have hqA : q * (d1 - d2) = (d1 - d2) + ((K:ℝ) - 1) * d2 := by
    rw [hq]
    exact div_mul_cancel₀ _ hA.ne'
  have hw0 : 0 ≤ (d1 - d2) * r + d2 * t :=
    add_nonneg (mul_nonneg hA.le hr) (mul_nonneg hd2.le ht)
  have ht'0 : 0 ≤ t' := by
    rw [ht']
    exact div_nonneg hw0 hE.le
  have hKB : ((K:ℝ) - 1) * d2 ≤ ((K:ℝ) - 1) * (d1 - d2) :=
    mul_le_mul_of_nonneg_left hBA (sub_nonneg.mpr hk1)
  have hq1 : 1 ≤ q := by
    rw [hq, le_div_iff₀ hA]
    linarith [mul_nonneg (sub_nonneg.mpr hk1) hd2.le]
  have hqK : q ≤ (K:ℝ) := by
    rw [hq, div_le_iff₀ hA]
    linarith [hKB]
  have hrr : t' * q ≤ r := by
    have h2 : d2 * t * ((d1 - d2) + ((K:ℝ) - 1) * d2) ≤ d2 * t * ((K:ℝ) * (d1 - d2)) :=
      mul_le_mul_of_nonneg_left (by linarith [hKB]) (mul_nonneg hd2.le ht)
    have h3 : d2 * (d1 - d2) * ((K:ℝ) * t) ≤ d2 * (d1 - d2) * r :=
      mul_le_mul_of_nonneg_left hsmall (mul_nonneg hd2.le hA.le)
    have hprod : t' * q * ((d1 - d2) * ((d1 - d2) + (K:ℝ) * d2)) =
        ((d1 - d2) * r + d2 * t) * ((d1 - d2) + ((K:ℝ) - 1) * d2) := by
      rw [← htE, ← hqA]
      ring
    have hbound : ((d1 - d2) * r + d2 * t) * ((d1 - d2) + ((K:ℝ) - 1) * d2) ≤
        r * ((d1 - d2) * ((d1 - d2) + (K:ℝ) * d2)) := by
      nlinarith [h2, h3]
    rw [← hprod] at hbound
    exact le_of_mul_le_mul_right hbound (mul_pos hA hE)
  have hz' : (t' * q, t') ∈ triangle K := by
    show 0 ≤ t' * q ∧ t' * q ≤ (K:ℝ) ∧ 0 ≤ t' ∧ t' ≤ (K:ℝ) * (t' * q)
    refine ⟨mul_nonneg ht'0 (by linarith [hq1]), by linarith [hrr, hrK], ht'0, ?_⟩
    have h1 : 1 ≤ (K:ℝ) * q := by
      nlinarith [mul_nonneg (sub_nonneg.mpr hk1) (sub_nonneg.mpr hq1)]
    nlinarith [mul_le_mul_of_nonneg_left h1 ht'0]
  have hS : scalarS d0 d1 d2 (t' * q) t' = scalarS d0 d1 d2 r t := by
    unfold scalarS
    linear_combination t' * hqA + htE
  refine ⟨t' * q, t', hz', ?_, ?_⟩
  · rw [div_le_iff₀ hk0]
    linarith [mul_le_mul_of_nonneg_left hqK ht'0]
  · have hs' : 0 < scalarS d0 d1 d2 (t' * q) t' := scalarS_pos hK hc hz'
    apply scalarF_le_of hK hs' hS.le
    · apply mul_nonneg ht
      apply pow_nonneg
      rw [sub_nonneg, div_le_iff₀ hk0]
      linarith [htK]
    · obtain ⟨n, hn⟩ : ∃ n, K - 1 = n := ⟨_, rfl⟩
      have hkn : (K:ℝ) = (n:ℝ) + 1 := by exact_mod_cast (show K = n + 1 by omega)
      rw [hn]
      exact pos_numerator (by omega) hkn hA hd2.le ht htK ht' hq

/-- For every native `K ≥ 2` and every cone point with `d2 ≤ d1/2`, some global scalar
maximizer satisfies the odd-orbit threshold `r/K ≤ t`. -/
theorem exists_feasible_max_of_half {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (hhalf : d2 ≤ d1 / 2) :
    ∃ r t : ℝ, (r, t) ∈ triangle K ∧ 0 < r ∧ 0 < t ∧ t < (K:ℝ) * r ∧ r / (K:ℝ) ≤ t ∧
      ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 r t := by
  obtain ⟨r0, t0, hr0, hrK, ht0, htr0, hmax⟩ := exists_positive_interior_maximum hK hc
  have hk1 : (1:ℝ) ≤ (K:ℝ) := by exact_mod_cast (show 1 ≤ K by omega)
  have hk0 : (0:ℝ) < (K:ℝ) := by linarith
  have hz0 : (r0, t0) ∈ triangle K := by
    show 0 ≤ r0 ∧ r0 ≤ (K:ℝ) ∧ 0 ≤ t0 ∧ t0 ≤ (K:ℝ) * r0
    exact ⟨hr0.le, hrK, ht0.le, htr0.le⟩
  have hpos0 : 0 < scalarF K d0 d1 d2 r0 t0 := by
    obtain ⟨h11, hp⟩ := scalarF_positive_point hK hc
    exact lt_of_lt_of_le hp (hmax (1, 1) h11)
  have upgrade : ∀ r' t' : ℝ, (r', t') ∈ triangle K → r' / (K:ℝ) ≤ t' →
      scalarF K d0 d1 d2 r0 t0 ≤ scalarF K d0 d1 d2 r' t' →
      ∃ r t : ℝ, (r, t) ∈ triangle K ∧ 0 < r ∧ 0 < t ∧ t < (K:ℝ) * r ∧ r / (K:ℝ) ≤ t ∧
        ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 r t := by
    intro r' t' hz' hodd hle
    obtain ⟨hr', ht', htr'⟩ := scalar_positive_interior hK hz' (lt_of_lt_of_le hpos0 hle)
    exact ⟨r', t', hz', hr', ht', htr', hodd, fun y hy => le_trans (hmax y hy) hle⟩
  by_cases hodd : r0 / (K:ℝ) ≤ t0
  · exact upgrade r0 t0 hz0 hodd le_rfl
  · have hlt : t0 < r0 / (K:ℝ) := not_le.mp hodd
    have hsmall : (K:ℝ) * t0 ≤ r0 := by
      have h := (lt_div_iff₀ hk0).mp hlt
      linarith
    by_cases hd2 : d2 ≤ 0
    · have htr : t0 ≤ r0 := by nlinarith [hsmall, hk1, ht0]
      obtain ⟨hz', hle⟩ := nonpos_step hK hc hd2 hz0 htr
      refine upgrade r0 r0 hz' ?_ hle
      rw [div_le_iff₀ hk0]
      nlinarith [hr0, hk1]
    · obtain ⟨r', t', hz', hodd', hle⟩ := pos_step hK hc (not_le.mp hd2) hhalf hz0 hsmall
      exact upgrade r' t' hz' hodd' hle

end OddFeasible

/-- COMPLETE SCALAR FEASIBILITY COMPONENT of MathDB 344485 (not the full source target).
For every native `K ≥ 2`, every point of the unchanged source cone, and the source parity
region, some global maximizer of the unchanged scalar objective on the unchanged triangle has
`r > 0`, `0 < t < K r`, and, when `K` is odd, `t ≥ r/K` (equivalently `t/r ≥ 1/K`). -/
theorem exists_rhombic_feasible_scalar_maximum {K : ℕ} (hK : 2 ≤ K) {d0 d1 d2 : ℝ}
    (hc : Cone K d0 d1 d2) (hpar : Even K ∨ (Odd K ∧ d2 ≤ d1 / 2)) :
    ∃ r t : ℝ, (r, t) ∈ triangle K ∧ 0 < r ∧ 0 < t ∧ t < (K:ℝ) * r ∧
      (Odd K → r / (K:ℝ) ≤ t ∧ 1 / (K:ℝ) ≤ t / r) ∧
      ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 r t := by
  have hk0 : (0:ℝ) < (K:ℝ) := by exact_mod_cast (show 0 < K by omega)
  rcases hpar with heven | ⟨_, hhalf⟩
  · obtain ⟨r, t, hr, hrK, ht, htr, hmax⟩ := exists_positive_interior_maximum hK hc
    refine ⟨r, t, ?_, hr, ht, htr, fun ho => absurd heven (Nat.not_even_iff_odd.mpr ho), hmax⟩
    show 0 ≤ r ∧ r ≤ (K:ℝ) ∧ 0 ≤ t ∧ t ≤ (K:ℝ) * r
    exact ⟨hr.le, hrK, ht.le, htr.le⟩
  · obtain ⟨r, t, hz, hr, ht, htr, hodd, hmax⟩ :=
      OddFeasible.exists_feasible_max_of_half hK hc hhalf
    refine ⟨r, t, hz, hr, ht, htr, fun _ => ⟨hodd, ?_⟩, hmax⟩
    rw [div_le_div_iff₀ hk0 hr]
    have h := (div_le_iff₀ hk0).mp hodd
    linarith

namespace OddFeasible

/-- Literal assembly interface for ROOT: the complete scalar feasibility component. -/
def FeasibleScalarComponent : Prop :=
  ∀ (K : ℕ), 2 ≤ K → ∀ (d0 d1 d2 : ℝ), Cone K d0 d1 d2 →
    (Even K ∨ (Odd K ∧ d2 ≤ d1 / 2)) →
    ∃ r t : ℝ, (r, t) ∈ triangle K ∧ 0 < r ∧ 0 < t ∧ t < (K:ℝ) * r ∧
      (Odd K → r / (K:ℝ) ≤ t ∧ 1 / (K:ℝ) ≤ t / r) ∧
      ∀ y ∈ triangle K, scalarF K d0 d1 d2 y.1 y.2 ≤ scalarF K d0 d1 d2 r t

theorem feasibleScalarComponent : FeasibleScalarComponent :=
  fun _ hK _ _ _ hc hpar => exists_rhombic_feasible_scalar_maximum hK hc hpar

end OddFeasible

#print axioms OddFeasible.amgm_pow
#print axioms OddFeasible.formula_aux
#print axioms OddFeasible.scalarF_formula
#print axioms OddFeasible.scalarF_le_of
#print axioms OddFeasible.nonpos_numerator
#print axioms OddFeasible.pos_numerator
#print axioms OddFeasible.nonpos_step
#print axioms OddFeasible.pos_step
#print axioms OddFeasible.exists_feasible_max_of_half
#print axioms exists_rhombic_feasible_scalar_maximum
#print axioms OddFeasible.FeasibleScalarComponent
#print axioms OddFeasible.feasibleScalarComponent
end Rhombic
