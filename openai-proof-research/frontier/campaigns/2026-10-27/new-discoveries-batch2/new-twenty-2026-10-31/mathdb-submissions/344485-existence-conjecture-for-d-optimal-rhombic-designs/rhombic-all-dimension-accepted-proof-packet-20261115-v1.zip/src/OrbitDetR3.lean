import OrbitCrossR3
import Mathlib.LinearAlgebra.Matrix.SchurComplement
noncomputable section
open scoped BigOperators
open Matrix
namespace Rhombic.OrbitR3

def equi (K : ℕ) (a b : ℝ) : Matrix (Fin K) (Fin K) ℝ :=
  fun i j => (if i=j then a else 0)+b

theorem det_equi {K : ℕ} (hK : 1 ≤ K) (a b : ℝ) (ha : a ≠ 0) :
    (equi K a b).det = (a+(K:ℝ)*b)*a^(K-1) := by
  classical
  have he : equi K a b = a • (1 + replicateCol PUnit.{1} (fun _ : Fin K => b/a) *
      replicateRow PUnit.{1} (fun _ : Fin K => (1:ℝ))) := by
    ext i j
    simp only [equi, Matrix.smul_apply, smul_eq_mul, Matrix.add_apply,
      Matrix.mul_apply, Matrix.replicateCol_apply, Matrix.replicateRow_apply,
      Fintype.sum_unique, mul_one, Matrix.one_apply]
    split_ifs
    · field_simp
    · field_simp
      ring
  rw [he,Matrix.det_smul,Matrix.det_one_add_replicateCol_mul_replicateRow]
  simp only [Fintype.card_fin, dotProduct, one_mul, Finset.sum_const,Finset.card_univ,
    Fintype.card_fin,nsmul_eq_mul]
  have hp : a^K = a^(K-1)*a := by
    conv_lhs => rw [← Nat.sub_add_cancel hK]
    rw [pow_succ]
  rw [hp]
  field_simp

theorem det_option_block {K : ℕ} (M : Matrix (Option (Fin K)) (Option (Fin K)) ℝ)
    (a0 a b : ℝ) (hK : 1 ≤ K) (ha : a ≠ 0)
    (h0 : M none none = a0)
    (h1 : ∀ i, M none (some i) = 0) (h2 : ∀ i, M (some i) none = 0)
    (hs : ∀ i j, M (some i) (some j) = equi K a b i j) :
    M.det = a0*(a+(K:ℝ)*b)*a^(K-1) := by
  classical
  let e : PUnit.{1} ⊕ Fin K ≃ Option (Fin K) :=
    (Equiv.sumComm PUnit.{1} (Fin K)).trans (Equiv.optionEquivSumPUnit (Fin K)).symm
  have he : M.submatrix e e =
      fromBlocks (diagonal (fun _ : PUnit.{1} => a0)) 0 0 (equi K a b) := by
    ext i j
    cases i with
    | inl i => cases j <;> simp [e,Matrix.fromBlocks,h0,h1]
    | inr i => cases j <;> simp [e,Matrix.fromBlocks,h2,hs]
  have hd := congrArg Matrix.det he
  rw [Matrix.det_submatrix_equiv_self,Matrix.det_fromBlocks_zero₂₁] at hd
  simpa [det_equi hK a b ha,mul_assoc] using hd

#print axioms det_equi
#print axioms det_option_block
end Rhombic.OrbitR3
