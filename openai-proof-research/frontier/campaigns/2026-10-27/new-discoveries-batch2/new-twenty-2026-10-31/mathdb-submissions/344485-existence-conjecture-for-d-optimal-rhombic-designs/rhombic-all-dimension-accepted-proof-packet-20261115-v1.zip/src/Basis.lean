import Global
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.Real.Sqrt

noncomputable section
open scoped BigOperators
open Matrix
namespace Rhombic

def flatVector (K : ℕ) : EuclideanSpace ℝ (Fin K) :=
  WithLp.toLp 2 (fun _ => 1 / Real.sqrt (K:ℝ))

theorem flat_inner (K : ℕ) (hK : 0 < K) :
    inner ℝ (flatVector K) (flatVector K) = 1 := by
  have hk : (0:ℝ) < K := by exact_mod_cast hK
  have hs : Real.sqrt (K:ℝ) ≠ 0 := ne_of_gt (Real.sqrt_pos.mpr hk)
  simp only [EuclideanSpace.inner_eq_star_dotProduct, flatVector, dotProduct,
    Pi.star_apply, star_trivial]
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  field_simp
  nlinarith [Real.sq_sqrt hk.le]

theorem exists_flat_basis (K : ℕ) (hK : 2 ≤ K) :
    ∃ b : OrthonormalBasis (Fin K) ℝ (EuclideanSpace ℝ (Fin K)),
      b ⟨0, by omega⟩ = flatVector K := by
  classical
  let i0 : Fin K := ⟨0, by omega⟩
  let v : Fin K → EuclideanSpace ℝ (Fin K) := fun _ => flatVector K
  have hv : Orthonormal ℝ (({i0} : Set (Fin K)).domRestrict v) := by
    rw [orthonormal_iff_ite]
    intro i j
    have hij : i = j := by apply Subtype.ext; simpa using i.property.trans j.property.symm
    subst j
    simp only [ite_true]
    exact flat_inner K (by omega)
  obtain ⟨b,hb⟩ := hv.exists_orthonormalBasis_extension_of_card_eq (by simp)
  exact ⟨b, hb i0 (by simp)⟩

theorem exists_flat_orthogonal (K : ℕ) (hK : 2 ≤ K) :
    ∃ U : Matrix (Fin K) (Fin K) ℝ,
      Uᴴ * U = 1 ∧ ∀ j, U j ⟨0, by omega⟩ = 1 / Real.sqrt (K:ℝ) := by
  classical
  obtain ⟨b,hb⟩ := exists_flat_basis K hK
  let U : Matrix (Fin K) (Fin K) ℝ := Matrix.of (fun j i => b i j)
  refine ⟨U, ?_, ?_⟩
  · ext i j
    rw [Matrix.mul_apply]
    change (∑ k, star (b i k) * b j k) = (1 : Matrix (Fin K) (Fin K) ℝ) i j
    have h := orthonormal_iff_ite.mp b.orthonormal i j
    simpa [EuclideanSpace.inner_eq_star_dotProduct, dotProduct, mul_comm, Matrix.one_apply] using h
  · intro j
    change b ⟨0, by omega⟩ j = _
    rw [hb]
    rfl

#print axioms exists_flat_orthogonal
end Rhombic
