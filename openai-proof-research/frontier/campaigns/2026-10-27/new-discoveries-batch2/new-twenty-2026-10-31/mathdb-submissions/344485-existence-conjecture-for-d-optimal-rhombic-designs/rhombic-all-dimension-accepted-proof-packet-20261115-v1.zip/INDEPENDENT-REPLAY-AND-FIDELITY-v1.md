# MathDB 344485 — independent final replay and native-source fidelity, v1

SCOPED PASS: fresh whole-paper replay, final unconditional assembly, and native arXiv:1911.05538v1 source fidelity. No mathematical defect or unpaid representation bridge found in this assigned scope. This is not acceptance, credit, novelty clearance, a clean-process verdict, or a waiver. Counts remain 74/80 NEW, 113 total, credit 0. Model: GPT-6.1 Sol, high/default; no children or fallback.

## Independent replay evidence

I extracted all 30 literal modules from my own frozen AUTHOR-FINAL-PAPER copy using my own extractor. Each byte length and SHA256 matches the paper marker and fresh-replay grant. The 28 sources authorized for semantic inheritance match exactly. I inherited their closed body reviews by hash only; I did not personally re-read all 28 bodies. I personally read the full two new modules, full final ordinary proof and source context, actual definitions and relevant source pages.

All 30 production modules compiled fresh and each passed a distinct leanchecker call before any dependent module was compiled. No author source directory, extracted source, olean, build, cache, origin or live-peer provider was accessed. The build directory started without production oleans; successful compiler receipts attest null prior oleans. Only own build, the exact eight pinned standard roots, and the pinned Lean runtime's implicit core were used. Source/import/order and provider maps are attached. Trusted standard libraries are accepted, not independently rebuilt.

There were 67/96 counted formal calls: 30 production pairs, runtime metadata pair, independent audit pair plus one failed audit compile, and provider metadata pair. There are 33 final custom oleans, all separately checked. Twenty-nine calls remain unused. No GET, search, scientific prototype, child, git, account, external message, ledger or credit action occurred. The separate historical total is 393 closed calls / 42 failures and is not reset. The full per-call index records arguments, versions, hashes, exit statuses, resources, stderr, stdout and receipt hashes.

Runtime metadata was executed inside counted wrapper compile f001: Lean 4.34.1; both executable hashes and both Mathlib metadata hashes match PINS. f061 prints githash 5045d0056413266e57c625dcd7c365b10e377c52. f066 hashes all 4,883 imported providers, uniquely resolved within the allowed roots. Successful per-call source and olean hashes were compared against the final physical files. PINS revision d13f23b723b8a846827a245b89c10fc7d3f11612 is trusted through its supplied metadata hashes; no git query or upstream truth audit was authorized.

## Mathematical and final-bridge review

Let A=d1−d2, B=d2, C=A+KB. The entire source cone gives d0>0, A≥0, C≥0, including both singular covariance endpoints. On T={0≤r≤K, 0≤t≤Kr}, S=d0+Ar+Bt>0: for B≥0 use A≥0, and for B<0 use t≤Kr and C≥0. This also proves the pointwise variance lower bound. No inverse of the covariance matrix is needed.

For any finite real mass competitor, information is PSD. Tilt its probability masses by reciprocal variance, normalize, and record moments r,t. Cauchy–Schwarz and the cube bound put these in T; normalization gives a=1/S. An orthogonal slope basis with first vector the normalized constant vector, PSD Hadamard and finite AM–GM bound its determinant by F=(1/S)(t/(KS))((r−t/K)/((K−1)S))^(K−1). The orthogonal basis is constructed in the inherited prefix, not an input hypothesis. Zero information eigenvalues and singular competitors are included. This comparison uses neither competitor symmetry nor fixed support/cardinality, rational weights, nor a fixed sample size.

Compactness supplies a positive interior scalar maximum. The odd step used here is the algebraic Bernoulli/AM–GM proof, not the abandoned derivative/envelope history. If B≤0, replacing t by r decreases S and improves the numerator. If 0<B≤A and Kt<r, the constant-covariance replacement t′=(Ar+Bt)/(A+KB), r′=((A+(K−1)B)/A)t′ improves the numerator, preserves S, has r′≤r≤K and r′/K≤t′. The boundary B=A is allowed. A=0 occurs only in the even branch of the requested region. This supplies an actually constructed feasible maximum; it is not an assumed supply.

Orbit attainment uses common radius sqrt(r/K), the all-same and balanced sign seeds, permutation/global-sign enumeration and real nonnegative mixture weights. Duplicates and stabilizers are consolidated. Untilting gives actual masses q(x)V(x)/S, total one and cube support. The off-diagonal moment and equicorrelation determinant calculation yields F. The common positive radius excludes the origin; comparing absolute coordinates of proportional support points forces the scalar to have absolute value one. Thus the four actual rhombic clauses hold, including at zero orbit weights and at r=K.

I personally checked FinalSourceR4 in full: feasible_scalar_maxima obtains its witness from the hash-inherited OddFeasible theorem, reads r≤K from triangle membership, and dispatches Nat.even_or_odd. It then supplies this proved value to the previously conditional packaging. source_target, expanded_source_target and literal_source_target have only K≥2, the cone and the source parity region as hypotheses. No supply, argmax, interface, criterion, orbit realization or bridge premise survives. FinalAuditR4 is a metadata/type/axiom printer, not an additional mathematical assumption.

The own IndependentAudit theorem below goes further than the production type alias: it exposes a Finsupp mass on actual functions Fin K→ℝ, pointwise nonnegativity, mass total one, cube support, all four rhombic clauses, and every competing real Finsupp mass under the same probability/cube conditions. Both regressors and variance denominators are literal. Its proof takes the actual record returned by literal_source_target, projects its fields and constructs a competitor record for each arbitrary mass. No hidden side condition is introduced. admissible_two proves a concrete admissible cone/parity input. Total one rules out an empty mass law; the source parameter domain and witness records are nonvacuous. The inherited compactness/attainment chain also gives F>0, so determinant maximality is the source log-det maximality on nonsingular information, while singular competitors cannot improve it. No totalized Real.log convention is used.

## Native source fidelity

I read the actual model setup/information and finite arbitrary-real-weight design paragraphs, model equation (3.1), dispersion (3.2), Definition 3.1, Definition 3.2, orbit description and Conjecture 6.1. I rendered and actually viewed whole native PDF pages 3,4,15. Source text and page images agree. The regressor is (1,x1,…,xK); the variance and information in the Lean records are exactly their scalar finite-sum transcription. Finite duplicate settings are absorbed by mass addition; every finite source design is represented, with arbitrary real weights. No infinite-support source quantifier is asserted in the inspected finite-design setup.

K≥2 is contextual multiple regression: the native cone contains K−1 in its denominator and the source's analysed dimensions start at 2. It is NOT printed beside Conjecture 6.1. This report grants no K=0/1 totalized-division interpretation or repair. All source covariance PSD endpoints remain present. The odd condition is d2≤d1/2 with equality.

Definition 3.2 itself defines support on space diagonals excluding the origin, at most two points per diagonal, and invariance under permutations and a simultaneous global sign. The Lean predicate directly transcribes those clauses. For K≥2 its proportional-support-point clause, combined with negation invariance and nonzero support points, is exactly the antipodal-pair restriction. The separate orbit description explains invariant parametrization and uniform orbit weights. It does not impose an additional data/model premise needed to interpret the definition. The constructed two-orbit witness satisfies the definition directly. Requiring a redundant second formal predicate and a general equivalence theorem here would add an unnecessary gate. No genuine unproved representation/model theorem was identified.

Binding is MathDB 344485, UUID 06c61365-9900-48da-926e-a1b65b8d14ac. The correct provenance labels are raw-line/owned projection SHA e6b158ccc7a8578afcd9acd62c5e7a3c64aaf2f8cf0e0d5eed474f85702e51d7, and opaque source-chunk SHA 1dd3c17314e7e62aa885f671966b45b8792ff8509b6186b2da18e52a7715ab88. The latter is not the projection hash. Only the owned target record was inspected, not adjacent original records.

This source judgment is native arXiv v1 only. JSPI final and Röttger dissertation bodies remain closed/unread, with material bounded prior-art risk. No recovery, final-version equality, worldwide-absence, new dedup dossier, priority or novelty PASS is claimed. Earlier bounded significance judgments are supplied context, not a fresh whole-literature review.

## Declaration and axiom coverage

The independent anchored lexical inventory includes leading-space declarations and tracks namespaces. It finds 151 explicit mathematical roots: 135 in the 27-module prefix, 12 in OddFeasible, four in FinalSourceR4. No private/protected authored root was found; the scanner recognizes those modifiers. ApproxDesign's constructor and four projections give the familiar 156-root interface count. This count was derived, not forced to the author's old parser total. A second compiler-environment enumeration audits 302 roots including two own theorems and all selected authored generated/auxiliary/structure roots: recursors, cases/noConfusion, projection and constructor interfaces, equations and helpers. Every lexical root appears; missing list is empty. The exact name and transitive-axiom map is supplied. The axiom sets are only subsets of {propext, Classical.choice, Quot.sound}; no additional mathematical axiom is used. Source scans find no banned proof token or umbrella Mathlib import. Metadata #eval/run_cmd is recorded separately and is not a mathematical proof oracle.

## Hostile SELF and process (all UNWAIVED)

Objections tested: assumed scalar supply; missed singular covariance/competitor cases; forced rational or fixed finite supports; hidden orthogonal-basis input; zero weights or duplicate orbit labels; source definition versus orbit parametrization; K=0/1 repairs; incorrect chunk/projection label; and incomplete leading-space/structure axiom enumeration. The literal audited statement and exact source comparisons resolve these within the stated scope. Independent replay does not establish novelty or waive process defects.

Current defects: the very first command inventoried paths before the override. Initial override/TASK/policy and helper reads used raw shell/Python outside the documentary runner; initial pwd/rg inventory included an unneeded pwd. Some early raw/helper outputs and a later batched replay-progress output exceeded or may have exceeded the 2,000-slice/2,400-printed-payload convention. A few tool-level responses were truncated; full runner/wrapper outputs remain on disk, and truncated output is not called personal reading. Initial raw outputs are retained in the tool transcript, without invented on-disk resource receipts. Later documentary work used the capped runner and writer with CPU2,3 override. The first extractor had the wrong fence-marker grammar and failed before writing production sources; its receipt is retained, and the corrected extractor is supplied. A provider-tool orchestration JavaScript syntax error occurred before shell execution; it is not a formal call.

The first own audit compile (f063) mistakenly selected private standard runtime names via a broad string test, reaching a runtime unsafeRunMetaM/lcProof declaration outside the authored theorem set. It failed, is counted, and its exact source is preserved. This was an overbroad audit attempt outside the intended upstream-truth-audit boundary, not a proof failure; no upstream file was modified or mathematical dependency adopted. The corrected exact authored-module selector compiled and separately checked at f064/f065. All 30 canonical production sources remain unchanged. No failure is erased. No clean-process PASS is asserted. All author/component/historical defects, including the supplied author mandatory-reading limitation, remain UNWAIVED; this independent assigned reading/replay is not retroactive cure.

## HANDOFF

Assigned scientific/replay/newbridge/native-fidelity gates are SCOPED PASS, with exact personal/inherited/machine/unread coverage attached. Root retains acceptance, significance/prior-art risk adjudication and all administrative decisions; this report awards zero credit. All writes precede the standalone frozen-after operation and exhaustive physical SHA seal. The exact exclusions are only the manifest, its generating receipt and stdout, whose absolute paths are in REPLAY-RECEIPTS-v1.json. No post-seal command or write is authorized.

## Independent literal code and compiler-printed theorem

```lean
import FinalAuditR4
import Lean
noncomputable section
open scoped BigOperators
namespace IndependentAudit

theorem expanded_actual :
    ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ,
      (0 < d0 ∧ 0 < d1 ∧ -d1/((K:ℝ)-1) ≤ d2 ∧ d2 ≤ d1) →
      (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
      ∃ w : (Fin K → ℝ) →₀ ℝ,
        (∀ x, 0 ≤ w x) ∧
        w.sum (fun _ a => a) = 1 ∧
        (∀ x ∈ w.support, ∀ i, -1 ≤ x i ∧ x i ≤ 1) ∧
        (∀ p : Equiv.Perm (Fin K), ∀ x, w (x ∘ p) = w x) ∧
        (∀ x, w (-x) = w x) ∧
        (∀ x ∈ w.support, ∃ ρ : ℝ, 0 < ρ ∧ ∀ i, |x i| = ρ) ∧
        (∀ x ∈ w.support, ∀ y ∈ w.support,
          (∃ c : ℝ, c ≠ 0 ∧ y = c • x) → y = x ∨ y = -x) ∧
        ∀ u : (Fin K → ℝ) →₀ ℝ,
          (∀ x, 0 ≤ u x) → u.sum (fun _ a => a) = 1 →
          (∀ x ∈ u.support, ∀ i, -1 ≤ x i ∧ x i ≤ 1) →
          Matrix.det ((fun i j => u.sum (fun x a =>
            a * (match i with | none => 1 | some k => x k) *
                (match j with | none => 1 | some k => x k) /
              (d0 + (d1-d2) * (∑ k, x k ^ 2) + d2 * (∑ k, x k) ^ 2))) :
            Option (Fin K) → Option (Fin K) → ℝ) ≤
          Matrix.det ((fun i j => w.sum (fun x a =>
            a * (match i with | none => 1 | some k => x k) *
                (match j with | none => 1 | some k => x k) /
              (d0 + (d1-d2) * (∑ k, x k ^ 2) + d2 * (∑ k, x k) ^ 2))) :
            Option (Fin K) → Option (Fin K) → ℝ) := by
  intro K hK d0 d1 d2 hc hp
  obtain ⟨ξ, hperm, hneg, hdiag, hpair, hmax⟩ :=
    Rhombic.FinalR4.literal_source_target K hK d0 d1 d2 hc hp
  refine ⟨ξ.mass, ξ.nonneg, ξ.total, ξ.cube, hperm, hneg, hdiag, hpair, ?_⟩
  intro u hu ht hcub
  exact hmax ⟨u, hu, ht, hcub⟩

theorem admissible_two :
    (0 < (1:ℝ) ∧ 0 < (1:ℝ) ∧ -(1:ℝ)/((2:ℝ)-1) ≤ 0 ∧ (0:ℝ) ≤ 1) ∧ Even (2:ℕ) := by
  constructor
  · norm_num
  · exact ⟨1, rfl⟩

#print expanded_actual
#print axioms expanded_actual
#print axioms admissible_two
end IndependentAudit

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for name in env.header.moduleNames do
    logInfo m!"PROVIDER_MODULE|{name}"
  for (name, _) in env.constants.toList do
    let s := name.toString
    if s.startsWith "Rhombic." || s.startsWith "IndependentAudit." ||
       (s.startsWith "_private.Source." || s.startsWith "_private.Hadamard." || s.startsWith "_private.Semantics." || s.startsWith "_private.Global." || s.startsWith "_private.Basis." || s.startsWith "_private.MomentBound." || s.startsWith "_private.Sharp." || s.startsWith "_private.SourceBound." || s.startsWith "_private.Audit." || s.startsWith "_private.Moments." || s.startsWith "_private.Substitution." || s.startsWith "_private.Scalar." || s.startsWith "_private.Boundary." || s.startsWith "_private.Untilt." || s.startsWith "_private.Finite." || s.startsWith "_private.Geometry." || s.startsWith "_private.FinalAudit." || s.startsWith "_private.OrbitAverageR3." || s.startsWith "_private.OrbitSymmetryR3." || s.startsWith "_private.OrbitExpectationR3." || s.startsWith "_private.OrbitSeedsR3." || s.startsWith "_private.OrbitCrossR3." || s.startsWith "_private.OrbitDetR3." || s.startsWith "_private.OrbitInformationR3." || s.startsWith "_private.OrbitAttainmentR3." || s.startsWith "_private.OrbitPackagingR3." || s.startsWith "_private.OrbitCompleteAuditR3." || s.startsWith "_private.OddFeasible." || s.startsWith "_private.FinalSourceR4." || s.startsWith "_private.FinalAuditR4." || s.startsWith "_private.IndependentAudit.") then
      let axs ← Lean.collectAxioms name
      logInfo m!"ENVROOT|{name}|{axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError m!"FORBIDDEN AXIOM {name}: {ax}"
```

Compiler output (successful counted f064; full output retained separately):

```text
theorem IndependentAudit.expanded_actual : ∀ (K : ℕ),
  2 ≤ K →
    ∀ (d0 d1 d2 : ℝ),
      0 < d0 ∧ 0 < d1 ∧ -d1 / (↑K - 1) ≤ d2 ∧ d2 ≤ d1 →
        Even K ∨ Odd K ∧ d2 ≤ d1 / 2 →
          ∃ w,
            (∀ (x : Fin K → ℝ), 0 ≤ w x) ∧
              (w.sum fun x a => a) = 1 ∧
                (∀ x ∈ w.support, ∀ (i : Fin K), -1 ≤ x i ∧ x i ≤ 1) ∧
                  (∀ (p : Equiv.Perm (Fin K)) (x : Fin K → ℝ), w (x ∘ ⇑p) = w x) ∧
                    (∀ (x : Fin K → ℝ), w (-x) = w x) ∧
                      (∀ x ∈ w.support, ∃ ρ, 0 < ρ ∧ ∀ (i : Fin K), |x i| = ρ) ∧
                        (∀ x ∈ w.support, ∀ y ∈ w.support, (∃ c, c ≠ 0 ∧ y = c • x) → y = x ∨ y = -x) ∧
                          ∀ (u : (Fin K → ℝ) →₀ ℝ),
                            (∀ (x : Fin K → ℝ), 0 ≤ u x) →
                              (u.sum fun x a => a) = 1 →
                                (∀ x ∈ u.support, ∀ (i : Fin K), -1 ≤ x i ∧ x i ≤ 1) →
                                  (Matrix.det fun i j =>
                                      u.sum fun x a =>
                                        ((a *
                                              match i with
                                              | none => 1
                                              | some k => x k) *
                                            match j with
                                            | none => 1
                                            | some k => x k) /
                                          (d0 + (d1 - d2) * ∑ k, x k ^ 2 + d2 * (∑ k, x k) ^ 2)) ≤
                                    Matrix.det fun i j =>
                                      w.sum fun x a =>
                                        ((a *
                                              match i with
                                              | none => 1
                                              | some k => x k) *
                                            match j with
                                            | none => 1
                                            | some k => x k) /
                                          (d0 + (d1 - d2) * ∑ k, x k ^ 2 + d2 * (∑ k, x k) ^ 2) :=
fun K hK d0 d1 d2 hc hp =>
  Exists.casesOn (Rhombic.FinalR4.literal_source_target K hK d0 d1 d2 hc hp) fun ξ h =>
    And.casesOn h fun hperm right =>
      And.casesOn right fun hneg right =>
        And.casesOn right fun hdiag right =>
          And.casesOn right fun hpair hmax =>
            Exists.intro ξ.mass
              ⟨ξ.nonneg,
                ⟨ξ.total,
                  ⟨ξ.cube,
                    ⟨hperm,
                      ⟨hneg,
                        ⟨hdiag,
                          ⟨hpair, fun u hu ht hcub => hmax { mass := u, nonneg := hu, total := ht, cube := hcub }⟩⟩⟩⟩⟩⟩⟩
'IndependentAudit.expanded_actual' depends on axioms: [propext, Classical.choice, Quot.sound]
'IndependentAudit.admissible_two' depends on axioms: [propext, Classical.choice, Quot.sound]
```

## Evidence files

- [REPLAY-RECEIPTS-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/REPLAY-RECEIPTS-v1.json)
- [per-call-index.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/per-call-index.json)
- [source-olean-import-inheritance-map.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/source-olean-import-inheritance-map.json)
- [declarations-lexical.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/declarations-lexical.json)
- [environment-axioms.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/environment-axioms.json)
- [runtime-pins-map.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/runtime-pins-map.json)
- [provider-closure.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/provider-closure.json)
- [reading-coverage.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/reading-coverage.json)
- [code-scan.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/code-scan.json)
- [alias-screen-full.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/alias-screen-full.json)
- [nonjson-control-screen.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/nonjson-control-screen.json)
- [own_extractor.py](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/own_extractor.py)
- [own-extraction.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/own-extraction.json)
- [control-screen.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/control-screen.json)
- [matched-narratives.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/matched-narratives.txt)
- [alias-narratives.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/alias-narratives.txt)
- [frozen-before.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/frozen-before.json)
- [frozen-after.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/frozen-after.json)
- [PHYSICAL-SHA256-MANIFEST-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/PHYSICAL-SHA256-MANIFEST-v1.json)
- [src/FinalSourceR4.lean](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/src/FinalSourceR4.lean)
- [src/FinalAuditR4.lean](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/src/FinalAuditR4.lean)
- [src/IndependentAudit.lean](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/src/IndependentAudit.lean)
- [f059-FinalSourceR4-compile.output.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/f059-FinalSourceR4-compile.output.txt)
- [f061-FinalAuditR4-compile.output.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/f061-FinalAuditR4-compile.output.txt)
- [f064-independent-compile-v2.output.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/f064-independent-compile-v2.output.txt)
- [inputs/primary.pdf](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/rhombic-full-final-independent-strict-replay-sol-r1/inputs/primary.pdf)

Final control addendum: all three actual AGENTS files also received full normalized nonJSON machine scans (agents-control-screen.json); generally operative inherited scope and seal verifier were personally read. Sharp-s alias matches are preserved separately. Long origin/path lists are custody metadata, not personally read narratives. No uninspected unrelated history is asserted as a personal-reading gate.
