import OrbitSymmetryR3
noncomputable section
open scoped BigOperators
namespace Rhombic.OrbitR3

def avg {K : ℕ} (v : Bool → Point K) (l : ℝ) (g : Point K → ℝ) : ℝ :=
  ∑ a : Index K, weight K l a * g (point v a)

theorem avg_perm {K : ℕ} (v : Bool → Point K) (l : ℝ)
    (g : Point K → ℝ) (p : Equiv.Perm (Fin K)) :
    avg v l (fun x => g (x ∘ p)) = avg v l g := by
  let e : Index K ≃ Index K := Equiv.prodCongr (Equiv.refl Bool)
    (Equiv.prodCongr (Equiv.mulRight p) (Equiv.refl Bool))
  have h : ∀ a, weight K l (e a) * g (point v (e a)) =
      weight K l a * g (point v a ∘ p) := by intro a; rfl
  unfold avg
  rw [← Equiv.sum_comp e (fun a => weight K l a * g (point v a))]
  simp only [h]

theorem avg_seed {K : ℕ} (v : Bool → Point K) (l : ℝ) (g : Point K → ℝ)
    (hg : ∀ a : Index K, g (point v a) = g (v a.1)) :
    avg v l g = l*g (v true) + (1-l)*g (v false) := by
  have hn : (Fintype.card (Equiv.Perm (Fin K)) : ℝ) ≠ 0 := by positivity
  simp only [avg,hg]
  simp [weight, Fintype.sum_prod_type]
  field_simp
  ring

theorem avg_first {K : ℕ} (v : Bool → Point K) (l : ℝ) (i : Fin K) :
    avg v l (fun x => x i) = 0 := by
  unfold avg
  simp only [Fintype.sum_prod_type]
  apply Finset.sum_eq_zero
  intro b _
  apply Finset.sum_eq_zero
  intro p _
  simp [weight,point]

theorem avg_norm {K : ℕ} (v : Bool → Point K) (l : ℝ) :
    avg v l (fun x => ∑ i, x i ^ 2) =
      l*(∑ i, v true i ^ 2) + (1-l)*(∑ i, v false i ^ 2) := by
  apply avg_seed
  intro a
  dsimp [point]
  cases a.2.2 <;> simp only [Bool.false_eq_true, ↓reduceIte, neg_sq]
  · exact Equiv.sum_comp a.2.1 (fun i => v a.1 i ^ 2)
  · exact Equiv.sum_comp a.2.1 (fun i => v a.1 i ^ 2)

theorem avg_sum_sq {K : ℕ} (v : Bool → Point K) (l : ℝ) :
    avg v l (fun x => (∑ i, x i)^2) =
      l*(∑ i, v true i)^2 + (1-l)*(∑ i, v false i)^2 := by
  apply avg_seed
  intro a
  dsimp [point]
  cases a.2.2 <;> simp only [Bool.false_eq_true, ↓reduceIte]
  · rw [Finset.sum_neg_distrib,neg_sq,Equiv.sum_comp a.2.1 (v a.1)]
  · rw [Equiv.sum_comp a.2.1 (v a.1)]

theorem avg_sum {K : ℕ} {ι : Type*} (v : Bool → Point K) (l : ℝ)
    (s : Finset ι) (g : ι → Point K → ℝ) :
    avg v l (fun x => ∑ i ∈ s, g i x) = ∑ i ∈ s, avg v l (g i) := by
  simp only [avg,Finset.mul_sum]
  exact Finset.sum_comm

theorem avg_one {K : ℕ} (v : Bool → Point K) (l : ℝ) : avg v l (fun _ => 1) = 1 := by
  simpa [avg] using weight_total K l

#print axioms avg_perm
#print axioms avg_seed
#print axioms avg_first
#print axioms avg_norm
#print axioms avg_sum_sq
#print axioms avg_sum
#print axioms avg_one
end Rhombic.OrbitR3
