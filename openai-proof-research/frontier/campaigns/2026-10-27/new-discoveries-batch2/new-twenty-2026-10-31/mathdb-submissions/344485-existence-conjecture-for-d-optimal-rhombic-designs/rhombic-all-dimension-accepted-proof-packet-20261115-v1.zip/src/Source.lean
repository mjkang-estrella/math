import Mathlib.Data.Finsupp.Basic
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Basic.Real.Basic

noncomputable section
open scoped BigOperators
namespace Rhombic
abbrev Point (K : ℕ) := Fin K → ℝ
structure ApproxDesign (K : ℕ) where
  mass : Point K →₀ ℝ
  nonneg : ∀ x, 0 ≤ mass x
  total : mass.sum (fun _ w => w) = 1
  cube : ∀ x ∈ mass.support, ∀ i, -1 ≤ x i ∧ x i ≤ 1

def regressor {K : ℕ} (x : Point K) : Option (Fin K) → ℝ
  | none => 1
  | some i => x i

def covariance (K : ℕ) (d0 d1 d2 : ℝ) :
    Matrix (Option (Fin K)) (Option (Fin K)) ℝ
  | none, none => d0
  | some i, some j => (if i = j then d1-d2 else 0) + d2
  | _, _ => 0

def variance {K : ℕ} (d0 d1 d2 : ℝ) (x : Point K) : ℝ :=
  d0 + (d1-d2) * (∑ i, x i ^ 2) + d2 * (∑ i, x i) ^ 2

def information {K : ℕ} (d0 d1 d2 : ℝ) (ξ : ApproxDesign K) :
    Matrix (Option (Fin K)) (Option (Fin K)) ℝ :=
  fun i j => ξ.mass.sum (fun x w =>
    w * regressor x i * regressor x j / variance d0 d1 d2 x)

def Cone (K : ℕ) (d0 d1 d2 : ℝ) : Prop :=
  0 < d0 ∧ 0 < d1 ∧ -d1 / ((K : ℝ)-1) ≤ d2 ∧ d2 ≤ d1

def SameDiagonal {K : ℕ} (x y : Point K) : Prop :=
  ∃ c : ℝ, c ≠ 0 ∧ y = c • x

def RhombicDesign {K : ℕ} (ξ : ApproxDesign K) : Prop :=
  (∀ p : Equiv.Perm (Fin K), ∀ x, ξ.mass (x ∘ p) = ξ.mass x) ∧
  (∀ x, ξ.mass (-x) = ξ.mass x) ∧
  (∀ x ∈ ξ.mass.support, ∃ ρ : ℝ, 0 < ρ ∧ ∀ i, |x i| = ρ) ∧
  (∀ x ∈ ξ.mass.support, ∀ y ∈ ξ.mass.support,
    SameDiagonal x y → y = x ∨ y = -x)

def SourceTarget : Prop :=
  ∀ (K : ℕ), 2 ≤ K → ∀ d0 d1 d2 : ℝ, Cone K d0 d1 d2 →
    (Even K ∨ (Odd K ∧ d2 ≤ d1/2)) →
    ∃ ξ : ApproxDesign K, RhombicDesign ξ ∧
      ∀ η : ApproxDesign K,
        Matrix.det (information d0 d1 d2 η) ≤
        Matrix.det (information d0 d1 d2 ξ)

-- This is a definition of the unpaid goal, not a proof of it.
#print axioms SourceTarget
end Rhombic
