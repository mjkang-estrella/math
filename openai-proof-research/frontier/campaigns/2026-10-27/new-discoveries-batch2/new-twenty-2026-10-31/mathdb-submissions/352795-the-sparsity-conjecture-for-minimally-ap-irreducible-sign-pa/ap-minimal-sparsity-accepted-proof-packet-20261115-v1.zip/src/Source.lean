import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Logic.Equiv.Set
import Mathlib.Logic.Equiv.Fin.Basic
import Mathlib.Data.Finset.Card

namespace APRefutation
inductive Sign where
  | zero | pos | neg
  deriving DecidableEq
abbrev Pattern (n : ℕ) := Fin n → Fin n → Sign
def support {n} (A : Pattern n) (i j : Fin n) : Prop := A i j ≠ .zero
-- An ordered two-block decomposition: equivalently a simultaneous permutation.
def BlockReducible {n} (R : Fin n → Fin n → Prop) : Prop :=
  ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
    ∀ i j, ¬ R (e (.inl i)) (e (.inr j))
def CutReducible {n} (R : Fin n → Fin n → Prop) : Prop :=
  ∃ s : Fin n → Bool, (∃ i, s i = true) ∧ (∃ j, s j = false) ∧
    ∀ i j, s i = true → s j = false → ¬ R i j

theorem block_cut {n} (R : Fin n → Fin n → Prop) :
    BlockReducible R ↔ CutReducible R := by
  classical
  constructor
  · rintro ⟨k,l,hk,hl,e,h⟩
    let s : Fin n → Bool := fun x => (e.symm x).isLeft
    refine ⟨s, ⟨e (.inl ⟨0,hk⟩), ?_⟩, ⟨e (.inr ⟨0,hl⟩), ?_⟩, ?_⟩
    · simp [s]
    · simp [s]
    · intro i j hi hj
      obtain ⟨x, rfl⟩ := e.surjective i
      obtain ⟨y, rfl⟩ := e.surjective j
      cases x with
      | inl a =>
        cases y with
        | inl b => simp [s] at hj
        | inr b => exact h a b
      | inr a => simp [s] at hi
  · rintro ⟨s,⟨a,ha⟩,⟨b,hb⟩,h⟩
    let S : Set (Fin n) := {x | s x = true}
    let T : Set (Fin n) := Sᶜ
    have hb' : b ∈ T := by simp [T,S,hb]
    let : Nonempty S := ⟨⟨a,ha⟩⟩
    let : Nonempty T := ⟨⟨b,hb'⟩⟩
    let e := (Equiv.sumCongr (Fintype.equivFin S).symm
      (Fintype.equivFin T).symm).trans (Equiv.Set.sumCompl S)
    refine ⟨Fintype.card S, Fintype.card T, Fintype.card_pos,
      Fintype.card_pos, e, ?_⟩
    intro i j
    apply h
    · exact ((Fintype.equivFin S).symm i).property
    · have := ((Fintype.equivFin T).symm j).property
      change s (↑((Fintype.equivFin T).symm j)) = false
      change s (↑((Fintype.equivFin T).symm j)) ≠ true at this
      cases hv : s (↑((Fintype.equivFin T).symm j)) <;> simp_all

-- Literal contiguous zero block after a simultaneous permutation of the indices.
theorem block_permutation {n} (R : Fin n → Fin n → Prop) :
    BlockReducible R ↔ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧
      ∃ e : Fin (k+l) ≃ Fin n,
        ∀ i : Fin k, ∀ j : Fin l, ¬ R (e (Fin.castAdd l i)) (e (Fin.natAdd k j)) := by
  constructor
  · rintro ⟨k,l,hk,hl,e,h⟩
    exact ⟨k,l,hk,hl,finSumFinEquiv.symm.trans e,by simpa using h⟩
  · rintro ⟨k,l,hk,hl,e,h⟩
    exact ⟨k,l,hk,hl,finSumFinEquiv.trans e,by simpa using h⟩

theorem block_order {n k l} (e : Fin (k+l) ≃ Fin n) : k+l=n := by
  simpa using Fintype.card_congr e

def Irreducible {n} (R : Fin n → Fin n → Prop) := ¬ BlockReducible R

def representative : Sign → ℤ
  | .zero => 0 | .pos => 1 | .neg => -1
def Aplus {n} (A : Pattern n) (i j : Fin n) : ℤ := if A i j = .pos then 1 else 0
def Aminus {n} (A : Pattern n) (i j : Fin n) : ℤ := if A i j = .neg then -1 else 0
def B {n} (A : Pattern n) (i j : Fin n) : ℤ := Aplus A i j - Aminus A j i

theorem representative_sign (s : Sign) :
    (representative s = 0 ↔ s = .zero) ∧
    (0 < representative s ↔ s = .pos) ∧
    (representative s < 0 ↔ s = .neg) := by cases s <;> decide

theorem B_support {n} (A : Pattern n) (i j : Fin n) :
    B A i j ≠ 0 ↔ A i j = .pos ∨ A j i = .neg := by
  cases h : A i j <;> cases h' : A j i <;> simp [B,Aplus,Aminus,h,h']

def AP {n} (A : Pattern n) : Prop :=
  Irreducible (support A) ∧ (∀ i, ∃ j, A i j = .pos) ∧
    (∀ j, ∃ i, A i j = .pos) ∧ Irreducible (fun i j => B A i j ≠ 0)
def erase {n} (A : Pattern n) (r c : Fin n) : Pattern n :=
  fun i j => if i=r ∧ j=c then .zero else A i j
def MinimalAP {n} (A : Pattern n) := AP A ∧ ∀ r c, support A r c → ¬ AP (erase A r c)
def ZeroDiagonal {n} (A : Pattern n) := ∀ i, A i i = .zero
instance {n} (A : Pattern n) (i j : Fin n) : Decidable (support A i j) := inferInstanceAs (Decidable (A i j ≠ .zero))

def nnz {n} (A : Pattern n) := (Finset.univ.filter (fun p : Fin n × Fin n => support A p.1 p.2)).card

theorem irred_cut {n} (R : Fin n → Fin n → Prop) :
    Irreducible R ↔ ¬ CutReducible R := not_congr (block_cut R)
end APRefutation
