# Independent replay and fidelity review v1 — MathDB 352795

Scientific verdict: PASS for the ordinary counterexample, exact owned v3/raw/live source binding, final production definitions and bridges, fresh paper extraction, fresh compilation, separate kernel replay, and new expanded unconditional endpoint audit. No load-bearing mathematical GAP found. This is an independent scientific review, not acceptance administration. All historical/current process defects remain UNWAIVED; process-clean PASS is expressly denied. Bounded SUBSTANTIAL is retained from the prior independent review and root adoption, without a new worldwide-priority judgment. No count, ledger or acceptance action occurred.

Review performed 2026-11-15 by GPT-6.1 Sol/high, without children. Current task allocation is 32 total formal invocations; the producer's 64 allocation is historical and was not reused. Current campaign status remains the supplied 70/80 NEW, 109 total, credit added zero.

## Independent ordinary proof and hostile checks

Use one-based indices. The exact matrix rows are 0000+, 00-+0, 0+00-, 0+000, +-+00. The six positive positions are (1,5),(2,4),(3,2),(4,2),(5,1),(5,3); the three negative positions are (2,3),(3,5),(5,2). All nine positions are distinct and off diagonal; all remaining sixteen entries are zero. The support cardinality is exactly 9, greater than 2*5-2=8. Every row contains a positive. Columns 1 through 5 have positive witnesses in rows 5,3,5,2,1. These facts were personally reconstructed from the literal table, not inferred from kernel success.

A has outgoing lists 1:{5}, 2:{3,4}, 3:{2,5}, 4:{2}, 5:{1,2,3}. Its walks to vertex 2 are 1-5-2, empty, 3-2, 4-2, 5-2; walks from 2 are 2-3-5-1, empty, 2-3, 2-4, 2-3-5. B has outgoing lists 1:{5}, 2:{4,5}, 3:{2}, 4:{2}, 5:{1,3}. Its walks to 2 are 1-5-3-2, empty, 3-2, 4-2, 5-3-2, and from 2 are 2-5-1, empty, 2-5-3, 2-4, 2-5. Every consecutive pair is an actual directed arc. Concatenation excludes every nonempty proper closed outgoing cut, proving both irreducibilities. Empty walks at the reference vertex do not create an extra loop requirement.

Aminus retains -1, not +1. Thus B(i,j) is indicator(Aij=+) plus indicator(Aji=-). Literal B rows are (0,0,0,0,1), (0,0,0,1,1), (0,2,0,0,0), (0,1,0,0,0), (1,0,2,0,0). In particular B(3,2)=B(5,3)=2. The plus and reversed-minus contributions cannot cancel, for arbitrary sign-consistent real magnitudes as well as the canonical integers. Hence canonical representatives suffice for the source sign/support condition; no algebraic-positive numerical realization is needed.

All nine single deletions were checked individually. Removing (1,5)+, (2,4)+, (3,2)+, or (4,2)+ destroys the sole positive in its row. Removing (5,1)+ or (5,3)+ destroys the sole positive in its column. Removing (2,3)- leaves S={2,4} closed in A, with internal arcs 2->4 and 4->2. Removing (3,5)- leaves S={2,3,4} closed in A, with lists 2:{3,4},3:{2},4:{2}. Removing (5,2)- requires recomputing B: precisely its reverse contribution 2->5 disappears; S={2,4} is then closed in B. In the first two negative deletions the overlapping B arcs survive with weight 1, and are not incorrectly removed. Every displayed S is nonempty and proper. Orders (2,4,1,3,5) and (2,3,4,1,5) put those cuts in literal upper-right zero-block form. Thus each erasure destroys AP, and the original pattern is minimally AP-irreducible under the source's actual single-erasure definition.

## Exact source fidelity and general bridges

The raw record and the entire owned live mainEntity statement projection were personally read. They agree on minimal AP-irreducibility, zero diagonal and the unrestricted 2n-2 bound. Their open/status/empty-solutions metadata are not novelty evidence. Source: Sunil Das, Sign patterns that allow algebraic positivity, https://arxiv.org/abs/2112.00442v3 ; target https://mathdb.com/p/352795/the-sparsity-conjecture-for-minimally-ap-irreducible-sign-pa . Source copy is v3, not a claimed journal-final equivalent. The source identity card distinguishes S. Das / Sunil Das from the distinct Kinkar Chandra Das restriction.

Personally read Section 3 Aplus/Aminus/B/AP/minimality definitions, Lemmas 3.9 and 3.10 with their proofs, and Conjectures 5.1 and 5.2. Freshly rendered and inspected pages 1,2,10,11,12,22, including material formulas. Page 10 expressly keeps the negative sign in Aminus. Page 22 Conjecture 5.1 has no numerical algebraic positivity premise: the realization issue belongs to 5.2. Lemma 3.9 concerns minimal irreducibility of one digraph, not minimality of the conjunction of AP requirements. Lemma 3.10 requires absence of cross-component positives; this witness violates that hypothesis. Its positive components are {1,5},{3},{2,4}, and 5->3->2 is a cross-component positive chain. Therefore this is no contradiction of that lemma and no unjustified application of its quotient argument. Retain the supplied bounded SUBSTANTIAL assessment of this target-specific joint essentiality obstruction; no compulsory journal-body or worldwide-absence requirement is invented.

The source uses standard signed-matrix irreducibility, not nonnegative Matrix.IsIrreducible. The inspected v3 does not restate its full block definition; the usual simultaneous-permutation definition is made explicit in the final paper and proved equivalent to the finite-cut representation. No nonnegative-matrix library theorem or undirected connectivity substitute is used.

Personally read every final production definition and proof body. In block_cut forward, the Boolean cut is the left tag of e.symm; positive k,l supply an actual vertex on each side. Surjectivity and case splitting give the missing cross arcs. Backward, S and its complement T are both inhabited, their finite cardinalities are positive, subtype enumerations plus Equiv.Set.sumCompl give a bijective two-block ordering, and Boolean nonmembership is proved equivalent to false. This proves both directions without assuming the desired bridge. block_permutation composes finSumFinEquiv with this ordering in both directions, using castAdd/natAdd for contiguous blocks; block_order uses cardinal congruence to prove k+l=n. It really is a permutation of the same n indices. Irreducible is the negation of that block condition, and irred_cut transports the established equivalence.

representative_sign checks all three signs. B_support checks both input signs and proves the exact OR support formula. AP includes both irreducibilities and both row and column coverage. erase changes only the specified ordered entry. MinimalAP requires AP and every supported single-erasure failure; nnz counts actual supported ordered pairs. finiteAP_iff uses the proved bridge, not an assumption. Kernel decide is confined to the concrete five-index witness and finite cuts/erasures; there is no native_decide, unsafe, new axiom, sorry or admit in production. The quantified SourceAssertion covers every positive natural order and every three-sign function. Fin 5 indices are one less than paper indices. n=0 is excluded by the positive-order premise; n=1 uses natural truncated subtraction without affecting the counterexample at 5. No quantifier or integer/natural coercion changes the 9>8 contradiction.

## Fresh replay and provider map

Bootstrap was followed immediately by standalone frozen-before: 55 inputs, zero mismatches. The initial build directory already existed from bootstrap but was verified empty. Extraction selected exactly the three named LEAN-FILE blocks in Source,Witness,Audit order and verified paper marker hashes, authoritative PRODUCTION-HASHES hashes and byte sizes. No producer source, olean, build or cache was read. The first documentary extractor failed because it demanded a nonexistent build directory rather than an empty one; it wrote no production file before the assertion. The preserved v2 extractor checked emptiness and succeeded. This documentary failure is not a Lean invocation or scientific prototype.

The source modules import only the six specific standard Mathlib modules listed below. Witness imports the freshly extracted Source; Audit imports the freshly extracted Witness; my new IndependentAudit imports the fresh Audit. LEAN_PATH was checked in every receipt to be exactly this lane's build followed by the eight PINS standard paths, never another project build. Every custom declaration/provider is listed below; the anonymous support Decidable instance is in Source, and CutReducible/FiniteAP Decidable instances are in Witness. Inductive constructors, derived DecidableEq and compiler-generated auxiliaries belong to their same extracted modules. Remaining dependencies are pinned standard Lean and the trusted standard packages. No custom source bridge provider remains unpaid.

Toolchain is pinned Lean 4.34.1 with mathlib revision d13f23b723b8a846827a245b89c10fc7d3f11612. Both executable hashes are verified by the frozen helper on every call; both mathlib source metadata hashes were independently checked during extraction. PINS includes eight standard package paths: mathlib, batteries, aesop, Qq, proofwidgets, importGraph, LeanSearchClient, plausible. Their upstream compiled origins are trusted pins, not independently attested here. No raw version/probe call was made; the runtime-version label is bound through executable SHA rather than a separate version query. This verification limit is explicit.

Actual commands, full argv, LEAN_PATH, source/olean hashes, timing, affinity and stdout are in REPLAY-RECEIPTS-v1.json and its referenced original receipts. The commands below were each prefixed taskset -c 4,5 and run standalone from this lane:

- bash ./check32.sh Source f01-source: exit 0, no kill.
- bash ./checker32.sh Source f02-source-kernel: exit 0, no kill.
- bash ./check32.sh Witness f03-witness: exit 0, no kill.
- bash ./checker32.sh Witness f04-witness-kernel: exit 0, no kill.
- bash ./check32.sh Audit f05-audit: exit 0, no kill.
- bash ./checker32.sh Audit f06-audit-kernel: exit 0, no kill.
- bash ./check32.sh IndependentAudit f07-independent: exit 0, no kill.
- bash ./checker32.sh IndependentAudit f08-independent-kernel: exit 0, no kill.

All four fresh modules compiled and separately kernel checked in dependency order. Exactly 8/32 formal calls were used, zero formal failures, probes or extra queries. Formal CPU115/deadline130/AS32GiB/RSS6GiB/j1/M3500 and affinity [4,5] were preserved by frozen wrappers. Documentary work after interface reading used own AS6GiB capped runner. GET=0, search=0, scientific prototypes=0, children=0; no installs, git, publication, messages, accounts or ledger changes.

The witness, universal refutation, producer expanded_refutation and my endpoint each print exactly propext, Classical.choice, Quot.sound as transitive axioms. block_permutation prints propext and Quot.sound; representative_sign has no axioms. The fresh Audit also prints the permitted set for actual_AP, all_deletions, actual_nnz, overlap_weights and B_support. Historical failed-draft sorryAx output is not used as production evidence. All formal receipts show zero exit and unchanged source hashes; kernel receipts show unchanged olean hashes.

### Extraction and evidence hashes

```json
{
  "inputs/PAPER-v1.md": {
    "bytes": 104980,
    "sha256": "ccd13e65942e095e8144c6ec4403d46a8bc13ffb84a166f92c824918b584d928"
  },
  "inputs/2112.00442v3.pdf": {
    "bytes": 261150,
    "sha256": "c7ebbffde1cd95c6cf363b9627d3dbd2311d066d0156fffd5a68e6df21198379"
  },
  "inputs/2112.00442v3.txt": {
    "bytes": 153593,
    "sha256": "a29482c3443e4d18f5f3ce112e579c0f19368d0f4cda897344b61d93671f53ab"
  },
  "inputs/mathdb-352795.raw.jsonl": {
    "bytes": 1827,
    "sha256": "d9f0fb711155d9d9a6b2101765b30966bd76979a38be8ab0c966749b1efa79a3"
  },
  "inputs/live352795-statement-field-release-20261115-v1.json": {
    "bytes": 3281,
    "sha256": "3a83f2f9e3fe54acfe94f7b514639bd61476c37e0b17bd73f1d5f6a5d6c919c9"
  },
  "src/IndependentAudit.lean": {
    "bytes": 1823,
    "sha256": "da46ad6bda3e01162bc7b9f8d8774c70e8b59cb7797f9b49302e363b0adc4285"
  },
  "PINS.json": {
    "bytes": 2482,
    "sha256": "f7f3d6f49f2ed48dd7a181d9c692a1bf95c14810fe1f8778c9298ab8e352c089"
  }
}
```

### Full custom declaration/provider and import map

```json
{
  "declarations": {
    "src/Source.lean": [
      "Sign",
      "Pattern",
      "support",
      "BlockReducible",
      "CutReducible",
      "block_cut",
      "block_permutation",
      "block_order",
      "Irreducible",
      "representative",
      "Aplus",
      "Aminus",
      "B",
      "representative_sign",
      "B_support",
      "AP",
      "erase",
      "MinimalAP",
      "ZeroDiagonal",
      "nnz",
      "irred_cut"
    ],
    "src/Witness.lean": [
      "A",
      "FiniteAP",
      "finiteAP_iff",
      "actual_AP",
      "all_deletions",
      "actual_minimal",
      "actual_diagonal",
      "actual_nnz",
      "overlap_weights",
      "witness",
      "SourceAssertion",
      "refutation"
    ],
    "src/Audit.lean": [
      "expanded_refutation"
    ],
    "src/IndependentAudit.lean": [
      "endpoint"
    ]
  },
  "imports": {
    "src/Source.lean": [
      "Mathlib.Data.Fintype.Prod",
      "Mathlib.Data.Fintype.Pi",
      "Mathlib.Data.Fintype.EquivFin",
      "Mathlib.Logic.Equiv.Set",
      "Mathlib.Logic.Equiv.Fin.Basic",
      "Mathlib.Data.Finset.Card"
    ],
    "src/Witness.lean": [
      "Source"
    ],
    "src/Audit.lean": [
      "Witness"
    ],
    "src/IndependentAudit.lean": [
      "Audit"
    ]
  }
}
```

### New expanded unconditional audit source

This independently written audit puts the diagonal premise first; its proof applies the actual checked arbitrary-order refutation, with no bridge assumptions. Every custom predicate is expanded in its statement. The two-block equivalences are source block permutations by block_permutation and block_order as personally verified above.

```lean
import Audit
namespace IndependentReview
open APRefutation
-- Arbitrary positive order; all custom predicates are expanded.
theorem endpoint : ¬ (∀ n : ℕ, 0 < n → ∀ X : Fin n → Fin n → Sign,
  (∀ i, X i i = Sign.zero) →
  (((¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ (X (e (.inl i)) (e (.inr j)) ≠ Sign.zero)) ∧
    (∀ i, ∃ j, X i j = Sign.pos) ∧ (∀ j, ∃ i, X i j = Sign.pos) ∧
    (¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ ((if X (e (.inl i)) (e (.inr j)) = Sign.pos then (1 : ℤ) else 0) -
       (if X (e (.inr j)) (e (.inl i)) = Sign.neg then -1 else 0) ≠ 0))) ∧
   ∀ r c, X r c ≠ Sign.zero → ¬ ((¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ ((fun i j => if i = r ∧ j = c then Sign.zero else X i j) (e (.inl i)) (e (.inr j)) ≠ Sign.zero)) ∧
    (∀ i, ∃ j, (fun i j => if i = r ∧ j = c then Sign.zero else X i j) i j = Sign.pos) ∧ (∀ j, ∃ i, (fun i j => if i = r ∧ j = c then Sign.zero else X i j) i j = Sign.pos) ∧
    (¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ ((if (fun i j => if i = r ∧ j = c then Sign.zero else X i j) (e (.inl i)) (e (.inr j)) = Sign.pos then (1 : ℤ) else 0) -
       (if (fun i j => if i = r ∧ j = c then Sign.zero else X i j) (e (.inr j)) (e (.inl i)) = Sign.neg then -1 else 0) ≠ 0)))) →
  (Finset.univ.filter (fun p : Fin n × Fin n => X p.1 p.2 ≠ Sign.zero)).card ≤ 2*n-2) := by
  intro h
  apply refutation
  intro n hn X hm hd
  exact h n hn X hd hm
#print axioms APRefutation.witness
#print axioms APRefutation.refutation
#print axioms APRefutation.expanded_refutation
#print axioms endpoint
end IndependentReview
```

## Personal reading coverage and explicit limits

Full personal bounded reading: TASK was reread in slices 0:2000:4000:6000:8000:end after the initial overrun; override; exact three applicable AGENTS; run.py, write_lane.py, formal_command.py, run_lean_32g.py, both shell wrappers; PINS, formal-budget, model-policy, reservation, public authorization and zero budgets; FORMAL-TOOL-OWNERSHIP; SOURCE-IDENTITY-CARD; ROOT-ROUTING-PREFLIGHT; raw target; full live target field projection; independent gate JSON and root-adoption intake; frozen PDF skill. The full scientific ordinary paper argument and final production code were read through paper character 24500, with the adjoining scientific tail read next. Production proof bodies are all covered by paper-7 through paper-11, not merely hashes. Paper primary inventory was partly read. Fresh IndependentAudit was personally read in full in its creation output (1668 characters).

Source text ranges personally read: 3750:5750, sign-class/digraph contextual excerpts, 77700:79700, 84100:86100, 86100:88100, 142800:144800; full material PDF pages 1,2,10,11,12,22 visually inspected. Source Lemma3.9/3.10 statements and proofs and Conjecture5.1/5.2 are within those ranges. The source's unrelated constructive/eigenvalue sections and remaining pages were not systematically read or re-proved.

Prior report mechanism/contribution section 7517:10052 and hostile/process/handoff 17263:end were read, plus the formal handoff hostile/process section and part of its closure protocol. Prior proof full body, prior full search receipts, all 109/14 released scopes and 373 headings, registry full bodies and other source-coverage files were not personally reread. Their prior bounded judgment is retained as supplied, not represented as fresh independent coverage. Paper receipt dumps and failed historical drafts were indexed but not re-proved or systematically read; they are not fresh replay evidence. Full original producer project source/build/cache and original restricted registries/corpora were never accessed. Journal-final body remains unread; no equivalence or worldwide absence claim follows. Every input's physical SHA is covered by frozen verification/seal, which does not imply semantic reading.

Control screening walked keys and scalar values of owned restriction/model/ownership/reservation/budget controls for target ID, optional v3 ID, full title, Sunil Das/S. Das, DOI and relevant hosts. Matching owned paths were used without following origins. The initial screen was incomplete and late relative to paper reading, and the expanded screen retained some unrelated same-host identity matches. No requests or source acquisition followed. Source permissions are limited to owned copies and standard pins; protected github.com/openai/math and Homomesy closures remain intact. This screening is a process defect record, not a new permission grant.

## Process defects — all UNWAIVED

Inherited producer/reviewer/root defects remain unwaived collectively and individually. The supplied prior review records producer read-index2499/auth-a2588 overruns, common-narratives10617 clipping, unnecessary routing/reservation displays, override after bootstrap/frozen, and an arXiv robots15s interval violation (~12.3s before abstract); its later compliant PDF interval does not cure that violation. Prior reviewer source01 emitted 3511 characters and exceeded the logical limit; it also records initial direct interface reads and a historical literal-bootstrap sequencing issue, with its scoped override ordering honored. Late normalized-title/journal-alias supplements remain unwaived.

Formal producer additionally records initial unnecessary pwd, failed TASK filename attempt, direct interface reading, multiple logical/payload overruns including read01/read12/std03/result07, oversized first f01 output, broad arXiv alias aggregate display and late exact-identity supplement. Root defects referenced by the inherited records remain unwaived; no clean-root certification is made here.

Current review defects: initial TASK response printed its entire 9380-character content, violating both logical/payload and response limits; later bounded rereading does not erase it. Initial inventory display used 2200-character slicing rather than <=2000 logical slicing. Some combined control/interface/process displays exceeded the 2000-character logical unit and/or 2400 payload policy (including controls-screen-rest and process-index; the latter display was clipped at 2350, and its prior-review process narrative was subsequently fully read in two bounded slices). Identity screening was late relative to paper reading and initially omitted the full alias/DOI scope. The expanded host screen displayed unrelated work identities; no unrelated body was acquired. Source identity/authorization coverage was supplemented later. Initial direct interface reads occurred before the capped runner could be used, consistent with the need to understand it but retained transparently as a process limit. The extraction assertion failure is preserved in extraction.receipt.json; no source alteration was used to pass replay. One tool orchestration attempt tried to store an undefined session after successful f05 compilation and raised a serialization error; f05 itself exited zero and was not rerun or omitted from accounting. Some contextual control fragments were read only partly; no claim of complete personal control-file narrative coverage or universal source clearance is made. No separate runtime version query was used, as explained above.

These defects do not disappear because the proof is correct. Scientific PASS and process compliance are separate findings. No clean process PASS, waiver, acceptance, count or ledger action is authorized by this report.

## Closure protocol and receipts

REPLAY-RECEIPTS-v1.json is the structured replay index, including all eight commands/outcomes, axiom lines, source/olean hashes, provider/import map and documentary extraction failure. Every capped runner invocation preserves its exact Python command, full stdout and stderr in paired receipt/output files. The initial bootstrap/standalone frozen checks have their own receipts. No failed scientific prototype or hidden Lean invocation occurred.

After this report and all supporting writes finish, run standalone frozen-after, then an exhaustive physical own-lane SHA256 seal. The seal excludes exactly SHA256-MANIFEST-v1.json, seal.receipt.json and seal.output.txt (its manifest and generating runner receipt/stdout), includes frozen-after and all other physical files and records directories, and refuses symlinks/special objects. The actual outcome of those final operations is in their receipts and final handoff. No commands or writes are permitted after the seal. No acceptance/ledger/count action is performed.
