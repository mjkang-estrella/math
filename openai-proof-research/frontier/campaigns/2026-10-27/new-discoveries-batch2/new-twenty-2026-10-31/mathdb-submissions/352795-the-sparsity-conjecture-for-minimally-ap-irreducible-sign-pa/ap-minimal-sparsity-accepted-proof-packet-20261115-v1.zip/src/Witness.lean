import Source
namespace APRefutation
set_option maxRecDepth 20000
set_option maxHeartbeats 4000000

def A : Pattern 5 := fun i j =>
  if (i,j) ∈ ([(0,4),(1,3),(2,1),(3,1),(4,0),(4,2)] : List (Fin 5 × Fin 5)) then .pos
  else if (i,j) ∈ ([(1,2),(2,4),(4,1)] : List (Fin 5 × Fin 5)) then .neg else .zero

instance {n} (R : Fin n → Fin n → Prop) [DecidableRel R] : Decidable (CutReducible R) := by
  unfold CutReducible
  infer_instance

def FiniteAP {n} (X : Pattern n) :=
  (¬ CutReducible (support X)) ∧ (∀ i, ∃ j, X i j = .pos) ∧
    (∀ j, ∃ i, X i j = .pos) ∧ ¬ CutReducible (fun i j => B X i j ≠ 0)
instance {n} (X : Pattern n) : Decidable (FiniteAP X) := by
  unfold FiniteAP
  infer_instance

theorem finiteAP_iff {n} (X : Pattern n) : FiniteAP X ↔ AP X := by
  simp only [FiniteAP, AP, irred_cut]

theorem actual_AP : AP A := finiteAP_iff A |>.mp (by decide)

theorem all_deletions : ∀ r c, support A r c → ¬ FiniteAP (erase A r c) := by decide

theorem actual_minimal : MinimalAP A := by
  refine ⟨actual_AP, ?_⟩
  intro r c h he
  exact all_deletions r c h ((finiteAP_iff _).mpr he)

theorem actual_diagonal : ZeroDiagonal A := by unfold ZeroDiagonal; decide
theorem actual_nnz : nnz A = 9 := by decide
theorem overlap_weights : B A 2 1 = 2 ∧ B A 4 2 = 2 := by decide

theorem witness : ∃ X : Pattern 5, MinimalAP X ∧ ZeroDiagonal X ∧ nnz X = 9 ∧ nnz X > 2*5-2 := by
  exact ⟨A,actual_minimal,actual_diagonal,actual_nnz,by rw [actual_nnz]; decide⟩

def SourceAssertion : Prop := ∀ n : ℕ, 0 < n → ∀ X : Pattern n,
  MinimalAP X → ZeroDiagonal X → nnz X ≤ 2*n-2

theorem refutation : ¬ SourceAssertion := by
  intro h
  have bad := h 5 (by decide) A actual_minimal actual_diagonal
  rw [actual_nnz] at bad
  exact (by decide : ¬ (9 ≤ 2*5-2)) bad
#print axioms witness
#print axioms refutation
#print axioms block_cut
#print axioms block_permutation
end APRefutation
