# FORMAL-HANDOFF v1

MathDB 352795. Implementation completed for the unchanged nine-entry witness. No acceptance or credit is reported. Counts unchanged: 70/80 NEW, 109 total.

The standalone PAPER-v1.md contains the complete ordinary source proof, all graph/entry/cut tables, a literal byte-extractable Lean appendix, exact imports/hashes/pins/rebuild commands, every formal receipt/stdout, and literal failed source drafts. INVESTIGATION-v1.md integrates the ordinary proof and this handoff. The production modules, in order, are src/Source.lean, src/Witness.lean, src/Audit.lean.

The endpoint APRefutation.witness exhibits a source-minimal AP-irreducible zero-diagonal order5 pattern with nnz9>8. APRefutation.refutation negates the full positive-order universal assertion. APRefutation.expanded_refutation repeats that negation with EVERY custom predicate expanded: literal two-block equivalences, signed support, both indicator contributions to B, both coverage conditions, every actual single erasure, diagonal equality and actual support cardinality. No semantic bridge is an endpoint hypothesis.

APRefutation.block_cut is a general equivalence, not a finite witness certificate assumed as the meaning of irreducibility. APRefutation.block_permutation and block_order identify a nonempty proper contiguous zero block under a simultaneous bijective reordering of the same n indices. Canonical integer sign/support correctness and overlap-aware literal B support are proved. No Matrix.IsIrreducible nonnegative convention or positive-length self-path convention is imported. Minimality is exactly single-erasure source minimality, so no stronger subpattern monotonicity is assumed.

## Actual verification

All three production modules compiled with -j1 -M3500 -DwarningAsError=true and separately passed leanchecker, using ONLY frozen taskset wrappers and the eight pinned standard package paths plus owned build. The final paper's appendix was mechanically extracted byte-identically and rewritten through the own writer; every module was then freshly recompiled (the wrapper archives/removes the previous olean) and separately kernel checked again, in dependency order. This is a self replay, not the required independent acceptance replay. extract01 records the byte identities. No source change followed extraction. Final paper regeneration adds receipts/metadata/drafts without altering Lean blocks.

Transitive endpoint axioms: propext, Classical.choice, Quot.sound only. representative_sign has no axioms. Full axiom output appears in f06/f08 and f13/f15 stdout and the paper. Failed elaboration error recovery printed sorryAx in failed drafts only; those were never treated as production proofs.

| Invocation | Exit | Meaning |
|---|---:|---|
| f01-source | 1 | retained failure |
| f02-source | 1 | retained failure |
| f03-source | 0 | successful bounded invocation |
| f04-source-kernel | 0 | successful bounded invocation |
| f05-witness | 1 | retained failure |
| f06-witness | 0 | successful bounded invocation |
| f07-audit | 1 | retained failure |
| f08-audit | 0 | successful bounded invocation |
| f09-witness-kernel | 0 | successful bounded invocation |
| f10-audit-kernel | 0 | successful bounded invocation |
| f11-extracted-source | 0 | successful bounded invocation |
| f12-extracted-source-kernel | 0 | successful bounded invocation |
| f13-extracted-witness | 0 | successful bounded invocation |
| f14-extracted-witness-kernel | 0 | successful bounded invocation |
| f15-extracted-audit | 0 | successful bounded invocation |
| f16-extracted-audit-kernel | 0 | successful bounded invocation |

Four failures remain: f01 (unnecessary enum Fintype deriving failure, style lint, complement coercion, missing support decidability), f02 (missing product Fintype import), f05 (ZeroDiagonal decidability required unfolding), f07 (the tactic simplifier's expression mismatch in the expanded audit). Repairs are local and retained in drafts/. The f07 expanded statement was already definitionally correct; `exact refutation` replaced an unsuitable simplification step. No endpoint weakening occurred.

Precise invocation usage is 16/64, including all failures, 10 compilation calls and 6 separate kernel checks. No additional Lean version/query/probe calls occurred. The remaining48 are unused, not a reset. USAGE-v1.json reports measured CPU/RSS. Acquisition/search/prototypes each remain0. Ordinary finite kernel decisions count as formal calls under this allocation, not as scientific prototypes.

## Source and reading limits

Source binding is to the owned arXiv:2112.00442v3 (submitted22March2022; PDF dated23March) and exact raw MathDB record. Source definitions and Conjectures5.1/5.2 were personally read, including visual source pages10,12,22. The final journal article body is unread. The live target-field bundle, current catalogue, released109/14/373 comparison bodies, and original accepted/registry proof bodies were not personally reread. Root-supplied unchanged independent ordinary/source PASS and bounded SUBSTANTIAL adoption remain inherited judgments. No fresh worldwide-priority/current-publication assertion is made.

READ-UNREAD-v1.json lists every physical owned input with hash, date and reading level. TASK and the three required ancestor AGENTS were personally read in slices. run.py/write_lane.py/check32.sh/checker32.sh/formal_command.py/run_lean_32g.py/verify_frozen.py interfaces were read. Authorization/model/ownership/reservation/budget restriction keys and scalar values were machine-screened in restriction-screen.json and the normalized restriction-screen-v2.json; exact operative github.com/openai/math omitted-narrative restrictions were read and obeyed. Source-ownership origin strings were never traversal grants. Own control narratives were read at the necessary operative fields; unrelated aggregate bodies were not fully read. The normalized MathDB full-title/host alias supplement occurred later than the raw record read; that timing remains UNWAIVED.

The pinned STANDARD source release was read, and declarations for finite subtype equivalences, sum/complement equivalence, contiguous finite-sum equivalence, product/Pi finite instances, and the initial attempted Fintype derive handler were inspected from actual standard source text. Standard lake-manifest metadata was personally read in slices and its relevant dependency revisions appear in the paper. This is an interface inventory, not an audit of upstream truth or a full-source reading claim. Both executables' hashes are checked by every frozen invocation; all upstream olean provenance is not separately attested beyond the supplied pin trust.

## Hostile SELF and process

See the complete hostile SELF in PAPER-v1.md: directed arcs, block equivalence, row AND column positivity, negative-part sign, the two weight2 overlaps, actual erasures/recomputed B, all nine failures, proper nonempty cut orientation, true support cardinality, zero diagonal, and the unchanged arbitrary-order universal endpoint all survive local audit. There is no unpaid mathematical bridge in the final production modules. This is not an independent review decision.

All historical producer/reviewer/root defects remain UNWAIVED, including payload overruns, clipped narratives, late control reading and the reported arXiv crawl-delay defect. Current defects remain UNWAIVED too: unnecessary initial pwd, missing TASK filename attempt, direct initial interface reads, combined logical/payload overruns (notably read01/read12/std03/result07), overly broad initial arXiv match display, late normalized-title screen supplement, and initially oversized f01 formal display. Unlimited cumulative mandatory reading never waives an individual response limit. Correct proofs do not confer process PASS.

No public requests/searches, prototypes, installs, author code, other-lane scientific files/oleans/caches, children, git, shared-ledger/count changes, accounts, messages, publication or uploads occurred. View-image is read-only; PDF rendering ran under the documentary runner. No new scientific gate is invented and none of the existing independent/paper/extracted-replay/acceptance gates is waived.

## Closure protocol

Bootstrap recorded PASS_MACHINE_BINDING_ONLY and frozen-before checked50 frozen objects with zero mismatches. After all final writes and verification, run standalone frozen-after, then seal the exhaustive physical own-lane set. The seal excludes EXACTLY SHA256-v1.json, seal01.receipt.json and seal01.output.txt. Its manifest records files/directories and hashes all regular files without following symlinks. No command or write follows that seal. Actual frozen-after/seal outcomes are in their own artifacts and the final handback; this paragraph does not preclaim them.
