# INDEPENDENT-PROOF-SOURCE-CONTRIBUTION-SELF-HANDOFF v2

2026-11-15 UTC; MathDB 352795; independent review, credit 0. No children. This report reviews the supplied candidate rather than accepting producer validator output as proof.

## Decisions

Ordinary mathematics: PASS, unchanged witness and proof. Version-specific source/statement fidelity: PASS for the authorized arXiv v3 and raw/live field release. Contribution: bounded SUBSTANTIAL, with limitations below; not a worldwide-priority certification. No complete old-method specialization supplying this admissible nine-entry construction was found in the inspected evidence. Formal feasibility: concrete plan with unpaid source bridges; HOLD, formal0. Process: UNWAIVED defects, not a clean-compliance PASS. Acceptance/credit, literal Lean, paper and fresh extracted replay: HOLD. Current intake says 70/80 NEW, 109 total; this reviewer changes no count.

## Source binding and scope

Personally read the full owned raw record and the released live mainEntity Question.text. Both say every minimally AP-irreducible zero-diagonal sign pattern has at most 2n-2 entries, and define minimality by erasing any single nonzero entry. The root release was retrieved 2026-11-15 17:10 UTC; it is inherited live evidence, not a new live request by this reviewer. The old raw reference's December-2021 status statement is not current novelty evidence.

Personally read the source's sign-pattern and digraph definitions, Section 3 AP definition, Lemma 3.9, the complete Lemma 3.10 proof, and Conjectures 5.1/5.2. Rendered and inspected pages 10,12,22, also inspecting the supplied page images. The title identifies Sunil Das, arXiv:2112.00442v3, submitted 22 March 2022, PDF title date 23 March. Conjecture 5.1 on page 22 is the exact sparsity statement. It does not demand a numerical algebraically positive realization. That converse problem is Conjecture 5.2. No spectral realization proof is needed for this target.

A+ keeps + and A- keeps NEGATIVE signs. Hence subtraction of transposed A- contributes positive entries. In a numeric representative with signs +/-1, B(i,j)=1[A(i,j)=+]+1[A(j,i)=-]. These nonnegative summands have positive sum precisely when either condition holds. This proves the support formula including overlaps, rather than assuming signed cancellation away. For arbitrary qualitative magnitudes the same noncancellation argument applies. The paper's AP condition is exactly irreducibility of A, a + in every row AND every column, and irreducibility of B.

The publication identity DOI 10.1016/j.laa.2022.08.007, LAA 15 November 2022 pp.151-182, is inherited/search metadata only. Final body unread, equivalence with v3 unasserted. No publisher/author/mirror body recovery was attempted. Sunil/S. Das is not the separately restricted Kinkar Chandra Das work. No blanket surname or host restriction was inferred. Initial screening-v1 recursively checked primary title, author aliases, version/base ID, numeric digit-guard target ID and hosts over own control keys and scalar values before source-body reading. The full imported MathDB title and journal-title alias were added only in screening-v2 after review; this is a prospective-screening process omission, UNWAIVED, not retroactively cured by the later supplement. No further source body was requested afterward. Full diagnostics are saved privately in screening-v1.json; machine screening does not mean personal reading of every unrelated control narrative.

## Complete independent certificate

Use one-based indices and the literal 25 entries:

    A = [0 0 0 0 +;
         0 0 - + 0;
         0 + 0 0 -;
         0 + 0 0 0;
         + - + 0 0].

Positive support P={(1,5),(2,4),(3,2),(4,2),(5,1),(5,3)}. Negative support N={(2,3),(3,5),(5,2)}. These are disjoint, exhaust the table, and have sizes 6 and 3. The five diagonal entries are 0. Thus nnz=9 and at n=5, 2n-2=8. This interior finite n works whether the universal domain is positive orders or orders at least 2, and for integer or natural subtraction. No endpoint repair is involved.

Rows' positive columns are respectively {5},{4},{2},{2},{1,3}. Columns' positive rows are {5},{3,4},{5},{2},{1}. Thus every row and column has +, without any assertion about a positive transversal.

D(A) has outgoing lists:
1:{5}; 2:{3,4}; 3:{2,5}; 4:{2}; 5:{1,2,3}.
The central directed cycle 2->3->5->2 and attached directed cycles 5->1->5 and 2->4->2 contain every vertex. A union of directed cycles connected through shared vertices is strongly connected: to travel between arbitrary vertices, follow their cycles to the shared central cycle, traverse it to the destination attachment, and follow that attachment. Walks can be shortened to paths by deleting repeated-vertex segments.

B has the complete numerical representative

    [0 0 0 0 1;
     0 0 0 1 1;
     0 2 0 0 0;
     0 1 0 0 0;
     1 0 2 0 0].

Its outgoing lists are 1:{5}; 2:{4,5}; 3:{2}; 4:{2}; 5:{1,3}. The reversed negatives contribute (3,2),(5,3),(2,5); the first two overlap existing positive arcs and give weight 2. There are exactly seven B arcs. Its central cycle 2->5->3->2, with 5->1->5 and 2->4->2, proves directed strong connectivity by the same argument.

Here is an independent bridge to matrix irreducibility. A reducible permutation-block matrix has a nonempty proper vertex set S with no outgoing entries into its complement (possibly swap the two blocks to use the opposite zero-block convention). A path from S to its complement would have a first exiting edge, impossible. Conversely, if the support is not strongly connected, choose u unable to reach v and let S be all vertices reachable from u, including u by the empty path. It is nonempty, omits v and is closed under outgoing arcs. Order S first, its complement second: the top-right off-diagonal block is zero. This is exactly the permutation zero-block definition, valid for signed matrices because support uses nonzero entries. All claims here concern directed reachability; no symmetrization is used.

All nine erasures, exhaustively:

* (1,5)+: row 1 loses its sole +.
* (2,4)+: row 2 loses its sole +.
* (3,2)+: row 3 loses its sole +.
* (4,2)+: row 4 loses its sole +.
* (5,1)+: column 1 loses its sole +.
* (5,3)+: column 3 loses its sole +.
* (2,3)-: in D(A erased), S={2,4} has outgoing lists 2:{4},4:{2}. No edge leaves S. S is nonempty and proper; 1 lies outside. Therefore A is reducible. Its reversed B contribution (3,2) overlaps a retained +, so this deletion need not destroy B connectivity.
* (3,5)-: in D(A erased), S={2,3,4} has outgoing lists 2:{3,4},3:{2},4:{2}. It is a nonempty proper closed set, with 1 outside. This is equivalently the producer's no-INCOMING cut {1,5}. The reversed contribution (5,3) overlaps a retained + in B. The outgoing-complement formulation is an equivalent certificate, not a witness or proof repair.
* (5,2)-: B loses precisely (2,5), since A(2,5)=0. Its other reversed-negative overlaps remain. In the erased B, S={2,4} has outgoing lists 2:{4},4:{2}, so it is a nonempty proper closed cut. Thus B is reducible.

Closedness forbids every alternative path, not just the displayed cycles. Each deletion destroys at least one conjunct of AP. Consequently this A is minimally AP-irreducible and violates the full universal sparsity assertion. The proof is complete without experiments or extrapolation. No scientific runs were needed or conducted in this review; the producer's two validators were not rerun or treated as independent evidence.

## Mechanism and adversarial contribution assessment

A+ has exactly the components {1,5}, {3}, {2,4}. The first and last have bidirected positive 2-cycles; {3} is a singleton component under the usual order-one irreducibility convention. Positive cross arcs 5->3 and 3->2 form a one-way chain from {1,5} through {3} to {2,4}, with no return positive path. Thus no larger positive induced submatrix can be strongly connected. The two cross arcs explicitly break Lemma 3.10's additional hypothesis.

Strongest positive case: the construction separates three kinds of entry-essentiality in the SAME sign pattern. Row/column coverage fixes six positives, and different directed cuts fix the three negatives in two related graphs. Contracting the positive components loses the decisive chain and overlap information. It is precisely the unsupported extrapolation from minimality of one graph to minimality of a conjunction that fails. The nine-entry example disproves the exact unrestricted conjecture rather than only weakening the existing theorem's boundary.

Strongest contrary case developed from actual source: Lemma 3.9 provides the directed-ear bound for a single minimally strong digraph. Lemma 3.10 constructs the negative quotient when all cross-component positives are absent; its actual proof gives (2m-2)+sum(2n_i-2)=2n-2. Trying to specialize that proof here fails at the explicit positive chain, so the quotient need not be minimally irreducible and the counting step is unavailable. Indeed D(A) is not minimally strong: deleting (3,2)+ leaves its three connecting cycles intact. D(B) also has redundant (5,3) contributions from distinct A entries. A theorem constructing two independently chosen minimal graphs would still need a common sign-pattern realization with this B transformation and positive coverage. No such complete applicable old construction was supplied by the actual inspected source statements or the bounded search evidence. A random search provenance alone supplies no significance; conversely direct finite verification supplies no argument for TECHNICAL0.

Bounded verdict SUBSTANTIAL: a target-specific finite obstruction to the exact conjecture, with a reasoned failure of the source's strongest native method and no demonstrated complete prior specialization. This is not a named-method or unbounded-family claim. Public priority is bounded, and no exact PUBLIC0 or global absence follows from search misses. A future authenticated identical or subsuming primary result can revise this judgment.

## Coverage and prior findings

Machine-screened all 109 sanitized released records, all 14 endpoint supplements and all 373 dated catalogue groups, over their full released fields. Personally read all 109+14+373 headings, in headings01-19. Personally read full selected accepted released fields for rows 16 (asymmetric subtour polytope), 23,35,41,54,68,72,73,84,107,109, and the full supplement 9. Row16 scope was read in plausible01; its own exact endpoint concerns tour adjacency, not AP. Records 23/35 concern symmetric signed kernel quotients and conference-code distances; 41 concerns multigraph moves; 54 a 0/1 rook monoid product count; 68 spectral Vendi support; 72/73 C*-spectral positivity; 84/supplement9 a Bernoulli enumeration inequality; 107 undirected frustrated-cycle stability; 109 universal rooted-board symmetry. None states or supplies minimal AP sparsity or a same-sign-pattern joint-connectivity construction. Sharing the word positive, signed, matrix, cut or directed does not make these variants of the current target.

Read complete catalogue statement fields for families 117,173,174,179,190,239,262,325. These concern sparsest-cut approximation, oriented second neighborhoods, undirected thin trees, circulant Hadamard matrices, ordered binary removal, random symmetric sign singularity, PSD matrix-potential spectral bounds, and polynomial numerical-range norms. In particular 173 excludes opposite pairs, whereas our witness has opposite positive arcs; 174 controls an undirected tree in a multigraph, not two sign-derived directed supports; 239 concerns random dense symmetric signs and determinant singularity, not erasure minimality. None supplies this finite obstruction. These are released statement comparisons, not reading their protected proofs. Other bodies and most released complete predicates remain unread; the all-heading screen is not a full technical audit of every field or a global registry clearance.

Catalogue provenance supplied: blob 7e1ed90ac5a666f1bbecb22027387c4ad79e9d03, acquired 2026-11-14T22:28:25.825Z; SHA256 fd41a43180c7bfa7bf1935cda4013ceea222a8bf69d904a394afecd82fa13d01. Root metadata refresh 2026-11-15T11:04:49Z says HEAD 4eaee87548250b2682affda7d05d947c05554bae unchanged (commit dated 2026-10-30). This is inherited field evidence, not this review's fresh registry inspection. No registry/original-proof path was followed. Primary v3 in March 2022 predates the current candidate; metadata alone establishes neither final-body scope nor an older exact counterexample.

Two fresh search calls/four queries on 2026-11-15 are preserved in fresh-searches-v1.json: exact minimally-AP counterexample, exact primary title+sparsity, AP-irreducible+2n+counterexample, and AP-irreducible+nine/sparsity/Conjecture5.1. The displayed returns were an older 3-by-3 AP classification research profile and irrelevant algebra material, not an authenticated five-by-five sparsity refutation or applicable joint-minimal construction. Only bounded initial portions of these response bodies were personally displayed; complete responses are saved. Prior supplied searches were only partially inspected, not represented as full independent reading. No new body was fetched from a search lead. No exact public counterpart is established. Negative search evidence is weak, explicitly so. Source Lemmas3.9/3.10 are the positive authenticated existing results; they are credited as prior ingredients with their actual hypotheses, not claimed new here.

## Real unexecuted formal map

Pinned mathlib revision from the authorized text release: d13f23b723b8a846827a245b89c10fc7d3f11612. Only STANDARD source text inspected. No Lean process, version, query, probe, compile, checker, project code, olean or cache used. Existing declarations actually inspected:

* Mathlib/Combinatorics/Quiver/Path.lean: Quiver.Path, constructors nil and cons; Quiver.Hom.toPath; Quiver.Path.length, comp, length_comp.
* Mathlib/Combinatorics/Quiver/ConnectedComponent.lean: Quiver.IsStronglyConnected := forall i j, Nonempty(Path i j); IsSStronglyConnected requires positive path length for all pairs; stronglyConnectedSetoid and StronglyConnectedComponent.
* Mathlib/LinearAlgebra/Matrix/Irreducible/Defs.lean: Matrix.toQuiver uses PLift(0<A i j); Matrix.IsIrreducible includes nonneg and positive-length strong connectivity. It is NOT directly the signed-matrix irreducibility needed here.
* Mathlib/Data/Matrix/Block.lean: Matrix.fromBlocks and all four fromBlocks_apply block equations, actually read. These can express a zero off-diagonal permutation block. No matching upstream source-cut equivalence was located or assumed.
* Mathlib/Logic/Function/Basic.lean: Function.update, update_self, update_of_ne, actually read; use pair-index update to erase one entry.
* Mathlib/Data/Finset/Filter.lean: Finset.filter and mem_filter; Data/Finset/Card.lean card_filter_eq_zero_iff/card_filter_le; Data/Fintype/Prod.lean instFintypeProd and Fintype.card_prod. Declaration inventories read; no source SignPattern declaration found in the standard-tree text search. This is not an exhaustive proof of absence.

New definitions: Sign with zero,pos,neg; SignPattern n = Matrix (Fin n) (Fin n) Sign; numerical sign representative; source reducibility as a nonempty proper permutation zero-block; Aplus/Aminus and B numeric definition; row/column + coverage; AP using source irreducibility and B; eraseEntry, zeroDiagonal, nnz via filtered Finset.univ of pairs; minimalAP with every nonzero-entry deletion failing AP.

Precise NEW lemmas still required: (1) source_permutation_block_iff_closed_cut, building the subset/complement equivalence and the two block orders; (2) path_stays_in_closed_cut by Quiver.Path induction; (3) source_irreducible_iff_directed_strong, using the reachable set for the converse; (4) B_support_iff, with noncancellation proved for the actual Aminus convention; (5) source_irreducibility agrees with support-matrix irreducibility on Fin n for n>=2, handling positive-length self paths if using Matrix.IsIrreducible; (6) finite cycle/path certificate constructors; (7) coverage-failure and cut-failure deletion lemmas. These cannot be replaced by a predicate merely named AP.

Cheapest decisive complete witness pilot, if root authorizes a separate formal lane: prove these bridges, then use the literal Fin5 table, explicit paths through anchor2 in both digraphs, six coverage failures and three cuts as above, zero diagonal, exact cardinality9, and instantiate the universal bound at5. Ordinary kernel decide/norm_num is appropriate only for the small table facts/cut memberships/cardinality. Directed reachability is handled by proof constructors, not a 3^25 universal search. No native_decide/oracle. Target theorem is the negation of forall n>=2 and all source-minimal zero-diagonal sign patterns, nnz<=2*n-2 (or the exact selected all-order source formulation with its domain convention made explicit). Nothing in this plan requires numerical spectral algebraic positivity. Feasibility is plausible but remains unexecuted and not a current formal GO. Definitions, source bridges, complete Lean, axiom audit, paper and independently extracted replay remain unpaid.

## Hostile SELF / process / handoff

The complete producer proof (~15k) was personally read in proof01-08; it was not used as instruction authority. The proof survives the strongest local objections: directed rather than undirected connectivity; row AND column coverage; overlap-aware B erasure; incoming/outgoing cut orientation; all nine entries; exact count/zero diagonal; and distinction of Conjectures5.1 and5.2. Equivalent outgoing-complement cut notation changes no mathematical claim. There is no repair and no residual ordinary mathematical gap.

Process is not clean. In this review source01 accidentally emitted 3511 payload characters, exceeding 2400 and its combined logical read exceeded2000. This is UNWAIVED; no claim that unlimited cumulative reading excuses it. Bootstrap was preceded by the FIRST-requested override read, so the literal first-shell bootstrap / second-shell frozen sequence was not met; override-before-bootstrap was honored, standalone frozen-before ran immediately after bootstrap. Initial interface reads used a bounded direct Python process before run.py was understood. All runner/bootstrap calls had taskset -c4,5; affinity receipts show [4,5]. No scientific execution occurred. View-image calls were read-only inspection outside the shell runner; PDF rendering itself used run.py and writes used write_lane.py.

Inherited producer defects, all UNWAIVED: read-index2499/auth-a2588 payload overruns; common-narratives10617 clipping; unnecessary routing/reservation displays; override read after bootstrap/frozen; arXiv robots15s crawl delay violated by ~12.3s interval before abstract. Later PDF interval was compliant per inherited report. Do not retroactively validate these from the current proof's correctness. Historical counts/budgets were not reset. This reviewer used0/8 GET hops,2/6 search calls,4/12 queries,0/2 scientific diagnostics,0 scientific CPU,0 formal calls. No installed dependencies, git, browsers, accounts, author code, external messages, uploads or publication; no child, other lane/origin traversal, original accepted/registry proof/plan/code or quarantine access.

Handoff: ordinary proof and v3 source fidelity independently PASS; bounded substantial target-specific obstruction supported. Current final-body equivalence/global priority are unclaimed. Scope comparisons are bounded to released fields and stated reading levels. Root must retain all process defects and all acceptance gates; no counts or credit change. Complete separate gate JSON and source/coverage index accompany this report. Finish with standalone frozen-after then exhaustive SHA256 seal excluding exactly the manifest and its generating receipt/stdout. No commands or writes after that seal.

Version note: v1 preserved. v2 clarifies the late screening supplement; it changes no witness, proof, scientific verdict or acceptance gate. QA receipts hash v1 and associated initial outputs; final seal binds v2.
