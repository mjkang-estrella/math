import Audit
namespace IndependentReview
open APRefutation
-- Arbitrary positive order; all custom predicates are expanded.
theorem endpoint : ¬ (∀ n : ℕ, 0 < n → ∀ X : Fin n → Fin n → Sign,
  (∀ i, X i i = Sign.zero) →
  (((¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ (X (e (.inl i)) (e (.inr j)) ≠ Sign.zero)) ∧
    (∀ i, ∃ j, X i j = Sign.pos) ∧ (∀ j, ∃ i, X i j = Sign.pos) ∧
    (¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ ((if X (e (.inl i)) (e (.inr j)) = Sign.pos then (1 : ℤ) else 0) -
       (if X (e (.inr j)) (e (.inl i)) = Sign.neg then -1 else 0) ≠ 0))) ∧
   ∀ r c, X r c ≠ Sign.zero → ¬ ((¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ ((fun i j => if i = r ∧ j = c then Sign.zero else X i j) (e (.inl i)) (e (.inr j)) ≠ Sign.zero)) ∧
    (∀ i, ∃ j, (fun i j => if i = r ∧ j = c then Sign.zero else X i j) i j = Sign.pos) ∧ (∀ j, ∃ i, (fun i j => if i = r ∧ j = c then Sign.zero else X i j) i j = Sign.pos) ∧
    (¬ ∃ k l : ℕ, 0 < k ∧ 0 < l ∧ ∃ e : Fin k ⊕ Fin l ≃ Fin n,
      ∀ i j, ¬ ((if (fun i j => if i = r ∧ j = c then Sign.zero else X i j) (e (.inl i)) (e (.inr j)) = Sign.pos then (1 : ℤ) else 0) -
       (if (fun i j => if i = r ∧ j = c then Sign.zero else X i j) (e (.inr j)) (e (.inl i)) = Sign.neg then -1 else 0) ≠ 0)))) →
  (Finset.univ.filter (fun p : Fin n × Fin n => X p.1 p.2 ≠ Sign.zero)).card ≤ 2*n-2) := by
  intro h
  apply refutation
  intro n hn X hm hd
  exact h n hn X hd hm
#print axioms APRefutation.witness
#print axioms APRefutation.refutation
#print axioms APRefutation.expanded_refutation
#print axioms endpoint
end IndependentReview
