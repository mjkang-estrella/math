/-
# Bunkbed E7 for transitive tournaments: base definitions and path lemmas

Literal model, MathDB 382297 (E7 / D7): transitive tournament arcs i<j on `Fin n`;
vertices `Fin n × Bool`; one token per horizontal arc per layer (exists only for i<j)
and ONE bidirectional token per index; outcome = arbitrary Boolean assignment to all
tokens; reachability = reflexive transitive closure of the enabled-arc relation.
-/
import Mathlib.Logic.Relation

/-- Horizontal arc token: ordered pair with `i < j`, carrying the layer. -/
structure HToken (n : Nat) where
  fst : Fin n
  snd : Fin n
  hlt : (fst : Nat) < (snd : Nat)
  layer : Bool

/-- One token per horizontal arc per layer, plus one bidirectional token per index. -/
def Token (n : Nat) := HToken n ⊕ Fin n

/-- Vertices of the two-layer bunkbed. -/
abbrev Vert (n : Nat) := Fin n × Bool

/-- Outcome: a Boolean assignment to every token. -/
def Out (n : Nat) := Token n → Bool

/-- Largest index a token touches (the horizontal target, or the vertical index). -/
def tmax {n : Nat} : Token n → Nat
  | Sum.inl t => (t.snd : Nat)
  | Sum.inr k => (k : Nat)

/-- The horizontal token for arc `(i,l) → (j,l)`, given `i < j`. -/
def htok {n : Nat} (i j : Fin n) (h : (i : Nat) < (j : Nat)) (l : Bool) : Token n :=
  Sum.inl ⟨i, j, h, l⟩

/-- The vertical token of index `i`; ONE token carries BOTH directions. -/
abbrev vtok {n : Nat} (i : Fin n) : Token n := Sum.inr i

@[simp] theorem tmax_htok {n : Nat} (i j : Fin n) (h : (i : Nat) < (j : Nat)) (l : Bool) :
    tmax (htok i j h l) = (j : Nat) := rfl

@[simp] theorem tmax_vtok {n : Nat} (i : Fin n) : tmax (vtok i) = (i : Nat) := rfl

/-- Enabled arc relation, literally: horizontal retention (same layer, `i < j`) or
vertical retention (one shared token enables both directions). -/
def Arc (n : Nat) (ω : Out n) : Vert n → Vert n → Prop := fun x y =>
  (x.2 = y.2 ∧ ∃ h : (x.1 : Nat) < (y.1 : Nat), ω (htok x.1 y.1 h x.2))
  ∨ (x.1 = y.1 ∧ x.2 ≠ y.2 ∧ ω (vtok x.1))

/-- Literal reachability: reflexive transitive closure of the enabled-arc relation. -/
def Reach (n : Nat) (ω : Out n) (x y : Vert n) : Prop :=
  Relation.ReflTransGen (Arc n ω) x y

theorem arc_fst_le {n : Nat} {ω : Out n} {x y : Vert n} (h : Arc n ω x y) :
    (x.1 : Nat) ≤ (y.1 : Nat) := by
  have h' : (x.2 = y.2 ∧ ∃ hh : (x.1 : Nat) < (y.1 : Nat), ω (htok x.1 y.1 hh x.2))
      ∨ (x.1 = y.1 ∧ x.2 ≠ y.2 ∧ ω (vtok x.1)) := h
  rcases h' with ⟨-, h2, -⟩ | ⟨h1, -, -⟩
  · exact Nat.le_of_lt h2
  · exact Nat.le_of_eq (by rw [h1])

/-- A retained arc, given its bit. -/
theorem arc_horiz {n : Nat} {ω : Out n} {i j : Fin n} {l : Bool}
    (hij : (i : Nat) < (j : Nat)) (h : ω (htok i j hij l)) : Arc n ω (i, l) (j, l) :=
  Or.inl ⟨rfl, ⟨hij, h⟩⟩

theorem arc_vert {n : Nat} {ω : Out n} {i : Fin n} {l : Bool} (h : ω (vtok i)) :
    Arc n ω (i, l) (i, !l) := by
  refine Or.inr ⟨rfl, ?_, h⟩
  cases l <;> simp

/-- Along a reachability path the index never decreases. -/
theorem reach_fst_le {n : Nat} {ω : Out n} {x y : Vert n}
    (h : Relation.ReflTransGen (Arc n ω) x y) : (x.1 : Nat) ≤ (y.1 : Nat) := by
  induction h with
  | refl => exact Nat.le_refl _
  | tail _ h2 ih => exact Nat.le_trans ih (arc_fst_le h2)

/-- Single-arc agreement on low endpoints from token agreement. -/
theorem arc_agree {n : Nat} {ω ω' : Out n} {c : Nat}
    (hag : ∀ t : Token n, tmax t ≤ c → ω t = ω' t) {x y : Vert n} (h : Arc n ω x y)
    (hx : (x.1 : Nat) ≤ c) (hy : (y.1 : Nat) ≤ c) : Arc n ω' x y := by
  have h' : (x.2 = y.2 ∧ ∃ hh : (x.1 : Nat) < (y.1 : Nat), ω (htok x.1 y.1 hh x.2))
      ∨ (x.1 = y.1 ∧ x.2 ≠ y.2 ∧ ω (vtok x.1)) := h
  rcases h' with ⟨h1, h2⟩ | ⟨h1, h2, h3⟩
  · rcases h2 with ⟨hlt, hw⟩
    refine Or.inl ⟨h1, ⟨hlt, ?_⟩⟩
    have htm : tmax (htok x.1 y.1 hlt x.2) ≤ c := by rw [tmax_htok]; exact hy
    rw [← hag _ htm]; exact hw
  · refine Or.inr ⟨h1, h2, ?_⟩
    have htm : tmax (vtok x.1) ≤ c := by rw [tmax_vtok]; exact hx
    rw [← hag _ htm]; exact h3

/-- If two outcomes agree on all tokens with `tmax ≤ c`, then reachability from `x`
to any vertex of index `≤ c` agrees: no path may leave the low indices, since along
any path the index is nondecreasing. -/
theorem reach_agree {n : Nat} {ω ω' : Out n} {c : Nat}
    (hag : ∀ t : Token n, tmax t ≤ c → ω t = ω' t) {x y : Vert n} (hy : (y.1 : Nat) ≤ c)
    (h : Relation.ReflTransGen (Arc n ω) x y) :
    Relation.ReflTransGen (Arc n ω') x y := by
  have key : ∀ b : Vert n, Relation.ReflTransGen (Arc n ω) x b → (b.1 : Nat) ≤ c →
      Relation.ReflTransGen (Arc n ω') x b := by
    intro b hb
    induction hb with
    | refl => exact fun _ => Relation.ReflTransGen.refl
    | @tail b' c' h1 h2 ih =>
        intro hcc
        have hbb : (b'.1 : Nat) ≤ c := Nat.le_trans (arc_fst_le h2) hcc
        exact Relation.ReflTransGen.tail (ih hbb) (arc_agree hag h2 hbb hcc)
  exact key y h hy

/-- Reachability from `(u,false)` never goes to an index `< u`. -/
theorem reach_ge {n : Nat} {ω : Out n} {u : Fin n} {x : Vert n}
    (h : Relation.ReflTransGen (Arc n ω) (u, false) x) : (u : Nat) ≤ (x.1 : Nat) :=
  reach_fst_le h

/-- The two entry shapes into a vertex, extracted from `Arc`. -/
theorem arc_cases {n : Nat} {ω : Out n} {x y : Vert n} (h : Arc n ω x y) :
    ((x.2 = y.2 ∧ ∃ hh : (x.1 : Nat) < (y.1 : Nat), ω (htok x.1 y.1 hh x.2) = true)
      ∨ (x.1 = y.1 ∧ x.2 ≠ y.2 ∧ ω (vtok x.1) = true)) := h

theorem arc_horiz' {n : Nat} {ω : Out n} {x y : Vert n}
    (h1 : x.2 = y.2) (hlt : (x.1 : Nat) < (y.1 : Nat)) (hw : ω (htok x.1 y.1 hlt x.2) = true) :
    Arc n ω x y := Or.inl ⟨h1, ⟨hlt, hw⟩⟩

/-- Recursive characterization (the exact new-index closure): for `u < j`, the copy
`(j,l)` is reachable iff some strictly-lower same-layer copy is reachable with its
horizontal bit set, or the vertical partner is reachable with the vertical bit set.
Arcs never decrease the index, so there is no other entry into index `j`. -/
theorem reach_char {n : Nat} {ω : Out n} {u j : Fin n} (huj : (u : Nat) < (j : Nat))
    {l : Bool} :
    Relation.ReflTransGen (Arc n ω) (u, false) (j, l) ↔
      ((∃ i : Fin n, (i : Nat) < (j : Nat) ∧
          Relation.ReflTransGen (Arc n ω) (u, false) (i, l) ∧
          ∃ h : (i : Nat) < (j : Nat), ω (htok i j h l) = true)
        ∨ (Relation.ReflTransGen (Arc n ω) (u, false) (j, !l) ∧ ω (vtok j) = true)) := by
  constructor
  · intro h
    have hne : (j, l) ≠ (u, false) := by
      intro hh
      have h1 : j = u := congrArg Prod.fst hh
      have h2 : (j : Nat) = (u : Nat) := by rw [h1]
      omega
    rcases Relation.ReflTransGen.cases_tail h with heq | ⟨z, h1, h2⟩
    · exact absurd heq hne
    · obtain ⟨z1, z2⟩ := z
      rcases arc_cases h2 with ⟨hz2, hz3⟩ | ⟨hz1, hz2, hz3⟩
      · obtain ⟨hlt, hw⟩ := hz3
        subst hz2
        exact Or.inl ⟨z1, hlt, h1, hlt, hw⟩
      · have hz1' : z1 = j := hz1
        have hz2l : z2 = !l := by cases z2 <;> cases l <;> simp at hz2 ⊢
        rw [hz1', hz2l] at h1
        have hw' : ω (vtok j) = true := by rw [← hz1']; exact hz3
        exact Or.inr ⟨h1, hw'⟩
  · intro h
    rcases h with ⟨i, hik, hreach, hik2, hwt⟩ | ⟨hreach, hwt⟩
    · exact Relation.ReflTransGen.trans hreach
        (Relation.ReflTransGen.single (arc_horiz' rfl hik2 hwt))
    · have hne : (!l : Bool) ≠ l := by cases l <;> simp
      exact Relation.ReflTransGen.trans hreach
        (Relation.ReflTransGen.single
          (show Arc n ω (j, !l) (j, l) from Or.inr ⟨rfl, hne, hwt⟩))
