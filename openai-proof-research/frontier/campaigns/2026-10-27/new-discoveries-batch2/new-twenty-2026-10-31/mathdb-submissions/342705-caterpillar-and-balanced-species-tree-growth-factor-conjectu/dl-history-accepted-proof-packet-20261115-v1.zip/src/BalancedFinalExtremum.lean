import BalancedFinalOrder
import CaterpillarCounts
namespace LiteralDL.BalancedStage
open LiteralDL

theorem rho_balanced_strict (s : Species)
    (hi : ¬ ShapeIso s (balanced (leaves s))) :
    rho s < rho (balanced (leaves s)) := by
  by_contra hn
  have hr : rho (balanced (leaves s)) ≤ rho s := le_of_not_gt hn
  have h := log_minimum (leaves s) (leaves_pos s) (rho_pos (balanced (leaves s)))
    le_rfl s le_rfl hr
  have hlt : logValue (balanced (leaves s)) (rho (balanced (leaves s))) <
      logValue s (rho (balanced (leaves s))) := lt_of_le_of_ne h.1 (fun he => hi (h.2.mp he))
  have he : branchValue (balanced (leaves s)) (rho (balanced (leaves s))) = 1/2 :=
    (actualThreshold (balanced (leaves s))).endpoint
  have hs := (branchValue_global_bounds s ((rho_pos (balanced (leaves s))).le)).2
  have hh : logValue s (rho (balanced (leaves s))) ≤
      logValue (balanced (leaves s)) (rho (balanced (leaves s))) := by
    unfold logValue
    rw [he]
    apply Real.log_le_log (by linarith [(branchValue_global_bounds s ((rho_pos (balanced (leaves s))).le)).1])
    linarith
  exact (not_lt_of_ge hh) hlt

theorem rho_balanced_le (s : Species) : rho s ≤ rho (balanced (leaves s)) := by
  by_cases hi : ShapeIso s (balanced (leaves s))
  · exact hi.rho_eq.le
  · exact (rho_balanced_strict s hi).le

theorem rho_balanced_eq_iff (s : Species) :
    rho s = rho (balanced (leaves s)) ↔ ShapeIso s (balanced (leaves s)) := by
  constructor
  · intro he
    by_contra hi
    exact ne_of_lt (rho_balanced_strict s hi) he
  · exact ShapeIso.rho_eq

theorem eventual_balanced_minimum (k : Nat) : ∃ N : Nat, 1 ≤ N ∧
    ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
      count (balanced k) n ≤ count s n ∧
      (count (balanced k) n = count s n ↔ ShapeIso s (balanced k)) := by
  have hall : ∀ s : {s : Species // leaves s = k}, ∀ᶠ n : Nat in Filter.atTop,
      count (balanced k) n ≤ count s.1 n ∧
      (count (balanced k) n = count s.1 n ↔ ShapeIso s.1 (balanced k)) := by
    intro s
    by_cases hi : ShapeIso s.1 (balanced k)
    · exact Filter.Eventually.of_forall (fun n => ⟨(hi.count_eq n).symm.le,
        ⟨fun _ => hi,fun _ => (hi.count_eq n).symm⟩⟩)
    · have hr : rho s.1 < rho (balanced k) := by
        have h := rho_balanced_strict s.1
        rw [s.2] at h
        exact h hi
      filter_upwards [eventual_count_lt_of_rho_lt (balanced k) s.1 hr] with n hn
      exact ⟨hn.le,⟨fun he => (ne_of_lt hn he).elim,fun hh => (hi hh).elim⟩⟩
  obtain ⟨N,hN⟩ := Filter.eventually_atTop.mp (Filter.eventually_all.mpr hall)
  refine ⟨max 1 N,le_max_left _ _,?_⟩
  intro s hs n hn
  exact hN n ((le_max_right _ _).trans hn) ⟨s,hs⟩

/-- Expanded assigned component, with a cutoff chosen for each fixed positive leaf count. -/
theorem balanced_component :
    (∀ k : Nat, 0 < k → ∀ s : Species, leaves s = k →
      rho s ≤ rho (balanced k) ∧
      (rho s = rho (balanced k) ↔ ShapeIso s (balanced k)) ∧
      (¬ ShapeIso s (balanced k) → rho s < rho (balanced k))) ∧
    (∀ k : Nat, 0 < k → ∃ N : Nat, 1 ≤ N ∧
      ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
        count (balanced k) n ≤ count s n ∧
        (count (balanced k) n = count s n ↔ ShapeIso s (balanced k)) ∧
        (count (balanced k) n < count s n ↔ ¬ ShapeIso s (balanced k))) := by
  constructor
  · intro k hk s hs
    have hw := rho_balanced_le s
    have he := rho_balanced_eq_iff s
    have ht := rho_balanced_strict s
    rw [hs] at hw he ht
    exact ⟨hw,he,ht⟩
  · intro k hk
    obtain ⟨N,hN,hh⟩ := eventual_balanced_minimum k
    refine ⟨N,hN,?_⟩
    intro s hs n hn
    obtain ⟨hw,he⟩ := hh s hs n hn
    exact ⟨hw,he,⟨fun ht hi => ne_of_lt ht (he.mpr hi),
      fun hi => lt_of_le_of_ne hw (fun h => hi (he.mp h))⟩⟩

#print axioms rho_balanced_strict
#print axioms rho_balanced_le
#print axioms rho_balanced_eq_iff
#print axioms eventual_balanced_minimum
#print axioms balanced_component
end LiteralDL.BalancedStage
