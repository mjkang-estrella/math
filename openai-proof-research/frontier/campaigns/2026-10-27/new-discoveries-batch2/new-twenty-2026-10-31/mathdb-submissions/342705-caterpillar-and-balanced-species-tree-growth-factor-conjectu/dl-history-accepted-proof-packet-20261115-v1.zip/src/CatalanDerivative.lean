import ClippedCatalan
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
namespace LiteralDL

theorem hasDerivAt_catalanBranch {q : ℝ} (hq : q < 1/4) :
    HasDerivAt catalanBranch (1 / Real.sqrt (1-4*q)) q := by
  have hp : 0 < 1-4*q := by linarith
  have hs : Real.sqrt (1-4*q) ≠ 0 := (Real.sqrt_pos.mpr hp).ne'
  have hd := ((hasDerivAt_const q (1:ℝ)).sub
    ((hasDerivAt_id q).const_mul 4)).sqrt hp.ne'
  have hc := ((hasDerivAt_const q (1:ℝ)).sub hd).div_const 2
  dsimp at hc
  convert hc using 1
  · rfl
  · field_simp [hs]
    ring

noncomputable def logConjugate (x : ℝ) : ℝ :=
  Real.log (1+catalanBranch (Real.exp x-1))

theorem hasDerivAt_logConjugate {x : ℝ} (hx : 0 ≤ x)
    (hxu : x < Real.log (5/4)) :
    HasDerivAt logConjugate
      (Real.exp x / ((1+catalanBranch (Real.exp x-1))*Real.sqrt (1-4*(Real.exp x-1)))) x := by
  have he0 : 0 ≤ Real.exp x-1 := by have := Real.one_le_exp hx; linarith
  have he1 : Real.exp x-1 < 1/4 := by
    have h : Real.exp x < (5/4:ℝ) := (Real.exp_lt_exp.mpr hxu).trans_eq (Real.exp_log (by norm_num))
    linarith
  have hc := catalanBranch_global_bounds he0
  have hn : 1+catalanBranch (Real.exp x-1) ≠ 0 := by linarith
  have hd := (hasDerivAt_catalanBranch he1).comp x ((Real.hasDerivAt_exp x).sub_const 1)
  have hl := ((hasDerivAt_const x (1:ℝ)).add hd).log hn
  convert hl using 1
  · rfl
  · dsimp
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring

#print axioms hasDerivAt_logConjugate
end LiteralDL
