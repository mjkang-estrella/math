import CardinalRecurrence
namespace LiteralDL

def extantCount : EventTree → Nat
  | .tip _ .extant => 1
  | .tip _ _ => 0
  | .fork _ _ x y => extantCount x + extantCount y

theorem encode_size {s} (h : Hist s) (p) : extantCount (encode p h) = size h := by
  induction h generalizing p <;> simp_all [encode, extantCount, size]

noncomputable def sourceFiberEquiv (s : Species) (n : Nat) (p : List Bool) :
    Fiber s n ≃ {t : EventTree // Valid s p t ∧ extantCount t = n} :=
  Equiv.ofBijective (fun h => ⟨encode p h.1, encode_valid h.1 p,
    (encode_size h.1 p).trans h.2⟩)
    ⟨fun _ _ h => Subtype.ext (encode_injective p (congrArg Subtype.val h)),
     fun t => by
       obtain ⟨h, hh⟩ := valid_has_history t.2.1
       refine ⟨⟨h, ?_⟩, Subtype.ext hh⟩
       rw [← encode_size h p, hh]
       exact t.2.2⟩

def swapRoot {a b} : Hist (.node a b) → Hist (.node b a)
  | .dup x y => .dup (swapRoot x) (swapRoot y)
  | .both x y => .both y x
  | .keepLeft x => .keepRight x
  | .keepRight y => .keepLeft y

theorem swapRoot_size {a b} (h : Hist (.node a b)) : size (swapRoot h) = size h := by
  cases h with
  | dup x y => simp [swapRoot, size, swapRoot_size x, swapRoot_size y]
  | both x y => simp [swapRoot, size, Nat.add_comm]
  | keepLeft x => simp [swapRoot, size]
  | keepRight y => simp [swapRoot, size]

theorem swapRoot_twice {a b} (h : Hist (.node a b)) : swapRoot (swapRoot h) = h := by
  cases h with
  | dup x y => simp [swapRoot, swapRoot_twice x, swapRoot_twice y]
  | both x y => simp [swapRoot]
  | keepLeft x => simp [swapRoot]
  | keepRight y => simp [swapRoot]

def swapFiber (a b : Species) (n : Nat) : Fiber (.node a b) n ≃ Fiber (.node b a) n where
  toFun h := ⟨swapRoot h.1, (swapRoot_size h.1).trans h.2⟩
  invFun h := ⟨swapRoot h.1, (swapRoot_size h.1).trans h.2⟩
  left_inv h := Subtype.ext (swapRoot_twice h.1)
  right_inv h := Subtype.ext (swapRoot_twice h.1)

theorem count_swap (a b : Species) (n : Nat) : count (.node a b) n = count (.node b a) n :=
  Fintype.card_congr (swapFiber a b n)

theorem count_zero (s : Species) : count s 0 = 0 := by
  let := fiber_zero_empty s
  exact Fintype.card_of_isEmpty

#print axioms sourceFiberEquiv
#print axioms count_swap
#print axioms count_zero
#print axioms count_pos
end LiteralDL
