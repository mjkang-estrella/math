import FinalAssembly
namespace IndependentReplay
open LiteralDL LiteralDL.FinalStage Filter

/-- Actual event cardinalities: no recurrence or packaged SourceTarget in this type. -/
theorem actual_event_four_claims :
  (∀ k : Nat, 0 < k → ∃ N : Nat, 1 ≤ N ∧
    ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
      Nat.card {t : EventTree // Valid (balanced k) [] t ∧ extantCount t = n} ≤
        Nat.card {t : EventTree // Valid s [] t ∧ extantCount t = n} ∧
      Nat.card {t : EventTree // Valid s [] t ∧ extantCount t = n} ≤
        Nat.card {t : EventTree // Valid (caterpillar k) [] t ∧ extantCount t = n} ∧
      (Nat.card {t : EventTree // Valid (balanced k) [] t ∧ extantCount t = n} =
        Nat.card {t : EventTree // Valid s [] t ∧ extantCount t = n} ↔
        ShapeIso s (balanced k)) ∧
      (Nat.card {t : EventTree // Valid s [] t ∧ extantCount t = n} =
        Nat.card {t : EventTree // Valid (caterpillar k) [] t ∧ extantCount t = n} ↔
        ShapeIso s (caterpillar k))) ∧
  (∀ s : Species, 0 < growth s ∧
    Tendsto (fun n : Nat =>
      (Nat.card {t : EventTree // Valid s [] t ∧ extantCount t = n} : ℝ) ^ (1/(n:ℝ)))
      atTop (nhds (growth s)) ∧ growth s = (rho s)⁻¹) ∧
  Tendsto (fun k : Nat => growth (caterpillar k)/(k:ℝ)) atTop atTop ∧
  (∀ k : Nat, 0 < k → 2*(k:ℝ) ≤ growth (balanced k) ∧
    growth (balanced k) ≤ 1000*(k:ℝ)) := by
  obtain ⟨extrema, limits, caterpillarRate, balancedBounds⟩ :=
    source_event_four_claims_expanded
  refine ⟨?_, ?_, caterpillarRate, balancedBounds⟩
  · intro k hk
    obtain ⟨N, hN, allSpecies⟩ := extrema k hk
    refine ⟨N, hN, ?_⟩
    intro s hs n hn
    simpa only [sourceCard] using allSpecies s hs n hn
  · intro s
    simpa only [sourceCard] using limits s

#print actual_event_four_claims
#print axioms actual_event_four_claims
end IndependentReplay
