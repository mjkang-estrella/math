import BranchGlobal
import SpeciesShapes
namespace LiteralDL.GrowthStage
open LiteralDL

theorem leaf_quadratic {z : ℝ} (hz : 0 ≤ z) (hr : z ≤ rho .leaf) :
    z + branchValue .leaf z * branchValue .leaf z = branchValue .leaf z := by
  have hq : rho .leaf ≤ 1/4 := (actualThreshold .leaf).quarter
  exact (catalanBranch_properties hz (hr.trans hq)).2.2

theorem leaf_mass (s : Species) {z : ℝ} (hz : 0 ≤ z) (hr : z ≤ rho s) :
    (leaves s : ℝ) * z ≤ branchValue s z := by
  induction s with
  | leaf =>
    have h := leaf_quadratic hz hr
    simp only [leaves, Nat.cast_one, one_mul]
    nlinarith [sq_nonneg (branchValue .leaf z)]
  | node a b ia ib =>
    have ha := hr.trans (rho_node_lt_left a b).le
    have hb := hr.trans (rho_node_lt_right a b).le
    have h := branch_node_quadratic a b hz hr
    have hn := mul_nonneg (branchValue_nonneg hz ha) (branchValue_nonneg hz hb)
    have ia' := ia ha
    have ib' := ib hb
    simp only [leaves, Nat.cast_add]
    nlinarith [sq_nonneg (branchValue (.node a b) z)]

theorem growth_lower (s : Species) : 2 * (leaves s : ℝ) ≤ growth s := by
  have h := leaf_mass s (rho_pos s).le le_rfl
  have he : branchValue s (rho s) = 1/2 := (actualThreshold s).endpoint
  have hg := growth_mul_rho_ge s
  have heq := growth_mul_rho_le s
  nlinarith [rho_pos s]
end LiteralDL.GrowthStage
