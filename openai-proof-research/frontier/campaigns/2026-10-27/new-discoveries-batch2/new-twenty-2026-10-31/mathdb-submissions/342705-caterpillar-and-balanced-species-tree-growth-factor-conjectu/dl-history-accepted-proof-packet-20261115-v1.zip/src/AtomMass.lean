import SourceWeighted
open scoped ENNReal
namespace LiteralDL

def atomNodeEquiv (a b : Species) : Atom (.node a b) ≃
    (Hist a ⊕ (Hist b ⊕ (Hist a × Hist b))) where
  toFun q := match q with
    | .keepLeft x => .inl x
    | .keepRight y => .inr (.inl y)
    | .both x y => .inr (.inr (x,y))
  invFun q := match q with
    | .inl x => .keepLeft x
    | .inr (.inl y) => .keepRight y
    | .inr (.inr xy) => .both xy.1 xy.2
  left_inv q := by cases q <;> rfl
  right_inv q := by rcases q with x | (y | ⟨x,y⟩) <;> rfl

theorem atomMass_node (a b : Species) (z : ℝ≥0∞) :
    (∑' q : Atom (.node a b), z ^ size (atomHist q)) =
      historySum a z + historySum b z + historySum a z * historySum b z := by
  rw [← (atomNodeEquiv a b).symm.tsum_eq (fun q => z ^ size (atomHist q))]
  rw [ENNReal.summable.tsum_sum ENNReal.summable]
  rw [ENNReal.summable.tsum_sum ENNReal.summable]
  change (∑' x : Hist a, z ^ size x) +
    ((∑' y : Hist b, z ^ size y) + (∑' xy : Hist a × Hist b, z ^ (size xy.1 + size xy.2))) = _
  simp_rw [pow_add]
  rw [ENNReal.tsum_prod']
  simp_rw [ENNReal.tsum_mul_left]
  rw [ENNReal.tsum_mul_right]
  exact (add_assoc _ _ _).symm

theorem total_eq_of_mass_eq {α β : Type} (f : α → ℝ≥0∞) (g : β → ℝ≥0∞)
    (h : (∑' a, f a) = ∑' b, g b) : total f = total g := by
  apply le_antisymm
  · apply total_le_of_prefixed
    rw [h]
    exact (total_quadratic g).ge
  · apply total_le_of_prefixed
    rw [← h]
    exact (total_quadratic f).ge

#print axioms atomNodeEquiv
#print axioms atomMass_node
#print axioms total_eq_of_mass_eq
end LiteralDL
