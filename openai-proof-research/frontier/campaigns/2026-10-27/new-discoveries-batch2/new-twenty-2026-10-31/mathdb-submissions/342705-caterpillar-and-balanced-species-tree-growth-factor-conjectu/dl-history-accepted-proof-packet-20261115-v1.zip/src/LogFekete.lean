import ThresholdFacts
import Mathlib.Analysis.Subadditive
import Mathlib.Analysis.SpecialFunctions.Log.Basic
namespace LiteralDL
noncomputable def negativeLogCount (s : Species) (n : Nat) : ℝ :=
  if n = 0 then 0 else -Real.log (count s n)

theorem count_cast_pos {s : Species} {n : Nat} (hn : n ≠ 0) : 0 < (count s n : ℝ) := by
  obtain ⟨m,rfl⟩ := Nat.exists_eq_succ_of_ne_zero hn
  exact_mod_cast count_pos s m

theorem negativeLogCount_subadditive (s : Species) : Subadditive (negativeLogCount s) := by
  intro m n
  by_cases hm : m = 0
  · simp [hm, negativeLogCount]
  by_cases hn : n = 0
  · simp [hn, negativeLogCount]
  have hm0 : 0 < (count s m : ℝ) := count_cast_pos hm
  have hn0 : 0 < (count s n : ℝ) := count_cast_pos hn
  have hmul : (count s m : ℝ) * count s n ≤ count s (m+n) := by
    exact_mod_cast supermultiplicative s m n
  have hl := Real.log_le_log (mul_pos hm0 hn0) hmul
  rw [Real.log_mul hm0.ne' hn0.ne'] at hl
  have hmn : m+n ≠ 0 := by omega
  simp only [negativeLogCount, ite_eq_right hm, ite_eq_right hn, ite_eq_right hmn]
  linarith

theorem negativeLogCount_bddBelow (s : Species) :
    BddBelow (Set.range (fun n : Nat => negativeLogCount s n / n)) := by
  refine ⟨Real.log (rho s), ?_⟩
  intro y hy
  obtain ⟨n,rfl⟩ := hy
  by_cases hn : n = 0
  · simp only [hn, negativeLogCount, Nat.cast_zero, div_zero]
    exact Real.log_nonpos (rho_pos s).le (by have := (actualThreshold s).quarter; change rho s ≤ 1/4 at this; linarith)
  have hc := count_cast_pos (s := s) hn
  have hr := rho_pos s
  have hb : (count s n : ℝ) * rho s ^ n ≤ 1 := le_trans (count_exponential_bound s n) (by norm_num)
  have hl := Real.log_le_log (mul_pos hc (pow_pos hr n)) hb
  rw [Real.log_mul hc.ne' (pow_pos hr n).ne', Real.log_pow, Real.log_one] at hl
  have hn0 : 0 < (n : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hn
  change Real.log (rho s) ≤ negativeLogCount s n / (n : ℝ)
  simp only [negativeLogCount, ite_eq_right hn]
  apply (le_div_iff₀ hn0).mpr
  nlinarith

theorem negativeLogCount_tendsto (s : Species) :
    Filter.Tendsto (fun n : Nat => negativeLogCount s n / n) Filter.atTop
      (nhds (negativeLogCount_subadditive s).lim) :=
  (negativeLogCount_subadditive s).tendsto_lim (negativeLogCount_bddBelow s)

#print axioms negativeLogCount_subadditive
#print axioms negativeLogCount_bddBelow
#print axioms negativeLogCount_tendsto
end LiteralDL
