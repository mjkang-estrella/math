import LiteralHistory
import SourceHistory
import SourceFiber
import CardinalRecurrence
import DuplicationSkeleton
import WeightedSkeleton
import LeastFixedPoint
import SourceWeighted
import EndpointAudit
import AtomMass
import ScalarBranch
import ScalarEvaluation
import HistoryEvaluation
import BranchRegularity
import HistoryOrder
import ActualThreshold
import ThresholdFacts
import LogFekete
import ActualRootLimit
import GeometricBridge
import ThresholdIdentity
import SpeciesShapes
import FiniteShapes
import StrictChildThreshold
import ThresholdUniqueness
import ClosureAudit
import ShapeTransport
import CatalanAssociator
import BranchDomain
import ClippedCatalan
import RealAssociator
import BranchGlobal
import CaterpillarOrder
import StrictRotation
import StrictMerge
import CaterpillarSplit
import StrictExtension
import StrictCaterpillar
import CatalanDerivative
import ConjugateSlope
import LogConjugateConvex
import CaterpillarCounts
import LeafExpansion
import BalancedExpansion
import LogConjugateExpansive
import ProgressAudit
import BalancedFinalDiscrete
import BalancedFinalSplit
import BalancedFinalValues
import BalancedFinalOrder
import BalancedFinalExtremum

#print axioms LiteralDL.Species
#print axioms LiteralDL.weight
#print axioms LiteralDL.weight_pos
#print axioms LiteralDL.Hist
#print axioms LiteralDL.size
#print axioms LiteralDL.size_pos
#print axioms LiteralDL.depth
#print axioms LiteralDL.depth_bound
#print axioms LiteralDL.pool
#print axioms LiteralDL.mem_pool
#print axioms LiteralDL.Fiber
#print axioms LiteralDL.count
#print axioms LiteralDL.duplicate
#print axioms LiteralDL.duplicate_injective
#print axioms LiteralDL.supermultiplicative
#print axioms LiteralDL.fiber_zero_empty
#print axioms LiteralDL.one
#print axioms LiteralDL.positiveFiber
#print axioms LiteralDL.count_pos
#print axioms LiteralDL.Event
#print axioms LiteralDL.EventTree
#print axioms LiteralDL.encode
#print axioms LiteralDL.Valid
#print axioms LiteralDL.encode_valid
#print axioms LiteralDL.valid_has_history
#print axioms LiteralDL.encode_ne_loss
#print axioms LiteralDL.encode_injective
#print axioms LiteralDL.sourceEquiv
#print axioms LiteralDL.extantCount
#print axioms LiteralDL.encode_size
#print axioms LiteralDL.sourceFiberEquiv
#print axioms LiteralDL.swapRoot
#print axioms LiteralDL.swapRoot_size
#print axioms LiteralDL.swapRoot_twice
#print axioms LiteralDL.swapFiber
#print axioms LiteralDL.count_swap
#print axioms LiteralDL.count_zero
#print axioms LiteralDL.PairFiber
#print axioms LiteralDL.Split
#print axioms LiteralDL.splitEquiv
#print axioms LiteralDL.pairCount
#print axioms LiteralDL.NodeRoot
#print axioms LiteralDL.nodeJoin
#print axioms LiteralDL.nodeCut
#print axioms LiteralDL.nodeEquiv
#print axioms LiteralDL.count_node
#print axioms LiteralDL.pairCount_eq
#print axioms LiteralDL.LeafRoot
#print axioms LiteralDL.leafJoin
#print axioms LiteralDL.leafCut
#print axioms LiteralDL.leafEquiv
#print axioms LiteralDL.count_leaf
#print axioms LiteralDL.count_node_convolution
#print axioms LiteralDL.Skeleton
#print axioms LiteralDL.Atom
#print axioms LiteralDL.atomHist
#print axioms LiteralDL.assemble
#print axioms LiteralDL.cutSkeleton
#print axioms LiteralDL.assemble_cut
#print axioms LiteralDL.cut_assemble
#print axioms LiteralDL.skeletonEquiv
#print axioms LiteralDL.skeletonSize
#print axioms LiteralDL.assemble_size
#print axioms LiteralDL.rootEquiv
#print axioms LiteralDL.skWeight
#print axioms LiteralDL.total
#print axioms LiteralDL.total_quadratic
#print axioms LiteralDL.historySum
#print axioms LiteralDL.skWeight_pow
#print axioms LiteralDL.historySum_skeleton
#print axioms LiteralDL.skHeight
#print axioms LiteralDL.cutWeight
#print axioms LiteralDL.cutTotal
#print axioms LiteralDL.cutWeight_fork
#print axioms LiteralDL.cutTotal_succ
#print axioms LiteralDL.cutTotal_zero
#print axioms LiteralDL.cutTotal_bound
#print axioms LiteralDL.total_le_of_prefixed
#print axioms LiteralDL.sizeEquiv
#print axioms LiteralDL.historySum_coeff
#print axioms LiteralDL.historySum_le_of_atom_prefixed
#print axioms LiteralDL.atomNodeEquiv
#print axioms LiteralDL.atomMass_node
#print axioms LiteralDL.total_eq_of_mass_eq
#print axioms LiteralDL.catalanBranch
#print axioms LiteralDL.catalanBranch_properties
#print axioms LiteralDL.total_principal
#print axioms LiteralDL.total_infinite_above
#print axioms LiteralDL.atomMass_leaf
#print axioms LiteralDL.historySum_leaf_principal
#print axioms LiteralDL.historySum_leaf_infinite
#print axioms LiteralDL.historySum_node_principal
#print axioms LiteralDL.branchValue
#print axioms LiteralDL.continuous_catalanBranch
#print axioms LiteralDL.branchValue_continuous
#print axioms LiteralDL.catalanBranch_zero
#print axioms LiteralDL.catalanBranch_quarter
#print axioms LiteralDL.branchValue_zero
#print axioms LiteralDL.catalanBranch_strictMono
#print axioms LiteralDL.mass_le_total
#print axioms LiteralDL.historySum_node_ge_left
#print axioms LiteralDL.historySum_node_ge_right
#print axioms LiteralDL.historySum_mono
#print axioms LiteralDL.historySum_node_infinite
#print axioms LiteralDL.ActualThreshold
#print axioms LiteralDL.leafThreshold
#print axioms LiteralDL.nodeThreshold
#print axioms LiteralDL.actualThreshold
#print axioms LiteralDL.rho
#print axioms LiteralDL.rho_pos
#print axioms LiteralDL.historySum_at_rho
#print axioms LiteralDL.historySum_finite_iff
#print axioms LiteralDL.count_exponential_bound
#print axioms LiteralDL.negativeLogCount
#print axioms LiteralDL.count_cast_pos
#print axioms LiteralDL.negativeLogCount_subadditive
#print axioms LiteralDL.negativeLogCount_bddBelow
#print axioms LiteralDL.negativeLogCount_tendsto
#print axioms LiteralDL.growth
#print axioms LiteralDL.growth_pos
#print axioms LiteralDL.actual_root_limit
#print axioms LiteralDL.count_le_growth_pow
#print axioms LiteralDL.finite_below_growth
#print axioms LiteralDL.growth_mul_rho_le
#print axioms LiteralDL.growth_mul_rho_ge
#print axioms LiteralDL.growth_eq_inv_rho
#print axioms LiteralDL.leaves
#print axioms LiteralDL.leaves_pos
#print axioms LiteralDL.caterpillar
#print axioms LiteralDL.balanced
#print axioms LiteralDL.leaves_caterpillar
#print axioms LiteralDL.leaves_balanced
#print axioms LiteralDL.ShapeIso
#print axioms LiteralDL.speciesPool
#print axioms LiteralDL.mem_speciesPool
#print axioms LiteralDL.historySum_node_quadratic
#print axioms LiteralDL.rho_node_lt_left
#print axioms LiteralDL.rho_eq_of_historySum_eq
#print axioms LiteralDL.rho_swap
#print axioms LiteralDL.rho_node_lt_right
#print axioms LiteralDL.ShapeIso.refl
#print axioms LiteralDL.ShapeIso.symm
#print axioms LiteralDL.ShapeIso.trans
#print axioms LiteralDL.count_node_congr
#print axioms LiteralDL.ShapeIso.count_eq
#print axioms LiteralDL.ShapeIso.leaves_eq
#print axioms LiteralDL.ShapeIso.rho_eq
#print axioms LiteralDL.catalan_associator_identity
#print axioms LiteralDL.catalan_associator_strict
#print axioms LiteralDL.branchValue_nonneg
#print axioms LiteralDL.branchValue_pos
#print axioms LiteralDL.branchValue_lt_half
#print axioms LiteralDL.branch_node_quadratic
#print axioms LiteralDL.catalanBranch_global_bounds
#print axioms LiteralDL.catalanBranch_saturated
#print axioms LiteralDL.catalanBranch_mono
#print axioms LiteralDL.mergeValue
#print axioms LiteralDL.mergeValue_nonneg
#print axioms LiteralDL.mergeValue_half
#print axioms LiteralDL.mergeValue_mono
#print axioms LiteralDL.mergeValue_comm
#print axioms LiteralDL.mergeValue_ge_left
#print axioms LiteralDL.mergeValue_associator
#print axioms LiteralDL.branchValue_global_bounds
#print axioms LiteralDL.branchValue_ge_leaf
#print axioms LiteralDL.rho_le_of_global_branch_le
#print axioms LiteralDL.caterpillar_succ
#print axioms LiteralDL.caterpillar_merge_le
#print axioms LiteralDL.branchValue_le_caterpillar
#print axioms LiteralDL.rho_caterpillar_le
#print axioms LiteralDL.branch_node_gt_left
#print axioms LiteralDL.branch_nonleaf_gt_leaf
#print axioms LiteralDL.rho_rotation_le
#print axioms LiteralDL.rho_rotation_lt
#print axioms LiteralDL.mergeValue_input_lt
#print axioms LiteralDL.mergeValue_strict
#print axioms LiteralDL.mergeValue_associator_lt
#print axioms LiteralDL.caterpillar_ne_leaf
#print axioms LiteralDL.rho_caterpillar_split_lt
#print axioms LiteralDL.caterpillar_merge_lt
#print axioms LiteralDL.ShapeIso.branch_eq
#print axioms LiteralDL.node_input_le_quarter
#print axioms LiteralDL.strict_leaf_extension
#print axioms LiteralDL.leaves_ge_two_of_nonleaf
#print axioms LiteralDL.caterpillar_dichotomy
#print axioms LiteralDL.rho_caterpillar_strict
#print axioms LiteralDL.hasDerivAt_catalanBranch
#print axioms LiteralDL.logConjugate
#print axioms LiteralDL.hasDerivAt_logConjugate
#print axioms LiteralDL.conjugateSlope
#print axioms LiteralDL.conjugateSlope_den_pos
#print axioms LiteralDL.conjugateSlope_gt_one
#print axioms LiteralDL.conjugateSlope_strictMono
#print axioms LiteralDL.deriv_logConjugate
#print axioms LiteralDL.conjugate_input_nonneg
#print axioms LiteralDL.conjugate_input_lt
#print axioms LiteralDL.logConjugate_continuousOn
#print axioms LiteralDL.logConjugate_strictConvex
#print axioms LiteralDL.eventual_count_lt_of_growth_lt
#print axioms LiteralDL.eventual_count_lt_of_rho_lt
#print axioms LiteralDL.eventual_caterpillar_maximum
#print axioms LiteralDL.LeafExpansion
#print axioms LiteralDL.LeafExpansion.global_le
#print axioms LiteralDL.LeafExpansion.strict_value
#print axioms LiteralDL.LeafExpansion.rho_lt
#print axioms LiteralDL.balanced_node
#print axioms LiteralDL.balanced_successor_expansion
#print axioms LiteralDL.rho_balanced_successor_lt
#print axioms LiteralDL.logConjugate_zero
#print axioms LiteralDL.conjugate_branch_interior
#print axioms LiteralDL.logConjugate_minus_id_strictMono
#print axioms LiteralDL.logConjugate_expansive
#print axioms LiteralDL.BalancedStage.strict_midpoint
#print axioms LiteralDL.BalancedStage.discrete_convex
#print axioms LiteralDL.BalancedStage.delta_lt
#print axioms LiteralDL.BalancedStage.split_ordered
#print axioms LiteralDL.BalancedStage.split_min
#print axioms LiteralDL.BalancedStage.logValue
#print axioms LiteralDL.BalancedStage.logValue_nonneg
#print axioms LiteralDL.BalancedStage.logValue_pos
#print axioms LiteralDL.BalancedStage.exp_logValue
#print axioms LiteralDL.BalancedStage.exp_log_pair
#print axioms LiteralDL.BalancedStage.logValue_node
#print axioms LiteralDL.BalancedStage.logValue_input_mem
#print axioms LiteralDL.BalancedStage.balanced_radius_antitone
#print axioms LiteralDL.BalancedStage.balanced_log_discrete
#print axioms LiteralDL.BalancedStage.conjugate_le
#print axioms LiteralDL.BalancedStage.conjugate_eq_iff
#print axioms LiteralDL.BalancedStage.log_minimum
#print axioms LiteralDL.BalancedStage.rho_balanced_strict
#print axioms LiteralDL.BalancedStage.rho_balanced_le
#print axioms LiteralDL.BalancedStage.rho_balanced_eq_iff
#print axioms LiteralDL.BalancedStage.eventual_balanced_minimum
#print axioms LiteralDL.BalancedStage.balanced_component

#print axioms LiteralDL.fiberFintype
#print axioms LiteralDL.pairFintype
#print axioms LiteralDL.fixedLeavesFintype
