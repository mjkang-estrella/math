import BalancedFinalValues
namespace LiteralDL.BalancedStage
open LiteralDL

theorem conjugate_le {x y : ℝ}
    (hx : x ∈ Set.Icc 0 (Real.log (5/4)))
    (hy : y ∈ Set.Icc 0 (Real.log (5/4))) (hxy : x ≤ y) :
    logConjugate x ≤ logConjugate y := by
  rcases lt_or_eq_of_le hxy with h|h
  · have he := logConjugate_expansive hx hy h
    linarith
  · rw [h]

theorem conjugate_eq_iff {x y : ℝ}
    (hx : x ∈ Set.Icc 0 (Real.log (5/4)))
    (hy : y ∈ Set.Icc 0 (Real.log (5/4))) (hxy : x ≤ y) :
    logConjugate x = logConjugate y ↔ x=y := by
  constructor
  · intro he
    by_contra hn
    have hh := logConjugate_expansive hx hy (lt_of_le_of_ne hxy hn)
    linarith
  · rintro rfl; rfl

theorem log_minimum (K : Nat) (hK : 1 ≤ K) {z : ℝ} (hz : 0 < z)
    (hr : z ≤ rho (balanced K)) (s : Species) (hs : leaves s ≤ K)
    (hrs : z ≤ rho s) :
    logValue (balanced (leaves s)) z ≤ logValue s z ∧
    (logValue (balanced (leaves s)) z = logValue s z ↔ ShapeIso s (balanced (leaves s))) := by
  induction s with
  | leaf => simp only [leaves,balanced]; exact ⟨le_rfl,⟨fun _ => .leaf,fun _ => trivial⟩⟩
  | node a b ia ib =>
    have ha := leaves_pos a
    have hb := leaves_pos b
    have hsa : leaves a ≤ K := by simp only [leaves] at hs; omega
    have hsb : leaves b ≤ K := by simp only [leaves] at hs; omega
    have hra := hrs.trans (rho_node_lt_left a b).le
    have hrb := hrs.trans (rho_node_lt_right a b).le
    obtain ⟨ha_le,ha_eq⟩ := ia hsa hra
    obtain ⟨hb_le,hb_eq⟩ := ib hsb hrb
    have htotal : leaves a+leaves b ≤ K := hs
    have htwo : 2 ≤ leaves a+leaves b := by omega
    have hsplit := split_min (fun n => logValue (balanced n) z) K
      (balanced_log_discrete hK hz hr) (by omega : 1 ≤ leaves a) (by omega : 1 ≤ leaves b) htotal
    have hleft := logValue_input_mem (balanced ((leaves a+leaves b)/2))
      (balanced ((leaves a+leaves b+1)/2)) hz.le
    have hbal := balanced_node htwo
    rw [← hbal] at hleft
    have hleft' := hleft (hr.trans (balanced_radius_antitone (by omega) htotal))
    have hright := logValue_input_mem a b hz.le hrs
    have hsum : logValue (balanced ((leaves a+leaves b)/2)) z +
        logValue (balanced ((leaves a+leaves b+1)/2)) z ≤ logValue a z+logValue b z := by
      linarith [hsplit.1]
    have hle := conjugate_le hleft' hright hsum
    have heq := conjugate_eq_iff hleft' hright hsum
    have hroot : logValue (balanced (leaves (.node a b))) z =
        logConjugate (logValue (balanced ((leaves a+leaves b)/2)) z+
          logValue (balanced ((leaves a+leaves b+1)/2)) z) := by
      rw [leaves,balanced_node htwo,logValue_node _ _ hz.le]
    rw [hroot,logValue_node a b hz.le]
    refine ⟨hle,⟨?_,?_⟩⟩
    · intro he
      have hin := heq.mp he
      have hae : logValue (balanced (leaves a)) z = logValue a z := by linarith [hsplit.1]
      have hbe : logValue (balanced (leaves b)) z = logValue b z := by linarith [hsplit.1]
      have hse : logValue (balanced ((leaves a+leaves b)/2)) z+
          logValue (balanced ((leaves a+leaves b+1)/2)) z =
          logValue (balanced (leaves a)) z+logValue (balanced (leaves b)) z := by linarith
      obtain ⟨hab,hba⟩ := hsplit.2.mp hse
      have hai := ha_eq.mp hae
      have hbi := hb_eq.mp hbe
      simp only [leaves]
      rw [balanced_node htwo]
      rcases le_total (leaves a) (leaves b) with h|h
      · have e0 : (leaves a+leaves b)/2=leaves a := by omega
        have e1 : (leaves a+leaves b+1)/2=leaves b := by omega
        rw [e0,e1]
        exact .node hai hbi
      · have e0 : (leaves a+leaves b)/2=leaves b := by omega
        have e1 : (leaves a+leaves b+1)/2=leaves a := by omega
        rw [e0,e1]
        exact .swap hai hbi
    · intro hi
      have he : logValue (balanced (leaves (.node a b))) z = logValue (.node a b) z := by
        unfold logValue
        rw [hi.branch_eq]
      rwa [hroot,logValue_node a b hz.le] at he

#print axioms log_minimum
end LiteralDL.BalancedStage
