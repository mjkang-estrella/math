import LogFekete
import Mathlib.Analysis.SpecialFunctions.Pow.Real
namespace LiteralDL
noncomputable def growth (s : Species) : ℝ := Real.exp (-(negativeLogCount_subadditive s).lim)

theorem growth_pos (s : Species) : 0 < growth s := Real.exp_pos _

theorem actual_root_limit (s : Species) :
    Filter.Tendsto (fun n : Nat => (count s n : ℝ) ^ (1 / (n : ℝ)))
      Filter.atTop (nhds (growth s)) := by
  have h := (Real.continuous_exp.tendsto (-(negativeLogCount_subadditive s).lim)).comp
    (negativeLogCount_tendsto s).neg
  apply h.congr'
  apply Filter.eventually_atTop.mpr
  refine ⟨1, fun n hn => ?_⟩
  have hn0 : n ≠ 0 := by omega
  change Real.exp (-(negativeLogCount s n / (n : ℝ))) = (count s n : ℝ) ^ (1 / (n : ℝ))
  rw [Real.rpow_def_of_pos (count_cast_pos (s := s) hn0)]
  apply congrArg Real.exp
  simp only [negativeLogCount, ite_eq_right hn0]
  ring

#print axioms growth_pos
#print axioms actual_root_limit
end LiteralDL
