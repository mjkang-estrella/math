import StrictExtension
namespace LiteralDL

theorem leaves_ge_two_of_nonleaf {s : Species} (hs : s ≠ .leaf) : 2 ≤ leaves s := by
  cases s with
  | leaf => exact (hs rfl).elim
  | node a b => have := leaves_pos a; have := leaves_pos b; simp only [leaves]; omega

theorem caterpillar_dichotomy (s : Species) :
    ShapeIso s (caterpillar (leaves s)) ∨
      (rho (caterpillar (leaves s)) < rho s ∧
        ∀ z : ℝ, 0 < z → z < rho (caterpillar (leaves s)) →
          branchValue s z < branchValue (caterpillar (leaves s)) z) := by
  induction s with
  | leaf => exact Or.inl .leaf
  | node a b ia ib =>
    by_cases ha : a = .leaf
    · subst a
      have he : caterpillar (leaves (.node .leaf b)) = .node (caterpillar (leaves b)) .leaf := by
        rw [leaves,show leaves .leaf + leaves b = leaves b+1 by simp [leaves,Nat.add_comm],
          caterpillar_succ (leaves_pos b)]
      rw [he]
      rcases ib with hi | hs
      · exact Or.inl (.swap .leaf hi)
      · right
        have h := strict_leaf_extension b (caterpillar (leaves b))
          (fun _ hz => branchValue_le_caterpillar b hz) hs.2
        constructor
        · rw [rho_swap .leaf b]; exact h.1
        · intro z hz hr
          have hswap : branchValue (.node .leaf b) z = branchValue (.node b .leaf) z :=
            mergeValue_comm _ _
          rw [hswap]
          exact h.2 z hz hr
    · by_cases hb : b = .leaf
      · subst b
        have he : caterpillar (leaves (.node a .leaf)) = .node (caterpillar (leaves a)) .leaf := by
          rw [leaves,show leaves a + leaves .leaf = leaves a+1 by rfl,
            caterpillar_succ (leaves_pos a)]
        rw [he]
        rcases ia with hi | hs
        · exact Or.inl (.node hi .leaf)
        · exact Or.inr (strict_leaf_extension a (caterpillar (leaves a))
            (fun _ hz => branchValue_le_caterpillar a hz) hs.2)
      · right
        have hla := leaves_ge_two_of_nonleaf ha
        have hlb := leaves_ge_two_of_nonleaf hb
        have hglob : ∀ z : ℝ, 0 ≤ z → branchValue (.node a b) z ≤
            branchValue (.node (caterpillar (leaves a)) (caterpillar (leaves b))) z := by
          intro z hz
          exact mergeValue_mono (branchValue_global_bounds a hz).1
            (branchValue_global_bounds b hz).1 (branchValue_le_caterpillar a hz)
            (branchValue_le_caterpillar b hz)
        constructor
        · exact (rho_caterpillar_split_lt hla hlb).trans_le
            (rho_le_of_global_branch_le _ _ hglob)
        · intro z hz hr
          exact (hglob z hz.le).trans_lt (caterpillar_merge_lt hla hlb hz hr)

theorem rho_caterpillar_strict (s : Species)
    (hs : ¬ ShapeIso s (caterpillar (leaves s))) :
    rho (caterpillar (leaves s)) < rho s := by
  rcases caterpillar_dichotomy s with hi | hi
  · exact (hs hi).elim
  · exact hi.1

#print axioms caterpillar_dichotomy
#print axioms rho_caterpillar_strict
end LiteralDL
