import SpeciesShapes
namespace LiteralDL

def speciesPool : Nat → List Species
  | 0 => []
  | d+1 => .leaf :: ((speciesPool d).product (speciesPool d)).map (fun p => .node p.1 p.2)

theorem mem_speciesPool (s : Species) (d : Nat) (hd : leaves s ≤ d) : s ∈ speciesPool d := by
  induction d generalizing s with
  | zero => have := leaves_pos s; omega
  | succ d ih =>
    cases s with
    | leaf => simp [speciesPool]
    | node a b =>
      have ha := leaves_pos a
      have hb := leaves_pos b
      have h1 : leaves a ≤ d := by simp only [leaves] at hd; omega
      have h2 : leaves b ≤ d := by simp only [leaves] at hd; omega
      have hma := ih a h1
      have hmb := ih b h2
      simp only [speciesPool, List.mem_cons, List.mem_map]
      right
      exact ⟨(a,b), List.mem_product.mpr ⟨hma,hmb⟩,rfl⟩

instance fixedLeavesFintype (k : Nat) : Fintype {s : Species // leaves s = k} :=
  Fintype.ofFinset ((speciesPool k).toFinset.filter (fun s => leaves s = k))
    (by intro s; simp only [Finset.mem_filter, List.mem_toFinset]
        exact ⟨fun h => h.2, fun h => ⟨mem_speciesPool s k h.le,h⟩⟩)

#print axioms fixedLeavesFintype
end LiteralDL
