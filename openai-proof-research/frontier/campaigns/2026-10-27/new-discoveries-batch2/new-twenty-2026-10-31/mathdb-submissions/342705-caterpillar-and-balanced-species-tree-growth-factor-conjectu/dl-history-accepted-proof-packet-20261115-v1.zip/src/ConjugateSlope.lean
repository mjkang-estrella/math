import CatalanDerivative
namespace LiteralDL
noncomputable def conjugateSlope (u : ℝ) : ℝ := (1+u-u*u)/(1-u-2*u*u)

theorem conjugateSlope_den_pos {u : ℝ} (hu : 0 ≤ u) (hh : u < 1/2) :
    0 < 1-u-2*u*u := by
  have h : 0 < (1+u)*(1-2*u) := mul_pos (by linarith) (by linarith)
  nlinarith

theorem conjugateSlope_gt_one {u : ℝ} (hu : 0 < u) (hh : u < 1/2) :
    1 < conjugateSlope u := by
  unfold conjugateSlope
  apply (lt_div_iff₀ (conjugateSlope_den_pos hu.le hh)).mpr
  nlinarith [sq_nonneg u]

theorem conjugateSlope_strictMono : StrictMonoOn conjugateSlope (Set.Ico 0 (1/2)) := by
  intro u hu v hv huv
  unfold conjugateSlope
  apply (div_lt_div_iff₀ (conjugateSlope_den_pos hu.1 hu.2)
    (conjugateSlope_den_pos hv.1 hv.2)).mpr
  have hu0 : 0 ≤ u := hu.1
  have hv0 : 0 ≤ v := hv.1
  have hp : 0 < (v-u)*(2+u+v+3*u*v) :=
    mul_pos (sub_pos.mpr huv) (by positivity)
  nlinarith

theorem deriv_logConjugate {x : ℝ} (hx : 0 ≤ x) (hxu : x < Real.log (5/4)) :
    deriv logConjugate x = conjugateSlope (catalanBranch (Real.exp x-1)) := by
  rw [(hasDerivAt_logConjugate hx hxu).deriv]
  have he0 : 0 ≤ Real.exp x-1 := by have := Real.one_le_exp hx; linarith
  have he1 : Real.exp x-1 < 1/4 := by
    have h := (Real.exp_lt_exp.mpr hxu).trans_eq (Real.exp_log (by norm_num : (0:ℝ) < 5/4))
    linarith
  have he := (catalanBranch_properties he0 he1.le).2.2
  have hs : Real.sqrt (1-4*(Real.exp x-1)) = 1-2*catalanBranch (Real.exp x-1) := by
    unfold catalanBranch
    ring
  unfold conjugateSlope
  rw [hs]
  have hn : Real.exp x = 1+catalanBranch (Real.exp x-1)-
      catalanBranch (Real.exp x-1)*catalanBranch (Real.exp x-1) := by linarith
  have hden : (1+catalanBranch (Real.exp x-1))*(1-2*catalanBranch (Real.exp x-1)) =
      1-catalanBranch (Real.exp x-1)-2*catalanBranch (Real.exp x-1)*catalanBranch (Real.exp x-1) := by ring
  rw [hden]
  exact congrArg (fun v : ℝ => v / (1-catalanBranch (Real.exp x-1)-
    2*catalanBranch (Real.exp x-1)*catalanBranch (Real.exp x-1))) hn

#print axioms conjugateSlope_strictMono
#print axioms deriv_logConjugate
end LiteralDL
