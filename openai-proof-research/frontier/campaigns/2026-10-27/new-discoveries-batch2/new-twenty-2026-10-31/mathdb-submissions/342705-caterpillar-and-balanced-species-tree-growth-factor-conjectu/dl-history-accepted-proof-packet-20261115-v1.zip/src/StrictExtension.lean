import CaterpillarSplit
namespace LiteralDL

theorem ShapeIso.branch_eq {s t} (h : ShapeIso s t) (z : ℝ) :
    branchValue s z = branchValue t z := by
  induction h with
  | leaf => rfl
  | node ha hb ia ib => simp only [branchValue,ia,ib]
  | swap ha hb ia ib =>
    simp only [branchValue,ia,ib]
    congr 1
    ring

theorem node_input_le_quarter (a b : Species) {z : ℝ} (hz : 0 ≤ z)
    (hr : z ≤ rho (.node a b)) :
    branchValue a z + branchValue b z + branchValue a z * branchValue b z ≤ 1/4 := by
  have he := branch_node_quadratic a b hz hr
  nlinarith [sq_nonneg (branchValue (.node a b) z - 1/2)]

theorem strict_leaf_extension (s t : Species)
    (hglobal : ∀ z : ℝ, 0 ≤ z → branchValue s z ≤ branchValue t z)
    (hstrict : ∀ z : ℝ, 0 < z → z < rho t → branchValue s z < branchValue t z) :
    rho (.node t .leaf) < rho (.node s .leaf) ∧
      ∀ z : ℝ, 0 < z → z < rho (.node t .leaf) →
        branchValue (.node s .leaf) z < branchValue (.node t .leaf) z := by
  have hval : ∀ z : ℝ, 0 < z → z ≤ rho (.node t .leaf) →
      branchValue (.node s .leaf) z < branchValue (.node t .leaf) z := by
    intro z hz hr
    have hchild : z < rho t := hr.trans_lt (rho_node_lt_left t .leaf)
    exact mergeValue_strict (branchValue_global_bounds s hz.le).1
      (branchValue_global_bounds .leaf hz.le).1 (hstrict z hz hchild) le_rfl
      (node_input_le_quarter t .leaf hz.le hr)
  constructor
  · have hle : rho (.node t .leaf) ≤ rho (.node s .leaf) := by
      apply rho_le_of_global_branch_le
      intro z hz
      exact mergeValue_mono (branchValue_global_bounds s hz).1
        (branchValue_global_bounds .leaf hz).1 (hglobal z hz) le_rfl
    apply lt_of_le_of_ne hle
    intro heq
    have h := hval (rho (.node t .leaf)) (rho_pos _) le_rfl
    have ht : branchValue (.node t .leaf) (rho (.node t .leaf)) = 1/2 :=
      (actualThreshold _).endpoint
    have hs : branchValue (.node s .leaf) (rho (.node t .leaf)) = 1/2 :=
      heq ▸ (actualThreshold _).endpoint
    linarith
  · intro z hz hr
    exact hval z hz hr.le

#print axioms strict_leaf_extension
end LiteralDL
