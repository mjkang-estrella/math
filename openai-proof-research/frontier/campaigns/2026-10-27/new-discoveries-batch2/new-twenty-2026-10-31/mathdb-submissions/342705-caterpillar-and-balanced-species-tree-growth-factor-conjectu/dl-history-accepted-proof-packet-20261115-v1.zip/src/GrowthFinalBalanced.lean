import GrowthFinalScalar
namespace LiteralDL.GrowthStage
open LiteralDL
set_option maxHeartbeats 1000000

theorem balanced_value_bound (k : Nat) (hk : 0 < k) {z : ℝ}
    (hz : 0 ≤ z) (hr : z ≤ rho (balanced k)) (hs : (k:ℝ)*z ≤ 1/1000) :
    branchValue (balanced k) z ≤ (k:ℝ)*z+20*((k:ℝ)*z)^2 := by
  induction k using Nat.strong_induction_on with
  | h k ih =>
    cases k with
    | zero => omega
    | succ n =>
      cases n with
      | zero =>
        norm_num only [Nat.zero_add, balanced, Nat.cast_one, one_mul] at hr ⊢
        have he := leaf_quadratic hz hr
        have hb := (branchValue_global_bounds .leaf hz).2
        have hn := (branchValue_global_bounds .leaf hz).1
        have hx : branchValue .leaf z ≤ 2*z := by nlinarith
        nlinarith
      | succ n =>
        let a := (n+2)/2
        let b := (n+3)/2
        have ha : 0 < a := by dsimp [a]; omega
        have hb : 0 < b := by dsimp [b]; omega
        have hat : a < n+2 := by dsimp [a]; omega
        have hbt : b < n+2 := by dsimp [b]; omega
        have hab : a+b=n+2 := by dsimp [a,b]; omega
        have hba : a ≤ b := by dsimp [a,b]; omega
        have hba' : b ≤ a+1 := by dsimp [a,b]; omega
        have hn : balanced (n+2) = .node (balanced a) (balanced b) := by
          simp only [balanced]
          rfl
        rw [hn] at hr ⊢
        have hra := hr.trans (rho_node_lt_left _ _).le
        have hrb := hr.trans (rho_node_lt_right _ _).le
        have hcast : (a:ℝ)+(b:ℝ)=(n+2:Nat) := by exact_mod_cast hab
        have haz : (a:ℝ)*z ≤ 1/1000 := by
          have : (a:ℝ) ≤ (n+2:Nat) := by exact_mod_cast hat.le
          nlinarith
        have hbz : (b:ℝ)*z ≤ 1/1000 := by
          have : (b:ℝ) ≤ (n+2:Nat) := by exact_mod_cast hbt.le
          nlinarith
        have hbal : ((a:ℝ)+(b:ℝ))^2 ≤ 5*(a:ℝ)*(b:ℝ) := by
          have ha1 : (1:ℝ) ≤ a := by exact_mod_cast ha
          have h1 : (a:ℝ) ≤ b := by exact_mod_cast hba
          have h2 : (b:ℝ) ≤ a+1 := by exact_mod_cast hba'
          nlinarith [sq_nonneg ((b:ℝ)-(a:ℝ))]
        have h := merge_bound (Nat.cast_nonneg a) (Nat.cast_nonneg b) hz hbal
          (by simpa only [hcast] using hs)
          (branchValue_global_bounds (balanced a) hz).1
          (branchValue_global_bounds (balanced b) hz).1
          (branchValue_global_bounds _ hz).1
          (branchValue_global_bounds _ hz).2
          (ih a hat ha hra haz) (ih b hbt hb hrb hbz)
          (branch_node_quadratic _ _ hz hr)
        simpa only [hcast] using h

end LiteralDL.GrowthStage
