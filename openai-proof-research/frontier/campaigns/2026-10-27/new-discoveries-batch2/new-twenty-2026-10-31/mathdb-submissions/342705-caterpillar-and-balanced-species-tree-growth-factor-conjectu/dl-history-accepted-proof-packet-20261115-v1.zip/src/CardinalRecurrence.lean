import SourceHistory
import Mathlib.Data.Fintype.Sigma
import Mathlib.Data.Fintype.Sum
import Mathlib.Data.Fintype.BigOperators
namespace LiteralDL
abbrev PairFiber (a b : Species) (n : Nat) :=
  {xy : Hist a × Hist b // size xy.1 + size xy.2 = n}
abbrev Split (a b : Species) (n : Nat) :=
  (i : Fin (n+1)) × (Fiber a i × Fiber b (n-i))

def splitEquiv (a b : Species) (n : Nat) : PairFiber a b n ≃ Split a b n where
  toFun x := ⟨⟨size x.1.1, by have := x.2; omega⟩,
    ⟨⟨x.1.1, rfl⟩, ⟨x.1.2, by have := x.2; dsimp; omega⟩⟩⟩
  invFun x := ⟨(x.2.1.1, x.2.2.1), by
    have h := x.1.2
    have h1 := x.2.1.2
    have h2 := x.2.2.2
    dsimp at h h1 h2 ⊢
    omega⟩
  left_inv x := by rfl
  right_inv x := by
    rcases x with ⟨⟨i, hi⟩, ⟨⟨x, hx⟩, ⟨y, hy⟩⟩⟩
    dsimp at hx
    subst i
    rfl

instance pairFintype (a b : Species) (n : Nat) : Fintype (PairFiber a b n) :=
  Fintype.ofEquiv (Split a b n) (splitEquiv a b n).symm

def pairCount (a b : Species) (n : Nat) := Fintype.card (PairFiber a b n)

/-- Root alternatives before translating the finite pair fibers to convolution. -/
abbrev NodeRoot (a b : Species) (n : Nat) :=
  PairFiber (.node a b) (.node a b) n ⊕
    (PairFiber a b n ⊕ (Fiber a n ⊕ Fiber b n))

def nodeJoin {a b n} : NodeRoot a b n → Fiber (.node a b) n
  | .inl xy => ⟨.dup xy.1.1 xy.1.2, xy.2⟩
  | .inr (.inl xy) => ⟨.both xy.1.1 xy.1.2, xy.2⟩
  | .inr (.inr (.inl x)) => ⟨.keepLeft x.1, x.2⟩
  | .inr (.inr (.inr y)) => ⟨.keepRight y.1, y.2⟩

def nodeCut {a b n} (h : Fiber (.node a b) n) : NodeRoot a b n :=
  match h with
  | ⟨.dup x y, hn⟩ => .inl ⟨(x,y), hn⟩
  | ⟨.both x y, hn⟩ => .inr (.inl ⟨(x,y), hn⟩)
  | ⟨.keepLeft x, hn⟩ => .inr (.inr (.inl ⟨x, hn⟩))
  | ⟨.keepRight y, hn⟩ => .inr (.inr (.inr ⟨y, hn⟩))

def nodeEquiv (a b : Species) (n : Nat) : NodeRoot a b n ≃ Fiber (.node a b) n where
  toFun := nodeJoin
  invFun := nodeCut
  left_inv x := by rcases x with x | (x | (x | x)) <;> rfl
  right_inv x := by rcases x with ⟨x,h⟩; cases x <;> rfl

theorem count_node (a b : Species) (n : Nat) :
    count (.node a b) n = pairCount (.node a b) (.node a b) n +
      pairCount a b n + count a n + count b n := by
  have h := Fintype.card_congr (nodeEquiv a b n)
  simp only [Fintype.card_sum] at h
  unfold count pairCount
  omega

theorem pairCount_eq (a b : Species) (n : Nat) :
    pairCount a b n = ∑ i : Fin (n+1), count a i * count b (n-i) := by
  simpa [pairCount, Split, count, Fintype.card_sigma, Fintype.card_prod] using
    Fintype.card_congr (splitEquiv a b n)

abbrev LeafRoot (n : Nat) := {_u : Unit // 1 = n} ⊕ PairFiber .leaf .leaf n

def leafJoin {n} : LeafRoot n → Fiber .leaf n
  | .inl u => ⟨.extant, u.2⟩
  | .inr xy => ⟨.dup xy.1.1 xy.1.2, xy.2⟩

def leafCut {n} (h : Fiber .leaf n) : LeafRoot n :=
  match h with
  | ⟨.extant, hn⟩ => .inl ⟨(), hn⟩
  | ⟨.dup x y, hn⟩ => .inr ⟨(x,y), hn⟩

def leafEquiv (n : Nat) : LeafRoot n ≃ Fiber .leaf n where
  toFun := leafJoin
  invFun := leafCut
  left_inv x := by rcases x with ⟨⟨⟩,h⟩ | x <;> rfl
  right_inv x := by rcases x with ⟨x,h⟩; cases x <;> rfl

theorem count_leaf (n : Nat) : count .leaf n = (if n = 1 then 1 else 0) +
    ∑ i : Fin (n+1), count .leaf i * count .leaf (n-i) := by
  have h := Fintype.card_congr (leafEquiv n)
  simp only [Fintype.card_sum] at h
  rw [← pairCount_eq]
  unfold count pairCount
  by_cases hn : n = 1
  · subst n
    simpa using h.symm
  · have : IsEmpty {_u : Unit // 1 = n} := ⟨fun x => hn x.2.symm⟩
    simpa [hn, Fintype.card_of_isEmpty] using h.symm

theorem count_node_convolution (a b : Species) (n : Nat) :
    count (.node a b) n =
      (∑ i : Fin (n+1), count (.node a b) i * count (.node a b) (n-i)) +
      (∑ i : Fin (n+1), count a i * count b (n-i)) + count a n + count b n := by
  simpa only [pairCount_eq] using count_node a b n

#print axioms count_leaf
#print axioms count_node_convolution
#print axioms splitEquiv
#print axioms count_node
end LiteralDL
