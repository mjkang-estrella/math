import StrictExtension
namespace LiteralDL
inductive LeafExpansion : Species → Species → Prop where
  | cherry : LeafExpansion .leaf (.node .leaf .leaf)
  | left {a b c} : LeafExpansion a b → LeafExpansion (.node a c) (.node b c)
  | right {a b c} : LeafExpansion a b → LeafExpansion (.node c a) (.node c b)

theorem LeafExpansion.global_le {s t} (h : LeafExpansion s t) {z : ℝ} (hz : 0 ≤ z) :
    branchValue s z ≤ branchValue t z := by
  induction h with
  | cherry =>
    exact mergeValue_ge_left (branchValue_global_bounds .leaf hz).1
      (branchValue_global_bounds .leaf hz).2 (branchValue_global_bounds .leaf hz).1
  | @left a b c h ih =>
    exact mergeValue_mono (branchValue_global_bounds a hz).1
      (branchValue_global_bounds c hz).1 ih le_rfl
  | @right a b c h ih =>
    exact mergeValue_mono (branchValue_global_bounds c hz).1
      (branchValue_global_bounds a hz).1 le_rfl ih

theorem LeafExpansion.strict_value {s t} (h : LeafExpansion s t) {z : ℝ}
    (hz : 0 < z) (hr : z ≤ rho t) : branchValue s z < branchValue t z := by
  induction h with
  | cherry => exact branch_node_gt_left .leaf .leaf hz hr
  | @left a b c h ih =>
    exact mergeValue_strict (branchValue_global_bounds a hz.le).1
      (branchValue_global_bounds c hz.le).1
      (ih (hr.trans (rho_node_lt_left b c).le)) le_rfl
      (node_input_le_quarter b c hz.le hr)
  | @right a b c h ih =>
    have hs : branchValue (.node c a) z = mergeValue (branchValue a z) (branchValue c z) := mergeValue_comm _ _
    have ht : branchValue (.node c b) z = mergeValue (branchValue b z) (branchValue c z) := mergeValue_comm _ _
    rw [hs,ht]
    have hq := node_input_le_quarter c b hz.le hr
    exact mergeValue_strict (branchValue_global_bounds a hz.le).1
      (branchValue_global_bounds c hz.le).1
      (ih (hr.trans (rho_node_lt_right c b).le)) le_rfl (by nlinarith)

theorem LeafExpansion.rho_lt {s t} (h : LeafExpansion s t) : rho t < rho s := by
  have hle := rho_le_of_global_branch_le s t (fun _ hz => h.global_le hz)
  apply lt_of_le_of_ne hle
  intro he
  have hh := h.strict_value (rho_pos t) le_rfl
  have hs : branchValue s (rho t) = 1/2 := he ▸ (actualThreshold s).endpoint
  have ht : branchValue t (rho t) = 1/2 := (actualThreshold t).endpoint
  linarith

#print axioms LeafExpansion.rho_lt
end LiteralDL
