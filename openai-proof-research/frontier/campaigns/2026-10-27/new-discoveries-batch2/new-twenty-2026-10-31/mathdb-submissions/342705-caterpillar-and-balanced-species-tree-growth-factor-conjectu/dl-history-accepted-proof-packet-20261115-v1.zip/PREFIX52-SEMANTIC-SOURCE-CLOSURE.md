# SEMANTIC-SOURCE-CLOSURE-v1 — MathDB 342705, DL-history 52-module prefix

Reviewer: Claude Opus 5.5 (claudeAgent/claude-opus-5-5, high, fastMode false), sole lane `dl-history-52-module-independent-semantics-opus-r1`, 2026-11-15. Role: independent scientific/source/semantic/proof-body review. Formal calls 0, GETs 0, searches 0, scientific prototypes 0, children 0, credit/ledger actions 0. Current administrative count as supplied: 72/80 NEW, 111 total (unchanged by this review).

## 1. Verdict (scoped)

**SCOPED PASS** for the 52-module prefix (46 common + 6 new) as extracted by me from my own `inputs/BALANCED-PAPER-v1.md`, restricted to the following scope:

- source semantics: unranked full binary species trees, k = species leaves, n = extant gene leaves, ordered duplication, explicit speciation/loss events, no all-loss history, no lost duplication child, no ranking, no transfer, no unordered-gene substitution;
- the history type is in bijection with the source event-tree grammar plus species map; fibers are finite; the actual cardinal recurrence is proved; the generating sum is the genuine sum of count(s,n)z^n;
- the threshold `rho` is built (not postulated). It is the exact convergence boundary of the actual sum (finite iff z <= rho). The actual nth-root limit exists by Fekete, and growth = 1/rho;
- ShapeIso is exactly recursive child-swap (unordered rooted binary tree) isomorphism. It is an equivalence relation and preserves counts, leaves and rho;
- caterpillar: strict radius minimum outside ShapeIso, and an eventual actual-count maximum with equality exactly on the ShapeIso class, using one cutoff per k uniform over ALL k-leaf species;
- balanced, for every positive k (not only powers of 2): strict radius maximum outside ShapeIso, rho equality iff ShapeIso, and an eventual actual-count minimum with weak, equality and strict clauses exactly as stated, using one cutoff per k uniform over ALL k-leaf species.

I found **no load-bearing defect** in this scope. Advisories A1-A6 (Section 7) are fidelity and presentation points for the final assembly. They are not defects of this component.

This is **NOT** a PASS of the full four-claim conjecture. The superlinear caterpillar growth clause and the linear balanced growth clause are not in these 52 modules. They remain UNPAID, which is not a defect of this component. I did not read or poll the growth/assembly lane. I make no claim about independent kernel checking: I ran no Lean, checker, compile or replay. The parent's 237-declaration permitted-axiom audit and its 19 calls (5 failures) are AUTHOR evidence and attributed as such. The later assembled closure still needs its single fresh extraction, rebuild and separate kernel check.

## 2. Source authentication and target binding

- Landing metadata (owned `1905.04971-landing.html`) and the PMC metadata give the citation: Cedric Chauve, Yann Ponty, Michael Wallner, "Counting and sampling gene family evolutionary histories in the duplication-loss and duplication-loss-transfer models", arXiv:1905.04971 (v1 2019-05-13). Final version: J. Math. Biol., DOI 10.1007/s00285-019-01465-x (PMC7052048).
- MathDB raw line sha256 9209561e49f595ec22fe9f2feed20206094001bec60fc2103aeb309814c1db4e matches the owned binding record. The live field projection text equals the raw statement.
- v1 sources I personally read: Section 2 preliminaries; Definition 2.1; Remarks 2.1-2.2; Theorem 3.1 grammar (1)-(6) plus its DL specialization and proof; counting recurrences (7)-(10); the Theorem 3.3 statement; Section 4.1 caterpillar, complete binary and balanced definitions; Section 4.2 including Conjecture 4.1 and footnote 3.
- Final version (PMC TXT): Definition 2.1, the Conjecture 4.5 text (identical to v1 Conjecture 4.1), the balanced definition, and the radicand recurrence R_u = -4 + 3R_l + 3R_r - R_l R_r with H_u = (1 - sqrt R_u)/2. I did not read the full body.
- Frozen PDF skill (`inputs/PDF-SKILL.md`), announced and used read-only. v1 pages 6 (grammar and recurrences) and 16 (Conjecture 4.1 and footnote 3) were rendered with pdftoppm (90 dpi) under my runner and inspected visually (`renders/`). The rendered formulas agree with the TXT.

Source to formal map:

| Source | Formal |
|---|---|
| species tree, ordered by labels, binary | `Species` (leaf/node) |
| H_u = S_u ∪ D_u (internal); Z_u ∪ D_u (leaf) | `Hist` constructors dup / both / keepLeft / keepRight / extant |
| S_u = H_l×H_r ∪ H_l×X_r ∪ X_l×H_r | `both`, `keepLeft` (right lost), `keepRight` (left lost) |
| D_u = H_u×H_u×Y_u, ordered (Remark 2.1) | `dup x y`, ordered pair, same species |
| Def. 2.1 event and species map | `EventTree`, `Valid`, `encode`; `sourceEquiv` and `sourceFiberEquiv` bijections |
| size = number of Extant leaves | `size`, `extantCount` |
| H[u,n] recurrences (8)-(10) | `count_leaf`, `count_node_convolution`: sums over 0..n where the zero-size terms vanish by `count_zero` |
| H_node = C(H_l + H_r + H_l·H_r), C(q) = (1-sqrt(1-4q))/2 | `atomMass_node`, `total_principal`, `historySum_node_principal` |
| rho_S, alpha_S = 1/rho_S | `rho`, `historySum_finite_iff`, `actual_root_limit`, `growth_eq_inv_rho` |
| CT_1 leaf; CT_k = (CT_{k-1}, CT_1) | `caterpillar` (identical recursion) |
| balanced: each node's children differ by at most 1 leaf; unique up to child swaps (fn. 3) | `balanced k` = node(B_{floor(k/2)}, B_{ceil(k/2)}) plus the ShapeIso class (see A1) |
| "unranked species tree considered up to isomorphism" | `ShapeIso` |

## 3. Independent ordinary argument (reviewer reconstruction)

I reconstructed this argument independently while reading the bodies. Every step below matches a module I read personally.

**(a) Counts, finiteness and generating sums.**
- Every history of species s with n extant leaves has depth at most n·weight(s). So the fiber is finite, enumerated by `pool`.
- Root duplication of a size-i history and a size-j history is injective into the size-(i+j) fiber, so count is supermultiplicative.
- `one s` uses keepLeft chains down to the leftmost leaf, giving count(s,n+1) >= 1. There is no size-0 history.
- Cutting the maximal duplication skeleton gives Hist s ≃ Skeleton(Atom s). The ENNReal total T then satisfies T = A + T^2, and T <= r for every r >= 0 with A + r^2 <= r (height-truncation induction). Hence:
  - when A = t <= 1/4, T = C(t) (the smaller root);
  - when t > 1/4, T = ⊤, since (T - 1/2)^2 + t - 1/4 > 0.
- The atom mass of node(a,b) is H_a + H_b + H_a·H_b, and the leaf atom mass is z.

**(b) Threshold.**
- Leaf: rho = 1/4.
- Node: q(z) = x_a + x_b + x_a·x_b is continuous and strictly increasing on [0, R], where R = min of the child radii. q(0) = 0, and q(R) >= 1/2 because one child is at 1/2 there. The intermediate value theorem gives r with q(r) = 1/4, and r < R strictly.
- Below r the actual sum equals C(q). Above r it is ⊤, including beyond R by monotonicity.
- So rho is the exact convergence boundary of the actual sum Σ count(s,n)z^n, with value 1/2 at rho. This makes the use of choice in the construction harmless: `historySum_finite_iff` pins rho uniquely.
- count(s,n)·rho^n <= 1/2.
- -log count is subadditive and bounded below by log rho, so Fekete gives a limit L. With growth = e^{-L}:
  - count^{1/n} → growth;
  - count <= growth^n, so the sum converges for z < 1/growth, so 1/growth <= rho;
  - the coefficient bound gives growth·rho <= 1.
  - Hence growth = 1/rho.
- A child radius is strictly larger than its parent's: at z = rho(a), H_a = 1/2 would force H_node >= 1/2 and H_node >= 1/2 + 1/4, a contradiction.

**(c) ShapeIso.** The relation is generated by node congruence and swap. Counts are congruent through the convolution recurrence (strong induction on n, since the i = 0 and i = n terms vanish) and invariant under root swap. A root swap exchanges species children but keeps duplication order, so ordered duplication children are never identified. Hence ShapeIso preserves count for all n, preserves rho, and preserves branch values.

**(d) Caterpillar maximum (smallest rho).**
- Associator identity: with x = C(a+b+ab) and y = C(c+b+cb),
  ((1+c)x + c - (1+a)y - a)(1-x-y) = (a-c)(x+y+xy).
  I spot-checked it numerically: a = b = 0.1, c = 0.05 gives both sides 0.027466. When c < a and x + y < 1, the left merge strictly exceeds the right merge.
- Clipped merges (Real.sqrt saturating at 1/2) give global weak monotone and associator inequalities. These are only comparison helpers. They reach the actual radius solely through `rho_le_of_global_branch_le`, which uses the actual endpoint value 1/2 and the strict actual monotonicity below rho.
- Weak result: induction gives branch(s) <= branch(cat(leaves s)), so rho(cat) <= rho(s).
- Strict result, by a case split on the root:
  - left child is a leaf: leaf extension;
  - right child is a leaf: leaf extension;
  - both children have at least 2 leaves: split strictness, via strict rotation at a common radius. Both inner arguments would equal 1/4 while the associator orders them strictly.
  This yields the dichotomy: either ShapeIso, or rho(cat) < rho(s) with strictly smaller branch values below rho(cat).

**(e) Balanced minimum (largest rho).**
- Write x_s(z) = log(1 + H_s(z)) and f(u) = log(1 + C(e^u - 1)). Then x_node = f(x_a + x_b) exactly, because 1 + S = (1 + H_a)(1 + H_b).
- f is valid on [0, log(5/4)], since C's argument must be <= 1/4. Checked derivative: f' = (1 + w - w^2)/(1 - w - 2w^2) with w = C(e^u - 1). This uses e^u = 1 + w - w^2 and sqrt(1 - 4q) = 1 - 2w.
- f' > 1 for w > 0, and f' is strictly increasing in w on [0, 1/2). So f is strictly convex on the closed domain (continuity plus derivative monotone on the interior) and expansive: f(v) - f(u) > v - u.
- Single-leaf expansion strictly lowers rho. B_k → B_{k+1} is a leaf expansion: k even goes to the right child, k odd to the left. So rho(B_K) <= rho(B_j) for j <= K.
- Fix 0 < z <= rho(B_K) and b_n = x_{B_n}(z), with b_n increasing. The discrete strict convexity 2b_n < b_{n-1} + b_{n+1} holds for 2 <= n and n+1 <= K:
  - center 2: expansiveness from 0 gives b_2 > 2b_1; expansiveness between 2b_1 and b_1 + b_2 gives b_3 - b_2 > b_2 - b_1;
  - odd n = 2m+1: the inputs 2b_m, b_m + b_{m+1}, 2b_{m+1} are equally spaced and distinct;
  - even n = 2m >= 4: the inputs are b_{m-1} + b_m, 2b_m, b_m + b_{m+1}; the induction at center m gives 2·middle < outer sum; monotonicity plus strict midpoint convexity finishes.
  - Every index stays <= K.
- Increasing differences then make the floor/ceiling split the unique minimizer of b_i + b_j over i + j = k (finite exchange induction).
- Structural induction gives x_{B_{leaves s}} <= x_s, with equality iff ShapeIso:
  - both children are valid (child radii are strictly larger), and both inputs lie in the closed domain;
  - f is strictly increasing, so equality forces equal inputs, which forces both child equalities and a central split;
  - node or swap then gives ShapeIso.
- Strict radius: if s is not ShapeIso to B_k but rho(s) >= rho(B_k), evaluate at z = rho(B_k). Then x_s > x_B = log(3/2), while every branch value is <= 1/2. Contradiction.
- Counts: rho(s) < rho(B_k) gives growth(B_k) < growth(s). A real number between the two limits separates the nth roots eventually, so count(B_k,n) < count(s,n) eventually (rpow monotonicity). ShapeIso gives equality for every n. A finite intersection over the exhaustive Fintype of k-leaf species gives one N, which is replaced by max(1, N).

The argument is complete for all k >= 1, including k = 1, 2, 3 (central splits need no convexity index), odd and even k, and non-dyadic k.

## 4. Expanded statement analysis (actual theorem types read in source)

`LiteralDL.BalancedStage.balanced_component` (BalancedFinalExtremum) is a closed proposition with no premises. Its two conjuncts are:

1. For every k : Nat with 0 < k and every s : Species with leaves s = k:
   - rho s <= rho (balanced k);
   - (rho s = rho (balanced k) ↔ ShapeIso s (balanced k));
   - (¬ShapeIso s (balanced k) → rho s < rho (balanced k)).
2. For every k : Nat with 0 < k there is N : Nat with 1 <= N such that, for every s with leaves s = k and every n >= N:
   - count (balanced k) n <= count s n;
   - (count (balanced k) n = count s n ↔ ShapeIso s (balanced k));
   - (count (balanced k) n < count s n ↔ ¬ShapeIso s (balanced k)).

The body only rewrites leaves s = k into `rho_balanced_le`, `rho_balanced_eq_iff` and `rho_balanced_strict`, and destructs `eventual_balanced_minimum`. The text is byte-identical to the paper's "Literal expanded endpoint".

Supporting theorem types:
- `rho_balanced_strict (s) (hi : ¬ShapeIso s (balanced (leaves s))) : rho s < rho (balanced (leaves s))`. Its only hypothesis is the non-isomorphism.
- `rho_balanced_eq_iff (s) : rho s = rho (balanced (leaves s)) ↔ ShapeIso s (balanced (leaves s))`.
- `eventual_balanced_minimum (k)` has no hypotheses; it is vacuous at k = 0.
- `eventual_caterpillar_maximum (k)`, the weak and equality-iff caterpillar count maximum, and `rho_caterpillar_strict (s) (hs : ¬ShapeIso s (caterpillar (leaves s)))` are likewise free of any extremum, convexity, limit or bridge premise.
- `discrete_convex` and `split_min` do take sequence hypotheses (positivity, increase, domain, recursion, discrete convexity). These are internal lemmas, and every hypothesis is discharged for the actual sequence by `balanced_log_discrete` and `log_minimum`. None of these hypotheses survives into any export.
- Every symbol in the endpoint types is a project definition I read: Species, leaves, balanced, caterpillar, ShapeIso, count (Fintype.card of the literal fiber), and rho (constructed radius). Apart from these there are only Nat, ℝ and Mathlib core notions. I read no pinned STANDARD text because none was needed for these types.

## 5. Provider / import / declaration map

- Direct external imports (20, all Mathlib, none from outside the pinned standard library): Analysis.Convex.Deriv, Analysis.Real.Sqrt, Analysis.SpecialFunctions.{Log.Basic, Log.Deriv, Pow.Real, Sqrt}, Analysis.SpecificLimits.Basic, Analysis.Subadditive, Data.Finset.Prod, Data.Fintype.{BigOperators, Card, OfMap, Prod, Sigma, Sum}, Order.Filter.Finite, Tactic.{Linarith, LinearCombination}, Topology.Algebra.InfiniteSum.ENNReal, Topology.Order.IntermediateValue.
- Every project import is one of the 52 extracted modules. Machine check: imports equal `BalancedFinalClosure.json` for all 52, and the dependency order equals the paper order.
- `BalancedFinalExtremum` transitively imports 47 project modules. Only the four audit-only modules (EndpointAudit, ClosureAudit, ProgressAudit, BalancedFinalAudit) are outside its cone.
- There is no custom provider outside the paper. I used no producer src, build, cache or olean.
- 237 declarations (theorem/def/abbrev/instance/inductive/structure), and every one appears in BalancedFinalAudit's 237 `#print axioms` lines (machine check).
- Prohibited-construct screen (machine, outside `#print`): sorry, admit, axiom, unsafe, native_decide, implemented_by, extern, opaque, partial, set_option, macro, elab, local instance, attribute, decide. Zero hits. The only "syntax" hit is a docstring in LiteralHistory, which I read.
- I personally confirmed in reading: no `axiom` declarations, no tactic holes, and no `native_decide` or `decide` oracles.
- Recorded process evidence: `extract52-v1.*`, `source-scan-v1.*`, `closure-crosscheck-v1.*`, `extract52-v1-verification.json`, `source-scan-v1-details.json`.

## 6. All 52 modules: personal proof-body coverage, exact hashes, imports

Every row: extracted by me from own paper via own writer, byte/length/sha256 equal to PRODUCTION-52-HASHES and BalancedFinalClosure; ALL definitions and proof bodies personally read in full.

| # | Module | Bytes | SHA256 | Direct imports | Decls | Content read |
|---|---|---|---|---|---|---|
| 1 | LiteralHistory | 5556 | `c40f422055fb4dce20d15df8871f649a2e98e1a26ab7b6f9856015eb7e73a97c` | M.Data.Fintype.Card, M.Data.Fintype.Prod, M.Data.Fintype.OfMap, M.Data.Finset.Prod, M.Tactic.Linarith | 20 | Species,Hist(extant/dup/both/keepLeft/keepRight),size,depth bound,pool,Fiber,count,supermultiplicative,count_pos |
| 2 | SourceHistory | 3518 | `b7df492ce4f3049440b665cfd106a52127b54247863226220151a484591a9e13` | LiteralHistory | 9 | EventTree,Valid grammar with species addresses and loss tips,encode,sourceEquiv bijection |
| 3 | CardinalRecurrence | 4086 | `410eb8a7ff37d70df547f84c705de81e78fccd5a8b49819a2b3d0cfb114fe977` | SourceHistory, M.Data.Fintype.Sigma, M.Data.Fintype.Sum, M.Data.Fintype.BigOperators | 17 | split/node/leaf root equivs,count_node,count_leaf,count_node_convolution = source (8)-(10) |
| 4 | SourceFiber | 2303 | `06c19bc61776a55a41d4d37870213de34ca94722181953024d9e5f9a6819c748` | CardinalRecurrence | 9 | extantCount,sourceFiberEquiv,swapRoot keeps dup order,count_swap,count_zero |
| 5 | DuplicationSkeleton | 1762 | `99169772c17e784b3a61538feb7ffd50a73ed7157c199a7aeb3f860cb5abc497` | SourceFiber | 10 | Hist ≃ Skeleton(Atom),assemble_size |
| 6 | WeightedSkeleton | 2041 | `ac7cdbbd7f1f70dc59380e1fca6f5993c6e03def31787d8800a40ca2e4c49309` | DuplicationSkeleton, M.Topology.Algebra.InfiniteSum.ENNReal | 7 | ENNReal skeleton total, T=A+T^2, historySum = total |
| 7 | LeastFixedPoint | 2881 | `6c5d6b8fb1c9b5eff6d906ff3c8811d2035ca653d1d846c82f2980af20252904` | WeightedSkeleton | 8 | height cut, total ≤ any prefixed r |
| 8 | SourceWeighted | 1218 | `515af092f29045a8f72d60929c699e934ebd7ffad7a71065031efbb548bba240` | LeastFixedPoint | 3 | historySum = Σ count z^n (actual coefficients) |
| 9 | EndpointAudit | 2806 | `e432baead9010f2c89502100283a0283551c9528eb049dddc26bd9811d1ce713` | SourceWeighted | 0 | #print axioms only, no declarations |
| 10 | AtomMass | 1619 | `14b9c6e105c9b771aa225ae4ac6758539d9c7f31551f312766dc9e0cab1eba33` | SourceWeighted | 3 | node atom mass A+B+AB, total determined by mass |
| 11 | ScalarBranch | 687 | `c78303497a7380e33a8b6d16e04f4e84526b5247430fc71794523d5c0ae4e65a` | AtomMass, M.Analysis.Real.Sqrt | 2 | catalanBranch C(t) bounds and fixed point on [0,1/4] |
| 12 | ScalarEvaluation | 1644 | `98ae402407c7160787ae036fffd0ead5cdb0db8a19b83ca799ca5e4d0fe149b3` | ScalarBranch | 2 | total=C(t) for t≤1/4, ⊤ for t>1/4 |
| 13 | HistoryEvaluation | 1402 | `8c04464ad6eed77805e9d8d884f9c62d94a5de483e3c431dbae0fffcc43c6eca` | ScalarEvaluation | 4 | actual leaf/node sums equal C(...) or ⊤ |
| 14 | BranchRegularity | 1484 | `7ca57947772b15de3737bc28c07ef62616cb91b1172a956fb46ca9458fc63b3f` | HistoryEvaluation, M.Topology.Order.IntermediateValue | 7 | clipped branchValue, continuity, zero, strictMono of C |
| 15 | HistoryOrder | 1705 | `f2969071f4489d94a5c91f978fe54c9793c9f1cc13ef1b68ab070db68b713852` | BranchRegularity | 5 | child sum ≤ parent, monotone, node divergence |
| 16 | ActualThreshold | 5409 | `ee2377e55440b4aeaf494d2d5bc85164d8641e7e35405bd4e3f4d6fd218bd8d0` | HistoryOrder | 4 | constructed threshold structure, IVT node threshold r<min child radii, divergence above |
| 17 | ThresholdFacts | 1561 | `d10d2af7884d5f715c6b7f1d08eb4f007e807af97c6fc22808fedf5b16a55be5` | ActualThreshold | 5 | rho, value 1/2 at rho, finite iff z≤rho, count·rho^n≤1/2 |
| 18 | LogFekete | 2416 | `15d54f9d7b83b58fe82acabf7a38886c156f9ae7108619f821795c51c6e72095` | ThresholdFacts, M.Analysis.Subadditive, M.Analysis.SpecialFunctions.Log.Basic | 5 | -log count subadditive, bounded below, Fekete limit |
| 19 | ActualRootLimit | 958 | `2991e373022b7ff7a9d20b1fbd19bac939b7d2470d3758fbf7f10ba00253ada4` | LogFekete, M.Analysis.SpecialFunctions.Pow.Real | 3 | growth, count^(1/n)→growth |
| 20 | GeometricBridge | 1515 | `e6fd52f129ea9915ee33243a906bf4a79ff2cf7f40a3eea9ca4feb89b75cd755` | ActualRootLimit, M.Analysis.SpecificLimits.Basic | 2 | count≤growth^n, convergence below 1/growth |
| 21 | ThresholdIdentity | 1933 | `d8ca6bb8d48881e89fb7f06f1661d72e0317c2c33b64468884790688e377e9bc` | GeometricBridge | 3 | growth = 1/rho |
| 22 | SpeciesShapes | 1482 | `5fc19e0d5318e6e3c7aac98c60c45002847b0d4400e9537b6adeb909fa761a28` | ThresholdIdentity | 7 | leaves, caterpillar, balanced floor/ceil, ShapeIso |
| 23 | FiniteShapes | 1177 | `311e58b8603450f8347e21c68d935f8c30fb7f2c333dfc12c56b2349eaa4b16c` | SpeciesShapes | 3 | exhaustive Fintype of k-leaf species |
| 24 | StrictChildThreshold | 1798 | `928790d737670955732c6f55f34256e0565c0a85f3e291774aae21110829f451` | FiniteShapes | 2 | node quadratic, rho(node)<rho(left) |
| 25 | ThresholdUniqueness | 896 | `4bcceca20683bd6db0a2c65aeb3eee64d4f3512c4cf184c55088c70ca36f09fe` | StrictChildThreshold | 3 | rho determined by sums, rho_swap, right child |
| 26 | ClosureAudit | 5315 | `630ce8302045fafd7c9bc55eda311822fb6f71cf610b0cdde60dbf9529644c07` | ThresholdUniqueness | 0 | #print axioms only |
| 27 | ShapeTransport | 2326 | `b7ab47e12db46b1b9cbdeb67696e1a4d94c957509326a121b10bb44192b0b218` | FiniteShapes, ThresholdUniqueness | 7 | ShapeIso refl/symm/trans, count/leaves/rho invariance |
| 28 | CatalanAssociator | 852 | `9558b44afc6a606019328be98a17e0096e89a128306ed1c75f8156df2b88ddf8` | BranchRegularity, M.Tactic.LinearCombination | 2 | associator identity and strict inequality |
| 29 | BranchDomain | 2060 | `e18b14b5411d660e2462491a406e3f457560f93ba95ba1caf965f8b8fd5e1ad7` | ShapeTransport | 4 | branch positivity, <1/2, quadratic at valid z |
| 30 | ClippedCatalan | 1948 | `af77c1f426ed8226fd29a83b872eb0ba7054e5988f711fc022ec5cc18ca49298` | CatalanAssociator | 9 | global bounds, saturation, mergeValue helpers |
| 31 | RealAssociator | 1776 | `c18e24444937abda69bea7466d9dfa3566ff48821dd29b1fcb1aea098d88c94c` | ClippedCatalan | 1 | weak clipped associator |
| 32 | BranchGlobal | 1163 | `fad4cb732022a2cac389675409bdc280e9febe4b87b223e0d80b9eef48d65ac1` | BranchDomain, RealAssociator | 3 | global bounds, ≥leaf, global branch order ⇒ rho order via actual endpoint |
| 33 | CaterpillarOrder | 1961 | `88ec591cc6516889d9bd570a95b958ea90a7dc95d73f33c1a47a95f37cb1b715` | BranchGlobal | 4 | weak caterpillar maximum, rho(cat)≤rho(s) |
| 34 | StrictRotation | 2714 | `d116011ba13cd251dca5e1dd50f8c93bac4979eb7253928ffd05e347b47431bd` | CaterpillarOrder | 4 | strict rotation radius |
| 35 | StrictMerge | 2247 | `e12731420f4451b6aaaebbdf34441ca29d9fe531269c2f1808415030c4913bfb` | StrictRotation | 3 | strict merge, strict unsaturated associator |
| 36 | CaterpillarSplit | 2508 | `eb62101fddf96ccccba2001a9cb39f3527ad3ffed1cacefeb57973198a08c15b` | StrictMerge | 3 | strict split for a,b≥2 |
| 37 | StrictExtension | 2138 | `38e57abce07dbf9b4cafd8a128f2d8d823cabd45a86f3452f39fcfd2ead9cb26` | CaterpillarSplit | 3 | ShapeIso.branch_eq, input≤1/4, strict leaf extension |
| 38 | StrictCaterpillar | 2914 | `2db213a95a82e9b2211bfe0eba32bdd8e13d9a75a2c0d79e7d1d3bfdc2a113e4` | StrictExtension | 3 | caterpillar dichotomy, rho_caterpillar_strict |
| 39 | CatalanDerivative | 1575 | `04019b62d0775ec340e97c2459555d12522c5f16a9709e725ae2e2e416ee61cf` | ClippedCatalan, M.Analysis.SpecialFunctions.Sqrt, M.Analysis.Convex.Deriv, M.Analysis.SpecialFunctions.Log.Deriv | 3 | derivatives of C and logConjugate |
| 40 | ConjugateSlope | 2108 | `3644958867104896feea7f8b5c163200a14c65c72ffebe7883db445f1c217adb` | CatalanDerivative | 5 | f' formula, >1, strictly increasing |
| 41 | LogConjugateConvex | 2022 | `8f13c8201b3f86ff2bbc991b5bef32424058f8194c39dc733fa5312f230f3235` | ConjugateSlope | 4 | closed-domain strict convexity |
| 42 | CaterpillarCounts | 2159 | `b7712bb6a212b064edb9882cbc9bff233156b6736d9c8c338d9b34ccae8910df` | StrictCaterpillar, M.Order.Filter.Finite | 3 | eventual count order from rho order, eventual_caterpillar_maximum uniform over the Fintype |
| 43 | LeafExpansion | 2321 | `419dbdf9c43cb6dd5096f311035930f0219b7aeced926fddf11d56cf29572ffb` | StrictExtension | 4 | single-leaf expansion strictly lowers rho |
| 44 | BalancedExpansion | 1242 | `dd5831e68ca4948dbb67b25151466d1989b3a5365f6ee5ac7f90703afe066a4f` | LeafExpansion | 3 | B_k→B_{k+1} leaf expansion, rho strictly decreasing |
| 45 | LogConjugateExpansive | 1683 | `65ff16048e4059e7fc83d81c9160130d33a93f36ec147c1373d25e38a9c38c4c` | LogConjugateConvex | 4 | f(y)-f(x)>y-x |
| 46 | ProgressAudit | 682 | `4b698cacc31ee352c1d0e9c3ece0a922420bfa0f803dca9f79d30e9951733a3a` | ClosureAudit, CaterpillarCounts, BalancedExpansion, LogConjugateExpansive | 0 | #print and axioms only |
| 47 | BalancedFinalDiscrete | 4179 | `e17d676a1f8c19a797ae3b600d3378007a413ec802db98cdc71d38c966ddd7e8` | LogConjugateExpansive, BalancedExpansion | 2 | strict_midpoint, discrete_convex (center 2/odd/even) |
| 48 | BalancedFinalSplit | 2813 | `c599a261ffcce4937f53268a1a7a1b16d0c0c5ffcf50488ea3024a46becb9908` | BalancedFinalDiscrete | 3 | delta_lt, split_ordered, split_min |
| 49 | BalancedFinalValues | 2880 | `561f7ad0145ed7b55edef305989ca31cdeae0cea597cba01440b1aa139d1fa5b` | BalancedFinalSplit | 9 | logValue, node law, closed domain, radius antitone, balanced_log_discrete |
| 50 | BalancedFinalOrder | 4008 | `21a68d1ef7f945daaac46e0d9650b496c765bd5d64c6b5ccaa9797d823fb3010` | BalancedFinalValues | 3 | conjugate monotone/injective, log_minimum |
| 51 | BalancedFinalExtremum | 4070 | `02922a6c2a12abfefa648688eec377443533efd42dd45ddc25d0f7163105f9b6` | BalancedFinalOrder, CaterpillarCounts | 5 | rho_balanced_strict/le/eq_iff, eventual_balanced_minimum, balanced_component |
| 52 | BalancedFinalAudit | 11079 | `18f1016ece5fb51028d8450c0d1574c875b512bfa363562ad9ce8cad374a5d35` | LiteralHistory, SourceHistory, SourceFiber, CardinalRecurrence, DuplicationSkeleton, WeightedSkeleton, LeastFixedPoint, SourceWeighted, EndpointAudit, AtomMass, ScalarBranch, ScalarEvaluation, HistoryEvaluation, BranchRegularity, HistoryOrder, ActualThreshold, ThresholdFacts, LogFekete, ActualRootLimit, GeometricBridge, ThresholdIdentity, SpeciesShapes, FiniteShapes, StrictChildThreshold, ThresholdUniqueness, ClosureAudit, ShapeTransport, CatalanAssociator, BranchDomain, ClippedCatalan, RealAssociator, BranchGlobal, CaterpillarOrder, StrictRotation, StrictMerge, CaterpillarSplit, StrictExtension, StrictCaterpillar, CatalanDerivative, ConjugateSlope, LogConjugateConvex, CaterpillarCounts, LeafExpansion, BalancedExpansion, LogConjugateExpansive, ProgressAudit, BalancedFinalDiscrete, BalancedFinalSplit, BalancedFinalValues, BalancedFinalOrder, BalancedFinalExtremum | 0 | 51 imports, 237 #print axioms lines |

Total 126,600 bytes; 237 declarations.

## 7. Advisories (not load-bearing for this component; preserve for final assembly)

- **A1. Balanced class presentation.** No source predicate "every node's child leaf counts differ by at most 1" appears in the 52 modules. The minimizer class is stated as the ShapeIso class of the floor/ceiling representative `balanced k`. Ordinary bridge (mine): if s is source-balanced with k >= 2 leaves, its root split is {floor(k/2), ceil(k/2)} and its children are balanced. By induction they are ShapeIso to B_floor and B_ceil, and node or swap gives ShapeIso s B_k. Conversely, ShapeIso preserves per-node unordered child leaf counts, and B_k is balanced. So the two classes coincide; source footnote 3 states exactly this. The final literal endpoint MAY add an explicit `IsBalanced` predicate and this equivalence for literal-text fidelity. This does not affect truth.
- **A2. Eventual quantifier is necessary.** count(s,1) = k for every k-leaf s: a size-1 history uses no duplication or `both`, only a keep-chain to one leaf. So strict minimality or maximality at all n is false, and the component correctly asserts only n >= N_k. This matches "for a given k and n large enough". N_k depends on k, not uniformly across k.
- **A3. Radius versus growth factor.** `balanced_component` speaks of `rho`. Its meaning as the actual radius and as 1/(actual nth-root limit) lives in separately proved closure theorems (`historySum_finite_iff`, `actual_root_limit`, `growth_eq_inv_rho`), not in the endpoint type. Final growth-language claims should export or cite those.
- **A4. Degenerate k = 0.** `balanced 0 = caterpillar 0 = leaf`. The balanced component excludes k = 0, and the eventual caterpillar statement is vacuous there. No source content is lost.
- **A5. Growth clauses.** The superlinear caterpillar and linear balanced growth clauses are absent from these modules: UNPAID, outside this review.
- **A6. Kernel evidence.** I performed no compile or kernel check. The truth of tactic steps rests on the author's attributed compile/check evidence until the planned single fresh assembled extraction, rebuild and separate kernel check. My reading verifies statements, definitions and the mathematical soundness of every argument structure; it does not certify that tactics elaborate.

## 8. Hostile SELF review

- Possible semantic substitution? I checked the Hist constructors against grammar rules (1)-(5): none is missing and none is extra. Losses occur only as speciation siblings, and extant leaves occur only at leaf species.
- Counts versus clipped helpers? `count` is literal Fintype.card. `branchValue`, `mergeValue` and `logValue` use clipped sqrt, but every transfer to `rho` or `count` goes through the actual threshold (`representation`/`endpoint`/`infinite`) or through actual root limits. I found no proxy count.
- Hidden choice in the threshold? Classical.choose picks an IVT point, but `historySum_finite_iff` proves it equals the convergence boundary, so the choice cannot matter.
- Cutoff over representatives? `eventual_*` quantifies over `{s // leaves s = k}` through an exhaustive Fintype (pool membership proved). Every genuine ordered k-leaf species is covered, so no extremum is assumed.
- ShapeIso too coarse or too fine? It is generated only by per-node swaps and congruence, so it equals unordered-shape isomorphism. Duplication order is untouched (`swapRoot` keeps dup order).
- Index or domain leaks in the discrete argument? I verified center 2, odd, even, K bounds and closed-domain membership on both sides of every application.
- Reviewer limitations:
  - The PMC final text was read only in targeted slices, not in full.
  - I did not personally reread the INDEPENDENT-PROOF / DIRECT-COUNT-GROWTH handoffs, which are growth/contribution narratives.
  - Contribution, novelty and prior-art risks are not assessed here. I preserve, as attributed by the author and root: root's bounded SUBSTANTIAL selection, the strong routine nonlinear-aggregation objection, and the unread hypotheses of Parker, *Conditions for Optimality of the Huffman Algorithm* (DOI 10.1137/0209035; SIAM robots denial; closed, no recovery). Gromada, the DMGT companion, toggleability/homomesy, github.com/openai/math and all protected origins stay closed. I make no worldwide-priority claim.

## 9. Read / unread / resource / process inventory

**Personally read in full:**
- TASK.txt and the own override/model/display/budget/reservation/routing/authorization JSONs.
- The three AGENTS files (root, batch2, new-twenty) and `prospective-control-reading-scope-clarification`.
- The model-mix authorization.
- bootstrap.py, run.py, verify_frozen.py and write_lane.py.
- The PDF-SKILL.
- The matched narratives: parker-huffman access control, the 342705 intake, the owned target binding, the live statement field release, the SOURCE-IDENTITY-CARD, candidate metadata, and the MathDB raw record.
- The BALANCED-PAPER prose sections from line 1 to the appendix, the expanded endpoint, and the command and environment maps. The import/hash table was machine-checked and only partly read by eye.
- **All 52 production module bodies (126,600 bytes) in full, in dependency order, from my own `src/`.**
- The BALANCED-HANDOFF 4-line export header. Its prose and appendix are byte-identical to the paper (machine diff), so I did not reread them.

**Source slices read** (v1 TXT and rendered pages 6 and 16): Section 2, Definition 2.1, Remarks 2.1-2.2, Theorem 3.1 with its proof, (7)-(10), the Theorem 3.3 statement, the Section 4.1 definitions, Section 4.2 and Conjecture 4.1 with its footnotes. Final-version slices are listed in Section 2.

**Machine-screened only (not personal reading):**
- All 39 own JSON controls, recursively over 13,179 keys and scalars, normalized against the target, arXiv/PMC IDs, title, DOI, the three authors and topic aliases (`controls-screen-v1-hits.json`). There were no hits in additional-work-restrictions, inherited-denials or frozen-inputs. The only access-control hit was the Parker narrative, whose path mentions dl-history; I read it in full.
- The bulk of inherited-denials (293 KB) and the unrelated additional-work-restriction narratives were screened but not personally reread, as the prospective clarification permits.

**Unread:** the full PMC body; INDEPENDENT-PROOF-SOURCE-CONTRIBUTION-SELF-HANDOFF; DIRECT-COUNT-GROWTH-SELF-HANDOFF; sanitized-acceptance-release-111; imset/other park and control JSON bodies beyond the machine screen; FORMAL-HANDOFF-v2 (not supplied); and every producer lane, build or olean.

**Resources:** every runner job used `run.py` (CPU set 2-3, CPU 115 s, AS 6 GiB, sampled RSS guard 6 GiB, deadline 130 s). There were 7 runs: controls-screen, pdf-render, extract52, source-scan, closure-crosscheck, the final report compose, and seal-manifest. Each had wall time under 1 s and RSS under 20 MB. Bootstrap and frozen-before ran with `taskset -c 2,3`. Formal 0/0, GET 0/0, searches 0/0, scientific prototypes 0/0.

**Process deviations (UNWAIVED):**
- (i) My first two reads, before bootstrap, displayed the full TASK (9,823 characters) and a combined control dump of about 7,000 characters in single responses. Both exceeded the 6,000-character per-response ceiling and were not bounded slices.
- (ii) Many later responses exceeded the 2,000-character logical slice and/or the 2,400-character payload. Examples: several whole-module `cat` displays of 2.5-3.6 KB, including the BalancedFinalAudit import and grep display. All post-bootstrap responses stayed under 6,000 characters.
- (iii) Many read-only display commands (cat, head, sed, grep, plus small python -I display snippets, one pdftotext page check and one sha256sum) ran directly in the shell, not under run.py or taskset.
- (iv) `controls-screen-v1-hits.json` was written by the runner child with open(), not through write_lane.py.
- (v) Early cwd mistakes: one failed `cd inputs` and one runner call from the wrong directory, which failed harmlessly.
- (vi) A shell `cd` changed the session cwd several times. No writes occurred outside the lane.

No network, search, Lean, children, credit or ledger actions occurred, and no other lane or origin was traversed.

## 10. Handoff

The final integration may reuse this personal coverage ONLY for modules whose source sha256 equals the table above. It must independently review every new growth or assembly module and the full final expanded endpoint (including A1/A3 if growth-factor or literal balanced-predicate language is used), and then perform the single fresh extraction, rebuild and separate kernel check. My reading must not be attributed to later agents. All historical and current defects remain UNWAIVED. Credit added: 0.
