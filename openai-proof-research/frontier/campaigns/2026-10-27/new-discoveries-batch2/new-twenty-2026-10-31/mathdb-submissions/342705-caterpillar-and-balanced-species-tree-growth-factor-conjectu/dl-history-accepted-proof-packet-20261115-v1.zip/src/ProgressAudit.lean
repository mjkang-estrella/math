import ClosureAudit
import CaterpillarCounts
import BalancedExpansion
import LogConjugateExpansive
#print LiteralDL.eventual_caterpillar_maximum
#print LiteralDL.rho_caterpillar_strict
#print axioms LiteralDL.ShapeIso.refl
#print axioms LiteralDL.ShapeIso.symm
#print axioms LiteralDL.ShapeIso.trans
#print axioms LiteralDL.ShapeIso.count_eq
#print axioms LiteralDL.ShapeIso.rho_eq
#print axioms LiteralDL.rho_caterpillar_strict
#print axioms LiteralDL.eventual_caterpillar_maximum
#print axioms LiteralDL.balanced_successor_expansion
#print axioms LiteralDL.rho_balanced_successor_lt
#print axioms LiteralDL.logConjugate_strictConvex
#print axioms LiteralDL.logConjugate_expansive
