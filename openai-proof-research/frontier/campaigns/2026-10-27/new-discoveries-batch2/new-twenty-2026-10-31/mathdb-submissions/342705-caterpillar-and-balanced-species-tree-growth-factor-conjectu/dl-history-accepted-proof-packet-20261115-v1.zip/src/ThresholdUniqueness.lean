import StrictChildThreshold
open scoped ENNReal
namespace LiteralDL

theorem rho_eq_of_historySum_eq (a b : Species)
    (h : ∀ z : ℝ≥0∞, historySum a z = historySum b z) : rho a = rho b := by
  apply le_antisymm
  · apply (historySum_finite_iff b (rho_pos a).le).mp
    rw [← h]
    exact (historySum_finite_iff a (rho_pos a).le).mpr le_rfl
  · apply (historySum_finite_iff a (rho_pos b).le).mp
    rw [h]
    exact (historySum_finite_iff b (rho_pos b).le).mpr le_rfl

theorem rho_swap (a b : Species) : rho (.node a b) = rho (.node b a) := by
  apply rho_eq_of_historySum_eq
  intro z
  rw [historySum_coeff, historySum_coeff]
  simp_rw [count_swap a b]

theorem rho_node_lt_right (a b : Species) : rho (.node a b) < rho b := by
  rw [rho_swap]
  exact rho_node_lt_left b a

#print axioms rho_eq_of_historySum_eq
#print axioms rho_swap
#print axioms rho_node_lt_right
end LiteralDL
