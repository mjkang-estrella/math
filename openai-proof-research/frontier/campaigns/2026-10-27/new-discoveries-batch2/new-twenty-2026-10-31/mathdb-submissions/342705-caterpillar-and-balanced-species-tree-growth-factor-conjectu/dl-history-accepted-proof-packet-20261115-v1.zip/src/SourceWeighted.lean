import LeastFixedPoint
open scoped ENNReal
namespace LiteralDL

def sizeEquiv (s : Species) : Hist s ≃ (n : Nat) × Fiber s n where
  toFun h := ⟨size h, ⟨h,rfl⟩⟩
  invFun h := h.2.1
  left_inv _ := rfl
  right_inv h := by rcases h with ⟨n,h,hn⟩; cases hn; rfl

theorem historySum_coeff (s : Species) (z : ℝ≥0∞) :
    historySum s z = ∑' n : Nat, (count s n : ℝ≥0∞) * z^n := by
  calc
    historySum s z = ∑' h : (n : Nat) × Fiber s n,
        z ^ size h.2.1 := ((sizeEquiv s).symm.tsum_eq _).symm
    _ = ∑' n : Nat, (count s n : ℝ≥0∞) * z^n := by
      rw [ENNReal.tsum_sigma']
      apply tsum_congr
      intro n
      have he : (fun h : Fiber s n => z ^ size h.1) = (fun _ : Fiber s n => z^n) := by
        funext h
        rw [h.2]
      rw [he]
      simp [count]

/-- A source-specific prefix bound, obtained without a recurrence-defined count. -/
theorem historySum_le_of_atom_prefixed (s : Species) (z r : ℝ≥0∞)
    (hr : (∑' a : Atom s, z ^ size (atomHist a)) + r*r ≤ r) :
    historySum s z ≤ r := by
  rw [historySum_skeleton]
  exact total_le_of_prefixed _ r hr

#print axioms historySum_coeff
#print axioms historySum_le_of_atom_prefixed
end LiteralDL
