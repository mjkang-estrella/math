import BalancedFinalSplit
namespace LiteralDL.BalancedStage
open LiteralDL

noncomputable def logValue (s : Species) (z : ℝ) := Real.log (1+branchValue s z)

theorem logValue_nonneg (s : Species) {z : ℝ} (hz : 0 ≤ z) : 0 ≤ logValue s z :=
  Real.log_nonneg (by linarith [(branchValue_global_bounds s hz).1])

theorem logValue_pos (s : Species) {z : ℝ} (hz : 0 < z) (hr : z ≤ rho s) :
    0 < logValue s z := Real.log_pos (by linarith [branchValue_pos hz hr])

theorem exp_logValue (s : Species) {z : ℝ} (hz : 0 ≤ z) :
    Real.exp (logValue s z) = 1+branchValue s z :=
  Real.exp_log (by linarith [(branchValue_global_bounds s hz).1])

theorem exp_log_pair (a b : Species) {z : ℝ} (hz : 0 ≤ z) :
    Real.exp (logValue a z+logValue b z)-1 =
      branchValue a z+branchValue b z+branchValue a z*branchValue b z := by
  rw [Real.exp_add,exp_logValue a hz,exp_logValue b hz]
  ring

theorem logValue_node (a b : Species) {z : ℝ} (hz : 0 ≤ z) :
    logValue (.node a b) z = logConjugate (logValue a z+logValue b z) := by
  unfold logConjugate
  rw [exp_log_pair a b hz]
  rfl

theorem logValue_input_mem (a b : Species) {z : ℝ} (hz : 0 ≤ z)
    (hr : z ≤ rho (.node a b)) :
    logValue a z+logValue b z ∈ Set.Icc 0 (Real.log (5/4)) := by
  refine ⟨add_nonneg (logValue_nonneg a hz) (logValue_nonneg b hz),?_⟩
  have he := exp_log_pair a b hz
  have hq := node_input_le_quarter a b hz hr
  apply Real.exp_le_exp.mp
  rw [Real.exp_log (by norm_num : (0:ℝ)<5/4)]
  linarith

theorem balanced_radius_antitone {i K : Nat} (hi : 1 ≤ i) (hik : i ≤ K) :
    rho (balanced K) ≤ rho (balanced i) := by
  induction K, hik using Nat.le_induction with
  | base => exact le_rfl
  | succ K hK ih =>
    exact (rho_balanced_successor_lt (by omega : 0 < K)).le.trans ih

theorem balanced_log_discrete {K : Nat} (hK : 1 ≤ K) {z : ℝ} (hz : 0 < z)
    (hr : z ≤ rho (balanced K)) :
    ∀ n, 2 ≤ n → n+1 ≤ K →
      2*logValue (balanced n) z < logValue (balanced (n-1)) z+logValue (balanced (n+1)) z := by
  apply discrete_convex (fun n => logValue (balanced n) z) K
  · exact logValue_pos _ hz (hr.trans (balanced_radius_antitone (by omega) (by omega)))
  · intro i hi hiK
    have he := (balanced_successor_expansion (by omega : 0 < i)).strict_value hz
      (hr.trans (balanced_radius_antitone (by omega) hiK))
    exact Real.log_lt_log (by linarith [(branchValue_global_bounds (balanced i) hz.le).1])
      (by linarith : 1+branchValue (balanced i) z < 1+branchValue (balanced (i+1)) z)
  · intro i hi hiK
    have h := logValue_input_mem (balanced (i/2)) (balanced ((i+1)/2)) hz.le
    have he := balanced_node hi
    rw [← he] at h
    exact h (hr.trans (balanced_radius_antitone (by omega) hiK))
  · intro i hi hiK
    rw [balanced_node hi,logValue_node _ _ hz.le]

#print axioms balanced_log_discrete
end LiteralDL.BalancedStage
