import ThresholdIdentity
namespace LiteralDL

def leaves : Species → Nat
  | .leaf => 1
  | .node a b => leaves a + leaves b

theorem leaves_pos (s : Species) : 0 < leaves s := by
  induction s <;> simp_all [leaves]

def caterpillar : Nat → Species
  | 0 => .leaf
  | 1 => .leaf
  | n+2 => .node (caterpillar (n+1)) .leaf

def balanced : Nat → Species
  | 0 => .leaf
  | 1 => .leaf
  | n+2 => .node (balanced ((n+2)/2)) (balanced ((n+3)/2))
termination_by n => n
 decreasing_by all_goals omega

theorem leaves_caterpillar {k : Nat} (hk : 0 < k) : leaves (caterpillar k) = k := by
  induction k with
  | zero => omega
  | succ k ih =>
    cases k with
    | zero => simp [caterpillar, leaves]
    | succ j => simp only [caterpillar, leaves]; rw [ih (by omega)]

theorem leaves_balanced {k : Nat} (hk : 0 < k) : leaves (balanced k) = k := by
  induction k using Nat.strong_induction_on with
  | h k ih =>
    cases k with
    | zero => omega
    | succ k =>
      cases k with
      | zero => simp [balanced, leaves]
      | succ j =>
        rw [balanced, leaves, ih _ (by omega) (by omega), ih _ (by omega) (by omega)]
        omega

inductive ShapeIso : Species → Species → Prop where
  | leaf : ShapeIso .leaf .leaf
  | node {a b c d} : ShapeIso a c → ShapeIso b d → ShapeIso (.node a b) (.node c d)
  | swap {a b c d} : ShapeIso a d → ShapeIso b c → ShapeIso (.node a b) (.node c d)

#print axioms leaves_caterpillar
#print axioms leaves_balanced
end LiteralDL
