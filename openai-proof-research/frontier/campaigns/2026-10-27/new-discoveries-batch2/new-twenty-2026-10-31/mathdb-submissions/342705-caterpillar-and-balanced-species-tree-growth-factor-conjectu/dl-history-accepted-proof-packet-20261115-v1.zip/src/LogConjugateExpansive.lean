import LogConjugateConvex
namespace LiteralDL

theorem logConjugate_zero : logConjugate 0 = 0 := by
  simp [logConjugate,catalanBranch_zero]

theorem conjugate_branch_interior {x : ℝ} (hx : 0 < x) (hxu : x < Real.log (5/4)) :
    0 < catalanBranch (Real.exp x-1) ∧ catalanBranch (Real.exp x-1) < 1/2 := by
  have hq0 : 0 < Real.exp x-1 := by
    have h := Real.exp_lt_exp.mpr hx
    rw [Real.exp_zero] at h
    linarith
  have hq1 := conjugate_input_lt hxu
  constructor
  · have h := catalanBranch_strictMono
      (show (0:ℝ) ∈ Set.Icc 0 (1/4) from ⟨le_rfl,by norm_num⟩) ⟨hq0.le,hq1.le⟩ hq0
    simpa only [catalanBranch_zero] using h
  · have h := catalanBranch_strictMono ⟨hq0.le,hq1.le⟩
      (show (1/4:ℝ) ∈ Set.Icc 0 (1/4) from ⟨by norm_num,le_rfl⟩) hq1
    simpa only [catalanBranch_quarter] using h

theorem logConjugate_minus_id_strictMono :
    StrictMonoOn (fun x => logConjugate x-x) (Set.Icc 0 (Real.log (5/4))) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc _ _) (logConjugate_continuousOn.sub continuousOn_id)
  rw [interior_Icc]
  intro x hx
  have hd := (hasDerivAt_logConjugate hx.1.le hx.2).sub (hasDerivAt_id x)
  rw [hd.deriv]
  rw [← (hasDerivAt_logConjugate hx.1.le hx.2).deriv,deriv_logConjugate hx.1.le hx.2]
  have hu := conjugate_branch_interior hx.1 hx.2
  exact sub_pos.mpr (conjugateSlope_gt_one hu.1 hu.2)

theorem logConjugate_expansive {x y : ℝ} (hx : x ∈ Set.Icc 0 (Real.log (5/4)))
    (hy : y ∈ Set.Icc 0 (Real.log (5/4))) (hxy : x < y) :
    y-x < logConjugate y-logConjugate x := by
  have h := logConjugate_minus_id_strictMono hx hy hxy
  linarith

#print axioms logConjugate_expansive
end LiteralDL
