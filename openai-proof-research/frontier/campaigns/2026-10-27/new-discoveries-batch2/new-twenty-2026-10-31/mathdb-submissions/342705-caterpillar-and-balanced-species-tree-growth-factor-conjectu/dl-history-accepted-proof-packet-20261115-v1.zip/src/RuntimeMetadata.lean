import FinalAssembly
#eval Lean.versionString
