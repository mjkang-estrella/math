import WeightedSkeleton
open scoped ENNReal
namespace LiteralDL

def skHeight {α : Type} : Skeleton α → Nat
  | .atom _ => 1
  | .fork x y => max (skHeight x) (skHeight y) + 1

noncomputable def cutWeight {α : Type} (d : Nat) (f : α → ℝ≥0∞) (t : Skeleton α) :=
  if skHeight t ≤ d then skWeight f t else 0
noncomputable def cutTotal {α : Type} (d : Nat) (f : α → ℝ≥0∞) := ∑' t, cutWeight d f t

theorem cutWeight_fork {α : Type} (d : Nat) (f : α → ℝ≥0∞) (x y : Skeleton α) :
    cutWeight (d+1) f (.fork x y) = cutWeight d f x * cutWeight d f y := by
  simp only [cutWeight, skHeight, skWeight]
  by_cases hx : skHeight x ≤ d <;> by_cases hy : skHeight y ≤ d <;>
    simp [hx, hy]

theorem cutTotal_succ {α : Type} (d : Nat) (f : α → ℝ≥0∞) :
    cutTotal (d+1) f = (∑' a, f a) + cutTotal d f * cutTotal d f := by
  calc
    cutTotal (d+1) f = ∑' u : α ⊕ (Skeleton α × Skeleton α),
        cutWeight (d+1) f ((rootEquiv α).symm u) :=
      ((rootEquiv α).symm.tsum_eq (cutWeight (d+1) f)).symm
    _ = (∑' a, f a) + cutTotal d f * cutTotal d f := by
      rw [ENNReal.summable.tsum_sum ENNReal.summable]
      change (∑' a, cutWeight (d+1) f (.atom a)) +
        (∑' xy : Skeleton α × Skeleton α, cutWeight (d+1) f (.fork xy.1 xy.2)) = _
      simp only [cutWeight_fork]
      have ha : ∀ a : α, cutWeight (d+1) f (.atom a) = f a := by
        intro a
        simp [cutWeight, skHeight, skWeight]
      simp_rw [ha]
      congr 1
      rw [ENNReal.tsum_prod']
      simp_rw [ENNReal.tsum_mul_left]
      exact ENNReal.tsum_mul_right

theorem cutTotal_zero {α : Type} (f : α → ℝ≥0∞) : cutTotal 0 f = 0 := by
  have hh : ∀ t : Skeleton α, ¬ skHeight t ≤ 0 := by
    intro t
    cases t <;> simp [skHeight]
  simp [cutTotal, cutWeight, hh]

theorem cutTotal_bound {α : Type} (f : α → ℝ≥0∞) (r : ℝ≥0∞)
    (hr : (∑' a, f a) + r*r ≤ r) (d : Nat) : cutTotal d f ≤ r := by
  induction d with
  | zero => rw [cutTotal_zero]; exact zero_le
  | succ d ih =>
    rw [cutTotal_succ]
    exact le_trans (add_le_add le_rfl (mul_le_mul' ih ih)) hr

/-- The nonnegative total is below every prefixed scalar bound. -/
theorem total_le_of_prefixed {α : Type} (f : α → ℝ≥0∞) (r : ℝ≥0∞)
    (hr : (∑' a, f a) + r*r ≤ r) : total f ≤ r := by
  classical
  unfold total
  rw [ENNReal.tsum_eq_iSup_sum]
  apply iSup_le
  intro F
  let d := ∑ t ∈ F, skHeight t
  have hd : ∀ t ∈ F, skHeight t ≤ d := by
    intro t ht
    exact Finset.single_le_sum (fun _ _ => Nat.zero_le _) ht
  have he : (∑ t ∈ F, skWeight f t) = ∑ t ∈ F, cutWeight d f t := by
    apply Finset.sum_congr rfl
    intro t ht
    simp [cutWeight, hd t ht]
  rw [he]
  exact le_trans (ENNReal.sum_le_tsum F) (cutTotal_bound f r hr d)

#print axioms total_le_of_prefixed
end LiteralDL
