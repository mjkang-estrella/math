import GrowthFinalAsymptotic
namespace LiteralDL.GrowthStage
open LiteralDL Filter
set_option maxHeartbeats 1000000

theorem caterpillar_superlinear :
    Tendsto (fun k : Nat => growth (caterpillar k)/(k:ℝ)) atTop atTop := by
  apply tendsto_atTop.2
  intro M
  obtain ⟨N,hN⟩ := exists_nat_gt (3*M^2+2)
  filter_upwards [eventually_ge_atTop N] with k hk
  have hNk : (N:ℝ) ≤ k := by exact_mod_cast hk
  have hk2 : (2:ℝ) < k := by nlinarith [sq_nonneg M]
  have hk0 : (0:ℝ) < k := by linarith
  have hkn : 0 < k := by exact_mod_cast hk0
  by_cases hM : M ≤ 0
  · exact hM.trans (div_nonneg (growth_pos _).le hk0.le)
  have hMp : 0 < M := lt_of_not_ge hM
  by_contra hnot
  have hlt : growth (caterpillar k)/(k:ℝ) < M := lt_of_not_ge hnot
  have hglt : growth (caterpillar k) < M*(k:ℝ) := (div_lt_iff₀ hk0).mp hlt
  have hg := growth_pos (caterpillar k)
  have hsq : growth (caterpillar k)^2 < M^2*(k:ℝ)^2 := by
    nlinarith only [hglt, hg, mul_pos hMp hk0]
  have hc := caterpillar_square_lower k hkn
  have hkk : 2*(k:ℝ) ≤ (k:ℝ)^3 := by
    have hp := mul_nonneg (show 0 ≤ (k:ℝ)^2-2 by nlinarith only [hk2]) hk0.le
    nlinarith only [hp]
  have hg3 : (k:ℝ)^3 ≤ 3*growth (caterpillar k)^2 := by nlinarith only [hc,hkk]
  have hkp : 0 < (k:ℝ)-3*M^2 := by linarith
  have hp := mul_pos hkp (sq_pos_of_pos hk0)
  nlinarith only [hp,hsq,hg3]

end LiteralDL.GrowthStage
