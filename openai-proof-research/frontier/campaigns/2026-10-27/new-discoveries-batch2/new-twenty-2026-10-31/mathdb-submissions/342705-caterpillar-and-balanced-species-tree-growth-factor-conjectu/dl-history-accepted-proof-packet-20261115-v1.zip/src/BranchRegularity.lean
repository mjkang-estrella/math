import HistoryEvaluation
import Mathlib.Topology.Order.IntermediateValue
namespace LiteralDL

noncomputable def branchValue : Species → ℝ → ℝ
  | .leaf, z => catalanBranch z
  | .node a b, z => catalanBranch (branchValue a z + branchValue b z + branchValue a z * branchValue b z)

theorem continuous_catalanBranch : Continuous catalanBranch := by
  unfold catalanBranch
  fun_prop

theorem branchValue_continuous (s : Species) : Continuous (branchValue s) := by
  induction s with
  | leaf => exact continuous_catalanBranch
  | node a b ia ib => exact continuous_catalanBranch.comp ((ia.add ib).add (ia.mul ib))

theorem catalanBranch_zero : catalanBranch 0 = 0 := by simp [catalanBranch]
theorem catalanBranch_quarter : catalanBranch (1/4) = 1/2 := by norm_num [catalanBranch]

theorem branchValue_zero (s : Species) : branchValue s 0 = 0 := by
  induction s <;> simp_all [branchValue, catalanBranch_zero]

theorem catalanBranch_strictMono : StrictMonoOn catalanBranch (Set.Icc 0 (1/4)) := by
  intro x hx y hy hxy
  obtain ⟨hx0,hxh,hxe⟩ := catalanBranch_properties hx.1 hx.2
  obtain ⟨hy0,hyh,hye⟩ := catalanBranch_properties hy.1 hy.2
  by_contra h
  have hle : catalanBranch y ≤ catalanBranch x := le_of_not_gt h
  have hprod := mul_nonneg (sub_nonneg.mpr hle)
    (show 0 ≤ 1 - catalanBranch x - catalanBranch y by linarith)
  nlinarith

#print axioms branchValue_continuous
#print axioms branchValue_zero
#print axioms catalanBranch_strictMono
end LiteralDL
