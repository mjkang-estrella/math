import GrowthFinalCaterpillar
import GrowthFinalBalanced
namespace LiteralDL.GrowthStage
open LiteralDL Filter
set_option maxHeartbeats 1000000

theorem caterpillar_square_lower (k : Nat) (hk : 0 < k) :
    (k:ℝ)^3-(k:ℝ) ≤ 3/2 * growth (caterpillar k)^2 := by
  let s := caterpillar k
  have h := caterpillar_cubic k hk (rho_pos s).le le_rfl
  have ep : branchValue (caterpillar k) (rho s) = 1/2 := (actualThreshold s).endpoint
  rw [ep] at h
  have he : growth s * rho s = 1 := le_antisymm (growth_mul_rho_le s) (growth_mul_rho_ge s)
  have hi : rho s ^2 * growth s ^2 = 1 := by
    calc
      _ = (growth s * rho s)^2 := by ring
      _ = 1 := by rw [he]; norm_num
  have hm := mul_le_mul_of_nonneg_right h (sq_nonneg (growth s))
  change (((k:ℝ)^3-(k:ℝ))/3 * rho s ^2) * growth s ^2 ≤ _ at hm
  rw [mul_assoc, hi, mul_one] at hm
  nlinarith only [hm]

theorem balanced_growth_upper (k : Nat) (hk : 0 < k) :
    growth (balanced k) ≤ 1000*(k:ℝ) := by
  let s := balanced k
  have hr := rho_pos s
  have hg := growth_pos s
  have he : growth s * rho s = 1 := le_antisymm (growth_mul_rho_le s) (growth_mul_rho_ge s)
  by_contra hn
  have hl : 1000*(k:ℝ) < growth s := lt_of_not_ge hn
  have hs : (k:ℝ)*rho s ≤ 1/1000 := by nlinarith
  have hb := balanced_value_bound k hk hr.le le_rfl hs
  have ep : branchValue (balanced k) (rho s) = 1/2 := (actualThreshold s).endpoint
  rw [ep] at hb
  have hz : 0 ≤ (k:ℝ)*rho s := by positivity
  nlinarith

end LiteralDL.GrowthStage
