import BranchGlobal
namespace LiteralDL

theorem caterpillar_succ {k : Nat} (hk : 0 < k) :
    caterpillar (k+1) = .node (caterpillar k) .leaf := by
  cases k with
  | zero => omega
  | succ k => rfl

theorem caterpillar_merge_le {a b : Nat} (ha : 0 < a) (hb : 0 < b)
    {z : ℝ} (hz : 0 ≤ z) :
    mergeValue (branchValue (caterpillar a) z) (branchValue (caterpillar b) z) ≤
      branchValue (caterpillar (a+b)) z := by
  induction b with
  | zero => omega
  | succ b ih =>
    cases b with
    | zero =>
      rw [caterpillar_succ ha]
      rfl
    | succ b =>
      have hbp : 0 < b+1 := by omega
      rw [caterpillar_succ hbp, show a+(b+1+1) = (a+(b+1))+1 by omega,
        caterpillar_succ (by omega : 0 < a+(b+1))]
      change mergeValue (branchValue (caterpillar a) z)
        (mergeValue (branchValue (caterpillar (b+1)) z) (branchValue .leaf z)) ≤
        mergeValue (branchValue (caterpillar (a+(b+1))) z) (branchValue .leaf z)
      exact (mergeValue_associator (branchValue_global_bounds _ hz).1
        (branchValue_global_bounds _ hz).1 (branchValue_global_bounds _ hz).1
        (branchValue_ge_leaf _ hz)).trans
        (mergeValue_mono (mergeValue_nonneg (branchValue_global_bounds _ hz).1
          (branchValue_global_bounds _ hz).1) (branchValue_global_bounds _ hz).1
          (ih hbp) le_rfl)

theorem branchValue_le_caterpillar (s : Species) {z : ℝ} (hz : 0 ≤ z) :
    branchValue s z ≤ branchValue (caterpillar (leaves s)) z := by
  induction s with
  | leaf => rfl
  | node a b ia ib =>
    exact (mergeValue_mono (branchValue_global_bounds _ hz).1
      (branchValue_global_bounds _ hz).1 ia ib).trans
      (caterpillar_merge_le (leaves_pos a) (leaves_pos b) hz)

theorem rho_caterpillar_le (s : Species) : rho (caterpillar (leaves s)) ≤ rho s :=
  rho_le_of_global_branch_le s _ (fun _ hz => branchValue_le_caterpillar s hz)

#print axioms branchValue_le_caterpillar
#print axioms rho_caterpillar_le
end LiteralDL
