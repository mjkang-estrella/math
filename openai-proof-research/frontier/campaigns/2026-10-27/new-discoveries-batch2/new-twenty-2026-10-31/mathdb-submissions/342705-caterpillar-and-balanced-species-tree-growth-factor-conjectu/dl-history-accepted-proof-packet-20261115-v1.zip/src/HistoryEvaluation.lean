import ScalarEvaluation
open scoped ENNReal
namespace LiteralDL

theorem atomMass_leaf (z : ℝ≥0∞) :
    (∑' q : Atom .leaf, z ^ size (atomHist q)) = z := by
  rw [tsum_eq_single Atom.extant]
  · simp [atomHist, size]
  · intro q h
    cases q
    exact (h rfl).elim

theorem historySum_leaf_principal {z : ℝ} (hz : 0 ≤ z) (hq : z ≤ 1/4) :
    historySum .leaf (ENNReal.ofReal z) = ENNReal.ofReal (catalanBranch z) := by
  rw [historySum_skeleton]
  exact total_principal _ hz hq (atomMass_leaf _)

theorem historySum_leaf_infinite {z : ℝ} (hz : 1/4 < z) :
    historySum .leaf (ENNReal.ofReal z) = ⊤ := by
  rw [historySum_skeleton]
  exact total_infinite_above _ hz (atomMass_leaf _)

theorem historySum_node_principal (a b : Species) (z : ℝ≥0∞) {x y : ℝ}
    (hx : 0 ≤ x) (hy : 0 ≤ y)
    (ha : historySum a z = ENNReal.ofReal x)
    (hb : historySum b z = ENNReal.ofReal y)
    (hq : x+y+x*y ≤ 1/4) :
    historySum (.node a b) z = ENNReal.ofReal (catalanBranch (x+y+x*y)) := by
  rw [historySum_skeleton]
  apply total_principal _ (by positivity) hq
  rw [atomMass_node, ha, hb, ← ENNReal.ofReal_mul hx,
    ← ENNReal.ofReal_add hx hy, ← ENNReal.ofReal_add (add_nonneg hx hy) (mul_nonneg hx hy)]

#print axioms atomMass_leaf
#print axioms historySum_leaf_principal
#print axioms historySum_leaf_infinite
#print axioms historySum_node_principal
end LiteralDL
