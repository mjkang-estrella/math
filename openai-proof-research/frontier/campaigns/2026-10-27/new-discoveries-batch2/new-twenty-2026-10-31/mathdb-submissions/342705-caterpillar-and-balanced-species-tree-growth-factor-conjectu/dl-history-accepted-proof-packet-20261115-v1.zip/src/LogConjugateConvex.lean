import ConjugateSlope
namespace LiteralDL

theorem conjugate_input_nonneg {x : ℝ} (hx : 0 ≤ x) : 0 ≤ Real.exp x-1 := by
  have := Real.one_le_exp hx
  linarith

theorem conjugate_input_lt {x : ℝ} (hx : x < Real.log (5/4)) : Real.exp x-1 < 1/4 := by
  have h := (Real.exp_lt_exp.mpr hx).trans_eq (Real.exp_log (by norm_num : (0:ℝ) < 5/4))
  linarith

theorem logConjugate_continuousOn :
    ContinuousOn logConjugate (Set.Icc 0 (Real.log (5/4))) := by
  apply ContinuousOn.log
  · exact (continuous_const.add (continuous_catalanBranch.comp
      (Real.continuous_exp.sub continuous_const))).continuousOn
  · intro x hx
    have hc := (catalanBranch_global_bounds (conjugate_input_nonneg hx.1)).1
    linarith

theorem logConjugate_strictConvex :
    StrictConvexOn ℝ (Set.Icc 0 (Real.log (5/4))) logConjugate := by
  apply StrictMonoOn.strictConvexOn_of_deriv (convex_Icc _ _) logConjugate_continuousOn
  rw [interior_Icc]
  intro x hx y hy hxy
  rw [deriv_logConjugate hx.1.le hx.2,deriv_logConjugate hy.1.le hy.2]
  have hqx0 := conjugate_input_nonneg hx.1.le
  have hqy0 := conjugate_input_nonneg hy.1.le
  have hqx1 := conjugate_input_lt hx.2
  have hqy1 := conjugate_input_lt hy.2
  have hux0 := (catalanBranch_global_bounds hqx0).1
  have huy0 := (catalanBranch_global_bounds hqy0).1
  have hux1 : catalanBranch (Real.exp x-1) < 1/2 := by
    have h := catalanBranch_strictMono ⟨hqx0,hqx1.le⟩
      (show (1/4:ℝ) ∈ Set.Icc 0 (1/4) from ⟨by norm_num,le_rfl⟩) hqx1
    simpa only [catalanBranch_quarter] using h
  have huy1 : catalanBranch (Real.exp y-1) < 1/2 := by
    have h := catalanBranch_strictMono ⟨hqy0,hqy1.le⟩
      (show (1/4:ℝ) ∈ Set.Icc 0 (1/4) from ⟨by norm_num,le_rfl⟩) hqy1
    simpa only [catalanBranch_quarter] using h
  apply conjugateSlope_strictMono ⟨hux0,hux1⟩ ⟨huy0,huy1⟩
  exact catalanBranch_strictMono ⟨hqx0,hqx1.le⟩ ⟨hqy0,hqy1.le⟩
    (sub_lt_sub_right (Real.exp_lt_exp.mpr hxy) 1)

#print axioms logConjugate_strictConvex
end LiteralDL
