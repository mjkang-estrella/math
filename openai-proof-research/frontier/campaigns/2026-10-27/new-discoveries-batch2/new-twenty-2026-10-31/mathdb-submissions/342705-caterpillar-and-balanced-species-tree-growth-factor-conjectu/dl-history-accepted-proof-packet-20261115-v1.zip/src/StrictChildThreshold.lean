import FiniteShapes
open scoped ENNReal
namespace LiteralDL

theorem historySum_node_quadratic (a b : Species) (z : ℝ≥0∞) :
    historySum (.node a b) z = historySum a z + historySum b z + historySum a z * historySum b z +
      historySum (.node a b) z * historySum (.node a b) z := by
  have h := total_quadratic (fun q : Atom (.node a b) => z ^ size (atomHist q))
  rw [atomMass_node, ← historySum_skeleton] at h
  exact h

theorem rho_node_lt_left (a b : Species) : rho (.node a b) < rho a := by
  by_contra hn
  have hr : rho a ≤ rho (.node a b) := le_of_not_gt hn
  let z := ENNReal.ofReal (rho a)
  let H := historySum (.node a b) z
  have ha : historySum a z = ENNReal.ofReal (1/2) := historySum_at_rho a
  have hH : H ≤ ENNReal.ofReal (1/2) := by
    change historySum (.node a b) (ENNReal.ofReal (rho a)) ≤ _
    rw [(actualThreshold (.node a b)).representation (rho a) ⟨(rho_pos a).le,hr⟩]
    exact ENNReal.ofReal_le_ofReal ((actualThreshold (.node a b)).bounds (rho a) ⟨(rho_pos a).le,hr⟩).2
  have hl : ENNReal.ofReal (1/2) ≤ H := by rw [← ha]; exact historySum_node_ge_left a b z
  have hq : historySum a z + H*H ≤ H := by
    calc
      _ ≤ (historySum a z + historySum b z + historySum a z * historySum b z) + H*H := by gcongr; exact le_trans le_self_add le_self_add
      _ = H := (historySum_node_quadratic a b z).symm
  have hh : ENNReal.ofReal (1/2) + ENNReal.ofReal (1/2) * ENNReal.ofReal (1/2) ≤ ENNReal.ofReal (1/2) :=
    (add_le_add ha.ge (mul_le_mul' hl hl)).trans (hq.trans hH)
  have ht := ENNReal.toReal_mono ENNReal.ofReal_ne_top hh
  rw [ENNReal.toReal_add ENNReal.ofReal_ne_top (ENNReal.mul_ne_top ENNReal.ofReal_ne_top ENNReal.ofReal_ne_top), ENNReal.toReal_mul] at ht
  norm_num at ht

#print axioms rho_node_lt_left
end LiteralDL
