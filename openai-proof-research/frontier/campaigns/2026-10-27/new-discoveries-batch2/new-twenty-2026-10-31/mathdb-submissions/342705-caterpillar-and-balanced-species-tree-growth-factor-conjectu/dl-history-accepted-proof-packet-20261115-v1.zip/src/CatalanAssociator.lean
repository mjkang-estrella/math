import BranchRegularity
import Mathlib.Tactic.LinearCombination
namespace LiteralDL

theorem catalan_associator_identity {a b c x y : ℝ}
    (hx : a+b+a*b+x*x=x) (hy : c+b+c*b+y*y=y) :
    ((1+c)*x+c-((1+a)*y+a))*(1-x-y) = (a-c)*(x+y+x*y) := by
  linear_combination (1+a)*hy - (1+c)*hx

theorem catalan_associator_strict {a b c x y : ℝ}
    (hx : a+b+a*b+x*x=x) (hy : c+b+c*b+y*y=y)
    (hac : c < a) (hx0 : 0 < x) (hy0 : 0 ≤ y) (hxy : x+y < 1) :
    (1+a)*y+a < (1+c)*x+c := by
  have hid := catalan_associator_identity hx hy
  have hp : 0 < (a-c)*(x+y+x*y) :=
    mul_pos (sub_pos.mpr hac) (by positivity)
  have hd : 0 < 1-x-y := by linarith
  have : 0 < (1+c)*x+c-((1+a)*y+a) :=
    (mul_pos_iff_of_pos_right hd).mp (hid.symm ▸ hp)
  linarith

#print axioms catalan_associator_identity
#print axioms catalan_associator_strict
end LiteralDL
