import ScalarBranch
open scoped ENNReal
namespace LiteralDL

theorem total_principal {α : Type} (f : α → ℝ≥0∞) {t : ℝ}
    (ht : 0 ≤ t) (hq : t ≤ 1/4) (hm : (∑' a, f a) = ENNReal.ofReal t) :
    total f = ENNReal.ofReal (catalanBranch t) := by
  obtain ⟨hr0, hrh, hroot⟩ := catalanBranch_properties ht hq
  have hb : total f ≤ ENNReal.ofReal (catalanBranch t) := by
    apply total_le_of_prefixed
    rw [hm, ← ENNReal.ofReal_mul hr0, ← ENNReal.ofReal_add ht (mul_nonneg hr0 hr0), hroot]
  have hf : total f ≠ ⊤ := ne_top_of_le_ne_top ENNReal.ofReal_ne_top hb
  have he := congrArg ENNReal.toReal (total_quadratic f)
  rw [hm, ENNReal.toReal_add ENNReal.ofReal_ne_top (ENNReal.mul_ne_top hf hf),
    ENNReal.toReal_mul, ENNReal.toReal_ofReal ht] at he
  have hs : 0 ≤ (total f).toReal := ENNReal.toReal_nonneg
  have hsr : (total f).toReal ≤ catalanBranch t := by
    have := ENNReal.toReal_mono ENNReal.ofReal_ne_top hb
    simpa only [ENNReal.toReal_ofReal hr0] using this
  have hx : (total f).toReal = catalanBranch t := by nlinarith
  rw [← ENNReal.ofReal_toReal hf, hx]

theorem total_infinite_above {α : Type} (f : α → ℝ≥0∞) {t : ℝ}
    (ht : 1/4 < t) (hm : (∑' a, f a) = ENNReal.ofReal t) : total f = ⊤ := by
  by_contra hf
  have ht0 : 0 ≤ t := by linarith
  have he := congrArg ENNReal.toReal (total_quadratic f)
  rw [hm, ENNReal.toReal_add ENNReal.ofReal_ne_top (ENNReal.mul_ne_top hf hf),
    ENNReal.toReal_mul, ENNReal.toReal_ofReal ht0] at he
  nlinarith [sq_nonneg ((total f).toReal - 1/2)]

#print axioms total_principal
#print axioms total_infinite_above
end LiteralDL
