import SourceFiber
namespace LiteralDL
inductive Skeleton (α : Type) where
  | atom : α → Skeleton α
  | fork : Skeleton α → Skeleton α → Skeleton α

inductive Atom : Species → Type where
  | extant : Atom .leaf
  | both {a b} : Hist a → Hist b → Atom (.node a b)
  | keepLeft {a b} : Hist a → Atom (.node a b)
  | keepRight {a b} : Hist b → Atom (.node a b)

def atomHist {s} : Atom s → Hist s
  | .extant => .extant
  | .both x y => .both x y
  | .keepLeft x => .keepLeft x
  | .keepRight y => .keepRight y

def assemble {s} : Skeleton (Atom s) → Hist s
  | .atom a => atomHist a
  | .fork x y => .dup (assemble x) (assemble y)

def cutSkeleton {s} : Hist s → Skeleton (Atom s)
  | .extant => .atom .extant
  | .dup x y => .fork (cutSkeleton x) (cutSkeleton y)
  | .both x y => .atom (.both x y)
  | .keepLeft x => .atom (.keepLeft x)
  | .keepRight y => .atom (.keepRight y)

theorem assemble_cut {s} (h : Hist s) : assemble (cutSkeleton h) = h := by
  induction h <;> simp_all [cutSkeleton, assemble, atomHist]

theorem cut_assemble {s} (t : Skeleton (Atom s)) : cutSkeleton (assemble t) = t := by
  induction t with
  | atom a => cases a <;> rfl
  | fork x y ix iy => simp [assemble, cutSkeleton, ix, iy]

def skeletonEquiv (s : Species) : Hist s ≃ Skeleton (Atom s) where
  toFun := cutSkeleton
  invFun := assemble
  left_inv := assemble_cut
  right_inv := cut_assemble

def skeletonSize {s} : Skeleton (Atom s) → Nat
  | .atom a => size (atomHist a)
  | .fork x y => skeletonSize x + skeletonSize y

theorem assemble_size {s} (t : Skeleton (Atom s)) : size (assemble t) = skeletonSize t := by
  induction t <;> simp_all [assemble, skeletonSize, size]

#print axioms skeletonEquiv
#print axioms assemble_size
end LiteralDL
