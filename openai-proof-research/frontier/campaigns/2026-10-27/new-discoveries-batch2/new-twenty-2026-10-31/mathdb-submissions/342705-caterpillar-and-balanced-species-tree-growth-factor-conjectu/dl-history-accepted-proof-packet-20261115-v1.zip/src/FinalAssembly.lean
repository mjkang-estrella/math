import FinalSourceTransport
namespace LiteralDL.FinalStage
open LiteralDL Filter

theorem uniform_extrema (k : Nat) : ∃ N : Nat, 1 ≤ N ∧
    ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
      count (balanced k) n ≤ count s n ∧ count s n ≤ count (caterpillar k) n ∧
      (count (balanced k) n = count s n ↔ ShapeIso s (balanced k)) ∧
      (count s n = count (caterpillar k) n ↔ ShapeIso s (caterpillar k)) := by
  obtain ⟨A,hA,ha⟩ := BalancedStage.eventual_balanced_minimum k
  obtain ⟨B,hB,hb⟩ := eventual_caterpillar_maximum k
  refine ⟨max A B, hA.trans (le_max_left _ _), ?_⟩
  intro s hs n hn
  obtain ⟨hl,he⟩ := ha s hs n ((le_max_left _ _).trans hn)
  obtain ⟨hu,hf⟩ := hb s hs n ((le_max_right _ _).trans hn)
  exact ⟨hl,hu,he,hf⟩

def SourceTarget : Prop :=
  (∀ k : Nat, 0 < k → ∃ N : Nat, 1 ≤ N ∧
    ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
      count (balanced k) n ≤ count s n ∧ count s n ≤ count (caterpillar k) n ∧
      (count (balanced k) n = count s n ↔ ShapeIso s (balanced k)) ∧
      (count s n = count (caterpillar k) n ↔ ShapeIso s (caterpillar k))) ∧
  (∀ s : Species, 0 < growth s ∧
    Tendsto (fun n : Nat => (count s n : ℝ) ^ (1/(n:ℝ))) atTop (nhds (growth s)) ∧
    growth s = (rho s)⁻¹) ∧
  Tendsto (fun k : Nat => growth (caterpillar k)/(k:ℝ)) atTop atTop ∧
  (∀ k : Nat, 0 < k → 2*(k:ℝ) ≤ growth (balanced k) ∧
    growth (balanced k) ≤ 1000*(k:ℝ))

theorem source_target : SourceTarget := by
  refine ⟨fun k _ => uniform_extrema k, GrowthStage.source_growth_component.1,
    GrowthStage.caterpillar_superlinear, ?_⟩
  intro k hk
  have h := GrowthStage.source_growth_component.2.1 k hk
  exact ⟨h.2.2.1,h.2.2.2.1⟩

theorem unranked_extrema (k : Nat) : ∃ N : Nat, 1 ≤ N ∧
    ∀ q : Unranked, unrankedLeaves q = k → ∀ n : Nat, N ≤ n →
      unrankedCount (shape (balanced k)) n ≤ unrankedCount q n ∧
      unrankedCount q n ≤ unrankedCount (shape (caterpillar k)) n ∧
      (unrankedCount (shape (balanced k)) n = unrankedCount q n ↔
        q = shape (balanced k)) ∧
      (unrankedCount q n = unrankedCount (shape (caterpillar k)) n ↔
        q = shape (caterpillar k)) := by
  obtain ⟨N,hN,hh⟩ := uniform_extrema k
  refine ⟨N,hN,?_⟩
  intro q
  refine Quotient.inductionOn q ?_
  intro s hs n hn
  obtain ⟨hl,hu,he,hf⟩ := hh s hs n hn
  exact ⟨hl,hu,he.trans (shape_eq_iff s (balanced k)).symm,
    hf.trans (shape_eq_iff s (caterpillar k)).symm⟩

theorem unranked_root_limit (q : Unranked) : 0 < unrankedGrowth q ∧
    Tendsto (fun n : Nat => (unrankedCount q n : ℝ) ^ (1/(n:ℝ)))
      atTop (nhds (unrankedGrowth q)) ∧ unrankedGrowth q = (unrankedRho q)⁻¹ := by
  refine Quotient.inductionOn q ?_
  intro s
  exact GrowthStage.source_growth_component.1 s

theorem source_four_claims_expanded :
  (∀ k : Nat, 0 < k → ∃ N : Nat, 1 ≤ N ∧
    ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
      count (balanced k) n ≤ count s n ∧ count s n ≤ count (caterpillar k) n ∧
      (count (balanced k) n = count s n ↔ ShapeIso s (balanced k)) ∧
      (count s n = count (caterpillar k) n ↔ ShapeIso s (caterpillar k))) ∧
  (∀ s : Species, 0 < growth s ∧
    Tendsto (fun n : Nat => (count s n : ℝ) ^ (1/(n:ℝ))) atTop (nhds (growth s)) ∧
    growth s = (rho s)⁻¹) ∧
  Tendsto (fun k : Nat => growth (caterpillar k)/(k:ℝ)) atTop atTop ∧
  (∀ k : Nat, 0 < k → 2*(k:ℝ) ≤ growth (balanced k) ∧
    growth (balanced k) ≤ 1000*(k:ℝ))
 := source_target

theorem source_event_four_claims_expanded :
  (∀ k : Nat, 0 < k → ∃ N : Nat, 1 ≤ N ∧
    ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
      sourceCard (balanced k) n ≤ sourceCard s n ∧ sourceCard s n ≤ sourceCard (caterpillar k) n ∧
      (sourceCard (balanced k) n = sourceCard s n ↔ ShapeIso s (balanced k)) ∧
      (sourceCard s n = sourceCard (caterpillar k) n ↔ ShapeIso s (caterpillar k))) ∧
  (∀ s : Species, 0 < growth s ∧
    Tendsto (fun n : Nat => (sourceCard s n : ℝ) ^ (1/(n:ℝ))) atTop (nhds (growth s)) ∧
    growth s = (rho s)⁻¹) ∧
  Tendsto (fun k : Nat => growth (caterpillar k)/(k:ℝ)) atTop atTop ∧
  (∀ k : Nat, 0 < k → 2*(k:ℝ) ≤ growth (balanced k) ∧
    growth (balanced k) ≤ 1000*(k:ℝ))
 := by
  simpa only [sourceCard_eq] using source_four_claims_expanded

theorem balanced_family_linear (f : Nat → Species)
    (h : ∀ k, 0 < k → ShapeIso (f k) (balanced k)) :
    ∀ k, 0 < k → leaves (f k) = k ∧ 2*(k:ℝ) ≤ growth (f k) ∧
      growth (f k) ≤ 1000*(k:ℝ) := by
  intro k hk
  exact GrowthStage.balanced_shape_growth hk (h k hk)

theorem caterpillar_family_superlinear (f : Nat → Species)
    (h : ∀ k, ShapeIso (f k) (caterpillar k)) :
    Tendsto (fun k : Nat => growth (f k)/(k:ℝ)) atTop atTop :=
  GrowthStage.caterpillar_family_superlinear f h

theorem unranked_four_claims_expanded :
    (∀ k : Nat, 0 < k → ∃ N : Nat, 1 ≤ N ∧
      ∀ q : Unranked, unrankedLeaves q = k → ∀ n : Nat, N ≤ n →
        unrankedCount (shape (balanced k)) n ≤ unrankedCount q n ∧
        unrankedCount q n ≤ unrankedCount (shape (caterpillar k)) n ∧
        (unrankedCount (shape (balanced k)) n = unrankedCount q n ↔
          q = shape (balanced k)) ∧
        (unrankedCount q n = unrankedCount (shape (caterpillar k)) n ↔
          q = shape (caterpillar k))) ∧
    (∀ q : Unranked, 0 < unrankedGrowth q ∧
      Tendsto (fun n : Nat => (unrankedCount q n : ℝ) ^ (1/(n:ℝ)))
        atTop (nhds (unrankedGrowth q)) ∧ unrankedGrowth q = (unrankedRho q)⁻¹) ∧
    Tendsto (fun k : Nat => unrankedGrowth (shape (caterpillar k))/(k:ℝ))
      atTop atTop ∧
    (∀ k : Nat, 0 < k → 2*(k:ℝ) ≤ unrankedGrowth (shape (balanced k)) ∧
      unrankedGrowth (shape (balanced k)) ≤ 1000*(k:ℝ)) := by
  exact ⟨fun k _ => unranked_extrema k, unranked_root_limit,
    source_target.2.2.1, source_target.2.2.2⟩

end LiteralDL.FinalStage
