# MathDB 342705 — final eleven-module semantics and bounded prior qualification (v1)

Reviewer: Claude Opus 5.5 (claude-opus-5-5, high effort, default speed), lane `dl-history-final-11-semantics-prior-opus-r1`, 2026-11-15 UTC. Role: independent review. No children. Formal 0, science 0, no credit or ledger actions. Current administrative count: 72/80 NEW, 111 total (unchanged). This file is the controlling deliverable. `GROWTH-SEMANTICS-AND-PRIOR-v1.md` (the name used in older TASK text) is a pointer to it.

## 0. Verdict summary

| Item | Outcome |
|---|---|
| Extraction of all 63 production modules from own FINAL-PAPER-v1.md | PASS: 63/63 bytes and SHA-256 match both the in-paper SOURCE markers and PRODUCTION-GROWTH-HASHES-v1; 63 unique; import order valid |
| Exact 52-module prefix vs the prior independent review | PASS: all 52 names, bytes and SHA-256 identical to the prior report's map (report sha256 4406c847…); new set = exactly the 11 listed |
| Personal review of ALL 11 new bodies (8 GrowthFinal + FinalSourceTransport, FinalAssembly, FinalExpandedAudit) | SEMANTIC/SOURCE PASS, no load-bearing defect |
| Full four-claim expanded endpoints (canonical count, source-event cardinality, unranked quotient) | SEMANTIC/SOURCE PASS |
| Combined full-source SEMANTIC PASS (prior 52 + new 11) | GRANTED on exact hashes only. Not a compile, kernel, replay or acceptance PASS |
| Bounded current-prior qualification | No authenticated public whole-target counterpart and no complete routine specialization found within budget. Bounded SUBSTANTIAL qualification, with the unread risks stated in §5. No worldwide novelty claim |
| Process | Not clean. Deviations listed in §7, all UNWAIVED |

## 1. Target and source fidelity

- **Target.** MathDB 342705, "Caterpillar and balanced species tree growth-factor conjecture" (owned raw record and live projection dated 2026-11-15). I read the full statement.
- **Source, authenticated from owned landing metadata.** Cedric Chauve, Yann Ponty, Michael Wallner, *Counting and sampling gene family evolutionary histories in the duplication-loss and duplication-loss-transfer models*, arXiv:1905.04971v1 (2019-05-13). Published in J. Math. Biol. 80(5):1353–1388 (2020-02-15), DOI 10.1007/s00285-019-01465-x, owned copy PMC7052048. The authentication happened after some body reading; see §7.
- **Conjecture.** v1 Conjecture 4.1 (p.16) and final Conjecture 4.5 have identical wording (checked against the owned PMC text).
- **Frozen PDF skill (read-only use).** I rendered v1 pages 6, 11 and 16 with Poppler under the runner (`renders/`) and inspected them.
  - Page 6, Theorem 3.1 grammar: the DL rules are H_u = S_u ∪ D_u (internal), H_u = Z_u ∪ D_u (leaf), S_u = H_l×H_r ∪ H_l×X_r ∪ X_l×H_r, and D_u = H_u×H_u×Y_u with ordered children.
  - Page 11: definitions of CT_k and CB_h, and of balanced trees (at every node the leaf counts of the children differ by at most 1).
  - Page 16: the conjecture, plus footnote 3: "any two balanced ordered binary trees with k leaves differ only by swapping … essentially a unique balanced species tree".
- **Code correspondence.**
  - `Hist` (extant / dup / both / keepLeft / keepRight) and `Valid`/`encode` match rules (1)–(5) without (6).
  - There is no extant constructor at an internal species, and losses appear only as the absent sibling at a speciation.
  - Size n = `extantCount` = number of extant genes (Z atoms). k = `leaves`.
- **Balanced definition.** The source class is "local child-leaf difference ≤ 1 at every node". The code uses the canonical representative `balanced k` = node(balanced ⌊k/2⌋, balanced ⌈k/2⌉). Ordinary equivalence:
  - At any balanced node with k leaves, a+b = k and |a−b| ≤ 1 force {a,b} = {⌊k/2⌋, ⌈k/2⌉}.
  - Induction plus an optional swap then gives ShapeIso to `balanced k`.
  - Conversely, the canonical tree is locally balanced.
  - So there is no genuine mismatch. This confirms the prior advisory; an extra lemma is optional and is not a gate.
- **"n large enough" is necessary.** At n = 1 every k-leaf species has exactly k histories (one lineage, one keep-choice per speciation). So strict uniqueness fails for all n once k ≥ 4. The eventual (∃N_k) reading is the faithful one.
- **Reading of the growth clauses.**
  - "Superlinear" is read as growth(C_k)/k → ∞ over all k (a full filter limit).
  - "Linear" is read as Θ(k), with 2k ≤ growth(B_k) ≤ 1000k for every k ≥ 1.
  - No limiting slope, quadratic order or historical 80 is claimed. Residual interpretive risk: a reader who demands that lim growth(B_k)/k exists is not served. I consider Θ(k) the faithful reading of "grows linearly".
- **"Exponential growth factor".** The source defines it as ρ^{-1}, with ρ the dominant singularity of Theorem 3.3. The code defines growth as the actual limit of count(s,n)^{1/n} (Fekete) and proves growth = 1/ρ, where ρ is the actual summability threshold of the history sum. Both are inherited prefix facts.

## 2. New-11 coverage (all personally read)

The full declaration/hash/import map is in `SOURCE-COVERAGE-v1.json`.

| Module | Bytes | SHA-256 (prefix) | Imports | Declarations |
|---|---|---|---|---|
| GrowthFinalBounds | 1348 | 12bfccfa | BranchGlobal, SpeciesShapes | leaf_quadratic, leaf_mass, growth_lower |
| GrowthFinalCaterpillar | 1600 | ea139539 | GrowthFinalBounds | caterpillar_cubic |
| GrowthFinalScalar | 1511 | d0416897 | GrowthFinalBounds | merge_bound |
| GrowthFinalBalanced | 2577 | 3d5cf75a | GrowthFinalScalar | balanced_value_bound |
| GrowthFinalAsymptotic | 1497 | 7e9bb3c2 | GrowthFinalCaterpillar, GrowthFinalBalanced | caterpillar_square_lower, balanced_growth_upper |
| GrowthFinalLimit | 1408 | 72640daa | GrowthFinalAsymptotic | caterpillar_superlinear |
| GrowthFinalEndpoint | 2504 | bbfa7acc | GrowthFinalLimit | source_growth_component, auxiliary_conventions, growth_shapeIso, balanced_shape_growth, caterpillar_family_superlinear |
| GrowthFinalAudit | 10655 | 3286e0f2 | 53 modules (whole growth closure) | none: 226 `#print axioms` + one `#print` of source_growth_component |
| FinalSourceTransport | 1522 | f362114a | BalancedFinalExtremum, GrowthFinalEndpoint | shapeSetoid, Unranked, shape, shape_eq_iff, unrankedLeaves, unrankedCount, unrankedGrowth, unrankedRho, sourceCard, sourceCard_eq, sourceCard_shape |
| FinalAssembly | 6144 | a7cff8d9 | FinalSourceTransport | uniform_extrema, SourceTarget, source_target, unranked_extrema, unranked_root_limit, source_four_claims_expanded, source_event_four_claims_expanded, balanced_family_linear, caterpillar_family_superlinear, unranked_four_claims_expanded |
| FinalExpandedAudit | 11869 | a047ccae | FinalAssembly, BalancedFinalAudit, GrowthFinalAudit | none: 272 `#print axioms` (all 21 FinalStage declarations included) + `#eval Lean.versionString` |

That is 35 new declarations.

**Text scan of all 63 sources.** The following are absent: `sorry`, `admit`, axiom declarations, `unsafe`, `native_decide`, `ofReduceBool`, `implemented_by`/`extern`, `opaque`, `elab`/`macro`/`syntax`/`run_cmd`, `skipKernelTC`. Present but benign:
- `set_option maxHeartbeats 1000000` in 5 new modules (elaboration budget only);
- `#eval Lean.versionString` in FinalExpandedAudit (a runtime print, not used by any proof);
- `instance` in 3 prefix modules (prior-reviewed).

I ran no compile and no `#print axioms`. The author's 272-closure axiom report is author evidence, not mine.

**Interfaces read in this lane** (signatures and definitions only):
- SpeciesShapes (full), ActualRootLimit (full), ActualThreshold structure and leaf/node head;
- branchValue, catalanBranch, rho, rho_pos;
- growth_mul_rho_le/ge, growth_eq_inv_rho;
- branchValue_nonneg, branch_node_quadratic, branchValue_global_bounds, rho_node_lt_left;
- ShapeIso.leaves_eq/rho_eq;
- SourceHistory lines 1–60, SourceFiber extantCount/encode_size/sourceFiberEquiv head;
- the statements of eventual_balanced_minimum and eventual_caterpillar_maximum.

## 3. Independent ordinary reconstruction of the new growth arguments

Notation: H_s(z) = branchValue s z, which for 0 ≤ z ≤ ρ(s) equals the actual history sum (ActualThreshold.representation). The facts H_s(ρ(s)) = 1/2, growth·ρ = 1 and ρ(node a b) < ρ(a), ρ(b) are inherited prefix facts.

**Leaf mass.** For 0 ≤ z ≤ ρ(s), H_s(z) ≥ leaves(s)·z.
- Leaf: H = z + H² ≥ z.
- Node: H = H_a + H_b + H_aH_b + H² ≥ H_a + H_b, and the children are inside their domains by strict child separation.
- At z = ρ this gives leaves·ρ ≤ 1/2, so growth = 1/ρ ≥ 2·leaves. **Checked.**

**Caterpillar cubic bound.** H_{C_k}(z) ≥ ((k³−k)/3)·z².
- k = 1: H_{C_1} ≥ 0.
- Step to k = m+1: H ≥ H_{C_m} + H². Here H² ≥ (m+1)²z² by leaf mass, and the inductive bound covers H_{C_m}.
- It remains to check (m³−m)/3 + (m+1)² ≥ ((m+1)³−(m+1))/3. This is m³+3m²+5m+3 ≥ m³+3m²+2m, which holds. **Checked.**
- Global bounds (clipped) are used only for nonnegativity. All evaluated quantities lie in the actual domain.

**Caterpillar square bound and superlinearity.**
- At ρ: ((k³−k)/3)ρ² ≤ 1/2, so k³−k ≤ (3/2)·growth².
- For k ≥ 2, k³ ≥ 2k, so k³ ≤ 3·growth².
- Given M > 0, choose N > 3M²+2. If k ≥ N and growth < Mk, then k³ < 3M²k², i.e. k < 3M². Contradiction.
- This is the full `Tendsto atTop atTop` over all ℕ, not a subsequence or dyadic-only result. **Checked.**

**Merge bound** (a, b ≥ 0, (a+b)² ≤ 5ab, (a+b)z ≤ 10⁻³, x ≤ az + 20(az)², y ≤ bz + 20(bz)², 0 ≤ w ≤ 1/2, x+y+xy+w² = w). Let q = x+y+xy.
- w(1−w) = q and 1−w ≥ 1/2 give w ≤ 2q.
- x ≤ 1.02·az and y ≤ 1.02·bz, so xy ≤ 2ab·z² and q ≤ 1.1(a+b)z, hence w² ≤ 4q² ≤ 5((a+b)z)².
- Therefore w ≤ (a+b)z + [20(a²+b²) + 2ab + 5(a+b)²]z².
- The bracket is ≤ 20(a+b)² ⇔ 5(a+b)² ≤ 38ab, which follows from (a+b)² ≤ 5ab. **Checked.**

**Balanced value bound.** For kz ≤ 10⁻³, H_{B_k}(z) ≤ kz + 20(kz)². By strong induction over every k ≥ 1:
- Leaf: H ≤ 1/2 gives H ≤ 2z, so H = z + H² ≤ z + 4z².
- Split a = ⌊k/2⌋, b = ⌈k/2⌉ with 1 ≤ a ≤ b ≤ a+1, which gives a²−3ab+b² ≤ 0 (b = a: −a²; b = a+1: −a²−a+1 ≤ 0).
- This covers odd splits, and the children are in their domains. **Checked.**

**Balanced upper bound.** If growth(B_k) > 1000k then kρ < 10⁻³. The bound at ρ then gives 1/2 ≤ 10⁻³ + 2·10⁻⁵, which is impossible. So 2k ≤ growth(B_k) ≤ 1000k for every k ≥ 1, with uniform constants. **Checked.**

**Endpoint and auxiliaries.**
- `source_growth_component` collects, for every species: positivity, the actual root limit of the counts, and growth = ρ⁻¹. For every k > 0 it adds the leaf counts of C_k and B_k, the bounds 2k/1000k and the cubic certificate. It also includes the superlinear limit and an eventual ∃c,C form.
- `auxiliary_conventions` (C_0 = B_0 = leaf, count s 0 = 0, x/0 = 0) is harmless: every real claim requires k > 0 or is a filter limit.
- `growth_shapeIso` uses growth = ρ⁻¹ and ρ-invariance.

**Scope check.** No generic bound, limit or source-bridge premise is hidden. Clipped scalars never replace actual counts or thresholds.

## 4. Integration and expanded endpoints

- **`uniform_extrema k`.** N = max(A_k, B_k) with A_k from `eventual_balanced_minimum` and B_k from `eventual_caterpillar_maximum`. I verified that their statements (prefix) give exactly the four conjuncts. One shared cutoff N ≥ 1 covers EVERY s with leaves s = k and every n ≥ N. Both equality directions are iff ShapeIso. Nothing selects a family.
- **`SourceTarget` / `source_target`.** This bundles the four claims: (1) uniform extrema for all k > 0; (2) a positive actual root limit with growth = ρ⁻¹ for all s; (3) caterpillar growth/k → ∞; (4) 2k ≤ growth(B_k) ≤ 1000k. The proof term uses only proved components. `source_four_claims_expanded` is the literal expansion.
- **`sourceCard`.** Defined as Nat.card of {t : EventTree // Valid s [] t ∧ extantCount t = n}, the literal species-addressed event trees from the root address. `sourceCard_eq` follows from the proved equivalence `sourceFiberEquiv`. `source_event_four_claims_expanded` restates all four claims with this cardinality.
- **Unranked quotient.** `Unranked` is Quotient(ShapeIso), using its refl/symm/trans. leaves, count, growth and ρ descend by proved invariance, and `shape_eq_iff` (Quotient.exact/sound) holds. `unranked_four_claims_expanded` has equality iff q = shape(canonical). Its third and fourth conjuncts reduce definitionally to the canonical statements.
- **Family transports.** These assume only `ShapeIso (f k) (canonical k)`, for k > 0 in the balanced case. These are genuine assumptions.

**Endpoint verdict.** Unconditional apart from positive k and ShapeIso. No residual bridge. SEMANTIC PASS.

## 5. Bounded current-prior and contribution qualification

**Budget.** 8 GET hops; 6 search calls / 12 queries. Used: 7 GET hops (including robots, one 404 and one 429) and 5 search calls / 5 queries. Inventory in §6.

**Findings.**
1. Three targeted searches (exact authors and conjecture, extremal shape plus growth wording, follow-up years) found no later public proof, refutation or claimed resolution. They found only the source (arXiv, PMC, Springer, PubMed) and Wallner's OEIS caterpillar sequences A307696/7/700. These are snippet leads, not authentication.
2. The OpenAlex citing-works list (count 5) has no title addressing the conjecture:
   - 2019, gene conversion reconciliation;
   - 2019, SharpTNI;
   - 2021, holobionts;
   - 2021, polynomial tuner for samplers;
   - 2026, French thesis on syntenic gene histories (algebraic approach).
   This is title-level only and unread. OpenAlex coverage is incomplete. Semantic Scholar returned 429 and was not retried.
3. Wallner's arXiv author listing (34 titles, fetched 2026-11-15) has no DL-history or species-tree-shape follow-up after 1905.04971.
4. Adjacent literature is not subsuming as far as titles and snippets show:
   - The coalescent-history enumeration by Rosenberg and coauthors (caterpillar and matching families, compact coalescent histories) counts different objects, with gene-tree size tied to the species tree.
   - Hu–Kleitman–Tamaki 1979 (SIAM J. Appl. Math. 37:246–256) concerns path-length/minimax alphabetic and Huffman-type criteria. Body unread.
5. The released-111 delta (377269, directed Hamiltonian paths) is unrelated. A machine check of all 111 sanitized credited records finds no caterpillar, Huffman, species, phylogenetic, binary-tree, generating-function, growth-rate or Catalan family. I inherit the documented 110/14/373 comparison by identity and did not personally reread it.

**Strongest ROUTINE / specialization case.**
- Once the source grammar gives H_leaf = z + H² and H_node = H_a + H_b + H_aH_b + H², the problem becomes comparing the dominant singularities of a tree-indexed composition of one monotone symmetric merge F(x,y) = C(x+y+xy) with equal leaf inputs C(z).
- Optimal-tree theory for merge functions (Huffman-type optimality: Parker 1980; Golumbic-style combinatorial merging; Hu–Kleitman–Tamaki) and rotation/exchange arguments are classical.
- Growth orders follow from short inductions (leaf mass, a cubic certificate, a quadratic remainder bound).
- Large-n count comparisons follow from strict ρ comparisons via root limits.
- On this view, the contribution is a careful assembly of standard tools.

**Strongest SUBSTANTIAL case.**
- The source authors explicitly tried unique-subtree counts and height, found counterexamples to both heuristics, and left the question open.
- The objective is not a fixed-weight root value. It is the threshold at which the root value reaches 1/2, with every leaf input depending on z. So shape comparisons must hold uniformly up to a moving singularity.
- The balanced minimum is not the Huffman/smallest-first tree. For 6 equal leaves, greedy pairing yields a 4|2 split, while the source minimizer is 3|3. That blocks a direct specialization of ordinary Huffman optimality, as the supplied direct argument notes. I did not assert any unread Parker hypothesis fails.
- The prefix supplies source-specific tools: a coefficientwise Catalan associator inequality F(F(a,b),c) ≥ F(a,F(b,c)), and strict log-conjugate convexity/expansion comparisons that yield strict extremality (equality iff ShapeIso) for every k.
- The new growth arguments are elementary. Superlinearity plus Θ(k) together with strict two-sided extremality and the full uniform eventual statement goes beyond the source's caterpillar and dyadic-complete computations.

**My bounded conclusion.**
- No authenticated whole-target public counterpart and no authenticated complete earlier-method specialization was found. So this is not a STOP-0.
- The SUBSTANTIAL case is stronger than the ROUTINE case within what I inspected, because the Huffman mismatch and the authors' documented failed approaches are concrete. The ROUTINE objection remains live through unread merge-function optimality theory.
- I reached this independently. It agrees with, but does not echo, the earlier root selection.

**Explicit unread risks (not invented gates).**
1. Parker 1980, DOI 10.1137/0209035. Body CLOSED, never fetched or searched.
2. The bodies of Hu–Kleitman–Tamaki 1979 and of Golumbic's combinatorial-merging work. Not read.
3. Citing works beyond OpenAlex/Semantic Scholar coverage.
4. The 2026 French thesis (title only).
5. Snippet-level search cannot establish absence.

None of these, as far as I can tell, is indispensable. If a reader shows that a published merge-function theorem covers the threshold objective with strict uniqueness, the contribution would downgrade to ROUTINE.

## 6. Reading, source and request inventory

**Personally read.**
- Controls and instructions: full TASK (3 slices); DISPLAY-AND-AFFINITY-OVERRIDE; model-policy-current; DISPLAY-LIMIT-CLARIFICATION; three AGENTS files; bootstrap/verify_frozen/write_lane/run.py; budgets, reservation, ROOT-ROUTING-PREFLIGHT, PUBLIC-SOURCE-AUTHORIZATION.
- Supplied root records: the Parker and Gromada controls; the 342705 direct-growth root decision; the target binding; SOURCE-IDENTITY-CARD; the SOURCE-OWNERSHIP grant; the 52-pass record (summary keys); FINAL-HANDOFF (full); FINAL-PAPER lines 1–34 and 52–97.
- Target and source: raw 342705; live projection head; source v1 text lines 310–346, 686–740 and 1056–1080; PMC Conjecture 4.5 window; rendered pages 6/11/16.

**Machine-screened only.** All own JSON keys and scalars (`control-screen-v1.json`, 41 terms) and the sanitized-111 record fields. Machine screening is not personal reading.

**Not read.** The PREFIX52 report body, prefix provider bodies beyond the listed interfaces, other v1/PMC body regions, and all other lanes.

**Hashes of owned source copies.**

| File | SHA-256 |
|---|---|
| v1 PDF | 26ab46cb…f99b |
| v1 txt | 5497dcbb…953d |
| landing | 56c0de52…0987 |
| PMC html | b8b0e02e…78a0 |
| PMC txt | 85ecaaaa…227f8 |

**Network.** Generic user agent, no redirects followed, every request logged in `network-log.jsonl` and saved under `net/`.

| # | Request | Status | Bytes |
|---|---|---|---|
| 1 | api.semanticscholar.org/robots.txt | 404 | 22 |
| 2 | S2 citations API | 429 (not retried) | 174 |
| 3 | api.openalex.org/robots.txt (allow all) | 200 | 23 |
| 4 | OpenAlex work by DOI (W2944576509, cited_by 5) | 200 | 221 |
| 5 | OpenAlex `cites:` filter | 200 | 2074 |
| 6 | arxiv.org/robots.txt (crawl-delay 15 s; `Disallow: /` only for SemrushBot) | 200 | 5854 |
| 7 | arxiv.org/a/wallner_m_1.html (after a 16 s delay) | 200 | 46666 |

**Searches (WebSearch, standard mode, github.com and mathdb.com blocked; the 4th also blocked epubs.siam.org).**
1. Authors + conjecture + DL-histories proof.
2. Extremal shape + growth wording.
3. Follow-up 2021–2023 + Wallner.
4. Hu–Kleitman–Tamaki title + merge/equal weights.
5. Extremal history counts + iterated Catalan/singularity.

## 7. Hostile SELF review and process limits

**Hostile mathematical self-check.**
- I verified ordinary truth by hand. Lean elaboration of the tactic scripts (for example `induction` generalizing hk/hr, `nlinarith` certificates) is the author's claim and is unchecked by me, since formal work is 0.
- Prior-52 coverage is inherited strictly by identical hashes and attributed to its reviewer. I did not repeat that personal reading.
- The `#eval` in the audit module is not a proof component. Still, a strict replay policy may want it removed or ignored.

**Process deviations, all UNWAIVED.**
1. My first command listed the lane directory and file sizes before the prescribed override/TASK read.
2. The DISPLAY-AND-AFFINITY-OVERRIDE was read after the TASK, not first.
3. Many displays exceeded the 2000-character logical slice and 2400-character payload: TASK slices of about 3.8–3.9k, the handoff at about 4k, several source and code reads at 2.5–5k.
4. One grep on the single-line PMC text overflowed the 6000-character response limit; the harness persisted it with a 2 KB preview.
5. Source body reading (v1 txt greps and windows) happened before landing-metadata authentication and before the control screen, contrary to SOURCE-IDENTITY-CARD ordering.
6. Personal file reads used plain shell `cat`/`sed`/`grep` (affinity not pinned). Only extraction, scans, rendering, network, coverage, frozen checks and the seal ran under the capped runner on CPUs 2,3.
7. Two mistaken relative `cd` invocations failed harmlessly; nothing executed and nothing was written.
8. The first arXiv robots filter was over-conservative and skipped one fetch; this was corrected on reparse.
9. The WebSearch engine is third-party; the queries contained no personal data.
10. Historical defects remain UNWAIVED.

**Not claimed.** Kernel replay, fresh whole-closure compile, axiom audit, acceptance, credit, worldwide novelty. A future final review may reuse prior-52 plus this new-11 semantic coverage ONLY for these exact hashes. It must still freshly extract, compile and separately kernel-check all 63 final sources once.
