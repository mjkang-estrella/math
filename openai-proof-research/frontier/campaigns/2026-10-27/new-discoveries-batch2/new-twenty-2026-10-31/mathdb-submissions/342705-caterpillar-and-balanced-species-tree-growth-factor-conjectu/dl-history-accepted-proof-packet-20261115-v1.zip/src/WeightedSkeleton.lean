import DuplicationSkeleton
import Mathlib.Topology.Algebra.InfiniteSum.ENNReal
open scoped ENNReal
namespace LiteralDL

def rootEquiv (α : Type) : Skeleton α ≃ α ⊕ (Skeleton α × Skeleton α) where
  toFun t := match t with | .atom a => .inl a | .fork x y => .inr (x,y)
  invFun t := match t with | .inl a => .atom a | .inr xy => .fork xy.1 xy.2
  left_inv t := by cases t <;> rfl
  right_inv t := by rcases t with a | ⟨x,y⟩ <;> rfl

noncomputable def skWeight {α : Type} (f : α → ℝ≥0∞) : Skeleton α → ℝ≥0∞
  | .atom a => f a
  | .fork x y => skWeight f x * skWeight f y

noncomputable def total {α : Type} (f : α → ℝ≥0∞) : ℝ≥0∞ := ∑' t, skWeight f t

theorem total_quadratic {α : Type} (f : α → ℝ≥0∞) :
    total f = (∑' a, f a) + total f * total f := by
  calc
    total f = ∑' u : α ⊕ (Skeleton α × Skeleton α), skWeight f ((rootEquiv α).symm u) :=
      ((rootEquiv α).symm.tsum_eq (skWeight f)).symm
    _ = (∑' a, f a) + total f * total f := by
      rw [ENNReal.summable.tsum_sum ENNReal.summable]
      change (∑' a, f a) + (∑' xy : Skeleton α × Skeleton α,
        skWeight f xy.1 * skWeight f xy.2) = _
      congr 1
      rw [ENNReal.tsum_prod']
      simp_rw [ENNReal.tsum_mul_left]
      exact ENNReal.tsum_mul_right

noncomputable def historySum (s : Species) (z : ℝ≥0∞) : ℝ≥0∞ :=
  ∑' h : Hist s, z ^ size h

theorem skWeight_pow {s} (z : ℝ≥0∞) (t : Skeleton (Atom s)) :
    skWeight (fun a => z ^ size (atomHist a)) t = z ^ size (assemble t) := by
  induction t with
  | atom a => rfl
  | fork x y ix iy => simp [skWeight, assemble, size, pow_add, ix, iy]

theorem historySum_skeleton (s : Species) (z : ℝ≥0∞) :
    historySum s z = total (fun a : Atom s => z ^ size (atomHist a)) := by
  unfold historySum total
  rw [← (skeletonEquiv s).symm.tsum_eq (fun h : Hist s => z ^ size h)]
  exact tsum_congr (fun t => (skWeight_pow z t).symm)

#print axioms total_quadratic
#print axioms historySum_skeleton
end LiteralDL
