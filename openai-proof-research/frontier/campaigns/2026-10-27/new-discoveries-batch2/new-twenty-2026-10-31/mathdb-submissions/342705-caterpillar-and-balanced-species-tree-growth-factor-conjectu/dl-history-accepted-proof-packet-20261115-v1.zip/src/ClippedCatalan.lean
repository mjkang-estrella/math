import CatalanAssociator
namespace LiteralDL

theorem catalanBranch_global_bounds {q : ℝ} (hq : 0 ≤ q) :
    0 ≤ catalanBranch q ∧ catalanBranch q ≤ 1/2 := by
  have hs := Real.sqrt_nonneg (1-4*q)
  have ht : Real.sqrt (1-4*q) ≤ 1 := Real.sqrt_le_one.mpr (by linarith)
  constructor <;> unfold catalanBranch <;> linarith

theorem catalanBranch_saturated {q : ℝ} (hq : 1/4 ≤ q) : catalanBranch q = 1/2 := by
  have hs : Real.sqrt (1-4*q) = 0 := Real.sqrt_eq_zero_of_nonpos (by linarith)
  simp [catalanBranch, hs]

theorem catalanBranch_mono : Monotone catalanBranch := by
  intro x y h
  have hs : Real.sqrt (1-4*y) ≤ Real.sqrt (1-4*x) := Real.sqrt_le_sqrt (by linarith)
  unfold catalanBranch
  linarith

noncomputable def mergeValue (a b : ℝ) : ℝ := catalanBranch (a+b+a*b)

theorem mergeValue_nonneg {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) :
    0 ≤ mergeValue a b := (catalanBranch_global_bounds (by positivity)).1

theorem mergeValue_half {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) :
    mergeValue a b ≤ 1/2 := (catalanBranch_global_bounds (by positivity)).2

theorem mergeValue_mono {a b c d : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hac : a ≤ c) (hbd : b ≤ d) : mergeValue a b ≤ mergeValue c d := by
  apply catalanBranch_mono
  have hc := ha.trans hac
  have hm := mul_le_mul hac hbd hb hc
  linarith

theorem mergeValue_comm (a b : ℝ) : mergeValue a b = mergeValue b a := by
  unfold mergeValue
  congr 1
  ring

theorem mergeValue_ge_left {a b : ℝ} (ha : 0 ≤ a) (hh : a ≤ 1/2) (hb : 0 ≤ b) :
    a ≤ mergeValue a b := by
  by_cases hq : a+b+a*b ≤ 1/4
  · obtain ⟨hx0,hxh,hxe⟩ := catalanBranch_properties (by positivity : 0 ≤ a+b+a*b) hq
    change a ≤ catalanBranch (a+b+a*b)
    nlinarith [mul_nonneg ha hb, sq_nonneg (catalanBranch (a+b+a*b))]
  · unfold mergeValue
    rw [catalanBranch_saturated (le_of_not_ge hq)]
    exact hh

#print axioms mergeValue_ge_left
end LiteralDL
