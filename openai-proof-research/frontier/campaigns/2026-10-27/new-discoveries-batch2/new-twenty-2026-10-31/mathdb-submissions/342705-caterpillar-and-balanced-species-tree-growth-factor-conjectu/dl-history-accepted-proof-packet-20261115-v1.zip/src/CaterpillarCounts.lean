import StrictCaterpillar
import Mathlib.Order.Filter.Finite
namespace LiteralDL

theorem eventual_count_lt_of_growth_lt (s t : Species) (hg : growth s < growth t) :
    ∀ᶠ n : Nat in Filter.atTop, count s n < count t n := by
  obtain ⟨c,hsc,hct⟩ := exists_between hg
  have hs := (actual_root_limit s).eventually_lt_const hsc
  have ht := (actual_root_limit t).eventually_const_lt hct
  filter_upwards [hs,ht] with n hn hm
  by_contra hc
  have hle : (count t n : ℝ) ≤ count s n := by exact_mod_cast le_of_not_gt hc
  have hp := Real.rpow_le_rpow (Nat.cast_nonneg (count t n)) hle
    (show (0:ℝ) ≤ 1/(n:ℝ) by positivity)
  linarith

theorem eventual_count_lt_of_rho_lt (s t : Species) (hr : rho t < rho s) :
    ∀ᶠ n : Nat in Filter.atTop, count s n < count t n := by
  apply eventual_count_lt_of_growth_lt
  rw [growth_eq_inv_rho s,growth_eq_inv_rho t]
  exact (inv_lt_inv₀ (rho_pos s) (rho_pos t)).mpr hr

theorem eventual_caterpillar_maximum (k : Nat) : ∃ N : Nat, 1 ≤ N ∧
    ∀ s : Species, leaves s = k → ∀ n : Nat, N ≤ n →
      count s n ≤ count (caterpillar k) n ∧
      (count s n = count (caterpillar k) n ↔ ShapeIso s (caterpillar k)) := by
  have hall : ∀ s : {s : Species // leaves s = k}, ∀ᶠ n : Nat in Filter.atTop,
      count s.1 n ≤ count (caterpillar k) n ∧
      (count s.1 n = count (caterpillar k) n ↔ ShapeIso s.1 (caterpillar k)) := by
    intro s
    by_cases hi : ShapeIso s.1 (caterpillar k)
    · exact Filter.Eventually.of_forall (fun n => ⟨(hi.count_eq n).le,⟨fun _ => hi,fun _ => hi.count_eq n⟩⟩)
    · have hr : rho (caterpillar k) < rho s.1 := by
        have h := rho_caterpillar_strict s.1
        rw [s.2] at h
        exact h hi
      filter_upwards [eventual_count_lt_of_rho_lt s.1 (caterpillar k) hr] with n hn
      exact ⟨hn.le,⟨fun he => (ne_of_lt hn he).elim,fun hh => (hi hh).elim⟩⟩
  obtain ⟨N,hN⟩ := Filter.eventually_atTop.mp (Filter.eventually_all.mpr hall)
  refine ⟨max 1 N,le_max_left _ _,?_⟩
  intro s hs n hn
  exact hN n ((le_max_right _ _).trans hn) ⟨s,hs⟩

#print axioms eventual_caterpillar_maximum
end LiteralDL
