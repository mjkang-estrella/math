import FiniteShapes
import ThresholdUniqueness
namespace LiteralDL

theorem ShapeIso.refl (s : Species) : ShapeIso s s := by
  induction s with
  | leaf => exact .leaf
  | node a b ha hb => exact .node ha hb

theorem ShapeIso.symm {s t : Species} (h : ShapeIso s t) : ShapeIso t s := by
  induction h with
  | leaf => exact .leaf
  | node _ _ ha hb => exact .node ha hb
  | swap _ _ ha hb => exact .swap hb ha

theorem ShapeIso.trans {s t u : Species} (h : ShapeIso s t) (g : ShapeIso t u) :
    ShapeIso s u := by
  induction h generalizing u with
  | leaf => cases g; exact .leaf
  | node ha hb ia ib =>
    cases g with
    | node ga gb => exact .node (ia ga) (ib gb)
    | swap ga gb => exact .swap (ia ga) (ib gb)
  | swap ha hb ia ib =>
    cases g with
    | node ga gb => exact .swap (ia gb) (ib ga)
    | swap ga gb => exact .node (ia gb) (ib ga)

theorem count_node_congr {a b c d : Species}
    (ha : ∀ n, count a n = count c n) (hb : ∀ n, count b n = count d n) :
    ∀ n, count (.node a b) n = count (.node c d) n := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    rw [count_node_convolution, count_node_convolution]
    have hs : (∑ i : Fin (n+1), count (.node a b) i * count (.node a b) (n-i)) =
        ∑ i : Fin (n+1), count (.node c d) i * count (.node c d) (n-i) := by
      apply Finset.sum_congr rfl
      intro i _
      by_cases h0 : i.val = 0
      · simp [h0, count_zero]
      by_cases hn : i.val = n
      · simp [hn, count_zero]
      have hi : i.val < n := by have := i.isLt; omega
      have hj : n-i.val < n := by omega
      rw [ih _ hi, ih _ hj]
    rw [hs]
    simp_rw [ha, hb]

theorem ShapeIso.count_eq {s t} (h : ShapeIso s t) (n : Nat) : count s n = count t n := by
  induction h generalizing n with
  | leaf => rfl
  | node ha hb ia ib => exact count_node_congr ia ib n
  | swap ha hb ia ib =>
    exact (count_node_congr ia ib n).trans (count_swap _ _ n)

theorem ShapeIso.leaves_eq {s t} (h : ShapeIso s t) : leaves s = leaves t := by
  induction h <;> simp_all [leaves, Nat.add_comm]

theorem ShapeIso.rho_eq {s t} (h : ShapeIso s t) : rho s = rho t := by
  apply rho_eq_of_historySum_eq
  intro z
  rw [historySum_coeff, historySum_coeff]
  simp_rw [h.count_eq]

#print axioms ShapeIso.count_eq
#print axioms ShapeIso.rho_eq
end LiteralDL
