import LiteralHistory
namespace LiteralDL
inductive Event where
  | extant | loss | duplication | speciation
  deriving DecidableEq
inductive EventTree where
  | tip : List Bool → Event → EventTree
  | fork : List Bool → Event → EventTree → EventTree → EventTree
  deriving DecidableEq

/-- Species addresses record the source map at every event, including losses. -/
def encode {s} (p : List Bool) : Hist s → EventTree
  | .extant => .tip p .extant
  | .dup x y => .fork p .duplication (encode p x) (encode p y)
  | .both x y => .fork p .speciation (encode (p ++ [false]) x) (encode (p ++ [true]) y)
  | .keepLeft x => .fork p .speciation (encode (p ++ [false]) x) (.tip (p ++ [true]) .loss)
  | .keepRight y => .fork p .speciation (.tip (p ++ [false]) .loss) (encode (p ++ [true]) y)

/-- Explicit source grammar with labels, ordered children and species map. -/
inductive Valid : Species → List Bool → EventTree → Prop where
  | extant (p) : Valid .leaf p (.tip p .extant)
  | dup {s p x y} : Valid s p x → Valid s p y →
      Valid s p (.fork p .duplication x y)
  | both {a b p x y} : Valid a (p ++ [false]) x → Valid b (p ++ [true]) y →
      Valid (.node a b) p (.fork p .speciation x y)
  | keepLeft {a b p x} : Valid a (p ++ [false]) x →
      Valid (.node a b) p (.fork p .speciation x (.tip (p ++ [true]) .loss))
  | keepRight {a b p y} : Valid b (p ++ [true]) y →
      Valid (.node a b) p (.fork p .speciation (.tip (p ++ [false]) .loss) y)

theorem encode_valid {s} (h : Hist s) (p) : Valid s p (encode p h) := by
  induction h generalizing p with
  | extant => exact .extant p
  | dup x y ix iy => exact .dup (ix p) (iy p)
  | both x y ix iy => exact .both (ix _) (iy _)
  | keepLeft x ix => exact .keepLeft (ix _)
  | keepRight x ix => exact .keepRight (ix _)

theorem valid_has_history {s p t} (v : Valid s p t) : ∃ h : Hist s, encode p h = t := by
  induction v with
  | extant p => exact ⟨.extant, rfl⟩
  | dup vx vy ix iy =>
    obtain ⟨x, rfl⟩ := ix
    obtain ⟨y, rfl⟩ := iy
    exact ⟨.dup x y, rfl⟩
  | both vx vy ix iy =>
    obtain ⟨x, rfl⟩ := ix
    obtain ⟨y, rfl⟩ := iy
    exact ⟨.both x y, rfl⟩
  | keepLeft vx ix =>
    obtain ⟨x, rfl⟩ := ix
    exact ⟨.keepLeft x, rfl⟩
  | keepRight vy iy =>
    obtain ⟨y, rfl⟩ := iy
    exact ⟨.keepRight y, rfl⟩

theorem encode_ne_loss {s} (h : Hist s) (p q) : encode p h ≠ .tip q .loss := by
  cases h <;> simp [encode]

theorem encode_injective {s} (p) : Function.Injective (@encode s p) := by
  intro x
  induction x generalizing p with
  | extant => intro y h; cases y <;> simp_all [encode]
  | dup x y ix iy =>
    intro z h
    cases z <;> simp_all [encode]
    exact ⟨ix _ h.1, iy _ h.2⟩
  | both x y ix iy =>
    intro z h
    cases z <;> simp_all [encode, encode_ne_loss]
    exact ⟨ix _ h.1, iy _ h.2⟩
  | keepLeft x ix =>
    intro z h
    cases z <;> simp_all [encode, encode_ne_loss, Ne.symm (encode_ne_loss _ _ _)]
    exact ix _ h
  | keepRight y iy =>
    intro z h
    cases z <;> simp_all [encode, encode_ne_loss, Ne.symm (encode_ne_loss _ _ _)]
    exact iy _ h

noncomputable def sourceEquiv (s : Species) (p : List Bool) :
    Hist s ≃ {t : EventTree // Valid s p t} :=
  Equiv.ofBijective (fun h => ⟨encode p h, encode_valid h p⟩)
    ⟨fun _ _ h => encode_injective p (congrArg Subtype.val h),
     fun t => by obtain ⟨h, hh⟩ := valid_has_history t.2; exact ⟨h, Subtype.ext hh⟩⟩

#print axioms sourceEquiv
end LiteralDL
