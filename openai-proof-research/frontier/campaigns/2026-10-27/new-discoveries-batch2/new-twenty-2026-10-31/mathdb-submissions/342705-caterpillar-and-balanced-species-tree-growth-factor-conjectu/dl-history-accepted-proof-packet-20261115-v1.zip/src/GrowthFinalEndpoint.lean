import GrowthFinalLimit
namespace LiteralDL.GrowthStage
open LiteralDL Filter

theorem source_growth_component :
    (∀ s : Species, 0 < growth s ∧
      Tendsto (fun n : Nat => (count s n : ℝ) ^ (1/(n:ℝ))) atTop (nhds (growth s)) ∧
      growth s = (rho s)⁻¹) ∧
    (∀ k : Nat, 0 < k → leaves (caterpillar k) = k ∧ leaves (balanced k) = k ∧
      2*(k:ℝ) ≤ growth (balanced k) ∧ growth (balanced k) ≤ 1000*(k:ℝ) ∧
      (k:ℝ)^3-(k:ℝ) ≤ 3/2*growth (caterpillar k)^2) ∧
    Tendsto (fun k : Nat => growth (caterpillar k)/(k:ℝ)) atTop atTop ∧
    (∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∃ N : Nat, ∀ k : Nat, N ≤ k →
      c*(k:ℝ) ≤ growth (balanced k) ∧ growth (balanced k) ≤ C*(k:ℝ)) := by
  refine ⟨?_, ?_, caterpillar_superlinear, ?_⟩
  · intro s
    exact ⟨growth_pos s, actual_root_limit s, growth_eq_inv_rho s⟩
  · intro k hk
    refine ⟨leaves_caterpillar hk, leaves_balanced hk, ?_, balanced_growth_upper k hk,
      caterpillar_square_lower k hk⟩
    simpa only [leaves_balanced hk] using growth_lower (balanced k)
  · refine ⟨2,1000,by norm_num,by norm_num,1,?_⟩
    intro k hk
    refine ⟨?_,balanced_growth_upper k (by omega)⟩
    simpa only [leaves_balanced (by omega : 0 < k)] using growth_lower (balanced k)

theorem auxiliary_conventions : caterpillar 0 = .leaf ∧ balanced 0 = .leaf ∧
    (∀ s : Species, count s 0 = 0) ∧
    growth (caterpillar 0)/(0:ℝ) = 0 := by
  simp [caterpillar, balanced, count_zero]

theorem growth_shapeIso {s t : Species} (h : ShapeIso s t) : growth s = growth t := by
  rw [growth_eq_inv_rho, growth_eq_inv_rho, h.rho_eq]

theorem balanced_shape_growth {s : Species} {k : Nat} (hk : 0 < k)
    (h : ShapeIso s (balanced k)) :
    leaves s = k ∧ 2*(k:ℝ) ≤ growth s ∧ growth s ≤ 1000*(k:ℝ) := by
  rw [growth_shapeIso h]
  exact ⟨h.leaves_eq.trans (leaves_balanced hk),
    by simpa only [leaves_balanced hk] using growth_lower (balanced k),
    balanced_growth_upper k hk⟩

theorem caterpillar_family_superlinear (f : Nat → Species)
    (h : ∀ k, ShapeIso (f k) (caterpillar k)) :
    Tendsto (fun k : Nat => growth (f k)/(k:ℝ)) atTop atTop := by
  have he : (fun k : Nat => growth (f k)/(k:ℝ)) =
      (fun k : Nat => growth (caterpillar k)/(k:ℝ)) := by
    funext k
    rw [growth_shapeIso (h k)]
  rw [he]
  exact caterpillar_superlinear

#print axioms source_growth_component
#print axioms auxiliary_conventions
end LiteralDL.GrowthStage
