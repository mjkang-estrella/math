import ClippedCatalan
namespace LiteralDL

theorem mergeValue_associator {a b c : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hc : 0 ≤ c) (hac : c ≤ a) :
    mergeValue a (mergeValue b c) ≤ mergeValue (mergeValue a b) c := by
  rw [mergeValue_comm b c]
  by_cases hq : 1/4 ≤ a+b+a*b
  · have hx : mergeValue a b = 1/2 := catalanBranch_saturated hq
    rw [hx]
    have hs : mergeValue (1/2) c = 1/2 := by
      apply catalanBranch_saturated
      nlinarith
    rw [hs]
    exact mergeValue_half ha (mergeValue_nonneg hc hb)
  · have hqab : a+b+a*b < 1/4 := lt_of_not_ge hq
    have hqcb : c+b+c*b ≤ a+b+a*b := by
      have hm := mul_le_mul_of_nonneg_right hac hb
      linarith
    obtain ⟨hx0,hxh,hxe⟩ := catalanBranch_properties (by positivity : 0 ≤ a+b+a*b) hqab.le
    obtain ⟨hy0,hyh,hye⟩ := catalanBranch_properties (by positivity : 0 ≤ c+b+c*b) (hqcb.trans hqab.le)
    have hxlt : catalanBranch (a+b+a*b) < 1/2 := by
      have h := catalanBranch_strictMono
        (show a+b+a*b ∈ Set.Icc 0 (1/4) from ⟨by positivity,hqab.le⟩)
        (show (1/4:ℝ) ∈ Set.Icc 0 (1/4) from ⟨by norm_num,le_rfl⟩) hqab
      simpa only [catalanBranch_quarter] using h
    have hd : 0 < 1-catalanBranch (a+b+a*b)-catalanBranch (c+b+c*b) := by linarith
    have hid := catalan_associator_identity hxe hye
    have hp : 0 ≤ (a-c)*(catalanBranch (a+b+a*b)+catalanBranch (c+b+c*b)+
        catalanBranch (a+b+a*b)*catalanBranch (c+b+c*b)) := by positivity
    have hdiff := (mul_nonneg_iff_of_pos_right hd).mp (hid.symm ▸ hp)
    apply catalanBranch_mono
    change a + catalanBranch (c+b+c*b) + a*catalanBranch (c+b+c*b) ≤
      catalanBranch (a+b+a*b) + c + catalanBranch (a+b+a*b)*c
    nlinarith

#print axioms mergeValue_associator
end LiteralDL
