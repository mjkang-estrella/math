import Mathlib.Data.Fintype.Card
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.OfMap
import Mathlib.Data.Finset.Prod
import Mathlib.Tactic.Linarith

namespace LiteralDL
inductive Species where
  | leaf : Species
  | node : Species → Species → Species
  deriving DecidableEq

def weight : Species → Nat
  | .leaf => 1
  | .node a b => weight a + weight b + 1

theorem weight_pos (s : Species) : 0 < weight s := by cases s <;> simp [weight]

/-- Actual ordered event syntax: keep constructors retain a loss on the other side. -/
inductive Hist : Species → Type where
  | extant : Hist .leaf
  | dup {s} : Hist s → Hist s → Hist s
  | both {a b} : Hist a → Hist b → Hist (.node a b)
  | keepLeft {a b} : Hist a → Hist (.node a b)
  | keepRight {a b} : Hist b → Hist (.node a b)
  deriving DecidableEq

def size : {s : Species} → Hist s → Nat
  | _, .extant => 1
  | _, .dup x y => size x + size y
  | _, .both x y => size x + size y
  | _, .keepLeft x => size x
  | _, .keepRight x => size x

theorem size_pos {s} (h : Hist s) : 0 < size h := by
  induction h <;> simp_all [size]

def depth : {s : Species} → Hist s → Nat
  | _, .extant => 1
  | _, .dup x y => max (depth x) (depth y) + 1
  | _, .both x y => max (depth x) (depth y) + 1
  | _, .keepLeft x => depth x + 1
  | _, .keepRight x => depth x + 1

theorem depth_bound {s} (h : Hist s) : depth h ≤ size h * weight s := by
  induction h with
  | extant => simp [depth, size, weight]
  | @dup s x y ix iy =>
    have px := size_pos x
    have py := size_pos y
    have pw := weight_pos s
    simp only [depth, size]
    have hx : depth x + 1 ≤ (size x + size y) * weight s := by nlinarith
    have hy : depth y + 1 ≤ (size x + size y) * weight s := by nlinarith
    omega
  | @both a b x y ix iy =>
    have px := size_pos x
    have py := size_pos y
    have pa := weight_pos a
    have pb := weight_pos b
    simp only [depth, size, weight]
    have hx : depth x + 1 ≤ (size x + size y) * (weight a + weight b + 1) := by nlinarith
    have hy : depth y + 1 ≤ (size x + size y) * (weight a + weight b + 1) := by nlinarith
    omega
  | @keepLeft a b x ix =>
    have px := size_pos x
    have pb := weight_pos b
    simp only [depth, size, weight]
    nlinarith
  | @keepRight a b x ix =>
    have px := size_pos x
    have pa := weight_pos a
    simp only [depth, size, weight]
    nlinarith

def pool : Nat → (s : Species) → List (Hist s)
  | 0, _ => []
  | d+1, .leaf => .extant :: ((pool d .leaf).product (pool d .leaf)).map
      (fun xy => .dup xy.1 xy.2)
  | d+1, .node a b =>
      (((pool d (.node a b)).product (pool d (.node a b))).map
        (fun xy => .dup xy.1 xy.2)) ++
      (((pool d a).product (pool d b)).map (fun xy => .both xy.1 xy.2)) ++
      ((pool d a).map (fun x => .keepLeft x)) ++
      ((pool d b).map (fun x => .keepRight x))

theorem mem_pool {s} (h : Hist s) (d : Nat) (hd : depth h ≤ d) : h ∈ pool d s := by
  induction d generalizing s with
  | zero => cases h <;> simp_all [depth]
  | succ d ih =>
    cases h with
    | extant => simp [pool]
    | dup x y =>
      have hx := ih x (by simp only [depth] at hd; omega)
      have hy := ih y (by simp only [depth] at hd; omega)
      cases s <;> simp only [pool, List.mem_cons, List.mem_append, List.mem_map]
      all_goals aesop
    | both x y =>
      have hx := ih x (by simp only [depth] at hd; omega)
      have hy := ih y (by simp only [depth] at hd; omega)
      simp only [pool, List.mem_append, List.mem_map]
      aesop
    | keepLeft x =>
      have hx := ih x (by simp only [depth] at hd; omega)
      simp only [pool, List.mem_append, List.mem_map]
      aesop
    | keepRight x =>
      have hx := ih x (by simp only [depth] at hd; omega)
      simp only [pool, List.mem_append, List.mem_map]
      aesop

abbrev Fiber (s : Species) (n : Nat) := {h : Hist s // size h = n}

instance fiberFintype (s : Species) (n : Nat) : Fintype (Fiber s n) :=
  Fintype.ofFinset ((pool (n * weight s) s).toFinset.filter (fun h => size h = n))
    (by intro h; simp only [Finset.mem_filter, List.mem_toFinset]
        exact ⟨fun q => q.2, fun q => ⟨mem_pool h _ (q ▸ depth_bound h), q⟩⟩)

def count (s : Species) (n : Nat) : Nat := Fintype.card (Fiber s n)

def duplicate {s i j} (x : Fiber s i × Fiber s j) : Fiber s (i+j) :=
  ⟨.dup x.1.1 x.2.1, by simp [size, x.1.2, x.2.2]⟩

theorem duplicate_injective {s i j} : Function.Injective (@duplicate s i j) := by
  intro x y h
  have hh := congrArg Subtype.val h
  cases x with
  | mk x1 x2 =>
    cases y with
    | mk y1 y2 =>
      simp only [duplicate, Hist.dup.injEq] at hh
      exact Prod.ext (Subtype.ext hh.1) (Subtype.ext hh.2)

theorem supermultiplicative (s : Species) (i j : Nat) :
    count s i * count s j ≤ count s (i+j) := by
  simpa [count, Fintype.card_prod] using Fintype.card_le_of_injective
    (@duplicate s i j) duplicate_injective

theorem fiber_zero_empty (s : Species) : IsEmpty (Fiber s 0) :=
  ⟨fun h => by have hp := size_pos h.1; omega⟩

def one : (s : Species) → Fiber s 1
  | .leaf => ⟨.extant, rfl⟩
  | .node a _ => ⟨.keepLeft (one a).1, (one a).2⟩

def positiveFiber (s : Species) : (n : Nat) → Fiber s (n+1)
  | 0 => one s
  | n+1 => duplicate (positiveFiber s n, one s)

theorem count_pos (s : Species) (n : Nat) : 0 < count s (n+1) := by
  have : Nonempty (Fiber s (n+1)) := ⟨positiveFiber s n⟩
  exact Fintype.card_pos_iff.mpr this

#print axioms depth_bound
#print axioms fiberFintype
#print axioms supermultiplicative
end LiteralDL
