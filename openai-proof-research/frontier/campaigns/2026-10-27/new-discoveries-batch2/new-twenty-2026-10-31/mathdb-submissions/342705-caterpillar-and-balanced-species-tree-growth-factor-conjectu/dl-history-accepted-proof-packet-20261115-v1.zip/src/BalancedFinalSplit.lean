import BalancedFinalDiscrete
namespace LiteralDL.BalancedStage

theorem delta_lt (b : Nat → ℝ) (K : Nat)
    (hc : ∀ n, 2 ≤ n → n+1 ≤ K → 2*b n < b (n-1)+b (n+1))
    {i j : Nat} (hi : 1 ≤ i) (hij : i < j) (hj : j+1 ≤ K) :
    b (i+1)-b i < b (j+1)-b j := by
  have step : ∀ j, i+1 ≤ j → j+1 ≤ K → b (i+1)-b i < b (j+1)-b j := by
    intro j hji
    induction j, hji using Nat.le_induction with
    | base =>
      intro hk
      have h := hc (i+1) (by omega) hk
      have he : i+1-1=i := by omega
      rw [he] at h
      linarith
    | succ j hji ih =>
      intro hk
      have h := hc (j+1) (by omega) hk
      have he : j+1-1=j := by omega
      rw [he] at h
      have hh := ih (by omega)
      linarith
  exact step j (by omega) hj

theorem split_ordered (b : Nat → ℝ) (K : Nat)
    (hc : ∀ n, 2 ≤ n → n+1 ≤ K → 2*b n < b (n-1)+b (n+1)) :
    ∀ i j : Nat, 1 ≤ i → i ≤ j → i+j ≤ K →
      b ((i+j)/2)+b ((i+j+1)/2) ≤ b i+b j ∧
      (b ((i+j)/2)+b ((i+j+1)/2) = b i+b j ↔ j ≤ i+1) := by
  have main : ∀ d i j : Nat, j-i=d → 1 ≤ i → i ≤ j → i+j ≤ K →
      b ((i+j)/2)+b ((i+j+1)/2) ≤ b i+b j ∧
      (b ((i+j)/2)+b ((i+j+1)/2) = b i+b j ↔ j ≤ i+1) := by
    intro d
    induction d using Nat.strong_induction_on with
    | h d ih =>
      intro i j hd hi hij hk
      by_cases hnear : j ≤ i+1
      · have e0 : (i+j)/2=i := by omega
        have e1 : (i+j+1)/2=j := by omega
        rw [e0,e1]
        exact ⟨le_rfl,⟨fun _ => hnear,fun _ => rfl⟩⟩
      · have hdelta := delta_lt b K hc hi (show i<j-1 by omega) (by omega)
        have he : j-1+1=j := by omega
        rw [he] at hdelta
        have hs : i+1+(j-1)=i+j := by omega
        have hinner := ih ((j-1)-(i+1)) (by omega) (i+1) (j-1) rfl
          (by omega) (by omega) (by omega)
        rw [hs] at hinner
        have hh : b ((i+j)/2)+b ((i+j+1)/2) < b i+b j := by linarith [hinner.1]
        exact ⟨hh.le,⟨fun h => (ne_of_lt hh h).elim, fun h => (hnear h).elim⟩⟩
  intro i j hi hij hk
  exact main (j-i) i j rfl hi hij hk

theorem split_min (b : Nat → ℝ) (K : Nat)
    (hc : ∀ n, 2 ≤ n → n+1 ≤ K → 2*b n < b (n-1)+b (n+1))
    {i j : Nat} (hi : 1 ≤ i) (hj : 1 ≤ j) (hk : i+j ≤ K) :
      b ((i+j)/2)+b ((i+j+1)/2) ≤ b i+b j ∧
      (b ((i+j)/2)+b ((i+j+1)/2) = b i+b j ↔ i ≤ j+1 ∧ j ≤ i+1) := by
  rcases le_total i j with hij|hji
  · have h := split_ordered b K hc i j hi hij hk
    exact ⟨h.1, h.2.trans ⟨fun hh => ⟨by omega,hh⟩,fun hh => hh.2⟩⟩
  · have h := split_ordered b K hc j i hj hji (by omega)
    rw [Nat.add_comm j i, add_comm (b j) (b i)] at h
    exact ⟨h.1,h.2.trans ⟨fun hh => ⟨hh,by omega⟩,fun hh => hh.1⟩⟩

#print axioms split_min
end LiteralDL.BalancedStage
