import AtomMass
import Mathlib.Analysis.Real.Sqrt
namespace LiteralDL
noncomputable def catalanBranch (t : ℝ) : ℝ := (1 - Real.sqrt (1 - 4*t))/2

theorem catalanBranch_properties {t : ℝ} (ht : 0 ≤ t) (hq : t ≤ 1/4) :
    0 ≤ catalanBranch t ∧ catalanBranch t ≤ 1/2 ∧
      t + catalanBranch t * catalanBranch t = catalanBranch t := by
  have ha : 0 ≤ 1 - 4*t := by linarith
  have hb := Real.sqrt_nonneg (1 - 4*t)
  have hc : Real.sqrt (1 - 4*t) ≤ 1 := Real.sqrt_le_one.mpr (by linarith)
  have hd := Real.sq_sqrt ha
  unfold catalanBranch
  constructor
  · linarith
  constructor
  · linarith
  · nlinarith

#print axioms catalanBranch_properties
end LiteralDL
