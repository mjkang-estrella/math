import GrowthFinalBounds
set_option maxHeartbeats 1000000
namespace LiteralDL.GrowthStage

theorem merge_bound {a b z x y w : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hz : 0 ≤ z)
    (hab : (a+b)^2 ≤ 5*a*b) (hs : (a+b)*z ≤ 1/1000)
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hw : 0 ≤ w) (hh : w ≤ 1/2)
    (hxb : x ≤ a*z+20*(a*z)^2) (hyb : y ≤ b*z+20*(b*z)^2)
    (he : x+y+x*y+w*w=w) : w ≤ (a+b)*z+20*((a+b)*z)^2 := by
  have haz : 0 ≤ a*z := mul_nonneg ha hz
  have hbz : 0 ≤ b*z := mul_nonneg hb hz
  have hau : a*z ≤ 1/1000 := by nlinarith
  have hbu : b*z ≤ 1/1000 := by nlinarith
  have hxx : x ≤ 51/50*(a*z) := by nlinarith
  have hyy : y ≤ 51/50*(b*z) := by nlinarith
  have hp : x*y ≤ 2*(a*z)*(b*z) := by
    have h := mul_le_mul hxx hyy hy (by positivity : 0 ≤ 51/50*(a*z))
    nlinarith [mul_nonneg haz hbz]
  let q := x+y+x*y
  have hq0 : 0 ≤ q := by dsimp [q]; positivity
  have hc : (a*z)*(b*z) ≤ (a*z+b*z)/1000 := by
    have h := mul_le_mul_of_nonneg_right hau hbz
    nlinarith only [h, haz]
  have hq : q ≤ 11/10*((a+b)*z) := by
    dsimp [q]
    nlinarith only [hxx, hyy, hp, hc, haz, hbz]
  have hwq : w ≤ 2*q := by dsimp [q] at *; nlinarith only [he, hh, hw]
  have hwq2 : w*w ≤ 4*q^2 := by nlinarith only [hwq, hw, hq0]
  have hq2 : 4*q^2 ≤ 5*((a+b)*z)^2 := by nlinarith only [hq, hq0]
  have hsquare := mul_le_mul_of_nonneg_right hab (sq_nonneg z)
  dsimp [q] at hwq2 hq2
  nlinarith only [he, hp, hxb, hyb, hwq2, hq2, hsquare]
end LiteralDL.GrowthStage
