import ActualThreshold
open scoped ENNReal
namespace LiteralDL
noncomputable def rho (s : Species) : ℝ := (actualThreshold s).radius

theorem rho_pos (s : Species) : 0 < rho s := (actualThreshold s).positive

theorem historySum_at_rho (s : Species) :
    historySum s (ENNReal.ofReal (rho s)) = ENNReal.ofReal (1/2) := by
  rw [(actualThreshold s).representation (rho s) ⟨(rho_pos s).le,le_rfl⟩]
  exact congrArg ENNReal.ofReal (actualThreshold s).endpoint

theorem historySum_finite_iff (s : Species) {z : ℝ} (hz : 0 ≤ z) :
    historySum s (ENNReal.ofReal z) < ⊤ ↔ z ≤ rho s := by
  constructor
  · intro h
    by_contra hn
    rw [(actualThreshold s).infinite z (lt_of_not_ge hn)] at h
    exact (lt_irrefl _ h)
  · intro h
    rw [(actualThreshold s).representation z ⟨hz,h⟩]
    exact ENNReal.ofReal_lt_top

theorem count_exponential_bound (s : Species) (n : Nat) :
    (count s n : ℝ) * rho s ^ n ≤ 1/2 := by
  have h : (count s n : ℝ≥0∞) * (ENNReal.ofReal (rho s)) ^ n ≤ ENNReal.ofReal (1/2) := by
    calc
      _ ≤ ∑' m : Nat, (count s m : ℝ≥0∞) * (ENNReal.ofReal (rho s)) ^ m := ENNReal.le_tsum n
      _ = historySum s (ENNReal.ofReal (rho s)) := (historySum_coeff _ _).symm
      _ = _ := historySum_at_rho s
  have hr := ENNReal.toReal_mono ENNReal.ofReal_ne_top h
  simpa [ENNReal.toReal_mul, ENNReal.toReal_pow, ENNReal.toReal_ofReal (rho_pos s).le] using hr

#print axioms rho_pos
#print axioms historySum_at_rho
#print axioms historySum_finite_iff
#print axioms count_exponential_bound
end LiteralDL
