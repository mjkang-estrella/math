import CaterpillarOrder
namespace LiteralDL

theorem branch_node_gt_left (a b : Species) {z : ℝ} (hz : 0 < z)
    (hr : z ≤ rho (.node a b)) : branchValue a z < branchValue (.node a b) z := by
  have he := branch_node_quadratic a b hz.le hr
  have hb := branchValue_pos hz (hr.trans (rho_node_lt_right a b).le)
  have ha := branchValue_nonneg hz.le (hr.trans (rho_node_lt_left a b).le)
  nlinarith [mul_nonneg ha hb.le, sq_nonneg (branchValue (.node a b) z)]

theorem branch_nonleaf_gt_leaf {s : Species} (hs : s ≠ .leaf) {z : ℝ}
    (hz : 0 < z) (hr : z ≤ rho s) : branchValue .leaf z < branchValue s z := by
  cases s with
  | leaf => exact (hs rfl).elim
  | node a b => exact (branchValue_ge_leaf a hz.le).trans_lt (branch_node_gt_left a b hz hr)

theorem rho_rotation_le (a b : Species) :
    rho (.node (.node a b) .leaf) ≤ rho (.node a (.node b .leaf)) := by
  apply rho_le_of_global_branch_le
  intro z hz
  exact mergeValue_associator (branchValue_global_bounds a hz).1
    (branchValue_global_bounds b hz).1 (branchValue_global_bounds .leaf hz).1
    (branchValue_ge_leaf a hz)

theorem rho_rotation_lt (a b : Species) (ha : a ≠ .leaf) :
    rho (.node (.node a b) .leaf) < rho (.node a (.node b .leaf)) := by
  have hle := rho_rotation_le a b
  apply lt_of_le_of_ne hle
  intro heq
  let r := rho (.node a (.node b .leaf))
  have hr : 0 < r := rho_pos _
  have hrL : r = rho (.node (.node a b) .leaf) := heq.symm
  have hleft : r < rho (.node a b) := hrL ▸ rho_node_lt_left (.node a b) .leaf
  have hright : r < rho (.node b .leaf) := rho_node_lt_right a (.node b .leaf)
  have hA : r ≤ rho a := (rho_node_lt_left a (.node b .leaf)).le
  have hx := branch_node_quadratic a b hr.le hleft.le
  have hy := branch_node_quadratic b .leaf hr.le hright.le
  have hac := branch_nonleaf_gt_leaf ha hr hA
  have hx0 := branchValue_pos hr hleft.le
  have hy0 := branchValue_nonneg hr.le hright.le
  have hxh := branchValue_lt_half hr.le hleft
  have hyh := branchValue_lt_half hr.le hright
  have hys : branchValue .leaf r + branchValue b r + branchValue .leaf r * branchValue b r +
      branchValue (.node b .leaf) r * branchValue (.node b .leaf) r = branchValue (.node b .leaf) r := by
    nlinarith [hy]
  have hc := catalan_associator_strict hx hys hac hx0 hy0 (by linarith)
  have heL := branch_node_quadratic (.node a b) .leaf hr.le hrL.le
  have heR := branch_node_quadratic a (.node b .leaf) hr.le le_rfl
  have hvL : branchValue (.node (.node a b) .leaf) r = 1/2 := hrL ▸ (actualThreshold _).endpoint
  have hvR : branchValue (.node a (.node b .leaf)) r = 1/2 := (actualThreshold _).endpoint
  rw [hvL] at heL
  rw [hvR] at heR
  nlinarith

#print axioms rho_rotation_lt
end LiteralDL
