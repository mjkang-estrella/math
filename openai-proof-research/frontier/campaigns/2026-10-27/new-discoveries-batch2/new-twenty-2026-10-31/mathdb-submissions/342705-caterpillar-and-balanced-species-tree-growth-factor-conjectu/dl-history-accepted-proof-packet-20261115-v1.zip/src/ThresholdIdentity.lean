import GeometricBridge
namespace LiteralDL

theorem growth_mul_rho_le (s : Species) : growth s * rho s ≤ 1 := by
  have hp : ∀ n : Nat, Real.log (rho s) ≤ negativeLogCount s n / n := by
    intro n
    by_cases hn : n = 0
    · simp only [hn, Nat.cast_zero, div_zero]
      exact Real.log_nonpos (rho_pos s).le (by have := (actualThreshold s).quarter; change rho s ≤ 1/4 at this; linarith)
    have hc := count_cast_pos (s := s) hn
    have hr := rho_pos s
    have hb : (count s n : ℝ) * rho s ^ n ≤ 1 := le_trans (count_exponential_bound s n) (by norm_num)
    have hl := Real.log_le_log (mul_pos hc (pow_pos hr n)) hb
    rw [Real.log_mul hc.ne' (pow_pos hr n).ne', Real.log_pow, Real.log_one] at hl
    have hn0 : 0 < (n : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hn
    simp only [negativeLogCount, ite_eq_right hn]
    apply (le_div_iff₀ hn0).mpr
    nlinarith
  have hL := ge_of_tendsto' (negativeLogCount_tendsto s) hp
  have he := Real.exp_le_exp.mpr (show -(negativeLogCount_subadditive s).lim + Real.log (rho s) ≤ 0 by linarith)
  rw [Real.exp_add, Real.exp_log (rho_pos s), Real.exp_zero] at he
  exact he

theorem growth_mul_rho_ge (s : Species) : 1 ≤ growth s * rho s := by
  by_contra h
  have hlt : growth s * rho s < 1 := lt_of_not_ge h
  have hg := growth_pos s
  let z := (rho s + 1 / growth s) / 2
  have hi : growth s * (1 / growth s) = 1 := by field_simp
  have hz : rho s < z := by dsimp [z]; nlinarith
  have hz0 : 0 ≤ z := le_trans (rho_pos s).le hz.le
  have hzg : growth s * z < 1 := by dsimp [z]; nlinarith
  have hf := (historySum_finite_iff s hz0).mp (finite_below_growth s hz0 hzg)
  exact (not_le_of_gt hz) hf

theorem growth_eq_inv_rho (s : Species) : growth s = (rho s)⁻¹ := by
  have he := le_antisymm (growth_mul_rho_le s) (growth_mul_rho_ge s)
  rw [← one_div]
  apply (eq_div_iff (rho_pos s).ne').mpr
  simpa using he

#print axioms growth_eq_inv_rho
end LiteralDL
