import LeafExpansion
namespace LiteralDL

theorem balanced_node {k : Nat} (hk : 2 ≤ k) :
    balanced k = .node (balanced (k/2)) (balanced ((k+1)/2)) := by
  cases k with
  | zero => omega
  | succ k => cases k with
    | zero => omega
    | succ k => simp [balanced,Nat.add_assoc]

theorem balanced_successor_expansion {k : Nat} (hk : 0 < k) :
    LeafExpansion (balanced k) (balanced (k+1)) := by
  induction k using Nat.strong_induction_on with
  | h k ih =>
    by_cases h1 : k = 1
    · subst k
      simpa [balanced] using LeafExpansion.cherry
    have hk2 : 2 ≤ k := by omega
    rw [balanced_node hk2, balanced_node (by omega : 2 ≤ k+1)]
    by_cases he : k%2 = 0
    · have h0 : (k+1)/2 = k/2 := by omega
      have h1 : (k+1+1)/2 = k/2+1 := by omega
      rw [h0,h1]
      exact .right (ih (k/2) (by omega) (by omega))
    · have h0 : (k+1)/2 = k/2+1 := by omega
      have h1 : (k+1+1)/2 = k/2+1 := by omega
      rw [h0,h1]
      exact .left (ih (k/2) (by omega) (by omega))

theorem rho_balanced_successor_lt {k : Nat} (hk : 0 < k) :
    rho (balanced (k+1)) < rho (balanced k) := (balanced_successor_expansion hk).rho_lt

#print axioms balanced_successor_expansion
#print axioms rho_balanced_successor_lt
end LiteralDL
