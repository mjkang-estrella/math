import StrictRotation
namespace LiteralDL

theorem mergeValue_input_lt {a b : ℝ} (h : mergeValue a b < 1/2) :
    a+b+a*b < 1/4 := by
  by_contra hn
  have he := catalanBranch_saturated (le_of_not_gt hn)
  change catalanBranch (a+b+a*b) < 1/2 at h
  linarith

theorem mergeValue_strict {a b c d : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hac : a < c) (hbd : b ≤ d) (hq : c+d+c*d ≤ 1/4) :
    mergeValue a b < mergeValue c d := by
  have hc : 0 ≤ c := ha.trans hac.le
  have hd : 0 ≤ d := hb.trans hbd
  have hprod := mul_le_mul hac.le hbd hb hc
  have hinput : a+b+a*b < c+d+c*d := by linarith
  exact catalanBranch_strictMono ⟨by positivity,hinput.le.trans hq⟩
    ⟨by positivity,hq⟩ hinput

theorem mergeValue_associator_lt {a b c : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hc : 0 ≤ c) (hac : c < a)
    (hhalf : mergeValue (mergeValue a b) c < 1/2) :
    mergeValue a (mergeValue b c) < mergeValue (mergeValue a b) c := by
  have hx0 := mergeValue_nonneg ha hb
  have hy0 := mergeValue_nonneg hc hb
  have hxhalf : mergeValue a b < 1/2 :=
    (mergeValue_ge_left hx0 (mergeValue_half ha hb) hc).trans_lt hhalf
  have hyle : mergeValue c b ≤ mergeValue a b := mergeValue_mono hc hb hac.le le_rfl
  have hyhalf := hyle.trans_lt hxhalf
  have hqx := mergeValue_input_lt hxhalf
  have hqy := mergeValue_input_lt hyhalf
  have hx := (catalanBranch_properties (by positivity : 0 ≤ a+b+a*b) hqx.le).2.2
  have hy := (catalanBranch_properties (by positivity : 0 ≤ c+b+c*b) hqy.le).2.2
  have hxpos : 0 < mergeValue a b := by
    change 0 < catalanBranch (a+b+a*b)
    have hpos : 0 < a := lt_of_le_of_lt hc hac
    nlinarith [hx, sq_nonneg (catalanBranch (a+b+a*b)), mul_nonneg ha hb]
  have hd : mergeValue a b + mergeValue c b < 1 := by linarith
  have hs := catalan_associator_strict hx hy hac hxpos hy0 hd
  have hqout := mergeValue_input_lt hhalf
  have hinput : a+mergeValue c b+a*mergeValue c b <
      mergeValue a b+c+mergeValue a b*c := by
    change (1+a)*mergeValue c b+a < (1+c)*mergeValue a b+c at hs
    nlinarith
  rw [mergeValue_comm b c]
  exact catalanBranch_strictMono
    ⟨by positivity,hinput.le.trans hqout.le⟩ ⟨by positivity,hqout.le⟩ hinput

#print axioms mergeValue_associator_lt
end LiteralDL
