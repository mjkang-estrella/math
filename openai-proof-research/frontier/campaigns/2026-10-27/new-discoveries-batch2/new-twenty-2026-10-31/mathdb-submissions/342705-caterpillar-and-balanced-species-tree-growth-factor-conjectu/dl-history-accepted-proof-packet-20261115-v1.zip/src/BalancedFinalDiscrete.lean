import LogConjugateExpansive
import BalancedExpansion
namespace LiteralDL.BalancedStage
open LiteralDL

theorem strict_midpoint {x y z : ℝ}
    (hx : x ∈ Set.Icc 0 (Real.log (5/4)))
    (hy : y ∈ Set.Icc 0 (Real.log (5/4)))
    (hz : z ∈ Set.Icc 0 (Real.log (5/4)))
    (hxz : x < z) (hm : 2*y ≤ x+z) :
    2*logConjugate y < logConjugate x+logConjugate z := by
  have hmid : (x+z)/2 ∈ Set.Icc 0 (Real.log (5/4)) := ⟨by linarith [hx.1,hz.1],by linarith [hx.2,hz.2]⟩
  have hj := logConjugate_strictConvex.2 hx hz (ne_of_lt hxz)
    (show (0:ℝ)<1/2 by norm_num) (show (0:ℝ)<1/2 by norm_num)
    (show (1/2:ℝ)+1/2=1 by norm_num)
  have he : (1/2:ℝ)*x+(1/2)*z = (x+z)/2 := by ring
  simp only [smul_eq_mul] at hj
  rw [he] at hj
  have hle : logConjugate y ≤ logConjugate ((x+z)/2) := by
    rcases lt_or_eq_of_le (show y ≤ (x+z)/2 by linarith) with h|h
    · have hh := logConjugate_expansive hy hmid h
      linarith
    · rw [h]
  linarith

/-- Finite, closed-domain version; no value beyond K is used. -/
theorem discrete_convex (b : Nat → ℝ) (K : Nat)
    (hpos : 0 < b 1)
    (hinc : ∀ i, 1 ≤ i → i+1 ≤ K → b i < b (i+1))
    (hdom : ∀ i, 2 ≤ i → i ≤ K →
      b (i/2)+b ((i+1)/2) ∈ Set.Icc 0 (Real.log (5/4)))
    (hrec : ∀ i, 2 ≤ i → i ≤ K →
      b i = logConjugate (b (i/2)+b ((i+1)/2))) :
    ∀ n, 2 ≤ n → n+1 ≤ K → 2*b n < b (n-1)+b (n+1) := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    intro hn hnK
    by_cases htwo : n=2
    · subst n
      have h2 := hrec 2 (by omega) (by omega)
      have h3 := hrec 3 (by omega) hnK
      norm_num at h2 h3
      have hd2 := hdom 2 (by omega) (by omega)
      have hd3 := hdom 3 (by omega) hnK
      norm_num only [Nat.reduceDiv, Nat.reduceAdd] at hd2 hd3
      have hzero : (0:ℝ) ∈ Set.Icc 0 (Real.log (5/4)) :=
        ⟨le_rfl, Real.log_nonneg (by norm_num)⟩
      have he := logConjugate_expansive hzero hd2 (by linarith : 0 < b 1+b 1)
      rw [logConjugate_zero, ← h2] at he
      have he2 := logConjugate_expansive hd2 hd3 (by linarith : b 1+b 1 < b 1+b 2)
      rw [← h2, ← h3] at he2
      norm_num
      linarith
    · let m := n/2
      have hm : 1 ≤ m := by dsimp [m]; omega
      have hmi : m+1 ≤ K := by dsimp [m]; omega
      have hm_lt : b m < b (m+1) := hinc m hm hmi
      have h0 := hdom (n-1) (by omega) (by omega)
      have h1 := hdom n hn (by omega)
      have h2 := hdom (n+1) (by omega) hnK
      rw [hrec n hn (by omega), hrec (n-1) (by omega) (by omega),
        hrec (n+1) (by omega) hnK]
      apply strict_midpoint h0 h1 h2
      · by_cases hp : n%2=0
        · have hh : 2 ≤ m := by dsimp [m]; omega
          have he := hinc (m-1) (by omega) (by omega)
          have e0 : (n-1)/2=m-1 := by dsimp [m]; omega
          have e1 : (n-1+1)/2=m := by dsimp [m]; omega
          have e2 : (n+1)/2=m := by dsimp [m]; omega
          have e3 : (n+1+1)/2=m+1 := by dsimp [m]; omega
          rw [e0,e1,e2,e3]
          have em : m-1+1=m := by omega
          rw [em] at he
          linarith
        · have e0 : (n-1)/2=m := by dsimp [m]; omega
          have e1 : (n-1+1)/2=m := by dsimp [m]; omega
          have e2 : (n+1)/2=m+1 := by dsimp [m]; omega
          have e3 : (n+1+1)/2=m+1 := by dsimp [m]; omega
          rw [e0,e1,e2,e3]
          linarith
      · by_cases hp : n%2=0
        · have hh : 2 ≤ m := by dsimp [m]; omega
          have hc := ih m (by dsimp [m]; omega) hh hmi
          have e0 : (n-1)/2=m-1 := by dsimp [m]; omega
          have e1 : (n-1+1)/2=m := by dsimp [m]; omega
          have e2 : (n+1)/2=m := by dsimp [m]; omega
          have e3 : (n+1+1)/2=m+1 := by dsimp [m]; omega
          change 2*(b m+b ((n+1)/2)) ≤ _
          rw [e0,e1,e2,e3]
          linarith
        · have e0 : (n-1)/2=m := by dsimp [m]; omega
          have e1 : (n-1+1)/2=m := by dsimp [m]; omega
          have e2 : (n+1)/2=m+1 := by dsimp [m]; omega
          have e3 : (n+1+1)/2=m+1 := by dsimp [m]; omega
          change 2*(b m+b ((n+1)/2)) ≤ _
          rw [e0,e1,e2,e3]
          linarith

#print axioms discrete_convex
end LiteralDL.BalancedStage
