import ShapeTransport
namespace LiteralDL
open scoped ENNReal

theorem branchValue_nonneg {s z} (hz : 0 ≤ z) (hr : z ≤ rho s) :
    0 ≤ branchValue s z := ((actualThreshold s).bounds z ⟨hz,hr⟩).1

theorem branchValue_pos {s z} (hz : 0 < z) (hr : z ≤ rho s) :
    0 < branchValue s z := by
  have h := (actualThreshold s).increasing
    (show 0 ∈ Set.Icc 0 (rho s) from ⟨le_rfl,(rho_pos s).le⟩) ⟨hz.le,hr⟩ hz
  simpa only [branchValue_zero] using h

theorem branchValue_lt_half {s z} (hz : 0 ≤ z) (hr : z < rho s) :
    branchValue s z < 1/2 := by
  have h := (actualThreshold s).increasing ⟨hz,hr.le⟩
    (show rho s ∈ Set.Icc 0 (rho s) from ⟨(rho_pos s).le,le_rfl⟩) hr
  have he : branchValue s (rho s) = 1/2 := (actualThreshold s).endpoint
  exact he ▸ h

theorem branch_node_quadratic (a b : Species) {z : ℝ} (hz : 0 ≤ z)
    (hr : z ≤ rho (.node a b)) :
    branchValue a z + branchValue b z + branchValue a z * branchValue b z +
      branchValue (.node a b) z * branchValue (.node a b) z = branchValue (.node a b) z := by
  have hra := hr.trans (rho_node_lt_left a b).le
  have hrb := hr.trans (rho_node_lt_right a b).le
  have ha := branchValue_nonneg hz hra
  have hb := branchValue_nonneg hz hrb
  have hn := branchValue_nonneg hz hr
  have he := historySum_node_quadratic a b (ENNReal.ofReal z)
  rw [(actualThreshold (.node a b)).representation z ⟨hz,hr⟩,
    (actualThreshold a).representation z ⟨hz,hra⟩,
    (actualThreshold b).representation z ⟨hz,hrb⟩] at he
  rw [← ENNReal.ofReal_mul ha, ← ENNReal.ofReal_mul hn,
    ← ENNReal.ofReal_add ha hb,
    ← ENNReal.ofReal_add (add_nonneg ha hb) (mul_nonneg ha hb),
    ← ENNReal.ofReal_add (add_nonneg (add_nonneg ha hb) (mul_nonneg ha hb))
      (mul_nonneg hn hn)] at he
  have ht := congrArg ENNReal.toReal he
  simpa only [ENNReal.toReal_ofReal hn,
    ENNReal.toReal_ofReal (add_nonneg (add_nonneg (add_nonneg ha hb)
      (mul_nonneg ha hb)) (mul_nonneg hn hn))] using ht.symm

#print axioms branch_node_quadratic
end LiteralDL
