import ActualRootLimit
import Mathlib.Analysis.SpecificLimits.Basic
open scoped ENNReal
namespace LiteralDL

theorem count_le_growth_pow (s : Species) (n : Nat) :
    (count s n : ℝ) ≤ growth s ^ n := by
  by_cases hn : n = 0
  · simp [hn, count_zero]
  have hc := count_cast_pos (s := s) hn
  have hn0 : 0 < (n : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hn
  have hl := (negativeLogCount_subadditive s).lim_le_div (negativeLogCount_bddBelow s) hn
  simp only [negativeLogCount, ite_eq_right hn] at hl
  have hd := (le_div_iff₀ hn0).mp hl
  unfold growth
  rw [← Real.exp_nat_mul, ← Real.exp_log hc]
  exact Real.exp_le_exp.mpr (by nlinarith)

theorem finite_below_growth (s : Species) {z : ℝ} (hz : 0 ≤ z) (hzg : growth s * z < 1) :
    historySum s (ENNReal.ofReal z) < ⊤ := by
  have hg := growth_pos s
  have hs : Summable (fun n : Nat => (count s n : ℝ) * z^n) := by
    apply (summable_geometric_of_lt_one (mul_nonneg hg.le hz) hzg).of_nonneg_of_le
    · intro n; positivity
    · intro n
      rw [mul_pow]
      exact mul_le_mul_of_nonneg_right (count_le_growth_pow s n) (pow_nonneg hz n)
  rw [historySum_coeff]
  have he : (fun n : Nat => ENNReal.ofReal ((count s n : ℝ) * z^n)) =
      (fun n : Nat => (count s n : ℝ≥0∞) * ENNReal.ofReal z ^ n) := by
    funext n
    rw [ENNReal.ofReal_mul (Nat.cast_nonneg _), ENNReal.ofReal_pow hz]
    simp
  rw [← he]
  exact hs.tsum_ofReal_lt_top

#print axioms count_le_growth_pow
#print axioms finite_below_growth
end LiteralDL
