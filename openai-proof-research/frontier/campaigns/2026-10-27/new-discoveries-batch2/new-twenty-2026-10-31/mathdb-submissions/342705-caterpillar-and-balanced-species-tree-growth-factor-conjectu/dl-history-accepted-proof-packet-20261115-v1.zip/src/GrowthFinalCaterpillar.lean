import GrowthFinalBounds
namespace LiteralDL.GrowthStage
open LiteralDL
set_option maxHeartbeats 1000000

theorem caterpillar_cubic (k : Nat) (hk : 0 < k) {z : ℝ}
    (hz : 0 ≤ z) (hr : z ≤ rho (caterpillar k)) :
    (((k:ℝ)^3-(k:ℝ))/3)*z^2 ≤ branchValue (caterpillar k) z := by
  induction k with
  | zero => omega
  | succ k ih =>
    cases k with
    | zero =>
      norm_num [caterpillar]
      exact (branchValue_global_bounds .leaf hz).1
    | succ j =>
      have hr' : z ≤ rho (caterpillar (j+1)) :=
        hr.trans (rho_node_lt_left (caterpillar (j+1)) .leaf).le
      have hi := ih (by omega) hr'
      have he := branch_node_quadratic (caterpillar (j+1)) .leaf hz hr
      have hn := (branchValue_global_bounds .leaf hz).1
      have hn' := (branchValue_global_bounds (caterpillar (j+1)) hz).1
      have hp := mul_nonneg hn' hn
      have hm := leaf_mass (caterpillar (j+2)) hz hr
      rw [leaves_caterpillar (by omega)] at hm
      have hc : (0:ℝ) ≤ (j+2:Nat)*z := by positivity
      have hsq : ((j+2:Nat):ℝ)^2*z^2 ≤ branchValue (caterpillar (j+2)) z ^ 2 := by
        nlinarith only [hm, hc]
      change branchValue (caterpillar (j+1)) z + branchValue .leaf z +
        branchValue (caterpillar (j+1)) z * branchValue .leaf z +
        branchValue (caterpillar (j+2)) z * branchValue (caterpillar (j+2)) z = branchValue (caterpillar (j+2)) z at he
      simp only [show j+1+1=j+2 by omega] at *
      push_cast at *
      nlinarith only [hi, he, hn, hp, hsq, sq_nonneg z, mul_nonneg (Nat.cast_nonneg j : (0:ℝ) ≤ j) (sq_nonneg z)]
end LiteralDL.GrowthStage
