import StrictMerge
namespace LiteralDL

theorem caterpillar_ne_leaf {k : Nat} (hk : 2 ≤ k) : caterpillar k ≠ .leaf := by
  cases k with
  | zero => omega
  | succ k => cases k with
    | zero => omega
    | succ k => simp [caterpillar]

theorem rho_caterpillar_split_lt {a b : Nat} (ha : 2 ≤ a) (hb : 2 ≤ b) :
    rho (caterpillar (a+b)) < rho (.node (caterpillar a) (caterpillar b)) := by
  obtain ⟨j,rfl⟩ : ∃ j, b = j+2 := ⟨b-2,by omega⟩
  have hrot := rho_rotation_lt (caterpillar a) (caterpillar (j+1)) (caterpillar_ne_leaf ha)
  have hle := rho_caterpillar_le (.node (.node (caterpillar a) (caterpillar (j+1))) .leaf)
  have hsize : leaves (.node (.node (caterpillar a) (caterpillar (j+1))) .leaf) = a+(j+2) := by
    simp only [leaves, leaves_caterpillar (by omega : 0 < a),
      leaves_caterpillar (by omega : 0 < j+1)]
    omega
  rw [hsize] at hle
  exact hle.trans_lt hrot

theorem caterpillar_merge_lt {a b : Nat} (ha : 2 ≤ a) (hb : 2 ≤ b)
    {z : ℝ} (hz : 0 < z) (hr : z < rho (caterpillar (a+b))) :
    mergeValue (branchValue (caterpillar a) z) (branchValue (caterpillar b) z) <
      branchValue (caterpillar (a+b)) z := by
  obtain ⟨j,rfl⟩ : ∃ j, b = j+2 := ⟨b-2,by omega⟩
  have hle := rho_caterpillar_le (.node (caterpillar a) (caterpillar (j+2)))
  simp only [leaves, leaves_caterpillar (by omega : 0 < a),
    leaves_caterpillar (by omega : 0 < j+2)] at hle
  have hra : z ≤ rho (caterpillar a) :=
    (hr.le.trans hle).trans (rho_node_lt_left _ _).le
  have hac := branch_nonleaf_gt_leaf (caterpillar_ne_leaf ha) hz hra
  have hins := caterpillar_merge_le (by omega : 0 < a) (by omega : 0 < j+1) hz.le
  have houter := mergeValue_mono
    (mergeValue_nonneg (branchValue_global_bounds _ hz.le).1 (branchValue_global_bounds _ hz.le).1)
    (branchValue_global_bounds .leaf hz.le).1 hins le_rfl
  have hsucc : a+(j+2) = (a+(j+1))+1 := by omega
  have hout : mergeValue (mergeValue (branchValue (caterpillar a) z)
      (branchValue (caterpillar (j+1)) z)) (branchValue .leaf z) ≤
      branchValue (caterpillar (a+(j+2))) z := by
    rw [hsucc,caterpillar_succ (by omega : 0 < a+(j+1))]
    exact houter
  have hhalf := hout.trans_lt (branchValue_lt_half hz.le hr)
  have hs := mergeValue_associator_lt (branchValue_global_bounds _ hz.le).1
    (branchValue_global_bounds _ hz.le).1 (branchValue_global_bounds .leaf hz.le).1 hac hhalf
  exact hs.trans_le hout

#print axioms rho_caterpillar_split_lt
#print axioms caterpillar_merge_lt
end LiteralDL
