import HistoryOrder
open scoped ENNReal
namespace LiteralDL
/-- A property of the actual source sum, constructed below, never postulated. -/
structure ActualThreshold (s : Species) where
  radius : ℝ
  positive : 0 < radius
  quarter : radius ≤ 1/4
  representation : ∀ z ∈ Set.Icc 0 radius,
    historySum s (ENNReal.ofReal z) = ENNReal.ofReal (branchValue s z)
  bounds : ∀ z ∈ Set.Icc 0 radius, 0 ≤ branchValue s z ∧ branchValue s z ≤ 1/2
  increasing : StrictMonoOn (branchValue s) (Set.Icc 0 radius)
  endpoint : branchValue s radius = 1/2
  infinite : ∀ z, radius < z → historySum s (ENNReal.ofReal z) = ⊤

noncomputable def leafThreshold : ActualThreshold .leaf where
  radius := 1/4
  positive := by norm_num
  quarter := le_rfl
  representation := by intro z hz; exact historySum_leaf_principal hz.1 hz.2
  bounds := by
    intro z hz
    obtain ⟨h0,h1,_⟩ := catalanBranch_properties hz.1 hz.2
    exact ⟨h0,h1⟩
  increasing := catalanBranch_strictMono
  endpoint := catalanBranch_quarter
  infinite := by intro z hz; exact historySum_leaf_infinite hz

noncomputable def nodeThreshold {a b : Species}
    (A : ActualThreshold a) (B : ActualThreshold b) : ActualThreshold (.node a b) := by
  let R := min A.radius B.radius
  let q := fun z => branchValue a z + branchValue b z + branchValue a z * branchValue b z
  have hR : 0 < R := lt_min A.positive B.positive
  have hRa : R ≤ A.radius := min_le_left _ _
  have hRb : R ≤ B.radius := min_le_right _ _
  have hq0 : q 0 = 0 := by simp [q, branchValue_zero]
  have hqc : Continuous q := ((branchValue_continuous a).add (branchValue_continuous b)).add
    ((branchValue_continuous a).mul (branchValue_continuous b))
  have hqm : StrictMonoOn q (Set.Icc 0 R) := by
    intro x hx y hy hxy
    have hax := A.increasing ⟨hx.1, hx.2.trans hRa⟩ ⟨hy.1, hy.2.trans hRa⟩ hxy
    have hby := B.increasing ⟨hx.1, hx.2.trans hRb⟩ ⟨hy.1, hy.2.trans hRb⟩ hxy
    have hx0 := (B.bounds x ⟨hx.1,hx.2.trans hRb⟩).1
    have hy0 := (A.bounds y ⟨hy.1,hy.2.trans hRa⟩).1
    exact add_lt_add_of_lt_of_le (add_lt_add hax hby) (mul_le_mul hax.le hby.le hx0 hy0)
  have hqR : 1/2 ≤ q R := by
    have ha := A.bounds R ⟨hR.le,hRa⟩
    have hb := B.bounds R ⟨hR.le,hRb⟩
    have hab := mul_nonneg ha.1 hb.1
    rcases le_total A.radius B.radius with h | h
    · have he : R = A.radius := min_eq_left h
      have hv : branchValue a R = 1/2 := he ▸ A.endpoint
      dsimp [q]; linarith
    · have he : R = B.radius := min_eq_right h
      have hv : branchValue b R = 1/2 := he ▸ B.endpoint
      dsimp [q]; linarith
  have hex : ∃ r ∈ Set.Icc 0 R, q r = 1/4 := intermediate_value_Icc hR.le hqc.continuousOn
    (show (1/4 : ℝ) ∈ Set.Icc (q 0) (q R) from ⟨by rw [hq0]; norm_num, by linarith⟩)
  let r := Classical.choose hex
  have hr : r ∈ Set.Icc 0 R := (Classical.choose_spec hex).1
  have he : q r = 1/4 := (Classical.choose_spec hex).2
  have hr0 : 0 < r := by
    have : r ≠ 0 := by intro hz; rw [hz,hq0] at he; norm_num at he
    exact lt_of_le_of_ne hr.1 (Ne.symm this)
  have hrR : r < R := by
    have : r ≠ R := by intro hz; rw [hz] at he; linarith
    exact lt_of_le_of_ne hr.2 this
  have hi : ∀ z ∈ Set.Icc 0 r, 0 ≤ q z ∧ q z ≤ 1/4 := by
    intro z hz
    have ha := A.bounds z ⟨hz.1,hz.2.trans (hrR.le.trans hRa)⟩
    have hb := B.bounds z ⟨hz.1,hz.2.trans (hrR.le.trans hRb)⟩
    constructor
    · exact add_nonneg (add_nonneg ha.1 hb.1) (mul_nonneg ha.1 hb.1)
    · rw [← he]
      exact hqm.monotoneOn ⟨hz.1,hz.2.trans hrR.le⟩ hr hz.2
  have hdiv : ∀ z, r < z → z ≤ R → historySum (.node a b) (ENNReal.ofReal z) = ⊤ := by
    intro z hz hzR
    have hz0 := hr0.le.trans hz.le
    have ha := A.bounds z ⟨hz0,hzR.trans hRa⟩
    have hb := B.bounds z ⟨hz0,hzR.trans hRb⟩
    apply historySum_node_infinite a b _ ha.1 hb.1
      (A.representation z ⟨hz0,hzR.trans hRa⟩) (B.representation z ⟨hz0,hzR.trans hRb⟩)
    change 1/4 < q z
    rw [← he]
    exact hqm hr ⟨hz0,hzR⟩ hz
  refine ⟨r,hr0,hrR.le.trans (hRa.trans A.quarter),?_,?_,?_,?_,?_⟩
  · intro z hz
    exact historySum_node_principal a b _
      (A.bounds z ⟨hz.1,hz.2.trans (hrR.le.trans hRa)⟩).1
      (B.bounds z ⟨hz.1,hz.2.trans (hrR.le.trans hRb)⟩).1
      (A.representation z ⟨hz.1,hz.2.trans (hrR.le.trans hRa)⟩)
      (B.representation z ⟨hz.1,hz.2.trans (hrR.le.trans hRb)⟩) (hi z hz).2
  · intro z hz
    obtain ⟨h0,h1,_⟩ := catalanBranch_properties (hi z hz).1 (hi z hz).2
    exact ⟨h0,h1⟩
  · intro x hx y hy hxy
    exact catalanBranch_strictMono (hi x hx) (hi y hy)
      (hqm ⟨hx.1,hx.2.trans hrR.le⟩ ⟨hy.1,hy.2.trans hrR.le⟩ hxy)
  · change catalanBranch (q r) = 1/2
    rw [he, catalanBranch_quarter]
  · intro z hz
    by_cases hzR : z ≤ R
    · exact hdiv z hz hzR
    · have hw : r < (r+R)/2 := by linarith
      have hwR : (r+R)/2 ≤ R := by linarith
      have hd := hdiv ((r+R)/2) hw hwR
      apply top_unique
      rw [← hd]
      apply historySum_mono
      apply ENNReal.ofReal_le_ofReal
      linarith

noncomputable def actualThreshold : (s : Species) → ActualThreshold s
  | .leaf => leafThreshold
  | .node a b => nodeThreshold (actualThreshold a) (actualThreshold b)

#print axioms leafThreshold
#print axioms nodeThreshold
#print axioms actualThreshold
end LiteralDL
