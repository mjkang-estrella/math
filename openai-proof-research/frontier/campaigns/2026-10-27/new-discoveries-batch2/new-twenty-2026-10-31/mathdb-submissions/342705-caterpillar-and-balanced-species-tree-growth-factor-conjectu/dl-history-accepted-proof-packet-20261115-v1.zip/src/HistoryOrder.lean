import BranchRegularity
open scoped ENNReal
namespace LiteralDL

theorem mass_le_total {α : Type} (f : α → ℝ≥0∞) : (∑' a, f a) ≤ total f := by
  calc
    (∑' a, f a) ≤ (∑' a, f a) + total f * total f := le_self_add
    _ = total f := (total_quadratic f).symm

theorem historySum_node_ge_left (a b : Species) (z : ℝ≥0∞) :
    historySum a z ≤ historySum (.node a b) z := by
  rw [historySum_skeleton (.node a b)]
  have h := mass_le_total (fun q : Atom (.node a b) => z ^ size (atomHist q))
  rw [atomMass_node] at h
  exact le_trans (le_trans le_self_add le_self_add) h

theorem historySum_node_ge_right (a b : Species) (z : ℝ≥0∞) :
    historySum b z ≤ historySum (.node a b) z := by
  rw [historySum_skeleton (.node a b)]
  have h := mass_le_total (fun q : Atom (.node a b) => z ^ size (atomHist q))
  rw [atomMass_node] at h
  exact le_trans (le_trans le_add_self le_self_add) h

theorem historySum_mono (s : Species) : Monotone (historySum s) := by
  intro z w h
  exact ENNReal.tsum_le_tsum (fun _ => pow_le_pow_left' h _)

theorem historySum_node_infinite (a b : Species) (z : ℝ≥0∞) {x y : ℝ}
    (hx : 0 ≤ x) (hy : 0 ≤ y)
    (ha : historySum a z = ENNReal.ofReal x)
    (hb : historySum b z = ENNReal.ofReal y)
    (hq : 1/4 < x+y+x*y) : historySum (.node a b) z = ⊤ := by
  rw [historySum_skeleton]
  apply total_infinite_above _ hq
  rw [atomMass_node, ha, hb, ← ENNReal.ofReal_mul hx,
    ← ENNReal.ofReal_add hx hy, ← ENNReal.ofReal_add (add_nonneg hx hy) (mul_nonneg hx hy)]

#print axioms historySum_node_ge_left
#print axioms historySum_node_ge_right
#print axioms historySum_mono
#print axioms historySum_node_infinite
end LiteralDL
