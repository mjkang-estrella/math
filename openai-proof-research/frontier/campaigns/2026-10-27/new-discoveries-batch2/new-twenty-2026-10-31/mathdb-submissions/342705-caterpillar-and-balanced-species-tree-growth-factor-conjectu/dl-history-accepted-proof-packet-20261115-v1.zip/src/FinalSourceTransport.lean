import BalancedFinalExtremum
import GrowthFinalEndpoint
namespace LiteralDL.FinalStage
open LiteralDL Filter

def shapeSetoid : Setoid Species where
  r := ShapeIso
  iseqv := ⟨ShapeIso.refl, ShapeIso.symm, ShapeIso.trans⟩
abbrev Unranked := Quotient shapeSetoid
def shape (s : Species) : Unranked := Quotient.mk shapeSetoid s

theorem shape_eq_iff (s t : Species) : shape s = shape t ↔ ShapeIso s t :=
  ⟨fun h => @Quotient.exact Species shapeSetoid s t h,
   fun h => @Quotient.sound Species shapeSetoid s t h⟩

def unrankedLeaves : Unranked → Nat :=
  Quotient.lift leaves (fun _ _ (h : ShapeIso _ _) => h.leaves_eq)
def unrankedCount (q : Unranked) (n : Nat) : Nat :=
  Quotient.lift (fun s => count s n) (fun _ _ (h : ShapeIso _ _) => h.count_eq n) q
noncomputable def unrankedGrowth : Unranked → ℝ :=
  Quotient.lift growth (fun _ _ (h : ShapeIso _ _) => GrowthStage.growth_shapeIso h)
noncomputable def unrankedRho : Unranked → ℝ :=
  Quotient.lift rho (fun _ _ (h : ShapeIso _ _) => h.rho_eq)

noncomputable def sourceCard (s : Species) (n : Nat) : Nat :=
  Nat.card {t : EventTree // Valid s [] t ∧ extantCount t = n}
theorem sourceCard_eq (s : Species) (n : Nat) : sourceCard s n = count s n := by
  unfold sourceCard count
  rw [← Nat.card_congr (sourceFiberEquiv s n []), Nat.card_eq_fintype_card]

theorem sourceCard_shape {s t : Species} (h : ShapeIso s t) (n : Nat) :
    sourceCard s n = sourceCard t n := by
  rw [sourceCard_eq, sourceCard_eq, h.count_eq]
end LiteralDL.FinalStage
