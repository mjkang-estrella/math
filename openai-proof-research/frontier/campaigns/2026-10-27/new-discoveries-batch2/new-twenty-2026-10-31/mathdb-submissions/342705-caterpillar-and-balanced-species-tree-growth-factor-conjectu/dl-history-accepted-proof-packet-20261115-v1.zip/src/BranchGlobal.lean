import BranchDomain
import RealAssociator
namespace LiteralDL

theorem branchValue_global_bounds (s : Species) {z : ℝ} (hz : 0 ≤ z) :
    0 ≤ branchValue s z ∧ branchValue s z ≤ 1/2 := by
  induction s with
  | leaf => exact catalanBranch_global_bounds hz
  | node a b ia ib =>
    exact catalanBranch_global_bounds (by
      exact add_nonneg (add_nonneg ia.1 ib.1) (mul_nonneg ia.1 ib.1))

theorem branchValue_ge_leaf (s : Species) {z : ℝ} (hz : 0 ≤ z) :
    branchValue .leaf z ≤ branchValue s z := by
  induction s with
  | leaf => rfl
  | node a b ia ib =>
    exact ia.trans (mergeValue_ge_left (branchValue_global_bounds a hz).1
      (branchValue_global_bounds a hz).2 (branchValue_global_bounds b hz).1)

theorem rho_le_of_global_branch_le (s t : Species)
    (h : ∀ z : ℝ, 0 ≤ z → branchValue s z ≤ branchValue t z) : rho t ≤ rho s := by
  by_contra hn
  have hr : rho s < rho t := lt_of_not_ge hn
  have hc := branchValue_lt_half (rho_pos s).le hr
  have he : branchValue s (rho s) = 1/2 := (actualThreshold s).endpoint
  have hh := h (rho s) (rho_pos s).le
  linarith

#print axioms rho_le_of_global_branch_le
end LiteralDL
