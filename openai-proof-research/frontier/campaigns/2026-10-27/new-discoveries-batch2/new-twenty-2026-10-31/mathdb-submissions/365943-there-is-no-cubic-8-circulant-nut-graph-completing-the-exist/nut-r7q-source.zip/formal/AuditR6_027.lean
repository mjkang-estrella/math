import SignedSupport011_000
import FiniteSupport011
import SupportData012
import SignedSupport012_000
import FiniteSupport012
import SupportData013
import SignedSupport013_000
import FiniteSupport013
import SupportData014
import SignedSupport014_000
import FiniteSupport014
import SupportData015
set_option pp.all true
set_option pp.proofs true
set_option pp.universes true
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (n, ci) in env.constants.toList do
    let mod := (env.getModuleIdxFor? n).bind (env.header.moduleNames[·]?)
    if mod.any (fun m => #[`SignedSupport011_000, `FiniteSupport011, `SupportData012, `SignedSupport012_000, `FiniteSupport012, `SupportData013, `SignedSupport013_000, `FiniteSupport013, `SupportData014, `SignedSupport014_000, `FiniteSupport014, `SupportData015].contains m) then
      count := count + 1
      logInfo m!"MODULE {mod} DECL {n} TYPE {ci.type}"
      logInfo m!"BODY {n} {ci.value? (allowOpaque := true)}"
      logInfo m!"FLAGS unsafe={ci.isUnsafe} partial={ci.isPartial} axiom={ci.isAxiom}"
      if ci.isUnsafe || ci.isPartial || ci.isAxiom then throwError "forbidden declaration {n}"
      let axs ← Lean.collectAxioms n
      logInfo m!"AXIOMS {n} {axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "forbidden axiom {ax} in {n}"
      elabCommand (← `(command| #print axioms $(mkIdent n)))
  logInfo m!"LOCAL_TOTAL {count}"
