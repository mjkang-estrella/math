import NewCertificates0262
import NewCertificates0263
import NewCertificates0264
import NewCertificates0265
import NewCertificates0266
import NewCertificates0267
import NewCertificates0268
import NewCertificates0269
import NewCertificates0270
import NewCertificates0271
import NewCertificates0272
import NewCertificates0273
set_option pp.all true
set_option pp.proofs true
set_option pp.universes true
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (n, ci) in env.constants.toList do
    let mod := (env.getModuleIdxFor? n).bind (env.header.moduleNames[·]?)
    if mod.any (fun m => #[`NewCertificates0262, `NewCertificates0263, `NewCertificates0264, `NewCertificates0265, `NewCertificates0266, `NewCertificates0267, `NewCertificates0268, `NewCertificates0269, `NewCertificates0270, `NewCertificates0271, `NewCertificates0272, `NewCertificates0273].contains m) then
      count := count + 1
      logInfo m!"MODULE {mod} DECL {n} TYPE {ci.type}"
      logInfo m!"BODY {n} {ci.value? (allowOpaque := true)}"
      logInfo m!"FLAGS unsafe={ci.isUnsafe} partial={ci.isPartial} axiom={ci.isAxiom}"
      if ci.isUnsafe || ci.isPartial || ci.isAxiom then throwError "forbidden declaration {n}"
      let axs ← Lean.collectAxioms n
      logInfo m!"AXIOMS {n} {axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "forbidden axiom {ax} in {n}"
      elabCommand (← `(command| #print axioms $(mkIdent n)))
  logInfo m!"LOCAL_TOTAL {count}"
