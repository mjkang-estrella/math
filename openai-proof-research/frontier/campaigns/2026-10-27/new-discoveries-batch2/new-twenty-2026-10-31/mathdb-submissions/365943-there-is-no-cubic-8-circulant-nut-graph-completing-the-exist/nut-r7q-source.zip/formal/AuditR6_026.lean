import SignedSupport007_000
import FiniteSupport007
import SupportData008
import SignedSupport008_000
import FiniteSupport008
import SupportData009
import SignedSupport009_000
import FiniteSupport009
import SupportData010
import SignedSupport010_000
import FiniteSupport010
import SupportData011
set_option pp.all true
set_option pp.proofs true
set_option pp.universes true
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (n, ci) in env.constants.toList do
    let mod := (env.getModuleIdxFor? n).bind (env.header.moduleNames[·]?)
    if mod.any (fun m => #[`SignedSupport007_000, `FiniteSupport007, `SupportData008, `SignedSupport008_000, `FiniteSupport008, `SupportData009, `SignedSupport009_000, `FiniteSupport009, `SupportData010, `SignedSupport010_000, `FiniteSupport010, `SupportData011].contains m) then
      count := count + 1
      logInfo m!"MODULE {mod} DECL {n} TYPE {ci.type}"
      logInfo m!"BODY {n} {ci.value? (allowOpaque := true)}"
      logInfo m!"FLAGS unsafe={ci.isUnsafe} partial={ci.isPartial} axiom={ci.isAxiom}"
      if ci.isUnsafe || ci.isPartial || ci.isAxiom then throwError "forbidden declaration {n}"
      let axs ← Lean.collectAxioms n
      logInfo m!"AXIOMS {n} {axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "forbidden axiom {ax} in {n}"
      elabCommand (← `(command| #print axioms $(mkIdent n)))
  logInfo m!"LOCAL_TOTAL {count}"
