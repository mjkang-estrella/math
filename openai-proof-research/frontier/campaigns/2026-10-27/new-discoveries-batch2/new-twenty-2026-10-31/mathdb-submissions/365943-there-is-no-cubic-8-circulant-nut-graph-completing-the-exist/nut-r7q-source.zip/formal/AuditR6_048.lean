import SupportData088
import SignedSupport088_000
import FiniteSupport088
import SupportData089
import SignedSupport089_000
import FiniteSupport089
import SupportData090
import SignedSupport090_000
import FiniteSupport090
import SupportData091
import SignedSupport091_000
import FiniteSupport091
set_option pp.all true
set_option pp.proofs true
set_option pp.universes true
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (n, ci) in env.constants.toList do
    let mod := (env.getModuleIdxFor? n).bind (env.header.moduleNames[·]?)
    if mod.any (fun m => #[`SupportData088, `SignedSupport088_000, `FiniteSupport088, `SupportData089, `SignedSupport089_000, `FiniteSupport089, `SupportData090, `SignedSupport090_000, `FiniteSupport090, `SupportData091, `SignedSupport091_000, `FiniteSupport091].contains m) then
      count := count + 1
      logInfo m!"MODULE {mod} DECL {n} TYPE {ci.type}"
      logInfo m!"BODY {n} {ci.value? (allowOpaque := true)}"
      logInfo m!"FLAGS unsafe={ci.isUnsafe} partial={ci.isPartial} axiom={ci.isAxiom}"
      if ci.isUnsafe || ci.isPartial || ci.isAxiom then throwError "forbidden declaration {n}"
      let axs ← Lean.collectAxioms n
      logInfo m!"AXIOMS {n} {axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "forbidden axiom {ax} in {n}"
      elabCommand (← `(command| #print axioms $(mkIdent n)))
  logInfo m!"LOCAL_TOTAL {count}"
