import SupportData177
import SignedSupport177_000
import SignedSupport177_001
import FiniteSupport177
import SupportData178
import SignedSupport178_000
import FiniteSupport178
import SupportData179
import SignedSupport179_000
import FiniteSupport179
import SupportData180
import SignedSupport180_000
set_option pp.all true
set_option pp.proofs true
set_option pp.universes true
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (n, ci) in env.constants.toList do
    let mod := (env.getModuleIdxFor? n).bind (env.header.moduleNames[·]?)
    if mod.any (fun m => #[`SupportData177, `SignedSupport177_000, `SignedSupport177_001, `FiniteSupport177, `SupportData178, `SignedSupport178_000, `FiniteSupport178, `SupportData179, `SignedSupport179_000, `FiniteSupport179, `SupportData180, `SignedSupport180_000].contains m) then
      count := count + 1
      logInfo m!"MODULE {mod} DECL {n} TYPE {ci.type}"
      logInfo m!"BODY {n} {ci.value? (allowOpaque := true)}"
      logInfo m!"FLAGS unsafe={ci.isUnsafe} partial={ci.isPartial} axiom={ci.isAxiom}"
      if ci.isUnsafe || ci.isPartial || ci.isAxiom then throwError "forbidden declaration {n}"
      let axs ← Lean.collectAxioms n
      logInfo m!"AXIOMS {n} {axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "forbidden axiom {ax} in {n}"
      elabCommand (← `(command| #print axioms $(mkIdent n)))
  logInfo m!"LOCAL_TOTAL {count}"
