import SupportData146
import SignedSupport146_000
import FiniteSupport146
import SupportData147
import SignedSupport147_000
import SignedSupport147_001
import FiniteSupport147
import SupportData148
import SignedSupport148_000
import SignedSupport148_001
import FiniteSupport148
import SupportData149
set_option pp.all true
set_option pp.proofs true
set_option pp.universes true
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut count : Nat := 0
  for (n, ci) in env.constants.toList do
    let mod := (env.getModuleIdxFor? n).bind (env.header.moduleNames[·]?)
    if mod.any (fun m => #[`SupportData146, `SignedSupport146_000, `FiniteSupport146, `SupportData147, `SignedSupport147_000, `SignedSupport147_001, `FiniteSupport147, `SupportData148, `SignedSupport148_000, `SignedSupport148_001, `FiniteSupport148, `SupportData149].contains m) then
      count := count + 1
      logInfo m!"MODULE {mod} DECL {n} TYPE {ci.type}"
      logInfo m!"BODY {n} {ci.value? (allowOpaque := true)}"
      logInfo m!"FLAGS unsafe={ci.isUnsafe} partial={ci.isPartial} axiom={ci.isAxiom}"
      if ci.isUnsafe || ci.isPartial || ci.isAxiom then throwError "forbidden declaration {n}"
      let axs ← Lean.collectAxioms n
      logInfo m!"AXIOMS {n} {axs}"
      for ax in axs do
        unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
          throwError "forbidden axiom {ax} in {n}"
      elabCommand (← `(command| #print axioms $(mkIdent n)))
  logInfo m!"LOCAL_TOTAL {count}"
