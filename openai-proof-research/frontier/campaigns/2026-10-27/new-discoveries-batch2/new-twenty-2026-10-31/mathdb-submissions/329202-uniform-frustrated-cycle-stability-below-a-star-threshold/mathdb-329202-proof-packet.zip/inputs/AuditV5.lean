import EndpointV5
namespace Frustrated
example : Conjecture19 := conjecture19_proved
#print axioms conjecture19_proved
#print axioms full_signed_remainder_bound
#print axioms actual_expansion_uniform_remainder
#print axioms uniform_sparse_star_minimum
#print axioms sparse_strict_threshold_forces_card
#print axioms three_strict_threshold_forces_card
#print axioms canonical_star_formula
#print axioms exact_three_correction
#print axioms graphEdges_card_eq_edgeCount
end Frustrated
