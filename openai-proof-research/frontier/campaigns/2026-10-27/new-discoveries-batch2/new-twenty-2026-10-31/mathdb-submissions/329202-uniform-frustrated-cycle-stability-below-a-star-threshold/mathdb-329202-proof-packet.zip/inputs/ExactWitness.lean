import WitnessCount
import Mathlib.Data.Fintype.CardEmbedding
import Mathlib.Tactic.FinCases
namespace Frustrated

abbrev Outside {n} (q : Ambient n 4) := {v : Fin n // v ∉ Set.range q}

noncomputable def ExtensionWitness (n m) (G : Graph (Fin n)) :=
  (q : OddTuple n 4 G) × (Fin m ↪ Outside q.val)

theorem outside_card {n} (q : Ambient n 4) : Nat.card (Outside q) = n-4 := by
  classical
  let : Fintype (Outside q) := Fintype.ofFinite _
  rw [Nat.card_eq_fintype_card]
  change Fintype.card {v : Fin n // ¬ v ∈ Set.range q} = n-4
  rw [Fintype.card_subtype_compl]
  have hr : Fintype.card {v : Fin n // v ∈ Set.range q} = 4 := by
    let e : Fin 4 ≃ {v : Fin n // v ∈ Set.range q} :=
      Equiv.ofBijective (fun i => ⟨q i,⟨i,rfl⟩⟩)
        ⟨fun i j h => q.injective (congrArg Subtype.val h), by
          rintro ⟨v,⟨i,rfl⟩⟩
          exact ⟨i,rfl⟩⟩
    simpa only [Fintype.card_fin] using (Fintype.card_congr e).symm
  rw [hr]
  simp

theorem extensionWitness_card (n m) (G : Graph (Fin n)) :
    Nat.card (ExtensionWitness n m G) =
      8 * cycleCount n 4 G * (n-4).descFactorial m := by
  classical
  let : Fintype (OddTuple n 4 G) := Fintype.ofFinite _
  unfold ExtensionWitness
  rw [Nat.card_sigma]
  have he (q : OddTuple n 4 G) :
      Nat.card (Fin m ↪ Outside q.val) = (n-4).descFactorial m := by
    let : Fintype (Outside q.val) := Fintype.ofFinite _
    rw [Nat.card_eq_fintype_card, Fintype.card_embedding_eq]
    rw [← Nat.card_eq_fintype_card, outside_card]
    simp
  simp only [he, Finset.sum_const, Finset.card_univ, Nat.nsmul_eq_mul]
  have ht : Nat.card (OddTuple n 4 G) = tupleCount n 4 G := by
    simp [OddTuple, tupleOdd, tupleCount, Nat.card_eq_fintype_card, Fintype.card_subtype]
  rw [← Nat.card_eq_fintype_card, ht, tuple_cycle_scale (by decide : 3 ≤ 4)]

theorem extension_distinct {n m} (q : Ambient n 4) (e : Fin m ↪ Outside q) :
    (q 0 :: List.ofFn (fun i => (e i).val) ++ [q 2,q 1,q 3]).Nodup := by
  have hp : (List.ofFn (fun i => (e i).val)).Nodup :=
    List.nodup_ofFn_ofInjective (Subtype.val_injective.comp e.injective)
  have ho (i : Fin m) (j : Fin 4) : (e i).val ≠ q j := by
    intro h
    exact (e i).property ⟨j,h.symm⟩
  have hd := List.nodup_ofFn_ofInjective q.injective
  simp only [List.ofFn_succ, List.ofFn_zero, List.nodup_cons, List.mem_cons,
    List.not_mem_nil] at hd
  simp only [List.nodup_cons, List.nodup_append, List.mem_cons,
    List.not_mem_nil, not_false_eq_true]
  simp_all only [List.mem_ofFn]
  aesop

noncomputable def extensionToWitness {n m} (G : Graph (Fin n))
    (x : ExtensionWitness n m G) : CountWitness n (m+3) G := by
  let q := x.1.val
  let e := x.2
  let w : Witness (Fin n) :=
    { a := q 0, b := q 1, c := q 2, d := q 3
      internal := List.ofFn (fun i => (e i).val)
      distinct := extension_distinct q e }
  refine ⟨w, ?_, ?_⟩
  · simp [w]
  · have h := (tupleOdd_list G x.1.val).mp x.1.property
    simpa [tupleToList, List.ofFn_succ, List.ofFn_zero, w, q] using h

theorem extensionToWitness_injective {n m} (G : Graph (Fin n)) :
    Function.Injective (extensionToWitness (m := m) G) := by
  rintro ⟨⟨q,hq⟩,e⟩ ⟨⟨r,hr⟩,f⟩ h
  have hw := congrArg Subtype.val h
  have ha := congrArg Witness.a hw
  have hb := congrArg Witness.b hw
  have hc := congrArg Witness.c hw
  have hd := congrArg Witness.d hw
  change q 0 = r 0 at ha
  change q 1 = r 1 at hb
  change q 2 = r 2 at hc
  change q 3 = r 3 at hd
  have hqr : q = r := by
    apply Function.Embedding.ext
    intro i
    fin_cases i <;> assumption
  subst r
  have hef : e = f := by
    apply Function.Embedding.ext
    intro i
    apply Subtype.ext
    have hp := congrArg Witness.internal hw
    change List.ofFn (fun j => (e j).val) = List.ofFn (fun j => (f j).val) at hp
    exact congrFun (List.ofFn_injective hp) i
  subst f
  rfl

theorem source_witness_inequality {n k} (hk : 3 ≤ k)
    (_hn : max 4 (k+1) ≤ n) (G : Graph (Fin n)) :
    8 * cycleCount n 4 G * (n-4).descFactorial (k-3) ≤
      4*k*n*cycleCount n k G := by
  have : Finite (CountWitness n (k-3+3) G) :=
    Finite.of_injective _ (witnessEncode_injective (k := k-3+3) G)
  have h := Nat.card_le_card_of_injective _
    (extensionToWitness_injective (m := k-3) G)
  rw [extensionWitness_card] at h
  have he : k-3+3 = k := by omega
  rw [he] at h
  exact h.trans (witness_bound_cycle hk G)

#print axioms extensionWitness_card
#print axioms extensionToWitness
#print axioms source_witness_inequality
end Frustrated
