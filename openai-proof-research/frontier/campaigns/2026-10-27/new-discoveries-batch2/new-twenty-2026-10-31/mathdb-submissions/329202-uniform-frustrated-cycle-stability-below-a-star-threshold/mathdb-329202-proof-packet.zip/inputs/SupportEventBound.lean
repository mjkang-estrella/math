import TriangleExclusion
namespace Frustrated

theorem cycle_support_vertex {n k} (c : Ambient n k) (e : Sym2 (Fin n))
    (he : e ∈ cycleSupport c) (v : Fin n) (hv : v ∈ e) :
    ∃ j, c j=v := by
  classical
  obtain ⟨i,_,hi⟩ := Finset.mem_image.mp he
  rw [← hi] at hv
  change v ∈ s(c i,c (nextIndex i)) at hv
  rcases Sym2.mem_iff.mp hv with hv | hv
  · exact ⟨i,hv.symm⟩
  · exact ⟨nextIndex i,hv.symm⟩

theorem four_vertex_completion_bound {n m} (F : Finset (Sym2 (Fin n)))
    (q : Ambient n 4) (hq : ∀ i, ∃ e ∈ F, q i ∈ e) :
    Nat.card {c : Ambient n (4+m) // F ⊆ cycleSupport c} ≤
      (4+m)^4*n^m := by
  let f : {c : Ambient n (4+m) // F ⊆ cycleSupport c} →
      ContainsVertices (k:=4+m) q := fun c => ⟨c.val,by
        intro i
        obtain ⟨e,he,hv⟩ := hq i
        exact cycle_support_vertex c.val e (c.property he) (q i) hv⟩
  have hf : Function.Injective f := by
    intro c d h
    have hh : (f c).val=(f d).val := congrArg Subtype.val h
    exact Subtype.ext hh
  exact (Nat.card_le_card_of_injective f hf).trans (vertex_completion_uniform_bound q)
#print axioms four_vertex_completion_bound
end Frustrated
