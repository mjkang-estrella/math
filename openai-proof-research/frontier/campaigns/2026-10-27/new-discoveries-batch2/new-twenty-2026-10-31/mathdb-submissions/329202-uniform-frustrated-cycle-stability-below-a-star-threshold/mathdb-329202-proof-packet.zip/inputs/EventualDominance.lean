import OddExclusion
namespace Frustrated
/-- Explicit all-n domination of a lower-degree monomial by a falling factorial. -/
theorem falling_dominates_lower_power (a m C n : Nat)
    (hn : 2*(a+(m+1)) ≤ n) (hC : C*2^(m+1) < n) :
    C*n^m < (n-a).descFactorial (m+1) := by
  have hlow := falling_uniform_lower a (m+1) n hn
  have hp : 0<n^m := Nat.pow_pos (by omega)
  have hmul : 2^(m+1)*(C*n^m) < 2^(m+1)*(n-a).descFactorial (m+1) := by
    calc
      _ = (C*2^(m+1))*n^m := by ring
      _ < n*n^m := Nat.mul_lt_mul_of_pos_right hC hp
      _ = n^(m+1) := by rw [pow_succ]; ring
      _ ≤ _ := hlow
  exact Nat.lt_of_mul_lt_mul_left hmul

theorem falling_eventual_dominance (a m C : Nat) :
    ∃ N, ∀ n, N ≤ n → C*n^m < (n-a).descFactorial (m+1) := by
  refine ⟨max (2*(a+(m+1))) (C*2^(m+1)+1),?_⟩
  intro n hn
  have h₁ : 2*(a+(m+1)) ≤ n := le_trans (le_max_left _ _) hn
  have h₂ : C*2^(m+1)+1 ≤ n := le_trans (le_max_right _ _) hn
  exact falling_dominates_lower_power a m C n h₁ (by omega)
#print axioms falling_eventual_dominance
end Frustrated
