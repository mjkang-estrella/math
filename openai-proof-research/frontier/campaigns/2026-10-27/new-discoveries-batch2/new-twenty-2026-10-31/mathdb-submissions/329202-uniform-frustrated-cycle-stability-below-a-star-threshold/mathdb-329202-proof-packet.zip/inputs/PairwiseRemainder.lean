import SparseComparison
namespace Frustrated
attribute [local instance] Classical.propDecidable

theorem pairwise_adjacent_eq {n} (E : Finset (Sym2 (Fin n)))
    (hm : ∀ e ∈ E, ∀ f ∈ E, EdgeMeets e f) :
    adjacentSupports E = E.powersetCard 2 := by
  ext F
  simp only [adjacentSupports,Finset.mem_filter,Finset.mem_powerset,Finset.mem_powersetCard]
  constructor
  · rintro ⟨hs,hc,hh⟩; exact ⟨hs,hc⟩
  · rintro ⟨hs,hc⟩; exact ⟨hs,hc,fun e he f hf => hm e (hs he) f (hs hf)⟩

theorem adjacent_card_strict {n} (E : Finset (Sym2 (Fin n)))
    (hm : ¬ ∀ e ∈ E, ∀ f ∈ E, EdgeMeets e f) :
    (adjacentSupports E).card < E.card.choose 2 := by
  have hs : adjacentSupports E ⊆ E.powersetCard 2 := by
    intro F hF
    obtain ⟨hsub,hcard,hh⟩ := Finset.mem_filter.mp hF
    exact Finset.mem_powersetCard.mpr ⟨Finset.mem_powerset.mp hsub,hcard⟩
  have hne : adjacentSupports E ≠ E.powersetCard 2 := by
    intro heq
    apply hm
    intro e he f hf
    by_cases hef : e=f
    · subst f; exact edge_meets_self e
    · have hp : ({e,f} : Finset (Sym2 (Fin n))) ∈ E.powersetCard 2 := by
        apply Finset.mem_powersetCard.mpr
        exact ⟨by intro g hg; simp only [Finset.mem_insert,Finset.mem_singleton] at hg; rcases hg with rfl | rfl <;> assumption,by simp [hef]⟩
      rw [← heq] at hp
      exact (Finset.mem_filter.mp hp).2.2 e (by simp) f (by simp)
  have hh := Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨hs,hne⟩)
  simpa only [Finset.card_powersetCard] using hh

theorem pairwise_remainder_zero {n m} (G : Graph (Fin n))
    (hm : ∀ e ∈ graphEdges G, ∀ f ∈ graphEdges G, EdgeMeets e f) :
    signedRemainder (k:=4+m) (graphEdges G)=0 := by
  classical
  let E := graphEdges G
  by_cases hne : E.Nonempty
  · rcases pairwise_intersecting_classification E hne (loopless_graph_edges G) hm with hs | ht
    · obtain ⟨a,ha⟩ := hs
      exact centered_remainder_zero (by omega) E a ha
    · obtain ⟨a,b,c,hab,hac,hbc,hE⟩ := ht
      let q : Ambient n 3 := ⟨![a,b,c],by
        intro i j hij
        fin_cases i <;> fin_cases j <;> simp_all⟩
      have htri : E = {s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} := by
        change E={s(a,b),s(b,c),s(c,a)}
        rw [hE,show s(c,a)=s(a,c) from Sym2.eq_swap]
        ext e
        simp only [Finset.mem_insert,Finset.mem_singleton]
        tauto
      have hcard : E.card ≤ 3 := by
        rw [htri]
        simp only [Finset.card_insert_eq_ite,Finset.card_singleton]
        split_ifs <;> omega
      apply Finset.sum_eq_zero
      intro F hF
      obtain ⟨hsub,hbad⟩ := Finset.mem_filter.mp hF
      have hsub' := Finset.mem_powerset.mp hsub
      have hc : 3 ≤ F.card := by
        rcases hbad with h | ⟨e,he,f,hf,hd⟩
        · exact h
        · exact (hd (hm e (hsub' he) f (hsub' hf))).elim
      have hFE : F=E := Finset.eq_of_subset_of_card_le hsub' (by omega)
      have hz : tupleCompletions (k:=4+m) F=0 := by
        rw [hFE,htri]
        exact triangle_completion_zero q
      simp only [hz,Nat.cast_zero,mul_zero]
  · have he : E=∅ := Finset.not_nonempty_iff_eq_empty.mp hne
    change signedRemainder (k:=4+m) E=0
    rw [he]
    simp [signedRemainder,badSupports,Finset.sum_filter]
#print axioms adjacent_card_strict
#print axioms pairwise_remainder_zero
end Frustrated
