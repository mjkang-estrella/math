import UniformFactorials
namespace Frustrated
/-- A proper triangle cannot be an edge subset of a longer simple cycle. -/
theorem triangle_not_in_cycle {n k} [NeZero k] (hk : 4 ≤ k)
    (q : Ambient n 3) (c : Ambient n k)
    (h₀₁ : HasCyclePair c (q 0) (q 1))
    (h₁₂ : HasCyclePair c (q 1) (q 2)) :
    ¬ HasCyclePair c (q 2) (q 0) := by
  intro h₂₀
  obtain ⟨d,hd,h₀,h₁,h₂⟩ := adjacent_normalize (by omega) c q h₀₁ h₁₂
  have h := pair_step c d hd (q 2) (q 0) h₂₀
  obtain ⟨x,y,hx,hy,hxy⟩ := pair_positions d (q 2) (q 0) h
  have hx' : x=2 := d.injective (hx.trans h₂.symm)
  have hy' : y=0 := d.injective (hy.trans h₀.symm)
  rw [hx',hy'] at hxy
  rcases hxy with hxy | hxy
  · have hv := congrArg Fin.val hxy
    norm_num [Fin.val_add,Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<k),
      Nat.mod_eq_of_lt (by omega : 2<k),Nat.mod_eq_of_lt (by omega : 3<k)] at hv
  · have hv := congrArg Fin.val hxy
    norm_num [Fin.val_add,Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<k),
      Nat.mod_eq_of_lt (by omega : 2<k)] at hv

theorem triangle_completion_zero {n m} (q : Ambient n 3) :
    Nat.card {c : Ambient n (4+m) //
      ({s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} = 0 := by
  classical
  have he : IsEmpty {c : Ambient n (4+m) //
      ({s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} := by
    constructor
    rintro ⟨c,hc⟩
    have h₀₁ := hc (by simp : s(q 0,q 1) ∈ ({s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} : Finset (Sym2 (Fin n))))
    have h₁₂ := hc (by simp : s(q 1,q 2) ∈ ({s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} : Finset (Sym2 (Fin n))))
    have h₂₀ := hc (by simp : s(q 2,q 0) ∈ ({s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} : Finset (Sym2 (Fin n))))
    rw [support_definition_bridge,← pair_iff_support] at h₀₁ h₁₂ h₂₀
    exact triangle_not_in_cycle (by omega) q c h₀₁ h₁₂ h₂₀
  let := he
  exact Nat.card_of_isEmpty
#print axioms triangle_completion_zero
end Frustrated
