import HigherSupport
import Mathlib.Algebra.Order.Ring.Abs
namespace Frustrated
noncomputable def badSupports {n} (E : Finset (Sym2 (Fin n))) : Finset (Finset (Sym2 (Fin n))) := by
  classical
  exact E.powerset.filter (fun F => 3 ≤ F.card ∨ ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f)

noncomputable def signedRemainder {n k : Nat} (E : Finset (Sym2 (Fin n))) : Int :=
  ∑ F ∈ badSupports E, (-2 : Int)^(F.card-1) * (tupleCompletions (k:=k) F : Int)

theorem unsigned_remainder_bound {n m M} (E : Finset (Sym2 (Fin n))) (hM : E.card ≤ M) :
    (∑ F ∈ badSupports E, 2^(F.card-1) * tupleCompletions (k:=4+m) F) ≤
      2^(2*M)*(4+m)^4*n^m := by
  classical
  have hc : (badSupports E).card ≤ 2^M := by
    have hs : badSupports E ⊆ E.powerset := Finset.filter_subset _ _
    calc
      (badSupports E).card ≤ E.powerset.card := Finset.card_le_card hs
      _ = 2^E.card := Finset.card_powerset E
      _ ≤ 2^M := Nat.pow_le_pow_right (by decide) hM
  have ht : ∀ F ∈ badSupports E,
      2^(F.card-1)*tupleCompletions (k:=4+m) F ≤ 2^M*((4+m)^4*n^m) := by
    intro F hF
    have hf := Finset.mem_filter.mp hF
    have hsub : F ⊆ E := Finset.mem_powerset.mp hf.1
    have hcard := Finset.card_le_card hsub
    have hp : 2^(F.card-1) ≤ 2^M := Nat.pow_le_pow_right (by decide) (by omega)
    exact Nat.mul_le_mul hp (bad_support_completion_bound F hf.2)
  calc
    _ ≤ ∑ F ∈ badSupports E, 2^M*((4+m)^4*n^m) := Finset.sum_le_sum ht
    _ = (badSupports E).card * (2^M*((4+m)^4*n^m)) := by simp
    _ ≤ 2^M * (2^M*((4+m)^4*n^m)) := Nat.mul_le_mul_right _ hc
    _ = _ := by rw [two_mul,pow_add]; ring

theorem full_signed_remainder_bound {n m M} (E : Finset (Sym2 (Fin n))) (hM : E.card ≤ M) :
    |signedRemainder (k:=4+m) E| ≤ (2^(2*M)*(4+m)^4*n^m : Nat) := by
  classical
  have ha (F : Finset (Sym2 (Fin n))) :
      |(-2 : Int)^(F.card-1) * (tupleCompletions (k:=4+m) F : Int)| =
        ((2^(F.card-1) * tupleCompletions (k:=4+m) F : Nat) : Int) := by
    simp [abs_mul,abs_pow,Nat.cast_mul,Nat.cast_pow]
  calc
    |signedRemainder (k:=4+m) E| ≤
        ∑ F ∈ badSupports E, |(-2 : Int)^(F.card-1)*(tupleCompletions (k:=4+m) F : Int)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ = ((∑ F ∈ badSupports E, 2^(F.card-1)*tupleCompletions (k:=4+m) F : Nat) : Int) := by
      simp only [ha,Nat.cast_sum]
    _ ≤ _ := by exact_mod_cast unsigned_remainder_bound E hM
#print axioms unsigned_remainder_bound
#print axioms full_signed_remainder_bound
end Frustrated
