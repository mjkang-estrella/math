import StarBound
namespace Frustrated
def nextIndex {k} (i : Fin k) : Fin k :=
  ⟨(i.val+1)%k,Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩
theorem nextIndex_ne {k} (hk : 3 ≤ k) (i : Fin k) : i ≠ nextIndex i := by
  intro h
  have hv := congrArg Fin.val h
  have hi := i.isLt
  change i.val = (i.val+1)%k at hv
  by_cases hs : i.val+1 < k
  · rw [Nat.mod_eq_of_lt hs] at hv
    omega
  · have he : i.val+1=k := by omega
    rw [he,Nat.mod_self] at hv
    omega

noncomputable def starOddWitness {n k s} (c : OddTuple n k (star n s)) :
    (i : Fin k) × EdgePositionStar (n := n) s i (nextIndex i) := by
  classical
  have hp := c.property
  unfold tupleOdd at hp
  have hh : 0 < (Finset.univ.filter (fun i : Fin k =>
      (star n s).edge (c.val i) (c.val (nextIndex i)))).card := by
    change (Finset.univ.filter (fun i : Fin k =>
      (star n s).edge (c.val i) (c.val (nextIndex i)))).card % 2 = 1 at hp
    omega
  let i := Classical.choose (Finset.card_pos.mp hh)
  have hi := Classical.choose_spec (Finset.card_pos.mp hh)
  exact ⟨i,⟨c.val,(Finset.mem_filter.mp hi).2⟩⟩

theorem starOddWitness_injective {n k s} :
    Function.Injective (@starOddWitness n k s) := by
  intro c d h
  have hh := congrArg (fun p : (i : Fin k) × EdgePositionStar (n := n) s i (nextIndex i) =>
    p.2.val) h
  exact Subtype.ext hh

theorem tupleCount_card {n k} (G : Graph (Fin n)) :
    tupleCount n k G = Nat.card (OddTuple n k G) := by
  classical
  rw [Nat.card_eq_fintype_card,Fintype.card_subtype]
  unfold tupleCount
  congr 1
  apply Finset.filter_congr
  intro c _
  rfl

theorem star_cycle_upper {n k s} (hk : 3 ≤ k) :
    cycleCount n k (star n s) ≤ s*n^(k-2) := by
  classical
  have h := Nat.card_le_card_of_injective _ (@starOddWitness_injective n k s)
  rw [Nat.card_sigma] at h
  have hu : (∑ i : Fin k, Nat.card (EdgePositionStar (n := n) s i (nextIndex i))) ≤
      k*(2*s*n^(k-2)) := by
    calc
      _ ≤ ∑ _ : Fin k, 2*s*n^(k-2) :=
        Finset.sum_le_sum (fun i _ => star_position_card i (nextIndex i) (nextIndex_ne hk i))
      _ = _ := by simp [Nat.mul_comm]
  rw [← tupleCount_card,tuple_cycle_scale hk] at h
  have ht : (2*k)*cycleCount n k (star n s) ≤ (2*k)*(s*n^(k-2)) := by nlinarith
  exact Nat.le_of_mul_le_mul_left ht (by omega)

theorem threshold_f4_bound {n k s} (hk : 3 ≤ k) (hn : 2*(k+1) ≤ n)
    (G : Graph (Fin n))
    (hth : cycleCount n k G < cycleCount n k (star n s)) :
    cycleCount n 4 G ≤ (k*s*2^(k-3))*n*n := by
  have hn4 : 4 ≤ n := by omega
  have hw := source_witness_inequality hk (by omega) G
  have hu := star_cycle_upper (n := n) (s := s) hk
  have hm : k-2 = (k-3)+1 := by omega
  have hb : 0 < n-k := by omega
  have hd : (n-k)^(k-3) ≤ (n-4).descFactorial (k-3) := by
    have he : (n-4)+1-(k-3) = n-k := by omega
    simpa only [he] using Nat.pow_sub_le_descFactorial (n-4) (k-3)
  have hn2 : n ≤ 2*(n-k) := by omega
  have hp : n^(k-3) ≤ 2^(k-3)*(n-k)^(k-3) := by
    simpa only [Nat.mul_pow] using Nat.pow_le_pow_left hn2 (k-3)
  have hpos : 0 < (n-k)^(k-3) := Nat.pow_pos hb
  rw [hm,Nat.pow_succ] at hu
  have hg : cycleCount n k G ≤ s*(n^(k-3)*n) := le_trans (Nat.le_of_lt hth) hu
  have hright : 4*k*n*cycleCount n k G ≤
      (4*k*s*2^(k-3)*n*n)*(n-k)^(k-3) := by
    calc
      _ ≤ 4*k*n*(s*(n^(k-3)*n)) := Nat.mul_le_mul_left _ hg
      _ ≤ 4*k*n*(s*((2^(k-3)*(n-k)^(k-3))*n)) := by gcongr
      _ = _ := by ring
  have hleft : (8*cycleCount n 4 G)*(n-k)^(k-3) ≤
      (4*k*s*2^(k-3)*n*n)*(n-k)^(k-3) := by
    exact le_trans (Nat.mul_le_mul_left _ hd) (le_trans hw hright)
  have hc := Nat.le_of_mul_le_mul_right hleft hpos
  nlinarith
#print axioms star_cycle_upper
#print axioms threshold_f4_bound
end Frustrated
