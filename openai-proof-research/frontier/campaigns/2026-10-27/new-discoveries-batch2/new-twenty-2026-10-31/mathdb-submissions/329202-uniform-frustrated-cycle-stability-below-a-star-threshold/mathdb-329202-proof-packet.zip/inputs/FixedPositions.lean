import SingletonCount
import Mathlib.Logic.Equiv.Fintype
namespace Frustrated
abbrev FixedPositions {n r k} (a : Fin r ↪ Fin k) (q : Ambient n r) :=
  {c : Ambient n k // ∀ i, c (a i)=q i}

def reindexAmbient {n k} (σ : Equiv.Perm (Fin k)) (c : Ambient n k) : Ambient n k :=
  ⟨fun i => c (σ i),c.injective.comp σ.injective⟩

noncomputable def positionsPrefixEquiv {n r m} (a : Fin r ↪ Fin (r+m))
    (q : Ambient n r) : FixedPositions a q ≃ FixedPrefix m q := by
  have hex := Equiv.Perm.exists_extending_pair
    (Fin.castAdd m : Fin r → Fin (r+m)) a
    (Fin.castAdd_injective r m) a.injective
  let σ := Classical.choose hex
  have hσ := Classical.choose_spec hex
  exact {
    toFun := fun c => ⟨reindexAmbient σ c.val,by
      intro i
      change c.val (σ (Fin.castAdd m i))=q i
      rw [hσ]
      exact c.property i⟩
    invFun := fun c => ⟨reindexAmbient σ.symm c.val,by
      intro i
      change c.val (σ.symm (a i))=q i
      rw [← hσ,σ.symm_apply_apply]
      exact c.property i⟩
    left_inv := fun c => by
      apply Subtype.ext
      apply Function.Embedding.ext
      intro i
      change c.val (σ (σ.symm i))=c.val i
      rw [σ.apply_symm_apply]
    right_inv := fun c => by
      apply Subtype.ext
      apply Function.Embedding.ext
      intro i
      change c.val (σ.symm (σ i))=c.val i
      rw [σ.symm_apply_apply] }

theorem fixed_positions_card {n r m} (a : Fin r ↪ Fin (r+m)) (q : Ambient n r) :
    Nat.card (FixedPositions a q) = (n-r).descFactorial m := by
  rw [Nat.card_congr (positionsPrefixEquiv a q),fixed_prefix_card]
#print axioms fixed_positions_card
end Frustrated
