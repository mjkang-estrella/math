import FullRemainder
import SingletonSum
namespace Frustrated
attribute [local instance] Classical.propDecidable
noncomputable def nonemptySupports {n} (E : Finset (Sym2 (Fin n))) :=
  E.powerset.filter (fun F => F.Nonempty)
noncomputable def lowSupports {n} (E : Finset (Sym2 (Fin n))) :=
  E.powerset.filter (fun F => F.Nonempty ∧ F.card ≤ 2 ∧ ∀ e ∈ F, ∀ f ∈ F, EdgeMeets e f)
noncomputable def supportWeight {n k : Nat} (F : Finset (Sym2 (Fin n))) : Int :=
  (-2 : Int)^(F.card-1) * tupleCompletions (k:=k) F

theorem nonempty_subset_expansion {n k : Nat} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    (2*(k:Int))*cycleCount n k G =
      ∑ F ∈ nonemptySupports (graphEdges G), supportWeight (k:=k) F := by
  classical
  let E := graphEdges G
  let w := fun F : Finset (Sym2 (Fin n)) => (-2:Int)^F.card * tupleCompletions (k:=k) F
  have hp (F : Finset (Sym2 (Fin n))) (_hF : F ∈ E.powerset) :
      w F = (if F=∅ then (Nat.card (Ambient n k):Int) else 0) -
        2*(if F.Nonempty then supportWeight (k:=k) F else 0) := by
    by_cases hz : F=∅
    · subst F; simp [w,empty_tuple_completions]
    · have hne := Finset.nonempty_iff_ne_empty.mpr hz
      have hc : F.card = (F.card-1)+1 := by have := Finset.card_pos.mpr hne; omega
      simp only [hz,ite_false,hne,ite_true,zero_sub]
      dsimp [w,supportWeight]
      conv_lhs => rw [hc,pow_succ]
      ring
  have hsum : (∑ F ∈ E.powerset, w F) =
      (Nat.card (Ambient n k):Int) -
        2*(∑ F ∈ nonemptySupports E, supportWeight (k:=k) F) := by
    calc
      _ = ∑ F ∈ E.powerset, ((if F=∅ then (Nat.card (Ambient n k):Int) else 0) -
          2*(if F.Nonempty then supportWeight (k:=k) F else 0)) := Finset.sum_congr rfl hp
      _ = _ := by
        simp [Finset.sum_sub_distrib,nonemptySupports,Finset.sum_filter]
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro F hF
        split_ifs <;> simp
  have h := subset_expansion_cycle_scale hk G
  change (4*(k:Int))*cycleCount n k G = (Nat.card (Ambient n k):Int) - ∑ F ∈ E.powerset, w F at h
  rw [hsum] at h
  nlinarith

theorem exact_low_remainder_expansion {n k : Nat} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    (2*(k:Int))*cycleCount n k G =
      (∑ F ∈ lowSupports (graphEdges G), supportWeight (k:=k) F) +
        signedRemainder (k:=k) (graphEdges G) := by
  classical
  rw [nonempty_subset_expansion hk G]
  let E := graphEdges G
  have hpoint (F : Finset (Sym2 (Fin n))) (hF : F∈E.powerset) :
      (if F.Nonempty then supportWeight (k:=k) F else 0) =
        (if F.Nonempty ∧ F.card ≤ 2 ∧ ∀ e ∈ F, ∀ f ∈ F, EdgeMeets e f then supportWeight (k:=k) F else 0) +
        (if 3 ≤ F.card ∨ ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f then supportWeight (k:=k) F else 0) := by
    by_cases hz : F.Nonempty
    · by_cases hb : 3 ≤ F.card ∨ ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f
      · have hn : ¬(F.card ≤ 2 ∧ ∀ e ∈ F, ∀ f ∈ F, EdgeMeets e f) := by
          rintro ⟨hsmall,hm⟩
          rcases hb with hb | ⟨e,he,f,hf,hd⟩
          · omega
          · exact hd (hm e he f hf)
        simp [hz,hb,hn]
      · have hl : F.card ≤ 2 ∧ ∀ e ∈ F, ∀ f ∈ F, EdgeMeets e f := by
          push Not at hb
          exact ⟨by omega,hb.2⟩
        have hlow : F.Nonempty ∧ F.card ≤ 2 ∧ ∀ e ∈ F, ∀ f ∈ F, EdgeMeets e f := ⟨hz,hl⟩
        split_ifs; simp
    · have he : F=∅ := Finset.not_nonempty_iff_eq_empty.mp hz
      subst F; simp
  have hs := Finset.sum_congr rfl hpoint
  simpa [nonemptySupports,lowSupports,signedRemainder,badSupports,supportWeight,
    Finset.sum_filter,Finset.sum_add_distrib] using hs

theorem actual_expansion_uniform_remainder {n m M : Nat} (G : Graph (Fin n))
    (hM : (graphEdges G).card ≤ M) :
    |(2*((4+m):Int))*cycleCount n (4+m) G -
      ∑ F ∈ lowSupports (graphEdges G), supportWeight (k:=4+m) F| ≤
        (2^(2*M)*(4+m)^4*n^m : Nat) := by
  have h := exact_low_remainder_expansion (k:=4+m) (by omega) G
  push_cast at h
  rw [h,add_sub_cancel_left]
  exact full_signed_remainder_bound (graphEdges G) hM
#print axioms nonempty_subset_expansion
#print axioms exact_low_remainder_expansion
#print axioms actual_expansion_uniform_remainder
end Frustrated
