import Orbit
namespace Frustrated

theorem succ_as_add {k} [NeZero k] (i : Fin k) :
    (⟨(i.val + 1) % k, Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩ : Fin k) = i+1 := by
  apply Fin.ext
  simp [Fin.val_add, Nat.add_mod]

def edgeBool {n k} [NeZero k] (G : Graph (Fin n)) (c : Ambient n k) (i : Fin k) :=
  G.edge (c i) (c (i+1))

theorem tupleOdd_count {n k} [NeZero k] (G : Graph (Fin n)) (c : Ambient n k) :
    tupleOdd G c ↔ (List.ofFn (edgeBool G c)).count true % 2 = 1 := by
  rw [ofFn_count]
  simp only [tupleOdd, edgeBool, succ_as_add]
  rfl

theorem ofFn_perm {k} (e : Equiv.Perm (Fin k)) (f : Fin k → Bool) :
    List.Perm (List.ofFn (fun i => f (e i))) (List.ofFn f) := by
  simpa [List.ofFn_eq_map, List.map_map, Function.comp_def] using
    (Equiv.Perm.map_finRange_perm e).map f

theorem tupleOdd_rot {n k} [NeZero k] (G : Graph (Fin n)) (c : Ambient n k) (r : Fin k) :
    tupleOdd G (rot c r) ↔ tupleOdd G c := by
  rw [tupleOdd_count, tupleOdd_count]
  have hp : edgeBool G (rot c r) = fun i => edgeBool G c (i+r) := by
    funext i
    change G.edge (c (i+r)) (c ((i+1)+r)) = G.edge (c (i+r)) (c ((i+r)+1))
    congr 2
    abel
  let e : Equiv.Perm (Fin k) :=
    { toFun := fun i => i+r
      invFun := fun i => i-r
      left_inv := by intro i; simp
      right_inv := by intro i; simp }
  have hc := (ofFn_perm e (edgeBool G c)).count_eq true
  change (List.ofFn (fun i => edgeBool G c (i+r))).count true = _ at hc
  rw [hp, hc]

theorem tupleOdd_refl {n k} [NeZero k] (G : Graph (Fin n)) (c : Ambient n k) (r : Fin k) :
    tupleOdd G (refl c r) ↔ tupleOdd G c := by
  rw [tupleOdd_count, tupleOdd_count]
  have hp : edgeBool G (refl c r) = fun i => edgeBool G c (r-i-1) := by
    funext i
    change G.edge (c (r-i)) (c (r-(i+1))) =
      G.edge (c (r-i-1)) (c ((r-i-1)+1))
    rw [G.symm]
    congr 2 <;> abel
  let e : Equiv.Perm (Fin k) :=
    { toFun := fun i => r-i-1
      invFun := fun i => r-i-1
      left_inv := by intro i; simp only [sub_eq_add_neg, neg_add_rev, neg_neg]; abel
      right_inv := by intro i; simp only [sub_eq_add_neg, neg_add_rev, neg_neg]; abel }
  have hc := (ofFn_perm e (edgeBool G c)).count_eq true
  change (List.ofFn (fun i => edgeBool G c (r-i-1))).count true = _ at hc
  rw [hp, hc]

theorem tupleOdd_step {n k} [NeZero k] (G : Graph (Fin n))
    {c d : Ambient n k} (h : dihedralStep c d) : tupleOdd G c ↔ tupleOdd G d := by
  obtain ⟨r, rfl | rfl⟩ := (dihedralStep_iff _ _).mp h
  · exact (tupleOdd_rot G c r).symm
  · exact (tupleOdd_refl G c r).symm

#print axioms tupleOdd_rot
#print axioms tupleOdd_refl
#print axioms tupleOdd_step
end Frustrated
