import Discrepancy
namespace Frustrated
/-- An unordered off-diagonal pair meeting the row in exactly one edge. -/
abbrev MixedPair {n} (G : Graph (Fin n)) (w : Fin n) :=
  {s : Finset (Fin n) // s.card = 2 ∧
    (∀ v ∈ s, v ≠ w) ∧
    (∃ v ∈ s, G.edge w v = true) ∧ (∃ x ∈ s, G.edge w x = false)}
noncomputable def pairOfMixed {n} (G : Graph (Fin n)) (w : Fin n)
    (p : RowNeighbor G w × RowNonneighbor G w) : MixedPair G w := by
  classical
  refine ⟨{p.1.val,p.2.val}, ?_, ?_, ?_, ?_⟩
  · simp [mixed_vertices_distinct G w p.1 p.2]
  · intro v hv
    simp only [Finset.mem_insert, Finset.mem_singleton] at hv
    rcases hv with rfl | rfl
    · exact p.1.property.1
    · exact p.2.property.1
  · exact ⟨p.1.val, by simp, p.1.property.2⟩
  · exact ⟨p.2.val, by simp, p.2.property.2⟩

theorem pairOfMixed_injective {n} (G : Graph (Fin n)) (w : Fin n) :
    Function.Injective (pairOfMixed G w) := by
  classical
  intro p q h
  have he := congrArg Subtype.val h
  change ({p.1.val,p.2.val} : Finset (Fin n)) = {q.1.val,q.2.val} at he
  have hv : p.1.val = q.1.val := by
    have hm : p.1.val ∈ ({q.1.val,q.2.val} : Finset (Fin n)) := by
      rw [← he]; simp
    simp only [Finset.mem_insert, Finset.mem_singleton] at hm
    rcases hm with hm | hm
    · exact hm
    · have hp := p.1.property.2
      rw [hm,q.2.property.2] at hp
      contradiction
  have hx : p.2.val = q.2.val := by
    have hm : p.2.val ∈ ({q.1.val,q.2.val} : Finset (Fin n)) := by
      rw [← he]; simp
    simp only [Finset.mem_insert, Finset.mem_singleton] at hm
    rcases hm with hm | hm
    · have hp := p.2.property.2
      rw [hm,q.1.property.2] at hp
      contradiction
    · exact hm
  exact Prod.ext (Subtype.ext hv) (Subtype.ext hx)

theorem pairOfMixed_surjective {n} (G : Graph (Fin n)) (w : Fin n) :
    Function.Surjective (pairOfMixed G w) := by
  classical
  intro s
  obtain ⟨v,hv,he⟩ := s.property.2.2.1
  obtain ⟨x,hx,hf⟩ := s.property.2.2.2
  have hne : v ≠ x := by intro h; rw [h,hf] at he; contradiction
  let p : RowNeighbor G w × RowNonneighbor G w :=
    (⟨v,s.property.2.1 v hv,he⟩,⟨x,s.property.2.1 x hx,hf⟩)
  refine ⟨p, Subtype.ext ?_⟩
  change ({v,x} : Finset (Fin n)) = s.val
  apply Finset.eq_of_subset_of_card_le
  · intro z hz
    simp only [Finset.mem_insert, Finset.mem_singleton] at hz
    rcases hz with rfl | rfl <;> assumption
  · simp [s.property.1,hne]

noncomputable def mixedPairEquiv {n} (G : Graph (Fin n)) (w : Fin n) :
    (RowNeighbor G w × RowNonneighbor G w) ≃ MixedPair G w :=
  Equiv.ofBijective (pairOfMixed G w)
    ⟨pairOfMixed_injective G w,pairOfMixed_surjective G w⟩

/-- Actual unordered pair count: no factor two is present. -/
theorem unordered_mixed_pair_card {n} (G : Graph (Fin n)) (w : Fin n) :
    Nat.card (MixedPair G w) = rowDegree G w * (n-1-rowDegree G w) := by
  rw [← Nat.card_congr (mixedPairEquiv G w), Nat.card_prod,
    row_nonneighbor_card]
  rfl

theorem opposite_pair_card {n} (G : Graph (Fin n)) :
    Nat.card ((w : Fin n) × MixedPair G w) =
      ∑ w : Fin n, rowDegree G w * (n-1-rowDegree G w) := by
  classical
  rw [Nat.card_eq_fintype_card, Fintype.card_sigma]
  apply Finset.sum_congr rfl
  intro w _
  rw [← Nat.card_eq_fintype_card, unordered_mixed_pair_card]
#print axioms mixedPairEquiv
#print axioms opposite_pair_card
end Frustrated
