import Parity
import Mathlib.Algebra.Group.Fin.Basic
import Mathlib.Tactic.Abel
namespace Frustrated

def rot {n k} [NeZero k] (c : Ambient n k) (r : Fin k) : Ambient n k where
  toFun i := c (i + r)
  inj' := fun _ _ h => add_right_cancel (c.injective h)

def refl {n k} [NeZero k] (c : Ambient n k) (r : Fin k) : Ambient n k where
  toFun i := c (r - i)
  inj' := fun _ _ h => sub_right_injective (c.injective h)

theorem dihedralStep_iff {n k} [NeZero k] (c d : Ambient n k) :
    dihedralStep c d ↔ ∃ r : Fin k, d = rot c r ∨ d = refl c r := by
  constructor
  · rintro ⟨r, h | h⟩
    · exact ⟨r, Or.inl (Function.Embedding.ext (fun i => h i (i+r) rfl))⟩
    · exact ⟨r, Or.inr (Function.Embedding.ext (fun i => h i (r-i) (by rw [Fin.val_sub]; congr 1; omega)))⟩
  · rintro ⟨r, rfl | rfl⟩
    · refine ⟨r, Or.inl ?_⟩
      intro i j h
      change c (i+r) = c j
      congr 1
      apply Fin.ext
      exact h.symm
    · refine ⟨r, Or.inr ?_⟩
      intro i j h
      change c (r-i) = c j
      congr 1
      apply Fin.ext
      rw [Fin.val_sub]
      convert h.symm using 2
      omega

theorem rot_zero {n k} [NeZero k] (c : Ambient n k) : rot c 0 = c := by
  ext i; simp [rot]

theorem rot_rot {n k} [NeZero k] (c : Ambient n k) (r s : Fin k) :
    rot (rot c r) s = rot c (s+r) := by
  apply Function.Embedding.ext
  intro i
  change c ((i+s)+r) = c (i+(s+r))
  rw [add_assoc]

theorem refl_refl {n k} [NeZero k] (c : Ambient n k) (r s : Fin k) :
    refl (refl c r) s = rot c (r-s) := by
  apply Function.Embedding.ext
  intro i
  change c (r - (s - i)) = c (i + (r-s))
  congr 1
  abel

theorem rot_refl {n k} [NeZero k] (c : Ambient n k) (r s : Fin k) :
    refl (rot c r) s = refl c (s+r) := by
  apply Function.Embedding.ext
  intro i
  change c ((s-i)+r) = c ((s+r)-i)
  congr 1
  abel

theorem refl_rot {n k} [NeZero k] (c : Ambient n k) (r s : Fin k) :
    rot (refl c r) s = refl c (r-s) := by
  apply Function.Embedding.ext
  intro i
  change c (r-(i+s)) = c ((r-s)-i)
  congr 1
  abel

theorem step_refl {n k} [NeZero k] (c : Ambient n k) : dihedralStep c c := by
  rw [dihedralStep_iff]
  exact ⟨0, Or.inl (rot_zero c).symm⟩

theorem step_symm {n k} [NeZero k] {c d : Ambient n k}
    (h : dihedralStep c d) : dihedralStep d c := by
  rw [dihedralStep_iff] at h ⊢
  obtain ⟨r, rfl | rfl⟩ := h
  · refine ⟨-r, Or.inl ?_⟩
    rw [rot_rot, neg_add_cancel, rot_zero]
  · refine ⟨r, Or.inr ?_⟩
    rw [refl_refl, sub_self, rot_zero]

theorem step_trans {n k} [NeZero k] {c d e : Ambient n k}
    (h : dihedralStep c d) (h' : dihedralStep d e) : dihedralStep c e := by
  rw [dihedralStep_iff] at h h' ⊢
  obtain ⟨r, rfl | rfl⟩ := h
  · obtain ⟨s, rfl | rfl⟩ := h'
    · exact ⟨s+r, Or.inl (rot_rot c r s)⟩
    · exact ⟨s+r, Or.inr (rot_refl c r s)⟩
  · obtain ⟨s, rfl | rfl⟩ := h'
    · exact ⟨r-s, Or.inr (refl_rot c r s)⟩
    · exact ⟨r-s, Or.inl (refl_refl c r s)⟩

theorem rot_parameter_injective {n k} [NeZero k] (c : Ambient n k) :
    Function.Injective (rot c) := by
  intro r s h
  have hh := congrArg (fun d : Ambient n k => d 0) h
  change c (0+r) = c (0+s) at hh
  simpa using c.injective hh

theorem refl_parameter_injective {n k} [NeZero k] (c : Ambient n k) :
    Function.Injective (refl c) := by
  intro r s h
  have hh := congrArg (fun d : Ambient n k => d 0) h
  change c (r-0) = c (s-0) at hh
  simpa using c.injective hh

theorem rot_ne_refl {n k} [NeZero k] (hk : 3 ≤ k) (c : Ambient n k)
    (r s : Fin k) : rot c r ≠ refl c s := by
  intro h
  have h0 := congrArg (fun d : Ambient n k => d 0) h
  change c (0+r) = c (s-0) at h0
  have hrs : r = s := by simpa using c.injective h0
  subst s
  have hh := congrArg (fun d : Ambient n k => d 1) h
  change c (1+r) = c (r-1) at hh
  have h1 := c.injective hh
  have htwo : (1 : Fin k) + 1 = 0 := by
    calc
      (1 : Fin k) + 1 = ((1+r)-r)+1 := by abel
      _ = ((r-1)-r)+1 := by rw [h1]
      _ = 0 := by abel
  have hv := congrArg Fin.val htwo
  norm_num [Fin.val_add, Fin.val_one, Nat.mod_eq_of_lt (show 2 < k by omega)] at hv

def orbitMap {n k} [NeZero k] (c : Ambient n k) (p : Bool × Fin k) :
    {d : Ambient n k // dihedralStep c d} :=
  if p.1 then ⟨refl c p.2, (dihedralStep_iff _ _).mpr ⟨p.2, Or.inr rfl⟩⟩
  else ⟨rot c p.2, (dihedralStep_iff _ _).mpr ⟨p.2, Or.inl rfl⟩⟩

theorem orbitMap_bijective {n k} [NeZero k] (hk : 3 ≤ k) (c : Ambient n k) :
    Function.Bijective (orbitMap c) := by
  constructor
  · rintro ⟨b,r⟩ ⟨d,s⟩ h
    have hv := congrArg Subtype.val h
    cases b <;> cases d
    · have hh : r = s := rot_parameter_injective c hv
      subst s; rfl
    · exact False.elim (rot_ne_refl hk c r s hv)
    · exact False.elim (rot_ne_refl hk c s r hv.symm)
    · have hh : r = s := refl_parameter_injective c hv
      subst s; rfl
  · rintro ⟨d,hd⟩
    obtain ⟨r, hr | hr⟩ := (dihedralStep_iff c d).mp hd
    · refine ⟨(false,r), ?_⟩
      apply Subtype.ext
      exact hr.symm
    · refine ⟨(true,r), ?_⟩
      apply Subtype.ext
      exact hr.symm

theorem ambient_orbit_card {n k} [NeZero k] (hk : 3 ≤ k) (c : Ambient n k) :
    Nat.card {d : Ambient n k // dihedralStep c d} = 2*k := by
  rw [← Nat.card_congr (Equiv.ofBijective (orbitMap c) (orbitMap_bijective hk c))]
  simp

#print axioms ambient_orbit_card
#print axioms dihedralStep_iff
#print axioms step_trans
#print axioms rot_ne_refl
end Frustrated
