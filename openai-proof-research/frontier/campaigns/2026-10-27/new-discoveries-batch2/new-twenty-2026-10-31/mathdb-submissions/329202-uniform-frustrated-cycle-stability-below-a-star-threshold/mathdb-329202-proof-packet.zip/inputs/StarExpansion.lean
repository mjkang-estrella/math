import StarSupport
namespace Frustrated

theorem empty_tuple_completions (n k : Nat) :
    tupleCompletions (n:=n) (k:=k) ∅ = Nat.card (Ambient n k) := by
  unfold tupleCompletions
  have e : {c : Ambient n k // (∅ : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} ≃ Ambient n k :=
    { toFun := Subtype.val
      invFun := fun c => ⟨c,Finset.empty_subset _⟩
      left_inv := fun _ => rfl
      right_inv := fun _ => rfl }
  exact Nat.card_congr e

/-- Exact source expansion, with all terms of support ≥3 removed by proof. -/
theorem star_truncated_expansion {n k s : Nat} (hk : 3≤k) :
    (4*(k:Int))*cycleCount n k (star n s) =
      - ∑ F ∈ ((graphEdges (star n s)).powerset.filter
        (fun F => 1≤F.card ∧ F.card≤2)),
          (-2:Int)^F.card * tupleCompletions (k:=k) F := by
  classical
  let E := graphEdges (star n s)
  let w := fun F : Finset (Sym2 (Fin n)) => (-2:Int)^F.card * tupleCompletions (k:=k) F
  have hpart : ∑ F ∈ E.powerset, w F = w ∅ +
      ∑ F ∈ E.powerset.filter (fun F => 1≤F.card ∧ F.card≤2), w F := by
    have hpoint (F : Finset (Sym2 (Fin n))) (hF : F∈E.powerset) :
        w F = (if F=∅ then w ∅ else 0) +
          (if 1≤F.card ∧ F.card≤2 then w F else 0) := by
      by_cases hz : F=∅
      · subst F; simp
      · have hpos : 1≤F.card := by exact Nat.succ_le_of_lt (Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr hz))
        by_cases hsmall : F.card≤2
        · simp [hz,hpos,hsmall]
        · have hzero := star_higher_completion_zero hk F (Finset.mem_powerset.mp hF) (by omega)
          simp [w,hz,hsmall,hzero]
    calc
      _ = ∑ F ∈ E.powerset, ((if F=∅ then w ∅ else 0) +
          (if 1≤F.card ∧ F.card≤2 then w F else 0)) := Finset.sum_congr rfl hpoint
      _ = _ := by simp [Finset.sum_add_distrib,Finset.sum_filter]
  have h := subset_expansion_cycle_scale hk (star n s)
  change (4*(k:Int))*cycleCount n k (star n s) =
    (Nat.card (Ambient n k):Int) - ∑ F ∈ E.powerset, w F at h
  rw [hpart] at h
  have hw : w ∅=(Nat.card (Ambient n k):Int) := by simp [w,empty_tuple_completions]
  rw [hw] at h
  simpa only [sub_add_cancel_left] using h
#print axioms star_truncated_expansion
end Frustrated
