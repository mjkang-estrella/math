import SparseMinimum
namespace Frustrated

theorem canonical_star_successor_lt {n s m : Nat}
    (hn : 2*s+2 < n) (hk : 3+m ≤ n) :
    cycleCount n (3+m) (star n s) < cycleCount n (3+m) (star n (s+1)) := by
  have h₀ := canonical_star_formula (m:=m) (s:=s) (by omega : s+1≤n)
  have h₁ := canonical_star_formula (m:=m) (s:=s+1) (by omega : s+1+1≤n)
  have hchoose : (s+1).choose 2=s.choose 2+s := by
    simpa [Nat.add_comm] using Nat.choose_succ_succ s 1
  have hn3 : n-3+1=n-2 := by omega
  have hfac : (n-2).descFactorial (1+m)=(n-2)*(n-3).descFactorial m := by
    simpa only [hn3,Nat.add_comm m 1] using Nat.succ_descFactorial_succ (n-3) m
  have hb : (0:Int) < (n-3).descFactorial m := by
    exact_mod_cast falling_eventual_positive 3 m n hk
  have hlead : (0:Int) < ((n-2:Nat):Int)-2*(s:Int) := by omega
  have hprod := mul_pos hlead hb
  rw [hchoose] at h₁
  rw [hfac] at h₀ h₁
  push_cast at h₀ h₁
  have hh : (cycleCount n (3+m) (star n s):Int) < (cycleCount n (3+m) (star n (s+1)):Int) := by
    nlinarith only [h₀,h₁,hprod]
  exact_mod_cast hh

theorem canonical_star_monotone {n s u m M : Nat}
    (hsu : s≤u) (hu : u≤M) (hn : 2*M+2<n) (hk : 3+m≤n) :
    cycleCount n (3+m) (star n s) ≤ cycleCount n (3+m) (star n u) := by
  have h : ∀ v, s≤v → v≤M →
      cycleCount n (3+m) (star n s) ≤ cycleCount n (3+m) (star n v) := by
    intro v hsv
    induction v, hsv using Nat.le_induction with
    | base => intro _; exact le_rfl
    | succ v hsv ih =>
      intro hv
      exact (ih (by omega)).trans (canonical_star_successor_lt (m:=m) (by omega : 2*v+2<n) hk).le
  exact h u hsu hu

theorem sparse_strict_threshold_forces_card {n m M t : Nat} (G : Graph (Fin n))
    (hM : (graphEdges G).card≤M) (hn : 2*M+2<n)
    (hfall : 2*(3+(1+m))≤n)
    (hlarge : (2^(2*M)*(4+m)^4)*2^(1+m)<n)
    (hthreshold : cycleCount n (4+m) G < cycleCount n (4+m) (star n (t+1))) :
    (graphEdges G).card≤t := by
  by_contra hbad
  have hs : t+1≤(graphEdges G).card := by omega
  have hmin := uniform_sparse_star_minimum G hM (by omega) hfall hlarge
  have hmono := canonical_star_monotone (m:=1+m) hs hM hn (by omega)
  have he : 3+(1+m)=4+m := by omega
  rw [he] at hmono
  omega

theorem three_strict_threshold_forces_card {n M t : Nat} (G : Graph (Fin n))
    (hM : (graphEdges G).card≤M) (hn : 2*M+2<n) (hk : 3≤n)
    (hthreshold : cycleCount n 3 G < cycleCount n 3 (star n (t+1))) :
    (graphEdges G).card≤t := by
  by_contra hbad
  have hs : t+1≤(graphEdges G).card := by omega
  have hmin := three_sparse_star_lower G (by omega)
  have hmono := canonical_star_monotone (m:=0) hs hM hn hk
  simp only [Nat.add_zero] at hmono
  omega
#print axioms canonical_star_successor_lt
#print axioms sparse_strict_threshold_forces_card
#print axioms three_strict_threshold_forces_card
end Frustrated
