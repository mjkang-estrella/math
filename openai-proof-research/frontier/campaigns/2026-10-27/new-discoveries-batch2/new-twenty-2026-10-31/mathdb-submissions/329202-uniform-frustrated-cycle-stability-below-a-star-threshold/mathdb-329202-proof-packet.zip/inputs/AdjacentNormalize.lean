import Orbit
import Mathlib.Data.Sym.Sym2
namespace Frustrated
/-- An actual unordered consecutive edge of the ambient cycle tuple. -/
def HasCyclePair {n k} [NeZero k] (c : Ambient n k) (a b : Fin n) : Prop :=
  ∃ i : Fin k, s(c i,c (i+1)) = s(a,b)

theorem pair_positions {n k} [NeZero k] (c : Ambient n k) (a b : Fin n)
    (h : HasCyclePair c a b) :
    ∃ x y : Fin k, c x = a ∧ c y = b ∧ (y=x+1 ∨ x=y+1) := by
  obtain ⟨i,hi⟩ := h
  rcases Sym2.eq_iff.mp hi with h | h
  · exact ⟨i,i+1,h.1,h.2,Or.inl rfl⟩
  · exact ⟨i+1,i,h.2,h.1,Or.inr rfl⟩

/-- Two incident edges force a consecutive path; distinct endpoints rule out
    the two backtracking possibilities, including at k=3. -/
theorem adjacent_positions {n k} [NeZero k] (hk : 3 ≤ k) (c : Ambient n k)
    (a b d : Fin n) (had : a ≠ d)
    (h₁ : HasCyclePair c a b) (h₂ : HasCyclePair c b d) :
    ∃ x : Fin k, c x = a ∧
      ((c (x+1) = b ∧ c (x+2) = d) ∨
       (c (x-1) = b ∧ c (x-2) = d)) := by
  have ht : (2 : Fin k) = 1+1 := by
    apply Fin.ext
    norm_num [Fin.val_add, Fin.val_ofNat, Nat.mod_eq_of_lt (by omega : 1<k),
      Nat.mod_eq_of_lt (by omega : 2<k)]
  obtain ⟨x,y,hx,hy,hxy⟩ := pair_positions c a b h₁
  obtain ⟨y',z,hy',hz,hyz⟩ := pair_positions c b d h₂
  have he : y'=y := c.injective (hy'.trans hy.symm)
  subst y'
  have hxz : x ≠ z := fun h => had (hx.symm.trans ((congrArg c h).trans hz))
  refine ⟨x,hx,?_⟩
  rcases hxy with hxy | hxy <;> rcases hyz with hyz | hyz
  · left
    constructor
    · simpa only [hxy] using hy
    · have he : z=x+2 := by rw [hyz,hxy,ht]; abel
      simpa only [he] using hz
  · exact False.elim (hxz (add_right_cancel (hxy.symm.trans hyz)))
  · exact False.elim (hxz (hxy.trans hyz.symm))
  · right
    have he : y=x-1 := by rw [hxy]; abel
    have he' : z=x-2 := by rw [hxy,hyz,ht]; abel
    exact ⟨he ▸ hy,he' ▸ hz⟩

/-- Existence of an orbit representative with the specified ordered path. -/
theorem adjacent_normalize {n k} [NeZero k] (hk : 3 ≤ k)
    (c : Ambient n k) (q : Ambient n 3)
    (h₁ : HasCyclePair c (q 0) (q 1))
    (h₂ : HasCyclePair c (q 1) (q 2)) :
    ∃ d : Ambient n k, dihedralStep c d ∧
      d 0=q 0 ∧ d 1=q 1 ∧ d 2=q 2 := by
  have h02 : q 0 ≠ q 2 := by intro h; have := q.injective h; have := congrArg Fin.val this; norm_num at this
  obtain ⟨x,hx,ho⟩ := adjacent_positions hk c (q 0) (q 1) (q 2) h02 h₁ h₂
  rcases ho with ho | ho
  · refine ⟨rot c x,(dihedralStep_iff _ _).mpr ⟨x,Or.inl rfl⟩,?_,?_,?_⟩
    · change c (0+x) = q 0
      simpa using hx
    · change c (1+x) = q 1
      simpa only [add_comm] using ho.1
    · change c (2+x) = q 2
      simpa only [add_comm] using ho.2
  · refine ⟨refl c x,(dihedralStep_iff _ _).mpr ⟨x,Or.inr rfl⟩,?_,?_,?_⟩
    · change c (x-0) = q 0
      simpa using hx
    · exact ho.1
    · exact ho.2
#print axioms adjacent_positions
#print axioms adjacent_normalize
end Frustrated
