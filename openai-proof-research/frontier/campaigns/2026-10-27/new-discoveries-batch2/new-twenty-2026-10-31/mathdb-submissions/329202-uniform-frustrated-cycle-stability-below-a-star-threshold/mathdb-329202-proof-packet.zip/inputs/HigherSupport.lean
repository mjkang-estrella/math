import CycleDegreeBound
import Mathlib.Tactic.FinCases
namespace Frustrated

theorem support_loopless {n k} (hk : 3 ≤ k) (c : Ambient n k) (a : Fin n) :
    s(a,a) ∉ cycleSupport c := by
  classical
  intro h
  obtain ⟨i,_,hi⟩ := Finset.mem_image.mp h
  change s(c i,c (nextIndex i)) = s(a,a) at hi
  rcases Sym2.eq_iff.mp hi with h | h
  · exact nextIndex_ne hk i (c.injective (h.1.trans h.2.symm))
  · exact nextIndex_ne hk i (c.injective (h.1.trans h.2.symm))

theorem higher_support_has_disjoint {n m} (F : Finset (Sym2 (Fin n)))
    (hcard : 3 ≤ F.card) (c : Ambient n (4+m)) (hF : F ⊆ cycleSupport c) :
    ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f := by
  classical
  by_contra! h
  have hloop : ∀ a, s(a,a) ∉ F := fun a ha => support_loopless (by omega) c a (hF ha)
  rcases pairwise_intersecting_classification F (Finset.card_pos.mp (by omega)) hloop h with hs | ht
  · obtain ⟨a,ha⟩ := hs
    have sub : F ⊆ (cycleSupport c).filter (fun e => a ∈ e) := by
      intro e he
      exact Finset.mem_filter.mpr ⟨hF he,ha e he⟩
    have hh := (Finset.card_le_card sub).trans (cycle_incident_card_le_two c a)
    omega
  · obtain ⟨a,b,d,hab,had,hbd,hEq⟩ := ht
    let q : Ambient n 3 := ⟨![a,b,d],by
      intro i j hij
      fin_cases i <;> fin_cases j <;> simp_all⟩
    have hzero := triangle_completion_zero (m:=m) q
    have hsub : ({s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c := by
      intro e he
      apply hF
      rw [hEq]
      change e ∈ ({s(a,b),s(b,d),s(d,a)} : Finset (Sym2 (Fin n))) at he
      simp only [Finset.mem_insert,Finset.mem_singleton] at he ⊢
      rcases he with rfl | rfl | rfl
      · exact Or.inl rfl
      · exact Or.inr (Or.inr rfl)
      · exact Or.inr (Or.inl Sym2.eq_swap)
    have hpos : 0 < Nat.card {c : Ambient n (4+m) //
        ({s(q 0,q 1),s(q 1,q 2),s(q 2,q 0)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} :=
      Nat.card_pos_iff.mpr ⟨⟨⟨c,hsub⟩⟩,inferInstance⟩
    omega

theorem disjoint_incident_four {n} (F : Finset (Sym2 (Fin n)))
    (hloop : ∀ a, s(a,a) ∉ F)
    (hdis : ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f) :
    ∃ q : Ambient n 4, ∀ i, ∃ e ∈ F, q i ∈ e := by
  classical
  obtain ⟨e,he,f,hf,hd⟩ := hdis
  induction e using Sym2.inductionOn with
  | _ a b =>
    induction f using Sym2.inductionOn with
    | _ c d =>
      have hab : a ≠ b := by intro h; subst b; exact hloop a he
      have hcd : c ≠ d := by intro h; subst d; exact hloop c hf
      have hac : a ≠ c := by intro h; subst c; exact hd ⟨a,by simp,by simp⟩
      have had : a ≠ d := by intro h; subst d; exact hd ⟨a,by simp,by simp⟩
      have hbc : b ≠ c := by intro h; subst c; exact hd ⟨b,by simp,by simp⟩
      have hbd : b ≠ d := by intro h; subst d; exact hd ⟨b,by simp,by simp⟩
      let q : Ambient n 4 := ⟨![a,b,c,d],by
        intro i j hij
        fin_cases i <;> fin_cases j <;> simp_all⟩
      refine ⟨q,?_⟩
      intro i
      fin_cases i
      · exact ⟨_,he,by change a ∈ s(a,b); simp⟩
      · exact ⟨_,he,by change b ∈ s(a,b); simp⟩
      · exact ⟨_,hf,by change c ∈ s(c,d); simp⟩
      · exact ⟨_,hf,by change d ∈ s(c,d); simp⟩

theorem bad_support_completion_bound {n m} (F : Finset (Sym2 (Fin n)))
    (hbad : 3 ≤ F.card ∨ ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f) :
    tupleCompletions (k:=4+m) F ≤ (4+m)^4*n^m := by
  classical
  by_cases hz : tupleCompletions (k:=4+m) F = 0
  · rw [hz]; exact Nat.zero_le _
  have hp : 0 < Nat.card {c : Ambient n (4+m) // F ⊆ cycleSupport c} := Nat.pos_of_ne_zero hz
  obtain ⟨c,hc⟩ := (Nat.card_pos_iff.mp hp).1
  have hd : ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f := by
    rcases hbad with h | h
    · exact higher_support_has_disjoint F h c hc
    · exact h
  have hl : ∀ a, s(a,a) ∉ F := fun a ha => support_loopless (by omega) c a (hc ha)
  obtain ⟨q,hq⟩ := disjoint_incident_four F hl hd
  exact four_vertex_completion_bound F q hq
#print axioms higher_support_has_disjoint
#print axioms bad_support_completion_bound
end Frustrated
