import Structural
import Mathlib.Tactic.FinCases
import Mathlib.Data.Fintype.Sigma
namespace Frustrated
/-- Off-diagonal neighbors in an actual finite symmetric graph. -/
abbrev RowNeighbor {n} (G : Graph (Fin n)) (w : Fin n) :=
  {v : Fin n // v ≠ w ∧ G.edge w v = true}
abbrev RowNonneighbor {n} (G : Graph (Fin n)) (w : Fin n) :=
  {v : Fin n // v ≠ w ∧ G.edge w v = false}
noncomputable def rowDegree {n} (G : Graph (Fin n)) (w : Fin n) :=
  Nat.card (RowNeighbor G w)
abbrev RowMixed {n} (G : Graph (Fin n)) :=
  (w : Fin n) × (RowNeighbor G w × RowNonneighbor G w)

theorem row_nonneighbor_card {n} (G : Graph (Fin n)) (w : Fin n) :
    Nat.card (RowNonneighbor G w) = n - 1 - rowDegree G w := by
  classical
  let e : {v : Fin n // ¬(v ≠ w ∧ G.edge w v = true)} ≃
      Option (RowNonneighbor G w) :=
    { toFun := fun v => if h : v.val = w then none else
        some ⟨v.val, h, by
          have hh := v.property
          cases he : G.edge w v.val <;> simp_all⟩
      invFun := fun v => match v with
        | none => ⟨w, by simp⟩
        | some v => ⟨v.val, by simp [v.property.2]⟩
      left_inv := by
        intro v
        dsimp
        split_ifs with h
        · exact Subtype.ext h.symm
        · rfl
      right_inv := by
        intro v
        cases v with
        | none => simp
        | some v => simp [v.property.1] }
  have hc := Fintype.card_subtype_compl (fun v : Fin n => v ≠ w ∧ G.edge w v = true)
  have hh := Nat.card_congr e
  simp only [Nat.card_eq_fintype_card, Fintype.card_option] at hh
  change Nat.card (RowNonneighbor G w) = n - 1 - Nat.card (RowNeighbor G w)
  simp only [Nat.card_eq_fintype_card]
  change Fintype.card (RowNonneighbor G w) = n - 1 - Fintype.card {v : Fin n // v ≠ w ∧ G.edge w v = true}
  simp only [Fintype.card_fin] at hc
  omega

theorem row_mixed_card {n} (G : Graph (Fin n)) :
    Nat.card (RowMixed G) =
      ∑ w : Fin n, rowDegree G w * (n-1-rowDegree G w) := by
  classical
  rw [Nat.card_eq_fintype_card, Fintype.card_sigma]
  apply Finset.sum_congr rfl
  intro w _
  rw [Fintype.card_prod]
  simp only [← Nat.card_eq_fintype_card, row_nonneighbor_card, rowDegree]

/-- A mixed pair has a distinguished neighbor, so reversal is not counted twice. -/
theorem mixed_vertices_distinct {n} (G : Graph (Fin n)) (w : Fin n)
    (v : RowNeighbor G w) (x : RowNonneighbor G w) : v.val ≠ x.val := by
  intro h
  have he := v.property.2
  rw [h, x.property.2] at he
  contradiction

#print axioms row_nonneighbor_card
#print axioms row_mixed_card
#print axioms mixed_vertices_distinct
end Frustrated
