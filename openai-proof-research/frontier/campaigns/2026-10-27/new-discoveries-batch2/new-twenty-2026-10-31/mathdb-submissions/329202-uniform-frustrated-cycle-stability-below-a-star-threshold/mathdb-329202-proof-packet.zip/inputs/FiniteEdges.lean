import ThresholdTransfer
import Mathlib.Data.Sym.Sym2
namespace Frustrated
noncomputable instance sym2FinFintype {n} : Fintype (Sym2 (Fin n)) := Fintype.ofFinite _
def cycleEdge {n k} (c : Ambient n k) (i : Fin k) : Sym2 (Fin n) :=
  s(c i,c (nextIndex i))

theorem cycleEdge_injective {n k} (hk : 3 ≤ k) (c : Ambient n k) :
    Function.Injective (cycleEdge c) := by
  intro i j h
  rcases Sym2.eq_iff.mp h with h | h
  · exact c.injective h.1
  · have h1 := c.injective h.1
    have h2 := c.injective h.2
    have hv1 := congrArg Fin.val h1
    have hv2 := congrArg Fin.val h2
    change i.val = (j.val+1)%k at hv1
    change (i.val+1)%k = j.val at hv2
    have hi := i.isLt
    have hj := j.isLt
    by_cases hi' : i.val+1<k
    · rw [Nat.mod_eq_of_lt hi'] at hv2
      by_cases hj' : j.val+1<k
      · rw [Nat.mod_eq_of_lt hj'] at hv1
        omega
      · have he : j.val+1=k := by omega
        rw [he,Nat.mod_self] at hv1
        omega
    · have he : i.val+1=k := by omega
      rw [he,Nat.mod_self] at hv2
      have hj' : j.val+1<k := by omega
      rw [Nat.mod_eq_of_lt hj'] at hv1
      omega

def edgePresent {n} (G : Graph (Fin n)) : Sym2 (Fin n) → Bool :=
  Sym2.lift ⟨G.edge,G.symm⟩
noncomputable def graphEdges {n} (G : Graph (Fin n)) : Finset (Sym2 (Fin n)) := by
  classical
  exact Finset.univ.filter (fun e => edgePresent G e = true)
noncomputable def cycleSupport {n k} (c : Ambient n k) : Finset (Sym2 (Fin n)) := by
  classical
  exact Finset.univ.image (cycleEdge c)

theorem cycleSupport_card {n k} (hk : 3 ≤ k) (c : Ambient n k) :
    (cycleSupport c).card = k := by
  classical
  exact (Finset.card_image_of_injective _ (cycleEdge_injective hk c)).trans (by simp)

theorem graph_cycle_intersection {n k} (G : Graph (Fin n)) (c : Ambient n k) :
    graphEdges G ∩ cycleSupport c =
      (Finset.univ.filter (fun i => G.edge (c i) (c (nextIndex i)) = true)).image
        (cycleEdge c) := by
  classical
  ext e
  simp only [graphEdges,cycleSupport,Finset.mem_inter,Finset.mem_filter,
    Finset.mem_univ,true_and,Finset.mem_image]
  constructor
  · rintro ⟨he,i,_,rfl⟩
    exact ⟨i,he,rfl⟩
  · rintro ⟨i,he,rfl⟩
    exact ⟨he,i,rfl⟩

theorem tupleOdd_edge_subset {n k} (hk : 3 ≤ k) (G : Graph (Fin n)) (c : Ambient n k) :
    tupleOdd G c ↔ (graphEdges G ∩ cycleSupport c).card % 2 = 1 := by
  classical
  rw [graph_cycle_intersection,Finset.card_image_of_injective _ (cycleEdge_injective hk c)]
  rfl
#print axioms cycleEdge_injective
#print axioms tupleOdd_edge_subset
end Frustrated
