import FixedPositions
namespace Frustrated
/-- Possible starts of an edge disjoint from positions 0 and 1, without wrap. -/
def disjointStart {m} (j : Fin (1+m)) : Fin (4+m) := ⟨j.val+2,by omega⟩
def disjointEnd {m} (j : Fin (1+m)) : Fin (4+m) := ⟨j.val+3,by omega⟩

theorem disjoint_next {m} (j : Fin (1+m)) :
    disjointStart j+1=disjointEnd j := by
  apply Fin.ext
  simp only [Fin.val_add,disjointStart,disjointEnd]
  norm_num [Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<4+m),
    Nat.mod_eq_of_lt (by omega : j.val+2+1<4+m)]

theorem disjoint_slots {n m} (c : Ambient n (4+m)) (q : Ambient n 4)
    (h₀ : c 0=q 0) (h₁ : c 1=q 1)
    (h : HasCyclePair c (q 2) (q 3)) :
    ∃ j : Fin (1+m),
      (c (disjointStart j)=q 2 ∧ c (disjointEnd j)=q 3) ∨
      (c (disjointStart j)=q 3 ∧ c (disjointEnd j)=q 2) := by
  obtain ⟨i,hi⟩ := h
  have hne (v : Fin (4+m)) (hv : c v=q 2 ∨ c v=q 3) :
      v ≠ 0 ∧ v ≠ 1 := by
    constructor
    · intro he
      subst v
      rcases hv with hv | hv
      · have he := q.injective (h₀.symm.trans hv)
        have := congrArg Fin.val he
        norm_num at this
      · have he := q.injective (h₀.symm.trans hv)
        have := congrArg Fin.val he
        norm_num at this
    · intro he
      subst v
      rcases hv with hv | hv
      · have he := q.injective (h₁.symm.trans hv)
        have := congrArg Fin.val he
        norm_num at this
      · have he := q.injective (h₁.symm.trans hv)
        have := congrArg Fin.val he
        norm_num at this
  have hev := Sym2.eq_iff.mp hi
  have hi' : c i=q 2 ∨ c i=q 3 := by rcases hev with h | h; exact Or.inl h.1; exact Or.inr h.1
  have hn' : c (i+1)=q 2 ∨ c (i+1)=q 3 := by rcases hev with h | h; exact Or.inr h.2; exact Or.inl h.2
  have hi0 := (hne i hi').1
  have hi1 := (hne i hi').2
  have hn0 := (hne (i+1) hn').1
  have hlow : 2 ≤ i.val := by
    have h0 : i.val ≠ 0 := by intro hh; exact hi0 (Fin.ext (by simpa using hh))
    have h1 : i.val ≠ 1 := by intro hh; exact hi1 (Fin.ext (by simpa [Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<4+m)] using hh))
    omega
  have hupp : i.val+1<4+m := by
    by_contra hh
    have he : i.val+1=4+m := by omega
    apply hn0
    apply Fin.ext
    simp only [Fin.val_add]
    norm_num [Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<4+m),he]
  let j : Fin (1+m) := ⟨i.val-2,by omega⟩
  have hs : disjointStart j=i := by apply Fin.ext; change i.val-2+2=i.val; omega
  have he : disjointEnd j=i+1 := by rw [← disjoint_next,hs]
  refine ⟨j,?_⟩
  rw [hs,he]
  exact hev
#print axioms disjoint_slots
end Frustrated
