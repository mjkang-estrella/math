import EventualDominance
namespace Frustrated

theorem support_incident_at {n k} [NeZero k] (c : Ambient n k) (i : Fin k)
    (e : Sym2 (Fin n)) (he : e ∈ cycleSupport c) (hv : c i ∈ e) :
    e ∈ ({cycleEdge c i,cycleEdge c (i-1)} : Finset (Sym2 (Fin n))) := by
  classical
  obtain ⟨j,_,hj⟩ := Finset.mem_image.mp he
  rw [← hj] at hv ⊢
  change c i ∈ s(c j,c (nextIndex j)) at hv
  rcases Sym2.mem_iff.mp hv with hv | hv
  · have hij := c.injective hv
    subst j
    simp
  · have hij := c.injective hv
    unfold nextIndex at hij
    rw [succ_as_add] at hij
    have hji : j=i-1 := by rw [hij]; abel
    subst j
    simp

theorem cycle_incident_card_le_two {n k} [NeZero k] (c : Ambient n k) (v : Fin n) :
    ((cycleSupport c).filter (fun e => v ∈ e)).card ≤ 2 := by
  classical
  by_cases hv : ∃ i, c i=v
  · obtain ⟨i,rfl⟩ := hv
    have hs : (cycleSupport c).filter (fun e => c i ∈ e) ⊆
        {cycleEdge c i,cycleEdge c (i-1)} := by
      intro e he
      have hh := Finset.mem_filter.mp he
      exact support_incident_at c i e hh.1 hh.2
    exact (Finset.card_le_card hs).trans (Finset.card_insert_le _ _ |>.trans (by simp))
  · have he : (cycleSupport c).filter (fun e => v ∈ e) = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro e he
      have hh := Finset.mem_filter.mp he
      exact hv (cycle_support_vertex c e hh.1 v hh.2)
    simp [he]
#print axioms cycle_incident_card_le_two
end Frustrated
