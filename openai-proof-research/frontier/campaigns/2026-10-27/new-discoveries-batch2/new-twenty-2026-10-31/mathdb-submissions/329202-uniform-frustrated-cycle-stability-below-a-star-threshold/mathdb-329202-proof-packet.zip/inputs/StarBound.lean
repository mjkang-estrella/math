import ComplementLaw
namespace Frustrated
abbrev StarDirected (n s : Nat) :=
  {p : Fin n × Fin n // (star n s).edge p.1 p.2 = true}
noncomputable def starDirectedEncode {n s} (p : StarDirected n s) : Bool × Fin s := by
  have hp := p.property
  simp only [star,decide_eq_true_eq] at hp
  by_cases h : p.val.1.val = 0
  · have hh : 1 ≤ p.val.2.val ∧ p.val.2.val ≤ s := by rcases hp with hp | hp <;> omega
    exact (false,⟨p.val.2.val-1,by omega⟩)
  · have hh : p.val.2.val = 0 ∧ 1 ≤ p.val.1.val ∧ p.val.1.val ≤ s := by
      rcases hp with hp | hp <;> omega
    exact (true,⟨p.val.1.val-1,by omega⟩)

theorem starDirectedEncode_injective {n s} :
    Function.Injective (@starDirectedEncode n s) := by
  intro p q h
  have hp := p.property
  have hq := q.property
  simp only [star,decide_eq_true_eq] at hp hq
  have hb := congrArg Prod.fst h
  have hi := congrArg (fun z : Bool × Fin s => z.2.val) h
  unfold starDirectedEncode at hb hi
  split_ifs at hb hi with h1 h2 h2
  all_goals
    apply Subtype.ext
    apply Prod.ext <;> apply Fin.ext <;> dsimp at * <;> omega

theorem star_directed_card (n s) : Nat.card (StarDirected n s) ≤ 2*s := by
  have h := Nat.card_le_card_of_injective _ (@starDirectedEncode_injective n s)
  simpa [Nat.card_prod,Nat.card_eq_fintype_card] using h

abbrev RestPositions {k} (i j : Fin k) := {a : Fin k // a ≠ i ∧ a ≠ j}
theorem rest_positions_card {k} (i j : Fin k) (h : i ≠ j) :
    Nat.card (RestPositions i j) = k-2 := by
  classical
  let e : RestPositions i j ≃ {a : Fin k // ¬ (a=i ∨ a=j)} :=
    Equiv.subtypeEquivRight (fun a => by tauto)
  rw [Nat.card_congr e,Nat.card_eq_fintype_card,Fintype.card_subtype_compl]
  have he : Fintype.card {a : Fin k // a=i ∨ a=j} = 2 := by
    rw [Fintype.card_subtype]
    have hf : (Finset.univ.filter (fun a : Fin k => a=i ∨ a=j)) = {i,j} := by ext a; simp
    rw [hf]
    simp [h]
  rw [he,Fintype.card_fin]

abbrev EdgePositionStar {n k} (s) (i j : Fin k) :=
  {c : Ambient n k // (star n s).edge (c i) (c j) = true}
def starPositionEncode {n k s} (i j : Fin k) (c : EdgePositionStar (n := n) s i j) :
    StarDirected n s × (RestPositions i j → Fin n) :=
  (⟨(c.val i,c.val j),c.property⟩,fun a => c.val a.val)

theorem starPositionEncode_injective {n k s} (i j : Fin k) :
    Function.Injective (@starPositionEncode n k s i j) := by
  intro c d h
  apply Subtype.ext
  apply Function.Embedding.ext
  intro a
  by_cases hi : a=i
  · subst a
    exact congrArg (fun z : StarDirected n s × (RestPositions i j → Fin n) => z.1.val.1) h
  by_cases hj : a=j
  · subst a
    exact congrArg (fun z : StarDirected n s × (RestPositions i j → Fin n) => z.1.val.2) h
  exact congrArg (fun z : StarDirected n s × (RestPositions i j → Fin n) => z.2 ⟨a,hi,hj⟩) h

theorem star_position_card {n k s} (i j : Fin k) (h : i ≠ j) :
    Nat.card (EdgePositionStar (n := n) s i j) ≤ 2*s*n^(k-2) := by
  classical
  have he := Nat.card_le_card_of_injective _ (@starPositionEncode_injective n k s i j)
  rw [Nat.card_prod,Nat.card_fun,rest_positions_card i j h,Nat.card_fin] at he
  exact le_trans he (Nat.mul_le_mul_right _ (star_directed_card n s))
#print axioms star_directed_card
#print axioms star_position_card
end Frustrated
