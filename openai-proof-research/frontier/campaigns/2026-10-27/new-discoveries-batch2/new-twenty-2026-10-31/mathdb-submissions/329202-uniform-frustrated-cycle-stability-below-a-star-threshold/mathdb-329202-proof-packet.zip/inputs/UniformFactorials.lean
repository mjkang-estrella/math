import VertexCompletions
namespace Frustrated
/-- Uniform for every n above the displayed threshold, with no asymptotic oracle. -/
theorem falling_uniform_lower (a m n : Nat) (hn : 2*(a+m) ≤ n) :
    n^m ≤ 2^m * (n-a).descFactorial m := by
  induction m with
  | zero => simp
  | succ m ih =>
    have hi := ih (by omega : 2*(a+m) ≤ n)
    have hf : n ≤ 2*(n-a-m) := by omega
    calc
      n^(m+1) = n^m*n := by rw [pow_succ]
      _ ≤ (2^m*(n-a).descFactorial m)*(2*(n-a-m)) := Nat.mul_le_mul hi hf
      _ = 2^(m+1)*(n-a).descFactorial (m+1) := by
        rw [pow_succ,Nat.descFactorial_succ]
        ring

theorem falling_eventual_positive (a m n : Nat) (hn : a+m ≤ n) :
    0 < (n-a).descFactorial m := by
  rw [Nat.descFactorial_pos]
  omega

theorem vertex_completion_uniform_bound {n r m} (q : Ambient n r) :
    Nat.card (ContainsVertices (k:=r+m) q) ≤ (r+m)^r*n^m := by
  rw [vertex_completion_count]
  apply Nat.mul_le_mul (Nat.descFactorial_le_pow _ _)
  exact (Nat.descFactorial_le_pow _ _).trans (Nat.pow_le_pow_left (Nat.sub_le _ _) _)

theorem total_cycle_uniform_lower {n k} (hk : 3 ≤ k) (hn : 2*k ≤ n) :
    n^k ≤ (2^k*(2*k))*totalCycleCount n k := by
  have h := falling_uniform_lower 0 k n (by simpa using hn)
  have hc := total_cycle_scale (n:=n) hk
  rw [Nat.card_eq_fintype_card,Fintype.card_embedding_eq] at hc
  simp only [Fintype.card_fin] at hc
  simpa only [Nat.sub_zero,hc,Nat.mul_assoc] using h

theorem total_cycle_dominates_sparse {n k D} (hk : 3 ≤ k)
    (hn : 2*k ≤ n) (hD : (2^k*(2*k))*D < n^2) :
    D*n^(k-2) < totalCycleCount n k := by
  have hp : 0<n^(k-2) := Nat.pow_pos (by omega)
  have hmul := Nat.mul_lt_mul_of_pos_right hD hp
  have hexp : n^2*n^(k-2)=n^k := by
    rw [← pow_add]
    congr 1
    omega
  rw [hexp] at hmul
  have hlow := total_cycle_uniform_lower hk hn
  have hfac : 0 < 2^k*(2*k) := Nat.mul_pos (Nat.pow_pos (by omega)) (by omega)
  nlinarith
#print axioms vertex_completion_uniform_bound
#print axioms total_cycle_dominates_sparse
end Frustrated
