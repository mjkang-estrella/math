# Extraction and build v5

This is a recipe for a NEW independently authorized extraction/replay task; no independent replay was run here.

1. Use the literal LEAN-SOURCE-APPENDIX-v5.md. For each BEGIN marker, read the module name, byte length and SHA256; take exactly the UTF-8 contents inside the following lean fence, preserving its trailing newline. Require the matching END marker and verify both length and hash. Write only into a new review lane through its authorized writer.
2. Check PINS.json and frozen helper hashes against their ownership records. This session uses pinned Lean 4.34.1, specific imports, and the existing pinned mathlib plus eight upstream libraries. No installation or update is part of the recipe. Copy only authorized helper/PINS files. Documentary origin paths are not read grants.
3. Create fresh src/build/cache. Extract every module in THEOREM-DEPENDENCY-MAP-v5.json build_order. Use exactly `taskset -c 4,5 bash ./check32.sh MODULE UNIQUE_LABEL` for compilation, one required rebuild per local dependency, and `taskset -c 4,5 bash ./checker32.sh MODULE UNIQUE_LABEL` for separate kernel checks. Follow the reviewing task's own formal-call budget. Never reuse this task's exhausted/used labels or project oleans.
4. AuditV5 imports the literal endpoint, contains `example : Conjecture19 := conjecture19_proved`, and prints critical transitive axioms. Require only propext, Classical.choice, Quot.sound. No broad import Mathlib, sorry/admit/new axioms/unsafe/native_decide/oracles.
5. The exact commands ACTUALLY used here, including failures, are in FORMAL-COMMANDS-v5.txt; formal-usage-v5.json links every command to full stdout/receipt, source/olean hashes, times and guards. Those commands are evidence, not instructions to rerun within this session.

The inherited modules were rebuilt only as needed. Their earlier independent checks remain inherited; all fifteen newly authored production modules (including AuditV5) were freshly compiled and separately kernel checked. This is production validation, not independent extracted replay.
