import Invariant
import Mathlib.Logic.Relation
import Mathlib.Logic.Equiv.Basic
namespace Frustrated
abbrev OddTuple (n k) (G : Graph (Fin n)) := {c : Ambient n k // tupleOdd G c}
def oddRel {n k} (G : Graph (Fin n)) (c d : OddTuple n k G) := dihedralStep c.val d.val

theorem quotient_eq_step {n k} [NeZero k] (G : Graph (Fin n)) (c d : OddTuple n k G) :
    Quot.mk (oddRel (k := k) G) c = Quot.mk (oddRel (k := k) G) d ↔ dihedralStep c.val d.val := by
  constructor
  · intro h
    have hh : Relation.EqvGen (oddRel (k := k) G) c d := Quot.eqvGen_exact h
    clear h
    induction hh with
    | rel a b h => exact h
    | refl a => exact step_refl a.val
    | symm a b _ ih => exact step_symm ih
    | trans a b c _ _ h1 h2 => exact step_trans h1 h2
  · intro h
    exact Quot.sound (r := oddRel (k := k) G) h

def oddOrbitEquiv {n k} [NeZero k] (G : Graph (Fin n)) (c : OddTuple n k G) :
    {d : OddTuple n k G // dihedralStep c.val d.val} ≃
      {d : Ambient n k // dihedralStep c.val d} where
  toFun d := ⟨d.val.val,d.property⟩
  invFun d := ⟨⟨d.val, (tupleOdd_step G d.property).mp c.property⟩,d.property⟩
  left_inv _ := rfl
  right_inv _ := rfl

theorem quotient_fiber_card {n k} [NeZero k] (hk : 3 ≤ k)
    (G : Graph (Fin n)) (q : Quot (oddRel (k := k) G)) :
    Nat.card {c : OddTuple n k G // Quot.mk (oddRel (k := k) G) c = q} = 2*k := by
  induction q using Quot.inductionOn with | h c =>
    let e : {d : OddTuple n k G // Quot.mk (oddRel (k := k) G) d = Quot.mk (oddRel (k := k) G) c} ≃
        {d : OddTuple n k G // dihedralStep c.val d.val} :=
      Equiv.subtypeEquivRight (fun d => by
        rw [eq_comm, quotient_eq_step])
    rw [Nat.card_congr e, Nat.card_congr (oddOrbitEquiv G c)]
    exact ambient_orbit_card hk c.val

theorem tuple_cycle_scale {n k} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    tupleCount n k G = (2*k) * cycleCount n k G := by
  classical
  have : NeZero k := ⟨by omega⟩
  have ht : tupleCount n k G = Nat.card (OddTuple n k G) := by
    simp [tupleCount, OddTuple, tupleOdd, Nat.card_eq_fintype_card, Fintype.card_subtype]
  rw [ht]
  let : Fintype (Quot (oddRel (k := k) G)) := Fintype.ofFinite _
  rw [← Nat.card_congr (Equiv.sigmaFiberEquiv (Quot.mk (oddRel (k := k) G))), Nat.card_sigma]
  simp only [quotient_fiber_card hk G, Finset.sum_const, Finset.card_univ, Nat.nsmul_eq_mul]
  rw [mul_comm]
  change 2*k*Fintype.card (Quot (oddRel (k := k) G)) =
    2*k*Nat.card (Quot (oddRel (k := k) G))
  rw [Nat.card_eq_fintype_card]

theorem strict_scale_cancel {n k} (hk : 3 ≤ k) (G H : Graph (Fin n)) :
    tupleCount n k G < tupleCount n k H ↔ cycleCount n k G < cycleCount n k H := by
  rw [tuple_cycle_scale hk, tuple_cycle_scale hk]
  exact Nat.mul_lt_mul_left (by omega)

#print axioms quotient_eq_step
#print axioms tuple_cycle_scale
#print axioms strict_scale_cancel
end Frustrated
