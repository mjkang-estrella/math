import LowEvaluation
namespace Frustrated
attribute [local instance] Classical.propDecidable

theorem centered_higher_completion_zero {n k : Nat} (hk : 3 ≤ k)
    (F : Finset (Sym2 (Fin n))) (a : Fin n) (ha : ∀ e ∈ F, a ∈ e)
    (hcard : 3 ≤ F.card) : tupleCompletions (k:=k) F=0 := by
  classical
  have he : IsEmpty {c : Ambient n k // F ⊆ cycleSupport c} := by
    constructor
    rintro ⟨c,hc⟩
    let : NeZero k := ⟨by omega⟩
    have hs : F ⊆ (cycleSupport c).filter (fun e => a ∈ e) :=
      fun e he => Finset.mem_filter.mpr ⟨hc he,ha e he⟩
    have hh := (Finset.card_le_card hs).trans (cycle_incident_card_le_two c a)
    omega
  let := he
  exact Nat.card_of_isEmpty

theorem centered_remainder_zero {n k : Nat} (hk : 3 ≤ k)
    (E : Finset (Sym2 (Fin n))) (a : Fin n) (ha : ∀ e ∈ E, a ∈ e) :
    signedRemainder (k:=k) E=0 := by
  classical
  apply Finset.sum_eq_zero
  intro F hF
  obtain ⟨hsub,hbad⟩ := Finset.mem_filter.mp hF
  have hs := Finset.mem_powerset.mp hsub
  rcases hbad with hc | ⟨e,he,f,hf,hd⟩
  · simp only [centered_higher_completion_zero hk F a (fun e he => ha e (hs he)) hc,Nat.cast_zero,mul_zero]
  · exact (hd ⟨a,ha e (hs he),ha f (hs hf)⟩).elim

theorem centered_adjacent_card {n} (E : Finset (Sym2 (Fin n)))
    (a : Fin n) (ha : ∀ e ∈ E, a ∈ e) :
    (adjacentSupports E).card = E.card.choose 2 := by
  classical
  have hs : adjacentSupports E = E.powersetCard 2 := by
    ext F
    simp only [adjacentSupports,Finset.mem_filter,Finset.mem_powerset,Finset.mem_powersetCard]
    constructor
    · rintro ⟨hsub,hcard,hm⟩
      exact ⟨hsub,hcard⟩
    · rintro ⟨hsub,hcard⟩
      exact ⟨hsub,hcard,fun e he f hf => ⟨a,ha e (hsub he),ha f (hsub hf)⟩⟩
  rw [hs,Finset.card_powersetCard]

theorem relabelled_star_formula {n m} (G : Graph (Fin n))
    (a : Fin n) (ha : ∀ e ∈ graphEdges G, a ∈ e) :
    (cycleCount n (3+m) G : Int) =
      ((graphEdges G).card : Int)*(n-2).descFactorial (1+m) -
        2*((graphEdges G).card.choose 2 : Int)*(n-3).descFactorial m := by
  have h := exact_low_remainder_expansion (k:=3+m) (by omega) G
  rw [centered_remainder_zero (by omega) (graphEdges G) a ha,add_zero,
    low_support_evaluation,centered_adjacent_card (graphEdges G) a ha] at h
  push_cast at h ⊢
  have hp : (2*(3+(m:Int))) ≠ 0 := by omega
  apply mul_left_cancel₀ hp
  rw [h]
  ring
#print axioms centered_higher_completion_zero
#print axioms centered_remainder_zero
#print axioms relabelled_star_formula
end Frustrated
