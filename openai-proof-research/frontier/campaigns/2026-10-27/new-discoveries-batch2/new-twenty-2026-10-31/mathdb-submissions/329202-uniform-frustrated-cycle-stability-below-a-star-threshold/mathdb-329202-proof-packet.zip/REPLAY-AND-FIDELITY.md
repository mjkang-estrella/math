# Independent replay and fidelity review v1 — MathDB329202

Review date:2026-11-15UTC. Scientific/source replay disposition: PASS within the explicit coverage below. Process: FAIL/UNWAIVED defects; no clean-history or independent acceptance claim. Credit0; no count/ledger action. The unchanged production paper and literal appendix are retained. No repair version was needed.

## Separate verdicts

|Gate|Verdict and evidence|
|---|---|
|Primary|PASS: owned Frustrated Triangles, Teeradej Kittipassorn/Gábor Mészáros, arXiv1411.1749v2,8April2015; actual definition and Conjecture19,p18 read and rendered/visually inspected. Internal February date is not the arXiv revision date.|
|Raw target/source binding|PASS: complete owned329202 record read, matching literal conjecture; solutions=[] is documentary status, not novelty evidence.|
|Model|PASS for the inspected actual definitions and load-bearing chain: arbitrary loopless symmetric Boolean graph, ambient injective cycles modulo rotation/reversal, full complement, genuine unordered edit distance, uniform threshold.|
|Paper|PASS: complete PAPER-v5 read; agrees with actual model/endpoint and inspected proof chain. False odd-n aside excluded entirely. No paper/source repair.|
|Parser|PASS: independently authored independent_parser.py,60 safe allowlisted modules, exact root/index/owned-copy/producer-map byte binding, exact preamble/fences/paired markers/EOF, duplicate/missing/unknown/unsafe rejection and9negative controls.|
|Compiles|PASS: all60 production modules freshly compiled in independently validated topological order; no producer project artifacts.|
|Kernel checks|PASS: all60 separately checked, plus independently authored expanded endpoint audit compiled and separately checked.|
|Axioms|PASS: all372 named local declarations plus own endpoint queried;335 dependent lists and38 axiom-free results. Exact allowed-name matching after careful terminal universe-suffix normalization; only propext,Classical.choice,Quot.sound.|
|Scope|PASS for additional104/105 literal released scopes; old103distinctness/dated373comparison and earlier ordinary/SUBSTANTIAL/source qualification remain separate paid bounded gates, unchanged and not claimed freshly personally read in full. No worldwide absence claim.|
|Process|FAIL/UNWAIVED: see PROCESS-INVENTORY-v1.md and unchanged inherited inventories. Successful replay is not process absolution or acceptance.|

## Investigation: literal semantics and hostile review

For each fixed k>=3,t>=0, ONE N(k,t)>=t+2 is chosen before n and G. For every n>=N and arbitrary simple G, the strict star threshold implies distance<=t from a complete bipartite graph for G OR its WHOLE complement. Fin n is a labelling of every n-vertex simple graph: the Graph structure has only arbitrary edge bits, symmetry and false diagonal; it imposes no density, support or expansion premise. cut U is xor of endpoint bits; constant U includes empty cut parts. star n s has precisely the center0 and leaves1..s when n>=s+1. editDistance filters p.1<p.2, hence one count per unordered toggled pair.

Ambient=Fin k↪Fin n excludes repeated vertices. tupleOdd counts odd consecutive G-pairs even when other consecutive pairs are nonedges: these are neither contained/induced cycles nor walks. dihedralStep is exactly a rotation or reversed rotation; its equivalence closure has no extra identifications because step_refl/symm/trans hold. Invariant transports parity, Orbit gives the free2k orbit for k>=3, and Counting's actual quotient-fiber proof yields tupleCount=2k*cycleCount. At k=3 each3-set has exactly six injective orders, one quotient cycle, and all three unordered pairs are consecutive, so the definition agrees with the primary frustrated-triple count for every n, including n<3 where both sets are empty. No unused new k3/k4 presentation theorem is necessary for that definitional interpretation.

The actual path-witness inequality has8*f4*(n-4)falling(k-3)<=4kn*fk; at k=3 the internal path is empty, not a missing case. ThresholdTransfer combines this with the actual star upper bound to give f4<=D*n² with D=k(t+1)2^(k-3). Normalization derives directed row discrepancy<=16D; row preference rigidity is derived, never assumed in the endpoint. WholeNormalization lifts errors after the deleted-vertex step and explicitly switches the whole complement at the isolated singleton, eliminating potential n-1 hidden incident errors. The actual graphEdges cardinality equals edgeCount via the checked unordered-pair bijection. EdgeBounds then identifies the sparse switch with the actual edit distance to a cut.

SubsetExpansion was read in full: the doubled odd-indicator gives4k scaling. SignedExpansion's full proof removes the empty support and divides by2 to obtain2k scaling and partitions ALL nonempty supports into low and bad supports with actual coefficient(-2)^(|F|-1). Singletons contribute2k*m*(n-2)falling(k-2); adjacent pairs contribute-2*(2k)*A*(n-3)falling(k-3). Disjoint pairs and every larger support remain in the signed remainder, with no truncation or presumed sign. HigherSupport's full proof uses the loopless intersecting-family classification and cycle degree<=2/triangle exclusion to produce four distinct incident vertices for any completable bad support. FullRemainder bounds both support multiplicity and coefficient by2^M and proves the absolute signed bound2^(2M)k^4*n^(k-4). M=16D is derived uniformly, not inserted as an extra endpoint hypothesis.

For k=3, the full ThreeCorrection proof retains exactly +4 times the NONNEGATIVE ACTUAL triple-completion sum at tuple scale; it does not posit an unused triangle-count bridge. At ordinary cycle scale a completed triangle has six representatives, giving the familiar +4triangle correction. Star supports have zero higher correction. For k>=4 the star/triangle intersecting cases have zero remainder, while a missing adjacent pair yields a gap dominating the full remainder. SparseMinimum and SharpThreshold were read in full; their graph-independent factorial bounds and actual star successor monotonicity force m<=t under strict inequality, including t=0.

ComplementLaw's actual statements and final proofs distinguish even-k preservation from odd-k total-minus-count. For odd k the uniform total-cycle lower bound excludes the dense complement branch eventually. For even k the whole complement retains the threshold. EndpointV5's complete proof tracks both switches, commutes complement and switch, chooses Ns and No before n,G, and sets N=t+2+Ns+No+2(k+1)+M+5. Thus no bounded-support, opaque expansion, or graph-dependent threshold hypothesis hides in the conclusion. No mathematical/model gap was found in this reviewed chain.

IndependentAudit.lean independently states the endpoint using explicit Nat.card/Quot subtypes and the unordered-pair filter rather than Conjecture19/NearCut wrappers; its proof is definitionally the production endpoint. Its authored source explicitly retains G versus star in the two subtypes. Lean's default pretty printer suppresses those subtype annotations in the displayed type, so that display alone is not treated as evidence of their contents; the complete independently authored type, printed Graph/tupleOdd/dihedralStep/star/complement definitions, and kernel check supply that binding. No additional assumption is present.

## Replay, hashes, commands and resources

independent_parser.py was authored from scratch; no producer extractor/package/reproducer ran. Negative controls, in separate in-memory buffers: body alteration, forged hash header, unsafe name, unknown name, mismatched end marker, missing modules, duplicate module, bad fence, trailing bytes. All rejected; production source bytes unchanged. Safe Mathlib submodule imports are specific, never import Mathlib; every local import is in the earlier independently parsed closure and exactly matches the producer map. Comment-aware nested-comment/string lexical scan rejects actual sorry/admit/axiom/unsafe/native_decide/oracle-like foreign declarations, with the sole source #eval being Lean.versionString. Axiom audit independently checks transitive trust.

source-index.json records the60 names, hashes, sizes, imports and build order; review-input-hashes.json binds root expected index, producer map, primary/raw, paper and appendix. pin-verification.json verifies binary hashes and all available pinned mathlib metadata. PINS.json records Lean4.34.1 and mathlibd13f23b723b8a846827a245b89c10fc7d3f11612. Upstream standard Lean/mathlib+8libraries are accepted pinned trusted inputs; no upstream truth/provenance rebuild was attempted. No scientific project cache fallback exists in effective LEAN_PATH, verified on EVERY receipt.

Exact122 command strings, stage JSON and full resource receipts are in formal-usage-independent.json. Production topological order is source-index.json order. Each module uses exactly `taskset -c 4,5 bash ./check32.sh MODULE UNIQUE_LABEL`, immediately followed by `taskset -c 4,5 bash ./checker32.sh MODULE UNIQUE_LABEL`; labels fresh001..fresh120. Own IndependentAudit uses fresh121/fresh122. Each underlying helper's complete stdout/stderr/command/environment is retained in freshNNN.output.txt/.receipt.json; actual exits, not display-filter exits, are zero. Every compile started without its module olean, emitted an actual artifact, and its checker preserved the artifact hash. All source hashes are stable before/after and still match the root/index/copies. Generated producer olean byte identity was unnecessary and not used.

Compile/check limits:32GiB AS, sampled group RSS6GiB,115CPU/130wall,CPUs4,5,j1,M3500,warningsAsErrors,oneLeanthread. Documentary work uses unchanged own run.py's6GiB envelope. Formal usage: {"axiom_lists": 335, "cpu_s": 143.37159599999998, "effective_lean_path_verified_every_call": true, "formal_calls": 122, "formal_failures": 0, "observed_axioms": ["Classical.choice", "Quot.sound", "propext"], "own_audit_compile": 1, "own_audit_kernel_check": 1, "peak_sampled_group_rss_bytes": 1945780224, "production_compiles": 60, "production_kernel_checks": 60, "source_stability": true, "wall_s": 145.23626201227307}. No formal failure, extra replay loop, scientific experiment or network/search operation. The failed supplementary documentary index is preserved and accounted separately; inherited failures are not reset.

## Read coverage and scope comparison

read-coverage-v1.json gives actual personally read file/ranges, header-only versus complete proofs, and machine-only coverage. Full primary/Lean/mathlib proof-body reading is NOT claimed. Complete reviewed mathematical source bodies: Pilot,EndpointV5 and11critical packet modules; selected actual definitions and additional exact bridges as enumerated there. Other local theorem statements were inspected through the header index plus repaired full-header supplement; their implementation proofs were freshly compiled/kernel checked. Imported trusted mathlib proof bodies were not human-audited. Original ordinary proof/source/SUBSTANTIAL and103/dated373qualification remain inherited paid gates, not a fresh literature review.

The additional accepted104(MathDB382130) refutes a characteristic-imset sink-edge conjecture with an actual5-vertex orientation/polytope counterexample and26subset coordinates. Accepted105(MathDB367654) refutes a broad pure-flag nonunimodality conjecture using an explicit540000-vertex pure flag complex; its original isolate-free graph conjecture remains unrefuted. Neither released literal scope supplies a uniform ambient-cycle parity stability theorem, its strict star threshold, nor its arbitrary-graph switching/whole-complement edit conclusion. These are not parameter variants of329202. Both exact released endpoint fields were read. The old103comparison files are unchanged, with their original bounded claims and process defects. No original protected proof/plan/code bodies, raw101corpus or closed registry were reopened.

## SELF-review and HANDOFF

Adversarial risks checked: orientation2k versus expansion4k; injectivity and small-n/k3 conventions; strict inequality and star existence; directed versus unordered error counting; deletion versus whole complement and singleton repair; signed remainder and all higher supports; nonnegative actual k3correction; derived uniform M and thresholds; N independent of n,G; no extra endpoint assumptions; exact trusted axioms; fresh artifacts and real checker exits. No source/definition/proof repair was performed. Producer local completion was never treated as independent PASS.

Root receives scientific replay/fidelity PASS with explicit human/kernel coverage, not acceptance or clean process. All deviations remain UNWAIVED. Retain unchanged primary,paper,appendix,index and all failures. Root must adjudicate process defects and any remaining independent acceptance requirements; this reviewer performs no acceptance/count action. All reports precede frozen-after and exhaustive physical seal. Their actual terminal outcomes are in frozen-after.json and SEAL-v1.json plus generating receipts; no postseal work is authorized.

## Exact input hashes

```json
{
  "inputs/PAPER-v5.md": "0e59e405d379b2c7e1a82f1ffc49a3f26528a471fa58938c4249936297b7d4ef",
  "inputs/LEAN-SOURCE-APPENDIX-v5.md": "40ce8adcfcb4d2397764ca81173656345f2b7a470948dc6a6105aa1f6b6f1691",
  "inputs/EXPECTED-SOURCES.json": "038f04d19673ddd4658bf6db76b4ca5541c855f4dfa8c4c38350dce2971ac561",
  "inputs/THEOREM-DEPENDENCY-MAP-v5.json": "fcbf3c3618161f51a9b11e85a88631049bf862937ad199631db08915001894ee",
  "inputs/cycle-source-v2.pdf": "79a754bb8827bbb63a00ae99b06b20d0b60950517c00d1ecfbbc546648aaa17a",
  "inputs/mathdb-329202.raw.jsonl": "b4fd0448ae1df5d18197af584267624c0f16a5de81cb2ba93f03a523fc9bae40"
}
```

Documentary precision correction before seal: read-coverage-v1.json distinguishes Unicode characters from physical source bytes; initial documentary versions retained in versions/. All60mathematical source byte hashes remain identical.
