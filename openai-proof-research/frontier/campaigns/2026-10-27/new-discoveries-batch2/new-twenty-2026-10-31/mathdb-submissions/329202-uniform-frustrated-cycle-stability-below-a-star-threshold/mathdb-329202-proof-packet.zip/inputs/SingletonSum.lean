import StarExpansion
namespace Frustrated
/-- Evaluated singleton portion of the literal ordered-tuple source expansion. -/
theorem singleton_completion_sum {n k} (hk : 3≤k) (G : Graph (Fin n)) :
    (∑ e ∈ graphEdges G, tupleCompletions (k:=k) {e}) =
      (graphEdges G).card*(2*k*(n-2).descFactorial (k-2)) := by
  classical
  have h (e : Sym2 (Fin n)) (he : e∈graphEdges G) :
      tupleCompletions (k:=k) {e}=2*k*(n-2).descFactorial (k-2) := by
    unfold tupleCompletions
    simp_rw [Finset.singleton_subset_iff]
    exact graph_edge_completion_count hk G e he
  calc
    _ = ∑ _e ∈ graphEdges G, 2*k*(n-2).descFactorial (k-2) := Finset.sum_congr rfl h
    _ = _ := by simp
#print axioms singleton_completion_sum
end Frustrated
