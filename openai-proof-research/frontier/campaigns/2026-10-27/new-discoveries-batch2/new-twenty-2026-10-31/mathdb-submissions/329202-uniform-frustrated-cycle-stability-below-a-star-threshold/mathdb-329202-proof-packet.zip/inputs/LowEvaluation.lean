import AdjacentSum
namespace Frustrated
attribute [local instance] Classical.propDecidable

theorem edge_meets_self {V : Type} (e : Sym2 V) : EdgeMeets e e := by
  induction e using Sym2.inductionOn with
  | _ a b => exact ⟨a,by simp,by simp⟩

theorem low_support_partition {n} (E : Finset (Sym2 (Fin n))) :
    lowSupports E = E.image (fun e => {e}) ∪ adjacentSupports E := by
  classical
  ext F
  constructor
  · intro h
    obtain ⟨hsub,hne,hcard,hm⟩ := Finset.mem_filter.mp h
    have hp := Finset.card_pos.mpr hne
    by_cases h1 : F.card=1
    · obtain ⟨e,rfl⟩ := Finset.card_eq_one.mp h1
      apply Finset.mem_union_left
      exact Finset.mem_image.mpr ⟨e,(Finset.mem_powerset.mp hsub) (by simp),rfl⟩
    · apply Finset.mem_union_right
      exact Finset.mem_filter.mpr ⟨hsub,by omega,hm⟩
  · intro h
    rcases Finset.mem_union.mp h with hs | ha
    · obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hs
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_powerset.mpr (by simpa using he),by simp,by simp,?_⟩
      intro f hf g hg
      have hf' : f=e := by simpa using hf
      have hg' : g=e := by simpa using hg
      subst f; subst g
      exact edge_meets_self e
    · obtain ⟨hsub,hcard,hm⟩ := Finset.mem_filter.mp ha
      exact Finset.mem_filter.mpr ⟨hsub,Finset.card_pos.mp (by omega),by omega,hm⟩

theorem low_support_evaluation {n m} (G : Graph (Fin n)) :
    (∑ F ∈ lowSupports (graphEdges G), supportWeight (k:=3+m) F) =
      (((graphEdges G).card * (2*(3+m)*(n-2).descFactorial (1+m)) : Nat) : Int) -
        2*(((adjacentSupports (graphEdges G)).card * (2*(3+m)*(n-3).descFactorial m) : Nat) : Int) := by
  classical
  let E := graphEdges G
  have hd : Disjoint (E.image (fun e => {e})) (adjacentSupports E) := by
    apply Finset.disjoint_left.mpr
    intro F hs ha
    obtain ⟨e,he,rfl⟩ := Finset.mem_image.mp hs
    have hh := (Finset.mem_filter.mp ha).2.1
    simp at hh
  rw [low_support_partition,Finset.sum_union hd]
  have hs : (∑ F ∈ E.image (fun e => {e}), supportWeight (k:=3+m) F) =
      ((∑ e ∈ E, tupleCompletions (k:=3+m) {e} : Nat) : Int) := by
    rw [Finset.sum_image]
    · simp [supportWeight,Nat.cast_sum]
    · intro e he f hf h
      simpa using h
  have ha : (∑ F ∈ adjacentSupports E, supportWeight (k:=3+m) F) =
      -2*((∑ F ∈ adjacentSupports E, tupleCompletions (k:=3+m) F : Nat) : Int) := by
    rw [Nat.cast_sum,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro F hF
    have hc := (Finset.mem_filter.mp hF).2.1
    simp [supportWeight,hc]
  change (∑ F ∈ E.image (fun e => {e}), supportWeight (k:=3+m) F) +
    (∑ F ∈ adjacentSupports E, supportWeight (k:=3+m) F) = _
  rw [hs,ha]
  have hsingle := singleton_completion_sum (k:=3+m) (by omega) G
  have hadj := adjacent_completion_sum (m:=m) G
  change (∑ e ∈ E, tupleCompletions (k:=3+m) {e}) = _ at hsingle
  rw [hsingle,hadj]
  have hm : 3+m-2=1+m := by omega
  rw [hm]
  ring
#print axioms low_support_evaluation
end Frustrated
