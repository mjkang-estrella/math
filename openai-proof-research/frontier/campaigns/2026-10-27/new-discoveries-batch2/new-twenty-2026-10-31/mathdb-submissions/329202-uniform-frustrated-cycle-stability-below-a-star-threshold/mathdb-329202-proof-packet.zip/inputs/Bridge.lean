import Pilot
import Mathlib.Data.List.FinRange
import Mathlib.Data.List.Rotate
namespace Frustrated

def ListCycle.toTuple {n k} (C : ListCycle (Fin n) k) : Ambient n k where
  toFun i := C.vertices.get (Fin.cast C.length_eq.symm i)
  inj' := by
    intro i j h
    have hh := (List.nodup_iff_injective_get.mp C.distinct) h
    apply Fin.ext
    simpa using congrArg (fun x : Fin C.vertices.length => x.val) hh

def tupleToList {n k} (c : Ambient n k) : ListCycle (Fin n) k where
  vertices := List.ofFn c
  length_eq := List.length_ofFn
  distinct := List.nodup_ofFn_ofInjective c.injective

theorem ListCycle.toTuple_toList {n k} (C : ListCycle (Fin n) k) :
    tupleToList C.toTuple = C := by
  cases C with | mk l h hd =>
    subst k
    simp [tupleToList, ListCycle.toTuple]

theorem tupleToList_toTuple {n k} (c : Ambient n k) :
    (tupleToList c).toTuple = c := by
  apply Function.Embedding.ext
  intro i
  change (List.ofFn c)[i.val]'(by simp) = c i
  simp only [List.getElem_ofFn]


def listTupleEquiv (n k : Nat) : ListCycle (Fin n) k ≃ Ambient n k where
  toFun := ListCycle.toTuple
  invFun := tupleToList
  left_inv := ListCycle.toTuple_toList
  right_inv := tupleToList_toTuple

theorem cycle_blocks {V} (G : Graph V) (a b : V) (p q : List V) :
    cycleParity G ((a :: p) ++ (b :: q)) =
      xor (pathParity G a (p ++ [b])) (pathParity G b (q ++ [a])) := by
  simp only [List.cons_append, cycleParity, List.append_assoc]
  exact path_append G a p b (q ++ [a])

theorem cycle_blocks_rotate {V} (G : Graph V) (a b : V) (p q : List V) :
    cycleParity G ((a :: p) ++ (b :: q)) =
      cycleParity G ((b :: q) ++ (a :: p)) := by
  rw [cycle_blocks, cycle_blocks]
  cases pathParity G a (p ++ [b]) <;> cases pathParity G b (q ++ [a]) <;> rfl

theorem path_reverse {V} (G : Graph V) (a b : V) (p : List V) :
    pathParity G a (p ++ [b]) = pathParity G b (p.reverse ++ [a]) := by
  induction p generalizing a b with
  | nil => simp [pathParity, G.symm]
  | cons c p ih =>
    simp only [List.cons_append, pathParity, List.reverse_cons, List.append_assoc, List.nil_append]
    rw [path_append G b p.reverse c [a], ← ih c b]
    simp only [pathParity]
    rw [G.symm c a]
    cases G.edge a c <;> cases pathParity G c (p ++ [b]) <;> rfl

theorem cycle_rotate_cons {V} (G : Graph V) (a : V) (p : List V) :
    cycleParity G (p ++ [a]) = cycleParity G (a :: p) := by
  cases p with
  | nil => rfl
  | cons b q => simpa using cycle_blocks_rotate G b a q []

theorem cycle_reverse {V} (G : Graph V) (l : List V) :
    cycleParity G l.reverse = cycleParity G l := by
  cases l with
  | nil => rfl
  | cons a p =>
    rw [List.reverse_cons, cycle_rotate_cons]
    exact (path_reverse G a a p).symm

theorem cycle_rotate {V} (G : Graph V) (l : List V) (r : Nat) :
    cycleParity G (l.rotate r) = cycleParity G l := by
  induction r generalizing l with
  | zero => simp
  | succ r ih =>
    cases l with
    | nil => simp
    | cons a p =>
      rw [List.rotate_cons_succ, ih, cycle_rotate_cons]

@[simp] theorem ListCycle.toTuple_get {n k} (C : ListCycle (Fin n) k) (i : Fin k) :
    C.toTuple i = C.vertices[i.val]'(by rw [C.length_eq]; exact i.isLt) := rfl

/-- The indexed edge uses precisely the successor of the original list, including wrap. -/
theorem ListCycle.successor_edge {n k} (G : Graph (Fin n))
    (C : ListCycle (Fin n) k) (i : Fin k) :
    G.edge (C.toTuple i)
      (C.toTuple ⟨(i.val + 1) % k, Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩) =
    G.edge (C.vertices.get (Fin.cast C.length_eq.symm i))
      (C.vertices.get (Fin.cast C.length_eq.symm
        ⟨(i.val + 1) % k, Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩)) := rfl

#print axioms listTupleEquiv
#print axioms cycle_blocks_rotate
#print axioms path_reverse
#print axioms cycle_reverse
#print axioms cycle_rotate_cons
#print axioms cycle_rotate
#print axioms ListCycle.successor_edge
end Frustrated
