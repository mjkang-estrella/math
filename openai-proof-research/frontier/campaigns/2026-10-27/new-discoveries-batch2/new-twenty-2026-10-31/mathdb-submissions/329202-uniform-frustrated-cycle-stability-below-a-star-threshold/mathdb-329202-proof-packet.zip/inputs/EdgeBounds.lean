import SwitchLaws
namespace Frustrated
abbrev EdgePair {n} (G : Graph (Fin n)) :=
  {p : Fin n × Fin n // p.1 < p.2 ∧ G.edge p.1 p.2 = true}
noncomputable def edgeCount {n} (G : Graph (Fin n)) := Nat.card (EdgePair G)
theorem edgeCount_eq_editDistance {n} (G : Graph (Fin n)) :
    edgeCount G = editDistance n G (cut (fun _ => false)) := by
  classical
  simp only [edgeCount,editDistance,Nat.card_eq_fintype_card,Fintype.card_subtype]
  congr 1
  apply Finset.filter_congr
  intro p _
  simp [cut]

theorem sparse_from_false_rows {n} (G : Graph (Fin n)) (U : Fin n → Bool)
    (h : ∀ w, U w = false) : edgeCount G ≤ Nat.card (DirectedError G U) := by
  let f : EdgePair G → DirectedError G U :=
    fun p => ⟨p.val,ne_of_lt p.property.1,by rw [h,p.property.2]; decide⟩
  exact Nat.card_le_card_of_injective f (fun _ _ he => Subtype.ext (congrArg (fun z : DirectedError G U => z.val) he))

theorem sparse_from_true_rows {n} (G : Graph (Fin n)) (U : Fin n → Bool)
    (h : ∀ w, U w = true) : edgeCount (complement G) ≤ Nat.card (DirectedError G U) := by
  have he (p : EdgePair (complement G)) : G.edge p.val.1 p.val.2 = false := by
    have hp := p.property.2
    have hn := ne_of_lt p.property.1
    simp only [complement,hn,ite_false] at hp
    cases hv : G.edge p.val.1 p.val.2 <;> simp_all
  let f : EdgePair (complement G) → DirectedError G U :=
    fun p => ⟨p.val,ne_of_lt p.property.1,by rw [h,he p]; decide⟩
  exact Nat.card_le_card_of_injective f (fun _ _ hh => Subtype.ext (congrArg (fun z : DirectedError G U => z.val) hh))

theorem editDistance_switch_cut {n} (G : Graph (Fin n)) (U : Fin n → Bool) :
    editDistance n (switch G U) (cut U) = edgeCount G := by
  classical
  rw [edgeCount_eq_editDistance]
  unfold editDistance
  congr 1
  apply Finset.filter_congr
  intro p _
  simp only [switch,cut]
  cases G.edge p.1 p.2 <;> cases U p.1 <;> cases U p.2 <;> simp

theorem nearCut_of_sparse_switch {n t} (G : Graph (Fin n)) (U : Fin n → Bool)
    (h : edgeCount G ≤ t) : NearCut n t (switch G U) :=
  ⟨U,by rw [editDistance_switch_cut]; exact h⟩

theorem switch_involutive {V} (G : Graph V) (U : V → Bool) :
    switch (switch G U) U = G := by
  have he : (switch (switch G U) U).edge = G.edge := by
    funext a b
    simp only [switch,cut]
    cases G.edge a b <;> cases U a <;> cases U b <;> rfl
  generalize hh : switch (switch G U) U = H at he ⊢
  cases G
  cases H
  cases he
  rfl

theorem nearCut_of_switch_sparse {n t} (G : Graph (Fin n)) (U : Fin n → Bool)
    (h : edgeCount (switch G U) ≤ t) : NearCut n t G := by
  have hh := nearCut_of_sparse_switch (switch G U) U h
  rwa [switch_involutive] at hh
#print axioms nearCut_of_switch_sparse
#print axioms sparse_from_false_rows
#print axioms sparse_from_true_rows
end Frustrated
