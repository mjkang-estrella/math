import Mathlib.SetTheory.Cardinal.Finite
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Quotient
import Mathlib.Data.Finset.Card
import Mathlib.Data.List.Nodup

namespace Frustrated

structure Graph (V : Type) where
  edge : V → V → Bool
  symm : ∀ a b, edge a b = edge b a
  loopless : ∀ a, edge a a = false

def complement {V} [DecidableEq V] (G : Graph V) : Graph V where
  edge a b := if a = b then false else !(G.edge a b)
  symm a b := by
    by_cases h : a = b
    · subst b; simp
    · have h' : b ≠ a := Ne.symm h
      simp [h, h', G.symm]
  loopless a := by simp

def cut {V} (U : V → Bool) : Graph V where
  edge a b := xor (U a) (U b)
  symm a b := by cases U a <;> cases U b <;> rfl
  loopless a := by cases U a <;> rfl

def switch {V} (G : Graph V) (U : V → Bool) : Graph V where
  edge a b := xor (G.edge a b) ((cut U).edge a b)
  symm a b := by rw [G.symm, (cut U).symm]
  loopless a := by simp [G.loopless, (cut U).loopless]

/-- A single edit toggles one unordered pair, separately from switching. -/
def edit {V} [DecidableEq V] (G : Graph V) (u v : V) : Graph V where
  edge a b := xor (G.edge a b) (decide (u ≠ v ∧ ((a = u ∧ b = v) ∨ (a = v ∧ b = u))))
  symm a b := by
    have h : (u ≠ v ∧ ((a = u ∧ b = v) ∨ (a = v ∧ b = u))) ↔
      (u ≠ v ∧ ((b = u ∧ a = v) ∨ (b = v ∧ a = u))) := by tauto
    simp only [h, G.symm a b]
  loopless a := by
    have h : ¬(u ≠ v ∧ ((a = u ∧ a = v) ∨ (a = v ∧ a = u))) := by
      rintro ⟨hne, hh⟩
      rcases hh with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ <;> exact hne rfl
    simp [h, G.loopless]

def star (n s : Nat) : Graph (Fin n) where
  edge a b := decide ((a.val = 0 ∧ 1 ≤ b.val ∧ b.val ≤ s) ∨
    (b.val = 0 ∧ 1 ≤ a.val ∧ a.val ≤ s))
  symm a b := by simp only [or_comm]
  loopless a := by simp; omega

def editDistance (n : Nat) (G H : Graph (Fin n)) : Nat :=
  ((Finset.univ : Finset (Fin n × Fin n)).filter
    (fun p => p.1 < p.2 ∧ G.edge p.1 p.2 ≠ H.edge p.1 p.2)).card

def NearCut (n t : Nat) (G : Graph (Fin n)) : Prop :=
  ∃ U : Fin n → Bool, editDistance n G (cut U) ≤ t

/-- Rooted, oriented ambient cycles: injectivity excludes repeated vertices. -/
abbrev Ambient (n k : Nat) := Fin k ↪ Fin n

noncomputable def tupleCount (n k : Nat) (G : Graph (Fin n)) : Nat := by
  classical
  exact ((Finset.univ : Finset (Ambient n k)).filter (fun c =>
    ((Finset.univ.filter (fun i : Fin k => G.edge (c i)
      (c ⟨(i.val + 1) % k, Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩))).card % 2 = 1))).card

def tupleOdd {n k} (G : Graph (Fin n)) (c : Ambient n k) : Prop :=
  ((Finset.univ.filter (fun i : Fin k => G.edge (c i)
    (c ⟨(i.val + 1) % k, Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩))).card % 2 = 1)

/-- One rotation or reversed rotation. Quot takes the equivalence closure. -/
def dihedralStep {n k} (c d : Ambient n k) : Prop :=
  ∃ r : Fin k,
    (∀ i j : Fin k, j.val = (i.val + r.val) % k → d i = c j) ∨
    (∀ i j : Fin k, j.val = (r.val + k - i.val) % k → d i = c j)

/-- Unoriented frustrated ambient cycles, modulo rotation and reversal.
The uniform 2*k fiber theorem is NOT yet proved. -/
noncomputable def cycleCount (n k : Nat) (G : Graph (Fin n)) : Nat :=
  Nat.card (Quot (fun c d : {c : Ambient n k // tupleOdd G c} =>
    dihedralStep c.val d.val))

/-- Literal target interface, not a theorem. Empty cut parts are allowed. -/
def Conjecture19 : Prop :=
  ∀ k : Nat, 3 ≤ k → ∀ t : Nat, ∃ N : Nat, t + 2 ≤ N ∧
    ∀ n : Nat, N ≤ n → ∀ G : Graph (Fin n),
      cycleCount n k G < cycleCount n k (star n (t+1)) →
      NearCut n t G ∨ NearCut n t (complement G)

/-- Following a list of vertices; all pairs are ambient, not graph-walk edges. -/
def pathParity {V} (G : Graph V) : V → List V → Bool
  | _, [] => false
  | a, b :: l => xor (G.edge a b) (pathParity G b l)

def cycleParity {V} (G : Graph V) : List V → Bool
  | [] => false
  | a :: l => pathParity G a (l ++ [a])

structure ListCycle (V : Type) (k : Nat) where
  vertices : List V
  length_eq : vertices.length = k
  distinct : vertices.Nodup

/-- No claimed scaling bridge from this list representation to tupleCount. -/
def frustrated {V k} (G : Graph V) (C : ListCycle V k) : Prop :=
  cycleParity G C.vertices = true

/-- Exact witness hypotheses: a,b,c,d and the internal path vertices are distinct. -/
structure Witness (V : Type) where
  a : V
  b : V
  c : V
  d : V
  internal : List V
  distinct : (a :: internal ++ [c,b,d]).Nodup

def Witness.first {V} (w : Witness V) := w.a :: w.internal ++ [w.c,w.b]
def Witness.second {V} (w : Witness V) := w.a :: w.internal ++ [w.c,w.d]

theorem path_append {V} (G : Graph V) (a : V) (p : List V) (c : V) (q : List V) :
    pathParity G a (p ++ c :: q) =
      xor (pathParity G a (p ++ [c])) (pathParity G c q) := by
  induction p generalizing a with
  | nil => simp [pathParity]
  | cons b p ih =>
    simp only [List.cons_append, pathParity, ih]
    cases G.edge a b <;> cases pathParity G b (p ++ [c]) <;>
      cases pathParity G c q <;> rfl

/-- Common-path cancellation for the actual two cyclic orderings in proof step 1. -/
theorem witness_parity {V} (G : Graph V) (w : Witness V) :
    xor (cycleParity G w.first) (cycleParity G w.second) =
      cycleParity G [w.a,w.b,w.c,w.d] := by
  simp only [Witness.first, Witness.second, cycleParity, List.append_assoc,
    List.cons_append, List.nil_append]
  rw [path_append G w.a w.internal w.c [w.b,w.a],
    path_append G w.a w.internal w.c [w.d,w.a]]
  simp only [pathParity]
  rw [G.symm w.c w.b, G.symm w.b w.a]
  cases pathParity G w.a (w.internal ++ [w.c]) <;>
    cases G.edge w.a w.b <;> cases G.edge w.b w.c <;>
    cases G.edge w.c w.d <;> cases G.edge w.d w.a <;> rfl

/-- The fiber over a fixed rooted/oriented first cycle injects into the remaining vertex. -/
theorem witness_first_fiber {V} (w z : Witness V)
    (h : w.first = z.first) (hd : w.d = z.d)
    (hlen : w.internal.length = z.internal.length) : w = z := by
  cases w with | mk a b c d p hp =>
    cases z with | mk a' b' c' d' p' hp' =>
      have ha : a = a' := (List.cons.inj h).1
      have hh : p ++ [c,b] = p' ++ [c',b'] := (List.cons.inj h).2
      subst a'
      have hs := List.append_inj hh hlen
      obtain ⟨he, ht⟩ := hs
      subst p'
      simp only [List.cons.injEq, and_true] at ht
      obtain ⟨hc,hb⟩ := ht
      subst c'; subst b'
      change d = d' at hd
      subst d'
      rfl

theorem first_nodup {V} (w : Witness V) : w.first.Nodup := by
  have h : (w.first ++ [w.d]).Nodup := by
    simpa [Witness.first, List.append_assoc] using w.distinct
  exact (List.nodup_append.mp h).1

theorem second_nodup {V} (w : Witness V) : w.second.Nodup := by
  have h := w.distinct
  simp only [List.nodup_cons, List.nodup_append, List.mem_cons] at h
  simp only [Witness.second, List.nodup_cons, List.nodup_append,
    List.mem_cons]
  simp_all

theorem exactly_one {V} (G : Graph V) (w : Witness V)
    (hq : cycleParity G [w.a,w.b,w.c,w.d] = true) :
    cycleParity G w.first ≠ cycleParity G w.second := by
  have h := witness_parity G w
  rw [hq] at h
  cases h1 : cycleParity G w.first <;>
    cases h2 : cycleParity G w.second <;> simp_all

theorem witness_first_recover {V} (w z : Witness V)
    (h : w.first = z.first) (hd : w.d = z.d) : w = z := by
  have hh := congrArg List.length h
  simp only [Witness.first, List.length_cons, List.length_append,
    List.length_nil] at hh
  apply witness_first_fiber w z h hd
  omega

/-- The rooted, oriented first-slot fiber has at most n witnesses, not 2*k*n.
The 2*k orientation/root bridge remains separate. -/
theorem first_fiber_card (n : Nat) (L : List (Fin n)) :
    Nat.card {w : Witness (Fin n) // w.first = L} ≤ n := by
  have inj : Function.Injective
      (fun w : {w : Witness (Fin n) // w.first = L} => w.val.d) := by
    intro w z h
    apply Subtype.ext
    exact witness_first_recover w.val z.val (w.property.trans z.property.symm) h
  simpa using Nat.card_le_card_of_injective _ inj

def Witness.firstCycle {V} (w : Witness V) : ListCycle V (w.internal.length + 3) where
  vertices := w.first
  length_eq := by simp [Witness.first]
  distinct := first_nodup w

def Witness.secondCycle {V} (w : Witness V) : ListCycle V (w.internal.length + 3) where
  vertices := w.second
  length_eq := by simp [Witness.second]
  distinct := second_nodup w

theorem witness_second_recover {V} (w z : Witness V)
    (h : w.second = z.second) (hb : w.b = z.b) : w = z := by
  cases w with | mk a b c d p hp =>
    cases z with | mk a' b' c' d' p' hp' =>
      have ha : a = a' := (List.cons.inj h).1
      have hh : p ++ [c,d] = p' ++ [c',d'] := (List.cons.inj h).2
      have hl := congrArg List.length hh
      simp only [List.length_append, List.length_cons, List.length_nil] at hl
      have hpLen : p.length = p'.length := by omega
      obtain ⟨he, ht⟩ := List.append_inj hh hpLen
      have hc : c = c' := (List.cons.inj ht).1
      have hd : d = d' := (List.cons.inj (List.cons.inj ht).2).1
      change b = b' at hb
      subst a'; subst b'; subst c'; subst d'; subst p'
      rfl

theorem second_fiber_card (n : Nat) (L : List (Fin n)) :
    Nat.card {w : Witness (Fin n) // w.second = L} ≤ n := by
  have inj : Function.Injective
      (fun w : {w : Witness (Fin n) // w.second = L} => w.val.b) := by
    intro w z h
    apply Subtype.ext
    exact witness_second_recover w.val z.val (w.property.trans z.property.symm) h
  simpa using Nat.card_le_card_of_injective _ inj

theorem path_switch {V} (G : Graph V) (U : V → Bool)
    (a b : V) (p : List V) :
    pathParity (switch G U) a (p ++ [b]) =
      xor (pathParity G a (p ++ [b])) (xor (U a) (U b)) := by
  induction p generalizing a with
  | nil => simp [pathParity, switch, cut]
  | cons c p ih =>
    simp only [List.cons_append, pathParity]
    rw [ih c]
    simp only [switch, cut]
    cases G.edge a c <;> cases U a <;> cases U c <;> cases U b <;>
      cases pathParity G c (p ++ [b]) <;> rfl

theorem cycle_switch {V} (G : Graph V) (U : V → Bool) (l : List V) :
    cycleParity (switch G U) l = cycleParity G l := by
  cases l with
  | nil => rfl
  | cons a p => simp [cycleParity, path_switch]

#eval Lean.versionString
#print axioms Witness.firstCycle
#print axioms Witness.secondCycle
#print axioms witness_second_recover
#print axioms second_fiber_card
#print axioms witness_first_recover
#print axioms first_fiber_card
#print axioms path_switch
#print axioms cycle_switch
#print axioms Conjecture19
#print axioms first_nodup
#print axioms second_nodup
#print axioms exactly_one
#print axioms witness_parity
#print axioms witness_first_fiber
end Frustrated
