import Normalization
namespace Frustrated
noncomputable def removeVertex {n} (u v : Fin (n+1)) (h : v ≠ u) : Fin n :=
  Classical.choose (Fin.exists_succAbove_eq h)
theorem removeVertex_spec {n} (u v : Fin (n+1)) (h : v ≠ u) :
    u.succAbove (removeVertex u v h) = v :=
  Classical.choose_spec (Fin.exists_succAbove_eq h)

theorem isolated_edge_endpoints {n} (Q : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, Q.edge u z = false) (p : EdgePair Q) :
    p.val.1 ≠ u ∧ p.val.2 ≠ u := by
  constructor
  · intro h
    have he := p.property.2
    rw [h,hu] at he
    contradiction
  · intro h
    have he := p.property.2
    rw [h,Q.symm,hu] at he
    contradiction

noncomputable def liftError {n} (Q : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, Q.edge u z = false) (B : Graph (Fin n)) (U : Fin n → Bool)
    (herr : ∀ a b, Q.edge (u.succAbove a) (u.succAbove b) = true →
      B.edge a b ≠ U a) (p : EdgePair Q) : DirectedError B U := by
  let ha := (isolated_edge_endpoints Q u hu p).1
  let hb := (isolated_edge_endpoints Q u hu p).2
  let a := removeVertex u p.val.1 ha
  let b := removeVertex u p.val.2 hb
  have hsa := removeVertex_spec u p.val.1 ha
  have hsb := removeVertex_spec u p.val.2 hb
  refine ⟨(a,b),?_,herr a b ?_⟩
  · intro h
    have hh := congrArg u.succAbove h
    change u.succAbove a = u.succAbove b at hh
    rw [hsa,hsb] at hh
    exact (ne_of_lt p.property.1) hh
  · rw [hsa,hsb]
    exact p.property.2

theorem liftError_injective {n} (Q : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, Q.edge u z = false) (B : Graph (Fin n)) (U : Fin n → Bool)
    (herr : ∀ a b, Q.edge (u.succAbove a) (u.succAbove b) = true →
      B.edge a b ≠ U a) :
    Function.Injective (liftError Q u hu B U herr) := by
  intro p q h
  apply Subtype.ext
  apply Prod.ext
  · have hh := congrArg (fun z : DirectedError B U => u.succAbove z.val.1) h
    simpa only [liftError,removeVertex_spec] using hh
  · have hh := congrArg (fun z : DirectedError B U => u.succAbove z.val.2) h
    simpa only [liftError,removeVertex_spec] using hh

theorem lift_sparse_bound {n} (Q : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, Q.edge u z = false) (B : Graph (Fin n)) (U : Fin n → Bool)
    (herr : ∀ a b, Q.edge (u.succAbove a) (u.succAbove b) = true →
      B.edge a b ≠ U a) :
    edgeCount Q ≤ Nat.card (DirectedError B U) :=
  Nat.card_le_card_of_injective _ (liftError_injective Q u hu B U herr)

theorem whole_sparse_normal_form {n D} (hn : 3 ≤ n) (hlarge : 16*D < n-1)
    (G : Graph (Fin (n+1))) (hf : cycleCount (n+1) 4 G ≤ D*(n+1)*(n+1)) :
    ∃ u : Fin (n+1),
      let H := switch G (G.edge u)
      edgeCount H ≤ 16*D ∨
      edgeCount (switch (complement H) (fun z => decide (z=u))) ≤ 16*D := by
  classical
  obtain ⟨u,hu,herr⟩ := bounded_discrepancy_of_f4 hn G hf
  let H := switch G (G.edge u)
  let B := deleteVertex H u
  have hr : Nat.card (DirectedError B (majority B)) < n-1 := lt_of_le_of_lt herr hlarge
  refine ⟨u,?_⟩
  rcases row_preference_rigidity B (majority B) hr with h0 | h1
  · apply Or.inl
    apply le_trans (lift_sparse_bound H u hu B (majority B) ?_) herr
    intro a b he
    change H.edge (u.succAbove a) (u.succAbove b) ≠ majority B a
    rw [h0 a,he]
    decide
  · apply Or.inr
    let Q := switch (complement H) (fun z => decide (z=u))
    have hQ := singleton_complement_repair H u hu
    apply le_trans (lift_sparse_bound Q u hQ.1 B (majority B) ?_) herr
    intro a b he
    have hab : u.succAbove a ≠ u.succAbove b := by
      intro h
      rw [h,Q.loopless] at he
      contradiction
    have hnotu := hQ.2 (u.succAbove a) (u.succAbove b)
      (Fin.succAbove_ne u a) (Fin.succAbove_ne u b)
    change Q.edge (u.succAbove a) (u.succAbove b) = _ at hnotu
    rw [hnotu] at he
    simp only [complement,hab,ite_false] at he
    change H.edge (u.succAbove a) (u.succAbove b) ≠ majority B a
    rw [h1 a]
    cases hv : H.edge (u.succAbove a) (u.succAbove b) <;> simp_all
#print axioms whole_sparse_normal_form
#print axioms lift_sparse_bound
end Frustrated
