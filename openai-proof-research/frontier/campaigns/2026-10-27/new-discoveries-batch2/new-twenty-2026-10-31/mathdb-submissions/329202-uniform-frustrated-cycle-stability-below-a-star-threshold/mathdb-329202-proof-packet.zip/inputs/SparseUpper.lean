import EdgeClassification
namespace Frustrated

theorem graph_edge_completion_count {n k} (hk : 3 ≤ k) (G : Graph (Fin n))
    (e : Sym2 (Fin n)) (he : e ∈ graphEdges G) :
    Nat.card {c : Ambient n k // e ∈ cycleSupport c} =
      2*k*(n-2).descFactorial (k-2) := by
  classical
  induction e using Sym2.inductionOn with
  | _ a b =>
    have hab : a ≠ b := by
      intro h
      subst b
      have hh := (Finset.mem_filter.mp he).2
      change G.edge a a=true at hh
      rw [G.loopless] at hh
      cases hh
    let q : Ambient n 2 := {
      toFun := fun i => if i=0 then a else b
      inj' := by
        intro i j h
        fin_cases i <;> fin_cases j <;> simp_all }
    have hq0 : q 0=a := by change (if (0:Fin 2)=0 then a else b)=a; simp
    have hq1 : q 1=b := by change (if (1:Fin 2)=0 then a else b)=b; norm_num
    have hcount := singleton_completion_count (n:=n) (m:=k-2) (by omega) q
    have hlen : 2+(k-2)=k := by omega
    rw [hlen,hq0,hq1] at hcount
    exact hcount

noncomputable def oddEdgeWitness {n k} (hk : 3 ≤ k) (G : Graph (Fin n))
    (c : OddTuple n k G) :
    (e : {e // e ∈ graphEdges G}) × {d : Ambient n k // e.val ∈ cycleSupport d} := by
  classical
  have hp := (tupleOdd_edge_subset hk G c.val).mp c.property
  have hpos : 0<(graphEdges G ∩ cycleSupport c.val).card := by omega
  let e := Classical.choose (Finset.card_pos.mp hpos)
  have he := Finset.mem_inter.mp (Classical.choose_spec (Finset.card_pos.mp hpos))
  exact ⟨⟨e,he.1⟩,⟨c.val,he.2⟩⟩

theorem oddEdgeWitness_injective {n k} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    Function.Injective (oddEdgeWitness hk G) := by
  intro c d h
  have hh := congrArg (fun p : (e : {e // e ∈ graphEdges G}) ×
    {d : Ambient n k // e.val ∈ cycleSupport d} => p.2.val) h
  exact Subtype.ext hh

theorem sparse_cycle_upper {n k} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    cycleCount n k G ≤ (graphEdges G).card*n^(k-2) := by
  classical
  have h := Nat.card_le_card_of_injective _ (oddEdgeWitness_injective hk G)
  rw [Nat.card_sigma] at h
  have hs (a : {e // e ∈ graphEdges G}) :
      Nat.card {d : Ambient n k // a.val ∈ cycleSupport d} =
        2*k*(n-2).descFactorial (k-2) := graph_edge_completion_count hk G a.val a.property
  simp_rw [hs] at h
  rw [← tupleCount_card,tuple_cycle_scale hk] at h
  have hu := Nat.descFactorial_le_pow (n-2) (k-2)
  have hp := Nat.pow_le_pow_left (Nat.sub_le n 2) (k-2)
  have hn : (n-2).descFactorial (k-2) ≤ n^(k-2) := hu.trans hp
  simp only [Finset.sum_const,Finset.card_univ,Nat.nsmul_eq_mul] at h
  have hc : Fintype.card {e // e ∈ graphEdges G} = (graphEdges G).card := Fintype.card_coe _
  rw [hc] at h
  have hh : (2*k)*cycleCount n k G ≤ (2*k)*
      ((graphEdges G).card*(n-2).descFactorial (k-2)) := by
    simpa only [Nat.mul_assoc,Nat.mul_left_comm] using h
  have hcan := Nat.le_of_mul_le_mul_left hh (by omega : 0<2*k)
  exact hcan.trans (Nat.mul_le_mul_left _ hn)
#print axioms sparse_cycle_upper
end Frustrated
