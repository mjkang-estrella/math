import AdjacentNormalize
namespace Frustrated
/-- Fixing two consecutive distinct vertices resolves the whole dihedral orbit. -/
theorem two_point_orbit_unique {n k : Nat} [NeZero k] (hk : 3 ≤ k) (c d : Ambient n k)
    (h0 : d 0 = c 0) (h1 : d 1 = c 1) (h : dihedralStep c d) : c = d := by
  obtain ⟨r,hr | hr⟩ := (dihedralStep_iff c d).mp h
  · have hh := congrArg (fun x : Ambient n k => x 0) hr
    change d 0 = c (0+r) at hh
    rw [zero_add,h0] at hh
    have hz : r=0 := (c.injective hh).symm
    simpa only [hz,rot_zero] using hr.symm
  · have hh := congrArg (fun x : Ambient n k => x 0) hr
    change d 0 = c (r-0) at hh
    rw [sub_zero,h0] at hh
    have hz : r=0 := (c.injective hh).symm
    have hh1 := congrArg (fun x : Ambient n k => x 1) hr
    change d 1 = c (r-1) at hh1
    rw [hz,h1] at hh1
    have he := c.injective hh1
    have hv := congrArg Fin.val he
    rw [Fin.val_sub] at hv
    change 1%k = (k-1%k+0)%k at hv
    have hmod : 1%k=1 := Nat.mod_eq_of_lt (by omega)
    rw [hmod,Nat.add_zero,Nat.mod_eq_of_lt (by omega : k-1<k)] at hv
    omega


theorem pair_rot {n k : Nat} [NeZero k] (c : Ambient n k) (r : Fin k)
    (a b : Fin n) (h : HasCyclePair c a b) : HasCyclePair (rot c r) a b := by
  obtain ⟨i,hi⟩ := h
  refine ⟨i-r,?_⟩
  change s(c (i-r+r),c (i-r+1+r))=s(a,b)
  have he : i-r+1+r=i+1 := by abel
  simpa only [sub_add_cancel,he] using hi

theorem pair_refl {n k : Nat} [NeZero k] (c : Ambient n k) (r : Fin k)
    (a b : Fin n) (h : HasCyclePair c a b) : HasCyclePair (refl c r) a b := by
  obtain ⟨i,hi⟩ := h
  refine ⟨r-i-1,?_⟩
  change s(c (r-(r-i-1)),c (r-(r-i-1+1)))=s(a,b)
  have he : r-(r-i-1)=i+1 := by abel
  have he' : r-(r-i-1+1)=i := by abel
  rw [he,he',Sym2.eq_swap]
  exact hi

theorem pair_step {n k : Nat} [NeZero k] (c d : Ambient n k)
    (h : dihedralStep c d) (a b : Fin n) (hp : HasCyclePair c a b) :
    HasCyclePair d a b := by
  obtain ⟨r,hr | hr⟩ := (dihedralStep_iff _ _).mp h
  · rw [hr]; exact pair_rot c r a b hp
  · rw [hr]; exact pair_refl c r a b hp

abbrev PathPrefix {n k : Nat} [NeZero k] (q : Ambient n 3) :=
  {c : Ambient n k // c 0=q 0 ∧ c 1=q 1 ∧ c 2=q 2}
abbrev AdjacentTuples {n k : Nat} [NeZero k] (q : Ambient n 3) :=
  {c : Ambient n k // HasCyclePair c (q 0) (q 1) ∧ HasCyclePair c (q 1) (q 2)}

theorem prefix_pairs {n k : Nat} [NeZero k] (hk : 3 ≤ k) (q : Ambient n 3)
    (d : PathPrefix (k:=k) q) :
    HasCyclePair d.val (q 0) (q 1) ∧ HasCyclePair d.val (q 1) (q 2) := by
  have ht : (1 : Fin k)+1=2 := by
    apply Fin.ext
    norm_num [Fin.val_add,Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<k),
      Nat.mod_eq_of_lt (by omega : 2<k)]
  constructor
  · refine ⟨0,?_⟩
    simp only [zero_add,d.property.1,d.property.2.1]
  · refine ⟨1,?_⟩
    rw [ht,d.property.2.1,d.property.2.2]

noncomputable def adjacentPlacement {n k : Nat} [NeZero k] (hk : 3 ≤ k)
    (q : Ambient n 3) (p : (Bool × Fin k) × PathPrefix (k:=k) q) :
    AdjacentTuples (k:=k) q := by
  let e := orbitMap p.2.val p.1
  have h := prefix_pairs hk q p.2
  exact ⟨e.val, pair_step _ _ e.property _ _ h.1,
    pair_step _ _ e.property _ _ h.2⟩

theorem adjacentPlacement_bijective {n k : Nat} [NeZero k] (hk : 3 ≤ k)
    (q : Ambient n 3) : Function.Bijective (adjacentPlacement hk q) := by
  constructor
  · rintro ⟨p,c⟩ ⟨r,d⟩ h
    have he : (orbitMap c.val p).val=(orbitMap d.val r).val := congrArg Subtype.val h
    have hc : dihedralStep c.val d.val :=
      step_trans (orbitMap c.val p).property
        (he ▸ step_symm (orbitMap d.val r).property)
    have hcd : c=d := Subtype.ext (two_point_orbit_unique hk c.val d.val
      (d.property.1.trans c.property.1.symm)
      (d.property.2.1.trans c.property.2.1.symm) hc)
    subst d
    have hpr : p=r := (orbitMap_bijective hk c.val).1 (Subtype.ext he)
    subst r
    rfl
  · intro c
    obtain ⟨d,hd,h₀,h₁,h₂⟩ := adjacent_normalize hk c.val q c.property.1 c.property.2
    let e : PathPrefix (k:=k) q := ⟨d,h₀,h₁,h₂⟩
    obtain ⟨p,hp⟩ := (orbitMap_bijective hk d).2 ⟨c.val,step_symm hd⟩
    refine ⟨(p,e),?_⟩
    apply Subtype.ext
    change (orbitMap d p).val=c.val
    exact congrArg Subtype.val hp

noncomputable def adjacentPlacementEquiv {n k : Nat} [NeZero k] (hk : 3 ≤ k)
    (q : Ambient n 3) :
    ((Bool × Fin k) × PathPrefix (k:=k) q) ≃ AdjacentTuples (k:=k) q :=
  Equiv.ofBijective _ (adjacentPlacement_bijective hk q)
#print axioms adjacentPlacementEquiv
end Frustrated
