import DisjointSlots
namespace Frustrated
def disjointPositionFn {m} (b : Bool) (j : Fin (1+m)) (i : Fin 4) : Fin (4+m) :=
  if i=0 then 0 else if i=1 then 1 else
    if i=2 then (if b then disjointEnd j else disjointStart j)
    else (if b then disjointStart j else disjointEnd j)

theorem disjointPositionFn_injective {m} (b : Bool) (j : Fin (1+m)) :
    Function.Injective (disjointPositionFn b j) := by
  have hmod : 1 % (4+m)=1 := Nat.mod_eq_of_lt (by omega)
  intro i l h
  fin_cases i <;> fin_cases l <;> cases b <;>
    norm_num [disjointPositionFn] at h ⊢ <;> try omega
  all_goals
    have hv := congrArg Fin.val h
    norm_num [disjointStart,disjointEnd,Fin.val_ofNat,hmod] at hv

def disjointPositions {m} (b : Bool) (j : Fin (1+m)) : Fin 4 ↪ Fin (4+m) :=
  ⟨disjointPositionFn b j,disjointPositionFn_injective b j⟩

theorem disjoint_position_card {n m} (q : Ambient n 4)
    (b : Bool) (j : Fin (1+m)) :
    Nat.card (FixedPositions (disjointPositions b j) q) = (n-4).descFactorial m :=
  fixed_positions_card _ _
#print axioms disjoint_position_card
end Frustrated
