import EdgeBounds
namespace Frustrated
theorem select_switched_row_control {n} (G : Graph (Fin (n+1))) :
    ∃ u : Fin (n+1),
      let H := switch G (G.edge u)
      (∀ z, H.edge u z = false) ∧
      (n+1) * Nat.card (RowMixed (deleteVertex H u)) ≤
        4 * cycleCount (n+1) 4 G := by
  obtain ⟨u,hu⟩ := select_four_cycle_vertex G
  refine ⟨u,switch_neighborhood_isolates G u,?_⟩
  have hi := isolated_incidence_row_sum (switch G (G.edge u)) u
    (switch_neighborhood_isolates G u)
  rw [← row_mixed_card] at hi
  rw [← hi,← Nat.card_congr (switchThroughEquiv G (G.edge u) u)]
  exact hu

theorem bounded_discrepancy_of_f4 {n D} (hn : 3 ≤ n)
    (G : Graph (Fin (n+1))) (hf : cycleCount (n+1) 4 G ≤ D*(n+1)*(n+1)) :
    ∃ u : Fin (n+1),
      let H := switch G (G.edge u)
      (∀ z, H.edge u z = false) ∧
      Nat.card (DirectedError (deleteVertex H u) (majority (deleteVertex H u))) ≤ 16*D := by
  obtain ⟨u,hu,hrow⟩ := select_switched_row_control G
  refine ⟨u,hu,?_⟩
  let B := deleteVertex (switch G (G.edge u)) u
  have hm : Nat.card (RowMixed B) ≤ 4*D*(n+1) := by
    have ht : (n+1)*Nat.card (RowMixed B) ≤ (n+1)*(4*D*(n+1)) := by
      change (n+1)*Nat.card (RowMixed B) ≤ _ at hrow
      nlinarith [hf]
    exact Nat.le_of_mul_le_mul_left ht (by omega)
  have hp := actual_discrepancy_product_bound B
  have ht : (n-1)*Nat.card (DirectedError B (majority B)) ≤ (n-1)*(16*D) := by
    have hh : 8*D*(n+1) ≤ (n-1)*(16*D) := by
      have hn' : n+1 ≤ 2*(n-1) := by omega
      nlinarith
    nlinarith [hm]
  exact Nat.le_of_mul_le_mul_left ht (by omega)

theorem deleted_sparse_normal_form {n D} (hn : 3 ≤ n) (hlarge : 16*D < n-1)
    (G : Graph (Fin (n+1))) (hf : cycleCount (n+1) 4 G ≤ D*(n+1)*(n+1)) :
    ∃ u : Fin (n+1),
      let H := switch G (G.edge u)
      let B := deleteVertex H u
      (∀ z, H.edge u z = false) ∧
      (edgeCount B ≤ 16*D ∨ edgeCount (complement B) ≤ 16*D) := by
  obtain ⟨u,hu,herr⟩ := bounded_discrepancy_of_f4 hn G hf
  refine ⟨u,hu,?_⟩
  let B := deleteVertex (switch G (G.edge u)) u
  have hr : Nat.card (DirectedError B (majority B)) < n-1 := lt_of_le_of_lt herr hlarge
  rcases row_preference_rigidity B (majority B) hr with h0 | h1
  · exact Or.inl (le_trans (sparse_from_false_rows B (majority B) h0) herr)
  · exact Or.inr (le_trans (sparse_from_true_rows B (majority B) h1) herr)
#print axioms select_switched_row_control
#print axioms bounded_discrepancy_of_f4
#print axioms deleted_sparse_normal_form
end Frustrated
