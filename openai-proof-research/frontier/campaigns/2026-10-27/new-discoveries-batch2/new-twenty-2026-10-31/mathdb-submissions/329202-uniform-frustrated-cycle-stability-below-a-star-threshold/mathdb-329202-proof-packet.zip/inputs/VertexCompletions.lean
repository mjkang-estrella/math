import DisjointCount
namespace Frustrated
abbrev ContainsVertices {n k r} (q : Ambient n r) :=
  {c : Ambient n k // ∀ i, ∃ j, c j=q i}
abbrev VertexPlacementData {n k r} (q : Ambient n r) :=
  (a : Fin r ↪ Fin k) × FixedPositions a q

def vertexPlacement {n k r} (q : Ambient n r) (p : VertexPlacementData (k:=k) q) :
    ContainsVertices (k:=k) q :=
  ⟨p.2.val,fun i => ⟨p.1 i,p.2.property i⟩⟩

theorem vertexPlacement_bijective {n k r} (q : Ambient n r) :
    Function.Bijective (vertexPlacement (k:=k) q) := by
  constructor
  · rintro ⟨a,c⟩ ⟨b,d⟩ h
    have he : c.val=d.val := congrArg Subtype.val h
    have hab : a=b := by
      apply Function.Embedding.ext
      intro i
      apply c.val.injective
      exact (c.property i).trans ((d.property i).symm.trans
        (congrArg (fun e : Ambient n k => e (b i)) he.symm))
    subst b
    have hcd : c=d := Subtype.ext he
    subst d
    rfl
  · intro c
    let a : Fin r ↪ Fin k := {
      toFun := fun i => Classical.choose (c.property i)
      inj' := by
        intro i j h
        apply q.injective
        exact (Classical.choose_spec (c.property i)).symm.trans
          ((congrArg c.val h).trans (Classical.choose_spec (c.property j))) }
    let e : FixedPositions a q := ⟨c.val,fun i => Classical.choose_spec (c.property i)⟩
    exact ⟨⟨a,e⟩,Subtype.ext rfl⟩

theorem vertex_completion_count {n r m} (q : Ambient n r) :
    Nat.card (ContainsVertices (k:=r+m) q) =
      (r+m).descFactorial r * (n-r).descFactorial m := by
  classical
  rw [← Nat.card_congr (Equiv.ofBijective _ (vertexPlacement_bijective (k:=r+m) q))]
  have hc (a : Fin r ↪ Fin (r+m)) :
      Fintype.card (FixedPositions a q) = (n-r).descFactorial m := by
    rw [← Nat.card_eq_fintype_card]
    exact fixed_positions_card a q
  simp [VertexPlacementData,hc,Fintype.card_embedding_eq]
#print axioms vertex_completion_count
end Frustrated
