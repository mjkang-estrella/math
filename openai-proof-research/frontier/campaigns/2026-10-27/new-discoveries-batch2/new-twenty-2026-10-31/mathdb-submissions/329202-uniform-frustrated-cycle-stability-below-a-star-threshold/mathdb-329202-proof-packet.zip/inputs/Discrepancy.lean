import Rows
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.BigOperators.Ring.Finset
namespace Frustrated
abbrev RowError {n} (G : Graph (Fin n)) (U : Fin n → Bool) (w : Fin n) :=
  {v : Fin n // v ≠ w ∧ G.edge w v ≠ U w}
def directedRowEquiv {n} (G : Graph (Fin n)) (U : Fin n → Bool) :
    DirectedError G U ≃ ((w : Fin n) × RowError G U w) where
  toFun p := ⟨p.val.1, ⟨p.val.2, Ne.symm p.property.1, p.property.2⟩⟩
  invFun p := ⟨(p.1,p.2.val), Ne.symm p.2.property.1, p.2.property.2⟩
  left_inv _ := rfl
  right_inv _ := rfl
noncomputable def majority {n} (G : Graph (Fin n)) (w : Fin n) : Bool :=
  decide (n-1-rowDegree G w < rowDegree G w)

theorem degree_le {n} (G : Graph (Fin n)) (w : Fin n) :
    rowDegree G w ≤ n-1 := by
  classical
  have h := Fintype.card_subtype_le (fun v : Fin n => v ≠ w ∧ G.edge w v = true)
  have hc := Fintype.card_subtype_compl (fun v : Fin n => v ≠ w ∧ G.edge w v = true)
  have hn := row_nonneighbor_card G w
  -- The complement contains w, hence it is nonempty.
  have : Nonempty {v : Fin n // ¬(v ≠ w ∧ G.edge w v = true)} := ⟨⟨w, by simp⟩⟩
  have hp : 0 < Fintype.card {v : Fin n // ¬(v ≠ w ∧ G.edge w v = true)} :=
    Fintype.card_pos
  change Nat.card {v : Fin n // v ≠ w ∧ G.edge w v = true} ≤ n-1
  simp only [Nat.card_eq_fintype_card]
  simp only [Fintype.card_fin] at h hc
  omega

theorem row_error_card {n} (G : Graph (Fin n)) (w : Fin n) :
    Nat.card (RowError G (majority G) w) =
      min (rowDegree G w) (n-1-rowDegree G w) := by
  classical
  by_cases h : n-1-rowDegree G w < rowDegree G w
  · have e : RowError G (majority G) w ≃ RowNonneighbor G w :=
      Equiv.subtypeEquivRight (fun v => by
        simp only [majority, h, decide_true]
        cases G.edge w v <;> simp)
    rw [Nat.card_congr e, row_nonneighbor_card, Nat.min_eq_right (Nat.le_of_lt h)]
  · have e : RowError G (majority G) w ≃ RowNeighbor G w :=
      Equiv.subtypeEquivRight (fun v => by
        simp only [majority, h, decide_false]
        cases G.edge w v <;> simp)
    rw [Nat.card_congr e, Nat.min_eq_left (Nat.le_of_not_gt h)]
    rfl

theorem actual_directed_error_sum {n} (G : Graph (Fin n)) :
    Nat.card (DirectedError G (majority G)) =
      ∑ w : Fin n, min (rowDegree G w) (n-1-rowDegree G w) := by
  classical
  rw [Nat.card_congr (directedRowEquiv G (majority G)),
    Nat.card_eq_fintype_card, Fintype.card_sigma]
  apply Finset.sum_congr rfl
  intro w _
  rw [← Nat.card_eq_fintype_card, row_error_card]

theorem actual_discrepancy_product_bound {n} (G : Graph (Fin n)) :
    (n-1) * Nat.card (DirectedError G (majority G)) ≤
      2 * Nat.card (RowMixed G) := by
  classical
  rw [actual_directed_error_sum, row_mixed_card,
    Finset.mul_sum, Finset.mul_sum]
  apply Finset.sum_le_sum
  intro w _
  have hd := degree_le G w
  have he : rowDegree G w + (n-1-rowDegree G w) = n-1 := by omega
  rcases le_total (rowDegree G w) (n-1-rowDegree G w) with h | h
  · rw [Nat.min_eq_left h]
    have hp := Nat.mul_le_mul_left (rowDegree G w) h
    nlinarith
  · rw [Nat.min_eq_right h]
    have hp := Nat.mul_le_mul_left (n-1-rowDegree G w) h
    nlinarith

theorem actual_majority_rigidity {n} (G : Graph (Fin n))
    (h : 2 * Nat.card (RowMixed G) < (n-1)*(n-1)) :
    (∀ w, majority G w = false) ∨ (∀ w, majority G w = true) := by
  apply row_preference_rigidity G (majority G)
  have hp := actual_discrepancy_product_bound G
  by_contra hn
  have hh := Nat.mul_le_mul_left (n-1) (Nat.le_of_not_gt hn)
  omega
#print axioms actual_directed_error_sum
#print axioms actual_discrepancy_product_bound
#print axioms actual_majority_rigidity
end Frustrated
