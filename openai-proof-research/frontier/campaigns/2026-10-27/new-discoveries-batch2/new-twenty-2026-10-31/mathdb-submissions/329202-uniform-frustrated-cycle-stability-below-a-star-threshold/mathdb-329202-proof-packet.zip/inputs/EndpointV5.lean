import EdgeCardBridge
namespace Frustrated

theorem sparse_eventual_card_bound (k t M : Nat) (hk : 3≤k) :
    ∃ N, ∀ n, N≤n → ∀ G : Graph (Fin n), (graphEdges G).card≤M →
      cycleCount n k G < cycleCount n k (star n (t+1)) → (graphEdges G).card≤t := by
  by_cases h3 : k=3
  · subst k
    refine ⟨2*M+4,?_⟩
    intro n hn G hM hth
    exact three_strict_threshold_forces_card G hM (by omega) (by omega) hth
  · obtain ⟨m,rfl⟩ : ∃ m, k=4+m := ⟨k-4,by omega⟩
    let C := (2^(2*M)*(4+m)^4)*2^(1+m)
    refine ⟨2*M+3+2*(3+(1+m))+C+1,?_⟩
    intro n hn G hM hth
    exact sparse_strict_threshold_forces_card G hM (by omega) (by omega) (by omega) hth

theorem graph_ext_edges {V} (G H : Graph V) (h : G.edge=H.edge) : G=H := by
  cases G
  cases H
  cases h
  rfl

theorem switch_compose {V} (G : Graph V) (U W : V → Bool) :
    switch (switch G U) W = switch G (fun z => xor (U z) (W z)) := by
  apply graph_ext_edges
  funext a b
  simp only [switch,cut]
  cases G.edge a b <;> cases U a <;> cases U b <;> cases W a <;> cases W b <;> rfl

theorem complement_switch_commute {V} [DecidableEq V] (G : Graph V) (U : V → Bool) :
    complement (switch G U)=switch (complement G) U := by
  apply graph_ext_edges
  funext a b
  by_cases hab : a=b
  · subst b
    simp [complement,switch,cut,G.loopless]
  · simp only [complement,switch,cut,hab,ite_false]
    cases G.edge a b <;> cases U a <;> cases U b <;> rfl

theorem conjecture19_proved : Conjecture19 := by
  intro k hk t
  let D := k*(t+1)*2^(k-3)
  let M := 16*D
  obtain ⟨Ns,hNs⟩ := sparse_eventual_card_bound k t M hk
  obtain ⟨No,hNo⟩ := odd_complement_eventual_exclusion (M:=M) (s:=t+1) hk
  let N := t+2+Ns+No+2*(k+1)+M+5
  refine ⟨N,by omega,?_⟩
  intro n hn G hthreshold
  cases n with
  | zero => omega
  | succ n =>
    have hkn : 2*(k+1) ≤ n+1 := by omega
    have hf : cycleCount (n+1) 4 G ≤ D*(n+1)*(n+1) :=
      threshold_f4_bound hk hkn G hthreshold
    have hnormal : 16*D<n-1 := by change M<n-1; omega
    obtain ⟨u,hu⟩ := whole_sparse_normal_form (by omega : 3≤n) hnormal G hf
    let U := G.edge u
    let W := fun z => decide (z=u)
    let H := switch G U
    let Q := switch (complement H) W
    change edgeCount H≤M ∨ edgeCount Q≤M at hu
    have hH : cycleCount (n+1) k H < cycleCount (n+1) k (star (n+1) (t+1)) := by
      simpa only [H,cycleCount_switch] using hthreshold
    rcases hu with hsmall | hsmall
    · have hcard : (graphEdges H).card≤M := by rwa [graphEdges_card_eq_edgeCount]
      have ht := hNs (n+1) (by omega) H hcard hH
      have hed : edgeCount H≤t := by rwa [graphEdges_card_eq_edgeCount] at ht
      exact Or.inl (nearCut_of_switch_sparse G U hed)
    · have hcard : (graphEdges Q).card≤M := by rwa [graphEdges_card_eq_edgeCount]
      by_cases he : k%2=0
      · have hQ : cycleCount (n+1) k Q < cycleCount (n+1) k (star (n+1) (t+1)) := by
          simpa only [Q,cycleCount_switch,complement_even_cycleCount hk he] using hH
        have ht := hNs (n+1) (by omega) Q hcard hQ
        have hed : edgeCount Q≤t := by rwa [graphEdges_card_eq_edgeCount] at ht
        have hq : Q=switch (complement G) (fun z => xor (U z) (W z)) := by
          change switch (complement (switch G U)) W = _
          rw [complement_switch_commute,switch_compose]
        rw [hq] at hed
        exact Or.inr (nearCut_of_switch_sparse (complement G) _ hed)
      · let A := switch H W
        have hA : cycleCount (n+1) k A < cycleCount (n+1) k (star (n+1) (t+1)) := by
          simpa only [A,cycleCount_switch] using hH
        have hAc : complement A=Q := complement_switch_commute H W
        have hMc : (graphEdges (complement A)).card≤M := by rwa [hAc]
        exact (hNo (n+1) (by omega) A he hMc hA).elim
#print axioms sparse_eventual_card_bound
#print axioms conjecture19_proved
end Frustrated
