import PairwiseRemainder
namespace Frustrated

theorem uniform_sparse_star_minimum {n m M : Nat} (G : Graph (Fin n))
    (hM : (graphEdges G).card ≤ M) (hn : (graphEdges G).card+1 ≤ n)
    (hfall : 2*(3+(1+m)) ≤ n)
    (hlarge : (2^(2*M)*(4+m)^4)*2^(1+m) < n) :
    cycleCount n (4+m) (star n (graphEdges G).card) ≤ cycleCount n (4+m) G := by
  classical
  let E := graphEdges G
  let B := (n-3).descFactorial (1+m)
  let K : Int := 2*((4+m:Nat):Int)
  have hK : 1 ≤ K := by dsimp [K]; omega
  have hG := evaluated_sparse_expansion (m:=m) G
  have hS := canonical_star_formula (m:=1+m) hn
  have he : 3+(1+m)=4+m := by omega
  have he' : 1+(1+m)=2+m := by omega
  rw [he,he'] at hS
  have hr := full_signed_remainder_bound (m:=m) E hM
  have hd := remainder_smaller_than_adjacent hfall hlarge
  have hd' : ((2^(2*M)*(4+m)^4*n^m:Nat):Int) < (B:Int) := by exact_mod_cast hd
  have hB : (0:Int) < B := by exact_mod_cast (Nat.lt_of_le_of_lt (Nat.zero_le _) hd)
  have hR : -(B:Int) < signedRemainder (k:=4+m) E := by
    have hl := (abs_le.mp hr).1
    linarith
  by_cases hm : ∀ e ∈ E, ∀ f ∈ E, EdgeMeets e f
  · have hz := pairwise_remainder_zero (m:=m) G hm
    have ha : (adjacentSupports E).card=E.card.choose 2 := by
      rw [pairwise_adjacent_eq E hm,Finset.card_powersetCard]
    change (adjacentSupports (graphEdges G)).card = (graphEdges G).card.choose 2 at ha
    rw [hz,ha] at hG
    have hcount : (cycleCount n (4+m) (star n E.card):Int) = (cycleCount n (4+m) G:Int) := by
      apply mul_left_cancel₀ (by dsimp [K]; omega : K ≠ 0)
      rw [hS]
      simpa only [add_zero] using hG.symm
    exact_mod_cast hcount.le
  · have hA := adjacent_card_strict E hm
    have hA' : ((adjacentSupports E).card:Int)+1 ≤ (E.card.choose 2:Int) := by exact_mod_cast hA
    have hp := mul_le_mul_of_nonneg_right hA' (le_of_lt hB)
    have hscale := mul_le_mul_of_nonneg_left hp (by omega : (0:Int) ≤ K)
    have hKB := mul_le_mul_of_nonneg_right hK (by positivity : (0:Int) ≤ 2*(B:Int))
    have hcount : (cycleCount n (4+m) (star n E.card):Int) ≤ (cycleCount n (4+m) G:Int) := by
      by_contra hbad
      have hbad' : (cycleCount n (4+m) G:Int) ≤ (cycleCount n (4+m) (star n E.card):Int) := le_of_lt (lt_of_not_ge hbad)
      have hscaled := mul_le_mul_of_nonneg_left hbad' (by omega : (0:Int) ≤ K)
      change K*(cycleCount n (4+m) G:Int) = K*((E.card:Int)*(n-2).descFactorial (2+m) -
        2*((adjacentSupports E).card:Int)*(B:Int)) + signedRemainder (k:=4+m) E at hG
      change (cycleCount n (4+m) (star n E.card):Int) =
        (E.card:Int)*(n-2).descFactorial (2+m)-2*(E.card.choose 2:Int)*(B:Int) at hS
      have hSeq := congrArg (fun x : Int => K*x) hS
      nlinarith only [hG,hSeq,hR,hscale,hKB,hscaled,hB]
    exact_mod_cast hcount
#print axioms uniform_sparse_star_minimum
end Frustrated
