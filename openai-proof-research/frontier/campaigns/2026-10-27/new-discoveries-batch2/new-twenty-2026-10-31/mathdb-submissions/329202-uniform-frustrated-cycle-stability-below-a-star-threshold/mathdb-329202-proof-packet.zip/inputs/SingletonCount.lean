import AdjacentCount
namespace Frustrated
abbrev EdgePrefix {n k : Nat} [NeZero k] (q : Ambient n 2) :=
  {c : Ambient n k // c 0=q 0 ∧ c 1=q 1}
abbrev SingletonTuples {n k : Nat} [NeZero k] (q : Ambient n 2) :=
  {c : Ambient n k // HasCyclePair c (q 0) (q 1)}

theorem singleton_normalize {n k} [NeZero k] (c : Ambient n k)
    (q : Ambient n 2) (h : HasCyclePair c (q 0) (q 1)) :
    ∃ d : Ambient n k, dihedralStep c d ∧ d 0=q 0 ∧ d 1=q 1 := by
  obtain ⟨x,y,hx,hy,hxy⟩ := pair_positions c (q 0) (q 1) h
  rcases hxy with hxy | hxy
  · refine ⟨rot c x,(dihedralStep_iff _ _).mpr ⟨x,Or.inl rfl⟩,?_,?_⟩
    · change c (0+x)=q 0; simpa using hx
    · change c (1+x)=q 1; simpa only [hxy,add_comm] using hy
  · refine ⟨refl c x,(dihedralStep_iff _ _).mpr ⟨x,Or.inr rfl⟩,?_,?_⟩
    · change c (x-0)=q 0; simpa using hx
    · change c (x-1)=q 1
      have he : x-1=y := by rw [hxy]; abel
      simpa only [he] using hy

noncomputable def singletonPlacement {n k} [NeZero k] (q : Ambient n 2)
    (p : (Bool × Fin k) × EdgePrefix (k:=k) q) : SingletonTuples (k:=k) q := by
  have h : HasCyclePair p.2.val (q 0) (q 1) := by
    refine ⟨0,?_⟩
    simp only [zero_add,p.2.property.1,p.2.property.2]
  let e := orbitMap p.2.val p.1
  exact ⟨e.val,pair_step _ _ e.property _ _ h⟩

theorem singletonPlacement_bijective {n k} [NeZero k] (hk : 3 ≤ k)
    (q : Ambient n 2) : Function.Bijective (singletonPlacement (k:=k) q) := by
  constructor
  · rintro ⟨p,c⟩ ⟨r,d⟩ h
    have he : (orbitMap c.val p).val=(orbitMap d.val r).val := congrArg Subtype.val h
    have hc : dihedralStep c.val d.val :=
      step_trans (orbitMap c.val p).property
        (he ▸ step_symm (orbitMap d.val r).property)
    have hcd : c=d := Subtype.ext (two_point_orbit_unique hk c.val d.val
      (d.property.1.trans c.property.1.symm)
      (d.property.2.trans c.property.2.symm) hc)
    subst d
    have hpr : p=r := (orbitMap_bijective hk c.val).1 (Subtype.ext he)
    subst r
    rfl
  · intro c
    obtain ⟨d,hd,h₀,h₁⟩ := singleton_normalize c.val q c.property
    let e : EdgePrefix (k:=k) q := ⟨d,h₀,h₁⟩
    obtain ⟨p,hp⟩ := (orbitMap_bijective hk d).2 ⟨c.val,step_symm hd⟩
    refine ⟨(p,e),?_⟩
    apply Subtype.ext
    change (orbitMap d p).val=c.val
    exact congrArg Subtype.val hp

theorem castAdd_two_0 (m : Nat) :
    Fin.castAdd m (0 : Fin 2) = (0 : Fin (2+m)) := by
  apply Fin.ext
  norm_num [Fin.val_ofNat]
theorem castAdd_two_1 (m : Nat) :
    Fin.castAdd m (1 : Fin 2) = (1 : Fin (2+m)) := by
  apply Fin.ext
  norm_num [Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<2+m)]

noncomputable def edgePrefixEquiv {n m} (q : Ambient n 2) :
    EdgePrefix (k:=2+m) q ≃ FixedPrefix m q where
  toFun c := ⟨c.val,by
    intro i
    fin_cases i
    · change c.val (Fin.castAdd m (0:Fin 2))=q 0
      simpa only [castAdd_two_0] using c.property.1
    · change c.val (Fin.castAdd m (1:Fin 2))=q 1
      simpa only [castAdd_two_1] using c.property.2⟩
  invFun c := ⟨c.val,by
    have h₀ := c.property 0
    have h₁ := c.property 1
    simpa only [castAdd_two_0,castAdd_two_1] using And.intro h₀ h₁⟩
  left_inv c := by apply Subtype.ext; rfl
  right_inv c := by apply Subtype.ext; rfl

theorem singleton_completion_count {n m} (hm : 1 ≤ m) (q : Ambient n 2) :
    Nat.card {c : Ambient n (2+m) // s(q 0,q 1) ∈ cycleSupport c} =
      2*(2+m)*(n-2).descFactorial m := by
  classical
  have he : Nat.card {c : Ambient n (2+m) // s(q 0,q 1) ∈ cycleSupport c} =
      Nat.card (SingletonTuples (k:=2+m) q) := by
    simp_rw [support_definition_bridge,← pair_iff_support]
  rw [he,← Nat.card_congr (Equiv.ofBijective _ (singletonPlacement_bijective (k:=2+m) (by omega) q))]
  rw [Nat.card_prod,Nat.card_prod,Nat.card_congr (edgePrefixEquiv (m:=m) q),fixed_prefix_card]
  simp [Nat.card_eq_fintype_card]
#print axioms singleton_completion_count
end Frustrated
