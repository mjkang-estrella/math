import AdjacentBijection
import PrefixCompletions
import Mathlib.Tactic.FinCases
namespace Frustrated
/-- Same unordered support definition as the inherited FiniteEdges module;
    kept in this small dependency branch to avoid rebuilding unrelated graph lemmas. -/
def adjacentSupport {n k} [NeZero k] (c : Ambient n k) : Finset (Sym2 (Fin n)) := by
  classical
  exact Finset.univ.image (fun i : Fin k => s(c i,c (i+1)))

theorem pair_iff_support {n k} [NeZero k] (c : Ambient n k) (a b : Fin n) :
    HasCyclePair c a b ↔ s(a,b) ∈ adjacentSupport c := by
  classical
  simp only [adjacentSupport,Finset.mem_image,Finset.mem_univ,true_and]
  rfl

theorem castAdd_three_0 (m : Nat) :
    Fin.castAdd m (0 : Fin 3) = (0 : Fin (3+m)) := by
  apply Fin.ext
  norm_num [Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 0<3+m)]

theorem castAdd_three_1 (m : Nat) :
    Fin.castAdd m (1 : Fin 3) = (1 : Fin (3+m)) := by
  apply Fin.ext
  norm_num [Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 1<3+m)]

theorem castAdd_three_2 (m : Nat) :
    Fin.castAdd m (2 : Fin 3) = (2 : Fin (3+m)) := by
  apply Fin.ext
  norm_num [Fin.val_ofNat,Nat.mod_eq_of_lt (by omega : 2<3+m)]

noncomputable def pathPrefixEquiv {n m} (q : Ambient n 3) :
    PathPrefix (k:=3+m) q ≃ FixedPrefix m q where
  toFun c := ⟨c.val,by
    intro i
    fin_cases i
    · change c.val (Fin.castAdd m (0 : Fin 3)) = q 0
      simpa only [castAdd_three_0,castAdd_three_1,castAdd_three_2] using c.property.1
    · change c.val (Fin.castAdd m (1 : Fin 3)) = q 1
      simpa only [castAdd_three_0,castAdd_three_1,castAdd_three_2] using c.property.2.1
    · change c.val (Fin.castAdd m (2 : Fin 3)) = q 2
      simpa only [castAdd_three_0,castAdd_three_1,castAdd_three_2] using c.property.2.2⟩
  invFun c := ⟨c.val,by
    have h₀ := c.property 0
    have h₁ := c.property 1
    have h₂ := c.property 2
    simpa only [castAdd_three_0,castAdd_three_1,castAdd_three_2] using And.intro h₀ (And.intro h₁ h₂)⟩
  left_inv c := by apply Subtype.ext; rfl
  right_inv c := by apply Subtype.ext; rfl

theorem adjacent_tuple_count {n m} (q : Ambient n 3) :
    Nat.card (AdjacentTuples (k:=3+m) q) = 2*(3+m)*(n-3).descFactorial m := by
  have h := Nat.card_congr (adjacentPlacementEquiv (k:=3+m) (by omega) q)
  rw [← h,Nat.card_prod,Nat.card_prod]
  rw [Nat.card_congr (pathPrefixEquiv (m:=m) q),fixed_prefix_card]
  simp [Nat.card_eq_fintype_card]

theorem adjacent_support_count {n m} (q : Ambient n 3) :
    Nat.card {c : Ambient n (3+m) //
      ({s(q 0,q 1),s(q 1,q 2)} : Finset (Sym2 (Fin n))) ⊆ adjacentSupport c} =
      2*(3+m)*(n-3).descFactorial m := by
  classical
  have he : (fun c : Ambient n (3+m) =>
      ({s(q 0,q 1),s(q 1,q 2)} : Finset (Sym2 (Fin n))) ⊆ adjacentSupport c) =
      (fun c => HasCyclePair c (q 0) (q 1) ∧ HasCyclePair c (q 1) (q 2)) := by
    funext c
    apply propext
    simp [Finset.insert_subset_iff,pair_iff_support]
  change Nat.card (Subtype _) = _
  rw [he]
  exact adjacent_tuple_count q
theorem support_definition_bridge {n k} [NeZero k] (c : Ambient n k) :
    cycleSupport c = adjacentSupport c := by
  classical
  unfold cycleSupport adjacentSupport
  congr 1
  funext i
  unfold cycleEdge nextIndex
  rw [succ_as_add]

theorem adjacent_completion_count {n m} (q : Ambient n 3) :
    Nat.card {c : Ambient n (3+m) //
      ({s(q 0,q 1),s(q 1,q 2)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} =
      2*(3+m)*(n-3).descFactorial m := by
  simp_rw [support_definition_bridge]
  exact adjacent_support_count q
noncomputable def adjacentCompletionEquiv {n m} (q : Ambient n 3) :
    {c : Ambient n (3+m) //
      ({s(q 0,q 1),s(q 1,q 2)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} ≃
      Bool × (Fin (3+m) × FixedPrefix m q) := by
  classical
  let e : {c : Ambient n (3+m) //
      ({s(q 0,q 1),s(q 1,q 2)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} ≃
      AdjacentTuples (k:=3+m) q :=
    { toFun := fun c => ⟨c.val,by
        simpa [support_definition_bridge,Finset.insert_subset_iff,← pair_iff_support]
          using c.property⟩
      invFun := fun c => ⟨c.val,by
        simpa [support_definition_bridge,Finset.insert_subset_iff,← pair_iff_support]
          using c.property⟩
      left_inv := fun c => by apply Subtype.ext; rfl
      right_inv := fun c => by apply Subtype.ext; rfl }
  exact e.trans ((adjacentPlacementEquiv (k:=3+m) (by omega) q).symm.trans
    ((Equiv.prodCongr (Equiv.refl (Bool × Fin (3+m))) (pathPrefixEquiv q)).trans
      (Equiv.prodAssoc Bool (Fin (3+m)) (FixedPrefix m q))))
#print axioms adjacentCompletionEquiv
#print axioms adjacent_completion_count
#print axioms adjacent_support_count
end Frustrated
