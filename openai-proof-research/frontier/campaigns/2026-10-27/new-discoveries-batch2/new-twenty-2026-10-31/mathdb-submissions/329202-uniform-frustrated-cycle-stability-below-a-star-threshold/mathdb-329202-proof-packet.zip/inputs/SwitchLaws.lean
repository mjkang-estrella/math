import Averaging
namespace Frustrated
theorem tupleOdd_switch_iff {n k} (G : Graph (Fin n)) (U : Fin n → Bool)
    (c : Ambient n k) : tupleOdd (switch G U) c ↔ tupleOdd G c := by
  rw [tupleOdd_list,tupleOdd_list,cycle_switch]

def switchOddEquiv {n k} (G : Graph (Fin n)) (U : Fin n → Bool) :
    OddTuple n k G ≃ OddTuple n k (switch G U) where
  toFun c := ⟨c.val,(tupleOdd_switch_iff G U c.val).mpr c.property⟩
  invFun c := ⟨c.val,(tupleOdd_switch_iff G U c.val).mp c.property⟩
  left_inv _ := rfl
  right_inv _ := rfl

def switchQuotEquiv {n k} (G : Graph (Fin n)) (U : Fin n → Bool) :
    Quot (oddRel (k := k) G) ≃ Quot (oddRel (k := k) (switch G U)) where
  toFun := Quot.map (switchOddEquiv G U) (fun _ _ h => h)
  invFun := Quot.map (switchOddEquiv G U).symm (fun _ _ h => h)
  left_inv q := by induction q using Quot.inductionOn with | h c => rfl
  right_inv q := by induction q using Quot.inductionOn with | h c => rfl

theorem cycleCount_switch {n k} (G : Graph (Fin n)) (U : Fin n → Bool) :
    cycleCount n k (switch G U) = cycleCount n k G :=
  (Nat.card_congr (switchQuotEquiv (k := k) G U)).symm

def switchThroughEquiv {n} (G : Graph (Fin (n+1))) (U : Fin (n+1) → Bool)
    (u : Fin (n+1)) : CycleThrough G u ≃ CycleThrough (switch G U) u where
  toFun q := ⟨switchQuotEquiv G U q.val, by
    obtain ⟨c,hc,hv⟩ := q.property
    exact ⟨switchOddEquiv G U c,congrArg (switchQuotEquiv G U) hc,hv⟩⟩
  invFun q := ⟨(switchQuotEquiv G U).symm q.val, by
    obtain ⟨c,hc,hv⟩ := q.property
    exact ⟨(switchOddEquiv G U).symm c,
      congrArg (switchQuotEquiv G U).symm hc,hv⟩⟩
  left_inv q := Subtype.ext ((switchQuotEquiv G U).left_inv q.val)
  right_inv q := Subtype.ext ((switchQuotEquiv G U).right_inv q.val)

theorem switch_neighborhood_isolates {V} (G : Graph V) (u : V) :
    ∀ z, (switch G (G.edge u)).edge u z = false := by
  intro z
  simp only [switch,cut,G.loopless]
  cases G.edge u z <;> rfl

theorem singleton_complement_repair {V} [DecidableEq V] (G : Graph V) (u : V)
    (hu : ∀ z, G.edge u z = false) :
    (∀ z, (switch (complement G) (fun a => decide (a=u))).edge u z = false) ∧
    (∀ a b, a ≠ u → b ≠ u →
      (switch (complement G) (fun z => decide (z=u))).edge a b =
        (complement G).edge a b) := by
  constructor
  · intro z
    by_cases h : u = z
    · subst z; exact (switch _ _).loopless _
    · simp [switch,cut,complement,h,Ne.symm h,hu]
  · intro a b ha hb
    simp [switch,cut,ha,hb]
#print axioms cycleCount_switch
#print axioms switchThroughEquiv
#print axioms singleton_complement_repair
end Frustrated
