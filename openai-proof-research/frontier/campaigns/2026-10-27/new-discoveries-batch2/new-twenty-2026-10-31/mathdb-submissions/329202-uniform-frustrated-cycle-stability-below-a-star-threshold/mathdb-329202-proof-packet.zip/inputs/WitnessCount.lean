import Counting
import Mathlib.Tactic.Ring
namespace Frustrated

theorem list_odd_tuple {n k} (G : Graph (Fin n)) (C : ListCycle (Fin n) k) :
    tupleOdd G C.toTuple ↔ frustrated G C := by
  rw [tupleOdd_list, ListCycle.toTuple_toList]
  rfl

abbrev CountWitness (n k) (G : Graph (Fin n)) :=
  {w : Witness (Fin n) // w.internal.length + 3 = k ∧
    cycleParity G [w.a,w.b,w.c,w.d] = true}

def CountWitness.firstList {n k G} (w : CountWitness n k G) : ListCycle (Fin n) k where
  vertices := w.val.first
  length_eq := by simpa [Witness.first] using w.property.1
  distinct := first_nodup w.val

def CountWitness.secondList {n k G} (w : CountWitness n k G) : ListCycle (Fin n) k where
  vertices := w.val.second
  length_eq := by simpa [Witness.second] using w.property.1
  distinct := second_nodup w.val

noncomputable def witnessEncode {n k} (G : Graph (Fin n)) (w : CountWitness n k G) :
    Bool × (OddTuple n k G × Fin n) := by
  classical
  by_cases h : frustrated G w.firstList
  · exact (false, (⟨w.firstList.toTuple, (list_odd_tuple G _).mpr h⟩, w.val.d))
  · have h' : frustrated G w.secondList := by
      have hh := exactly_one G w.val w.property.2
      change cycleParity G w.val.first ≠ cycleParity G w.val.second at hh
      change cycleParity G w.val.first ≠ true at h
      change cycleParity G w.val.second = true
      cases h1 : cycleParity G w.val.first <;>
        cases h2 : cycleParity G w.val.second <;> simp_all
    exact (true, (⟨w.secondList.toTuple, (list_odd_tuple G _).mpr h'⟩, w.val.b))

theorem firstList_recover {n k G} (w z : CountWitness n k G)
    (ht : w.firstList.toTuple = z.firstList.toTuple) (hd : w.val.d = z.val.d) : w = z := by
  apply Subtype.ext
  apply witness_first_recover _ _ _ hd
  have hc := (listTupleEquiv n k).injective ht
  exact congrArg ListCycle.vertices hc

theorem secondList_recover {n k G} (w z : CountWitness n k G)
    (ht : w.secondList.toTuple = z.secondList.toTuple) (hb : w.val.b = z.val.b) : w = z := by
  apply Subtype.ext
  apply witness_second_recover _ _ _ hb
  have hc := (listTupleEquiv n k).injective ht
  exact congrArg ListCycle.vertices hc

theorem witnessEncode_injective {n k} (G : Graph (Fin n)) :
    Function.Injective (witnessEncode (k := k) G) := by
  classical
  intro w z h
  unfold witnessEncode at h
  split_ifs at h with hw hz hz
  · have ht := congrArg (fun p => p.2.1.val) h
    have hd := congrArg (fun p => p.2.2) h
    exact firstList_recover w z ht hd
  · have hh := congrArg Prod.fst h
    contradiction
  · have hh := congrArg Prod.fst h
    contradiction
  · have ht := congrArg (fun p => p.2.1.val) h
    have hb := congrArg (fun p => p.2.2) h
    exact secondList_recover w z ht hb

theorem witness_bound_tuple {n k} (G : Graph (Fin n)) :
    Nat.card (CountWitness n k G) ≤ 2*n*tupleCount n k G := by
  have h := Nat.card_le_card_of_injective _ (witnessEncode_injective (k := k) G)
  have ht : Nat.card (OddTuple n k G) = tupleCount n k G := by
    simp [OddTuple, tupleOdd, tupleCount, Nat.card_eq_fintype_card, Fintype.card_subtype]
  simpa [Nat.card_prod, ht, Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc] using h

theorem witness_bound_cycle {n k} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    Nat.card (CountWitness n k G) ≤ 4*k*n*cycleCount n k G := by
  have h := witness_bound_tuple (k := k) G
  rw [tuple_cycle_scale hk] at h
  convert h using 1
  ring

#print axioms witness_bound_cycle
end Frustrated
