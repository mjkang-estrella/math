import WholeNormalization
namespace Frustrated
theorem bitParity_not (l : List Bool) :
    bitParity (l.map Bool.not) =
      if l.length % 2 = 0 then bitParity l else !(bitParity l) := by
  induction l with
  | nil => rfl
  | cons b l ih =>
    simp only [List.map_cons,bitParity,List.length_cons,ih]
    by_cases hp : l.length % 2 = 0
    · have hs : (l.length+1)%2 ≠ 0 := by omega
      simp only [hp,ite_true,hs,ite_false]
      cases b <;> cases bitParity l <;> rfl
    · have hs : (l.length+1)%2 = 0 := by omega
      simp only [hp,ite_false,hs,ite_true]
      cases b <;> cases bitParity l <;> rfl

theorem tuple_complement_bits {n k} (hk : 3 ≤ k) (G : Graph (Fin n))
    (c : Ambient n k) :
    cycleBits (complement G) (List.ofFn c) =
      (cycleBits G (List.ofFn c)).map Bool.not := by
  rw [cycleBits_ofFn,cycleBits_ofFn, List.map_ofFn]
  congr 1
  funext i
  have hn : c i ≠ c ⟨(i.val+1)%k,Nat.mod_lt _ (by omega)⟩ := by
    intro h
    have hh := c.injective h
    have hv := congrArg Fin.val hh
    have hi := i.isLt
    have hm : (i.val+1)%k ≠ i.val := by
      by_cases hs : i.val+1 < k
      · rw [Nat.mod_eq_of_lt hs]; omega
      · have he : i.val+1=k := by omega
        rw [he,Nat.mod_self]; omega
    exact hm hv.symm
  simp [complement,hn]

theorem tupleOdd_complement_iff {n k} (hk : 3 ≤ k) (G : Graph (Fin n))
    (c : Ambient n k) :
    tupleOdd (complement G) c ↔
      if k%2=0 then tupleOdd G c else ¬ tupleOdd G c := by
  rw [tupleOdd_list,tupleOdd_list]
  change cycleParity (complement G) (List.ofFn c) = true ↔
    if k%2=0 then cycleParity G (List.ofFn c) = true
      else ¬ cycleParity G (List.ofFn c) = true
  rw [← cycleBits_parity,tuple_complement_bits hk G c,bitParity_not]
  have hl : (cycleBits G (List.ofFn c)).length = k := by
    rw [cycleBits_ofFn,List.length_ofFn]
  rw [hl]
  rw [cycleBits_parity]
  by_cases h : k%2=0 <;> simp only [h,ite_true,ite_false]
  cases cycleParity G (List.ofFn c) <;> decide

noncomputable def totalCycleCount (n k : Nat) :=
  Nat.card (Quot (@dihedralStep n k))

theorem total_cycle_scale {n k} (hk : 3 ≤ k) :
    Nat.card (Ambient n k) = (2*k)*totalCycleCount n k := by
  classical
  have : NeZero k := ⟨by omega⟩
  let : Fintype (Quot (@dihedralStep n k)) := Fintype.ofFinite _
  have hf (q : Quot (@dihedralStep n k)) :
      Nat.card {c : Ambient n k // Quot.mk dihedralStep c=q} = 2*k := by
    induction q using Quot.inductionOn with | h c =>
      have he (d : Ambient n k) :
          Quot.mk dihedralStep d = Quot.mk dihedralStep c ↔ dihedralStep c d := by
        constructor
        · intro h
          have hh := Quot.eqvGen_exact h
          clear h
          have hs : dihedralStep d c := by
            induction hh with
            | rel a b h => exact h
            | refl a => exact step_refl a
            | symm a b _ ih => exact step_symm ih
            | trans a b c _ _ h1 h2 => exact step_trans h1 h2
          exact step_symm hs
        · intro h
          exact Quot.sound (step_symm h)
      rw [Nat.card_congr (Equiv.subtypeEquivRight he)]
      exact ambient_orbit_card hk c
  rw [← Nat.card_congr (Equiv.sigmaFiberEquiv (Quot.mk (@dihedralStep n k))),Nat.card_sigma]
  simp only [hf,Finset.sum_const,Finset.card_univ,Nat.nsmul_eq_mul]
  rw [mul_comm]
  change (2*k)*Fintype.card (Quot (@dihedralStep n k)) =
    (2*k)*Nat.card (Quot (@dihedralStep n k))
  rw [Nat.card_eq_fintype_card]

theorem complement_even_cycleCount {n k} (hk : 3 ≤ k) (he : k%2=0)
    (G : Graph (Fin n)) : cycleCount n k (complement G) = cycleCount n k G := by
  classical
  have hc : tupleCount n k (complement G) = tupleCount n k G := by
    unfold tupleCount
    congr 1
    apply Finset.filter_congr
    intro c _
    change tupleOdd (complement G) c ↔ tupleOdd G c
    simpa only [he,ite_true] using tupleOdd_complement_iff hk G c
  rw [tuple_cycle_scale hk,tuple_cycle_scale hk] at hc
  exact Nat.eq_of_mul_eq_mul_left (by omega) hc

theorem complement_odd_cycleCount {n k} (hk : 3 ≤ k) (ho : k%2≠0)
    (G : Graph (Fin n)) :
    cycleCount n k G + cycleCount n k (complement G) = totalCycleCount n k := by
  classical
  have hc : tupleCount n k G + tupleCount n k (complement G) = Nat.card (Ambient n k) := by
    have ht (H : Graph (Fin n)) : tupleCount n k H = Fintype.card {c : Ambient n k // tupleOdd H c} := by
      rw [Fintype.card_subtype]
      unfold tupleCount
      congr 1
      apply Finset.filter_congr
      intro c _
      rfl
    rw [ht,ht]
    let e : {c : Ambient n k // tupleOdd (complement G) c} ≃
        {c : Ambient n k // ¬ tupleOdd G c} :=
      Equiv.subtypeEquivRight (fun c => by
        simpa only [ho,ite_false] using tupleOdd_complement_iff hk G c)
    rw [Fintype.card_congr e,Fintype.card_subtype_compl,Nat.card_eq_fintype_card]
    have hh := Fintype.card_subtype_le (tupleOdd (k := k) G)
    omega
  rw [tuple_cycle_scale hk,tuple_cycle_scale hk,total_cycle_scale hk,← Nat.mul_add] at hc
  exact Nat.eq_of_mul_eq_mul_left (by omega) hc
#print axioms complement_even_cycleCount
#print axioms complement_odd_cycleCount
#print axioms total_cycle_scale
end Frustrated
