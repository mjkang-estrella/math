import FiniteEdges
import Mathlib.Algebra.Ring.Parity
namespace Frustrated
attribute [local instance] Classical.propDecidable
theorem powerset_signed_sum {α : Type} (A : Finset α) :
    (∑ F ∈ A.powerset, (-2 : Int)^F.card) = (-1 : Int)^A.card := by
  classical
  have h := Finset.prod_add (fun _ : α => (-2 : Int)) (fun _ => (1 : Int)) A
  simpa using h.symm

theorem restricted_powerset_sum {α : Type} [DecidableEq α] (E C : Finset α) :
    (∑ F ∈ E.powerset, if F ⊆ C then (-2 : Int)^F.card else 0) =
      (-1 : Int)^(E∩C).card := by
  classical
  have hf : E.powerset.filter (fun F => F ⊆ C) = (E∩C).powerset := by
    ext F
    simp only [Finset.mem_filter,Finset.mem_powerset,Finset.subset_inter_iff]
  rw [← Finset.sum_filter,hf,powerset_signed_sum]

/-- Exact finite expansion over actual graph-edge subsets; doubled to avoid division. -/
theorem cycle_subset_expansion {n k : Nat} (hk : 3 ≤ k) (G : Graph (Fin n)) (c : Ambient n k) :
    (2 : Int) * (if tupleOdd G c then 1 else 0) =
      1 - ∑ F ∈ (graphEdges G).powerset,
        if F ⊆ cycleSupport c then (-2 : Int)^F.card else 0 := by
  classical
  rw [restricted_powerset_sum,tupleOdd_edge_subset hk G c,neg_one_pow_eq_ite]
  simp only [Nat.even_iff]
  have hm := Nat.mod_lt (graphEdges G ∩ cycleSupport c).card (by decide : 0<2)
  by_cases h : (graphEdges G ∩ cycleSupport c).card % 2 = 0
  · simp [h]
  · have hn : (graphEdges G ∩ cycleSupport c).card % 2 = 1 := by omega
    simp [hn]

noncomputable def tupleCompletions {n k : Nat} (F : Finset (Sym2 (Fin n))) : Nat :=
  Nat.card {c : Ambient n k // F ⊆ cycleSupport c}

theorem subset_expansion_tuple_sum {n k : Nat} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    (2 : Int) * tupleCount n k G =
      (Nat.card (Ambient n k) : Int) -
      ∑ F ∈ (graphEdges G).powerset, (-2 : Int)^F.card * tupleCompletions (k := k) F := by
  classical
  have h := congrArg (fun f : Ambient n k → Int => ∑ c, f c)
    (funext (cycle_subset_expansion hk G))
  have ht : (∑ c : Ambient n k, if tupleOdd G c then (1 : Int) else 0) = tupleCount n k G := by
    rw [tupleCount_card,Nat.card_eq_fintype_card,Fintype.card_subtype]
    simp
  have hf (F : Finset (Sym2 (Fin n))) :
      (∑ c : Ambient n k, if F ⊆ cycleSupport c then (-2 : Int)^F.card else 0) =
        (-2 : Int)^F.card * tupleCompletions (k := k) F := by
    unfold tupleCompletions
    rw [Nat.card_eq_fintype_card,Fintype.card_subtype]
    simp [Finset.sum_ite,mul_comm]
  rw [← Finset.mul_sum,ht,Finset.sum_sub_distrib] at h
  rw [Finset.sum_comm] at h
  simp_rw [hf] at h
  simpa [Nat.card_eq_fintype_card] using h

theorem subset_expansion_cycle_scale {n k : Nat} (hk : 3 ≤ k) (G : Graph (Fin n)) :
    (4*(k : Int)) * cycleCount n k G =
      (Nat.card (Ambient n k) : Int) -
      ∑ F ∈ (graphEdges G).powerset, (-2 : Int)^F.card * tupleCompletions (k := k) F := by
  have h := subset_expansion_tuple_sum hk G
  rw [tuple_cycle_scale hk] at h
  push_cast at h
  nlinarith [h]
#print axioms cycle_subset_expansion
#print axioms subset_expansion_cycle_scale
end Frustrated
