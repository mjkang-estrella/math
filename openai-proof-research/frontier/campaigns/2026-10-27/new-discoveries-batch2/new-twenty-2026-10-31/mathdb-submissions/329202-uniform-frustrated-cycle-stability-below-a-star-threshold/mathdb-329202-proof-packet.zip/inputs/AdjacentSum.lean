import SignedExpansion
namespace Frustrated
attribute [local instance] Classical.propDecidable
noncomputable def adjacentSupports {n} (E : Finset (Sym2 (Fin n))) :=
  E.powerset.filter (fun F => F.card=2 ∧ ∀ e ∈ F, ∀ f ∈ F, EdgeMeets e f)

theorem loopless_graph_edges {n} (G : Graph (Fin n)) (a : Fin n) :
    s(a,a) ∉ graphEdges G := by
  intro h
  have hh := (Finset.mem_filter.mp h).2
  change G.edge a a = true at hh
  rw [G.loopless] at hh
  contradiction

theorem adjacent_pair_completion {n m} (F : Finset (Sym2 (Fin n)))
    (hloop : ∀ a, s(a,a) ∉ F) (hcard : F.card=2)
    (hmeet : ∀ e ∈ F, ∀ f ∈ F, EdgeMeets e f) :
    tupleCompletions (k:=3+m) F = 2*(3+m)*(n-3).descFactorial m := by
  classical
  obtain ⟨e,f,hef,hF⟩ := Finset.card_eq_two.mp hcard
  have he : e ∈ F := by rw [hF]; simp
  have hf : f ∈ F := by rw [hF]; simp
  obtain ⟨a,hae,haf⟩ := hmeet e he f hf
  obtain ⟨b,hb⟩ := Sym2.mem_iff_exists.mp hae
  obtain ⟨d,hd⟩ := Sym2.mem_iff_exists.mp haf
  subst e
  subst f
  have hab : a ≠ b := by intro h; subst b; exact hloop a he
  have had : a ≠ d := by intro h; subst d; exact hloop a hf
  have hbd : b ≠ d := by intro h; subst d; exact hef rfl
  let q : Ambient n 3 := ⟨![b,a,d],by
    intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all⟩
  have hq : F = {s(q 0,q 1),s(q 1,q 2)} := by
    change F = {s(b,a),s(a,d)}
    rw [hF,show s(b,a)=s(a,b) from Sym2.eq_swap]
  rw [hq]
  exact adjacent_completion_count q

theorem adjacent_completion_sum {n m} (G : Graph (Fin n)) :
    (∑ F ∈ adjacentSupports (graphEdges G), tupleCompletions (k:=3+m) F) =
      (adjacentSupports (graphEdges G)).card * (2*(3+m)*(n-3).descFactorial m) := by
  classical
  have ht (F : Finset (Sym2 (Fin n))) (hF : F ∈ adjacentSupports (graphEdges G)) :
      tupleCompletions (k:=3+m) F = 2*(3+m)*(n-3).descFactorial m := by
    have hh := Finset.mem_filter.mp hF
    have hs := Finset.mem_powerset.mp hh.1
    exact adjacent_pair_completion F (fun a ha => loopless_graph_edges G a (hs ha)) hh.2.1 hh.2.2
  calc
    _ = ∑ _F ∈ adjacentSupports (graphEdges G), 2*(3+m)*(n-3).descFactorial m := Finset.sum_congr rfl ht
    _ = _ := by simp
#print axioms adjacent_pair_completion
#print axioms adjacent_completion_sum
end Frustrated
