import ThreeCorrection
namespace Frustrated
attribute [local instance] Classical.propDecidable

theorem adjacent_card_le_choose {n} (E : Finset (Sym2 (Fin n))) :
    (adjacentSupports E).card ≤ E.card.choose 2 := by
  have hs : adjacentSupports E ⊆ E.powersetCard 2 := by
    intro F hF
    obtain ⟨hsub,hcard,hm⟩ := Finset.mem_filter.mp hF
    exact Finset.mem_powersetCard.mpr ⟨Finset.mem_powerset.mp hsub,hcard⟩
  exact (Finset.card_le_card hs).trans_eq (Finset.card_powersetCard _ _)

theorem adjacent_card_le_pow {n M} (E : Finset (Sym2 (Fin n))) (hM : E.card ≤ M) :
    (adjacentSupports E).card ≤ 2^M := by
  have hs : adjacentSupports E ⊆ E.powerset := Finset.filter_subset _ _
  calc
    _ ≤ E.powerset.card := Finset.card_le_card hs
    _ = 2^E.card := Finset.card_powerset E
    _ ≤ _ := Nat.pow_le_pow_right (by decide) hM

theorem three_sparse_star_lower {n} (G : Graph (Fin n))
    (hn : (graphEdges G).card+1 ≤ n) :
    cycleCount n 3 (star n (graphEdges G).card) ≤ cycleCount n 3 G := by
  have h := exact_low_remainder_expansion (k:=3) (by omega) G
  rw [low_support_evaluation (m:=0)] at h
  have hs := canonical_star_formula (m:=0) hn
  have hr := three_remainder_nonnegative (graphEdges G)
  have ha : ((adjacentSupports (graphEdges G)).card : Int) ≤ ((graphEdges G).card.choose 2 : Int) :=
    by exact_mod_cast adjacent_card_le_choose (graphEdges G)
  simp only [Nat.add_zero,Nat.descFactorial_one,Nat.descFactorial_zero,Nat.cast_mul,Nat.cast_ofNat,Nat.cast_one,mul_one] at h hs
  have hc : (cycleCount n 3 (star n (graphEdges G).card) : Int) ≤ (cycleCount n 3 G : Int) := by nlinarith
  exact_mod_cast hc

theorem evaluated_sparse_expansion {n m} (G : Graph (Fin n)) :
    (2*((4+m:Nat):Int))*cycleCount n (4+m) G =
      (2*((4+m:Nat):Int))*
        (((graphEdges G).card : Int)*(n-2).descFactorial (2+m) -
          2*((adjacentSupports (graphEdges G)).card : Int)*(n-3).descFactorial (1+m)) +
      signedRemainder (k:=4+m) (graphEdges G) := by
  have h := exact_low_remainder_expansion (k:=3+(1+m)) (by omega) G
  rw [low_support_evaluation (m:=1+m)] at h
  have he : 3+(1+m)=4+m := by omega
  have he' : 1+(1+m)=2+m := by omega
  rw [he,he'] at h
  push_cast at h ⊢
  rw [h]
  ring

theorem remainder_smaller_than_adjacent {n m C : Nat}
    (hn : 2*(3+(1+m)) ≤ n) (hC : C*2^(1+m) < n) :
    C*n^m < (n-3).descFactorial (1+m) := by
  have hl := falling_uniform_lower 3 (1+m) n hn
  have hp : 0<n^m := Nat.pow_pos (by omega)
  have hmul := Nat.mul_lt_mul_of_pos_right hC hp
  have he : n^(1+m)=n*n^m := by rw [pow_add]; simp
  rw [he] at hl
  by_contra h
  have hb : (n-3).descFactorial (1+m) ≤ C*n^m := Nat.le_of_not_gt h
  have hh := Nat.mul_le_mul_left (2^(1+m)) hb
  nlinarith only [hl,hmul,hh]
#print axioms three_sparse_star_lower
#print axioms evaluated_sparse_expansion
#print axioms remainder_smaller_than_adjacent
end Frustrated
