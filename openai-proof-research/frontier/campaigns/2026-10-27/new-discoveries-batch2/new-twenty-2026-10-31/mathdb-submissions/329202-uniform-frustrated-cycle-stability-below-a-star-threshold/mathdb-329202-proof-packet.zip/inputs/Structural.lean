import ExactWitness
import Mathlib.Tactic.Linarith
namespace Frustrated

theorem isolated_quadrilateral {V} (G : Graph V) (u v w x : V)
    (hu : ∀ z, G.edge u z = false) :
    cycleParity G [u,v,w,x] = xor (G.edge w v) (G.edge w x) := by
  simp [cycleParity, pathParity, hu, G.symm x u, G.symm v w]

abbrev DirectedError {n} (G : Graph (Fin n)) (U : Fin n → Bool) :=
  {p : Fin n × Fin n // p.1 ≠ p.2 ∧ G.edge p.1 p.2 ≠ U p.1}

abbrev MixedRows {n} (U : Fin n → Bool) :=
  {a : Fin n // U a = true} × {b : Fin n // U b = false}

def mixedError {n} (G : Graph (Fin n)) (U : Fin n → Bool)
    (p : MixedRows U) : DirectedError G U := by
  have hab : p.1.val ≠ p.2.val := by
    intro h
    have hh := p.1.property
    rw [h,p.2.property] at hh
    contradiction
  by_cases he : G.edge p.1.val p.2.val = true
  · exact ⟨(p.2.val,p.1.val), Ne.symm hab, by
      rw [G.symm, he, p.2.property]; decide⟩
  · exact ⟨(p.1.val,p.2.val), hab, by rw [p.1.property]; exact he⟩

theorem mixedError_injective {n} (G : Graph (Fin n)) (U : Fin n → Bool) :
    Function.Injective (mixedError G U) := by
  intro p q h
  have hp := p.1.property
  have hp' := p.2.property
  have hq := q.1.property
  have hq' := q.2.property
  have hv := congrArg Subtype.val h
  unfold mixedError at hv
  split_ifs at hv with he hf hf
  · have hh := Prod.mk.inj hv
    apply Prod.ext
    · exact Subtype.ext hh.2
    · exact Subtype.ext hh.1
  · have hh := Prod.mk.inj hv
    have hx := congrArg U hh.1
    simp_all
  · have hh := Prod.mk.inj hv
    have hx := congrArg U hh.1
    simp_all
  · have hh := Prod.mk.inj hv
    apply Prod.ext
    · exact Subtype.ext hh.1
    · exact Subtype.ext hh.2

theorem mixed_row_bound {n} (G : Graph (Fin n)) (U : Fin n → Bool) :
    Nat.card {a : Fin n // U a = true} * Nat.card {b : Fin n // U b = false} ≤
      Nat.card (DirectedError G U) := by
  have h := Nat.card_le_card_of_injective _ (mixedError_injective G U)
  simpa only [Nat.card_prod] using h

theorem row_preference_rigidity {n} (G : Graph (Fin n)) (U : Fin n → Bool)
    (herr : Nat.card (DirectedError G U) < n-1) :
    (∀ a, U a = false) ∨ (∀ a, U a = true) := by
  classical
  by_cases h0 : ∀ a, U a = false
  · exact Or.inl h0
  by_cases h1 : ∀ a, U a = true
  · exact Or.inr h1
  push Not at h0 h1
  obtain ⟨a,ha⟩ := h0
  obtain ⟨b,hb⟩ := h1
  have ha' : U a = true := by cases h : U a <;> simp_all
  have hb' : U b = false := by cases h : U b <;> simp_all
  let : Nonempty {a : Fin n // U a = true} := ⟨⟨a,ha'⟩⟩
  let : Nonempty {b : Fin n // U b = false} := ⟨⟨b,hb'⟩⟩
  have hp : 0 < Nat.card {a : Fin n // U a = true} := Nat.card_pos
  have lp : 0 < Nat.card {b : Fin n // U b = false} := Nat.card_pos
  have hc : Nat.card {b : Fin n // U b = false} =
      n - Nat.card {a : Fin n // U a = true} := by
    let e : {b : Fin n // U b = false} ≃ {b : Fin n // ¬ U b = true} :=
      Equiv.subtypeEquivRight (fun b => by cases U b <;> simp)
    rw [Nat.card_congr e]
    rw [Nat.card_eq_fintype_card, Fintype.card_subtype_compl]
    simp only [Fintype.card_fin, Nat.card_eq_fintype_card]
  have hn : Nat.card {a : Fin n // U a = true} ≤ n := by
    simpa using Nat.card_le_card_of_injective
      (fun x : {a : Fin n // U a = true} => x.val) Subtype.val_injective
  have hsum : Nat.card {a : Fin n // U a = true} +
      Nat.card {b : Fin n // U b = false} = n := by omega
  have hm := mixed_row_bound G U
  have hprod : 0 ≤ (Nat.card {a : Fin n // U a = true} - 1) *
      (Nat.card {b : Fin n // U b = false} - 1) := Nat.zero_le _
  have heq1 : Nat.card {a : Fin n // U a = true} - 1 + 1 =
      Nat.card {a : Fin n // U a = true} := by omega
  have heq2 : Nat.card {b : Fin n // U b = false} - 1 + 1 =
      Nat.card {b : Fin n // U b = false} := by omega
  have hi : Nat.card {a : Fin n // U a = true} * Nat.card {b : Fin n // U b = false} =
      (Nat.card {a : Fin n // U a = true} - 1 + 1) *
      (Nat.card {b : Fin n // U b = false} - 1 + 1) := by rw [heq1,heq2]
  have hsub : n-1+1 = n := by omega
  exfalso
  nlinarith only [hi,hprod,heq1,heq2,hsum,hm,herr,hsub]

#print axioms row_preference_rigidity
#print axioms isolated_quadrilateral
#print axioms mixed_row_bound
end Frustrated
