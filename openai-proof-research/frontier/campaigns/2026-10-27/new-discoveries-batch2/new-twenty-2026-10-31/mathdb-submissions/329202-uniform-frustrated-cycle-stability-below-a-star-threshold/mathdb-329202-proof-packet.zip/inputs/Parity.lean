import Bridge
namespace Frustrated

def bitParity : List Bool → Bool
  | [] => false
  | b :: l => xor b (bitParity l)

theorem bitParity_count (l : List Bool) :
    bitParity l = true ↔ l.count true % 2 = 1 := by
  induction l with
  | nil => simp [bitParity]
  | cons b l ih =>
    cases b <;> cases h : bitParity l <;>
      simp_all [bitParity] <;> omega

def pathBits {V} (G : Graph V) : V → List V → List Bool
  | _, [] => []
  | a, b :: l => G.edge a b :: pathBits G b l

theorem pathBits_parity {V} (G : Graph V) (a : V) (l : List V) :
    bitParity (pathBits G a l) = pathParity G a l := by
  induction l generalizing a with
  | nil => rfl
  | cons b l ih => simp [pathBits, bitParity, pathParity, ih]

theorem pathBits_zip {V} (G : Graph V) (a b : V) (p : List V) :
    pathBits G a (p ++ [b]) = List.zipWith G.edge (a :: p) (p ++ [b]) := by
  induction p generalizing a with
  | nil => rfl
  | cons c p ih => simp [pathBits, ih]

def cycleBits {V} (G : Graph V) (l : List V) : List Bool :=
  List.zipWith G.edge l (l.rotate 1)

theorem cycleBits_parity {V} (G : Graph V) (l : List V) :
    bitParity (cycleBits G l) = cycleParity G l := by
  cases l with
  | nil => rfl
  | cons a p =>
    simp only [cycleBits, List.rotate_cons_succ, List.rotate_zero]
    rw [← pathBits_zip, pathBits_parity]
    rfl

theorem cycleBits_ofFn {n k} (G : Graph (Fin n)) (c : Ambient n k) :
    cycleBits G (List.ofFn c) = List.ofFn (fun i : Fin k =>
      G.edge (c i) (c ⟨(i.val + 1) % k,
        Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩)) := by
  apply List.ext_getElem
  · simp [cycleBits]
  · intro i h1 h2
    simp only [cycleBits, List.getElem_zipWith, List.getElem_ofFn,
      List.getElem_rotate]
    congr 1
    congr 1
    apply Fin.ext
    simp

/-- A filtered Finset count is the true-bit count of its indexed list. -/
theorem ofFn_count {k} (p : Fin k → Bool) :
    (List.ofFn p).count true =
      ((Finset.univ : Finset (Fin k)).filter (fun i => p i)).card := by
  have h := (List.nodup_finRange k).card_eq_countP (P := fun i => p i = true)
  rw [List.toFinset_finRange] at h
  rw [List.ofFn_eq_map]
  simpa [List.count, List.countP_map, Function.comp_def] using h.symm

theorem tupleOdd_list {n k} (G : Graph (Fin n)) (c : Ambient n k) :
    tupleOdd G c ↔ cycleParity G (tupleToList c).vertices = true := by
  rw [← cycleBits_parity]
  change _ ↔ bitParity (cycleBits G (List.ofFn c)) = true
  rw [cycleBits_ofFn, bitParity_count, ofFn_count]
  rfl


#print axioms bitParity_count
#print axioms cycleBits_ofFn
#print axioms tupleOdd_list
end Frustrated
