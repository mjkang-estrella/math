import Incidence
namespace Frustrated
abbrev CycleThrough {n} (G : Graph (Fin (n+1))) (u : Fin (n+1)) :=
  {q : Quot (oddRel (k := 4) G) //
    ∃ c : OddTuple (n+1) 4 G, Quot.mk (oddRel G) c = q ∧ ∃ i, c.val i = u}
def canonicalClass {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, G.edge u z = false) (c : CanonicalQuad G u) : CycleThrough G u :=
  ⟨Quot.mk (oddRel G) ⟨c.val,canonical_is_frustrated G u hu c⟩,
    ⟨⟨c.val,canonical_is_frustrated G u hu c⟩,rfl,0,c.property.1⟩⟩

theorem canonical_step_unique {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (c d : CanonicalQuad G u) (h : dihedralStep c.val d.val) : c = d := by
  obtain ⟨r,hr | hr⟩ := (dihedralStep_iff c.val d.val).mp h
  · have hh : c.val r = c.val 0 := by
      have h0 := congrArg (fun x : Ambient (n+1) 4 => x 0) hr
      change d.val 0 = c.val (0+r) at h0
      simpa only [zero_add,c.property.1,d.property.1] using h0.symm
    have hz : r = 0 := c.val.injective hh
    apply Subtype.ext
    simpa [hz,rot_zero] using hr.symm
  · have hh : c.val r = c.val 0 := by
      have h0 := congrArg (fun x : Ambient (n+1) 4 => x 0) hr
      change d.val 0 = c.val (r-0) at h0
      simpa only [sub_zero,c.property.1,d.property.1] using h0.symm
    have hz : r = 0 := c.val.injective hh
    have he := d.property.2.1
    rw [hr,hz] at he
    change G.edge (c.val (0-2)) (c.val (0-1)) = true at he
    have h2 : (0-2 : Fin 4) = 2 := by decide
    have h3 : (0-1 : Fin 4) = 3 := by decide
    rw [h2,h3,c.property.2.2] at he
    contradiction

theorem canonicalClass_injective {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, G.edge u z = false) :
    Function.Injective (canonicalClass G u hu) := by
  intro c d h
  apply canonical_step_unique G u c d
  exact (quotient_eq_step G _ _).mp (congrArg Subtype.val h)

theorem odd_root_canonical {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, G.edge u z = false) (c : OddTuple (n+1) 4 G)
    (i : Fin 4) (hi : c.val i = u) :
    ∃ d : CanonicalQuad G u, dihedralStep c.val d.val := by
  let r := rot c.val i
  have hr0 : r 0 = u := by
    change c.val (0+i) = u
    simpa only [zero_add] using hi
  have hodd : tupleOdd G r := (tupleOdd_rot G c.val i).mpr c.property
  have hp := (tupleOdd_list G r).mp hodd
  change cycleParity G (List.ofFn r) = true at hp
  have hl : List.ofFn r = [r 0,r 1,r 2,r 3] := by simp [List.ofFn_succ]
  rw [hl,hr0,isolated_quadrilateral G u _ _ _ hu] at hp
  by_cases he : G.edge (r 2) (r 1) = true
  · have hf : G.edge (r 2) (r 3) = false := by
      cases h : G.edge (r 2) (r 3) <;> simp_all
    exact ⟨⟨r,hr0,he,hf⟩,(dihedralStep_iff _ _).mpr ⟨i,Or.inl rfl⟩⟩
  · have he' : G.edge (r 2) (r 1) = false := by
      cases h : G.edge (r 2) (r 1) <;> simp_all
    have hf : G.edge (r 2) (r 3) = true := by
      cases h : G.edge (r 2) (r 3) <;> simp_all
    let d := refl r 0
    have hd0 : d 0 = u := by simpa [d,refl] using hr0
    have hd1 : G.edge (d 2) (d 1) = true := by exact hf
    have hd2 : G.edge (d 2) (d 3) = false := by exact he'
    refine ⟨⟨d,hd0,hd1,hd2⟩, ?_⟩
    exact step_trans ((dihedralStep_iff _ _).mpr ⟨i,Or.inl rfl⟩)
      ((dihedralStep_iff _ _).mpr ⟨0,Or.inr rfl⟩)

theorem canonicalClass_surjective {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, G.edge u z = false) :
    Function.Surjective (canonicalClass G u hu) := by
  intro q
  obtain ⟨c,hc,i,hi⟩ := q.property
  obtain ⟨d,hd⟩ := odd_root_canonical G u hu c i hi
  refine ⟨d,Subtype.ext ?_⟩
  change Quot.mk (oddRel G) _ = q.val
  rw [← hc]
  exact (quotient_eq_step G _ _).mpr (step_symm hd)

noncomputable def incidentQuadEquiv {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, G.edge u z = false) : CanonicalQuad G u ≃ CycleThrough G u :=
  Equiv.ofBijective (canonicalClass G u hu)
    ⟨canonicalClass_injective G u hu,canonicalClass_surjective G u hu⟩

theorem isolated_incidence_row_sum {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, G.edge u z = false) :
    Nat.card (CycleThrough G u) =
      ∑ w : Fin n, rowDegree (deleteVertex G u) w *
        (n-1-rowDegree (deleteVertex G u) w) := by
  rw [← Nat.card_congr (incidentQuadEquiv G u hu),canonical_quad_card]
#print axioms incidentQuadEquiv
#print axioms isolated_incidence_row_sum
end Frustrated
