import SparseUpper
namespace Frustrated
/-- The odd-complement obstruction uses the total AMBIENT cycle lower bound. -/
theorem odd_complement_sparse_exclusion {n k M s} (hk : 3 ≤ k)
    (ho : k%2 ≠ 0) (hn : 2*k ≤ n)
    (hlarge : (2^k*(2*k))*(M+s) < n^2)
    (G : Graph (Fin n)) (hM : (graphEdges (complement G)).card ≤ M)
    (hthreshold : cycleCount n k G < cycleCount n k (star n s)) : False := by
  have hG : cycleCount n k G < s*n^(k-2) :=
    hthreshold.trans_le (star_cycle_upper hk)
  have hE : cycleCount n k (complement G) ≤ M*n^(k-2) :=
    (sparse_cycle_upper hk (complement G)).trans (Nat.mul_le_mul_right _ hM)
  have hsum := complement_odd_cycleCount hk ho G
  have htotal := total_cycle_dominates_sparse hk hn hlarge
  nlinarith

/-- A single explicit sufficient order threshold, independent of the graph. -/
theorem odd_complement_eventual_exclusion {k M s} (hk : 3 ≤ k) :
    ∃ N, ∀ n, N ≤ n → ∀ G : Graph (Fin n), k%2 ≠ 0 →
      (graphEdges (complement G)).card ≤ M →
      cycleCount n k G < cycleCount n k (star n s) → False := by
  let N := max (2*k) ((2^k*(2*k))*(M+s)+1)
  refine ⟨N,?_⟩
  intro n hn G ho hM hthreshold
  have hkn : 2*k ≤ n := le_trans (le_max_left _ _) hn
  have hdn : (2^k*(2*k))*(M+s)+1 ≤ n := le_trans (le_max_right _ _) hn
  have hnpos : 0<n := by omega
  have hn2 : n ≤ n^2 := by nlinarith
  exact odd_complement_sparse_exclusion hk ho hkn (by omega) G hM hthreshold
#print axioms odd_complement_eventual_exclusion
end Frustrated
