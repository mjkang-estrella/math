import DisjointPositions
import Mathlib.Tactic.Ring
namespace Frustrated
abbrev DisjointRooted {n m} (q : Ambient n 4) :=
  {c : Ambient n (4+m) // c 0=q 0 ∧ c 1=q 1 ∧ HasCyclePair c (q 2) (q 3)}
abbrev DisjointData {n m} (q : Ambient n 4) :=
  (b : Bool) × (j : Fin (1+m)) × FixedPositions (disjointPositions b j) q

theorem disjoint_constraints {n m} (q : Ambient n 4) (b : Bool)
    (j : Fin (1+m)) (c : Ambient n (4+m)) :
    (∀ i, c (disjointPositions b j i)=q i) ↔
      c 0=q 0 ∧ c 1=q 1 ∧
        (if b then c (disjointEnd j)=q 2 ∧ c (disjointStart j)=q 3
        else c (disjointStart j)=q 2 ∧ c (disjointEnd j)=q 3) := by
  constructor
  · intro h
    have h₀ := h 0
    have h₁ := h 1
    have h₂ := h 2
    have h₃ := h 3
    cases b <;> simpa [disjointPositions,disjointPositionFn] using
      And.intro h₀ (And.intro h₁ (And.intro h₂ h₃))
  · intro h i
    cases b <;> fin_cases i
    all_goals simp only [Bool.false_eq_true,ite_false,ite_true] at h
    all_goals simp [disjointPositions,disjointPositionFn,h.1,h.2.1,h.2.2.1,h.2.2.2]

noncomputable def disjointForget {n m} (q : Ambient n 4)
    (p : DisjointData (m:=m) q) : DisjointRooted (m:=m) q := by
  obtain ⟨b,j,c⟩ := p
  have h := (disjoint_constraints q b j c.val).mp c.property
  refine ⟨c.val,h.1,h.2.1,disjointStart j,?_⟩
  rw [disjoint_next]
  cases b
  · simp only [Bool.false_eq_true,ite_false] at h
    rw [h.2.2.1,h.2.2.2]
  · simp only [ite_true] at h
    rw [h.2.2.1,h.2.2.2,Sym2.eq_swap]

theorem disjointForget_bijective {n m} (q : Ambient n 4) :
    Function.Bijective (disjointForget (m:=m) q) := by
  constructor
  · rintro ⟨b,j,c⟩ ⟨d,l,e⟩ hh
    have he : c.val=e.val := congrArg Subtype.val hh
    have h := (disjoint_constraints q b j c.val).mp c.property
    have h' := (disjoint_constraints q d l e.val).mp e.property
    have hj : cycleEdge c.val (disjointStart j)=s(q 2,q 3) := by
      change s(c.val (disjointStart j),c.val (nextIndex (disjointStart j)))=_
      unfold nextIndex
      rw [succ_as_add,disjoint_next]
      cases b <;> simp_all [Sym2.eq_swap]
    have hl : cycleEdge c.val (disjointStart l)=s(q 2,q 3) := by
      rw [he]
      change s(e.val (disjointStart l),e.val (nextIndex (disjointStart l)))=_
      unfold nextIndex
      rw [succ_as_add,disjoint_next]
      cases d <;> simp_all [Sym2.eq_swap]
    have hjl := cycleEdge_injective (by omega : 3 ≤ 4+m) c.val (hj.trans hl.symm)
    have hjl' : j=l := by
      apply Fin.ext
      have hv := congrArg Fin.val hjl
      change j.val+2=l.val+2 at hv
      omega
    subst l
    have hbd : b=d := by
      cases b <;> cases d <;> try rfl
      all_goals
        simp only [Bool.false_eq_true,ite_false,ite_true] at h h'
        have h23 : q 2=q 3 := by
          first
          | exact h.2.2.1.symm.trans ((congrArg (fun x : Ambient n (4+m) => x (disjointStart j)) he).trans h'.2.2.2)
          | exact h'.2.2.1.symm.trans ((congrArg (fun x : Ambient n (4+m) => x (disjointStart j)) he.symm).trans h.2.2.2)
        have hv := congrArg Fin.val (q.injective h23)
        norm_num at hv
    subst d
    have hce : c=e := Subtype.ext he
    subst e
    rfl
  · intro c
    obtain ⟨j,hj | hj⟩ := disjoint_slots c.val q c.property.1 c.property.2.1 c.property.2.2
    · let e : FixedPositions (disjointPositions false j) q :=
        ⟨c.val,(disjoint_constraints q false j c.val).mpr ⟨c.property.1,c.property.2.1,hj⟩⟩
      exact ⟨⟨false,j,e⟩,Subtype.ext rfl⟩
    · let e : FixedPositions (disjointPositions true j) q :=
        ⟨c.val,(disjoint_constraints q true j c.val).mpr ⟨c.property.1,c.property.2.1,hj.2,hj.1⟩⟩
      exact ⟨⟨true,j,e⟩,Subtype.ext rfl⟩
theorem disjoint_rooted_count {n m} (q : Ambient n 4) :
    Nat.card (DisjointRooted (m:=m) q) = 2*(1+m)*(n-4).descFactorial m := by
  rw [← Nat.card_congr (Equiv.ofBijective _ (disjointForget_bijective (m:=m) q))]
  classical
  have hc (b : Bool) (j : Fin (1+m)) :
      Fintype.card (FixedPositions (disjointPositions b j) q) = (n-4).descFactorial m := by
    rw [← Nat.card_eq_fintype_card]
    exact disjoint_position_card q b j
  simp [DisjointData,hc,two_mul]
  ring

abbrev DisjointTuples {n m} (q : Ambient n 4) :=
  {c : Ambient n (4+m) // HasCyclePair c (q 0) (q 1) ∧ HasCyclePair c (q 2) (q 3)}

noncomputable def disjointPlacement {n m} (q : Ambient n 4)
    (p : (Bool × Fin (4+m)) × DisjointRooted (m:=m) q) : DisjointTuples (m:=m) q := by
  have h : HasCyclePair p.2.val (q 0) (q 1) := by
    refine ⟨0,?_⟩
    simp only [zero_add,p.2.property.1,p.2.property.2.1]
  let e := orbitMap p.2.val p.1
  exact ⟨e.val,pair_step _ _ e.property _ _ h,
    pair_step _ _ e.property _ _ p.2.property.2.2⟩

theorem disjointPlacement_bijective {n m} (q : Ambient n 4) :
    Function.Bijective (disjointPlacement (m:=m) q) := by
  constructor
  · rintro ⟨p,c⟩ ⟨r,d⟩ h
    have he : (orbitMap c.val p).val=(orbitMap d.val r).val := congrArg Subtype.val h
    have hc : dihedralStep c.val d.val :=
      step_trans (orbitMap c.val p).property
        (he ▸ step_symm (orbitMap d.val r).property)
    have hcd : c=d := Subtype.ext (two_point_orbit_unique (by omega) c.val d.val
      (d.property.1.trans c.property.1.symm)
      (d.property.2.1.trans c.property.2.1.symm) hc)
    subst d
    have hpr : p=r := (orbitMap_bijective (by omega) c.val).1 (Subtype.ext he)
    subst r
    rfl
  · intro c
    let q01 : Ambient n 2 :=
      ⟨fun i => q (Fin.castLE (by omega : 2≤4) i),q.injective.comp (Fin.castLE_injective (by omega : 2≤4))⟩
    have h01 : HasCyclePair c.val (q01 0) (q01 1) := by
      change HasCyclePair c.val (q 0) (q 1)
      exact c.property.1
    obtain ⟨d,hd,h₀,h₁⟩ := singleton_normalize c.val q01 h01
    have hd0 : d 0=q 0 := h₀
    have hd1 : d 1=q 1 := h₁
    let e : DisjointRooted (m:=m) q :=
      ⟨d,hd0,hd1,pair_step _ _ hd _ _ c.property.2⟩
    obtain ⟨p,hp⟩ := (orbitMap_bijective (by omega) d).2 ⟨c.val,step_symm hd⟩
    refine ⟨(p,e),?_⟩
    apply Subtype.ext
    change (orbitMap d p).val=c.val
    exact congrArg Subtype.val hp

theorem disjoint_tuple_count {n m} (q : Ambient n 4) :
    Nat.card (DisjointTuples (m:=m) q) = 4*(4+m)*(1+m)*(n-4).descFactorial m := by
  rw [← Nat.card_congr (Equiv.ofBijective _ (disjointPlacement_bijective (m:=m) q))]
  rw [Nat.card_prod,Nat.card_prod,disjoint_rooted_count]
  simp only [Nat.card_eq_fintype_card,Fintype.card_bool,Fintype.card_fin]
  ring

theorem disjoint_completion_count {n m} (q : Ambient n 4) :
    Nat.card {c : Ambient n (4+m) //
      ({s(q 0,q 1),s(q 2,q 3)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c} =
      4*(4+m)*(1+m)*(n-4).descFactorial m := by
  classical
  have he : (fun c : Ambient n (4+m) =>
      ({s(q 0,q 1),s(q 2,q 3)} : Finset (Sym2 (Fin n))) ⊆ cycleSupport c) =
      (fun c => HasCyclePair c (q 0) (q 1) ∧ HasCyclePair c (q 2) (q 3)) := by
    funext c
    apply propext
    simp [support_definition_bridge,Finset.insert_subset_iff,pair_iff_support]
  change Nat.card (Subtype _) = _
  rw [he]
  exact disjoint_tuple_count q
#print axioms disjoint_completion_count
#print axioms disjointForget_bijective
end Frustrated
