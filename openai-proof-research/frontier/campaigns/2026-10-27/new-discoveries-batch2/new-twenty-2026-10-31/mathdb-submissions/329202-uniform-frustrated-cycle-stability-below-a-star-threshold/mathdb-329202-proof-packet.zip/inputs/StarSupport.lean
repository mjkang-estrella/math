import CycleDegreeBound
namespace Frustrated

theorem star_edge_zero {n s} [NeZero n] (e : Sym2 (Fin n))
    (he : e ∈ graphEdges (star n s)) : (0 : Fin n) ∈ e := by
  classical
  induction e using Sym2.inductionOn with
  | _ a b =>
    have h := (Finset.mem_filter.mp he).2
    change decide ((a.val=0 ∧ 1≤b.val ∧ b.val≤s) ∨
      (b.val=0 ∧ 1≤a.val ∧ a.val≤s))=true at h
    have hh := of_decide_eq_true h
    rw [Sym2.mem_iff]
    rcases hh with hh | hh
    · left
      apply Fin.ext
      simpa using hh.1.symm
    · right
      apply Fin.ext
      simpa using hh.1.symm

theorem star_cycle_support_card {n k s} [NeZero k] [NeZero n]
    (c : Ambient n k) : (graphEdges (star n s) ∩ cycleSupport c).card ≤ 2 := by
  classical
  have hs : graphEdges (star n s) ∩ cycleSupport c ⊆
      (cycleSupport c).filter (fun e => (0:Fin n) ∈ e) := by
    intro e he
    have hh := Finset.mem_inter.mp he
    exact Finset.mem_filter.mpr ⟨hh.2,star_edge_zero e hh.1⟩
  exact (Finset.card_le_card hs).trans (cycle_incident_card_le_two c 0)

theorem star_higher_completion_zero {n k s} (hk : 3≤k)
    (F : Finset (Sym2 (Fin n))) (hF : F ⊆ graphEdges (star n s)) (hcard : 3≤F.card) :
    tupleCompletions (k:=k) F=0 := by
  classical
  have he : IsEmpty {c : Ambient n k // F ⊆ cycleSupport c} := by
    constructor
    rintro ⟨c,hc⟩
    have hkn : k≤n := by
      simpa only [Fintype.card_fin] using Fintype.card_le_of_injective c c.injective
    let : NeZero n := ⟨by omega⟩
    let : NeZero k := ⟨by omega⟩
    have hs : F ⊆ graphEdges (star n s) ∩ cycleSupport c :=
      fun e he => Finset.mem_inter.mpr ⟨hF he,hc he⟩
    have hh := (Finset.card_le_card hs).trans (star_cycle_support_card c)
    omega
  let := he
  exact Nat.card_of_isEmpty
#print axioms star_higher_completion_zero
end Frustrated
