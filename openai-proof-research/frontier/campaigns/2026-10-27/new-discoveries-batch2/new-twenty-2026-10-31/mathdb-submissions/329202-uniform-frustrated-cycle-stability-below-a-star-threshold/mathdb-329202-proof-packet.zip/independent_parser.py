import re,json,hashlib,subprocess,sys,base64
from pathlib import Path

def write(p,b):
 r=subprocess.run([sys.executable,'-I','-B','write_lane.py',p,'--base64'],input=base64.b64encode(b).decode(),text=True,capture_output=True);assert r.returncode==0,r.stderr

def digest(b):return hashlib.sha256(b).hexdigest()
idx=json.loads(Path('inputs/EXPECTED-SOURCES.json').read_text())
expected={x['module']:x for x in idx['modules']}
assert len(expected)==idx['module_count']==60
for n,x in expected.items():
 assert re.fullmatch('[A-Za-z][A-Za-z0-9_]*',n)
 assert x['owned_copy']=='inputs/'+n+'.lean'
preamble=b'# Literal production Lean dependency closure v5\n\nAll local imports needed by AuditV5, in build order. Upstream standard Lean/mathlib plus eight libraries are read-only and pinned in PINS.json. No failed version is in this appendix.\n\n'
def parse(data):
 assert data.startswith(preamble),'preamble'
 pos=len(preamble);out={};order=[]
 while pos<len(data):
  m=re.match(rb'<!-- LEAN-SOURCE-BEGIN ([A-Za-z][A-Za-z0-9_]*) SHA256 ([0-9a-f]{64}) BYTES (0|[1-9][0-9]*) -->\n```lean\n',data[pos:]);assert m,'header'
  n=m[1].decode();assert n in expected and n not in out,'name'
  x=expected[n];assert m[2].decode()==x['sha256'] and int(m[3])==x['bytes'],'forged header'
  pos+=m.end();body=data[pos:pos+x['bytes']];assert len(body)==x['bytes'] and digest(body)==x['sha256'],'body'
  assert body==Path(x['owned_copy']).read_bytes(),'owned copy'
  pos+=x['bytes'];end=b'```\n<!-- LEAN-SOURCE-END '+m[1]+b' -->\n'
  assert data[pos:pos+len(end)]==end,'end';pos+=len(end)
  out[n]=body;order.append(n)
  if pos<len(data):assert data[pos:pos+1]==b'\n','separator';pos+=1;assert pos<len(data),'trailing'
 assert set(out)==set(expected),'coverage'
 return out,order

def lex(s):
 # Strip nested comments and strings while preserving positions and lines.
 a=list(s);i=0;depth=0;string=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i):a[i:i+2]=[' ',' '];depth+=1;i+=2
   elif s.startswith('-/',i):a[i:i+2]=[' ',' '];depth-=1;i+=2
   else:
    if s[i]!='\n':a[i]=' '
    i+=1
  elif string:
   if s[i]=='\\':a[i]=' ';i+=1
   elif s[i]=='"':string=False
   if i<len(s) and s[i]!='\n':a[i]=' '
   i+=1
  elif s.startswith('/-',i):a[i:i+2]=[' ',' '];depth=1;i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);j=len(s) if j<0 else j;a[i:j]=[' ']*(j-i);i=j
  elif s[i]=='"':a[i]=' ';string=True;i+=1
  else:i+=1
 assert not depth and not string
 return ''.join(a)

raw=Path('inputs/LEAN-SOURCE-APPENDIX-v5.md').read_bytes();sources,order=parse(raw)
# Independent adversarial parser tests; no production mutation.
first=order[0];start=len(preamble);bodypos=raw.index(b'```lean\n')+8
neg={
'body-alteration':raw[:bodypos]+bytes([raw[bodypos]^1])+raw[bodypos+1:],
'forged-header':raw.replace(expected[first]['sha256'].encode(),b'0'*64,1),
'unsafe-name':raw.replace(b'BEGIN Pilot ',b'BEGIN ../Pilot ',1),
'unknown-name':raw.replace(b'BEGIN Pilot ',b'BEGIN Unknown ',1),
'mismatched-end':raw.replace(b'END Pilot',b'END Bridge',1),
'missing':preamble,
'duplicate':raw+b'\n'+raw[start:raw.index(b'<!-- LEAN-SOURCE-BEGIN Bridge')-1],
'bad-fence':raw.replace(b'```lean',b'```Lean',1),
'trailing':raw+b'junk',
}
for name,b in neg.items():
 try:parse(b)
 except (AssertionError,ValueError):pass
 else:raise AssertionError('accepted '+name)
mp=json.loads(Path('inputs/THEOREM-DEPENDENCY-MAP-v5.json').read_text());mapped={x['module']:x for x in mp['modules']}
assert set(mapped)==set(expected) and order==mp['build_order']
seen=set();imports={};declarations=[]
for n in order:
 b=sources[n];s=b.decode();clean=lex(s)
 assert not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide|implemented_by|extern)\b',clean),(n,'forbidden')
 for e in re.findall(r'^\s*#eval\s+([^\n]+)',clean,re.M):assert e.strip()=='Lean.versionString',(n,e)
 im=re.findall(r'^import\s+(\S+)\s*$',clean,re.M);imports[n]=im
 assert im==mapped[n]['imports'] and digest(b)==mapped[n]['source_sha256'] and len(b)==mapped[n]['bytes']
 for m in im:
  assert m!='Mathlib'
  assert m in seen or (m.startswith('Mathlib.') and re.fullmatch(r'Mathlib(?:\.[A-Za-z0-9_]+)+',m)),(n,m)
 seen.add(n)
 # Capture all local command headers; preserve source text for review.
 matches=list(re.finditer(r'^(?:(?:noncomputable|private|protected|abbrev)\s+)*(?:def|abbrev|structure|theorem|lemma|instance)\b',clean,re.M))
 for m in matches:
  end=clean.find(':=',m.start());end2=clean.find(' where',m.start())
  limits=[q for q in [end,end2] if q>=0];q=min(limits) if limits else clean.find('\n',m.start())
  declarations.append(f'{n}:{s.count(chr(10),0,m.start())+1}\n'+s[m.start():q]+'\n')
for n,b in sources.items():write('src/'+n+'.lean',b)
write('independent-declarations.txt','\n'.join(declarations).encode())
write('source-index.json',json.dumps({'appendix_sha256':digest(raw),'expected_index_sha256':digest(Path('inputs/EXPECTED-SOURCES.json').read_bytes()),'order':order,'imports':imports,'sources':expected,'negative_controls':list(neg)},indent=2).encode())
print('Strict parser PASS; 60 exact owned/index/map bindings; 9 negative controls rejected; topological import closure PASS; comment-aware command scan PASS.')
