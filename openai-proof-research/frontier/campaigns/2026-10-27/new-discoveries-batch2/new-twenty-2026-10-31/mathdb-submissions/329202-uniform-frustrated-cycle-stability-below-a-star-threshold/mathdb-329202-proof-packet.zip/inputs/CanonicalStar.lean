import RelabelledStar
namespace Frustrated

theorem canonical_star_edge_card {n s : Nat} (hn : s+1 ≤ n) :
    (graphEdges (star n s)).card = s := by
  classical
  let z : Fin n := ⟨0,by omega⟩
  let leaf : Fin s → Fin n := fun i => ⟨i.val+1,by omega⟩
  let f : Fin s → Sym2 (Fin n) := fun i => s(z,leaf i)
  have hf : Function.Injective f := by
    intro i j h
    rcases Sym2.eq_iff.mp h with h | h
    · apply Fin.ext
      have hh := congrArg Fin.val h.2
      change i.val+1=j.val+1 at hh
      omega
    · have hh := congrArg Fin.val h.1
      change 0=j.val+1 at hh
      omega
  have he : graphEdges (star n s) = Finset.univ.image f := by
    ext e
    induction e using Sym2.inductionOn with
    | _ a b =>
      constructor
      · intro h
        have hh := (Finset.mem_filter.mp h).2
        change decide ((a.val=0 ∧ 1≤b.val ∧ b.val≤s) ∨ (b.val=0 ∧ 1≤a.val ∧ a.val≤s))=true at hh
        rcases of_decide_eq_true hh with hh | hh
        · let i : Fin s := ⟨b.val-1,by omega⟩
          have ha : a=z := Fin.ext hh.1
          have hb : b=leaf i := by apply Fin.ext; dsimp [leaf,i]; omega
          exact Finset.mem_image.mpr ⟨i,Finset.mem_univ _,by simp only [f,← ha,← hb]⟩
        · let i : Fin s := ⟨a.val-1,by omega⟩
          have hb : b=z := Fin.ext hh.1
          have ha : a=leaf i := by apply Fin.ext; dsimp [leaf,i]; omega
          exact Finset.mem_image.mpr ⟨i,Finset.mem_univ _,by
            change s(z,leaf i)=s(a,b)
            rw [← hb,← ha]
            exact Sym2.eq_swap⟩
      · intro h
        obtain ⟨i,hi,heq⟩ := Finset.mem_image.mp h
        rw [← heq]
        apply Finset.mem_filter.mpr
        refine ⟨Finset.mem_univ _,?_⟩
        change decide ((z.val=0 ∧ 1≤(leaf i).val ∧ (leaf i).val≤s) ∨
          ((leaf i).val=0 ∧ 1≤z.val ∧ z.val≤s))=true
        apply decide_eq_true
        left
        dsimp [z,leaf]
        exact ⟨rfl,by omega,by omega⟩
  rw [he,Finset.card_image_of_injective _ hf]
  simp

theorem canonical_star_formula {n s m : Nat} (hn : s+1 ≤ n) :
    (cycleCount n (3+m) (star n s) : Int) =
      (s:Int)*(n-2).descFactorial (1+m) - 2*(s.choose 2 : Int)*(n-3).descFactorial m := by
  let : NeZero n := ⟨by omega⟩
  have h := relabelled_star_formula (m:=m) (star n s) (0:Fin n) (fun e he => star_edge_zero e he)
  rw [canonical_star_edge_card hn] at h
  exact h
#print axioms canonical_star_edge_card
#print axioms canonical_star_formula
end Frustrated
