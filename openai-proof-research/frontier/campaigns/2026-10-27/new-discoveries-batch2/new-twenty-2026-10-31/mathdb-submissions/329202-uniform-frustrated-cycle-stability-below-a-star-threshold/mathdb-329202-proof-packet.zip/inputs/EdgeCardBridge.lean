import SharpThreshold
namespace Frustrated

theorem graphEdges_card_eq_edgeCount {n} (G : Graph (Fin n)) :
    (graphEdges G).card=edgeCount G := by
  classical
  let f : EdgePair G → {e // e ∈ graphEdges G} := fun p =>
    ⟨s(p.val.1,p.val.2),Finset.mem_filter.mpr ⟨Finset.mem_univ _,p.property.2⟩⟩
  have hf : Function.Injective f := by
    intro p q h
    have hh : s(p.val.1,p.val.2)=s(q.val.1,q.val.2) := congrArg Subtype.val h
    rcases Sym2.eq_iff.mp hh with hh | hh
    · apply Subtype.ext
      exact Prod.ext hh.1 hh.2
    · have hp := p.property.1
      have hq := q.property.1
      rw [hh.1,hh.2] at hp
      exact (lt_asymm hp hq).elim
  have hs : Function.Surjective f := by
    rintro ⟨e,he⟩
    induction e using Sym2.inductionOn with
    | _ a b =>
      have hh := (Finset.mem_filter.mp he).2
      change G.edge a b=true at hh
      have hab : a≠b := by intro h; subst b; rw [G.loopless] at hh; contradiction
      rcases lt_or_gt_of_ne hab with hab | hba
      · refine ⟨⟨(a,b),hab,hh⟩,?_⟩
        apply Subtype.ext
        rfl
      · have hh' : G.edge b a=true := by rw [G.symm]; exact hh
        refine ⟨⟨(b,a),hba,hh'⟩,?_⟩
        apply Subtype.ext
        exact Sym2.eq_swap
  have h := Nat.card_congr (Equiv.ofBijective f ⟨hf,hs⟩)
  simpa only [Nat.card_eq_fintype_card,Fintype.card_coe,edgeCount] using h.symm
#print axioms graphEdges_card_eq_edgeCount
end Frustrated
