import UnorderedRows
import Mathlib.Data.Fin.VecNotation
import Mathlib.Data.Fin.SuccPred
namespace Frustrated
def deleteVertex {n} (G : Graph (Fin (n+1))) (u : Fin (n+1)) : Graph (Fin n) where
  edge a b := G.edge (u.succAbove a) (u.succAbove b)
  symm a b := G.symm (u.succAbove a) (u.succAbove b)
  loopless a := G.loopless (u.succAbove a)
/-- Root fixed at u, with reversal resolved by putting the neighbor first. -/
abbrev CanonicalQuad {n} (G : Graph (Fin (n+1))) (u : Fin (n+1)) :=
  {c : Ambient (n+1) 4 // c 0 = u ∧ G.edge (c 2) (c 1) = true ∧
    G.edge (c 2) (c 3) = false}
def mixedTuple {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (p : RowMixed (deleteVertex G u)) : Ambient (n+1) 4 := by
  let v := p.2.1
  let x := p.2.2
  have hv := v.property.1
  have hx := x.property.1
  have hvx := mixed_vertices_distinct (deleteVertex G u) p.1 v x
  refine ⟨![u,u.succAbove v.val,u.succAbove p.1,u.succAbove x.val], ?_⟩
  intro i j h
  fin_cases i <;> fin_cases j <;>
    simp_all [Fin.succAbove_ne, Fin.ne_succAbove]
def mixedCanonical {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (p : RowMixed (deleteVertex G u)) : CanonicalQuad G u :=
  ⟨mixedTuple G u p, by
    exact ⟨rfl,p.2.1.property.2,p.2.2.property.2⟩⟩

theorem mixedCanonical_injective {n} (G : Graph (Fin (n+1))) (u : Fin (n+1)) :
    Function.Injective (mixedCanonical G u) := by
  intro p q h
  have he := congrArg (fun c : CanonicalQuad G u => c.val 2) h
  have hw : p.1 = q.1 := Fin.succAbove_right_injective (by exact he)
  cases p with | mk w p =>
    cases q with | mk z q =>
      dsimp at hw
      subst z
      apply Sigma.mk.inj_iff.mpr
      refine ⟨rfl, ?_⟩
      apply heq_of_eq
      apply Prod.ext
      · apply Subtype.ext
        apply Fin.succAbove_right_injective (p := u)
        exact congrArg (fun c : CanonicalQuad G u => c.val 1) h
      · apply Subtype.ext
        apply Fin.succAbove_right_injective (p := u)
        exact congrArg (fun c : CanonicalQuad G u => c.val 3) h

theorem mixedCanonical_surjective {n} (G : Graph (Fin (n+1))) (u : Fin (n+1)) :
    Function.Surjective (mixedCanonical G u) := by
  intro c
  have h1 : c.val 1 ≠ u := by
    intro h
    have hh := c.val.injective (h.trans c.property.1.symm)
    have : (1 : Fin 4) ≠ 0 := by decide
    exact this hh
  have h2 : c.val 2 ≠ u := by
    intro h
    have hh := c.val.injective (h.trans c.property.1.symm)
    have : (2 : Fin 4) ≠ 0 := by decide
    exact this hh
  have h3 : c.val 3 ≠ u := by
    intro h
    have hh := c.val.injective (h.trans c.property.1.symm)
    have : (3 : Fin 4) ≠ 0 := by decide
    exact this hh
  obtain ⟨v,hv⟩ := Fin.exists_succAbove_eq h1
  obtain ⟨w,hw⟩ := Fin.exists_succAbove_eq h2
  obtain ⟨x,hx⟩ := Fin.exists_succAbove_eq h3
  have hvw : v ≠ w := by
    intro h
    have hh : c.val 1 = c.val 2 := by rw [← hv, ← hw,h]
    have := c.val.injective hh
    contradiction
  have hxw : x ≠ w := by
    intro h
    have hh : c.val 3 = c.val 2 := by rw [← hx, ← hw,h]
    have := c.val.injective hh
    contradiction
  let p : RowMixed (deleteVertex G u) := ⟨w,
    ⟨⟨v,hvw,by simpa [deleteVertex,hw,hv] using c.property.2.1⟩,
     ⟨x,hxw,by simpa [deleteVertex,hw,hx] using c.property.2.2⟩⟩⟩
  refine ⟨p, Subtype.ext ?_⟩
  apply DFunLike.ext
  intro i
  fin_cases i <;> simp [mixedCanonical,mixedTuple,p,hv,hw,hx,c.property.1]

noncomputable def canonicalQuadEquiv {n} (G : Graph (Fin (n+1))) (u : Fin (n+1)) :
    RowMixed (deleteVertex G u) ≃ CanonicalQuad G u :=
  Equiv.ofBijective (mixedCanonical G u)
    ⟨mixedCanonical_injective G u,mixedCanonical_surjective G u⟩

theorem canonical_quad_card {n} (G : Graph (Fin (n+1))) (u : Fin (n+1)) :
    Nat.card (CanonicalQuad G u) =
      ∑ w : Fin n, rowDegree (deleteVertex G u) w *
        (n-1-rowDegree (deleteVertex G u) w) := by
  rw [← Nat.card_congr (canonicalQuadEquiv G u),row_mixed_card]

theorem canonical_is_frustrated {n} (G : Graph (Fin (n+1))) (u : Fin (n+1))
    (hu : ∀ z, G.edge u z = false) (c : CanonicalQuad G u) :
    tupleOdd G c.val := by
  rw [tupleOdd_list]
  change cycleParity G (List.ofFn c.val) = true
  have hl : List.ofFn c.val = [c.val 0,c.val 1,c.val 2,c.val 3] := by
    simp [List.ofFn_succ]
  rw [hl,c.property.1,isolated_quadrilateral G u _ _ _ hu,
    c.property.2.1,c.property.2.2]
  rfl
#print axioms canonicalQuadEquiv
#print axioms canonical_quad_card
#print axioms canonical_is_frustrated
end Frustrated
