import CanonicalStar
namespace Frustrated
attribute [local instance] Classical.propDecidable

theorem oversized_completion_zero {n k : Nat} (hk : 3 ≤ k)
    (F : Finset (Sym2 (Fin n))) (hcard : k < F.card) : tupleCompletions (k:=k) F=0 := by
  classical
  have he : IsEmpty {c : Ambient n k // F ⊆ cycleSupport c} := by
    constructor
    rintro ⟨c,hc⟩
    have hh := Finset.card_le_card hc
    rw [cycleSupport_card hk c] at hh
    omega
  let := he
  exact Nat.card_of_isEmpty

theorem disjoint_completion_zero_three {n} (F : Finset (Sym2 (Fin n)))
    (hd : ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f) : tupleCompletions (k:=3) F=0 := by
  classical
  have he : IsEmpty {c : Ambient n 3 // F ⊆ cycleSupport c} := by
    constructor
    rintro ⟨c,hc⟩
    have hl : ∀ a, s(a,a) ∉ F := fun a ha => support_loopless (by omega) c a (hc ha)
    obtain ⟨q,hq⟩ := disjoint_incident_four F hl hd
    have hx (i : Fin 4) : ∃ j, c j=q i := by
      obtain ⟨e,he,hv⟩ := hq i
      exact cycle_support_vertex c e (hc he) (q i) hv
    let j : Fin 4 → Fin 3 := fun i => Classical.choose (hx i)
    have hj (i : Fin 4) : c (j i)=q i := Classical.choose_spec (hx i)
    have hinj : Function.Injective j := by
      intro a b h
      apply q.injective
      rw [← hj a,← hj b,h]
    have hh := Fintype.card_le_of_injective j hinj
    norm_num at hh
  let := he
  exact Nat.card_of_isEmpty

theorem three_remainder_exact {n} (E : Finset (Sym2 (Fin n))) :
    signedRemainder (k:=3) E =
      4*((∑ F ∈ E.powerset.filter (fun F => F.card=3), tupleCompletions (k:=3) F : Nat) : Int) := by
  classical
  unfold signedRemainder badSupports
  rw [Finset.sum_filter,Nat.cast_sum,Finset.mul_sum,Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro F hF
  by_cases h3 : F.card=3
  · simp [h3]
  · by_cases hlarge : 3 < F.card
    · simp [oversized_completion_zero (by omega) F hlarge]
    · by_cases hb : 3 ≤ F.card ∨ ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f
      · have hd : ∃ e ∈ F, ∃ f ∈ F, ¬ EdgeMeets e f := hb.resolve_left (by omega)
        simp [disjoint_completion_zero_three F hd,h3]
      · simp only [hb,ite_false,h3]

theorem three_remainder_nonnegative {n} (E : Finset (Sym2 (Fin n))) :
    0 ≤ signedRemainder (k:=3) E := by
  rw [three_remainder_exact]
  positivity

theorem exact_three_correction {n} (G : Graph (Fin n)) :
    (6:Int)*cycleCount n 3 G =
      ((graphEdges G).card : Int)*(6*((n-2:Nat):Int)) -
      2*((adjacentSupports (graphEdges G)).card : Int)*6 +
      4*((∑ F ∈ (graphEdges G).powerset.filter (fun F => F.card=3), tupleCompletions (k:=3) F : Nat) : Int) := by
  have h := exact_low_remainder_expansion (k:=3) (by omega) G
  rw [low_support_evaluation (m:=0),three_remainder_exact] at h
  simpa [mul_assoc] using h
#print axioms disjoint_completion_zero_three
#print axioms three_remainder_exact
#print axioms exact_three_correction
end Frustrated
