import SubsetExpansion
namespace Frustrated
abbrev OutsidePrefix {n r} (q : Ambient n r) := {v : Fin n // v ∉ Set.range q}
abbrev FixedPrefix {n r} (m : Nat) (q : Ambient n r) :=
  {c : Ambient n (r+m) // ∀ i : Fin r, c (Fin.castAdd m i) = q i}

def joinPrefix {n r m} (q : Ambient n r) (e : Fin m ↪ OutsidePrefix q) :
    FixedPrefix m q := by
  let c : Ambient n (r+m) :=
    { toFun := Fin.addCases q (fun i => (e i).val)
      inj' := by
        intro i j h
        cases i using Fin.addCases with
        | left i =>
          cases j using Fin.addCases with
          | left j =>
            simp only [Fin.addCases_left] at h
            exact congrArg (Fin.castAdd m) (q.injective h)
          | right j =>
            simp only [Fin.addCases_left,Fin.addCases_right] at h
            exact False.elim ((e j).property ⟨i,h⟩)
        | right i =>
          cases j using Fin.addCases with
          | left j =>
            simp only [Fin.addCases_left,Fin.addCases_right] at h
            exact False.elim ((e i).property ⟨j,h.symm⟩)
          | right j =>
            simp only [Fin.addCases_right] at h
            exact congrArg (Fin.natAdd r) (e.injective (Subtype.ext h)) }
  refine ⟨c,?_⟩
  intro i
  change Fin.addCases q (fun j => (e j).val) (Fin.castAdd m i) = q i
  exact Fin.addCases_left i

def tailPrefix {n r m} (q : Ambient n r) (c : FixedPrefix m q) :
    Fin m ↪ OutsidePrefix q where
  toFun i := ⟨c.val (Fin.natAdd r i),by
    rintro ⟨j,hj⟩
    have hh : c.val (Fin.castAdd m j) = c.val (Fin.natAdd r i) :=
      (c.property j).trans hj
    have he := congrArg Fin.val (c.val.injective hh)
    have hj' := j.isLt
    change j.val = r+i.val at he
    omega⟩
  inj' i j h := by
    have hh := c.val.injective (congrArg Subtype.val h)
    have he := congrArg Fin.val hh
    change r+i.val = r+j.val at he
    apply Fin.ext
    omega

def prefixCompletionEquiv {n r m} (q : Ambient n r) :
    (Fin m ↪ OutsidePrefix q) ≃ FixedPrefix m q where
  toFun := joinPrefix q
  invFun := tailPrefix q
  left_inv e := by
    apply Function.Embedding.ext
    intro i
    apply Subtype.ext
    change Fin.addCases q (fun j => (e j).val) (Fin.natAdd r i) = (e i).val
    exact Fin.addCases_right i
  right_inv c := by
    apply Subtype.ext
    apply Function.Embedding.ext
    intro i
    cases i using Fin.addCases with
    | left i =>
      change Fin.addCases q (fun j => c.val (Fin.natAdd r j)) (Fin.castAdd m i) = c.val (Fin.castAdd m i)
      rw [Fin.addCases_left]
      exact (c.property i).symm
    | right i =>
      change Fin.addCases q (fun j => c.val (Fin.natAdd r j)) (Fin.natAdd r i) = c.val (Fin.natAdd r i)
      exact Fin.addCases_right i

theorem outside_prefix_card {n r} (q : Ambient n r) :
    Nat.card (OutsidePrefix q) = n-r := by
  classical
  let : Fintype (OutsidePrefix q) := Fintype.ofFinite _
  rw [Nat.card_eq_fintype_card]
  change Fintype.card {v : Fin n // ¬ v ∈ Set.range q} = n-r
  rw [Fintype.card_subtype_compl]
  have hr : Fintype.card {v : Fin n // v ∈ Set.range q} = r := by
    let e : Fin r ≃ {v : Fin n // v ∈ Set.range q} :=
      Equiv.ofBijective (fun i => ⟨q i,⟨i,rfl⟩⟩)
        ⟨fun i j h => q.injective (congrArg Subtype.val h),by
          rintro ⟨v,⟨i,rfl⟩⟩
          exact ⟨i,rfl⟩⟩
    simpa only [Fintype.card_fin] using (Fintype.card_congr e).symm
  rw [hr,Fintype.card_fin]

theorem fixed_prefix_card {n r m} (q : Ambient n r) :
    Nat.card (FixedPrefix m q) = (n-r).descFactorial m := by
  classical
  let : Fintype (OutsidePrefix q) := Fintype.ofFinite _
  rw [← Nat.card_congr (prefixCompletionEquiv (m := m) q),
    Nat.card_eq_fintype_card,Fintype.card_embedding_eq]
  rw [← Nat.card_eq_fintype_card,outside_prefix_card]
  simp
#print axioms fixed_prefix_card
#print axioms prefixCompletionEquiv
end Frustrated
