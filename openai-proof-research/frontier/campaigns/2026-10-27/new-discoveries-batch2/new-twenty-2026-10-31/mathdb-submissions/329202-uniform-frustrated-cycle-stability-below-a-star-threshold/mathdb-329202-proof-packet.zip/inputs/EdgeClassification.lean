import SupportEventBound
namespace Frustrated
def EdgeMeets {V : Type} (e f : Sym2 V) : Prop := ∃ v, v ∈ e ∧ v ∈ f

theorem meets_pair_iff {V : Type} (e : Sym2 V) (a b : V) :
    EdgeMeets e s(a,b) ↔ a ∈ e ∨ b ∈ e := by
  constructor
  · rintro ⟨v,hv,hab⟩
    rcases Sym2.mem_iff.mp hab with rfl | rfl
    · exact Or.inl hv
    · exact Or.inr hv
  · rintro (h | h)
    · exact ⟨a,h,Sym2.mem_mk_left _ _⟩
    · exact ⟨b,h,Sym2.mem_mk_right _ _⟩

theorem meets_triangle_edges {V : Type} [DecidableEq V] (a b c : V)
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) (e : Sym2 V)
    (h₁ : a ∈ e ∨ b ∈ e) (h₂ : a ∈ e ∨ c ∈ e)
    (h₃ : b ∈ e ∨ c ∈ e) :
    e ∈ ({s(a,b),s(a,c),s(b,c)} : Finset (Sym2 V)) := by
  induction e using Sym2.inductionOn with
  | _ x y =>
    simp only [Sym2.mem_iff] at h₁ h₂ h₃
    rcases h₁ with (h₁ | h₁) | (h₁ | h₁) <;>
      rcases h₂ with (h₂ | h₂) | (h₂ | h₂) <;>
      rcases h₃ with (h₃ | h₃) | (h₃ | h₃) <;>
      simp_all [Sym2.eq_swap]

theorem intersecting_edges_star_or_triangle {V : Type} [DecidableEq V]
    (E : Finset (Sym2 V)) (a b c : V)
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (h₁ : s(a,b) ∈ E) (h₂ : s(a,c) ∈ E)
    (hE : ∀ e ∈ E, ∀ f ∈ E, EdgeMeets e f) :
    (∀ e ∈ E, a ∈ e) ∨ E = {s(a,b),s(a,c),s(b,c)} := by
  by_cases ha : ∀ e ∈ E, a ∈ e
  · exact Or.inl ha
  · right
    push Not at ha
    obtain ⟨e,he,hae⟩ := ha
    have hb : b ∈ e := ((meets_pair_iff e a b).mp (hE e he _ h₁)).resolve_left hae
    have hc : c ∈ e := ((meets_pair_iff e a c).mp (hE e he _ h₂)).resolve_left hae
    have heq : e=s(b,c) := (Sym2.mem_and_mem_iff hbc).mp ⟨hb,hc⟩
    have h₃ : s(b,c) ∈ E := heq ▸ he
    apply Finset.Subset.antisymm
    · intro f hf
      exact meets_triangle_edges a b c hab hac hbc f
        ((meets_pair_iff f a b).mp (hE f hf _ h₁))
        ((meets_pair_iff f a c).mp (hE f hf _ h₂))
        ((meets_pair_iff f b c).mp (hE f hf _ h₃))
    · intro f hf
      simp only [Finset.mem_insert,Finset.mem_singleton] at hf
      rcases hf with rfl | rfl | rfl
      · exact h₁
      · exact h₂
      · exact h₃
theorem pairwise_intersecting_classification {V : Type} [DecidableEq V]
    (E : Finset (Sym2 V)) (hne : E.Nonempty)
    (hloop : ∀ a, s(a,a) ∉ E)
    (hE : ∀ e ∈ E, ∀ f ∈ E, EdgeMeets e f) :
    (∃ a, ∀ e ∈ E, a ∈ e) ∨
      ∃ a b c, a≠b ∧ a≠c ∧ b≠c ∧ E={s(a,b),s(a,c),s(b,c)} := by
  by_cases hcard : E.card ≤ 1
  · obtain ⟨e,he⟩ := hne
    have rep : ∃ a b, e=s(a,b) := by
      induction e using Sym2.inductionOn with
      | _ a b => exact ⟨a,b,rfl⟩
    obtain ⟨a,b,rfl⟩ := rep
    left
    refine ⟨a,?_⟩
    intro f hf
    rw [(Finset.card_le_one.mp hcard) f hf _ he]
    exact Sym2.mem_mk_left _ _
  · obtain ⟨e,he,f,hf,hef⟩ := Finset.one_lt_card.mp (by omega : 1<E.card)
    obtain ⟨a,hae,haf⟩ := hE e he f hf
    obtain ⟨b,hb⟩ := Sym2.mem_iff_exists.mp hae
    obtain ⟨c,hc⟩ := Sym2.mem_iff_exists.mp haf
    subst e
    subst f
    have hab : a≠b := by intro hh; subst b; exact hloop a he
    have hac : a≠c := by intro hh; subst c; exact hloop a hf
    have hbc : b≠c := by intro hh; subst c; exact hef rfl
    rcases intersecting_edges_star_or_triangle E a b c hab hac hbc he hf hE with h | h
    · exact Or.inl ⟨a,h⟩
    · exact Or.inr ⟨a,b,c,hab,hac,hbc,h⟩
#print axioms pairwise_intersecting_classification
#print axioms intersecting_edges_star_or_triangle
end Frustrated
