import IncidentQuotient
namespace Frustrated
theorem step_vertex_iff {n k} [NeZero k] {c d : Ambient n k}
    (h : dihedralStep c d) (u : Fin n) :
    (∃ i, c i = u) ↔ (∃ i, d i = u) := by
  obtain ⟨r, rfl | rfl⟩ := (dihedralStep_iff c d).mp h
  · constructor
    · rintro ⟨i,hi⟩
      refine ⟨i-r, ?_⟩
      change c (i-r+r) = u
      simpa using hi
    · rintro ⟨i,hi⟩
      exact ⟨i+r,hi⟩
  · constructor
    · rintro ⟨i,hi⟩
      refine ⟨r-i, ?_⟩
      change c (r-(r-i)) = u
      simpa using hi
    · rintro ⟨i,hi⟩
      exact ⟨r-i,hi⟩

abbrev VertexOn {n} (G : Graph (Fin (n+1))) (q : Quot (oddRel (k := 4) G)) :=
  {u : Fin (n+1) // ∃ c : OddTuple (n+1) 4 G,
    Quot.mk (oddRel G) c = q ∧ ∃ i, c.val i = u}

theorem vertexOn_card {n} (G : Graph (Fin (n+1)))
    (q : Quot (oddRel (k := 4) G)) : Nat.card (VertexOn G q) = 4 := by
  induction q using Quot.inductionOn with | h c =>
    have hp (u : Fin (n+1)) :
        (∃ d : OddTuple (n+1) 4 G, Quot.mk (oddRel G) d =
          Quot.mk (oddRel G) c ∧ ∃ i, d.val i = u) ↔ ∃ i, c.val i = u := by
      constructor
      · rintro ⟨d,hd,hv⟩
        exact (step_vertex_iff ((quotient_eq_step G d c).mp hd) u).mp hv
      · intro hv
        exact ⟨c,rfl,hv⟩
    let e : VertexOn G (Quot.mk (oddRel G) c) ≃
        {u : Fin (n+1) // ∃ i, c.val i = u} :=
      Equiv.subtypeEquivRight hp
    let f : Fin 4 → {u : Fin (n+1) // ∃ i, c.val i = u} :=
      fun i => ⟨c.val i,i,rfl⟩
    have hf : Function.Bijective f := by
      constructor
      · intro i j h
        exact c.val.injective (congrArg Subtype.val h)
      · rintro ⟨u,i,hi⟩
        exact ⟨i,Subtype.ext hi⟩
    rw [Nat.card_congr e, ← Nat.card_congr (Equiv.ofBijective f hf)]
    exact Nat.card_fin 4

def swapIncidence {n} (G : Graph (Fin (n+1))) :
    ((u : Fin (n+1)) × CycleThrough G u) ≃
      ((q : Quot (oddRel (k := 4) G)) × VertexOn G q) where
  toFun p := ⟨p.2.val,⟨p.1,p.2.property⟩⟩
  invFun p := ⟨p.2.val,⟨p.1,p.2.property⟩⟩
  left_inv _ := rfl
  right_inv _ := rfl

theorem four_cycle_incidence_sum {n} (G : Graph (Fin (n+1))) :
    (∑ u : Fin (n+1), Nat.card (CycleThrough G u)) =
      4 * cycleCount (n+1) 4 G := by
  classical
  let : Fintype (Quot (oddRel (k := 4) G)) := Fintype.ofFinite _
  rw [← Nat.card_sigma, Nat.card_congr (swapIncidence G),Nat.card_sigma]
  simp only [vertexOn_card,Finset.sum_const,Finset.card_univ,Nat.nsmul_eq_mul]
  rw [mul_comm]
  change 4 * Fintype.card (Quot (oddRel (k := 4) G)) = 4 * Nat.card (Quot (oddRel (k := 4) G))
  rw [Nat.card_eq_fintype_card]

theorem select_four_cycle_vertex {n} (G : Graph (Fin (n+1))) :
    ∃ u : Fin (n+1), (n+1) * Nat.card (CycleThrough G u) ≤
      4 * cycleCount (n+1) 4 G := by
  classical
  by_contra h
  push Not at h
  have hp : ∀ u : Fin (n+1), 4 * cycleCount (n+1) 4 G + 1 ≤
      (n+1) * Nat.card (CycleThrough G u) := by intro u; exact h u
  have hs := Finset.sum_le_sum (fun u (_ : u ∈ (Finset.univ : Finset (Fin (n+1)))) => hp u)
  rw [← Finset.mul_sum,four_cycle_incidence_sum] at hs
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,Nat.nsmul_eq_mul] at hs
  nlinarith
#print axioms four_cycle_incidence_sum
#print axioms select_four_cycle_vertex
end Frustrated
