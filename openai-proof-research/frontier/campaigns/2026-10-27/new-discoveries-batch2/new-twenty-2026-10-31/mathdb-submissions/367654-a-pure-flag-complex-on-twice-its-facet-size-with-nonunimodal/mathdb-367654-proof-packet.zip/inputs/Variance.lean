import Moments

namespace PureFlag
open scoped BigOperators
variable {ι κ : Type*}

theorem centered_second (s : Finset ι) (w x : ι → ℚ) (μ : ℚ) :
    (∑ i ∈ s, (x i - μ)^2 * w i) =
      second s w x - 2*μ*first s w x + μ^2*mass s w := by
  simp only [second, first, mass, Finset.mul_sum, ← Finset.sum_sub_distrib,
    ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem product_centered_variance (s : Finset ι) (t : Finset κ)
    (u x : ι → ℚ) (v y : κ → ℚ)
    (hu : mass s u = 1) (hv : mass t v = 1) :
    (∑ i ∈ s, ∑ j ∈ t,
      (x i + y j - (first s u x + first t v y))^2 * (u i * v j)) =
    (second s u x - (first s u x)^2) +
      (second t v y - (first t v y)^2) := by
  have hex : ∀ i j,
      (x i + y j - (first s u x + first t v y))^2 * (u i * v j) =
      (x i+y j)^2*(u i*v j) -
        2*(first s u x+first t v y)*((x i+y j)*(u i*v j)) +
        (first s u x+first t v y)^2*(u i*v j) := by
    intro i j; ring
  simp_rw [hex]
  simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum]
  rw [product_second, product_first, ← Finset.sum_mul]
  simp only [mass] at hu hv ⊢
  rw [hu, hv]
  ring

#print axioms centered_second
#print axioms product_centered_variance
end PureFlag
