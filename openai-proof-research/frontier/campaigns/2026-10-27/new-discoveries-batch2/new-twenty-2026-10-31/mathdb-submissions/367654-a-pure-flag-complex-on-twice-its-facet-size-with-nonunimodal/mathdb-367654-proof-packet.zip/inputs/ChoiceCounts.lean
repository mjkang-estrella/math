import Choices
import Mathlib.Data.Fintype.BigOperators

namespace PureFlag
variable {I T : Type*} [Fintype I] [Fintype T] [DecidableEq I] [DecidableEq T]

omit [DecidableEq I] in
theorem encode_card (f : I → Option T) :
    (encode f).card = (Finset.univ.filter (fun i => f i ≠ none)).card := by
  apply Finset.card_bij (fun p _ => p.1)
  · intro p hp
    have he := (mem_encode f p.1 p.2).mp hp
    simp [he]
  · intro p hp q hq he
    have h₁ := (mem_encode f p.1 p.2).mp hp
    have h₂ := (mem_encode f q.1 q.2).mp hq
    apply Prod.ext he
    rw [← he] at h₂
    exact Option.some.inj (h₁.symm.trans h₂)
  · intro i hi
    have hn : f i ≠ none := (Finset.mem_filter.mp hi).2
    cases he : f i with
    | none => exact (hn he).elim
    | some t => exact ⟨(i,t), (mem_encode f i t).mpr he, rfl⟩

omit [DecidableEq I] in
theorem encode_none : encode (fun _ : I => (none : Option T)) = ∅ := by
  ext p
  simp [encode]

noncomputable instance partialFintype : Fintype {s : Finset (I × T) // Partial s} :=
  Fintype.ofEquiv (I → Option T) choiceEquiv

theorem partial_count : Fintype.card {s : Finset (I × T) // Partial s} =
    (Fintype.card T + 1) ^ Fintype.card I := by
  rw [← Fintype.card_congr (choiceEquiv (I:=I) (T:=T))]
  simp [Fintype.card_option]

-- Maximality is inclusion maximality of the genuine finite subsets.
def MaxPartial (s : Finset (I × T)) : Prop :=
  Partial s ∧ ∀ t, Partial t → s ⊆ t → t = s

omit [Fintype I] in
theorem maxPartial_full [Nonempty T] (s : Finset (I × T)) (hs : MaxPartial s) :
    ∀ i, ∃ t, (i,t) ∈ s := by
  classical
  intro i
  by_contra hn
  have hnone : ∀ t, (i,t) ∉ s := by simpa using hn
  let x : T := Classical.choice inferInstance
  have hp : Partial (insert (i,x) s) := by
    intro j u v hu hv
    simp only [Finset.mem_insert] at hu hv
    rcases hu with hu | hu <;> rcases hv with hv | hv
    · exact (congrArg Prod.snd hu).trans (congrArg Prod.snd hv).symm
    · have hj : j = i := congrArg Prod.fst hu
      exact (hnone v (by simpa only [hj] using hv)).elim
    · have hj : j = i := congrArg Prod.fst hv
      exact (hnone u (by simpa only [hj] using hu)).elim
    · exact hs.1 j u v hu hv
  have he := hs.2 (insert (i,x) s) hp (Finset.subset_insert _ _)
  have hm : (i,x) ∈ s := by rw [← he]; simp
  exact hnone x hm

theorem maxPartial_card [Nonempty T] (s : Finset (I × T)) (hs : MaxPartial s) :
    s.card = Fintype.card I := by
  have he := encode_decode s hs.1
  rw [← he, encode_card]
  have hf : ∀ i, decode s i ≠ none := by
    intro i
    obtain ⟨t, ht⟩ := maxPartial_full s hs i
    rw [(decode_spec s hs.1 i t).mpr ht]
    simp
  simp [hf]

#print axioms encode_card
#print axioms partial_count
#print axioms maxPartial_card


end PureFlag
