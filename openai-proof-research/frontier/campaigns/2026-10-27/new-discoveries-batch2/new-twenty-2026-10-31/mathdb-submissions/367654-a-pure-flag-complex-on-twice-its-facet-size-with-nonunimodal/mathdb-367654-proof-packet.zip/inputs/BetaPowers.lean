import DegreePushforward
import Moments
namespace PureFlag
open scoped BigOperators
open Polynomial
def betaDegree (t : Bool) : ℕ := if t then 1 else 0
def betaWeight (b : ℚ) (t : Bool) : ℚ := if t then b/(1+b) else 1/(1+b)
abbrev Trials : ℕ → Type
  | 0 => Unit
  | n+1 => Bool × Trials n
instance trialsFintype : (n : ℕ) → Fintype (Trials n)
  | 0 => inferInstanceAs (Fintype Unit)
  | n+1 => @instFintypeProd Bool (Trials n) inferInstance (trialsFintype n)
def trialDegree : (n : ℕ) → Trials n → ℕ
  | 0, _ => 0
  | n+1, t => betaDegree t.1 + trialDegree n t.2
def trialWeight (b : ℚ) : (n : ℕ) → Trials n → ℚ
  | 0, _ => 1
  | n+1, t => betaWeight b t.1 * trialWeight b n t.2

theorem beta_moments (b : ℚ) (hb : 0 ≤ b) :
    mass Finset.univ (betaWeight b) = 1 ∧
    first Finset.univ (betaWeight b) (fun t => (betaDegree t : ℚ)) = b/(1+b) ∧
    second Finset.univ (betaWeight b) (fun t => (betaDegree t : ℚ)) = b/(1+b) := by
  have hn : 1+b ≠ 0 := by linarith
  simp [mass,first,second,betaWeight,betaDegree]
  field_simp
  ring

theorem trial_moments (b : ℚ) (hb : 0 ≤ b) (n : ℕ) :
    mass Finset.univ (trialWeight b n) = 1 ∧
    first Finset.univ (trialWeight b n) (fun t => (trialDegree n t : ℚ)) = (n:ℚ)*(b/(1+b)) ∧
    second Finset.univ (trialWeight b n) (fun t => (trialDegree n t : ℚ)) =
      (n:ℚ)*(b/(1+b)^2) + ((n:ℚ)*(b/(1+b)))^2 := by
  induction n with
  | zero => simp [mass,first,second,trialWeight,trialDegree,Trials]
  | succ n ih =>
    have hbeta := beta_moments b hb
    have hm := product_mass (Finset.univ : Finset Bool) (Finset.univ : Finset (Trials n)) (betaWeight b) (trialWeight b n)
    have hf := product_first (Finset.univ : Finset Bool) (Finset.univ : Finset (Trials n))
      (betaWeight b) (fun t => (betaDegree t : ℚ)) (trialWeight b n) (fun t => (trialDegree n t : ℚ))
    have hs := product_second (Finset.univ : Finset Bool) (Finset.univ : Finset (Trials n))
      (betaWeight b) (fun t => (betaDegree t : ℚ)) (trialWeight b n) (fun t => (trialDegree n t : ℚ))
    rw [hbeta.1,ih.1] at hm
    rw [hbeta.1,hbeta.2.1,ih.1,ih.2.1] at hf
    rw [hbeta.1,hbeta.2.1,hbeta.2.2,ih.1,ih.2.1,ih.2.2] at hs
    have hv := bernoulli_variance b hb
    constructor
    · simpa only [mass,trialWeight,Fintype.sum_prod_type,one_mul] using hm
    constructor
    · simp only [first,trialWeight,trialDegree,Nat.cast_add,Fintype.sum_prod_type]
      rw [hf]
      push_cast
      ring
    · simp only [second,trialWeight,trialDegree,Nat.cast_add,Fintype.sum_prod_type]
      rw [hs]
      push_cast
      nlinarith [hv]

theorem trial_polynomial (b : ℚ) (n : ℕ) :
    degreePoly Finset.univ (trialWeight b n) (trialDegree n) =
      (Polynomial.C (1/(1+b)) + Polynomial.C (b/(1+b))*X)^n := by
  classical
  induction n with
  | zero => simp [degreePoly,trialWeight,trialDegree,Trials]
  | succ n ih =>
    change degreePoly ((Finset.univ : Finset Bool) ×ˢ (Finset.univ : Finset (Trials n)))
      (fun t => betaWeight b t.1 * trialWeight b n t.2)
      (fun t => betaDegree t.1 + trialDegree n t.2) = _
    rw [degreePoly_product,ih]
    change ((∑ t : Bool, C (betaWeight b t) * X^(betaDegree t)) *
      (C (1/(1+b)) + C (b/(1+b))*X)^n) = _
    rw [Fintype.sum_bool]
    norm_num only [betaWeight,betaDegree,Bool.false_eq_true,ite_false,ite_true,pow_zero,pow_one,mul_one]
    rw [pow_succ]
    ring

#print axioms beta_moments
#print axioms trial_moments
#print axioms trial_polynomial
end PureFlag
