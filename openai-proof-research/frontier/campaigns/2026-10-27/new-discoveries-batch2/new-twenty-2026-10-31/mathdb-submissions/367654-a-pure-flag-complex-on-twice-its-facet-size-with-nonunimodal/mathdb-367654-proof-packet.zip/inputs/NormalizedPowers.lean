import BetaPowers
namespace PureFlag
open scoped BigOperators
open Polynomial
noncomputable def trialSupport (n : ℕ) : Finset ℕ := by
  classical
  exact Finset.univ.image (trialDegree n)
noncomputable def betaPower (b : ℚ) (n : ℕ) : ℚ[X] :=
  (C (1/(1+b)) + C (b/(1+b))*X)^n

theorem trialWeight_nonneg (b : ℚ) (hb : 0 ≤ b) (n : ℕ) :
    ∀ t : Trials n, 0 ≤ trialWeight b n t := by
  induction n with
  | zero => intro t; exact zero_le_one
  | succ n ih =>
    intro t
    apply mul_nonneg _ (ih t.2)
    unfold betaWeight
    have hd : 0 ≤ 1+b := by linarith
    split_ifs
    · exact div_nonneg hb hd
    · exact div_nonneg zero_le_one hd

theorem betaPower_coeff_nonneg (b : ℚ) (hb : 0 ≤ b) (n j : ℕ) :
    0 ≤ (betaPower b n).coeff j := by
  rw [betaPower,← trial_polynomial,degreePoly_coeff]
  exact degreeWeight_nonneg _ _ _ (fun i _ => trialWeight_nonneg b hb n i) j

theorem betaPower_support (b : ℚ) (n j : ℕ) (hj : j ∉ trialSupport n) :
    (betaPower b n).coeff j = 0 := by
  classical
  rw [betaPower,← trial_polynomial,degreePoly_coeff]
  exact degreeWeight_outside _ _ _ _ hj

theorem betaPower_moments (b : ℚ) (hb : 0 ≤ b) (n : ℕ) :
    (∑ j ∈ trialSupport n, (betaPower b n).coeff j) = 1 ∧
    (∑ j ∈ trialSupport n, (j:ℚ)*(betaPower b n).coeff j) = (n:ℚ)*(b/(1+b)) ∧
    (∑ j ∈ trialSupport n, (j:ℚ)^2*(betaPower b n).coeff j) =
      (n:ℚ)*(b/(1+b)^2) + ((n:ℚ)*(b/(1+b)))^2 := by
  classical
  have hm := degree_transport Finset.univ (trialWeight b n) (trialDegree n) (fun _ => 1)
  have hf := degree_transport Finset.univ (trialWeight b n) (trialDegree n) (fun j => (j:ℚ))
  have hs := degree_transport Finset.univ (trialWeight b n) (trialDegree n) (fun j => (j:ℚ)^2)
  have h := trial_moments b hb n
  simp only [one_mul] at hm
  simp only [betaPower,← trial_polynomial,degreePoly_coeff,trialSupport]
  exact ⟨hm.trans h.1, hf.trans h.2.1, hs.trans h.2.2⟩

#print axioms trialWeight_nonneg
#print axioms betaPower_coeff_nonneg
#print axioms betaPower_support
#print axioms betaPower_moments
end PureFlag
