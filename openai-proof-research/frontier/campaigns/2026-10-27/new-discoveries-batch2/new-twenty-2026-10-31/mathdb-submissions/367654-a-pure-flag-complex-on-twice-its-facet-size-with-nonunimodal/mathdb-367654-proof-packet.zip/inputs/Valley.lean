import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Data.Finset.Sum

namespace PureFlag
-- A global mode predicate; finite-list/zero-extension transport remains separate.
def HasMode (u : ℤ → ℚ) : Prop :=
  ∃ m : ℤ, (∀ i j, i ≤ j → j ≤ m → u i ≤ u j) ∧
    (∀ i j, m ≤ i → i ≤ j → u j ≤ u i)

theorem no_reversed_window_signs (u : ℤ → ℚ) (hu : HasMode u)
    (s t L : ℤ) (hst : s < t) (hL : 0 ≤ L)
    (hs : u (s + L) < u s) (ht : u t < u (t + L)) : False := by
  obtain ⟨m, inc, dec⟩ := hu
  have hm1 : m < s + L := by
    by_contra h
    have hle : s + L ≤ m := le_of_not_gt h
    have := inc s (s + L) (by omega) hle
    linarith
  have hm2 : t < m := by
    by_contra h
    have hle : m ≤ t := le_of_not_gt h
    have := dec t (t + L) hle (by omega)
    linarith
  have hleft := inc s t (le_of_lt hst) (le_of_lt hm2)
  have hright := dec (s + L) (t + L) (le_of_lt hm1) (by omega)
  linarith

theorem point_valley_not_mode (u : ℤ → ℚ) (i j k : ℤ)
    (hij : i ≤ j) (hjk : j ≤ k) (hl : u j < u i) (hr : u j < u k) :
    ¬ HasMode u := by
  rintro ⟨m, inc, dec⟩
  by_cases h : j ≤ m
  · have := inc i j hij h
    linarith
  · have := dec j k (by omega) hjk
    linarith

theorem rational_block_valley (q b₁ b₂ b₃ : ℚ)
    (hq : q ≤ 1 / 12)
    (h₁ : 1 - 308 / 1875 - q ≤ b₁)
    (h₃ : 1 - 311 / 1875 - q ≤ b₃)
    (h₂ : b₂ ≤ (2 - q) - b₁ - b₃) :
    b₂ < b₁ ∧ b₂ < b₃ := by
  constructor <;> linarith

theorem exact_leaf_values :
    (192500 / 3 : ℚ) / 625^2 = 308 / 1875 ∧
    (194375 / 3 : ℚ) / 625^2 = 311 / 1875 ∧
    (1 - 308 / 1875 - 2 / 3 - (2 / 3) * (1 / 12) : ℚ) = 1277 / 11250 ∧
    (1 - 311 / 1875 - 2 / 3 - (2 / 3) * (1 / 12) : ℚ) = 1259 / 11250 := by
  norm_num

#print axioms no_reversed_window_signs
#print axioms point_valley_not_mode
#print axioms rational_block_valley
#print axioms exact_leaf_values
end PureFlag
