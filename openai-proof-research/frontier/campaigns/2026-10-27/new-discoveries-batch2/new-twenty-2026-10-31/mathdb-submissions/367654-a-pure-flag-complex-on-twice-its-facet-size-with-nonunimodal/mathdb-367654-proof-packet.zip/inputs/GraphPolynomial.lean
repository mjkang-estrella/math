import FacePolynomial
import ChoiceCounts
import MixedPurity
namespace PureFlag
open scoped BigOperators
open Polynomial
variable {I T : Type*} [Fintype I] [Fintype T] [DecidableEq I] [DecidableEq T]
abbrev UniformRel (u v : I × T) : Prop := u ≠ v ∧ u.1 = v.1
noncomputable def uniformFaceEquiv : (I → Option T) ≃ Faces (UniformRel (I:=I) (T:=T)) :=
  (choiceEquiv (I:=I) (T:=T)).trans
    { toFun := fun s => ⟨s.val,(partial_iff_independent _).mp s.property⟩
      invFun := fun s => ⟨s.val,(partial_iff_independent _).mpr s.property⟩
      left_inv := fun _ => rfl
      right_inv := fun _ => rfl }

theorem uniform_polynomial : facePoly (UniformRel (I:=I) (T:=T)) =
    (1 + (Fintype.card T : ℤ[X])*X)^Fintype.card I := by
  classical
  have he : ∀ f : I → Option T,
      (X : ℤ[X])^((uniformFaceEquiv f).val.card) =
        ∏ i : I, if f i ≠ none then X else 1 := by
    intro f
    change X^(encode f).card = _
    rw [encode_card,Finset.prod_ite]
    simp
  have h := Fintype.sum_equiv (uniformFaceEquiv (I:=I) (T:=T))
    (fun f => ∏ i : I, if f i ≠ none then (X : ℤ[X]) else 1)
    (fun s => (X : ℤ[X])^s.val.card) (fun f => (he f).symm)
  unfold facePoly
  rw [← h, ← Fintype.prod_sum (fun (_ : I) (t : Option T) => if t ≠ none then (X : ℤ[X]) else 1)]
  simp [Fintype.sum_option]

theorem branch_decomposition (a p q : ℕ) :
    @BranchAdj a p q = DisjointRel (@UniformRel (Fin a) (Fin p)) (@UniformRel (Fin a) (Fin q)) := by
  funext u v
  rcases u with u|u <;> rcases v with v|v <;>
    simp [BranchAdj,key,DisjointRel,UniformRel]

theorem branch_polynomial (a p q : ℕ) : facePoly (@BranchAdj a p q) =
    ((1 + (p : ℤ[X])*X)*(1+(q : ℤ[X])*X))^a := by
  classical
  rw [branch_decomposition,facePoly_disjoint,uniform_polynomial,uniform_polynomial]
  simp only [Fintype.card_fin,mul_pow]

theorem isolates_polynomial (n : ℕ) : facePoly (fun _ _ : Fin n => False) = (1+X)^n := by
  classical
  let e : Faces (fun _ _ : Fin n => False) ≃ (Fin n → Option Unit) :=
    { toFun := fun s => fun i => if i ∈ s.val then some () else none
      invFun := fun f => ⟨Finset.univ.filter (fun i => f i ≠ none),by simp [Independent]⟩
      left_inv := by intro s; apply Subtype.ext; ext i; simp
      right_inv := by intro f; funext i; cases h : f i with
        | none => simp [h]
        | some u => cases u; simp [h] }
  have h := Fintype.sum_equiv e (fun s => (X : ℤ[X])^s.val.card)
    (fun f => ∏ i : Fin n, if f i ≠ none then (X : ℤ[X]) else 1) (by
      intro s
      simp [e])
  unfold facePoly
  rw [h, ← Fintype.prod_sum (fun (_ : Fin n) (t : Option Unit) => if t ≠ none then (X : ℤ[X]) else 1)]
  simp [Fintype.sum_option]

theorem actual_graph_polynomial (a : ℕ) : facePoly (@Adj a) =
    (1+X)^(7*a) *
      ((((1+X)*(1+5*X))^a) + (((1+2*X)*(1+3*X))^a) - 1) := by
  classical
  rw [adj_decomposition,facePoly_disjoint,facePoly_join,
    branch_polynomial,branch_polynomial,isolates_polynomial]
  norm_num
  ring

#print axioms uniformFaceEquiv
#print axioms uniform_polynomial
#print axioms branch_decomposition
#print axioms branch_polynomial
#print axioms isolates_polynomial
#print axioms actual_graph_polynomial
end PureFlag
