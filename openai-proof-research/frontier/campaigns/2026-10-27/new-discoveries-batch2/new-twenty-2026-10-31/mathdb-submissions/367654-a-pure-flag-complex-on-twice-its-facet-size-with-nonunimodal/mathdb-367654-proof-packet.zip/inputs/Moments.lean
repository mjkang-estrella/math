import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp

namespace PureFlag
open scoped BigOperators
variable {ι κ : Type*}

def mass (s : Finset ι) (w : ι → ℚ) : ℚ := ∑ i ∈ s, w i
def first (s : Finset ι) (w x : ι → ℚ) : ℚ := ∑ i ∈ s, x i * w i
def second (s : Finset ι) (w x : ι → ℚ) : ℚ := ∑ i ∈ s, x i ^ 2 * w i

theorem product_mass (s : Finset ι) (t : Finset κ) (u : ι → ℚ) (v : κ → ℚ) :
    (∑ i ∈ s, ∑ j ∈ t, u i * v j) = mass s u * mass t v := by
  simp only [mass, Finset.mul_sum, Finset.sum_mul]
  exact Finset.sum_comm

theorem product_first (s : Finset ι) (t : Finset κ)
    (u x : ι → ℚ) (v y : κ → ℚ) :
    (∑ i ∈ s, ∑ j ∈ t, (x i + y j) * (u i * v j)) =
      first s u x * mass t v + mass s u * first t v y := by
  simp only [first, mass, Finset.mul_sum, Finset.sum_mul, ← Finset.sum_add_distrib]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem product_second (s : Finset ι) (t : Finset κ)
    (u x : ι → ℚ) (v y : κ → ℚ) :
    (∑ i ∈ s, ∑ j ∈ t, (x i + y j)^2 * (u i * v j)) =
      second s u x * mass t v + 2 * first s u x * first t v y +
        mass s u * second t v y := by
  simp only [second, first, mass, Finset.mul_sum, Finset.sum_mul,
    ← Finset.sum_add_distrib]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro i hi
  ring

theorem finite_chebyshev [DecidableEq ι] (s t : Finset ι)
    (ht : t ⊆ s) (w x : ι → ℚ) (μ r : ℚ)
    (hw : ∀ i ∈ s, 0 ≤ w i) (_hr : 0 < r)
    (hout : ∀ i ∈ t, r^2 ≤ (x i - μ)^2) :
    r^2 * (∑ i ∈ t, w i) ≤ ∑ i ∈ s, (x i - μ)^2 * w i := by
  calc
    r^2 * (∑ i ∈ t, w i) = ∑ i ∈ t, r^2 * w i := Finset.mul_sum ..
    _ ≤ ∑ i ∈ t, (x i - μ)^2 * w i := by
      apply Finset.sum_le_sum
      intro i hi
      exact mul_le_mul_of_nonneg_right (hout i hi) (hw i (ht hi))
    _ ≤ ∑ i ∈ s, (x i - μ)^2 * w i := by
      apply Finset.sum_le_sum_of_subset_of_nonneg ht
      intro i hi _
      exact mul_nonneg (sq_nonneg _) (hw i hi)

theorem bernoulli_variance (b : ℚ) (hb : 0 ≤ b) :
    b / (1+b) - (b / (1+b))^2 = b / (1+b)^2 := by
  have h : 1+b ≠ 0 := by linarith
  field_simp [h]
  ring

#print axioms product_mass
#print axioms product_first
#print axioms product_second
#print axioms finite_chebyshev
#print axioms bernoulli_variance
end PureFlag
