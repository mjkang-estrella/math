import GraphPolynomial
namespace PureFlag
open Polynomial
noncomputable def allTypesBroadConjecture : Prop :=
  ∀ (V : Type) [Fintype V] [DecidableEq V], BroadConjecture V

theorem actual_f_coeff (a i : ℕ) :
    ((graphComplex a).f i : ℤ) = (facePoly (@Adj a)).coeff (i+1) := by
  classical
  rw [facePoly_coeff_count]
  let t := (Finset.univ : Finset (Vertices a)).powerset.filter
    (fun s => Independent Adj s ∧ s.card = i+1)
  have ht : ∀ s : Finset (Vertices a), s ∈ t → Independent Adj s ∧ s.card = i+1 := by
    intro s hs; simpa [t] using hs
  let e : {s : Faces (@Adj a) // s.val.card = i+1} ≃ {s // s ∈ t} :=
    { toFun := fun s => ⟨s.val.val,by simp [t,s.val.property,s.property]⟩
      invFun := fun s => ⟨⟨s.val,(ht s.val s.property).1⟩,(ht s.val s.property).2⟩
      left_inv := fun _ => rfl
      right_inv := fun _ => rfl }
  have he := Fintype.card_congr e
  simp only [Fintype.card_coe] at he
  change (t.card : ℤ) = _
  exact congrArg (fun n : ℕ => (n : ℤ)) he.symm

theorem witness_pure : (graphComplex 30000).Pure 270000 := by
  exact graph_pure 30000 (by norm_num)

theorem outer_negation_of_actual_failure
    (h : ¬ (graphComplex 30000).Unimodal 270000) : ¬ allTypesBroadConjecture := by
  intro hc
  exact h (hc (Vertices 30000) 270000 (by norm_num) (graphComplex 30000)
    (by rw [vertices_card]) witness_pure (graphComplex_flag _))

#print axioms allTypesBroadConjecture
#print axioms actual_f_coeff
#print axioms witness_pure
#print axioms outer_negation_of_actual_failure
end PureFlag
