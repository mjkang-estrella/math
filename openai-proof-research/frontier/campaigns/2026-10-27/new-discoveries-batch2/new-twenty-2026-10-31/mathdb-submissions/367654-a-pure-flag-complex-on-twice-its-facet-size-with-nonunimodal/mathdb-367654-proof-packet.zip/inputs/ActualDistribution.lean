import RangeMoments
import Mathlib.Algebra.Polynomial.Eval.Coeff
namespace PureFlag
open scoped BigOperators
open Polynomial
noncomputable def actualW (a j : ℕ) : ℚ := (actualRat a).coeff j / commonMass a

theorem empty_range (a : ℕ) :
    (∑ j ∈ Finset.range (9*a+1), (betaPower 1 (7*a)).coeff j) = 1 := by
  have h := range_centered (trialWeight 1 (7*a)) (trialDegree (7*a)) (betaPower 1 (7*a))
    _ _ (9*a) (trial_polynomial 1 (7*a))
    (fun t => by have := trialDegree_le (7*a) t; omega)
    (fun t => trialWeight_nonneg 1 (by norm_num) _ t) (trial_moments 1 (by norm_num) (7*a))
  exact h.1

theorem actualW_nonneg (a j : ℕ) : 0 ≤ actualW a j := by
  have hc : 0 ≤ (actualRat a).coeff j := by
    simp only [actualRat,coeff_map]
    change (0:ℚ) ≤ ((facePoly (@Adj a)).coeff j : ℚ)
    exact_mod_cast actual_coeff_nonneg a j
  exact div_nonneg hc (le_of_lt (commonMass_pos a))

theorem actualW_support (a j : ℕ) (hj : 9*a < j) : actualW a j = 0 := by
  unfold actualW actualRat
  rw [coeff_map,actual_coeff_support a j hj]
  simp

theorem actualW_total (a : ℕ) :
    (∑ j ∈ Finset.range (9*a+1), actualW a j) = 2-emptyMass a/commonMass a := by
  simp only [actualW,actual_normalized_coefficient,Finset.sum_sub_distrib,
    Finset.sum_add_distrib,← Finset.mul_sum]
  rw [(first_range a).1,(second_range a).1,empty_range]
  ring

theorem actual_first_branch_mass (a : ℕ) :
    (∑ j ∈ Finset.range (9*a+1), (rawFirst a).coeff j) = commonMass a := by
  rw [← first_scale]
  simp only [coeff_C_mul,← Finset.mul_sum,(first_range a).1,mul_one]
  rfl

theorem actual_second_branch_mass (a : ℕ) :
    (∑ j ∈ Finset.range (9*a+1), (rawSecond a).coeff j) = commonMass a := by
  rw [← second_scale]
  simp only [coeff_C_mul,← Finset.mul_sum,(second_range a).1,mul_one]
  rfl

#print axioms empty_range
#print axioms actualW_nonneg
#print axioms actualW_support
#print axioms actualW_total
#print axioms actual_first_branch_mass
#print axioms actual_second_branch_mass
end PureFlag
