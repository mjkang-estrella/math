import Heterogeneous
namespace PureFlag
open scoped BigOperators
open Polynomial
noncomputable def innerWeight (a : ℕ) (t : Trials (7*a) × Trials a) : ℚ :=
  trialWeight 1 (7*a) t.1 * trialWeight 2 a t.2
def innerDegree (a : ℕ) (t : Trials (7*a) × Trials a) : ℕ :=
  trialDegree (7*a) t.1 + trialDegree a t.2
noncomputable def secondWeight (a : ℕ) (t : (Trials (7*a) × Trials a) × Trials a) : ℚ :=
  innerWeight a t.1 * trialWeight 3 a t.2
def secondDegree (a : ℕ) (t : (Trials (7*a) × Trials a) × Trials a) : ℕ :=
  innerDegree a t.1 + trialDegree a t.2

theorem second_branch_moments (a : ℕ) :
    mass Finset.univ (secondWeight a) = 1 ∧
    first Finset.univ (secondWeight a) (fun t => (secondDegree a t : ℚ)) = 59*(a:ℚ)/12 ∧
    second Finset.univ (secondWeight a) (fun t => (secondDegree a t : ℚ)) =
      311*(a:ℚ)/144 + (59*(a:ℚ)/12)^2 := by
  have hi := heterogeneous_moments _ _ _ _ _ _ _ _
    (trial_moments 1 (by norm_num) (7*a)) (trial_moments 2 (by norm_num) a)
  have hi' : mass Finset.univ (innerWeight a) = 1 ∧
      first Finset.univ (innerWeight a) (fun t => (innerDegree a t : ℚ)) =
        (7*(a:ℚ)/2+2*(a:ℚ)/3) ∧
      second Finset.univ (innerWeight a) (fun t => (innerDegree a t : ℚ)) =
        (7*(a:ℚ)/4+2*(a:ℚ)/9)+(7*(a:ℚ)/2+2*(a:ℚ)/3)^2 := by
    refine ⟨hi.1,hi.2.1.trans ?_,hi.2.2.trans ?_⟩ <;> push_cast <;> ring
  have h := heterogeneous_moments _ _ _ _ _ _ _ _ hi' (trial_moments 3 (by norm_num) a)
  refine ⟨h.1,h.2.1.trans ?_,h.2.2.trans ?_⟩ <;> ring

theorem second_branch_polynomial (a : ℕ) :
    degreePoly Finset.univ (secondWeight a) (secondDegree a) =
      betaPower 1 (7*a) * betaPower 2 a * betaPower 3 a := by
  classical
  change degreePoly (Finset.univ ×ˢ Finset.univ) _ _ = _
  unfold secondWeight secondDegree
  rw [degreePoly_product,trial_polynomial]
  change degreePoly (Finset.univ ×ˢ Finset.univ) _ _ * _ = _
  unfold innerWeight innerDegree
  rw [degreePoly_product,trial_polynomial,trial_polynomial]
  rfl
#print axioms second_branch_moments
#print axioms second_branch_polynomial
end PureFlag
