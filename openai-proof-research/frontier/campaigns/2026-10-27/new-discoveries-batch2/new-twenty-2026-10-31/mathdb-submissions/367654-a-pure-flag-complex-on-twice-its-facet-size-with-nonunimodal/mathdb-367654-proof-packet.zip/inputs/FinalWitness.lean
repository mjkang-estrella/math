import ActualBlocks
import ZeroExtension
import Mathlib.Algebra.BigOperators.Field
namespace PureFlag
open scoped BigOperators
open Polynomial

theorem actualRat_f (a j : ℕ) (hj : 1 ≤ j) :
    (actualRat a).coeff j = ((graphComplex a).f (j-1) : ℚ) := by
  unfold actualRat
  rw [coeff_map]
  change ((facePoly (@Adj a)).coeff j : ℚ) = _
  have hh := actual_f_coeff a (j-1)
  rw [show j-1+1=j by omega] at hh
  exact_mod_cast hh.symm

theorem block_window (a s : ℕ) (ha : a=30000) (hs : 1 ≤ s) (he : s+1250 ≤ 270001) :
    blockMass a s = window (zeroF (graphComplex a) (9*a)) ((s:ℤ)-1) 1250 / commonMass a := by
  classical
  unfold blockMass window
  rw [Finset.sum_div]
  symm
  apply Finset.sum_bij (fun i _ => s+i)
  · intro i hi
    simp only [Finset.mem_range] at hi
    simp only [B,Finset.mem_Ico]
    omega
  · intro i hi j hj hij
    omega
  · intro j hj
    simp only [B,Finset.mem_Ico] at hj
    exact ⟨j-s,Finset.mem_range.mpr (by omega),by omega⟩
  · intro i hi
    have hi' := Finset.mem_range.mp hi
    have hj : 1 ≤ s+i := by omega
    have hd : s+i ≤ 9*a := by omega
    change zeroF (graphComplex a) (9*a) ((s:ℤ)-1+(i:ℤ)) / commonMass a = actualW a (s+i)
    rw [show (s:ℤ)-1+(i:ℤ) = ((s+i:ℕ):ℤ)-1 by omega,
      positive_index_translation _ _ _ (by omega) (by exact_mod_cast hd)]
    simp only [Int.toNat_natCast]
    rw [actualW,actualRat_f a (s+i) hj]

theorem actual_f_not_unimodal (a : ℕ) (ha : a=30000) :
    ¬ (graphComplex a).Unimodal (9*a) := by
  have h := actual_block_valley a ha
  rw [block_window a 145625 ha (by norm_num) (by norm_num),
    block_window a 144375 ha (by norm_num) (by norm_num),
    block_window a 146875 ha (by norm_num) (by norm_num)] at h
  have hl := (div_lt_div_iff_of_pos_right (commonMass_pos a)).mp h.1
  have hr := (div_lt_div_iff_of_pos_right (commonMass_pos a)).mp h.2
  apply finite_window_valley (graphComplex a) (9*a) 1250 144374
  · exact hl
  · exact hr

theorem literal_broad_refutation : ¬ allTypesBroadConjecture :=
  outer_negation_of_actual_failure (actual_f_not_unimodal 30000 rfl)

theorem actual_missing_witness : MissingWitness :=
  ⟨witness_pure,actual_f_not_unimodal 30000 rfl⟩

#print axioms actualRat_f
#print axioms block_window
#print axioms actual_f_not_unimodal
#print axioms literal_broad_refutation
#print axioms actual_missing_witness
end PureFlag
