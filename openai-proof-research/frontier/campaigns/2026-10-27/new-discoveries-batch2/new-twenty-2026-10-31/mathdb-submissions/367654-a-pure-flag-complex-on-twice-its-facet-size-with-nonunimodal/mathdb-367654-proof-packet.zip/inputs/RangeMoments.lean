import ActualNormalization
namespace PureFlag
open scoped BigOperators
open Polynomial

theorem trialDegree_le (n : ℕ) (t : Trials n) : trialDegree n t ≤ n := by
  induction n with
  | zero => exact Nat.zero_le _
  | succ n ih =>
    have h := ih t.2
    have hb : betaDegree t.1 ≤ 1 := by unfold betaDegree; split_ifs <;> omega
    change betaDegree t.1 + trialDegree n t.2 ≤ n+1
    omega

variable {I : Type*} [Fintype I]
theorem range_centered (u : I → ℚ) (d : I → ℕ) (P : ℚ[X]) (μ σ : ℚ) (N : ℕ)
    (hp : degreePoly Finset.univ u d = P) (hd : ∀ i, d i ≤ N)
    (hu : ∀ i, 0 ≤ u i)
    (h : mass Finset.univ u = 1 ∧ first Finset.univ u (fun i => (d i : ℚ)) = μ ∧
      second Finset.univ u (fun i => (d i : ℚ)) = σ+μ^2) :
    (∑ j ∈ Finset.range (N+1), P.coeff j) = 1 ∧
    (∑ j ∈ Finset.range (N+1), ((j:ℚ)-μ)^2 * P.coeff j) = σ ∧
    (∀ j, 0 ≤ P.coeff j) := by
  classical
  have hc := coefficient_centered u d P μ σ hp h
  have hz (j : ℕ) (hj : j ∉ Finset.univ.image d) : P.coeff j = 0 := by
    rw [← hp,degreePoly_coeff]
    exact degreeWeight_outside _ _ _ _ hj
  have hs : Finset.univ.image d ⊆ Finset.range (N+1) := by
    intro j hj
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hj
    exact Finset.mem_range.mpr (by have := hd i; omega)
  have ht (g : ℕ → ℚ) :
      (∑ j ∈ Finset.univ.image d, g j * P.coeff j) =
      ∑ j ∈ Finset.range (N+1), g j * P.coeff j := by
    apply Finset.sum_subset hs
    intro j _ hj
    rw [hz j hj,mul_zero]
  constructor
  · have hm := ht (fun _ => 1)
    simp only [one_mul] at hm
    exact hm.symm.trans hc.1
  constructor
  · exact (ht (fun j => ((j:ℚ)-μ)^2)).symm.trans hc.2.2
  · intro j
    rw [← hp,degreePoly_coeff]
    exact degreeWeight_nonneg _ _ _ (fun i _ => hu i) j

theorem first_range (a : ℕ) :
    (∑ j ∈ Finset.range (9*a+1), (betaPower 1 (8*a)*betaPower 5 a).coeff j) = 1 ∧
    (∑ j ∈ Finset.range (9*a+1), ((j:ℚ)-29*(a:ℚ)/6)^2 *
      (betaPower 1 (8*a)*betaPower 5 a).coeff j) = 77*(a:ℚ)/36 ∧
    (∀ j, 0 ≤ (betaPower 1 (8*a)*betaPower 5 a).coeff j) := by
  apply range_centered _ _ _ _ _ _ (first_branch_polynomial a) _ _ (first_branch_moments a)
  · intro t
    have h1 := trialDegree_le (8*a) t.1
    have h2 := trialDegree_le a t.2
    unfold mixedDegree
    omega
  · intro t
    exact mul_nonneg (trialWeight_nonneg 1 (by norm_num) _ _) (trialWeight_nonneg 5 (by norm_num) _ _)

theorem second_range (a : ℕ) :
    (∑ j ∈ Finset.range (9*a+1), (betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a).coeff j) = 1 ∧
    (∑ j ∈ Finset.range (9*a+1), ((j:ℚ)-59*(a:ℚ)/12)^2 *
      (betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a).coeff j) = 311*(a:ℚ)/144 ∧
    (∀ j, 0 ≤ (betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a).coeff j) := by
  apply range_centered _ _ _ _ _ _ (second_branch_polynomial a) _ _ (second_branch_moments a)
  · intro t
    have h1 := trialDegree_le (7*a) t.1.1
    have h2 := trialDegree_le a t.1.2
    have h3 := trialDegree_le a t.2
    unfold secondDegree innerDegree
    omega
  · intro t
    exact mul_nonneg (mul_nonneg (trialWeight_nonneg 1 (by norm_num) _ _)
      (trialWeight_nonneg 2 (by norm_num) _ _)) (trialWeight_nonneg 3 (by norm_num) _ _)

#print axioms trialDegree_le
#print axioms first_range
#print axioms second_range
end PureFlag
