import Join
import Mathlib.Data.Fintype.Powerset
namespace PureFlag
abbrev Faces {V : Type*} (R : V → V → Prop) := {s : Finset V // Independent R s}
noncomputable instance facesFintype {V : Type*} [Fintype V] (R : V → V → Prop) : Fintype (Faces R) := by
  classical
  exact Fintype.ofFinite _
variable {A B : Type*} [DecidableEq A] [DecidableEq B]
noncomputable def disjointFaceEquiv (R : A → A → Prop) (S : B → B → Prop) :
    Faces (DisjointRel R S) ≃ Faces R × Faces S where
  toFun u := ⟨⟨u.val.toLeft, ((disjoint_faces R S _ _).mp (by rw [Finset.toLeft_disjSum_toRight]; exact u.property)).1⟩,
    ⟨u.val.toRight, ((disjoint_faces R S _ _).mp (by rw [Finset.toLeft_disjSum_toRight]; exact u.property)).2⟩⟩
  invFun p := ⟨p.1.val.disjSum p.2.val,(disjoint_faces R S _ _).mpr ⟨p.1.property,p.2.property⟩⟩
  left_inv u := Subtype.ext Finset.toLeft_disjSum_toRight
  right_inv p := by apply Prod.ext <;> apply Subtype.ext <;> simp only [Finset.toLeft_disjSum,Finset.toRight_disjSum]

omit [DecidableEq A] [DecidableEq B] in
theorem disjointFaceEquiv_size (R : A → A → Prop) (S : B → B → Prop)
    (u : Faces (DisjointRel R S)) :
    u.val.card = ((disjointFaceEquiv R S u).1.val.card + (disjointFaceEquiv R S u).2.val.card) :=
  split_card _

noncomputable def joinEncode (R : A → A → Prop) (S : B → B → Prop) :
    Faces R ⊕ {s : Faces S // s.val.Nonempty} → Faces (JoinRel R S)
  | .inl s => ⟨s.val.disjSum ∅,(join_faces R S _ _).mpr ⟨s.property,independent_empty S,Or.inr rfl⟩⟩
  | .inr t => ⟨(∅ : Finset A).disjSum t.val.val,(join_faces R S _ _).mpr ⟨independent_empty R,t.val.property,Or.inl rfl⟩⟩

noncomputable def joinFaceEquiv (R : A → A → Prop) (S : B → B → Prop) :
    (Faces R ⊕ {s : Faces S // s.val.Nonempty}) ≃ Faces (JoinRel R S) :=
  Equiv.ofBijective (joinEncode R S) (by
    constructor
    · intro u v he
      have hh := congrArg Subtype.val he
      cases u with
      | inl s =>
        cases v with
        | inl t =>
          apply congrArg Sum.inl; apply Subtype.ext
          simpa only [joinEncode,Finset.toLeft_disjSum] using congrArg Finset.toLeft hh
        | inr t =>
          have he' : (∅ : Finset B) = t.val.val := by
            simpa only [joinEncode,Finset.toRight_disjSum] using congrArg Finset.toRight hh
          exact (t.property.ne_empty he'.symm).elim
      | inr s =>
        cases v with
        | inl t =>
          have he' : s.val.val = (∅ : Finset B) := by
            simpa only [joinEncode,Finset.toRight_disjSum] using congrArg Finset.toRight hh
          exact (s.property.ne_empty he').elim
        | inr t =>
          apply congrArg Sum.inr; apply Subtype.ext; apply Subtype.ext
          simpa only [joinEncode,Finset.toRight_disjSum] using congrArg Finset.toRight hh
    · intro u
      have hf := (join_faces R S u.val.toLeft u.val.toRight).mp
        (by rw [Finset.toLeft_disjSum_toRight]; exact u.property)
      by_cases hr : u.val.toRight = ∅
      · refine ⟨.inl ⟨u.val.toLeft,hf.1⟩,Subtype.ext ?_⟩
        change u.val.toLeft.disjSum ∅ = u.val
        rw [← hr,Finset.toLeft_disjSum_toRight]
      · have hl : u.val.toLeft = ∅ := hf.2.2.resolve_right hr
        refine ⟨.inr ⟨⟨u.val.toRight,hf.2.1⟩,Finset.nonempty_iff_ne_empty.mpr hr⟩,Subtype.ext ?_⟩
        change (∅ : Finset A).disjSum u.val.toRight = u.val
        rw [← hl,Finset.toLeft_disjSum_toRight])

theorem joinEncode_size (R : A → A → Prop) (S : B → B → Prop)
    (u : Faces R ⊕ {s : Faces S // s.val.Nonempty}) :
    (joinFaceEquiv R S u).val.card = Sum.elim (fun s : Faces R => s.val.card)
      (fun s : {s : Faces S // s.val.Nonempty} => s.val.val.card) u := by
  cases u <;> simp [joinFaceEquiv,joinEncode,Equiv.ofBijective]
#print axioms disjointFaceEquiv
#print axioms disjointFaceEquiv_size
#print axioms joinFaceEquiv
#print axioms joinEncode_size
end PureFlag
