import MixedCoefficients
namespace PureFlag
open Polynomial

theorem beta_factor (b : ℚ) (hb : 1+b ≠ 0) :
    C (1+b) * (C (1/(1+b)) + C (b/(1+b))*X) = 1+C b*X := by
  calc
    _ = C ((1+b)*(1/(1+b))) + C ((1+b)*(b/(1+b)))*X := by
      simp only [map_mul]
      ring
    _ = _ := by
      have h1 : (1+b)*(1/(1+b)) = 1 := by field_simp
      have h2 : (1+b)*(b/(1+b)) = b := by field_simp
      rw [h1,h2,map_one]

theorem beta_power_scale (b : ℚ) (hb : 1+b ≠ 0) (n : ℕ) :
    C ((1+b)^n) * betaPower b n = (1+C b*X)^n := by
  rw [betaPower,map_pow,← mul_pow,beta_factor b hb]

noncomputable def rawFirst (a : ℕ) : ℚ[X] := (1+X)^(8*a)*(1+5*X)^a
noncomputable def rawSecond (a : ℕ) : ℚ[X] := (1+X)^(7*a)*(1+2*X)^a*(1+3*X)^a

theorem first_scale (a : ℕ) :
    C ((2:ℚ)^(7*a)*12^a) * (betaPower 1 (8*a)*betaPower 5 a) = rawFirst a := by
  have hm : (2:ℚ)^(7*a)*12^a = 2^(8*a)*6^a := by
    rw [show 8*a=7*a+a by omega,pow_add]
    rw [show (12:ℚ)=2*6 by norm_num,mul_pow]
    ring
  rw [hm,map_mul]
  calc
    _ = (C ((1+1:ℚ)^(8*a))*betaPower 1 (8*a)) *
        (C ((1+5:ℚ)^a)*betaPower 5 a) := by norm_num; ring
    _ = _ := by rw [beta_power_scale 1 (by norm_num),beta_power_scale 5 (by norm_num)]; simp only [rawFirst,map_one,map_ofNat,one_mul]

theorem second_scale (a : ℕ) :
    C ((2:ℚ)^(7*a)*12^a) * (betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a) = rawSecond a := by
  rw [show (12:ℚ)=3*4 by norm_num,mul_pow,map_mul,map_mul]
  calc
    _ = (C ((1+1:ℚ)^(7*a))*betaPower 1 (7*a)) *
        (C ((1+2:ℚ)^a)*betaPower 2 a) * (C ((1+3:ℚ)^a)*betaPower 3 a) := by norm_num; ring
    _ = _ := by rw [beta_power_scale 1 (by norm_num),beta_power_scale 2 (by norm_num),beta_power_scale 3 (by norm_num)]; simp only [rawSecond,map_one,map_ofNat,one_mul]

#print axioms beta_power_scale
#print axioms first_scale
#print axioms second_scale
end PureFlag
