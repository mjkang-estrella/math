import Valley
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

namespace PureFlag
open scoped BigOperators

def window (u : ℤ → ℚ) (s : ℤ) (L : ℕ) : ℚ :=
  ∑ i ∈ Finset.range L, u (s + (i : ℤ))

theorem window_step (u : ℤ → ℚ) (s : ℤ) (L : ℕ) :
    window u (s+1) L - window u s L = u (s+(L:ℤ)) - u s := by
  induction L with
  | zero => simp [window]
  | succ n ih =>
    simp only [window, Finset.sum_range_succ] at *
    have h : s + 1 + (n : ℤ) = s + (n : ℤ) + 1 := by omega
    simp only [Nat.cast_add, Nat.cast_one, ← add_assoc]
    rw [h]
    linarith

theorem exists_drop (H : ℤ → ℚ) (a : ℤ) (n : ℕ)
    (h : H (a+(n:ℤ)) < H a) :
    ∃ i : ℕ, i < n ∧ H (a+(i:ℤ)+1) < H (a+(i:ℤ)) := by
  induction n with
  | zero => simp at h
  | succ n ih =>
    by_cases hd : H (a+(n:ℤ)+1) < H (a+(n:ℤ))
    · exact ⟨n, Nat.lt_succ_self n, hd⟩
    · have he : H (a+(n:ℤ)) < H a := by
        simp only [Nat.cast_add, Nat.cast_one, ← add_assoc] at h
        linarith
      obtain ⟨i, hi, hv⟩ := ih he
      exact ⟨i, by omega, hv⟩

theorem window_valley_not_mode (u : ℤ → ℚ) (s : ℤ) (L : ℕ)
    (hl : window u (s+(L:ℤ)) L < window u s L)
    (hr : window u (s+(L:ℤ)) L < window u (s+(L:ℤ)+(L:ℤ)) L) :
    ¬ HasMode u := by
  intro hu
  obtain ⟨i, hi, hdrop⟩ := exists_drop (fun t => window u t L) s L hl
  have hn : (-window u (s+(L:ℤ)+(L:ℤ)) L) < -window u (s+(L:ℤ)) L := by
    linarith
  obtain ⟨j, hj, hrise⟩ := exists_drop (fun t => -window u t L) (s+(L:ℤ)) L hn
  have hd := window_step u (s+(i:ℤ)) L
  have hu' := window_step u (s+(L:ℤ)+(j:ℤ)) L
  have hs : u (s+(i:ℤ)+(L:ℤ)) < u (s+(i:ℤ)) := by linarith
  have ht : u (s+(L:ℤ)+(j:ℤ)) < u (s+(L:ℤ)+(j:ℤ)+(L:ℤ)) := by
    linarith
  exact no_reversed_window_signs u hu _ _ (L:ℤ) (by omega) (by omega) hs ht

#print axioms window_step
#print axioms exists_drop
#print axioms window_valley_not_mode
end PureFlag
