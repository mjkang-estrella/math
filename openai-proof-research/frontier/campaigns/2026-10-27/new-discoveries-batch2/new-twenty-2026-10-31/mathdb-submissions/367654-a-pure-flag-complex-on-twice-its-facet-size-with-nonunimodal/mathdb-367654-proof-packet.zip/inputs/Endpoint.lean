import Complex
import Valley
import Mathlib.Data.Finset.Powerset
import Mathlib.Tactic.NormNum

namespace PureFlag
variable (V : Type*) [Fintype V] [DecidableEq V]

structure FiniteComplex where
  face : Finset V → Prop
  empty_face : face ∅
  singleton_face : ∀ v, face {v}
  downward : ∀ {s t}, face s → t ⊆ s → face t

namespace FiniteComplex
variable {V}
def Facet (K : FiniteComplex V) (s : Finset V) : Prop :=
  K.face s ∧ ∀ t, K.face t → s ⊆ t → t = s

def Pure (K : FiniteComplex V) (d : ℕ) : Prop :=
  (∃ s, K.Facet s) ∧ ∀ s, K.Facet s → s.card = d

def Flag (K : FiniteComplex V) : Prop :=
  ∀ s, (∀ u ∈ s, ∀ v ∈ s, u ≠ v → K.face {u,v}) → K.face s

noncomputable def f (K : FiniteComplex V) (i : ℕ) : ℕ := by
  classical
  exact ((Finset.univ : Finset V).powerset.filter
    (fun s => K.face s ∧ s.card = i+1)).card

def Unimodal (K : FiniteComplex V) (d : ℕ) : Prop :=
  ∃ m : ℕ, m < d ∧
    (∀ i j, i ≤ j → j ≤ m → K.f i ≤ K.f j) ∧
    (∀ i j, m ≤ i → i ≤ j → j < d → K.f j ≤ K.f i)
end FiniteComplex

noncomputable instance verticesDecidableEq (a : ℕ) : DecidableEq (Vertices a) := Classical.decEq _

noncomputable def graphComplex (a : ℕ) : FiniteComplex (Vertices a) := by
  classical
  exact ⟨Independent Adj, independent_empty Adj,
    independent_singleton Adj adj_irreflexive,
    fun h ht => independent_downward Adj h ht⟩

theorem graphComplex_flag (a : ℕ) : (graphComplex a).Flag := by
  classical
  exact independent_flag Adj adj_irreflexive

theorem witness_vertices : Fintype.card (Vertices 30000) = 540000 := by
  rw [vertices_card]

-- This is a definition of the broad source assertion, not an axiom or theorem.
def BroadConjecture : Prop :=
  ∀ (d : ℕ), 0 < d → ∀ (K : FiniteComplex V),
    Fintype.card V = 2*d → K.Pure d → K.Flag → K.Unimodal d

-- Exact outstanding witness obligation, deliberately not asserted as a theorem.
def MissingWitness : Prop :=
  (graphComplex 30000).Pure 270000 ∧
    ¬ (graphComplex 30000).Unimodal 270000

#print axioms graphComplex
#print axioms graphComplex_flag
#print axioms witness_vertices
end PureFlag
