import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Tactic.Ring
namespace PureFlag
open scoped BigOperators
open Polynomial
variable {I J : Type*}
def degreeWeight (s : Finset I) (w : I → ℚ) (d : I → ℕ) (n : ℕ) : ℚ :=
  ∑ i ∈ s with d i = n, w i
noncomputable def degreePoly (s : Finset I) (w : I → ℚ) (d : I → ℕ) : ℚ[X] :=
  ∑ i ∈ s, C (w i) * X^(d i)
theorem degreePoly_coeff (s : Finset I) (w : I → ℚ) (d : I → ℕ) (n : ℕ) :
    (degreePoly s w d).coeff n = degreeWeight s w d n := by
  classical
  simp [degreePoly,degreeWeight,Polynomial.coeff_C_mul,Polynomial.coeff_X_pow,Finset.sum_filter,eq_comm]

theorem degree_transport (s : Finset I) (w : I → ℚ) (d : I → ℕ) (g : ℕ → ℚ) :
    (∑ n ∈ s.image d, g n * degreeWeight s w d n) = ∑ i ∈ s, g (d i)*w i := by
  classical
  unfold degreeWeight
  simp only [Finset.mul_sum]
  calc
    _ = ∑ n ∈ s.image d, ∑ i ∈ s with d i = n, g (d i)*w i := by
      apply Finset.sum_congr rfl
      intro n hn
      apply Finset.sum_congr rfl
      intro i hi
      rw [(Finset.mem_filter.mp hi).2]
    _ = _ := Finset.sum_fiberwise_of_maps_to (fun i hi => Finset.mem_image_of_mem d hi) _

theorem degreeWeight_nonneg (s : Finset I) (w : I → ℚ) (d : I → ℕ)
    (hw : ∀ i ∈ s, 0 ≤ w i) (n : ℕ) : 0 ≤ degreeWeight s w d n := by
  apply Finset.sum_nonneg
  intro i hi
  exact hw i (Finset.mem_filter.mp hi).1

theorem degreeWeight_outside (s : Finset I) (w : I → ℚ) (d : I → ℕ)
    (n : ℕ) (hn : n ∉ s.image d) : degreeWeight s w d n = 0 := by
  apply Finset.sum_eq_zero
  intro i hi
  have he := (Finset.mem_filter.mp hi).2
  exact (hn (he ▸ Finset.mem_image_of_mem d (Finset.mem_filter.mp hi).1)).elim

theorem degreePoly_product (s : Finset I) (t : Finset J)
    (u : I → ℚ) (v : J → ℚ) (d : I → ℕ) (e : J → ℕ) :
    degreePoly (s ×ˢ t) (fun p => u p.1 * v p.2) (fun p => d p.1 + e p.2) =
      degreePoly s u d * degreePoly t v e := by
  classical
  simp only [degreePoly,Finset.sum_product,Finset.sum_mul,Finset.mul_sum,pow_add,map_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro i hi
  ring

#print axioms degreePoly_coeff
#print axioms degree_transport
#print axioms degreeWeight_nonneg
#print axioms degreeWeight_outside
#print axioms degreePoly_product
end PureFlag
