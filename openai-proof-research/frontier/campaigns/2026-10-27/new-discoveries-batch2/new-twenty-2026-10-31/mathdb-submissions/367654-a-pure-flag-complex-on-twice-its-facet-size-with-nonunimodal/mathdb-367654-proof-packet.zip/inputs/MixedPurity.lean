import Purity
import Endpoint
namespace PureFlag
variable {A B V K : Type*}
theorem keyed_rep_max [Fintype K] [DecidableEq V] (k : V → K)
    (rep : K → V) (hr : ∀ i, k (rep i) = i) :
    MaxInd (fun u v => u ≠ v ∧ k u = k v) (Finset.univ.image rep) := by
  classical
  constructor
  · intro u hu v hv ⟨hn,he⟩
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hu
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hv
    rw [hr,hr] at he
    exact hn (congrArg rep he)
  · intro t ht hsub
    apply Finset.Subset.antisymm _ hsub
    intro u hu
    have hm : rep (k u) ∈ Finset.univ.image rep := Finset.mem_image.mpr ⟨k u,by simp,rfl⟩
    by_cases he : u = rep (k u)
    · rw [he]; exact hm
    · exact (ht u hu _ (hsub hm) ⟨he,(hr _).symm⟩).elim

noncomputable def branchRep (a p q : ℕ) [NeZero p] [NeZero q] : (Fin a ⊕ Fin a) → Branch a p q
  | .inl i => .inl (i,0)
  | .inr i => .inr (i,0)
@[simp] theorem branch_key_rep (a p q : ℕ) [NeZero p] [NeZero q] (i : Fin a ⊕ Fin a) :
    key (branchRep a p q i) = i := by cases i <;> rfl

theorem branch_max_card (a p q : ℕ) [NeZero p] [NeZero q]
    (s : Finset (Branch a p q)) (hs : MaxInd BranchAdj s) : s.card = 2*a := by
  classical
  have h := keyed_card key (branchRep a p q) (branch_key_rep a p q) s hs
  simp only [Fintype.card_sum, Fintype.card_fin] at h
  omega

theorem max_join_card [DecidableEq A] [DecidableEq B]
    (R : A → A → Prop) (S : B → B → Prop) (d : ℕ)
    (hR : ∀ s, MaxInd R s → s.card = d) (hS : ∀ t, MaxInd S t → t.card = d)
    (u : Finset (A ⊕ B)) (hu : MaxInd (JoinRel R S) u) : u.card = d := by
  have hf := (join_faces R S u.toLeft u.toRight).mp (by rw [Finset.toLeft_disjSum_toRight]; exact hu.1)
  rcases hf.2.2 with hl | hr
  · have ht : MaxInd S u.toRight := by
      refine ⟨hf.2.1, ?_⟩
      intro t ht hsub
      have hh := hu.2 ((∅ : Finset A).disjSum t)
        ((join_faces R S ∅ t).mpr ⟨independent_empty R,ht,Or.inl rfl⟩)
        (Finset.subset_disjSum.mpr ⟨by simp [hl],hsub⟩)
      simpa only [Finset.toRight_disjSum] using congrArg Finset.toRight hh
    rw [split_card, hl, Finset.card_empty, zero_add, hS _ ht]
  · have hs : MaxInd R u.toLeft := by
      refine ⟨hf.1, ?_⟩
      intro s hs hsub
      have hh := hu.2 (s.disjSum (∅ : Finset B))
        ((join_faces R S s ∅).mpr ⟨hs,independent_empty S,Or.inr rfl⟩)
        (Finset.subset_disjSum.mpr ⟨hsub,by simp [hr]⟩)
      simpa only [Finset.toLeft_disjSum] using congrArg Finset.toLeft hh
    rw [split_card, hr, Finset.card_empty, add_zero, hR _ hs]

theorem adj_decomposition (a : ℕ) :
    @Adj a = DisjointRel (JoinRel (@BranchAdj a 1 5) (@BranchAdj a 2 3))
      (fun _ _ : Fin (7*a) => False) := by
  funext u v
  rcases u with (u|u)|u <;> rcases v with (v|v)|v <;> rfl

theorem graph_facet_card (a : ℕ) (s : Finset (Vertices a))
    (hs : (graphComplex a).Facet s) : s.card = 9*a := by
  classical
  have hm : MaxInd Adj s := hs
  rw [adj_decomposition] at hm
  have hh := (max_disjoint _ _ s.toLeft s.toRight).mp (by rw [Finset.toLeft_disjSum_toRight]; exact hm)
  have hl := max_join_card _ _ (2*a) (branch_max_card a 1 5) (branch_max_card a 2 3) s.toLeft hh.1
  have hr : s.toRight = Finset.univ := by
    exact (hh.2.2 Finset.univ (by simp [Independent]) (Finset.subset_univ _)).symm
  rw [split_card, hl, hr]
  simp only [Finset.card_univ, Fintype.card_fin]
  omega

theorem graph_pure (a : ℕ) (ha : 0 < a) : (graphComplex a).Pure (9*a) := by
  classical
  let s : Finset (Branch a 1 5) := Finset.univ.image (branchRep a 1 5)
  have hs : MaxInd BranchAdj s := keyed_rep_max key _ (branch_key_rep a 1 5)
  have hn : s.Nonempty := by
    exact ⟨branchRep a 1 5 (.inl ⟨0,ha⟩),Finset.mem_image.mpr ⟨.inl ⟨0,ha⟩,by simp,rfl⟩⟩
  have hj := max_join_left (@BranchAdj a 1 5) (@BranchAdj a 2 3) s hn hs
  have he : MaxInd (fun _ _ : Fin (7*a) => False) Finset.univ := by
    refine ⟨by simp [Independent], ?_⟩
    intro t ht hsub
    exact Finset.Subset.antisymm (Finset.subset_univ _) hsub
  have hm := (max_disjoint _ _ _ _).mpr ⟨hj,he⟩
  rw [← adj_decomposition] at hm
  exact ⟨⟨_,hm⟩,graph_facet_card a⟩

#print axioms keyed_rep_max
#print axioms branch_max_card
#print axioms max_join_card
#print axioms adj_decomposition
#print axioms graph_facet_card
#print axioms graph_pure
end PureFlag
