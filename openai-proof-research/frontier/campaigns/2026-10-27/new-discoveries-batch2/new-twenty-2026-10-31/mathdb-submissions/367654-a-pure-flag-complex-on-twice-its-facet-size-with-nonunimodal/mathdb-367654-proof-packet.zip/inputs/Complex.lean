import Mathlib.Data.Fintype.Card
import Mathlib.Data.Fintype.Sum
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Finset.Card
import Mathlib.Tactic.Ring

namespace PureFlag
variable {V : Type*}
-- Faces are actual finite subsets, including all actual vertices.
def Independent (R : V → V → Prop) (s : Finset V) : Prop :=
  ∀ u ∈ s, ∀ v ∈ s, ¬ R u v

theorem independent_downward (R : V → V → Prop) {s t : Finset V}
    (h : Independent R s) (ht : t ⊆ s) : Independent R t := by
  intro u hu v hv
  exact h u (ht hu) v (ht hv)

theorem independent_empty (R : V → V → Prop) : Independent R ∅ := by
  simp [Independent]

theorem independent_singleton [DecidableEq V] (R : V → V → Prop)
    (hR : ∀ v, ¬ R v v) (v : V) : Independent R {v} := by
  simpa [Independent] using hR v

theorem independent_flag [DecidableEq V] (R : V → V → Prop)
    (hR : ∀ v, ¬ R v v) (s : Finset V)
    (hp : ∀ u ∈ s, ∀ v ∈ s, u ≠ v → Independent R {u,v}) :
    Independent R s := by
  intro u hu v hv
  by_cases h : u = v
  · subst v; exact hR u
  · exact hp u hu v hv h u (by simp) v (by simp)

abbrev Branch (a p q : ℕ) := (Fin a × Fin p) ⊕ (Fin a × Fin q)
def key {a p q : ℕ} : Branch a p q → (Fin a ⊕ Fin a)
  | .inl v => .inl v.1
  | .inr v => .inr v.1

def BranchAdj {a p q : ℕ} (u v : Branch a p q) : Prop :=
  u ≠ v ∧ key u = key v

abbrev Vertices (a : ℕ) := (Branch a 1 5 ⊕ Branch a 2 3) ⊕ Fin (7*a)

def Adj {a : ℕ} : Vertices a → Vertices a → Prop
  | .inl (.inl u), .inl (.inl v) => BranchAdj u v
  | .inl (.inr u), .inl (.inr v) => BranchAdj u v
  | .inl (.inl _), .inl (.inr _) => True
  | .inl (.inr _), .inl (.inl _) => True
  | _, _ => False

theorem adj_irreflexive {a : ℕ} (v : Vertices a) : ¬ Adj v v := by
  rcases v with (u | v) | e
  · simp [Adj, BranchAdj]
  · simp [Adj, BranchAdj]
  · simp [Adj]

theorem adj_symmetric {a : ℕ} (u v : Vertices a) : Adj u v ↔ Adj v u := by
  rcases u with (u | u) | u <;> rcases v with (v | v) | v <;>
    simp [Adj, BranchAdj, eq_comm]


theorem vertices_card (a : ℕ) : Fintype.card (Vertices a) = 18*a := by
  simp only [Vertices, Branch, Fintype.card_sum, Fintype.card_prod, Fintype.card_fin]
  ring

theorem actual_vertex (a : ℕ) (v : Vertices a) : Independent Adj {v} := by
  classical
  exact independent_singleton Adj adj_irreflexive v

#print axioms independent_flag
#print axioms adj_symmetric
#print axioms vertices_card
#print axioms actual_vertex
#eval Lean.versionString
end PureFlag
