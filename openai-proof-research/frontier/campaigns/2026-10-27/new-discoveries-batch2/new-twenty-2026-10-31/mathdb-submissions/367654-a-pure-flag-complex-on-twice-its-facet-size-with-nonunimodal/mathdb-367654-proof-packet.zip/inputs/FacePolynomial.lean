import FaceBijections
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.BigOperators.Ring.Finset
namespace PureFlag
open scoped BigOperators
open Polynomial
noncomputable def facePoly {V : Type*} [Fintype V] (R : V → V → Prop) : ℤ[X] :=
  ∑ s : Faces R, X ^ s.val.card

variable {A B : Type*} [Fintype A] [Fintype B] [DecidableEq A] [DecidableEq B]
omit [DecidableEq A] [DecidableEq B] in
theorem facePoly_disjoint (R : A → A → Prop) (S : B → B → Prop) :
    facePoly (DisjointRel R S) = facePoly R * facePoly S := by
  classical
  unfold facePoly
  rw [Fintype.sum_equiv (disjointFaceEquiv R S) _
    (fun p : Faces R × Faces S => X ^ (p.1.val.card + p.2.val.card))
    (fun u => congrArg (fun n => (X : ℤ[X])^n) (disjointFaceEquiv_size R S u))]
  simp only [Fintype.sum_prod_type,pow_add,Finset.sum_mul,Finset.mul_sum]
  exact Finset.sum_comm

omit [Fintype A] [DecidableEq A] [DecidableEq B] in
theorem nonempty_face_sum (S : B → B → Prop) :
    (∑ s : {s : Faces S // s.val.Nonempty}, (X : ℤ[X])^s.val.val.card) + 1 = facePoly S := by
  classical
  have he : (∑ s : {s : Faces S // ¬s.val.Nonempty}, (X : ℤ[X])^s.val.val.card) = 1 := by
    let e : {s : Faces S // ¬s.val.Nonempty} ≃ Unit :=
      { toFun := fun _ => ()
        invFun := fun _ => ⟨⟨∅,independent_empty S⟩,by simp⟩
        left_inv := by intro s; apply Subtype.ext; apply Subtype.ext; exact (Finset.not_nonempty_iff_eq_empty.mp s.property).symm
        right_inv := by intro u; cases u; rfl }
    rw [Fintype.sum_equiv e _ (fun _ => (1 : ℤ[X])) (by
      intro s
      rw [Finset.not_nonempty_iff_eq_empty.mp s.property]
      simp)]
    simp
  rw [← he]
  exact Fintype.sum_subtype_add_sum_subtype (fun s : Faces S => s.val.Nonempty) (fun s => (X : ℤ[X])^s.val.card)

theorem facePoly_join (R : A → A → Prop) (S : B → B → Prop) :
    facePoly (JoinRel R S) = facePoly R + facePoly S - 1 := by
  classical
  have h := Fintype.sum_equiv (joinFaceEquiv R S)
    (fun u => Sum.elim (fun s : Faces R => (X : ℤ[X])^s.val.card)
      (fun s : {s : Faces S // s.val.Nonempty} => X^s.val.val.card) u)
    (fun u => (X : ℤ[X])^u.val.card)
    (by intro u; rw [joinEncode_size]; cases u <;> rfl)
  rw [Fintype.sum_sum_type] at h
  simp only [Sum.elim_inl,Sum.elim_inr] at h
  have he := nonempty_face_sum S
  unfold facePoly at *
  rw [← h, ← he]
  ring

omit [DecidableEq A] in
theorem facePoly_coeff_count (R : A → A → Prop) (n : ℕ) :
    (facePoly R).coeff n = (Fintype.card {s : Faces R // s.val.card = n} : ℤ) := by
  classical
  simp [facePoly,Polynomial.coeff_X_pow,eq_comm,Fintype.card_subtype]

#print axioms facePoly
#print axioms facePoly_disjoint
#print axioms nonempty_face_sum
#print axioms facePoly_join
#print axioms facePoly_coeff_count
end PureFlag
