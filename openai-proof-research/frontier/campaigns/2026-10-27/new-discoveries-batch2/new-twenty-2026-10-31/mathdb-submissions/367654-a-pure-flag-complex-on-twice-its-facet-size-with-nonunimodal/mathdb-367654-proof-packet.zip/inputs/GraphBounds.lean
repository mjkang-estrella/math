import FTransport
import Mathlib.Algebra.Order.Field.Basic
import Mathlib.Tactic.FieldSimp
namespace PureFlag
open scoped BigOperators
open Polynomial
variable {V K : Type*}
theorem keyed_bound [Fintype K] (k : V → K) (s : Finset V)
    (hs : Independent (fun u v => u ≠ v ∧ k u = k v) s) : s.card ≤ Fintype.card K := by
  classical
  apply Finset.card_le_card_of_injOn k (fun _ _ => Finset.mem_univ _)
  intro u hu v hv he
  by_contra hn
  exact hs u hu v hv ⟨hn,he⟩

theorem branch_bound (a p q : ℕ) (s : Finset (Branch a p q))
    (hs : Independent BranchAdj s) : s.card ≤ 2*a := by
  have h := keyed_bound key s hs
  simp only [Fintype.card_sum,Fintype.card_fin] at h
  omega

theorem actual_face_bound (a : ℕ) (s : Faces (@Adj a)) : s.val.card ≤ 9*a := by
  classical
  have hh := (congrArg (fun R : Vertices a → Vertices a → Prop => Independent R s.val) (adj_decomposition a)).mp s.property
  have hf := (disjoint_faces _ _ s.val.toLeft s.val.toRight).mp (by rw [Finset.toLeft_disjSum_toRight]; exact hh)
  have hj := (join_faces _ _ s.val.toLeft.toLeft s.val.toLeft.toRight).mp
    (by rw [Finset.toLeft_disjSum_toRight]; exact hf.1)
  have hb1 := branch_bound a 1 5 _ hj.1
  have hb2 := branch_bound a 2 3 _ hj.2.1
  have hi : s.val.toRight.card ≤ 7*a := by simpa using Finset.card_le_univ s.val.toRight
  have h1 := split_card s.val
  have h2 := split_card s.val.toLeft
  rcases hj.2.2 with h | h <;> rw [h,Finset.card_empty] at h2 <;> omega

theorem actual_coeff_nonneg (a n : ℕ) : 0 ≤ (facePoly (@Adj a)).coeff n := by
  rw [facePoly_coeff_count]
  exact Nat.cast_nonneg _

theorem actual_coeff_support (a n : ℕ) (hn : 9*a < n) : (facePoly (@Adj a)).coeff n = 0 := by
  classical
  simp only [facePoly,finsetSum_coeff]
  apply Finset.sum_eq_zero
  intro s hs
  have he : s.val.card ≠ n := by have := actual_face_bound a s; omega
  simp [Polynomial.coeff_X_pow,Ne.symm he]

def commonMass (a : ℕ) : ℚ := 2^(7*a)*12^a
def emptyMass (a : ℕ) : ℚ := 2^(7*a)
theorem commonMass_pos (a : ℕ) : 0 < commonMass a := by unfold commonMass; positivity

theorem normalized_empty_ratio (a : ℕ) : emptyMass a / commonMass a = 1/(12:ℚ)^a := by
  unfold emptyMass commonMass
  have h : (2:ℚ)^(7*a) ≠ 0 := by positivity
  field_simp

theorem normalized_empty_bound (a : ℕ) (ha : 0 < a) :
    0 < emptyMass a / commonMass a ∧ emptyMass a / commonMass a ≤ 1/12 := by
  rw [normalized_empty_ratio]
  have hp : (12:ℚ) ≤ 12^a := by
    obtain ⟨n,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : a ≠ 0)
    have hh : (1:ℚ) ≤ 12^n := one_le_pow₀ (by norm_num)
    rw [pow_succ]
    nlinarith
  constructor
  · positivity
  · apply (div_le_div_iff₀ (by positivity : (0:ℚ)<12^a) (by norm_num : (0:ℚ)<12)).mpr
    simpa using hp

theorem exact_window_containment (j : ℤ)
    (h : (144375 ≤ j ∧ j ≤ 145624) ∨ (145625 ≤ j ∧ j ≤ 146874) ∨ (146875 ≤ j ∧ j ≤ 148124)) :
    0 ≤ j-1 ∧ j-1 < 270000 := by omega

#print axioms keyed_bound
#print axioms branch_bound
#print axioms actual_face_bound
#print axioms actual_coeff_nonneg
#print axioms actual_coeff_support
#print axioms commonMass_pos
#print axioms normalized_empty_ratio
#print axioms normalized_empty_bound
#print axioms exact_window_containment
end PureFlag
