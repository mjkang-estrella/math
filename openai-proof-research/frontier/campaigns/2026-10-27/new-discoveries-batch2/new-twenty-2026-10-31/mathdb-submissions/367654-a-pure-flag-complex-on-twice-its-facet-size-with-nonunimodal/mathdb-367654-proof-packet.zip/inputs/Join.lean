import Complex
import Mathlib.Data.Finset.Sum

namespace PureFlag
variable {A B : Type*} [DecidableEq A] [DecidableEq B]

def JoinRel (R : A → A → Prop) (S : B → B → Prop) : (A ⊕ B) → (A ⊕ B) → Prop
  | .inl u, .inl v => R u v
  | .inr u, .inr v => S u v
  | _, _ => True

def DisjointRel (R : A → A → Prop) (S : B → B → Prop) : (A ⊕ B) → (A ⊕ B) → Prop
  | .inl u, .inl v => R u v
  | .inr u, .inr v => S u v
  | _, _ => False

theorem join_faces (R : A → A → Prop) (S : B → B → Prop)
    (s : Finset A) (t : Finset B) :
    Independent (JoinRel R S) (s.disjSum t) ↔
      Independent R s ∧ Independent S t ∧ (s = ∅ ∨ t = ∅) := by
  constructor
  · intro h
    refine ⟨?_, ?_, ?_⟩
    · intro u hu v hv
      exact h (.inl u) (by simp [hu]) (.inl v) (by simp [hv])
    · intro u hu v hv
      exact h (.inr u) (by simp [hu]) (.inr v) (by simp [hv])
    · by_cases hs : s = ∅
      · exact Or.inl hs
      · right
        by_contra ht
        obtain ⟨u, hu⟩ := Finset.nonempty_iff_ne_empty.mpr hs
        obtain ⟨v, hv⟩ := Finset.nonempty_iff_ne_empty.mpr ht
        exact h (.inl u) (by simp [hu]) (.inr v) (by simp [hv]) trivial
  · rintro ⟨hs, ht, hempty⟩ u hu v hv
    rcases u with u | u <;> rcases v with v | v
    · exact hs u (by simpa using hu) v (by simpa using hv)
    · rcases hempty with he | he
      · simp [he] at hu
      · simp [he] at hv
    · rcases hempty with he | he
      · simp [he] at hv
      · simp [he] at hu
    · exact ht u (by simpa using hu) v (by simpa using hv)

omit [DecidableEq A] [DecidableEq B] in
theorem disjoint_faces (R : A → A → Prop) (S : B → B → Prop)
    (s : Finset A) (t : Finset B) :
    Independent (DisjointRel R S) (s.disjSum t) ↔
      Independent R s ∧ Independent S t := by
  constructor
  · intro h
    constructor
    · intro u hu v hv
      exact h (.inl u) (by simp [hu]) (.inl v) (by simp [hv])
    · intro u hu v hv
      exact h (.inr u) (by simp [hu]) (.inr v) (by simp [hv])
  · rintro ⟨hs, ht⟩ u hu v hv
    rcases u with u | u <;> rcases v with v | v
    · exact hs u (by simpa using hu) v (by simpa using hv)
    · exact not_false
    · exact not_false
    · exact ht u (by simpa using hu) v (by simpa using hv)

-- The two branch embeddings overlap at exactly the empty face.
omit [DecidableEq A] [DecidableEq B] in
theorem empty_overlap (s : Finset A) (t : Finset B)
    (h : s.disjSum (∅ : Finset B) = (∅ : Finset A).disjSum t) :
    s = ∅ ∧ t = ∅ := by
  have hl := congrArg Finset.toLeft h
  have hr := congrArg Finset.toRight h
  simpa only [Finset.toLeft_disjSum, Finset.toRight_disjSum] using And.intro hl hr.symm

omit [DecidableEq A] [DecidableEq B] in
theorem split_card (s : Finset (A ⊕ B)) :
    s.card = s.toLeft.card + s.toRight.card := by
  exact Finset.card_toLeft_add_card_toRight.symm

#print axioms join_faces
#print axioms disjoint_faces
#print axioms empty_overlap
#print axioms split_card
end PureFlag
