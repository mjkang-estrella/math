import Complex
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Option

namespace PureFlag
variable {I T : Type*} [Fintype I] [Fintype T] [DecidableEq I] [DecidableEq T]

def Partial (s : Finset (I × T)) : Prop :=
  ∀ i x y, (i,x) ∈ s → (i,y) ∈ s → x = y

def encode (f : I → Option T) : Finset (I × T) :=
  Finset.univ.filter (fun p => f p.1 = some p.2)

omit [DecidableEq I] in
@[simp] theorem mem_encode (f : I → Option T) (i : I) (t : T) :
    (i,t) ∈ encode f ↔ f i = some t := by simp [encode]

omit [DecidableEq I] in
theorem encode_partial (f : I → Option T) : Partial (encode f) := by
  intro i x y hx hy
  simp only [mem_encode] at hx hy
  exact Option.some.inj (hx.symm.trans hy)

omit [DecidableEq I] in
theorem encode_injective : Function.Injective (encode (I:=I) (T:=T)) := by
  intro f g h
  funext i
  have hm : ∀ t, f i = some t ↔ g i = some t := by
    intro t
    simpa only [mem_encode] using (show (i,t) ∈ encode f ↔ (i,t) ∈ encode g by rw [h])
  cases hf : f i with
  | none =>
    cases hg : g i with
    | none => rfl
    | some t => have := (hm t).mpr hg; simp [hf] at this
  | some t => exact ((hm t).mp hf).symm

noncomputable def decode (s : Finset (I × T)) (i : I) : Option T :=
  if h : ∃ t, (i,t) ∈ s then some (Classical.choose h) else none

omit [Fintype I] in
theorem decode_spec (s : Finset (I × T)) (hs : Partial s) (i : I) (t : T) :
    decode s i = some t ↔ (i,t) ∈ s := by
  classical
  unfold decode
  split_ifs with h
  · constructor
    · intro he
      have he' := Option.some.inj he
      rw [← he']
      exact Classical.choose_spec h
    · intro ht
      congr 1
      exact hs i _ t (Classical.choose_spec h) ht
  · constructor
    · intro he; cases he
    · intro ht; exact (h ⟨t,ht⟩).elim

theorem encode_decode (s : Finset (I × T)) (hs : Partial s) :
    encode (decode s) = s := by
  ext p
  exact (mem_encode _ p.1 p.2).trans (decode_spec s hs p.1 p.2)

noncomputable def choiceEquiv : (I → Option T) ≃ {s : Finset (I × T) // Partial s} :=
  Equiv.ofBijective (fun f => ⟨encode f, encode_partial f⟩) (by
    constructor
    · intro f g h
      exact encode_injective (congrArg Subtype.val h)
    · intro s
      exact ⟨decode s.val, Subtype.ext (encode_decode s.val s.property)⟩)

omit [Fintype I] [Fintype T] [DecidableEq I] in
theorem partial_iff_independent (s : Finset (I × T)) :
    Partial s ↔ Independent (fun u v : I × T => u ≠ v ∧ u.1 = v.1) s := by
  constructor
  · intro hs u hu v hv ⟨hne, heq⟩
    apply hne
    apply Prod.ext heq
    apply hs u.1 u.2 v.2 hu
    simpa only [heq] using hv
  · intro hs i x y hx hy
    by_contra hne
    exact hs (i,x) hx (i,y) hy ⟨by intro h; exact hne (congrArg Prod.snd h), rfl⟩

#print axioms choiceEquiv
#print axioms encode_decode
#print axioms partial_iff_independent
end PureFlag
