import ActualDistribution
import Mathlib.Order.Interval.Finset.Nat
namespace PureFlag
open scoped BigOperators
open Polynomial
abbrev D (a : ℕ) : Finset ℕ := Finset.range (9*a+1)
abbrev B (s : ℕ) : Finset ℕ := Finset.Ico s (s+1250)
noncomputable def p1 (a j : ℕ) : ℚ := (betaPower 1 (8*a)*betaPower 5 a).coeff j
noncomputable def p2 (a j : ℕ) : ℚ := (betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a).coeff j
noncomputable def p0 (a j : ℕ) : ℚ := (betaPower 1 (7*a)).coeff j

theorem cheb_block (a : ℕ) (p : ℕ → ℚ) (s : Finset ℕ) (μ v : ℚ) (hs : s ⊆ D a)
    (hp : ∀ j ∈ D a, 0 ≤ p j) (hm : (∑ j ∈ D a,p j)=1)
    (hv : (∑ j ∈ D a,((j:ℚ)-μ)^2*p j)=v)
    (ho : ∀ j ∈ D a, j ∉ s → (625:ℚ)^2 ≤ ((j:ℚ)-μ)^2) :
    1-v/625^2 ≤ ∑ j ∈ s,p j := by
  have hc := finite_chebyshev (D a) (D a \ s) Finset.sdiff_subset p (fun j => (j:ℚ)) μ 625 hp
    (by norm_num) (fun j hj => ho j (Finset.mem_sdiff.mp hj).1 (Finset.mem_sdiff.mp hj).2)
  rw [hv] at hc
  have ht : (∑ j ∈ D a \ s,p j)+(∑ j ∈ s,p j) = ∑ j ∈ D a,p j := Finset.sum_sdiff hs
  rw [hm] at ht
  norm_num at hc ⊢
  linarith

theorem left_concentration (a : ℕ) (ha : a=30000) : 1-308/1875 ≤ ∑ j ∈ B 144375,p1 a j := by
  have h := first_range a
  rw [show 29*(a:ℚ)/6=145000 by rw [ha]; norm_num, show 77*(a:ℚ)/36=192500/3 by rw [ha]; norm_num] at h
  have hh := cheb_block a (p1 a) (B 144375) 145000 (192500/3)
    (by intro j hj; simp only [B,Finset.mem_Ico] at hj; simp only [D,Finset.mem_range]; omega)
    (fun j _ => h.2.2 j) h.1
    h.2.1 ?_
  · convert hh using 1
    norm_num
  · intro j _ hj
    have hj' : j < 144375 ∨ 145625 ≤ j := by simpa only [B,Finset.mem_Ico,not_and_or,not_le,not_lt] using hj
    rcases hj' with hj'|hj'
    · have hjq : (j:ℚ) ≤ 144374 := by exact_mod_cast (show j ≤ 144374 by omega)
      nlinarith [sq_nonneg ((j:ℚ)-145000+625)]
    · have hjq : (145625:ℚ) ≤ j := by exact_mod_cast hj'
      nlinarith [sq_nonneg ((j:ℚ)-145000-625)]

theorem right_concentration (a : ℕ) (ha : a=30000) : 1-311/1875 ≤ ∑ j ∈ B 146875,p2 a j := by
  have h := second_range a
  rw [show 59*(a:ℚ)/12=147500 by rw [ha]; norm_num, show 311*(a:ℚ)/144=194375/3 by rw [ha]; norm_num] at h
  have hh := cheb_block a (p2 a) (B 146875) 147500 (194375/3)
    (by intro j hj; simp only [B,Finset.mem_Ico] at hj; simp only [D,Finset.mem_range]; omega)
    (fun j _ => h.2.2 j) h.1
    h.2.1 ?_
  · convert hh using 1
    norm_num
  · intro j _ hj
    have hj' : j < 146875 ∨ 148125 ≤ j := by simpa only [B,Finset.mem_Ico,not_and_or,not_le,not_lt] using hj
    rcases hj' with hj'|hj'
    · have hjq : (j:ℚ) ≤ 146874 := by exact_mod_cast (show j ≤ 146874 by omega)
      nlinarith [sq_nonneg ((j:ℚ)-147500+625)]
    · have hjq : (148125:ℚ) ≤ j := by exact_mod_cast hj'
      nlinarith [sq_nonneg ((j:ℚ)-147500-625)]
#print axioms cheb_block
#print axioms left_concentration
#print axioms right_concentration
end PureFlag
