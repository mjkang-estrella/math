import re,json,hashlib,subprocess,base64
from pathlib import Path
NAMES="Complex Join Choices Purity ChoiceCounts FaceBijections GraphPolynomial FacePolynomial BetaPowers GraphBounds MixedPurity Heterogeneous MixedCoefficients Moments Variance RangeMoments NormalizedPowers SecondBranch ActualNormalization BranchScaling ActualDistribution DegreePushforward ActualBlocks ChebyshevBlocks Windows Valley FTransport ZeroExtension FinalWitness Endpoint AuditV3".split()
allowed=set(NAMES)
H=b'# COMPLETE LEAN SOURCE APPENDIX v3\n\nAll imported local production sources, in topological order. UTF-8 payloads include their final newline. Failed drafts are excluded. Upstream specific Mathlib imports use PINS.json.\n\n'
def digest(b):return hashlib.sha256(b).hexdigest()
def parse(raw,records,copies):
 assert raw.startswith(H),'header'
 pos=len(H); found={}; order=[]
 while pos<len(raw):
  m=re.compile(rb'<!-- BEGIN LEAN MODULE ([A-Za-z][A-Za-z0-9_]*) SHA256 ([0-9a-f]{64}) -->\n```lean\n').match(raw,pos)
  assert m,'begin marker'
  name=m[1].decode(); assert name in allowed and name not in found,'unknown/duplicate'
  start=m.end(); end=raw.find(b'```\n',start); assert end>=start,'fence'
  body=raw[start:end]; assert body.endswith(b'\n') and b'```' not in body and b'<!--' not in body,'body/fence'
  close=('```\n<!-- END LEAN MODULE '+name+' -->\n').encode()
  assert raw.startswith(close,end),'end marker'
  pos=end+len(close)
  if pos<len(raw): assert raw[pos:pos+1]==b'\n'; pos+=1
  assert digest(body)==m[2].decode()==records[name]['sha256'],'hash'
  assert len(body)==records[name]['bytes'] and body==copies[name],'copy/length'
  text=body.decode('utf-8')
  assert not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide)\b', re.sub(r'(?m)^\s*--[^\n]*', '', text)), 'forbidden'
  imports=re.findall(r'^import ([A-Za-z][A-Za-z0-9_.]*)$',text,re.M)
  assert imports==records[name]['imports'],'import map'
  for dep in imports:
   assert dep!='Mathlib' and (dep.startswith('Mathlib.') or dep in found),'dependency closure/order'
  found[name]=body;order.append(name)
 assert set(found)==allowed,'missing modules'
 return found,order
raw=Path('inputs/LEAN-SOURCE-APPENDIX-v3.md').read_bytes()
source_map=json.loads(Path('inputs/SOURCE-MAP-v3.json').read_text())
records={}
for rec in source_map['sources']:
 n=rec['module']; assert n in allowed and n not in records
 assert rec['path']=='src/'+n+'.lean'; records[n]=rec
assert set(records)==allowed
copies={n:Path('inputs',n+'.lean').read_bytes() for n in NAMES}
found,order=parse(raw,records,copies)
# Memory-only adversarial mutations; production bytes remain untouched.
first=order[0]; marker=b'<!-- BEGIN LEAN MODULE '+first.encode()
cases={
 'unknown':raw.replace(marker,b'<!-- BEGIN LEAN MODULE Unknown',1),
 'unsafe_name':raw.replace(marker,b'<!-- BEGIN LEAN MODULE ../Complex',1),
 'hash_alteration':raw.replace(records[first]['sha256'].encode(),b'0'*64,1),
 'body_alteration':raw.replace(b'namespace PureFlag',b'namespace PureFlax',1),
 'trailing':raw+b'garbage',
 'mismatched_end':raw.replace(b'<!-- END LEAN MODULE Complex -->',b'<!-- END LEAN MODULE Join -->',1),
 'missing':H+raw[raw.index(b'<!-- BEGIN LEAN MODULE Join'):],
 'duplicate':raw+b'\n'+raw[len(H):raw.index(b'<!-- BEGIN LEAN MODULE Join')].rstrip(b'\n')+b'\n',
 'fence':raw.replace(b'```lean\n',b'```python\n',1)}
results={}
for label,bad in cases.items():
 try:parse(bad,records,copies)
 except (AssertionError,UnicodeError,KeyError): results[label]='REJECT'
 else:raise AssertionError('negative control accepted: '+label)
def write(name,data,binary=False):
 p=subprocess.run(['python3','-I','-B','write_lane.py',name]+(['--base64'] if binary else []),input=base64.b64encode(data).decode() if binary else data,text=True,capture_output=True); assert p.returncode==0,p.stderr
assert not any(Path('src').iterdir()) and not any(Path('build').iterdir()) and not any(Path('cache').iterdir())
for n in order:write('src/'+n+'.lean',found[n],True)
write('independent-parser-results.json',json.dumps(dict(order=order,negative_controls=results,appendix_sha256=digest(raw),sources={n:digest(found[n]) for n in order}),indent=2))
print('Strict byte extraction PASS: 31 source copies/map hashes; 9 memory-only negative controls rejected; topological closure verified.')
