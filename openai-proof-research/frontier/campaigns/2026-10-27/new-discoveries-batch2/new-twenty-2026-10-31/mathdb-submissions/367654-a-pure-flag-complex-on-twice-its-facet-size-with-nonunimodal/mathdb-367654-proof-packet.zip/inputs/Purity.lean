import Join
import Mathlib.Data.Fintype.BigOperators
namespace PureFlag
variable {V K A B : Type*}
def MaxInd (R : V → V → Prop) (s : Finset V) : Prop :=
  Independent R s ∧ ∀ t, Independent R t → s ⊆ t → t = s

theorem keyed_card [Fintype K] [DecidableEq V] (k : V → K)
    (rep : K → V) (hr : ∀ i, k (rep i) = i) (s : Finset V)
    (hs : MaxInd (fun u v => u ≠ v ∧ k u = k v) s) : s.card = Fintype.card K := by
  classical
  apply Finset.card_bij (fun v _ => k v)
  · intro v hv; simp
  · intro u hu v hv he
    by_contra hn
    exact hs.1 u hu v hv ⟨hn,he⟩
  · intro i hi
    by_contra hn
    have hn' : ∀ v ∈ s, k v ≠ i := by simpa using hn
    have hp : Independent (fun u v => u ≠ v ∧ k u = k v) (insert (rep i) s) := by
      intro u hu v hv ⟨hne,he⟩
      simp only [Finset.mem_insert] at hu hv
      rcases hu with rfl | hu <;> rcases hv with rfl | hv
      · exact hne rfl
      · exact hn' v hv (he.symm.trans (hr i))
      · exact hn' u hu (he.trans (hr i))
      · exact hs.1 u hu v hv ⟨hne,he⟩
    have he := hs.2 _ hp (Finset.subset_insert _ _)
    have hm : rep i ∈ s := by rw [← he]; simp
    exact hn' _ hm (hr i)

variable [DecidableEq A] [DecidableEq B]
omit [DecidableEq A] [DecidableEq B] in
theorem max_disjoint (R : A → A → Prop) (S : B → B → Prop)
    (s : Finset A) (t : Finset B) :
    MaxInd (DisjointRel R S) (s.disjSum t) ↔ MaxInd R s ∧ MaxInd S t := by
  constructor
  · intro h
    have hf := (disjoint_faces R S s t).mp h.1
    constructor
    · refine ⟨hf.1, ?_⟩
      intro u hu hsu
      have he := h.2 (u.disjSum t) ((disjoint_faces R S u t).mpr ⟨hu,hf.2⟩)
        (Finset.disjSum_subset.mpr (by simpa using And.intro hsu (Finset.Subset.refl t)))
      simpa using congrArg Finset.toLeft he
    · refine ⟨hf.2, ?_⟩
      intro u hu htu
      have he := h.2 (s.disjSum u) ((disjoint_faces R S s u).mpr ⟨hf.1,hu⟩)
        (Finset.disjSum_subset.mpr (by simpa using And.intro (Finset.Subset.refl s) htu))
      simpa using congrArg Finset.toRight he
  · rintro ⟨hs,ht⟩
    refine ⟨(disjoint_faces R S s t).mpr ⟨hs.1,ht.1⟩, ?_⟩
    intro u hu hsu
    have hf := (disjoint_faces R S u.toLeft u.toRight).mp (by rw [Finset.toLeft_disjSum_toRight]; exact hu)
    have hsub := Finset.disjSum_subset.mp hsu
    have hl := hs.2 _ hf.1 hsub.1
    have hr := ht.2 _ hf.2 hsub.2
    rw [← (Finset.toLeft_disjSum_toRight (u := u)), hl, hr]

theorem max_join_left (R : A → A → Prop) (S : B → B → Prop)
    (s : Finset A) (hn : s.Nonempty) (hs : MaxInd R s) :
    MaxInd (JoinRel R S) (s.disjSum ∅) := by
  refine ⟨(join_faces R S s ∅).mpr ⟨hs.1, independent_empty S, Or.inr rfl⟩, ?_⟩
  intro u hu hsu
  have hf := (join_faces R S u.toLeft u.toRight).mp (by rw [Finset.toLeft_disjSum_toRight]; exact hu)
  have hsub := (Finset.disjSum_subset.mp hsu).1
  have hl := hs.2 _ hf.1 hsub
  have hr : u.toRight = ∅ := by
    rcases hf.2.2 with he | he
    · have : s = ∅ := Finset.eq_empty_iff_forall_notMem.mpr (by
        intro v hv; have := hsub hv; simp [he] at this)
      exact (hn.ne_empty this).elim
    · exact he
  rw [← (Finset.toLeft_disjSum_toRight (u := u)), hl, hr]

#print axioms keyed_card
#print axioms max_disjoint
#print axioms max_join_left
end PureFlag
