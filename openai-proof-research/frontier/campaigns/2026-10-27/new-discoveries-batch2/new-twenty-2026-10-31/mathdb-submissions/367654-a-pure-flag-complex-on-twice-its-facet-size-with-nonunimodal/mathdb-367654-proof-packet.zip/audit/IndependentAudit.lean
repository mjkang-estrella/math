import FinalWitness
set_option pp.universes true
set_option pp.explicit true
#print PureFlag.FiniteComplex
#print PureFlag.FiniteComplex.Facet
#print PureFlag.FiniteComplex.Pure
#print PureFlag.FiniteComplex.Flag
#print PureFlag.FiniteComplex.f
#print PureFlag.FiniteComplex.Unimodal
#print PureFlag.BroadConjecture
#print PureFlag.allTypesBroadConjecture
#check @PureFlag.literal_broad_refutation
namespace IndependentReview
theorem expandedEndpoint : ¬ (∀ (V : Type) [Fintype V] [DecidableEq V],
  ∀ d : ℕ, 0 < d → ∀ K : PureFlag.FiniteComplex V,
  Fintype.card V = 2*d → K.Pure d → K.Flag → K.Unimodal d) :=
  PureFlag.literal_broad_refutation
#print axioms expandedEndpoint
end IndependentReview
#print axioms PureFlag.FiniteComplex.Facet
#print axioms PureFlag.FiniteComplex.Flag
#print axioms PureFlag.FiniteComplex.Pure
#print axioms PureFlag.FiniteComplex.Unimodal
#print axioms PureFlag.FiniteComplex.f
#print axioms PureFlag.actualRat_f
#print axioms PureFlag.actualW_nonneg
#print axioms PureFlag.actualW_support
#print axioms PureFlag.actualW_total
#print axioms PureFlag.actual_block_valley
#print axioms PureFlag.actual_coeff_nonneg
#print axioms PureFlag.actual_coeff_support
#print axioms PureFlag.actual_f_coeff
#print axioms PureFlag.actual_f_not_unimodal
#print axioms PureFlag.actual_face_bound
#print axioms PureFlag.actual_first_branch_mass
#print axioms PureFlag.actual_graph_polynomial
#print axioms PureFlag.actual_mass_at_one_v3
#print axioms PureFlag.actual_missing_witness
#print axioms PureFlag.actual_normalization
#print axioms PureFlag.actual_normalized_coefficient
#print axioms PureFlag.actual_rat_decomposition
#print axioms PureFlag.actual_second_branch_mass
#print axioms PureFlag.actual_vertex
#print axioms PureFlag.adj_decomposition
#print axioms PureFlag.adj_symmetric
#print axioms PureFlag.allTypesBroadConjecture
#print axioms PureFlag.bernoulli_variance
#print axioms PureFlag.betaPower_coeff_nonneg
#print axioms PureFlag.betaPower_moments
#print axioms PureFlag.betaPower_support
#print axioms PureFlag.beta_moments
#print axioms PureFlag.beta_power_scale
#print axioms PureFlag.block_bounds
#print axioms PureFlag.block_window
#print axioms PureFlag.branch_bound
#print axioms PureFlag.branch_decomposition
#print axioms PureFlag.branch_max_card
#print axioms PureFlag.branch_polynomial
#print axioms PureFlag.centered_second
#print axioms PureFlag.cheb_block
#print axioms PureFlag.choiceEquiv
#print axioms PureFlag.coefficient_centered
#print axioms PureFlag.commonMass_pos
#print axioms PureFlag.degreePoly_coeff
#print axioms PureFlag.degreePoly_product
#print axioms PureFlag.degreeWeight_nonneg
#print axioms PureFlag.degreeWeight_outside
#print axioms PureFlag.degree_transport
#print axioms PureFlag.disjointFaceEquiv
#print axioms PureFlag.disjointFaceEquiv_size
#print axioms PureFlag.disjoint_faces
#print axioms PureFlag.empty_overlap
#print axioms PureFlag.empty_range
#print axioms PureFlag.encode_card
#print axioms PureFlag.encode_decode
#print axioms PureFlag.exact_leaf_values
#print axioms PureFlag.exact_window_containment
#print axioms PureFlag.exists_drop
#print axioms PureFlag.facePoly
#print axioms PureFlag.facePoly_coeff_count
#print axioms PureFlag.facePoly_disjoint
#print axioms PureFlag.facePoly_join
#print axioms PureFlag.finite_chebyshev
#print axioms PureFlag.finite_unimodal_zeroF
#print axioms PureFlag.finite_window_valley
#print axioms PureFlag.first_branch_moments
#print axioms PureFlag.first_branch_polynomial
#print axioms PureFlag.first_coefficients
#print axioms PureFlag.first_range
#print axioms PureFlag.first_scale
#print axioms PureFlag.graphComplex
#print axioms PureFlag.graphComplex_flag
#print axioms PureFlag.graph_facet_card
#print axioms PureFlag.graph_pure
#print axioms PureFlag.heterogeneous_moments
#print axioms PureFlag.independent_flag
#print axioms PureFlag.isolates_polynomial
#print axioms PureFlag.joinEncode_size
#print axioms PureFlag.joinFaceEquiv
#print axioms PureFlag.join_faces
#print axioms PureFlag.keyed_bound
#print axioms PureFlag.keyed_card
#print axioms PureFlag.keyed_rep_max
#print axioms PureFlag.left_concentration
#print axioms PureFlag.literal_broad_refutation
#print axioms PureFlag.maxPartial_card
#print axioms PureFlag.max_disjoint
#print axioms PureFlag.max_join_card
#print axioms PureFlag.max_join_left
#print axioms PureFlag.middle_bound
#print axioms PureFlag.no_reversed_window_signs
#print axioms PureFlag.nonempty_face_sum
#print axioms PureFlag.normalized_empty_bound
#print axioms PureFlag.normalized_empty_ratio
#print axioms PureFlag.outer_negation_of_actual_failure
#print axioms PureFlag.partial_count
#print axioms PureFlag.partial_iff_independent
#print axioms PureFlag.point_valley_not_mode
#print axioms PureFlag.positive_index_translation
#print axioms PureFlag.product_centered_variance
#print axioms PureFlag.product_first
#print axioms PureFlag.product_mass
#print axioms PureFlag.product_second
#print axioms PureFlag.rational_block_valley
#print axioms PureFlag.right_concentration
#print axioms PureFlag.second_branch_moments
#print axioms PureFlag.second_branch_polynomial
#print axioms PureFlag.second_coefficients
#print axioms PureFlag.second_range
#print axioms PureFlag.second_scale
#print axioms PureFlag.split_card
#print axioms PureFlag.trialDegree_le
#print axioms PureFlag.trialWeight_nonneg
#print axioms PureFlag.trial_moments
#print axioms PureFlag.trial_polynomial
#print axioms PureFlag.uniformFaceEquiv
#print axioms PureFlag.uniform_polynomial
#print axioms PureFlag.vertices_card
#print axioms PureFlag.window_step
#print axioms PureFlag.window_valley_not_mode
#print axioms PureFlag.witness_pure
#print axioms PureFlag.witness_vertices
#print axioms PureFlag.zeroF
