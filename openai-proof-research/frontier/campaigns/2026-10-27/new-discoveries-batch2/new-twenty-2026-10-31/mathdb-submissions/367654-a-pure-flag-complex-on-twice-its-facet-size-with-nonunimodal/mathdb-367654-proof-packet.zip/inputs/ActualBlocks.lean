import ChebyshevBlocks
namespace PureFlag
open scoped BigOperators
noncomputable def blockMass (a s : ℕ) : ℚ := ∑ j ∈ B s,actualW a j

theorem block_subset (a s : ℕ) (ha : a=30000) (hs : s+1250 ≤ 270001) : B s ⊆ D a := by
  intro j hj
  simp only [B,Finset.mem_Ico] at hj
  simp only [D,Finset.mem_range]
  omega

theorem block_bounds (a s : ℕ) (ha : a=30000) (hs : s+1250 ≤ 270001) :
    (∑ j ∈ B s,p1 a j)-emptyMass a/commonMass a ≤ blockMass a s ∧
    (∑ j ∈ B s,p2 a j)-emptyMass a/commonMass a ≤ blockMass a s := by
  have hp0 : (∑ j ∈ B s,p0 a j) ≤ 1 := by
    rw [← empty_range a]
    apply Finset.sum_le_sum_of_subset_of_nonneg (block_subset a s ha hs)
    intro j _ _
    exact betaPower_coeff_nonneg 1 (by norm_num) _ _
  have hp1 : 0 ≤ ∑ j ∈ B s,p1 a j := Finset.sum_nonneg (fun j _ => (first_range a).2.2 j)
  have hp2 : 0 ≤ ∑ j ∈ B s,p2 a j := Finset.sum_nonneg (fun j _ => (second_range a).2.2 j)
  have hq : 0 ≤ emptyMass a/commonMass a := div_nonneg (by unfold emptyMass; positivity) (le_of_lt (commonMass_pos a))
  have he : blockMass a s = (∑ j ∈ B s,p1 a j)+(∑ j ∈ B s,p2 a j)-
      (emptyMass a/commonMass a)*(∑ j ∈ B s,p0 a j) := by
    simp only [blockMass,actualW,actual_normalized_coefficient,p1,p2,p0,
      Finset.sum_add_distrib,Finset.sum_sub_distrib,Finset.mul_sum]
  have hprod := mul_le_mul_of_nonneg_left hp0 hq
  rw [he]
  constructor <;> linarith only [hprod,hp1,hp2]

theorem middle_bound (a : ℕ) (ha : a=30000) :
    blockMass a 145625 ≤ (2-emptyMass a/commonMass a)-blockMass a 144375-blockMass a 146875 := by
  have h12 : Disjoint (B 144375) (B 145625) := by
    apply Finset.disjoint_left.mpr
    intro j hj hk
    simp only [B,Finset.mem_Ico] at hj hk
    omega
  have h123 : Disjoint (B 144375 ∪ B 145625) (B 146875) := by
    apply Finset.disjoint_left.mpr
    intro j hj hk
    simp only [Finset.mem_union,B,Finset.mem_Ico] at hj hk
    omega
  have hs : (B 144375 ∪ B 145625) ∪ B 146875 ⊆ D a := by
    intro j hj
    simp only [Finset.mem_union] at hj
    rcases hj with (hj|hj)|hj
    · exact block_subset a 144375 ha (by norm_num) hj
    · exact block_subset a 145625 ha (by norm_num) hj
    · exact block_subset a 146875 ha (by norm_num) hj
  have hh := Finset.sum_le_sum_of_subset_of_nonneg hs (fun j _ _ => actualW_nonneg a j)
  rw [Finset.sum_union h123,Finset.sum_union h12,actualW_total] at hh
  change blockMass a 144375+blockMass a 145625+blockMass a 146875 ≤ _ at hh
  linarith

theorem actual_block_valley (a : ℕ) (ha : a=30000) :
    blockMass a 145625 < blockMass a 144375 ∧ blockMass a 145625 < blockMass a 146875 := by
  have h1 := (block_bounds a 144375 ha (by norm_num)).1
  have h3 := (block_bounds a 146875 ha (by norm_num)).2
  have hc1 := left_concentration a ha
  have hc3 := right_concentration a ha
  have hq := (normalized_empty_bound a (by omega)).2
  apply rational_block_valley (emptyMass a/commonMass a) _ _ _ hq
  · linarith
  · linarith
  · exact middle_bound a ha
#print axioms block_bounds
#print axioms middle_bound
#print axioms actual_block_valley
end PureFlag
