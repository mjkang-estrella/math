import NormalizedPowers
namespace PureFlag
open scoped BigOperators
open Polynomial
variable {I J : Type*} [Fintype I] [Fintype J]

theorem heterogeneous_moments (u : I → ℚ) (d : I → ℕ) (v : J → ℚ) (e : J → ℕ)
    (μ ν σ τ : ℚ)
    (hu : mass Finset.univ u = 1 ∧ first Finset.univ u (fun i => (d i : ℚ)) = μ ∧
      second Finset.univ u (fun i => (d i : ℚ)) = σ + μ^2)
    (hv : mass Finset.univ v = 1 ∧ first Finset.univ v (fun j => (e j : ℚ)) = ν ∧
      second Finset.univ v (fun j => (e j : ℚ)) = τ + ν^2) :
    mass Finset.univ (fun p : I × J => u p.1 * v p.2) = 1 ∧
    first Finset.univ (fun p : I × J => u p.1 * v p.2)
      (fun p => ((d p.1 + e p.2 : ℕ) : ℚ)) = μ + ν ∧
    second Finset.univ (fun p : I × J => u p.1 * v p.2)
      (fun p => ((d p.1 + e p.2 : ℕ) : ℚ)) = (σ+τ) + (μ+ν)^2 := by
  have hm := product_mass Finset.univ Finset.univ u v
  have hf := product_first Finset.univ Finset.univ u (fun i => (d i : ℚ)) v (fun j => (e j : ℚ))
  have hs := product_second Finset.univ Finset.univ u (fun i => (d i : ℚ)) v (fun j => (e j : ℚ))
  rw [hu.1,hv.1] at hm
  rw [hu.1,hv.1,hu.2.1,hv.2.1] at hf
  rw [hu.1,hv.1,hu.2.1,hv.2.1,hu.2.2,hv.2.2] at hs
  constructor
  · simpa only [mass,Fintype.sum_prod_type,mul_one] using hm
  constructor
  · simpa only [first,Fintype.sum_prod_type,Nat.cast_add,mul_one,one_mul] using hf
  · simp only [second,Fintype.sum_prod_type,Nat.cast_add]
    rw [hs]
    ring

noncomputable def mixedWeight (a : ℕ) (t : Trials (8*a) × Trials a) : ℚ :=
  trialWeight 1 (8*a) t.1 * trialWeight 5 a t.2
def mixedDegree (a : ℕ) (t : Trials (8*a) × Trials a) : ℕ :=
  trialDegree (8*a) t.1 + trialDegree a t.2

theorem first_branch_moments (a : ℕ) :
    mass Finset.univ (mixedWeight a) = 1 ∧
    first Finset.univ (mixedWeight a) (fun t => (mixedDegree a t : ℚ)) = 29*(a:ℚ)/6 ∧
    second Finset.univ (mixedWeight a) (fun t => (mixedDegree a t : ℚ)) =
      77*(a:ℚ)/36 + (29*(a:ℚ)/6)^2 := by
  have h := heterogeneous_moments _ _ _ _ _ _ _ _
    (trial_moments 1 (by norm_num) (8*a)) (trial_moments 5 (by norm_num) a)
  refine ⟨h.1, h.2.1.trans ?_, h.2.2.trans ?_⟩
  · push_cast
    ring
  · push_cast
    ring

theorem first_branch_polynomial (a : ℕ) :
    degreePoly Finset.univ (mixedWeight a) (mixedDegree a) = betaPower 1 (8*a) * betaPower 5 a := by
  classical
  change degreePoly (Finset.univ ×ˢ Finset.univ) _ _ = _
  unfold mixedWeight mixedDegree
  rw [degreePoly_product,trial_polynomial,trial_polynomial]
  rfl

#print axioms heterogeneous_moments
#print axioms first_branch_moments
#print axioms first_branch_polynomial
end PureFlag
