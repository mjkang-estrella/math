import SecondBranch
import Variance
namespace PureFlag
open scoped BigOperators
open Polynomial
variable {I : Type*} [Fintype I]
theorem coefficient_centered (u : I → ℚ) (d : I → ℕ) (P : ℚ[X]) (μ σ : ℚ)
    (hp : degreePoly Finset.univ u d = P)
    (h : mass Finset.univ u = 1 ∧ first Finset.univ u (fun i => (d i : ℚ)) = μ ∧
      second Finset.univ u (fun i => (d i : ℚ)) = σ + μ^2) :
    (∑ j ∈ Finset.univ.image d, P.coeff j) = 1 ∧
    (∑ j ∈ Finset.univ.image d, (j:ℚ) * P.coeff j) = μ ∧
    (∑ j ∈ Finset.univ.image d, ((j:ℚ)-μ)^2 * P.coeff j) = σ := by
  classical
  have hm := degree_transport Finset.univ u d (fun _ => 1)
  have hf := degree_transport Finset.univ u d (fun j => (j:ℚ))
  have hv := degree_transport Finset.univ u d (fun j => ((j:ℚ)-μ)^2)
  rw [← hp]
  simp only [degreePoly_coeff]
  simp only [one_mul] at hm
  refine ⟨hm.trans h.1,hf.trans h.2.1,hv.trans ?_⟩
  rw [centered_second,h.1,h.2.1,h.2.2]
  ring

theorem first_coefficients (a : ℕ) :
    (∑ j ∈ Finset.univ.image (mixedDegree a),
      (betaPower 1 (8*a) * betaPower 5 a).coeff j) = 1 ∧
    (∑ j ∈ Finset.univ.image (mixedDegree a), (j:ℚ) *
      (betaPower 1 (8*a) * betaPower 5 a).coeff j) = 29*(a:ℚ)/6 ∧
    (∑ j ∈ Finset.univ.image (mixedDegree a), ((j:ℚ)-29*(a:ℚ)/6)^2 *
      (betaPower 1 (8*a) * betaPower 5 a).coeff j) = 77*(a:ℚ)/36 :=
  coefficient_centered _ _ _ _ _ (first_branch_polynomial a) (first_branch_moments a)

theorem second_coefficients (a : ℕ) :
    (∑ j ∈ Finset.univ.image (secondDegree a),
      (betaPower 1 (7*a) * betaPower 2 a * betaPower 3 a).coeff j) = 1 ∧
    (∑ j ∈ Finset.univ.image (secondDegree a), (j:ℚ) *
      (betaPower 1 (7*a) * betaPower 2 a * betaPower 3 a).coeff j) = 59*(a:ℚ)/12 ∧
    (∑ j ∈ Finset.univ.image (secondDegree a), ((j:ℚ)-59*(a:ℚ)/12)^2 *
      (betaPower 1 (7*a) * betaPower 2 a * betaPower 3 a).coeff j) = 311*(a:ℚ)/144 :=
  coefficient_centered _ _ _ _ _ (second_branch_polynomial a) (second_branch_moments a)

#print axioms coefficient_centered
#print axioms first_coefficients
#print axioms second_coefficients
end PureFlag
