import GraphBounds
import BranchScaling
import Mathlib.Algebra.Polynomial.Eval.Defs
namespace PureFlag
open Polynomial
noncomputable def actualRat (a : ℕ) : ℚ[X] :=
  (facePoly (@Adj a)).map (Int.castRingHom ℚ)

theorem actual_mass_at_one_v3 (a : ℕ) :
    (facePoly (@Adj a)).eval 1 = 2*(2:ℤ)^(7*a)*12^a - 2^(7*a) := by
  rw [actual_graph_polynomial]
  norm_num
  ring

theorem actual_rat_decomposition (a : ℕ) :
    actualRat a = rawFirst a + rawSecond a - (1+X)^(7*a) := by
  unfold actualRat
  rw [actual_graph_polynomial]
  simp only [Polynomial.map_mul,Polynomial.map_pow,Polynomial.map_add,Polynomial.map_sub,
    Polynomial.map_one,Polynomial.map_X,Polynomial.map_ofNat]
  unfold rawFirst rawSecond
  rw [show 8*a=7*a+a by omega,pow_add,mul_pow,mul_pow]
  ring

theorem actual_normalization (a : ℕ) :
    actualRat a = C (commonMass a) *
      (betaPower 1 (8*a)*betaPower 5 a + betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a) -
      C (emptyMass a)*betaPower 1 (7*a) := by
  rw [mul_add,show C (commonMass a) * (betaPower 1 (8*a)*betaPower 5 a) = rawFirst a from first_scale a,
    show C (commonMass a) * (betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a) = rawSecond a from second_scale a]
  have h := beta_power_scale 1 (by norm_num) (7*a)
  norm_num only [one_add_one_eq_two,map_one,one_mul] at h
  change actualRat a = rawFirst a + rawSecond a - C ((2:ℚ)^(7*a))*betaPower 1 (7*a)
  rw [h,actual_rat_decomposition]

theorem actual_normalized_coefficient (a j : ℕ) :
    (actualRat a).coeff j / commonMass a =
      (betaPower 1 (8*a)*betaPower 5 a).coeff j +
      (betaPower 1 (7*a)*betaPower 2 a*betaPower 3 a).coeff j -
      (emptyMass a/commonMass a)*(betaPower 1 (7*a)).coeff j := by
  rw [actual_normalization]
  simp only [coeff_sub,coeff_add,coeff_C_mul]
  field_simp [ne_of_gt (commonMass_pos a)]

#print axioms actual_mass_at_one_v3
#print axioms actual_rat_decomposition
#print axioms actual_normalization
#print axioms actual_normalized_coefficient
end PureFlag
