import FTransport
import Windows
namespace PureFlag
variable {V : Type*} [Fintype V] [DecidableEq V]
noncomputable def zeroF (K : FiniteComplex V) (d : ℕ) (i : ℤ) : ℚ :=
  if 0 ≤ i ∧ i < (d : ℤ) then (K.f i.toNat : ℚ) else 0

omit [DecidableEq V] in
theorem finite_unimodal_zeroF (K : FiniteComplex V) (d : ℕ)
    (h : K.Unimodal d) : HasMode (zeroF K d) := by
  obtain ⟨m,hm,inc,dec⟩ := h
  refine ⟨(m : ℤ),?_,?_⟩
  · intro i j hij hjm
    by_cases hi : 0 ≤ i
    · have hj : 0 ≤ j := by omega
      have hid : i < (d : ℤ) := by omega
      have hjd : j < (d : ℤ) := by omega
      simp only [zeroF,hi,hid,hj,hjd,and_self,ite_true]
      exact_mod_cast inc i.toNat j.toNat (by omega) (by omega)
    · have hz : zeroF K d i = 0 := by simp [zeroF,hi]
      rw [hz]
      unfold zeroF
      split_ifs <;> positivity
  · intro i j hmi hij
    have hi : 0 ≤ i := by omega
    have hj : 0 ≤ j := by omega
    by_cases hjd : j < (d : ℤ)
    · have hid : i < (d : ℤ) := by omega
      simp only [zeroF,hi,hid,hj,hjd,and_self,ite_true]
      exact_mod_cast dec i.toNat j.toNat (by omega) (by omega) (by omega)
    · have hz : zeroF K d j = 0 := by simp [zeroF,hjd]
      rw [hz]
      unfold zeroF
      split_ifs <;> positivity

omit [DecidableEq V] in
theorem finite_window_valley (K : FiniteComplex V) (d L : ℕ) (s : ℤ)
    (hl : window (zeroF K d) (s+(L:ℤ)) L < window (zeroF K d) s L)
    (hr : window (zeroF K d) (s+(L:ℤ)) L < window (zeroF K d) (s+(L:ℤ)+(L:ℤ)) L) :
    ¬ K.Unimodal d := by
  intro h
  exact window_valley_not_mode _ _ _ hl hr (finite_unimodal_zeroF K d h)

#print axioms zeroF
#print axioms finite_unimodal_zeroF
#print axioms finite_window_valley
omit [DecidableEq V] in
theorem positive_index_translation
    (K : FiniteComplex V) (d : ℕ) (j : ℤ) (hj : 1 ≤ j) (hd : j ≤ d) :
    zeroF K d (j-1) = (K.f (j.toNat-1) : ℚ) := by
  have h0 : 0 ≤ j-1 := by omega
  have hlt : j-1 < (d:ℤ) := by omega
  simp only [zeroF,h0,hlt,and_self,ite_true]
  have he : (j-1).toNat = j.toNat-1 := by omega
  rw [he]


#print axioms positive_index_translation
end PureFlag
