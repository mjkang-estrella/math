/-
BiHControl2: reviewer-authored Gate E exact values, importing BiHBase only through BiHControl1.
The Laplacians below are hand-written and checked entry-by-entry against the literal
`SimpleGraph.degree`/`Adj` of the authors' star and path graphs and a reviewer-defined fork.
Reviewer module; NOT part of the packet.
-/
import BiHControl1
import Mathlib.Tactic.FinCases

open Matrix BiH

namespace BiHCtrl

theorem bh_five (G : SimpleGraph (Fin 5)) [DecidableRel G.Adj]
    (p1 p2 p3 p4 p5 E2 E3 E4 : ℝ)
    (h1 : ((G.lapMatrix ℝ) ^ 1).trace = p1) (h2 : ((G.lapMatrix ℝ) ^ 2).trace = p2)
    (h3 : ((G.lapMatrix ℝ) ^ 3).trace = p3) (h4 : ((G.lapMatrix ℝ) ^ 4).trace = p4)
    (h5 : ((G.lapMatrix ℝ) ^ 5).trace = p5)
    (hE2 : E2 = (p1 ^ 2 - p2) / 2)
    (hE3 : E3 = (E2 * p1 - p1 * p2 + p3) / 3)
    (hE4 : E4 = (E3 * p1 - E2 * p2 + p1 * p3 - p4) / 4)
    (hE5 : E4 * p1 - E3 * p2 + E2 * p3 - p1 * p4 + p5 = 0)
    (hE40 : E4 ≠ 0) :
    bh G = 5 * ((E3 ^ 2 - 2 * E2 * E4) / E4 ^ 2) ∧
      (∑ i, (if lapEigs G i = 0 then 0 else (lapEigs G i)⁻¹)) = E3 / E4 ∧
      (∑ i, (if lapEigs G i = 0 then (1 : ℕ) else 0)) = 1 ∧
      (∑ i, (if lapEigs G i = 0 then 0 else (lapEigs G i)⁻¹ ^ 2)) =
        (E3 ^ 2 - 2 * E2 * E4) / E4 ^ 2 := by
  have t := fun k => trace_pow_eq (G.lapMatrix ℝ) (G.isHermitian_lapMatrix ℝ) k
  rw [t 1, Fin.sum_univ_five] at h1
  rw [t 2, Fin.sum_univ_five] at h2
  rw [t 3, Fin.sum_univ_five] at h3
  rw [t 4, Fin.sum_univ_five] at h4
  rw [t 5, Fin.sum_univ_five] at h5
  obtain ⟨c1, c2, c3⟩ := five_core (lapEigs G 0) (lapEigs G 1) (lapEigs G 2) (lapEigs G 3)
    (lapEigs G 4) p1 p2 p3 p4 p5 E2 E3 E4 h1 h2 h3 h4 h5 hE2 hE3 hE4 hE5 hE40
  refine ⟨?_, ?_, ?_, ?_⟩
  · unfold bh
    rw [Fintype.card_fin, Fin.sum_univ_five, c1]
    norm_num
  · rw [Fin.sum_univ_five]; exact c2
  · rw [Fin.sum_univ_five]; exact c3
  · rw [Fin.sum_univ_five]; exact c1

theorem lap_eq_map {n : ℕ} (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (M : Matrix (Fin n) (Fin n) ℤ)
    (h : ∀ i j, M i j = (if i = j then ((G.degree i : ℕ) : ℤ) else 0)
      - (if G.Adj i j then 1 else 0)) :
    G.lapMatrix ℝ = M.map (Int.cast : ℤ → ℝ) := by
  ext i j
  simp only [SimpleGraph.lapMatrix, SimpleGraph.degMatrix, Matrix.sub_apply,
    Matrix.diagonal_apply, SimpleGraph.adjMatrix_apply, Matrix.map_apply, h i j]
  split_ifs <;> push_cast <;> ring

theorem trace_pow_cast {n : ℕ} (M : Matrix (Fin n) (Fin n) ℤ) (k : ℕ) (v : ℤ)
    (h : (M ^ k).trace = v) :
    ((M.map (Int.cast : ℤ → ℝ)) ^ k).trace = (v : ℝ) := by
  subst h
  have hm : (M.map (Int.cast : ℤ → ℝ)) = (Int.castRingHom ℝ).mapMatrix M := rfl
  rw [hm, ← map_pow, RingHom.mapMatrix_apply]
  simp [Matrix.trace]

/-- Hand-written Laplacian of `K_{1,4}` with centre `0`. -/
def Mstar : Matrix (Fin 5) (Fin 5) ℤ :=
  !![4, -1, -1, -1, -1; -1, 1, 0, 0, 0; -1, 0, 1, 0, 0; -1, 0, 0, 1, 0; -1, 0, 0, 0, 1]

/-- Hand-written Laplacian of `P_5`. -/
def Mpath : Matrix (Fin 5) (Fin 5) ℤ :=
  !![1, -1, 0, 0, 0; -1, 2, -1, 0, 0; 0, -1, 2, -1, 0; 0, 0, -1, 2, -1; 0, 0, 0, -1, 1]

/-- Hand-written Laplacian of the fork with edges 01, 12, 23, 24. -/
def Mfork : Matrix (Fin 5) (Fin 5) ℤ :=
  !![1, -1, 0, 0, 0; -1, 2, -1, 0, 0; 0, -1, 3, -1, -1; 0, 0, -1, 1, 0; 0, 0, -1, 0, 1]

abbrev star5 : SimpleGraph (Fin 5) := starGraphFin 5 (by norm_num)
abbrev path5 : SimpleGraph (Fin 5) := pathGraphFin 5

def forkRel (i j : Fin 5) : Prop :=
  (i.val = 0 ∧ j.val = 1) ∨ (i.val = 1 ∧ j.val = 2) ∨ (i.val = 2 ∧ j.val = 3) ∨
    (i.val = 2 ∧ j.val = 4)

instance instDecForkRel : DecidableRel forkRel := fun i j =>
  inferInstanceAs (Decidable ((i.val = 0 ∧ j.val = 1) ∨ (i.val = 1 ∧ j.val = 2) ∨
    (i.val = 2 ∧ j.val = 3) ∨ (i.val = 2 ∧ j.val = 4)))

/-- A tree on five vertices that is neither the star nor the path. -/
def fork5 : SimpleGraph (Fin 5) := SimpleGraph.fromRel forkRel

instance instDecFork5 : DecidableRel fork5.Adj := fun a b =>
  decidable_of_iff (a ≠ b ∧ (forkRel a b ∨ forkRel b a)) (SimpleGraph.fromRel_adj forkRel a b).symm

theorem star5_entries : ∀ i j : Fin 5, Mstar i j =
    (if i = j then ((star5.degree i : ℕ) : ℤ) else 0) - (if star5.Adj i j then 1 else 0) := by
  intro i j; fin_cases i <;> fin_cases j <;> decide +kernel

theorem path5_entries : ∀ i j : Fin 5, Mpath i j =
    (if i = j then ((path5.degree i : ℕ) : ℤ) else 0) - (if path5.Adj i j then 1 else 0) := by
  intro i j; fin_cases i <;> fin_cases j <;> decide +kernel

theorem fork5_entries : ∀ i j : Fin 5, Mfork i j =
    (if i = j then ((fork5.degree i : ℕ) : ℤ) else 0) - (if fork5.Adj i j then 1 else 0) := by
  intro i j; fin_cases i <;> fin_cases j <;> decide +kernel

/-- **Star value (hand-derived `76/5`)**, plus: exactly one zero eigenvalue; the factor-of-`n`
and power comparisons used to show the model is not subtly wrong. -/
theorem star5_value : bh star5 = 76 / 5 ∧
    (∑ i, (if lapEigs star5 i = 0 then 0 else (lapEigs star5 i)⁻¹)) = 16 / 5 ∧
    (∑ i, (if lapEigs star5 i = 0 then (1 : ℕ) else 0)) = 1 ∧
    (∑ i, (if lapEigs star5 i = 0 then 0 else (lapEigs star5 i)⁻¹ ^ 2)) = 76 / 25 := by
  have tr : ∀ (k : ℕ) (v : ℤ), (Mstar ^ k).trace = v →
      ((star5.lapMatrix ℝ) ^ k).trace = (v : ℝ) := fun k v h => by
    rw [lap_eq_map star5 Mstar star5_entries]; exact trace_pow_cast Mstar k v h
  obtain ⟨a, b, c, d⟩ := bh_five star5 ((8 : ℤ) : ℝ) ((28 : ℤ) : ℝ) ((128 : ℤ) : ℝ)
    ((628 : ℤ) : ℝ) ((3128 : ℤ) : ℝ) 18 16 5
    (tr 1 8 (by decide +kernel)) (tr 2 28 (by decide +kernel)) (tr 3 128 (by decide +kernel))
    (tr 4 628 (by decide +kernel)) (tr 5 3128 (by decide +kernel))
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  refine ⟨by rw [a]; norm_num, by rw [b], c, by rw [d]; norm_num⟩

/-- **Path value (hand-derived `38`).** -/
theorem path5_value : bh path5 = 38 ∧
    (∑ i, (if lapEigs path5 i = 0 then (1 : ℕ) else 0)) = 1 := by
  have tr : ∀ (k : ℕ) (v : ℤ), (Mpath ^ k).trace = v →
      ((path5.lapMatrix ℝ) ^ k).trace = (v : ℝ) := fun k v h => by
    rw [lap_eq_map path5 Mpath path5_entries]; exact trace_pow_cast Mpath k v h
  obtain ⟨a, _, c, _⟩ := bh_five path5 ((8 : ℤ) : ℝ) ((22 : ℤ) : ℝ) ((68 : ℤ) : ℝ)
    ((222 : ℤ) : ℝ) ((748 : ℤ) : ℝ) 21 20 5
    (tr 1 8 (by decide +kernel)) (tr 2 22 (by decide +kernel)) (tr 3 68 (by decide +kernel))
    (tr 4 222 (by decide +kernel)) (tr 5 748 (by decide +kernel))
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  exact ⟨by rw [a]; norm_num, c⟩

/-- **Fork value (hand-derived `124/5`).** -/
theorem fork5_value : bh fork5 = 124 / 5 ∧
    (∑ i, (if lapEigs fork5 i = 0 then (1 : ℕ) else 0)) = 1 := by
  have tr : ∀ (k : ℕ) (v : ℤ), (Mfork ^ k).trace = v →
      ((fork5.lapMatrix ℝ) ^ k).trace = (v : ℝ) := fun k v h => by
    rw [lap_eq_map fork5 Mfork fork5_entries]; exact trace_pow_cast Mfork k v h
  obtain ⟨a, _, c, _⟩ := bh_five fork5 ((8 : ℤ) : ℝ) ((24 : ℤ) : ℝ) ((86 : ℤ) : ℝ)
    ((332 : ℤ) : ℝ) ((1328 : ℤ) : ℝ) 20 18 5
    (tr 1 8 (by decide +kernel)) (tr 2 24 (by decide +kernel)) (tr 3 86 (by decide +kernel))
    (tr 4 332 (by decide +kernel)) (tr 5 1328 (by decide +kernel))
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  exact ⟨by rw [a]; norm_num, c⟩

/-- Strictly between: the fork lies strictly between the star and the path. -/
theorem fork5_between : bh star5 < bh fork5 ∧ bh fork5 < bh path5 := by
  rw [star5_value.1, fork5_value.1, path5_value.1]
  norm_num

/-- `K_2`: eigenvalues `0, 2`, so `BH = 2 · 1/4 = 1/2` (hand-derived). -/
theorem bh_K2 : bh (starGraphFin 2 (by norm_num)) = 1 / 2 := by
  let G : SimpleGraph (Fin 2) := starGraphFin 2 (by norm_num)
  let M2 : Matrix (Fin 2) (Fin 2) ℤ := !![1, -1; -1, 1]
  have he : ∀ i j : Fin 2, M2 i j =
      (if i = j then ((G.degree i : ℕ) : ℤ) else 0) - (if G.Adj i j then 1 else 0) := by
    intro i j; fin_cases i <;> fin_cases j <;> decide +kernel
  have tr : ∀ (k : ℕ) (v : ℤ), (M2 ^ k).trace = v →
      ((G.lapMatrix ℝ) ^ k).trace = (v : ℝ) := fun k v h => by
    rw [lap_eq_map G M2 he]; exact trace_pow_cast M2 k v h
  have t := fun k => trace_pow_eq (G.lapMatrix ℝ) (G.isHermitian_lapMatrix ℝ) k
  have h1 := tr 1 2 (by decide +kernel)
  have h2 := tr 2 4 (by decide +kernel)
  rw [t 1, Fin.sum_univ_two] at h1
  rw [t 2, Fin.sum_univ_two] at h2
  show bh G = 1 / 2
  unfold bh
  rw [Fintype.card_fin, Fin.sum_univ_two]
  have hs0 : lapEigs G 0 + lapEigs G 1 = 2 := by simpa using h1
  have hq0 : lapEigs G 0 ^ 2 + lapEigs G 1 ^ 2 = 4 := by simpa using h2
  generalize lapEigs G 0 = x at hs0 hq0 ⊢
  generalize lapEigs G 1 = y at hs0 hq0 ⊢
  have hs : x + y = 2 := hs0
  have hq : x ^ 2 + y ^ 2 = 4 := hq0
  have hxy : x * y = 0 := by nlinarith [hs, hq]
  rcases mul_eq_zero.mp hxy with h0 | h0
  · subst h0
    have hy2 : y = 2 := by linarith
    subst hy2
    norm_num
  · subst h0
    have hx2 : x = 2 := by linarith
    subst hx2
    norm_num

theorem fork5_tree : fork5.IsTree := by
  have r : ∀ u : Fin 5, fork5.Reachable u 2 := by
    intro u
    fin_cases u
    · exact (show fork5.Adj 0 1 by decide).reachable.trans (show fork5.Adj 1 2 by decide).reachable
    · exact (show fork5.Adj 1 2 by decide).reachable
    · exact SimpleGraph.Reachable.refl _
    · exact (show fork5.Adj 3 2 by decide).reachable
    · exact (show fork5.Adj 4 2 by decide).reachable
  have : Nonempty (Fin 5) := ⟨0⟩
  have hc : fork5.Connected := ⟨fun u v => (r u).trans (r v).symm⟩
  refine SimpleGraph.isTree_iff_connected_and_card.mpr ⟨hc, ?_⟩
  rw [Nat.card_eq_fintype_card, Nat.card_eq_fintype_card, Fintype.card_fin]
  decide +kernel

end BiHCtrl

#print axioms BiHCtrl.star5_value
#print axioms BiHCtrl.path5_value
#print axioms BiHCtrl.fork5_value
#print axioms BiHCtrl.bh_K2
#print axioms BiHCtrl.fork5_tree
