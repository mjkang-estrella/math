/-
BiHCut: for a tree, every edge carries a "cut vector" `x_e` (the centred indicator of one side of
`G - e`, namely the side of the endpoint carrying colour sign `+1`).  These vectors satisfy
`Bᵀ *ᵥ x_e = e_e` and have zero coordinate sum, so `Xᵀ X = (Bᵀ B)⁻¹`.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHInc
import BiHInv
import Mathlib.Combinatorics.SimpleGraph.DeleteEdges
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected
import Mathlib.Combinatorics.SimpleGraph.Acyclic
import Mathlib.Data.Matrix.Mul

open Matrix

namespace BiH

set_option linter.unusedSectionVars false

variable {V : Type*} [Fintype V] [DecidableEq V]

section

variable {G : SimpleGraph V} [DecidableRel G.Adj] [Fintype G.edgeSet]

omit [Fintype V] [DecidableEq V] in
/-- `colSign` only takes the values `1` and `-1`. -/
theorem colSign_eq_or (c : G.Coloring (Fin 2)) (v : V) :
    colSign c v = 1 ∨ colSign c v = -1 := by
  unfold colSign
  split_ifs <;> norm_num

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] [Fintype G.edgeSet] in
/-- A function that is constant on every edge of a walk is constant on its endpoints. -/
theorem walk_const {G : SimpleGraph V} {x : V → ℝ} {u v : V} (p : G.Walk u v)
    (h : ∀ a b : V, G.Adj a b → x a = x b) : x u = x v := by
  induction p with
  | nil => rfl
  | cons hadj p ih => rw [h _ _ hadj, ih]

/-- The signed incidence matrix has only two non-zero entries in each edge column, and they are
`colSign`-opposite. -/
theorem sInc_transpose_mulVec_eq (c : G.Coloring (Fin 2)) (x : V → ℝ) (e : ↥G.edgeFinset)
    {a b : V} (hab : G.Adj a b) (he : (e : Sym2 V) = s(a, b)) :
    ((sInc c)ᵀ *ᵥ x) e = colSign c a * (x a - x b) := by
  classical
  rw [Matrix.mulVec_apply_eq_sum]
  have h1 : ∀ v : V, (sInc c)ᵀ e v * x v
      = colSign c v * (if v = a ∨ v = b then (1 : ℝ) else 0) * x v := by
    intro v
    simp only [Matrix.transpose_apply, sInc, he]
    rw [SimpleGraph.incMatrix_apply']
    by_cases h : v = a ∨ v = b
    · have hmem : s(a, b) ∈ G.incidenceSet v := ⟨hab, Sym2.mem_iff.mpr h⟩
      rw [ite_eq_left hmem, ite_eq_left h]
    · have hmem : s(a, b) ∉ G.incidenceSet v := fun hh => h (Sym2.mem_iff.mp hh.2)
      rw [ite_eq_right hmem, ite_eq_right h]
  simp only [h1]
  have hstep : ∀ v : V, colSign c v * (if v = a ∨ v = b then (1 : ℝ) else 0) * x v
      = if v ∈ ({a, b} : Finset V) then colSign c v * x v else 0 := by
    intro v; by_cases h : v = a ∨ v = b <;> simp [h]
  simp only [hstep]
  rw [Finset.sum_ite_mem, Finset.univ_inter, Finset.sum_pair (G.ne_of_adj hab)]
  have hneg : colSign c b = -colSign c a := by
    have h := colSign_add_of_adj c hab
    linarith
  rw [hneg]
  ring

/-- **`ker Bᵀ` = constants** for a tree. -/
theorem sInc_ker_const (c : G.Coloring (Fin 2)) (hG : G.IsTree) (x : V → ℝ)
    (hx : (sInc c)ᵀ *ᵥ x = 0) : ∀ i j : V, x i = x j := by
  have hadj_eq : ∀ a b : V, G.Adj a b → x a = x b := by
    intro a b hab
    have hmem : s(a, b) ∈ G.edgeFinset := by
      rw [SimpleGraph.mem_edgeFinset]; exact hab
    have h := congrFun hx ⟨s(a, b), hmem⟩
    rw [sInc_transpose_mulVec_eq c x ⟨s(a, b), hmem⟩ hab rfl] at h
    have hne : colSign c a ≠ 0 := by
      rcases colSign_eq_or c a with h1 | h1 <;> rw [h1] <;> norm_num
    rcases mul_eq_zero.mp h with h1 | h1
    · exact absurd h1 hne
    · linarith
  intro i j
  obtain ⟨p⟩ := hG.connected i j
  exact walk_const p hadj_eq

/-- **`ker L` = constants** for a tree. -/
theorem lapMatrix_ker_const (c : G.Coloring (Fin 2)) (hG : G.IsTree) (x : V → ℝ)
    (hx : G.lapMatrix ℝ *ᵥ x = 0) : ∀ i j : V, x i = x j := by
  classical
  have hL : G.lapMatrix ℝ = sInc c * (sInc c)ᵀ := (sInc_mul_transpose c).symm
  have hvec : x ᵥ* sInc c = (sInc c)ᵀ *ᵥ x := by
    have h' := Matrix.vecMul_transpose ((sInc c)ᵀ) x
    rw [Matrix.transpose_transpose] at h'
    exact h'
  have hdot : x ⬝ᵥ (G.lapMatrix ℝ *ᵥ x)
      = ((sInc c)ᵀ *ᵥ x) ⬝ᵥ ((sInc c)ᵀ *ᵥ x) := by
    calc x ⬝ᵥ (G.lapMatrix ℝ *ᵥ x)
        = x ⬝ᵥ ((sInc c * (sInc c)ᵀ) *ᵥ x) := by rw [hL]
      _ = x ⬝ᵥ (sInc c *ᵥ ((sInc c)ᵀ *ᵥ x)) := by
            rw [Matrix.mulVec_mulVec x (sInc c) ((sInc c)ᵀ)]
      _ = (x ᵥ* sInc c) ⬝ᵥ ((sInc c)ᵀ *ᵥ x) :=
            Matrix.dotProduct_mulVec x (sInc c) ((sInc c)ᵀ *ᵥ x)
      _ = ((sInc c)ᵀ *ᵥ x) ⬝ᵥ ((sInc c)ᵀ *ᵥ x) := by rw [hvec]
  have hzero : ((sInc c)ᵀ *ᵥ x) ⬝ᵥ ((sInc c)ᵀ *ᵥ x) = 0 := by
    rw [← hdot, hx]; simp
  have hB : (sInc c)ᵀ *ᵥ x = 0 := by
    funext e
    have hsum : ∑ e : ↥G.edgeFinset, ((sInc c)ᵀ *ᵥ x) e * ((sInc c)ᵀ *ᵥ x) e = 0 := hzero
    have hnn : ∀ e ∈ Finset.univ, (0 : ℝ) ≤ ((sInc c)ᵀ *ᵥ x) e * ((sInc c)ᵀ *ᵥ x) e :=
      fun e _ => mul_self_nonneg _
    have h1 := (Finset.sum_eq_zero_iff_of_nonneg hnn).mp hsum e (Finset.mem_univ e)
    exact mul_self_eq_zero.mp h1
  exact sInc_ker_const c hG x hB

/-- Each edge has an endpoint carrying sign `+1`. -/
theorem exists_posEnd (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    ∃ v : V, v ∈ (e : Sym2 V) ∧ colSign c v = 1 := by
  have he := G.mem_edgeFinset.mp e.2
  refine Sym2.ind (f := fun z => z ∈ G.edgeSet → ∃ v : V, v ∈ z ∧ colSign c v = 1)
    ?_ (e : Sym2 V) he
  intro a b hmem
  have hab : G.Adj a b := hmem
  rcases colSign_eq_or c a with h | h
  · exact ⟨a, Sym2.mem_iff.mpr (Or.inl rfl), h⟩
  · have hb : colSign c b = 1 := by
      have h2 := colSign_add_of_adj c hab
      rw [h] at h2
      linarith
    exact ⟨b, Sym2.mem_iff.mpr (Or.inr rfl), hb⟩

/-- The endpoint of an edge carrying sign `+1`. -/
noncomputable def posEnd (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) : V :=
  Classical.choose (exists_posEnd c e)

theorem posEnd_mem (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    posEnd c e ∈ (e : Sym2 V) := (Classical.choose_spec (exists_posEnd c e)).1

theorem posEnd_sign (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    colSign c (posEnd c e) = 1 := (Classical.choose_spec (exists_posEnd c e)).2

/-- The two endpoints of an edge carry opposite signs. -/
theorem colSign_add_of_mem (c : G.Coloring (Fin 2)) {e : Sym2 V} (he : e ∈ G.edgeSet)
    {v w : V} (hv : v ∈ e) (hw : w ∈ e) (hne : v ≠ w) : colSign c v + colSign c w = 0 := by
  refine (Sym2.ind (f := fun z => z ∈ G.edgeSet → v ∈ z → w ∈ z → v ≠ w →
    colSign c v + colSign c w = 0) ?_ e he) hv hw hne
  intro a b hmem hv hw hne
  rw [Sym2.mem_iff] at hv hw
  have hvw : G.Adj v w := by
    rcases hv with rfl | rfl <;> rcases hw with rfl | rfl
    · exact absurd rfl hne
    · exact hmem
    · exact SimpleGraph.Adj.symm hmem
    · exact absurd rfl hne
  exact colSign_add_of_adj c hvw

/-- Uniqueness of the sign-`+1` endpoint. -/
theorem posEnd_unique (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) {v : V}
    (hv : v ∈ (e : Sym2 V)) (hs : colSign c v = 1) : v = posEnd c e := by
  by_contra hne
  have h1 := colSign_add_of_mem c (G.mem_edgeFinset.mp e.2) hv (posEnd_mem c e) hne
  rw [hs, posEnd_sign c e] at h1
  norm_num at h1

/-- The side of `G - e` containing the sign-`+1` endpoint. -/
noncomputable def cutSet (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) : Set V :=
  {w | (G.deleteEdges {(e : Sym2 V)}).Reachable w (posEnd c e)}

theorem mem_cutSet_iff (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) (v : V) :
    v ∈ cutSet c e ↔ (G.deleteEdges {(e : Sym2 V)}).Reachable v (posEnd c e) := Iff.rfl

theorem posEnd_mem_cutSet (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    posEnd c e ∈ cutSet c e := SimpleGraph.Reachable.refl _

/-- Removing a bridge disconnects its endpoints. -/
theorem not_reachable_deleteEdges_of_adj (hG : G.IsTree) {a b : V} (hab : G.Adj a b) :
    ¬ (G.deleteEdges {s(a, b)}).Reachable a b := by
  have hbridge : G.IsBridge s(a, b) :=
    SimpleGraph.isAcyclic_iff_forall_isBridge.mp hG.isAcyclic hab
  exact SimpleGraph.isBridge_iff.mp hbridge

/-- Edges other than `e` do not separate the two sides of `e`. -/
theorem reachable_iff_of_ne {a b : V} (hab : G.Adj a b) {e : Sym2 V} (hne : s(a, b) ≠ e)
    (p : V) :
    (G.deleteEdges {e}).Reachable a p ↔ (G.deleteEdges {e}).Reachable b p := by
  have hadj : (G.deleteEdges {e}).Adj a b := by
    rw [SimpleGraph.deleteEdges_adj]
    exact ⟨hab, by simpa using hne⟩
  exact ⟨fun h => SimpleGraph.Reachable.trans hadj.symm.reachable h,
    fun h => SimpleGraph.Reachable.trans hadj.reachable h⟩

/-- Membership of the endpoints of the cutting edge itself. -/
theorem mem_cutSet_pair (c : G.Coloring (Fin 2)) (hG : G.IsTree) {a b : V} (hab : G.Adj a b)
    (e : ↥G.edgeFinset) (he : (e : Sym2 V) = s(a, b)) :
    (a ∈ cutSet c e ↔ a = posEnd c e) ∧ (b ∈ cutSet c e ↔ b = posEnd c e) := by
  have hpe : posEnd c e ∈ s(a, b) := by rw [← he]; exact posEnd_mem c e
  rw [Sym2.mem_iff] at hpe
  constructor
  · constructor
    · intro h
      rw [mem_cutSet_iff, he] at h
      by_contra hne
      have hpb : posEnd c e = b := by
        rcases hpe with h1 | h1
        · exact absurd h1.symm hne
        · exact h1
      rw [hpb] at h
      exact not_reachable_deleteEdges_of_adj hG hab h
    · intro h
      exact h.symm ▸ posEnd_mem_cutSet c e
  · constructor
    · intro h
      rw [mem_cutSet_iff, he] at h
      by_contra hne
      have hpa : posEnd c e = a := by
        rcases hpe with h1 | h1
        · exact h1
        · exact absurd h1.symm hne
      rw [hpa] at h
      exact not_reachable_deleteEdges_of_adj hG hab h.symm
    · intro h
      exact h.symm ▸ posEnd_mem_cutSet c e

/-- The size of a cut. -/
noncomputable def cutSize (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) : ℕ := by
  classical exact (Finset.univ.filter (fun v : V => v ∈ cutSet c e)).card

/-- The centred indicator of the side of `G - e` carrying the sign-`+1` endpoint. -/
noncomputable def cutVec [Nonempty V] (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) : V → ℝ := by
  classical exact fun v => (if v ∈ cutSet c e then (1 : ℝ) else 0)
    - (cutSize c e : ℝ) / (Fintype.card V : ℝ)

theorem sum_cutVec [Nonempty V] (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    ∑ v : V, cutVec c e v = 0 := by
  classical
  have hcard : (Fintype.card V : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  have hsum : ∑ v : V, (if v ∈ cutSet c e then (1 : ℝ) else 0) = (cutSize c e : ℝ) := by
    have h1 : cutSize c e = ∑ v ∈ Finset.univ, (if v ∈ cutSet c e then 1 else 0) := by
      rw [cutSize, Finset.card_filter]
    rw [h1, Nat.cast_sum]
    refine Finset.sum_congr rfl (fun v _ => ?_)
    split_ifs <;> simp
  simp only [cutVec, Finset.sum_sub_distrib, hsum, Finset.sum_const, Finset.card_univ,
    nsmul_eq_mul]
  rw [mul_comm, div_mul_cancel₀ _ hcard, sub_self]

/-- **`Bᵀ *ᵥ x_e = e_e`.** -/
theorem sInc_transpose_mulVec_cutVec [Nonempty V] (c : G.Coloring (Fin 2)) (hG : G.IsTree)
    (e : ↥G.edgeFinset) :
    (sInc c)ᵀ *ᵥ (cutVec c e) = fun e' => if e' = e then (1 : ℝ) else 0 := by
  classical
  funext e'
  have he' := G.mem_edgeFinset.mp e'.2
  have key : ∀ z : Sym2 V, z ∈ G.edgeSet → ∀ (e' : ↥G.edgeFinset), (e' : Sym2 V) = z →
      ((sInc c)ᵀ *ᵥ (cutVec c e)) e' = if e' = e then (1 : ℝ) else 0 := by
    intro z
    refine Sym2.ind (f := fun z => z ∈ G.edgeSet → ∀ (e' : ↥G.edgeFinset),
      (e' : Sym2 V) = z → ((sInc c)ᵀ *ᵥ (cutVec c e)) e' = if e' = e then (1 : ℝ) else 0)
      ?_ z
    intro a b hmem e' hpair
    have hab : G.Adj a b := hmem
    rw [sInc_transpose_mulVec_eq c (cutVec c e) e' hab hpair]
    have hsub : cutVec c e a - cutVec c e b
        = (if a ∈ cutSet c e then (1 : ℝ) else 0)
          - (if b ∈ cutSet c e then (1 : ℝ) else 0) := by
      simp only [cutVec]; ring
    rw [hsub]
    by_cases hsame : e' = e
    · rw [hsame] at hpair ⊢
      obtain ⟨ha, hb⟩ := mem_cutSet_pair c hG hab e hpair
      rw [ite_eq_left rfl]
      have hpe : posEnd c e ∈ s(a, b) := by rw [← hpair]; exact posEnd_mem c e
      rw [Sym2.mem_iff] at hpe
      rcases hpe with h1 | h1
      · have hA : a ∈ cutSet c e := ha.mpr h1.symm
        have hB : ¬ (b ∈ cutSet c e) := by
          intro hc
          rw [mem_cutSet_iff, hpair] at hc
          exact not_reachable_deleteEdges_of_adj hG hab (h1 ▸ hc).symm
        rw [ite_eq_left hA, ite_eq_right hB, ← h1, posEnd_sign c e]
        norm_num
      · have hA : ¬ (a ∈ cutSet c e) := by
          intro hc
          rw [mem_cutSet_iff, hpair] at hc
          exact not_reachable_deleteEdges_of_adj hG hab (h1 ▸ hc)
        have hB : b ∈ cutSet c e := hb.mpr h1.symm
        rw [ite_eq_right hA, ite_eq_left hB]
        have hb1 : colSign c b = 1 := by rw [← h1]; exact posEnd_sign c e
        have ha1 : colSign c a = -1 := by
          have h2 := colSign_add_of_adj c hab
          rw [hb1] at h2
          linarith
        rw [ha1]
        norm_num
    · rw [ite_eq_right hsame]
      have hne' : s(a, b) ≠ (e : Sym2 V) := fun h => hsame (Subtype.ext (hpair.trans h))
      have hiff : (a ∈ cutSet c e) ↔ (b ∈ cutSet c e) := reachable_iff_of_ne hab hne' (posEnd c e)
      by_cases ha : a ∈ cutSet c e
      · rw [ite_eq_left ha, ite_eq_left (hiff.mp ha)]; ring
      · rw [ite_eq_right ha, ite_eq_right (fun hc => ha (hiff.mpr hc))]; ring
  exact key (e' : Sym2 V) he' e' rfl

/-- The matrix whose columns are the cut vectors. -/
noncomputable def cutMatrix [Nonempty V] (c : G.Coloring (Fin 2)) :
    Matrix V ↥G.edgeFinset ℝ := fun v e => cutVec c e v

theorem sInc_transpose_mul_cutMatrix [Nonempty V] (c : G.Coloring (Fin 2)) (hG : G.IsTree) :
    (sInc c)ᵀ * cutMatrix c = 1 := by
  classical
  ext e' e
  rw [Matrix.mul_apply, Matrix.one_apply]
  have h := congrFun (sInc_transpose_mulVec_cutVec c hG e) e'
  rw [Matrix.mulVec_apply_eq_sum] at h
  simpa [cutMatrix] using h

theorem sum_cutMatrix [Nonempty V] (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    ∑ v : V, cutMatrix c v e = 0 := sum_cutVec c e

end

end BiH
