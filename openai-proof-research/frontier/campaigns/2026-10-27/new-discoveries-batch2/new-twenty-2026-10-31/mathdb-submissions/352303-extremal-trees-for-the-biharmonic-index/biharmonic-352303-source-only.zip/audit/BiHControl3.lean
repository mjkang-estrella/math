/-
BiHControl3: reviewer-authored Gate D/E controls tying the literal endpoint theorem to the
independently computed values of BiHControl2. Reviewer module; NOT part of the packet.
-/
import BiHPathValue
import BiHControl2

open BiH BiHCtrl

namespace BiHCtrl3

theorem bhStar_five_eq : bhStar 5 (by norm_num) = 76 / 5 := star5_value.1

theorem bhPath_five_eq : bhPath 5 = 38 := by
  unfold bhPath
  exact (bh_inst _ _).trans path5_value.1

/-- The authors' double-sum path formula, evaluated at `n = 5`, agrees with the value obtained
from the literal eigenvalues. -/
theorem bhPath_authors_formula_five : bhPath 5 = 38 := by
  rw [bhPath_value 5 (by norm_num)]
  norm_num [Finset.sum_range_succ, min_def]

/-- Apply the endpoint to a tree that is neither star nor path, and read off the strict facts. -/
theorem endpoint_on_fork :
    bhStar 5 (by norm_num) ≤ bh fork5 ∧ bh fork5 ≤ bhPath 5 ∧
      ¬ Nonempty (fork5 ≃g starGraphFin 5 (by norm_num)) ∧
      ¬ Nonempty (fork5 ≃g pathGraphFin 5) := by
  obtain ⟨h1, h2, h3, h4⟩ := bh_endpoint 5 (by norm_num) (by simp) fork5 fork5_tree
  refine ⟨h1, h2, ?_, ?_⟩
  · intro hiso
    have := h3.mpr hiso
    rw [fork5_value.1, bhStar_five_eq] at this
    norm_num at this
  · intro hiso
    have := h4.mpr hiso
    rw [fork5_value.1, bhPath_five_eq] at this
    norm_num at this

/-- The endpoint's equality directions fire on the concrete star and path. -/
theorem endpoint_on_star :
    bh star5 = bhStar 5 (by norm_num) ↔ Nonempty (star5 ≃g starGraphFin 5 (by norm_num)) :=
  (bh_endpoint 5 (by norm_num) (by simp) star5 (SimpleGraph.isTree_starGraph _)).2.2.1

theorem endpoint_on_path :
    bh path5 = bhPath 5 ↔ Nonempty (path5 ≃g pathGraphFin 5) :=
  (bh_endpoint 5 (by norm_num) (by simp) path5 (isTree_pathGraph 5 (by norm_num))).2.2.2

/-- No universe restriction: the endpoint instantiates at `Type 1`. -/
theorem endpoint_universe_one (G : SimpleGraph (ULift.{1} (Fin 5))) [DecidableRel G.Adj]
    (h : G.IsTree) : bhStar 5 (by norm_num) ≤ bh G ∧ bh G ≤ bhPath 5 :=
  ⟨(bh_endpoint 5 (by norm_num) (by simp) G h).1, (bh_endpoint 5 (by norm_num) (by simp) G h).2.1⟩

/-- The endpoint instantiates at a non-`Fin` vertex type with arbitrary instances. -/
theorem endpoint_generic_type (α : Type) [Fintype α] [DecidableEq α] (hα : Fintype.card α = 6)
    (G : SimpleGraph α) [DecidableRel G.Adj] (h : G.IsTree) :
    bhStar 6 (by norm_num) ≤ bh G ∧ bh G ≤ bhPath 6 :=
  ⟨(bh_endpoint 6 (by norm_num) hα G h).1, (bh_endpoint 6 (by norm_num) hα G h).2.1⟩

/-- `bh` does not change with the `DecidableRel` instance (authors' `bh_inst`, re-used). -/
theorem bh_inst_control (i1 i2 : DecidableRel fork5.Adj) :
    @bh _ _ _ fork5 i1 = @bh _ _ _ fork5 i2 := bh_inst i1 i2

/-- The values exclude every subtly wrong model: no factor `n` would give `76/25`; power one
would give `16`; merging equal eigenvalues (no multiplicity) would give `26/5`. -/
theorem star5_not_other_models :
    bh star5 ≠ 76 / 25 ∧ bh star5 ≠ 16 ∧ bh star5 ≠ 26 / 5 := by
  rw [star5_value.1]
  norm_num

/-- Exactly one zero eigenvalue is dropped; the total weight is `n - 1 = 4` nonzero terms. -/
theorem star5_one_zero :
    (∑ i, (if lapEigs star5 i = 0 then (1 : ℕ) else 0)) = 1 := star5_value.2.2.1

end BiHCtrl3

#print axioms BiHCtrl3.endpoint_on_fork
#print axioms BiHCtrl3.endpoint_on_star
#print axioms BiHCtrl3.endpoint_on_path
#print axioms BiHCtrl3.endpoint_universe_one
#print axioms BiHCtrl3.bhPath_authors_formula_five
#print axioms BiHCtrl3.star5_not_other_models
