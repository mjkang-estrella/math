/-
BiHControl1: reviewer-authored Gate E semantic controls, importing ONLY the definition module
`BiHBase` (none of the authors' proof chain). Exact values of `bh` on concrete trees are derived
from the literal mathlib eigenvalues via `tr(L^k) = Σ λ^k` and Newton's identities, using exact
integer power traces of the literal Laplacian. Hand-derived expected values:
K2: 1/2. Star K_{1,4}: 76/5. Path P5: 38. Fork (spider with legs 2,1,1): 124/5.
Reviewer module; NOT part of the packet.
-/
import BiHBase
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum

open Matrix Unitary BiH

namespace BiHCtrl

section trace
variable {n : Type*} [Fintype n] [DecidableEq n]

/-- Independent derivation: the trace of a power is the power sum of the eigenvalues. -/
theorem trace_pow_eq (A : Matrix n n ℝ) (hA : A.IsHermitian) (k : ℕ) :
    (A ^ k).trace = ∑ i, (hA.eigenvalues i) ^ k := by
  let U : Matrix n n ℝ := ↑hA.eigenvectorUnitary
  let D : Matrix n n ℝ := diagonal hA.eigenvalues
  have hUtU : star U * U = 1 := coe_star_mul_self hA.eigenvectorUnitary
  have hUU : U * star U = 1 := coe_mul_star_self hA.eigenvectorUnitary
  have hAeq : A = U * D * star U := by
    conv_lhs => rw [hA.spectral_theorem]
    rw [conjStarAlgAut_apply]
    have hd : diagonal (RCLike.ofReal ∘ hA.eigenvalues) = D := by
      rw [RCLike.ofReal_real_eq_id]
      rfl
    rw [hd]
  have hpow : ∀ m : ℕ, A ^ m = U * D ^ m * star U := by
    intro m
    induction m with
    | zero => simp [hUU]
    | succ m ih =>
      calc A ^ (m + 1) = A ^ m * A := pow_succ A m
        _ = (U * D ^ m * star U) * (U * D * star U) := by rw [← hAeq, ih]
        _ = U * D ^ m * (star U * U) * D * star U := by simp only [Matrix.mul_assoc]
        _ = U * (D ^ m * D) * star U := by
            rw [hUtU]; simp only [Matrix.mul_assoc, Matrix.mul_one]
        _ = U * D ^ (m + 1) * star U := by rw [pow_succ]
  rw [hpow k, Matrix.trace_mul_cycle, hUtU, Matrix.one_mul]
  show (diagonal hA.eigenvalues ^ k).trace = _
  rw [Matrix.diagonal_pow, Matrix.trace_diagonal]
  rfl

end trace

/-- The reciprocal-square sum of four nonzero reals from their elementary symmetric functions. -/
theorem key4 (b c d e E2 E3 E4 : ℝ)
    (h2 : b * c + b * d + b * e + c * d + c * e + d * e = E2)
    (h3 : b * c * d + b * c * e + b * d * e + c * d * e = E3)
    (h4 : b * c * d * e = E4)
    (hb : b ≠ 0) (hc : c ≠ 0) (hd : d ≠ 0) (he : e ≠ 0) :
    b⁻¹ ^ 2 + c⁻¹ ^ 2 + d⁻¹ ^ 2 + e⁻¹ ^ 2 = (E3 ^ 2 - 2 * E2 * E4) / E4 ^ 2 := by
  subst h2 h3 h4
  field_simp
  ring

/-- Same for the sum of reciprocals (first power), used only for a negative comparison. -/
theorem key4_first (b c d e E3 E4 : ℝ)
    (h3 : b * c * d + b * c * e + b * d * e + c * d * e = E3)
    (h4 : b * c * d * e = E4)
    (hb : b ≠ 0) (hc : c ≠ 0) (hd : d ≠ 0) (he : e ≠ 0) :
    b⁻¹ + c⁻¹ + d⁻¹ + e⁻¹ = E3 / E4 := by
  subst h3 h4
  field_simp
  ring

/-- Five reals with prescribed power sums: exactly one is zero and the reciprocal sums are forced. -/
theorem five_core (a b c d e p1 p2 p3 p4 p5 E2 E3 E4 : ℝ)
    (h1 : a ^ 1 + b ^ 1 + c ^ 1 + d ^ 1 + e ^ 1 = p1)
    (h2 : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 + e ^ 2 = p2)
    (h3 : a ^ 3 + b ^ 3 + c ^ 3 + d ^ 3 + e ^ 3 = p3)
    (h4 : a ^ 4 + b ^ 4 + c ^ 4 + d ^ 4 + e ^ 4 = p4)
    (h5 : a ^ 5 + b ^ 5 + c ^ 5 + d ^ 5 + e ^ 5 = p5)
    (hE2 : E2 = (p1 ^ 2 - p2) / 2)
    (hE3 : E3 = (E2 * p1 - p1 * p2 + p3) / 3)
    (hE4 : E4 = (E3 * p1 - E2 * p2 + p1 * p3 - p4) / 4)
    (hE5 : E4 * p1 - E3 * p2 + E2 * p3 - p1 * p4 + p5 = 0)
    (hE40 : E4 ≠ 0) :
    ((if a = 0 then 0 else a⁻¹ ^ 2) + (if b = 0 then 0 else b⁻¹ ^ 2) +
        (if c = 0 then 0 else c⁻¹ ^ 2) + (if d = 0 then 0 else d⁻¹ ^ 2) +
        (if e = 0 then 0 else e⁻¹ ^ 2) = (E3 ^ 2 - 2 * E2 * E4) / E4 ^ 2) ∧
    ((if a = 0 then 0 else a⁻¹) + (if b = 0 then 0 else b⁻¹) +
        (if c = 0 then 0 else c⁻¹) + (if d = 0 then 0 else d⁻¹) +
        (if e = 0 then 0 else e⁻¹) = E3 / E4) ∧
    ((if a = 0 then (1 : ℕ) else 0) + (if b = 0 then 1 else 0) + (if c = 0 then 1 else 0) +
        (if d = 0 then 1 else 0) + (if e = 0 then 1 else 0) = 1) := by
  have e2' : a * b + a * c + a * d + a * e + b * c + b * d + b * e + c * d + c * e + d * e = E2 := by
    rw [hE2, ← h1, ← h2]; ring
  have e3' : a * b * c + a * b * d + a * b * e + a * c * d + a * c * e + a * d * e +
      b * c * d + b * c * e + b * d * e + c * d * e = E3 := by
    rw [hE3, hE2, ← h1, ← h2, ← h3]; ring
  have e4' : a * b * c * d + a * b * c * e + a * b * d * e + a * c * d * e + b * c * d * e = E4 := by
    rw [hE4, hE3, hE2, ← h1, ← h2, ← h3, ← h4]; ring
  have e5five : 5 * (a * b * c * d * e) = E4 * p1 - E3 * p2 + E2 * p3 - p1 * p4 + p5 := by
    rw [hE4, hE3, hE2, ← h1, ← h2, ← h3, ← h4, ← h5]; ring
  have e5' : a * b * c * d * e = 0 := by linarith
  have hzero : a = 0 ∨ b = 0 ∨ c = 0 ∨ d = 0 ∨ e = 0 := by
    simpa [mul_eq_zero, or_assoc] using e5'
  rcases hzero with rfl | rfl | rfl | rfl | rfl
  · have q2 : b * c + b * d + b * e + c * d + c * e + d * e = E2 := by linear_combination e2'
    have q3 : b * c * d + b * c * e + b * d * e + c * d * e = E3 := by linear_combination e3'
    have q4 : b * c * d * e = E4 := by linear_combination e4'
    have hb : b ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hc : c ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hd : d ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have he : e ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have k := key4 b c d e E2 E3 E4 q2 q3 q4 hb hc hd he
    have k1 := key4_first b c d e E3 E4 q3 q4 hb hc hd he
    refine ⟨?_, ?_, ?_⟩
    · rw [ite_eq_left rfl, ite_eq_right hb, ite_eq_right hc, ite_eq_right hd, ite_eq_right he]; linear_combination k
    · rw [ite_eq_left rfl, ite_eq_right hb, ite_eq_right hc, ite_eq_right hd, ite_eq_right he]; linear_combination k1
    · simp [hb, hc, hd, he]
  · have q2 : a * c + a * d + a * e + c * d + c * e + d * e = E2 := by linear_combination e2'
    have q3 : a * c * d + a * c * e + a * d * e + c * d * e = E3 := by linear_combination e3'
    have q4 : a * c * d * e = E4 := by linear_combination e4'
    have ha : a ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hc : c ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hd : d ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have he : e ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have k := key4 a c d e E2 E3 E4 q2 q3 q4 ha hc hd he
    have k1 := key4_first a c d e E3 E4 q3 q4 ha hc hd he
    refine ⟨?_, ?_, ?_⟩
    · rw [ite_eq_right ha, ite_eq_left rfl, ite_eq_right hc, ite_eq_right hd, ite_eq_right he]; linear_combination k
    · rw [ite_eq_right ha, ite_eq_left rfl, ite_eq_right hc, ite_eq_right hd, ite_eq_right he]; linear_combination k1
    · simp [ha, hc, hd, he]
  · have q2 : a * b + a * d + a * e + b * d + b * e + d * e = E2 := by linear_combination e2'
    have q3 : a * b * d + a * b * e + a * d * e + b * d * e = E3 := by linear_combination e3'
    have q4 : a * b * d * e = E4 := by linear_combination e4'
    have ha : a ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hb : b ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hd : d ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have he : e ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have k := key4 a b d e E2 E3 E4 q2 q3 q4 ha hb hd he
    have k1 := key4_first a b d e E3 E4 q3 q4 ha hb hd he
    refine ⟨?_, ?_, ?_⟩
    · rw [ite_eq_right ha, ite_eq_right hb, ite_eq_left rfl, ite_eq_right hd, ite_eq_right he]; linear_combination k
    · rw [ite_eq_right ha, ite_eq_right hb, ite_eq_left rfl, ite_eq_right hd, ite_eq_right he]; linear_combination k1
    · simp [ha, hb, hd, he]
  · have q2 : a * b + a * c + a * e + b * c + b * e + c * e = E2 := by linear_combination e2'
    have q3 : a * b * c + a * b * e + a * c * e + b * c * e = E3 := by linear_combination e3'
    have q4 : a * b * c * e = E4 := by linear_combination e4'
    have ha : a ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hb : b ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hc : c ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have he : e ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have k := key4 a b c e E2 E3 E4 q2 q3 q4 ha hb hc he
    have k1 := key4_first a b c e E3 E4 q3 q4 ha hb hc he
    refine ⟨?_, ?_, ?_⟩
    · rw [ite_eq_right ha, ite_eq_right hb, ite_eq_right hc, ite_eq_left rfl, ite_eq_right he]; linear_combination k
    · rw [ite_eq_right ha, ite_eq_right hb, ite_eq_right hc, ite_eq_left rfl, ite_eq_right he]; linear_combination k1
    · simp [ha, hb, hc, he]
  · have q2 : a * b + a * c + a * d + b * c + b * d + c * d = E2 := by linear_combination e2'
    have q3 : a * b * c + a * b * d + a * c * d + b * c * d = E3 := by linear_combination e3'
    have q4 : a * b * c * d = E4 := by linear_combination e4'
    have ha : a ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hb : b ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hc : c ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have hd : d ≠ 0 := by rintro rfl; exact hE40 (by rw [← q4]; ring)
    have k := key4 a b c d E2 E3 E4 q2 q3 q4 ha hb hc hd
    have k1 := key4_first a b c d E3 E4 q3 q4 ha hb hc hd
    refine ⟨?_, ?_, ?_⟩
    · rw [ite_eq_right ha, ite_eq_right hb, ite_eq_right hc, ite_eq_right hd, ite_eq_left rfl]; linear_combination k
    · rw [ite_eq_right ha, ite_eq_right hb, ite_eq_right hc, ite_eq_right hd, ite_eq_left rfl]; linear_combination k1
    · simp [ha, hb, hc, hd]

end BiHCtrl
