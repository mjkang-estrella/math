/-
AuditWalk: reviewer-authored Gate C transitive closure walk, leaner than AuditAxioms (no explicit
`import Lean`; duplicates are filtered during the fold). Reviewer module; NOT part of the packet.
-/
import BiHPathValue

open Lean Elab Command

namespace BiHAudit

def pushUnseen (seen : Std.HashSet Name) (acc : Array Name) (e : Expr) : Array Name :=
  e.foldConsts acc fun n a => if seen.contains n then a else a.push n

def extendStack (seen : Std.HashSet Name) (c : ConstantInfo) (stack : Array Name) : Array Name :=
  let acc := pushUnseen seen stack c.type
  match c with
  | .defnInfo v => pushUnseen seen acc v.value
  | .thmInfo v => pushUnseen seen acc v.value
  | .opaqueInfo v => pushUnseen seen acc v.value
  | .inductInfo v => (v.ctors.foldl (·.push ·) acc) |> fun a => v.all.foldl (·.push ·) a
  | .ctorInfo v => acc.push v.induct
  | .recInfo v =>
      let a2 := v.all.foldl (·.push ·) acc
      v.rules.foldl (fun a r => pushUnseen seen (a.push r.ctor) r.rhs) a2
  | _ => acc

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quot"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "ctor"
  | .recInfo _ => "rec"

def walk (env : Environment) (roots : Array Name) : Std.HashSet Name × Array Name := Id.run do
  let mut seen : Std.HashSet Name := {}
  let mut missing : Array Name := #[]
  let mut stack := roots
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if seen.contains n then continue
    seen := seen.insert n
    match env.find? n with
    | none => missing := missing.push n
    | some c => stack := extendStack seen c stack
  return (seen, missing)

def topComponent (n : Name) : String :=
  match n.components with
  | [] => "?"
  | c :: _ => c.toString

def bump (m : Std.HashMap String Nat) (k : String) : Std.HashMap String Nat :=
  m.insert k (m.getD k 0 + 1)

def showMap (m : Std.HashMap String Nat) : String :=
  let l := m.toList.toArray.qsort (fun a b => a.1 < b.1)
  ", ".intercalate (l.map fun (k, v) => s!"{k}={v}").toList

def names (a : Array Name) (cap : Nat) : String :=
  let sorted := a.qsort Name.lt
  let shown := sorted.toList.take cap
  let s := ", ".intercalate (shown.map toString)
  if a.size > cap then s ++ s!" … ({a.size - cap} more)" else s

end BiHAudit

open BiHAudit in
run_cmd do
  let env ← getEnv
  let roots : Array Name := #[``BiH.bh_endpoint, ``BiH.shift_increases, ``BiH.exists_maximizer,
    ``BiH.iso_path_of_maximal, ``BiH.starN_div_le_bh, ``BiH.iso_star_of_allPendant,
    ``BiH.bhPath_value]
  let (seen, missing) := walk env roots
  let mut kinds : Std.HashMap String Nat := {}
  let mut mods : Std.HashMap String Nat := {}
  let mut axs : Array Name := #[]
  let mut unsafes : Array Name := #[]
  let mut partials : Array Name := #[]
  let mut opaques : Array Name := #[]
  let mut impl : Array Name := #[]
  let mut ext : Array Name := #[]
  let mut biHmods : Array Name := #[]
  let mut biHoutside : Array Name := #[]
  for n in seen do
    match env.find? n with
    | none => pure ()
    | some c =>
      kinds := bump kinds (kindOf c)
      if c.isUnsafe then unsafes := unsafes.push n
      if c.isPartial then partials := partials.push n
      match c with
      | .axiomInfo _ => axs := axs.push n
      | .opaqueInfo _ => opaques := opaques.push n
      | _ => pure ()
      if (Compiler.getImplementedBy? env n).isSome then impl := impl.push n
      if isExtern env n then ext := ext.push n
      match env.getModuleIdxFor? n with
      | none => mods := bump mods "<current>"
      | some idx =>
        let modName := env.header.moduleNames[idx.toNat]!
        let tc := topComponent modName
        let isBiH := tc.startsWith "BiH"
        mods := bump mods (if isBiH then "BiH*" else tc)
        if isBiH then
          biHmods := biHmods.push n
          if !(n.components.head?.map (fun c => c == `BiH) |>.getD false) then
            biHoutside := biHoutside.push n
  logInfo m!"closure size (joint, 7 roots): {seen.size}; missing from env: {missing.size}"
  logInfo m!"kinds: {showMap kinds}"
  logInfo m!"source modules by top component: {showMap mods}"
  logInfo m!"axioms ({axs.size}): {names axs 50}"
  logInfo m!"unsafe ({unsafes.size}): {names unsafes 60}"
  logInfo m!"partial ({partials.size}): {names partials 60}"
  logInfo m!"opaque ({opaques.size}): {names opaques 60}"
  logInfo m!"implemented_by ({impl.size}): {names impl 80}"
  logInfo m!"extern ({ext.size}): {names ext 30}"
  logInfo m!"constants from BiH* modules: {biHmods.size}"
  logInfo m!"constants from BiH* modules outside namespace BiH ({biHoutside.size}): {names biHoutside 60}"
  logInfo m!"modules imported: {env.header.moduleNames.size}"
  logInfo m!"lean version: {Lean.versionString}, githash {Lean.githash}"
