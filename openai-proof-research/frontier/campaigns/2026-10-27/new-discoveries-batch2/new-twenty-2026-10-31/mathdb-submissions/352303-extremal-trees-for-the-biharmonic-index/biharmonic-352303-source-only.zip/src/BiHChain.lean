/-
BiHChain: pendant chains from a leaf. Every tree has either a full chain (and is then a path) or
a chain ending at a vertex with two further neighbours (the shift data).

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHIso
import Mathlib.Order.Interval.Finset.Nat

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- A pendant chain `x 0, …, x k`: consecutive adjacency, injectivity, and every `x i` with
`i < k` has no neighbours other than its chain neighbours. -/
structure PChain (G : SimpleGraph V) (k : ℕ) (x : ℕ → V) : Prop where
  adj : ∀ i < k, G.Adj (x i) (x (i + 1))
  inj : ∀ i ≤ k, ∀ j ≤ k, x i = x j → i = j
  nbr : ∀ i < k, ∀ z, G.Adj (x i) z → z = x (i + 1) ∨ ∃ j, i = j + 1 ∧ z = x j

/-- Extending a chain through a degree-two endpoint. -/
theorem PChain.extend {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} (h : PChain G k x) (hk : 1 ≤ k)
    {z : V} (hadj : G.Adj (x k) z) (hz : z ≠ x (k - 1))
    (honly : ∀ u, G.Adj (x k) u → u = x (k - 1) ∨ u = z) :
    PChain G (k + 1) (Function.update x (k + 1) z) := by
  have hold : ∀ i, i ≠ k + 1 → Function.update x (k + 1) z i = x i := fun i hi =>
    Function.update_of_ne hi _ _
  have hnew : Function.update x (k + 1) z (k + 1) = z := Function.update_self _ _ _
  have hznot : ∀ j ≤ k, z ≠ x j := by
    intro j hj hzj
    rcases Nat.lt_or_ge j k with hlt | hge
    · rw [hzj] at hadj
      rcases h.nbr j hlt (x k) hadj.symm with h1 | ⟨j', hj', h1⟩
      · have : j + 1 = k := (h.inj k le_rfl (j + 1) hlt h1).symm
        apply hz
        rw [hzj]
        congr 1
        omega
      · have : k = j' := h.inj k le_rfl j' (by omega) h1
        omega
    · have : j = k := le_antisymm hj hge
      subst this
      rw [hzj] at hadj
      exact hadj.ne rfl
  refine ⟨?_, ?_, ?_⟩
  · intro i hi
    rcases Nat.lt_or_ge i k with hlt | hge
    · rw [hold i (by omega), hold (i + 1) (by omega)]
      exact h.adj i hlt
    · have : i = k := by omega
      subst this
      rw [hold i (by omega), hnew]
      exact hadj
  · intro i hi j hj hij
    rcases Nat.lt_or_ge i (k + 1) with hilt | hige
    · rcases Nat.lt_or_ge j (k + 1) with hjlt | hjge
      · rw [hold i (by omega), hold j (by omega)] at hij
        exact h.inj i (by omega) j (by omega) hij
      · have hj' : j = k + 1 := by omega
        subst hj'
        rw [hold i (by omega), hnew] at hij
        exact absurd hij.symm (hznot i (by omega))
    · rcases Nat.lt_or_ge j (k + 1) with hjlt | hjge
      · have hi' : i = k + 1 := by omega
        subst hi'
        rw [hold j (by omega), hnew] at hij
        exact absurd hij (hznot j (by omega))
      · omega
  · intro i hi u hu
    rcases Nat.lt_or_ge i k with hlt | hge
    · rw [hold i (by omega)] at hu
      rcases h.nbr i hlt u hu with h1 | ⟨j, hj, h1⟩
      · left
        rw [hold (i + 1) (by omega)]
        exact h1
      · right
        refine ⟨j, hj, ?_⟩
        rw [hold j (by omega)]
        exact h1
    · have hi' : i = k := by omega
      subst hi'
      rw [hold i (by omega)] at hu
      rcases honly u hu with h1 | h1
      · right
        refine ⟨i - 1, by omega, ?_⟩
        rw [hold (i - 1) (by omega)]
        exact h1
      · left
        rw [hnew]
        exact h1

/-- A chain has at most `card V` vertices. -/
theorem PChain.card_bound {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} (h : PChain G k x) :
    k + 1 ≤ Fintype.card V := by
  have hinj : Function.Injective (fun i : Fin (k + 1) => x i) := by
    intro i j hij
    exact Fin.ext (h.inj i (Nat.lt_succ_iff.mp i.2) j (Nat.lt_succ_iff.mp j.2) hij)
  simpa using Fintype.card_le_of_injective _ hinj

/-- **Dichotomy.** From a leaf `y` with unique neighbour `v` in a connected graph, take a
maximal chain. It either closes up (full) or ends at a vertex with two further neighbours. -/
theorem exists_chain {G : SimpleGraph V} (y v : V) (hyv : G.Adj y v)
    (hleaf : ∀ u, G.Adj y u → u = v) :
    ∃ k x, 1 ≤ k ∧ x 0 = y ∧ PChain G k x ∧
      ((∀ u, G.Adj (x k) u → u = x (k - 1)) ∨
        ∃ c b, G.Adj (x k) c ∧ G.Adj (x k) b ∧ c ≠ b ∧ c ≠ x (k - 1) ∧ b ≠ x (k - 1)) := by
  classical
  let P : ℕ → Prop := fun k => 1 ≤ k ∧ ∃ x : ℕ → V, x 0 = y ∧ PChain G k x
  have hP1 : P 1 := by
    refine ⟨le_rfl, fun i => if i = 0 then y else v, by simp, ?_, ?_, ?_⟩
    · intro i hi
      have : i = 0 := by omega
      subst this
      simpa using hyv
    · intro i hi j hj hij
      interval_cases i <;> interval_cases j <;> simp at hij ⊢
      · exact absurd hij hyv.ne
      · exact absurd hij.symm hyv.ne
    · intro i hi z hz
      have : i = 0 := by omega
      subst this
      left
      simpa using hleaf z (by simpa using hz)
  have hbd : ∀ k, P k → k ≤ Fintype.card V := by
    rintro k ⟨_, x, _, hx⟩
    have := hx.card_bound
    omega
  let k := Nat.findGreatest P (Fintype.card V)
  have hPk : P k := Nat.findGreatest_spec (m := 1) (hbd 1 hP1) hP1
  have hmax : ¬ P (k + 1) := by
    by_cases hle : k + 1 ≤ Fintype.card V
    · exact Nat.findGreatest_is_greatest (Nat.lt_succ_self k) hle
    · intro h
      exact hle (hbd _ h)
  obtain ⟨hk1, x, hx0, hx⟩ := hPk
  refine ⟨k, x, hk1, hx0, hx, ?_⟩
  by_cases hfull : ∀ u, G.Adj (x k) u → u = x (k - 1)
  · exact Or.inl hfull
  · right
    push Not at hfull
    obtain ⟨c, hc, hc'⟩ := hfull
    by_cases honly : ∀ u, G.Adj (x k) u → u = x (k - 1) ∨ u = c
    · exfalso
      apply hmax
      exact ⟨by omega, _, by rw [Function.update_of_ne (by omega)]; exact hx0,
        hx.extend hk1 hc hc' honly⟩
    · push Not at honly
      obtain ⟨b, hb, hb1, hb2⟩ := honly
      exact ⟨c, b, hc, hb, Ne.symm hb2, hc', hb1⟩

/-- A full chain covers the whole vertex set. -/
theorem PChain.mem_of_full {G : SimpleGraph V} (hconn : G.Preconnected) {k : ℕ} {x : ℕ → V}
    (h : PChain G k x) (hk : 1 ≤ k) (hfull : ∀ u, G.Adj (x k) u → u = x (k - 1)) (v : V) :
    ∃ i ≤ k, v = x i := by
  obtain ⟨p⟩ := hconn (x 0) v
  refine walk_prop (P := fun z => ∃ i ≤ k, z = x i) ?_ p ⟨0, by omega, rfl⟩
  rintro u u' hadj ⟨i, hi, rfl⟩
  rcases Nat.lt_or_ge i k with hlt | hge
  · rcases h.nbr i hlt u' hadj with h1 | ⟨j, hj, h1⟩
    · exact ⟨i + 1, hlt, h1⟩
    · exact ⟨j, by omega, h1⟩
  · have : i = k := le_antisymm hi hge
    subst this
    exact ⟨i - 1, by omega, hfull u' hadj⟩

/-- A connected graph with a full chain is isomorphic to the path. -/
theorem iso_path_of_full {n : ℕ} (hV : Fintype.card V = n) {G : SimpleGraph V}
    (hconn : G.Preconnected) {k : ℕ} {x : ℕ → V} (h : PChain G k x) (hk : 1 ≤ k)
    (hfull : ∀ u, G.Adj (x k) u → u = x (k - 1)) :
    Nonempty (G ≃g pathGraphFin n) := by
  have hinj : Function.Injective (fun i : Fin (k + 1) => x i) := by
    intro i j hij
    exact Fin.ext (h.inj i (Nat.lt_succ_iff.mp i.2) j (Nat.lt_succ_iff.mp j.2) hij)
  have hsurj : Function.Surjective (fun i : Fin (k + 1) => x i) := by
    intro v
    obtain ⟨i, hi, rfl⟩ := h.mem_of_full hconn hk hfull v
    exact ⟨⟨i, Nat.lt_succ_iff.mpr hi⟩, rfl⟩
  have hcard : k + 1 = n := by
    have := Fintype.card_of_bijective ⟨hinj, hsurj⟩
    simp only [Fintype.card_fin] at this
    omega
  subst hcard
  let e : Fin (k + 1) ≃ V := Equiv.ofBijective _ ⟨hinj, hsurj⟩
  refine ⟨SimpleGraph.Iso.symm { toEquiv := e, map_rel_iff' := ?_ }⟩
  intro a b
  have hea : ∀ i : Fin (k + 1), e i = x i := fun _ => rfl
  rw [hea, hea, SimpleGraph.pathGraph_adj]
  have ha := Nat.lt_succ_iff.mp a.2
  have hb := Nat.lt_succ_iff.mp b.2
  constructor
  · intro hadj
    rcases Nat.lt_or_ge a.val k with hlt | hge
    · rcases h.nbr a.val hlt (x b) hadj with h1 | ⟨j, hj, h1⟩
      · have : b.val = a.val + 1 := h.inj b.val hb (a.val + 1) hlt h1
        exact Or.inl this.symm
      · have : b.val = j := h.inj b.val hb j (by omega) h1
        exact Or.inr (by omega)
    · have haeq : a.val = k := le_antisymm ha hge
      have hxa : x a.val = x k := congrArg x haeq
      have hb1 := hfull (x b) (by rw [← hxa]; exact hadj)
      have : b.val = k - 1 := h.inj b.val hb (k - 1) (by omega) hb1
      exact Or.inr (by omega)
  · rintro (h1 | h1)
    · have : b.val = a.val + 1 := h1.symm
      rw [this]
      exact h.adj a.val (by omega)
    · have : a.val = b.val + 1 := h1.symm
      rw [this]
      exact (h.adj b.val (by omega)).symm

end BiH
