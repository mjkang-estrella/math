/-
AuditAxioms: reviewer-authored Gate C audit. `#print axioms` for the seven named theorems and a
full transitive-constant-closure walk through the environment API. Reviewer module; NOT part of
the packet.
-/
import BiHPathValue
import Lean

open Lean Elab Command

#print axioms BiH.bh_endpoint
#print axioms BiH.shift_increases
#print axioms BiH.exists_maximizer
#print axioms BiH.iso_path_of_maximal
#print axioms BiH.starN_div_le_bh
#print axioms BiH.iso_star_of_allPendant
#print axioms BiH.bhPath_value

#check @BiH.bh_endpoint
#print BiH.bh
#print BiH.lapEigs
#print BiH.bhStar
#print BiH.bhPath
#print BiH.starGraphFin
#print BiH.pathGraphFin

namespace BiHAudit

def depsOf (c : ConstantInfo) : Array Name :=
  let fromE (acc : Array Name) (e : Expr) : Array Name := e.foldConsts acc fun n a => a.push n
  let acc := fromE #[] c.type
  match c with
  | .defnInfo v => fromE acc v.value
  | .thmInfo v => fromE acc v.value
  | .opaqueInfo v => fromE acc v.value
  | .inductInfo v => acc ++ v.ctors.toArray ++ v.all.toArray
  | .ctorInfo v => acc.push v.induct
  | .recInfo v =>
      let acc2 := acc ++ v.all.toArray
      v.rules.foldl (fun a r => fromE (a.push r.ctor) r.rhs) acc2
  | .quotInfo _ => acc
  | .axiomInfo _ => acc

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quot"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "ctor"
  | .recInfo _ => "rec"

def walk (env : Environment) (roots : Array Name) : Std.HashSet Name × Array Name := Id.run do
  let mut seen : Std.HashSet Name := {}
  let mut missing : Array Name := #[]
  let mut stack := roots
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if seen.contains n then continue
    seen := seen.insert n
    match env.find? n with
    | none => missing := missing.push n
    | some c =>
      for d in depsOf c do
        if !seen.contains d then stack := stack.push d
  return (seen, missing)

def topComponent (n : Name) : String :=
  match n.components with
  | [] => "?"
  | c :: _ => c.toString

def bump (m : Std.HashMap String Nat) (k : String) : Std.HashMap String Nat :=
  m.insert k (m.getD k 0 + 1)

def showMap (m : Std.HashMap String Nat) : String :=
  let l := m.toList.toArray.qsort (fun a b => a.1 < b.1)
  ", ".intercalate (l.map fun (k, v) => s!"{k}={v}").toList

def names (a : Array Name) (cap : Nat) : String :=
  let sorted := a.qsort Name.lt
  let shown := sorted.toList.take cap
  let s := ", ".intercalate (shown.map toString)
  if a.size > cap then s ++ s!" … ({a.size - cap} more)" else s

end BiHAudit

open BiHAudit in
run_cmd do
  let env ← getEnv
  let roots : Array Name := #[``BiH.bh_endpoint, ``BiH.shift_increases, ``BiH.exists_maximizer,
    ``BiH.iso_path_of_maximal, ``BiH.starN_div_le_bh, ``BiH.iso_star_of_allPendant,
    ``BiH.bhPath_value]
  let (seen, missing) := walk env roots
  logInfo m!"closure size (joint, 7 roots): {seen.size}; missing from env: {missing.size}"
  let mut kinds : Std.HashMap String Nat := {}
  let mut mods : Std.HashMap String Nat := {}
  let mut axs : Array Name := #[]
  let mut unsafes : Array Name := #[]
  let mut partials : Array Name := #[]
  let mut opaques : Array Name := #[]
  let mut impl : Array Name := #[]
  let mut ext : Array Name := #[]
  let mut biHmods : Array Name := #[]
  let mut biHoutside : Array Name := #[]
  for n in seen do
    match env.find? n with
    | none => pure ()
    | some c =>
      kinds := bump kinds (kindOf c)
      if c.isUnsafe then unsafes := unsafes.push n
      if c.isPartial then partials := partials.push n
      match c with
      | .axiomInfo _ => axs := axs.push n
      | .opaqueInfo _ => opaques := opaques.push n
      | _ => pure ()
      if (Compiler.getImplementedBy? env n).isSome then impl := impl.push n
      if isExtern env n then ext := ext.push n
      match env.getModuleIdxFor? n with
      | none => mods := bump mods "<current>"
      | some idx =>
        let modName := env.header.moduleNames[idx.toNat]!
        let tc := topComponent modName
        let isBiH := tc.startsWith "BiH"
        mods := bump mods (if isBiH then "BiH*" else tc)
        if isBiH then
          biHmods := biHmods.push n
          if !(n.components.head?.map (fun c => c == `BiH) |>.getD false) then
            biHoutside := biHoutside.push n
  logInfo m!"kinds: {showMap kinds}"
  logInfo m!"source modules by top component: {showMap mods}"
  logInfo m!"axioms ({axs.size}): {names axs 50}"
  logInfo m!"unsafe ({unsafes.size}): {names unsafes 60}"
  logInfo m!"partial ({partials.size}): {names partials 60}"
  logInfo m!"opaque ({opaques.size}): {names opaques 60}"
  logInfo m!"implemented_by ({impl.size}): {names impl 80}"
  logInfo m!"extern ({ext.size}): {names ext 30}"
  logInfo m!"constants from BiH* modules: {biHmods.size}"
  logInfo m!"constants from BiH* modules outside namespace BiH ({biHoutside.size}): {names biHoutside 60}"
  logInfo m!"modules imported: {env.header.moduleNames.size}"
  logInfo m!"lean version: {Lean.versionString}, githash {Lean.githash}"
