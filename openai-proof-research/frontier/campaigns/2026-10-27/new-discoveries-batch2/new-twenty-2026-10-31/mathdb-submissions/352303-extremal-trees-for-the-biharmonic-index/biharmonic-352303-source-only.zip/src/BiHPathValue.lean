/-
BiHPathValue: the exact value of `bh` on the path as a finite double sum, and two negative
controls: `BH(P_4) = 13` and `BH(K_{1,3}) = 33/4`.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHEndpoint

namespace BiH

set_option linter.unusedSectionVars false

/-- The standard path labelling as a chain. -/
theorem pathChain (n : ℕ) (hn : 2 ≤ n) :
    PChain (SimpleGraph.pathGraph n) (n - 1)
      (fun i => (⟨min i (n - 1), by omega⟩ : Fin n)) := by
  refine ⟨?_, ?_, ?_⟩
  · intro i hi
    rw [SimpleGraph.pathGraph_adj]
    left
    simp only
    rw [min_eq_left (by omega), min_eq_left (by omega)]
  · intro i hi j hj h
    have h1 := congrArg Fin.val h
    simp only at h1
    rw [min_eq_left hi, min_eq_left hj] at h1
    exact h1
  · intro i hi z hz
    rw [SimpleGraph.pathGraph_adj] at hz
    simp only at hz
    rw [min_eq_left (by omega)] at hz
    rcases hz with h1 | h1
    · left
      apply Fin.ext
      simp only
      rw [min_eq_left (by omega)]
      omega
    · right
      refine ⟨z.val, by omega, ?_⟩
      apply Fin.ext
      simp only
      rw [min_eq_left (by omega)]

theorem isTree_pathGraph (n : ℕ) (hn : 2 ≤ n) : (pathGraphFin n).IsTree := by
  classical
  have hstar : (SimpleGraph.starGraph (⟨0, by omega⟩ : Fin n)).IsTree :=
    SimpleGraph.isTree_starGraph _
  obtain ⟨H, hH, hmax⟩ := exists_maximizer hstar
  obtain ⟨ψ⟩ := iso_path_of_maximal (Fintype.card_fin n) hn hH hmax
  exact (ψ.isTree_iff).mp hH

/-- **The path value.** -/
theorem bhPath_value (n : ℕ) (hn : 2 ≤ n) :
    bhPath n = (∑ a ∈ Finset.range (n - 1), ∑ b ∈ Finset.range (n - 1),
      ((n : ℝ) * ((min (a + 1) (b + 1) : ℕ) : ℝ) - ((a : ℝ) + 1) * ((b : ℝ) + 1)) ^ 2) / (n : ℝ) := by
  classical
  have hc := pathChain n hn
  have hT := isTree_pathGraph n hn
  set x : ℕ → Fin n := fun i => (⟨min i (n - 1), by omega⟩ : Fin n) with hx
  have hxval : ∀ m : ℕ, m ≤ n - 1 → (x m).val = m := by
    intro m hm
    simp only [hx]
    exact min_eq_left hm
  have hmem : ∀ i : Fin (n - 1), s(x i, x (i.val + 1)) ∈ (pathGraphFin n).edgeSet :=
    fun i => hc.adj i i.2
  have hbij : ∀ e ∈ (pathGraphFin n).edgeSet,
      ∃! i : Fin (n - 1), s(x i, x (i.val + 1)) = e := by
    intro e he
    obtain ⟨u, v, rfl⟩ := exists_pair e
    have huv : (pathGraphFin n).Adj u v := he
    rw [SimpleGraph.pathGraph_adj] at huv
    have hun : u.val ≤ n - 1 := by have := u.2; omega
    have hvn : v.val ≤ n - 1 := by have := v.2; omega
    rcases huv with h | h
    · refine ⟨⟨u.val, by omega⟩, ?_, ?_⟩
      · have h1 : x u.val = u := Fin.ext (hxval _ hun)
        have h2 : x (u.val + 1) = v := Fin.ext (by rw [hxval _ (by omega)]; exact h)
        show s(x u.val, x (u.val + 1)) = s(u, v)
        rw [h1, h2]
      · rintro ⟨y, hy⟩ hyeq
        have hyeq' : s(x y, x (y + 1)) = s(u, v) := hyeq
        rw [Sym2.eq_iff] at hyeq'
        rcases hyeq' with ⟨h1, _⟩ | ⟨h1, h2⟩
        · apply Fin.ext
          show y = u.val
          have := congrArg Fin.val h1
          rwa [hxval y (by omega)] at this
        · exfalso
          have h3 := congrArg Fin.val h1
          have h4 := congrArg Fin.val h2
          rw [hxval y (by omega)] at h3
          rw [hxval (y + 1) (by omega)] at h4
          omega
    · refine ⟨⟨v.val, by omega⟩, ?_, ?_⟩
      · have h1 : x v.val = v := Fin.ext (hxval _ hvn)
        have h2 : x (v.val + 1) = u := Fin.ext (by rw [hxval _ (by omega)]; exact h)
        show s(x v.val, x (v.val + 1)) = s(u, v)
        rw [h1, h2, Sym2.eq_swap]
      · rintro ⟨y, hy⟩ hyeq
        have hyeq' : s(x y, x (y + 1)) = s(u, v) := hyeq
        rw [Sym2.eq_iff] at hyeq'
        rcases hyeq' with ⟨h1, h2⟩ | ⟨h1, _⟩
        · exfalso
          have h3 := congrArg Fin.val h1
          have h4 := congrArg Fin.val h2
          rw [hxval y (by omega)] at h3
          rw [hxval (y + 1) (by omega)] at h4
          omega
        · apply Fin.ext
          show y = v.val
          have := congrArg Fin.val h1
          rwa [hxval y (by omega)] at this
  have hbh := bh_eq_family hT (fun i : Fin (n - 1) => s(x i, x (i.val + 1))) hmem hbij
    (fun i => chainL x (i.val + 1)) (fun i => chainL_side hc i.2)
  unfold bhPath
  rw [hbh, Fintype.card_fin]
  congr 1
  rw [Finset.sum_range]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  rw [Finset.sum_range]
  refine Finset.sum_congr rfl (fun j _ => ?_)
  have hi := i.2
  have hj := j.2
  rw [tau_chainL hc (by omega) (by omega), Fintype.card_fin]
  push_cast
  ring

/-- Negative control: `BH(P_4) = 13`. -/
theorem bhPath_four : bhPath 4 = 13 := by
  rw [bhPath_value 4 (by norm_num)]
  norm_num [Finset.sum_range_succ, min_def]

/-- Negative control: `BH(K_{1,3}) = 33/4`. -/
theorem bhStar_four : bhStar 4 (by norm_num) = 33 / 4 := by
  unfold bhStar starGraphFin
  rw [bh_eq_starN_of_allPendant (SimpleGraph.isTree_starGraph _)
    (allPendant_starGraph _), Fintype.card_fin]
  unfold starN
  norm_num

end BiH
