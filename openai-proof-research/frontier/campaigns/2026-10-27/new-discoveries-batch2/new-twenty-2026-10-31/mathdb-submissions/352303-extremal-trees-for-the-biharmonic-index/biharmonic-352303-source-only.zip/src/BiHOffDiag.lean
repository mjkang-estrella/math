/-
BiHOffDiag: laminarity of tree cuts, the off-diagonal lower bound `tau ≥ 1`, the sum bound
`N(T) ≥ N(star)`, its equality case (every edge pendant), and the value of `bh` on such trees.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHSide

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- Laminarity. If the ends of `f` lie in `A` and the ends of `e` lie in `B`, then `A ∪ B` is
everything. -/
theorem cover {G : SimpleGraph V} (hconn : G.Preconnected) {e f : Sym2 V} {A B : Finset V}
    (hA : IsSide G e A) (hB : IsSide G f B)
    (h1 : ∀ z ∈ f, z ∈ A) (h2 : ∀ z ∈ e, z ∈ B) (z : V) : z ∈ A ∨ z ∈ B := by
  obtain ⟨⟨a, b, he, ha, hb⟩, hA2⟩ := hA
  have hbB : b ∈ B := h2 b (by rw [he]; exact Sym2.mem_mk_right a b)
  have key : ∀ u v, G.Adj u v → (u ∈ A ∨ u ∈ B) → (v ∈ A ∨ v ∈ B) := by
    intro u v huv hu
    by_cases hv : v ∈ A
    · exact Or.inl hv
    · right
      rcases hu with hu | hu
      · have hcross : s(u, v) = e := by
          by_contra hne
          exact hv ((hA2 u v huv hne).mp hu)
        rw [he, Sym2.eq_iff] at hcross
        rcases hcross with ⟨_, rfl⟩ | ⟨rfl, rfl⟩
        · exact hbB
        · exact absurd ha hv
      · by_cases huA : u ∈ A
        · have hcross : s(u, v) = e := by
            by_contra hne
            exact hv ((hA2 u v huv hne).mp huA)
          rw [he, Sym2.eq_iff] at hcross
          rcases hcross with ⟨_, rfl⟩ | ⟨rfl, rfl⟩
          · exact hbB
          · exact absurd ha hv
        · have hne : s(u, v) ≠ f := by
            intro h
            exact huA (h1 u (by rw [← h]; exact Sym2.mem_mk_left u v))
          exact (hB.2 u v huv hne).mp hu
  obtain ⟨p⟩ := hconn b z
  exact walk_prop (P := fun z => z ∈ A ∨ z ∈ B) key p (Or.inr hbB)

/-- With `A ∪ B` everything and both differences non-empty, `tau A B ≥ 1`. -/
theorem one_le_tau_of_cover {A B : Finset V} (hcov : ∀ z, z ∈ A ∨ z ∈ B)
    (h1 : ∃ v, v ∈ A ∧ v ∉ B) (h2 : ∃ v, v ∈ B ∧ v ∉ A) : 1 ≤ tau A B := by
  have hA := Finset.card_sdiff_add_card_inter A B
  have hB := Finset.card_sdiff_add_card_inter B A
  have hU := Finset.card_union_add_card_inter A B
  have hu : A ∪ B = Finset.univ := by
    rw [Finset.eq_univ_iff_forall]
    intro z
    exact Finset.mem_union.mpr (hcov z)
  rw [hu, Finset.card_univ] at hU
  rw [Finset.inter_comm B A] at hB
  have hx : 1 ≤ (A \ B).card := by
    obtain ⟨v, hv, hv'⟩ := h1
    exact Finset.card_pos.mpr ⟨v, Finset.mem_sdiff.mpr ⟨hv, hv'⟩⟩
  have hy : 1 ≤ (B \ A).card := by
    obtain ⟨v, hv, hv'⟩ := h2
    exact Finset.card_pos.mpr ⟨v, Finset.mem_sdiff.mpr ⟨hv, hv'⟩⟩
  unfold tau
  set x : ℝ := ((A \ B).card : ℝ) with hxr
  set y : ℝ := ((B \ A).card : ℝ) with hyr
  set w : ℝ := ((A ∩ B).card : ℝ) with hwr
  have hA' : (A.card : ℝ) = x + w := by
    rw [hxr, hwr]
    exact_mod_cast hA.symm
  have hB' : (B.card : ℝ) = y + w := by
    rw [hyr, hwr]
    exact_mod_cast hB.symm
  have hn : (Fintype.card V : ℝ) + w = (A.card : ℝ) + (B.card : ℝ) := by
    rw [hwr]
    exact_mod_cast hU
  have hx1 : (1 : ℝ) ≤ x := by rw [hxr]; exact_mod_cast hx
  have hy1 : (1 : ℝ) ≤ y := by rw [hyr]; exact_mod_cast hy
  have hval : (Fintype.card V : ℝ) * w - (A.card : ℝ) * (B.card : ℝ) = -(x * y) := by
    have hn' : (Fintype.card V : ℝ) = x + y + w := by linarith
    rw [hn', hA', hB']
    ring
  rw [hval]
  have hxy : (1 : ℝ) ≤ x * y := by nlinarith
  have h0 : (-(x * y)) ^ 2 = (x * y) ^ 2 := by ring
  rw [h0]
  exact one_le_pow₀ hxy

/-- **The off-diagonal bound.** Sides of distinct edges of a connected graph have `tau ≥ 1`. -/
theorem one_le_tau_of_ne {G : SimpleGraph V} (hconn : G.Preconnected) {e f : Sym2 V}
    {A B : Finset V} (hA : IsSide G e A) (hB : IsSide G f B) (hef : e ≠ f)
    (heE : e ∈ G.edgeSet) (hfE : f ∈ G.edgeSet) : 1 ≤ tau A B := by
  obtain ⟨a, b, he, ha, hb⟩ := hA.1
  obtain ⟨u, v, hf, hu, hv⟩ := hB.1
  have hab : G.Adj a b := by rw [he] at heE; exact heE
  have huv : G.Adj u v := by rw [hf] at hfE; exact hfE
  have huvA : u ∈ A ↔ v ∈ A := hA.2 u v huv (by rw [← hf]; exact hef.symm)
  have habB : a ∈ B ↔ b ∈ B := hB.2 a b hab (by rw [← he]; exact hef)
  have core : ∀ {A' B' : Finset V}, IsSide G e A' → IsSide G f B' → ∀ {a' b' u' v' : V},
      e = s(a', b') → b' ∉ A' → a' ∈ B' → b' ∈ B' → f = s(u', v') → v' ∉ B' →
      u' ∈ A' → v' ∈ A' → 1 ≤ tau A' B' := by
    intro A' B' hA' hB' a' b' u' v' he' hb' haB hbB hf' hv' huA hvA
    refine one_le_tau_of_cover (cover hconn hA' hB' ?_ ?_) ⟨v', hvA, hv'⟩ ⟨b', hbB, hb'⟩
    · intro z hz
      rw [hf', Sym2.mem_iff] at hz
      rcases hz with rfl | rfl
      · exact huA
      · exact hvA
    · intro z hz
      rw [he', Sym2.mem_iff] at hz
      rcases hz with rfl | rfl
      · exact haB
      · exact hbB
  have heSwap : e = s(b, a) := by rw [he, Sym2.eq_swap]
  have hfSwap : f = s(v, u) := by rw [hf, Sym2.eq_swap]
  by_cases huA : u ∈ A
  · have hvA : v ∈ A := huvA.mp huA
    by_cases haB : a ∈ B
    · have hbB : b ∈ B := habB.mp haB
      exact core hA hB he hb haB hbB hf hv huA hvA
    · have hbB : b ∉ B := fun h => haB (habB.mpr h)
      have h := core hA hB.compl he hb (by simpa using haB) (by simpa using hbB)
        hfSwap (by simpa using hu) hvA huA
      rwa [tau_compl_right] at h
  · have hvA : v ∉ A := fun h => huA (huvA.mpr h)
    by_cases haB : a ∈ B
    · have hbB : b ∈ B := habB.mp haB
      have h := core hA.compl hB heSwap (by simpa using ha) hbB haB hf hv
        (by simpa using huA) (by simpa using hvA)
      rwa [tau_compl_left] at h
    · have hbB : b ∉ B := fun h => haB (habB.mpr h)
      have h := core hA.compl hB.compl heSwap (by simpa using ha) (by simpa using hbB)
        (by simpa using haB) hfSwap (by simpa using hu) (by simpa using hvA)
        (by simpa using huA)
      rwa [tau_compl_left, tau_compl_right] at h

/-- Side sizes: `1 ≤ |A| ≤ n - 1`. -/
theorem side_card_bounds {G : SimpleGraph V} {e : Sym2 V} {A : Finset V} (hA : IsSide G e A) :
    1 ≤ A.card ∧ A.card + 1 ≤ Fintype.card V := by
  obtain ⟨a, b, _, ha, hb⟩ := hA.1
  refine ⟨Finset.card_pos.mpr ⟨a, ha⟩, ?_⟩
  have h : A.card < Fintype.card V := by
    rw [← Finset.card_univ]
    refine Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_univ _, ?_⟩)
    intro h
    exact hb (h ▸ Finset.mem_univ b)
  exact h

theorem tau_self_eq (A : Finset V) :
    tau A A = ((A.card : ℝ) * ((Fintype.card V : ℝ) - (A.card : ℝ))) ^ 2 := by
  unfold tau
  rw [Finset.inter_self]
  ring

/-- The diagonal bound. -/
theorem le_tau_self {G : SimpleGraph V} {e : Sym2 V} {A : Finset V} (hA : IsSide G e A) :
    ((Fintype.card V : ℝ) - 1) ^ 2 ≤ tau A A := by
  obtain ⟨h1, h2⟩ := side_card_bounds hA
  rw [tau_self_eq]
  have ha : (1 : ℝ) ≤ (A.card : ℝ) := by exact_mod_cast h1
  have hb : (A.card : ℝ) + 1 ≤ (Fintype.card V : ℝ) := by exact_mod_cast h2
  have hprod : (Fintype.card V : ℝ) - 1 ≤ (A.card : ℝ) * ((Fintype.card V : ℝ) - (A.card : ℝ)) := by
    nlinarith [mul_nonneg (sub_nonneg.mpr ha) (sub_nonneg.mpr hb)]
  have hn0 : (0 : ℝ) ≤ (Fintype.card V : ℝ) - 1 := by linarith
  exact pow_le_pow_left₀ hn0 hprod 2

/-- The equality case of the diagonal bound: the side is a singleton or a co-singleton. -/
theorem card_side_of_tau_self_eq {G : SimpleGraph V} {e : Sym2 V} {A : Finset V}
    (hA : IsSide G e A) (h : tau A A = ((Fintype.card V : ℝ) - 1) ^ 2) :
    A.card = 1 ∨ A.card + 1 = Fintype.card V := by
  obtain ⟨h1, h2⟩ := side_card_bounds hA
  rw [tau_self_eq] at h
  have ha : (1 : ℝ) ≤ (A.card : ℝ) := by exact_mod_cast h1
  have hb : (A.card : ℝ) + 1 ≤ (Fintype.card V : ℝ) := by exact_mod_cast h2
  set a : ℝ := (A.card : ℝ) with hadef
  set n : ℝ := (Fintype.card V : ℝ) with hndef
  have hx : 0 ≤ a * (n - a) := mul_nonneg (by linarith) (by linarith)
  have hy : 0 < n - 1 := by linarith
  have hfac : (a * (n - a) - (n - 1)) * (a * (n - a) + (n - 1)) = 0 := by
    have : (a * (n - a) - (n - 1)) * (a * (n - a) + (n - 1))
        = (a * (n - a)) ^ 2 - (n - 1) ^ 2 := by ring
    rw [this, h]
    ring
  have hsum : a * (n - a) + (n - 1) ≠ 0 := by positivity
  have hzero : a * (n - a) - (n - 1) = 0 := by
    rcases mul_eq_zero.mp hfac with h' | h'
    · exact h'
    · exact absurd h' hsum
  have hzero' : (a - 1) * (n - a - 1) = 0 := by nlinarith
  rcases mul_eq_zero.mp hzero' with h' | h'
  · left
    have : a = 1 := by linarith
    rw [hadef] at this
    exact_mod_cast this
  · right
    have : a + 1 = n := by linarith
    rw [hadef, hndef] at this
    exact_mod_cast this

/-- The value `N(K_{1,n-1})`. -/
noncomputable def starN (n : ℝ) : ℝ := (n - 1) ^ 3 + (n - 1) * (n - 2)

/-- Abstract bookkeeping of the double sum. -/
theorem sum_ite_eq_aux {ι : Type*} [Fintype ι] [DecidableEq ι] (D : ℝ) :
    ∑ i : ι, ∑ j : ι, (if i = j then D else 1)
      = (Fintype.card ι : ℝ) * D + (Fintype.card ι : ℝ) * ((Fintype.card ι : ℝ) - 1) := by
  have h : ∀ i : ι, ∑ j : ι, (if i = j then D else 1) = D + ((Fintype.card ι : ℝ) - 1) := by
    intro i
    have hij : ∀ j : ι, (if i = j then D else 1) = 1 + (if i = j then D - 1 else 0) := by
      intro j
      split_ifs <;> ring
    rw [Finset.sum_congr rfl (fun j _ => hij j), Finset.sum_add_distrib,
      Finset.sum_ite_eq]
    simp [Finset.card_univ]
    ring
  rw [Finset.sum_congr rfl (fun i _ => h i), Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  ring

theorem sum_lower {ι : Type*} [Fintype ι] [DecidableEq ι] (F : ι → ι → ℝ) (D : ℝ)
    (h1 : ∀ i, D ≤ F i i) (h2 : ∀ i j, i ≠ j → 1 ≤ F i j) :
    (Fintype.card ι : ℝ) * D + (Fintype.card ι : ℝ) * ((Fintype.card ι : ℝ) - 1)
      ≤ ∑ i, ∑ j, F i j := by
  rw [← sum_ite_eq_aux]
  refine Finset.sum_le_sum (fun i _ => Finset.sum_le_sum (fun j _ => ?_))
  split_ifs with h
  · rw [← h]
    exact h1 i
  · exact h2 i j h

theorem sum_lower_eq {ι : Type*} [Fintype ι] [DecidableEq ι] (F : ι → ι → ℝ) (D : ℝ)
    (h1 : ∀ i, D ≤ F i i) (h2 : ∀ i j, i ≠ j → 1 ≤ F i j)
    (heq : ∑ i, ∑ j, F i j
      = (Fintype.card ι : ℝ) * D + (Fintype.card ι : ℝ) * ((Fintype.card ι : ℝ) - 1)) (i : ι) :
    F i i = D := by
  by_contra hne
  have hlt : D < F i i := lt_of_le_of_ne (h1 i) (Ne.symm hne)
  have hstrict : ∑ i : ι, ∑ j : ι, (if i = j then D else 1) < ∑ i, ∑ j, F i j := by
    refine Finset.sum_lt_sum (fun i' _ => Finset.sum_le_sum (fun j _ => ?_)) ⟨i, Finset.mem_univ _, ?_⟩
    · split_ifs with h
      · rw [← h]
        exact h1 i'
      · exact h2 i' j h
    · refine Finset.sum_lt_sum (fun j _ => ?_) ⟨i, Finset.mem_univ _, ?_⟩
      · split_ifs with h
        · rw [← h]
          exact h1 i
        · exact h2 i j h
      · simpa using hlt
  rw [sum_ite_eq_aux, heq] at hstrict
  exact lt_irrefl _ hstrict

/-- All edges are pendant. -/
def AllPendant (G : SimpleGraph V) : Prop :=
  ∀ e ∈ G.edgeSet, ∃ l, IsSide G e ({l} : Finset V)

theorem tau_singleton_self (l : V) :
    tau ({l} : Finset V) {l} = ((Fintype.card V : ℝ) - 1) ^ 2 := by
  simp [tau]

theorem tau_singleton_ne {l l' : V} (h : l ≠ l') : tau ({l} : Finset V) {l'} = 1 := by
  have h0 : ({l} : Finset V) ∩ {l'} = ∅ := by
    ext v
    simp only [Finset.mem_inter, Finset.mem_singleton, Finset.notMem_empty, iff_false, not_and]
    rintro rfl
    exact h
  unfold tau
  rw [h0]
  simp

theorem singleton_side_unique {G : SimpleGraph V} {e f : Sym2 V} {l : V}
    (he : IsSide G e {l}) (hf : IsSide G f {l}) (heE : e ∈ G.edgeSet) : e = f := by
  by_contra hne
  obtain ⟨a, b, hab, ha, hb⟩ := he.1
  rw [Finset.mem_singleton] at ha
  subst ha
  have hadj : G.Adj a b := by rw [hab] at heE; exact heE
  have h := (hf.2 a b hadj (by rw [← hab]; exact hne)).mp (Finset.mem_singleton_self a)
  exact hb h

section

variable {G : SimpleGraph V} [DecidableRel G.Adj] [Fintype G.edgeSet]

theorem card_edge_family (hG : G.IsTree) :
    (Fintype.card ↥G.edgeFinset : ℝ) = (Fintype.card V : ℝ) - 1 := by
  have h := hG.card_edgeFinset
  have h2 : Fintype.card ↥G.edgeFinset = G.edgeFinset.card := Fintype.card_coe G.edgeFinset
  have h' : (G.edgeFinset.card : ℝ) + 1 = (Fintype.card V : ℝ) := by exact_mod_cast h
  rw [h2]
  linarith

theorem edge_bij (e : Sym2 V) (he : e ∈ G.edgeSet) :
    ∃! i : ↥G.edgeFinset, (i : Sym2 V) = e :=
  ⟨⟨e, G.mem_edgeFinset.mpr he⟩, rfl, fun _ hy => Subtype.ext hy⟩

theorem starN_eq (hG : G.IsTree) :
    (Fintype.card ↥G.edgeFinset : ℝ) * ((Fintype.card V : ℝ) - 1) ^ 2
      + (Fintype.card ↥G.edgeFinset : ℝ) * ((Fintype.card ↥G.edgeFinset : ℝ) - 1)
      = starN (Fintype.card V : ℝ) := by
  rw [card_edge_family hG]
  unfold starN
  ring

/-- **The lower bound.** -/
theorem starN_div_le_bh (hG : G.IsTree) :
    starN (Fintype.card V : ℝ) / (Fintype.card V : ℝ) ≤ bh G := by
  classical
  haveI : Nonempty V := hG.connected.nonempty
  have hn : (0 : ℝ) < (Fintype.card V : ℝ) := by exact_mod_cast Fintype.card_pos
  have c := hG.coloringTwo
  rw [bh_eq_family hG (fun i : ↥G.edgeFinset => (i : Sym2 V))
    (fun i => G.mem_edgeFinset.mp i.2) edge_bij (cutFin c) (isSide_cutFin c hG)]
  refine div_le_div_of_nonneg_right ?_ (le_of_lt hn)
  rw [← starN_eq hG]
  refine sum_lower (fun i j => tau (cutFin c i) (cutFin c j)) _ ?_ ?_
  · intro i
    exact le_tau_self (isSide_cutFin c hG i)
  · intro i j hij
    exact one_le_tau_of_ne hG.connected.preconnected (isSide_cutFin c hG i)
      (isSide_cutFin c hG j) (fun h => hij (Subtype.ext h))
      (G.mem_edgeFinset.mp i.2) (G.mem_edgeFinset.mp j.2)

/-- **Lower equality**: if `bh G` attains the star value then every edge is pendant. -/
theorem allPendant_of_bh_eq (hG : G.IsTree)
    (h : bh G = starN (Fintype.card V : ℝ) / (Fintype.card V : ℝ)) : AllPendant G := by
  classical
  haveI : Nonempty V := hG.connected.nonempty
  have hn : (Fintype.card V : ℝ) ≠ 0 := by
    have : (0 : ℝ) < (Fintype.card V : ℝ) := by exact_mod_cast Fintype.card_pos
    exact this.ne'
  have c := hG.coloringTwo
  rw [bh_eq_family hG (fun i : ↥G.edgeFinset => (i : Sym2 V))
    (fun i => G.mem_edgeFinset.mp i.2) edge_bij (cutFin c) (isSide_cutFin c hG)] at h
  have hsum := (div_left_inj' hn).mp h
  have hdiag := sum_lower_eq (fun i j => tau (cutFin c i) (cutFin c j))
    (((Fintype.card V : ℝ) - 1) ^ 2) (fun i => le_tau_self (isSide_cutFin c hG i))
    (fun i j hij => one_le_tau_of_ne hG.connected.preconnected (isSide_cutFin c hG i)
      (isSide_cutFin c hG j) (fun h => hij (Subtype.ext h))
      (G.mem_edgeFinset.mp i.2) (G.mem_edgeFinset.mp j.2)) (by rw [hsum, starN_eq hG])
  intro e he
  have hside := isSide_cutFin c hG ⟨e, G.mem_edgeFinset.mpr he⟩
  have hd := hdiag ⟨e, G.mem_edgeFinset.mpr he⟩
  rcases card_side_of_tau_self_eq hside hd with h1 | h1
  · obtain ⟨l, hl⟩ := Finset.card_eq_one.mp h1
    exact ⟨l, hl ▸ hside⟩
  · have hc : (cutFin c ⟨e, G.mem_edgeFinset.mpr he⟩)ᶜ.card = 1 := by
      have := Finset.card_add_card_compl (cutFin c ⟨e, G.mem_edgeFinset.mpr he⟩)
      omega
    obtain ⟨l, hl⟩ := Finset.card_eq_one.mp hc
    exact ⟨l, hl ▸ hside.compl⟩

/-- A tree whose edges are all pendant has the star value. -/
theorem bh_eq_starN_of_allPendant (hG : G.IsTree) (hp : AllPendant G) :
    bh G = starN (Fintype.card V : ℝ) / (Fintype.card V : ℝ) := by
  classical
  haveI : Nonempty V := hG.connected.nonempty
  choose! l hl using hp
  rw [bh_eq_family hG (fun i : ↥G.edgeFinset => (i : Sym2 V))
    (fun i => G.mem_edgeFinset.mp i.2) edge_bij
    (fun i : ↥G.edgeFinset => ({l (i : Sym2 V)} : Finset V))
    (fun i => hl _ (G.mem_edgeFinset.mp i.2))]
  congr 1
  rw [← starN_eq hG, ← sum_ite_eq_aux]
  refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
  split_ifs with hij
  · rw [← hij]
    exact tau_singleton_self _
  · apply tau_singleton_ne
    intro h0
    apply hij
    have hi := hl _ (G.mem_edgeFinset.mp i.2)
    have hj := hl _ (G.mem_edgeFinset.mp j.2)
    rw [← h0] at hj
    exact Subtype.ext (singleton_side_unique hi hj (G.mem_edgeFinset.mp i.2))

end

end BiH
