/-
BiHShiftA: the chain-prefix sets, the shifted graph, and the edge bijections of the shift.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHChain
import BiHArith

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- The first `m` chain vertices. -/
def chainL (x : ℕ → V) (m : ℕ) : Finset V := (Finset.range m).image x

theorem mem_chainL {x : ℕ → V} {m : ℕ} {v : V} : v ∈ chainL x m ↔ ∃ i < m, x i = v := by
  simp [chainL]

theorem chainL_mono (x : ℕ → V) {a b : ℕ} (h : a ≤ b) : chainL x a ⊆ chainL x b := by
  intro v hv
  obtain ⟨i, hi, rfl⟩ := mem_chainL.mp hv
  exact mem_chainL.mpr ⟨i, by omega, rfl⟩

theorem card_chainL {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} (h : PChain G k x) {m : ℕ}
    (hm : m ≤ k + 1) : (chainL x m).card = m := by
  unfold chainL
  rw [Finset.card_image_of_injOn, Finset.card_range]
  intro i hi j hj hij
  have hi' := Finset.mem_range.mp (Finset.mem_coe.mp hi)
  have hj' := Finset.mem_range.mp (Finset.mem_coe.mp hj)
  exact h.inj i (by omega) j (by omega) hij

/-- The data of a shift: a pendant chain ending at a vertex with two further neighbours. -/
structure ShiftData (G : SimpleGraph V) (k : ℕ) (x : ℕ → V) (c b : V) : Prop where
  chain : PChain G k x
  hk : 1 ≤ k
  hc : G.Adj (x k) c
  hb : G.Adj (x k) b
  hcb : c ≠ b
  hc1 : c ≠ x (k - 1)
  hb1 : b ≠ x (k - 1)

/-- The shifted graph `G - wc + yc`. -/
def shiftG (G : SimpleGraph V) (w c y : V) : SimpleGraph V :=
  SimpleGraph.fromEdgeSet ((G.edgeSet \ {s(w, c)}) ∪ {s(y, c)})

theorem shiftG_adj {G : SimpleGraph V} {w c y u v : V} (hyc : y ≠ c) :
    (shiftG G w c y).Adj u v ↔ (G.Adj u v ∧ s(u, v) ≠ s(w, c)) ∨ s(u, v) = s(y, c) := by
  unfold shiftG
  rw [SimpleGraph.fromEdgeSet_adj]
  simp only [Set.mem_union, Set.mem_sdiff, SimpleGraph.mem_edgeSet, Set.mem_singleton_iff]
  constructor
  · rintro ⟨h | h, _⟩
    · exact Or.inl ⟨h.1, h.2⟩
    · exact Or.inr h
  · rintro (⟨h, h'⟩ | h)
    · exact ⟨Or.inl ⟨h, h'⟩, h.ne⟩
    · refine ⟨Or.inr h, ?_⟩
      intro huv
      rw [huv, Sym2.eq_iff] at h
      rcases h with ⟨h1, h2⟩ | ⟨h1, h2⟩
      · exact hyc (h1.symm.trans h2)
      · exact hyc (h2.symm.trans h1)

/-- Edges of `G` off the chain. -/
abbrev Rest (G : SimpleGraph V) (k : ℕ) (x : ℕ → V) :=
  {e : Sym2 V // e ∈ G.edgeSet ∧ ∀ i < k, e ≠ s(x i, x (i + 1))}

noncomputable instance instFintypeRest (G : SimpleGraph V) (k : ℕ) (x : ℕ → V) :
    Fintype (Rest G k x) := Fintype.ofFinite _

/-- Edge indexing of `G`. -/
def eps0 (G : SimpleGraph V) (k : ℕ) (x : ℕ → V) : Fin k ⊕ Rest G k x → Sym2 V :=
  Sum.elim (fun i => s(x i, x (i.val + 1))) (fun r => r.1)

/-- Edge indexing of the shifted graph. -/
def eps1 (G : SimpleGraph V) (k : ℕ) (x : ℕ → V) (w c y : V) : Fin k ⊕ Rest G k x → Sym2 V :=
  Sum.elim (fun i => s(x i, x (i.val + 1)))
    (fun r => if r.1 = s(w, c) then s(y, c) else r.1)

namespace ShiftData

variable {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} {c b : V}

theorem ne_chain (d : ShiftData G k x c b) {u : V} (hu : G.Adj (x k) u) (hu1 : u ≠ x (k - 1))
    {i : ℕ} (hi : i ≤ k) : x i ≠ u := by
  intro h
  rcases Nat.lt_or_ge i k with hlt | hge
  · have hadj : G.Adj (x i) (x k) := by
      rw [h]
      exact hu.symm
    rcases d.chain.nbr i hlt (x k) hadj with h1 | ⟨j, hj, h1⟩
    · have hk' : k = i + 1 := d.chain.inj k le_rfl (i + 1) hlt h1
      apply hu1
      rw [← h]
      congr 1
      omega
    · have hk' : k = j := d.chain.inj k le_rfl j (by omega) h1
      omega
  · have hik : i = k := le_antisymm hi hge
    rw [hik] at h
    exact hu.ne h

theorem chain_edge_ne (d : ShiftData G k x c b) {i : ℕ} (hi : i < k) :
    s(x i, x (i + 1)) ≠ s(x k, c) := by
  intro h
  rw [Sym2.eq_iff] at h
  rcases h with ⟨h1, _⟩ | ⟨h1, h2⟩
  · have := d.chain.inj i (by omega) k le_rfl h1
    omega
  · have hk' : i + 1 = k := d.chain.inj (i + 1) hi k le_rfl h2
    apply d.hc1
    rw [← h1]
    congr 1
    omega

theorem y_ne_c (d : ShiftData G k x c b) : x 0 ≠ c :=
  d.ne_chain d.hc d.hc1 (Nat.zero_le k)

theorem not_adj_y_c (d : ShiftData G k x c b) : ¬ G.Adj (x 0) c := by
  intro h
  rcases d.chain.nbr 0 (by have := d.hk; omega) c h with h1 | ⟨j, hj, _⟩
  · exact d.ne_chain d.hc d.hc1 d.hk h1.symm
  · omega

theorem not_edge_y_c (d : ShiftData G k x c b) : s(x 0, c) ∉ G.edgeSet := d.not_adj_y_c

theorem chain_edge_inj (hc : PChain G k x) {i j : ℕ} (hi : i < k) (hj : j < k)
    (h : s(x i, x (i + 1)) = s(x j, x (j + 1))) : i = j := by
  rw [Sym2.eq_iff] at h
  rcases h with ⟨h1, _⟩ | ⟨h1, h2⟩
  · exact hc.inj i (by omega) j (by omega) h1
  · have h3 := hc.inj i (by omega) (j + 1) hj h1
    have h4 := hc.inj (i + 1) hi j (by omega) h2
    omega

theorem eps0_mem (d : ShiftData G k x c b) (p : Fin k ⊕ Rest G k x) :
    eps0 G k x p ∈ G.edgeSet := by
  rcases p with i | r
  · exact d.chain.adj i i.2
  · exact r.2.1

theorem eps0_bij (d : ShiftData G k x c b) (e : Sym2 V) (he : e ∈ G.edgeSet) :
    ∃! p : Fin k ⊕ Rest G k x, eps0 G k x p = e := by
  by_cases hch : ∃ i, i < k ∧ e = s(x i, x (i + 1))
  · obtain ⟨i, hi, rfl⟩ := hch
    refine ⟨Sum.inl ⟨i, hi⟩, rfl, ?_⟩
    rintro (⟨j, hj⟩ | r) h
    · have : j = i := chain_edge_inj d.chain hj hi h
      subst this
      rfl
    · exact absurd h (r.2.2 i hi)
  · have hrest : ∀ i < k, e ≠ s(x i, x (i + 1)) := fun i hi h => hch ⟨i, hi, h⟩
    refine ⟨Sum.inr ⟨e, he, hrest⟩, rfl, ?_⟩
    rintro (⟨j, hj⟩ | r) h
    · exact absurd h.symm (hrest j hj)
    · exact congrArg Sum.inr (Subtype.ext h)

theorem eps1_mem (d : ShiftData G k x c b) (p : Fin k ⊕ Rest G k x) :
    eps1 G k x (x k) c (x 0) p ∈ (shiftG G (x k) c (x 0)).edgeSet := by
  rcases p with i | r
  · change (shiftG G (x k) c (x 0)).Adj (x i) (x (i.val + 1))
    rw [shiftG_adj d.y_ne_c]
    exact Or.inl ⟨d.chain.adj i i.2, d.chain_edge_ne i.2⟩
  · simp only [eps1, Sum.elim_inr]
    split_ifs with h
    · change (shiftG G (x k) c (x 0)).Adj (x 0) c
      rw [shiftG_adj d.y_ne_c]
      exact Or.inr rfl
    · obtain ⟨a, b', ha⟩ := exists_pair r.1
      rw [ha]
      change (shiftG G (x k) c (x 0)).Adj a b'
      rw [shiftG_adj d.y_ne_c]
      left
      constructor
      · have hmem := r.2.1
        rw [ha] at hmem
        exact hmem
      · rw [← ha]
        exact h

theorem eps1_bij (d : ShiftData G k x c b) (e : Sym2 V)
    (he : e ∈ (shiftG G (x k) c (x 0)).edgeSet) :
    ∃! p : Fin k ⊕ Rest G k x, eps1 G k x (x k) c (x 0) p = e := by
  obtain ⟨u, v, rfl⟩ := exists_pair e
  have huv : (shiftG G (x k) c (x 0)).Adj u v := he
  rw [shiftG_adj d.y_ne_c] at huv
  rcases huv with ⟨h1, h2⟩ | h1
  · have he' : s(u, v) ∈ G.edgeSet := h1
    by_cases hch : ∃ i, i < k ∧ s(u, v) = s(x i, x (i + 1))
    · obtain ⟨i, hi, hie⟩ := hch
      refine ⟨Sum.inl ⟨i, hi⟩, hie.symm, ?_⟩
      rintro (⟨j, hj⟩ | r) h
      · have h3 : s(x j, x (j + 1)) = s(x i, x (i + 1)) := h.trans hie
        have : j = i := chain_edge_inj d.chain hj hi h3
        subst this
        rfl
      · simp only [eps1, Sum.elim_inr] at h
        split_ifs at h with h4
        · exact absurd (h ▸ he') d.not_edge_y_c
        · exact absurd (h.trans hie) (r.2.2 i hi)
    · have hrest : ∀ i < k, s(u, v) ≠ s(x i, x (i + 1)) := fun i hi h => hch ⟨i, hi, h⟩
      refine ⟨Sum.inr ⟨s(u, v), he', hrest⟩, ?_, ?_⟩
      · simp only [eps1, Sum.elim_inr]
        exact ite_eq_right h2
      · rintro (⟨j, hj⟩ | r) h
        · exact absurd h.symm (hrest j hj)
        · simp only [eps1, Sum.elim_inr] at h
          split_ifs at h with h4
          · exact absurd (h ▸ he') d.not_edge_y_c
          · exact congrArg Sum.inr (Subtype.ext h)
  · let r0 : Rest G k x := ⟨s(x k, c), d.hc, fun i hi h => d.chain_edge_ne hi h.symm⟩
    refine ⟨Sum.inr r0, ?_, ?_⟩
    · show (if (s(x k, c) : Sym2 V) = s(x k, c) then s(x 0, c) else s(x k, c)) = s(u, v)
      rw [ite_eq_left rfl]
      exact h1.symm
    · rintro (⟨j, hj⟩ | r) h
      · have h3 : s(x j, x (j + 1)) = s(x 0, c) := h.trans h1
        have hmem : s(x j, x (j + 1)) ∈ G.edgeSet := d.chain.adj j hj
        exact absurd (h3 ▸ hmem) d.not_edge_y_c
      · simp only [eps1, Sum.elim_inr] at h
        split_ifs at h with h4
        · exact congrArg Sum.inr (Subtype.ext h4)
        · exact absurd ((h.trans h1) ▸ r.2.1) d.not_edge_y_c

end ShiftData

end BiH
