/-
BiHIso: isomorphism invariance of `bh` for trees, the star value, and the characterisation of
trees with every edge pendant as the star.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHOffDiag
import Mathlib.Combinatorics.SimpleGraph.Star

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V] {W : Type*} [Fintype W] [DecidableEq W]

theorem IsSide.map {G : SimpleGraph V} {H : SimpleGraph W} (φ : G ≃g H) {e : Sym2 V}
    {A : Finset V} (h : IsSide G e A) :
    IsSide H (e.map φ) (A.map φ.toEquiv.toEmbedding) := by
  obtain ⟨⟨a, b, he, ha, hb⟩, h2⟩ := h
  refine ⟨⟨φ a, φ b, by rw [he]; rfl, ?_, ?_⟩, ?_⟩
  · rw [Finset.mem_map_equiv]
    show φ.toEquiv.symm (φ.toEquiv a) ∈ A
    rw [Equiv.symm_apply_apply]
    exact ha
  · rw [Finset.mem_map_equiv]
    show φ.toEquiv.symm (φ.toEquiv b) ∉ A
    rw [Equiv.symm_apply_apply]
    exact hb
  · intro u v huv hne
    rw [Finset.mem_map_equiv, Finset.mem_map_equiv]
    refine h2 _ _ ((φ.symm.map_adj_iff).mpr huv) ?_
    intro h
    apply hne
    have h3 : (s(φ.symm u, φ.symm v) : Sym2 V).map φ = s(u, v) := by
      simp [Sym2.map_mk]
    rw [← h3]
    exact congrArg _ h

theorem tau_map (φ : V ≃ W) (A B : Finset V) :
    tau (A.map φ.toEmbedding) (B.map φ.toEmbedding) = tau A B := by
  unfold tau
  rw [← Finset.map_inter, Finset.card_map, Finset.card_map, Finset.card_map,
    Fintype.card_congr φ]

/-- **Isomorphism invariance** of the biharmonic index for trees. -/
theorem bh_congr_iso {G : SimpleGraph V} [DecidableRel G.Adj] {H : SimpleGraph W}
    [DecidableRel H.Adj] (hG : G.IsTree) (φ : G ≃g H) : bh G = bh H := by
  classical
  have hH : H.IsTree := (φ.isTree_iff).mp hG
  have c := hG.coloringTwo
  have hcard : Fintype.card V = Fintype.card W := Fintype.card_congr φ.toEquiv
  have hmem : ∀ i : ↥G.edgeFinset, (i : Sym2 V).map φ ∈ H.edgeSet := by
    intro i
    have hi := G.mem_edgeFinset.mp i.2
    obtain ⟨a, b, hab⟩ := exists_pair (i : Sym2 V)
    rw [hab] at hi ⊢
    exact (φ.map_adj_iff).mpr hi
  have hbij : ∀ e ∈ H.edgeSet, ∃! i : ↥G.edgeFinset, (i : Sym2 V).map φ = e := by
    intro e he
    obtain ⟨u, v, rfl⟩ := exists_pair e
    have huv : H.Adj u v := he
    have hG' : G.Adj (φ.symm u) (φ.symm v) := (φ.symm.map_adj_iff).mpr huv
    refine ⟨⟨s(φ.symm u, φ.symm v), G.mem_edgeFinset.mpr hG'⟩, ?_, ?_⟩
    · simp [Sym2.map_mk]
    · intro y hy
      apply Subtype.ext
      apply Sym2.map.injective φ.injective
      rw [hy]
      simp [Sym2.map_mk]
  rw [bh_eq_family hG (fun i : ↥G.edgeFinset => (i : Sym2 V))
    (fun i => G.mem_edgeFinset.mp i.2) edge_bij (cutFin c) (isSide_cutFin c hG)]
  rw [bh_eq_family hH (fun i : ↥G.edgeFinset => (i : Sym2 V).map φ) hmem hbij
    (fun i => (cutFin c i).map φ.toEquiv.toEmbedding)
    (fun i => (isSide_cutFin c hG i).map φ)]
  have hcardR : (Fintype.card V : ℝ) = (Fintype.card W : ℝ) := by exact_mod_cast hcard
  rw [hcardR]
  congr 1
  refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
  exact (tau_map φ.toEquiv _ _).symm

theorem isSide_star_leaf (r y : V) (h : r ≠ y) :
    IsSide (SimpleGraph.starGraph r) s(r, y) ({y} : Finset V) := by
  refine ⟨⟨y, r, by rw [Sym2.eq_swap], Finset.mem_singleton_self y,
    by simpa [Finset.mem_singleton] using h⟩, ?_⟩
  intro u v huv hne
  rw [SimpleGraph.starGraph_adj] at huv
  obtain ⟨huv1, huv2⟩ := huv
  simp only [Finset.mem_singleton]
  constructor
  · intro hu
    subst hu
    rcases huv2 with h1 | h1
    · exact absurd h1.symm h
    · exact absurd (by rw [h1, Sym2.eq_swap]) hne
  · intro hv
    subst hv
    rcases huv2 with h1 | h1
    · exact absurd (by rw [h1]) hne
    · exact absurd h1.symm h

theorem allPendant_starGraph (r : V) : AllPendant (SimpleGraph.starGraph r) := by
  intro e he
  obtain ⟨x, y, rfl⟩ := exists_pair e
  have hadj : (SimpleGraph.starGraph r).Adj x y := he
  rw [SimpleGraph.starGraph_adj] at hadj
  obtain ⟨hxy, hr⟩ := hadj
  rcases hr with h | h
  · subst h
    exact ⟨y, isSide_star_leaf x y hxy⟩
  · subst h
    refine ⟨x, ?_⟩
    rw [Sym2.eq_swap]
    exact isSide_star_leaf y x (Ne.symm hxy)

theorem pendant_end {G : SimpleGraph V} {x y l : V} (h : IsSide G s(x, y) ({l} : Finset V)) :
    l = x ∨ l = y := by
  obtain ⟨a, b, hp, ha, _⟩ := h.1
  rw [Finset.mem_singleton] at ha
  subst ha
  rw [Sym2.eq_iff] at hp
  rcases hp with ⟨h1, _⟩ | ⟨_, h1⟩
  · exact Or.inl h1.symm
  · exact Or.inr h1.symm

theorem leaf_only {G : SimpleGraph V} {a b z : V} (h : IsSide G s(a, b) ({a} : Finset V))
    (hz : G.Adj a z) : z = b := by
  by_contra hzb
  have hne : s(a, z) ≠ s(a, b) := fun h' => hzb (Sym2.congr_right.mp h')
  have := (h.2 a z hz hne).mp (Finset.mem_singleton_self a)
  rw [Finset.mem_singleton] at this
  exact hz.ne this.symm

/-- A tree on `n ≥ 2` vertices with every edge pendant is isomorphic to the star. -/
theorem iso_star_of_allPendant {n : ℕ} (hV : Fintype.card V = n) (hn0 : 0 < n) (hn : 2 ≤ n)
    {G : SimpleGraph V} (hG : G.IsTree) (hp : AllPendant G) :
    Nonempty (G ≃g starGraphFin n hn0) := by
  classical
  have hnt : Nontrivial V := Fintype.one_lt_card_iff_nontrivial.mp (by omega)
  obtain ⟨x0, y0, hxy⟩ := exists_pair_ne V
  obtain ⟨a, b, hab, ha⟩ : ∃ a b, G.Adj a b ∧ IsSide G s(a, b) ({a} : Finset V) := by
    obtain ⟨p⟩ := hG.connected.preconnected x0 y0
    cases p with
    | nil => exact absurd rfl hxy
    | @cons _ v _ h _ =>
      obtain ⟨l, hl⟩ := hp s(x0, v) h
      rcases pendant_end hl with rfl | rfl
      · exact ⟨_, _, h, hl⟩
      · refine ⟨_, _, h.symm, ?_⟩
        rw [Sym2.eq_swap]
        exact hl
  have claim1 : ∀ x y, G.Adj b x → G.Adj x y → y = b := by
    intro x y hbx hxy'
    by_contra hyb
    have not_side1 : ¬ IsSide G s(b, x) ({x} : Finset V) := by
      intro h
      have hne : s(x, y) ≠ s(b, x) := by
        intro h'
        rw [Sym2.eq_iff] at h'
        rcases h' with ⟨h1, _⟩ | ⟨_, h2⟩
        · exact hbx.ne h1.symm
        · exact hyb h2
      have := (h.2 x y hxy' hne).mp (Finset.mem_singleton_self x)
      rw [Finset.mem_singleton] at this
      exact hxy'.ne this.symm
    obtain ⟨l2, hl2⟩ := hp s(b, x) hbx
    have hl2b : l2 = b := by
      rcases pendant_end hl2 with h | h
      · exact h
      · subst h
        exact absurd hl2 not_side1
    subst hl2b
    have hax : a = x := leaf_only hl2 hab.symm
    subst hax
    apply not_side1
    rw [Sym2.eq_swap]
    exact ha
  have hclosed : ∀ v, v = b ∨ G.Adj b v := by
    intro v
    obtain ⟨p⟩ := hG.connected.preconnected b v
    refine walk_prop (P := fun z => z = b ∨ G.Adj b z) ?_ p (Or.inl rfl)
    intro u v' huv hu
    rcases hu with rfl | hu
    · exact Or.inr huv
    · exact Or.inl (claim1 u v' hu huv)
  have hadj_iff : ∀ u v, G.Adj u v ↔ u ≠ v ∧ (u = b ∨ v = b) := by
    intro u v
    constructor
    · intro h
      refine ⟨h.ne, ?_⟩
      rcases hclosed u with h1 | h1
      · exact Or.inl h1
      · exact Or.inr (claim1 u v h1 h)
    · rintro ⟨hne, h1 | h1⟩
      · subst h1
        rcases hclosed v with h2 | h2
        · exact absurd h2.symm hne
        · exact h2
      · subst h1
        rcases hclosed u with h2 | h2
        · exact absurd h2 hne
        · exact h2.symm
  let e0 : V ≃ Fin n := Fintype.equivFinOfCardEq hV
  let e : V ≃ Fin n := e0.trans (Equiv.swap (e0 b) ⟨0, hn0⟩)
  have heb : e b = ⟨0, hn0⟩ := by simp [e]
  have he0 : ∀ u, e u = ⟨0, hn0⟩ ↔ u = b := by
    intro u
    constructor
    · intro h
      exact e.injective (h.trans heb.symm)
    · rintro rfl
      exact heb
  refine ⟨{ toEquiv := e, map_rel_iff' := ?_ }⟩
  intro u v
  show (SimpleGraph.starGraph (⟨0, hn0⟩ : Fin n)).Adj (e u) (e v) ↔ G.Adj u v
  rw [SimpleGraph.starGraph_adj, hadj_iff, he0, he0]
  simp only [ne_eq, EmbeddingLike.apply_eq_iff_eq]

end BiH
