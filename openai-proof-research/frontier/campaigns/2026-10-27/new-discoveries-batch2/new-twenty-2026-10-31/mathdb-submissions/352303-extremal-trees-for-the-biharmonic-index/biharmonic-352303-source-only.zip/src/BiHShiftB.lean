/-
BiHShiftB: the pendant-path shift strictly increases the biharmonic index.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHShiftA
import Mathlib.Combinatorics.SimpleGraph.Acyclic

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false
set_option linter.unusedVariables false

variable {V : Type*} [Fintype V] [DecidableEq V]

theorem exists_side_avoid {G : SimpleGraph V} (hG : G.IsTree) {e : Sym2 V}
    (he : e ∈ G.edgeSet) (w : V) : ∃ A, IsSide G e A ∧ w ∉ A := by
  classical
  have c := hG.coloringTwo
  have hS := isSide_cutFin c hG ⟨e, G.mem_edgeFinset.mpr he⟩
  by_cases hw : w ∈ cutFin c ⟨e, G.mem_edgeFinset.mpr he⟩
  · exact ⟨_, hS.compl, by simpa using hw⟩
  · exact ⟨_, hS, hw⟩

theorem chain_notMem {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} (hc : PChain G k x) {e : Sym2 V}
    {A : Finset V} (hA : IsSide G e A) (hne : ∀ i < k, s(x i, x (i + 1)) ≠ e)
    (hw : x k ∉ A) {i : ℕ} (hi : i ≤ k) : x i ∉ A := by
  have key : ∀ d, d ≤ k → x (k - d) ∉ A := by
    intro d
    induction d with
    | zero => simpa using hw
    | succ d ih =>
      intro hd
      have hi' : k - (d + 1) < k := by omega
      have h1 := hA.2 _ _ (hc.adj _ hi') (hne _ hi')
      have e1 : k - (d + 1) + 1 = k - d := by omega
      rw [e1] at h1
      intro h
      exact ih (by omega) (h1.mp h)
  have h := key (k - i) (by omega)
  rwa [Nat.sub_sub_self hi] at h

theorem chainL_side {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} (hc : PChain G k x) {i : ℕ}
    (hi : i < k) : IsSide G s(x i, x (i + 1)) (chainL x (i + 1)) := by
  have helper : ∀ u v, G.Adj u v → s(u, v) ≠ s(x i, x (i + 1)) → u ∈ chainL x (i + 1) →
      v ∈ chainL x (i + 1) := by
    intro u v huv hne hu
    obtain ⟨j, hj, rfl⟩ := mem_chainL.mp hu
    rcases hc.nbr j (by omega) v huv with h1 | ⟨j', hj', h1⟩
    · rcases Nat.lt_or_ge (j + 1) (i + 1) with hlt | hge
      · exact mem_chainL.mpr ⟨j + 1, hlt, h1.symm⟩
      · have hji : j = i := by omega
        subst hji
        exact absurd (by rw [h1]) hne
    · exact mem_chainL.mpr ⟨j', by omega, h1.symm⟩
  refine ⟨⟨x i, x (i + 1), rfl, mem_chainL.mpr ⟨i, by omega, rfl⟩, ?_⟩, ?_⟩
  · intro h
    obtain ⟨j, hj, hje⟩ := mem_chainL.mp h
    have := hc.inj j (by omega) (i + 1) hi hje
    omega
  · intro u v huv hne
    constructor
    · exact helper u v huv hne
    · exact helper v u huv.symm (by rw [Sym2.eq_swap]; exact hne)

theorem tau_chainL {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} (hc : PChain G k x) {a b : ℕ}
    (ha : a ≤ k + 1) (hb : b ≤ k + 1) :
    tau (chainL x a) (chainL x b)
      = ((Fintype.card V : ℝ) * ((min a b : ℕ) : ℝ) - (a : ℝ) * (b : ℝ)) ^ 2 := by
  have hinter : chainL x a ∩ chainL x b = chainL x (min a b) := by
    rcases le_total a b with h | h
    · rw [min_eq_left h]
      exact Finset.inter_eq_left.mpr (chainL_mono x h)
    · rw [min_eq_right h]
      exact Finset.inter_eq_right.mpr (chainL_mono x h)
  unfold tau
  rw [hinter, card_chainL hc ha, card_chainL hc hb, card_chainL hc (min_le_of_left_le ha)]

theorem tau_chainLQ {G : SimpleGraph V} {k : ℕ} {x : ℕ → V} (hc : PChain G k x) {Q : Finset V}
    (hQ : ∀ i ≤ k, x i ∉ Q) {a b : ℕ} (ha : a ≤ k + 1) (hb : b ≤ k + 1) :
    tau (chainL x a ∪ Q) (chainL x b ∪ Q)
      = ((Fintype.card V : ℝ) * (((min a b : ℕ) : ℝ) + (Q.card : ℝ))
          - ((a : ℝ) + (Q.card : ℝ)) * ((b : ℝ) + (Q.card : ℝ))) ^ 2 := by
  have hdis : ∀ c ≤ k + 1, Disjoint (chainL x c) Q := by
    intro c hc'
    rw [Finset.disjoint_left]
    intro v hv
    obtain ⟨i, hi, rfl⟩ := mem_chainL.mp hv
    exact hQ i (by omega)
  have hinter : (chainL x a ∪ Q) ∩ (chainL x b ∪ Q) = chainL x (min a b) ∪ Q := by
    have h0 : chainL x a ∩ chainL x b = chainL x (min a b) := by
      rcases le_total a b with h | h
      · rw [min_eq_left h]
        exact Finset.inter_eq_left.mpr (chainL_mono x h)
      · rw [min_eq_right h]
        exact Finset.inter_eq_right.mpr (chainL_mono x h)
    rw [← h0]
    ext v
    simp only [Finset.mem_inter, Finset.mem_union]
    tauto
  have hc1 : ∀ c ≤ k + 1, (chainL x c ∪ Q).card = c + Q.card := by
    intro c hc'
    rw [Finset.card_union_of_disjoint (hdis c hc'), card_chainL hc hc']
  unfold tau
  rw [hinter, hc1 a ha, hc1 b hb, hc1 _ (min_le_of_left_le ha)]
  push_cast
  ring

theorem tau_rest_disj {L Q A : Finset V} (hLA : Disjoint L A) (hAQ : Disjoint A Q)
    (hLQ : Disjoint L Q) :
    tau (L ∪ Q) A - tau L A
      = (((L.card : ℝ) + (Q.card : ℝ)) * (A.card : ℝ)) ^ 2 - ((L.card : ℝ) * (A.card : ℝ)) ^ 2 := by
  have h1 : (L ∪ Q) ∩ A = ∅ := by
    rw [← Finset.disjoint_iff_inter_eq_empty]
    exact Finset.disjoint_union_left.mpr ⟨hLA, hAQ.symm⟩
  have h2 : L ∩ A = ∅ := Finset.disjoint_iff_inter_eq_empty.mp hLA
  unfold tau
  rw [h1, h2, Finset.card_union_of_disjoint hLQ]
  simp only [Finset.card_empty, Nat.cast_zero, mul_zero, zero_sub]
  push_cast
  ring

theorem tau_rest_sub {L Q A : Finset V} (hLA : Disjoint L A) (hsub : A ⊆ Q) (hLQ : Disjoint L Q) :
    tau (L ∪ Q) A - tau L A
      = (((Fintype.card V : ℝ) - (L.card : ℝ) - (Q.card : ℝ)) * (A.card : ℝ)) ^ 2
        - ((L.card : ℝ) * (A.card : ℝ)) ^ 2 := by
  have h1 : (L ∪ Q) ∩ A = A :=
    Finset.inter_eq_right.mpr (hsub.trans Finset.subset_union_right)
  have h2 : L ∩ A = ∅ := Finset.disjoint_iff_inter_eq_empty.mp hLA
  unfold tau
  rw [h1, h2, Finset.card_union_of_disjoint hLQ]
  simp only [Finset.card_empty, Nat.cast_zero, mul_zero, zero_sub]
  push_cast
  ring

theorem nat_card_family {H : SimpleGraph V} {ι : Type*} (ε : ι → Sym2 V)
    (hmem : ∀ i, ε i ∈ H.edgeSet) (hbij : ∀ e ∈ H.edgeSet, ∃! i, ε i = e) :
    Nat.card ι = Nat.card H.edgeSet := by
  let f : ι → H.edgeSet := fun i => ⟨ε i, hmem i⟩
  have hf : Function.Bijective f := by
    constructor
    · intro i j h
      exact ExistsUnique.unique (hbij _ (hmem j)) (congrArg Subtype.val h) rfl
    · rintro ⟨e, he⟩
      obtain ⟨i, hi, _⟩ := hbij e he
      exact ⟨i, Subtype.ext hi⟩
  exact Nat.card_congr (Equiv.ofBijective f hf)

/-- The shift gives a tree of strictly larger biharmonic index. -/
theorem shift_increases {G : SimpleGraph V} [DecidableRel G.Adj] (hG : G.IsTree) {k : ℕ}
    {x : ℕ → V} {c b : V} (d : ShiftData G k x c b) :
    ∃ G' : SimpleGraph V, G'.IsTree ∧ ∃ _ : DecidableRel G'.Adj, bh G < bh G' := by
  classical
  set G' := shiftG G (x k) c (x 0) with hG'
  have hyc := d.y_ne_c
  have hadj' : ∀ u v, G'.Adj u v ↔ (G.Adj u v ∧ s(u, v) ≠ s(x k, c)) ∨ s(u, v) = s(x 0, c) :=
    fun u v => shiftG_adj hyc
  have hex : ∀ r : Rest G k x, ∃ A, IsSide G r.1 A ∧ x k ∉ A :=
    fun r => exists_side_avoid hG r.2.1 (x k)
  choose A hA hAw using hex
  have hAside : ∀ r : Rest G k x, IsSide G r.1 (A r) := hA
  let r0 : Rest G k x := ⟨s(x k, c), d.hc, fun i hi h => d.chain_edge_ne hi h.symm⟩
  obtain ⟨Q, hQdef⟩ : ∃ Q, Q = A r0 := ⟨_, rfl⟩
  have hQ : IsSide G s(x k, c) Q := by rw [hQdef]; exact hA r0
  have hQw : x k ∉ Q := by rw [hQdef]; exact hAw r0
  have hQchain : ∀ i ≤ k, x i ∉ Q :=
    fun i hi => chain_notMem d.chain hQ (fun j hj => d.chain_edge_ne hj) hQw hi
  have hcQ : c ∈ Q := by
    obtain ⟨a, b', h, ha, _⟩ := hQ.1
    rw [Sym2.eq_iff] at h
    rcases h with ⟨h1, _⟩ | ⟨_, h2⟩
    · rw [← h1] at ha
      exact absurd ha hQw
    · rw [← h2] at ha
      exact ha
  have hAchain : ∀ (r : Rest G k x) (i : ℕ), i ≤ k → x i ∉ A r :=
    fun r i hi => chain_notMem d.chain (hA r) (fun j hj h => r.2.2 j hj h.symm) (hAw r) hi
  have hcA : ∀ r : Rest G k x, (r.1 : Sym2 V) ≠ s(x k, c) → c ∉ A r := by
    intro r hne h
    exact hAw r (((hA r).2 (x k) c d.hc (fun h' => hne h'.symm)).mpr h)
  have hconnG := hG.connected.preconnected
  have hlam : ∀ r : Rest G k x, A r ⊆ Q ∨ Disjoint (A r) Q := by
    intro r
    by_cases hr : r = r0
    · left
      rw [hr, hQdef]
    · have hne : (r.1 : Sym2 V) ≠ s(x k, c) := fun h => hr (Subtype.ext h)
      obtain ⟨⟨a, b', he, ha, hb'⟩, _⟩ := hA r
      have hab' : G.Adj a b' := by
        have h0 := r.2.1
        rw [he] at h0
        exact h0
      have hends : ∀ z ∈ s(x k, c), z ∈ (A r)ᶜ := by
        intro z hz
        rw [Sym2.mem_iff] at hz
        rcases hz with hz | hz
        · rw [hz]
          simpa using hAw r
        · rw [hz]
          simpa using hcA r hne
      have hQab : a ∈ Q ↔ b' ∈ Q := hQ.2 a b' hab' (by rw [← he]; exact hne)
      by_cases haQ : a ∈ Q
      · left
        intro z hz
        have hb'Q : b' ∈ Q := hQab.mp haQ
        have hcov := cover hconnG (hA r).compl hQ hends (by
          intro z' hz'
          rw [he, Sym2.mem_iff] at hz'
          rcases hz' with hz' | hz'
          · rw [hz']; exact haQ
          · rw [hz']; exact hb'Q) z
        rcases hcov with h | h
        · exact absurd hz (by simpa using h)
        · exact h
      · right
        have hb'Q : b' ∉ Q := fun h => haQ (hQab.mpr h)
        rw [Finset.disjoint_left]
        intro z hz hzQ
        have hcov := cover hconnG (hA r).compl hQ.compl hends (by
          intro z' hz'
          rw [he, Sym2.mem_iff] at hz'
          rcases hz' with hz' | hz'
          · rw [hz']; simpa using haQ
          · rw [hz']; simpa using hb'Q) z
        rcases hcov with h | h
        · exact absurd hz (by simpa using h)
        · exact absurd hzQ (by simpa using h)
  obtain ⟨m, hmdef⟩ : ∃ m, m = Q.card := ⟨_, rfl⟩
  have hm1 : 1 ≤ m := by
    rw [hmdef]
    exact Finset.card_pos.mpr ⟨c, hcQ⟩
  have hLQ : ∀ a ≤ k + 1, Disjoint (chainL x a) Q := by
    intro a ha
    rw [Finset.disjoint_left]
    intro v hv
    obtain ⟨i, hi, rfl⟩ := mem_chainL.mp hv
    exact hQchain i (by omega)
  have hLA : ∀ (r : Rest G k x) (a : ℕ), a ≤ k + 1 → Disjoint (chainL x a) (A r) := by
    intro r a ha
    rw [Finset.disjoint_left]
    intro v hv
    obtain ⟨i, hi, rfl⟩ := mem_chainL.mp hv
    exact hAchain r i (by omega)
  have hcount : k + m + 2 ≤ Fintype.card V := by
    have hbQ : b ∉ Q := by
      intro h
      exact hQw ((hQ.2 (x k) b d.hb (fun h' => d.hcb (Sym2.congr_right.mp h').symm)).mpr h)
    have hbL : b ∉ chainL x k := by
      intro h
      obtain ⟨i, hi, hie⟩ := mem_chainL.mp h
      exact d.ne_chain d.hb d.hb1 (Nat.le_of_lt hi) hie
    have hwL : x k ∉ chainL x k := by
      intro h
      obtain ⟨i, hi, hie⟩ := mem_chainL.mp h
      have := d.chain.inj i (by omega) k le_rfl hie
      omega
    have hbw : x k ≠ b := d.hb.ne
    have hT : (insert (x k) (insert b (chainL x k ∪ Q))).card = k + m + 2 := by
      rw [Finset.card_insert_of_notMem, Finset.card_insert_of_notMem,
        Finset.card_union_of_disjoint (hLQ k (by omega)), card_chainL d.chain (by omega), hmdef]
      · intro h
        rw [Finset.mem_union] at h
        rcases h with h | h
        · exact hbL h
        · exact hbQ h
      · intro h
        rw [Finset.mem_insert, Finset.mem_union] at h
        rcases h with h | h | h
        · exact hbw h
        · exact hwL h
        · exact hQw h
    rw [← hT]
    exact Finset.card_le_univ _
  -- `G'` is a tree.
  have hreach : ∀ i, i ≤ k → G'.Reachable (x i) (x 0) := by
    intro i
    induction i with
    | zero => exact fun _ => SimpleGraph.Reachable.refl _
    | succ i ih =>
      intro hi
      have hadj2 : G'.Adj (x (i + 1)) (x i) := (hadj' _ _).mpr (Or.inl ⟨(d.chain.adj i (by omega)).symm, by
        rw [Sym2.eq_swap]
        exact d.chain_edge_ne (by omega)⟩)
      exact hadj2.reachable.trans (ih (by omega))
  have hwc : G'.Reachable (x k) c :=
    (hreach k le_rfl).trans ((hadj' (x 0) c).mpr (Or.inr rfl)).reachable
  have hconnG' : G'.Preconnected := by
    intro u v
    obtain ⟨p⟩ := hconnG u v
    refine walk_prop (P := fun z => G'.Reachable u z) ?_ p (SimpleGraph.Reachable.refl _)
    intro z z' hzz' hz
    by_cases hedge : s(z, z') = s(x k, c)
    · rw [Sym2.eq_iff] at hedge
      rcases hedge with ⟨h1, h2⟩ | ⟨h1, h2⟩
      · rw [h1] at hz
        rw [h2]
        exact hz.trans hwc
      · rw [h1] at hz
        rw [h2]
        exact hz.trans hwc.symm
    · exact hz.trans ((hadj' z z').mpr (Or.inl ⟨hzz', hedge⟩)).reachable
  haveI : Nonempty V := hG.connected.nonempty
  have hG'conn : G'.Connected := ⟨hconnG'⟩
  have hcardE : Nat.card G'.edgeSet = Nat.card G.edgeSet :=
    (nat_card_family (eps1 G k x (x k) c (x 0)) d.eps1_mem d.eps1_bij).symm.trans
      (nat_card_family (eps0 G k x) d.eps0_mem d.eps0_bij)
  have hG'tree : G'.IsTree := SimpleGraph.isTree_iff_connected_and_card.mpr
    ⟨hG'conn, by rw [hcardE]; exact (SimpleGraph.isTree_iff_connected_and_card.mp hG).2⟩
  -- Sides.
  have hL : ∀ i : Fin k, IsSide G s(x i, x (i.val + 1)) (chainL x (i.val + 1)) :=
    fun i => chainL_side d.chain i.2
  have hS0 : ∀ p, IsSide G (eps0 G k x p)
      (Sum.elim (fun i : Fin k => chainL x (i.val + 1)) A p) := by
    rintro (i | r)
    · exact hL i
    · exact hA r
  have hS1 : ∀ p, IsSide G' (eps1 G k x (x k) c (x 0) p)
      (Sum.elim (fun i : Fin k => chainL x (i.val + 1) ∪ Q) A p) := by
    rintro (i | r)
    · have hilt := i.2
      refine ⟨⟨x i, x (i.val + 1), rfl,
        Finset.mem_union_left _ (mem_chainL.mpr ⟨i, by omega, rfl⟩), ?_⟩, ?_⟩
      · intro h
        rcases Finset.mem_union.mp h with h1 | h1
        · obtain ⟨j, hj, hje⟩ := mem_chainL.mp h1
          have := d.chain.inj j (by omega) (i.val + 1) hilt hje
          omega
        · exact hQchain _ hilt h1
      · intro u v huv hne
        rcases (hadj' u v).mp huv with ⟨h1, h2⟩ | h1
        · simp only [Sum.elim_inl, Finset.mem_union]
          rw [(hL i).2 u v h1 hne, hQ.2 u v h1 h2]
        · simp only [Sum.elim_inl, Finset.mem_union]
          have hy : x 0 ∈ chainL x (i.val + 1) := mem_chainL.mpr ⟨0, by omega, rfl⟩
          rw [Sym2.eq_iff] at h1
          rcases h1 with ⟨hu, hv⟩ | ⟨hu, hv⟩
          · rw [hu, hv]
            exact iff_of_true (Or.inl hy) (Or.inr hcQ)
          · rw [hu, hv]
            exact iff_of_true (Or.inr hcQ) (Or.inl hy)
    · by_cases hr : (r.1 : Sym2 V) = s(x k, c)
      · have he1 : eps1 G k x (x k) c (x 0) (Sum.inr r) = s(x 0, c) := by
          simp only [eps1, Sum.elim_inr]
          exact ite_eq_left hr
        rw [he1]
        have hcAr : c ∈ A r := by
          obtain ⟨a, b', he, ha, _⟩ := (hA r).1
          rw [hr, Sym2.eq_iff] at he
          rcases he with ⟨h1, _⟩ | ⟨_, h2⟩
          · rw [← h1] at ha
            exact absurd ha (hAw r)
          · rw [← h2] at ha
            exact ha
        refine ⟨⟨c, x 0, by rw [Sym2.eq_swap], hcAr, hAchain r 0 (Nat.zero_le _)⟩, ?_⟩
        intro u v huv hne
        rcases (hadj' u v).mp huv with ⟨h1, h2⟩ | h1
        · exact (hA r).2 u v h1 (by rw [hr]; exact h2)
        · exact absurd h1 hne
      · have he1 : eps1 G k x (x k) c (x 0) (Sum.inr r) = r.1 := by
          simp only [eps1, Sum.elim_inr]
          exact ite_eq_right hr
        rw [he1]
        refine ⟨(hA r).1, ?_⟩
        intro u v huv hne
        rcases (hadj' u v).mp huv with ⟨h1, _⟩ | h1
        · exact (hA r).2 u v h1 hne
        · rw [Sym2.eq_iff] at h1
          have hy := hAchain r 0 (Nat.zero_le _)
          have hc' := hcA r hr
          rcases h1 with ⟨hu, hv⟩ | ⟨hu, hv⟩
          · rw [hu, hv]
            exact iff_of_false hy hc'
          · rw [hu, hv]
            exact iff_of_false hc' hy
  have hn : (0 : ℝ) < (Fintype.card V : ℝ) := by exact_mod_cast Fintype.card_pos
  -- The arithmetic.
  have hnr : ((k : ℝ) + (m : ℝ) + 2) ≤ (Fintype.card V : ℝ) := by exact_mod_cast hcount
  have hm1r : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm1
  have hmQ : (Q.card : ℝ) = (m : ℝ) := by rw [hmdef]
  have hH : 0 < ∑ a ∈ Finset.range k, ∑ b ∈ Finset.range k,
      phi (Fintype.card V : ℝ) (m : ℝ) a b := by
    refine H_pos d.hk hm1r ?_
    linarith
  have hkey : ∀ r : Rest G k x, 0 ≤ ∑ i ∈ Finset.range k,
      (tau (chainL x (i + 1) ∪ Q) (A r) - tau (chainL x (i + 1)) (A r)) := by
    intro r
    rcases hlam r with hsub | hdis
    · have hterm : ∀ i ∈ Finset.range k,
          tau (chainL x (i + 1) ∪ Q) (A r) - tau (chainL x (i + 1)) (A r)
            = (((Fintype.card V : ℝ) - ((i : ℝ) + 1) - (m : ℝ)) * ((A r).card : ℝ)) ^ 2
              - (((i : ℝ) + 1) * ((A r).card : ℝ)) ^ 2 := by
        intro i hi
        have hi' := Finset.mem_range.mp hi
        rw [tau_rest_sub (hLA r _ (by omega)) hsub (hLQ _ (by omega)),
          card_chainL d.chain (by omega), hmQ]
        push_cast
        ring
      rw [Finset.sum_congr rfl hterm]
      exact rest_nonneg _ (by linarith) (by linarith)
    · refine Finset.sum_nonneg (fun i hi => ?_)
      have hi' := Finset.mem_range.mp hi
      rw [tau_rest_disj (hLA r _ (by omega)) hdis (hLQ _ (by omega)),
        card_chainL d.chain (by omega), hmQ]
      push_cast
      have h1 : (0 : ℝ) ≤ ((i : ℝ) + 1) * ((A r).card : ℝ) := by positivity
      have h2 : ((i : ℝ) + 1) * ((A r).card : ℝ)
          ≤ ((i : ℝ) + 1 + (m : ℝ)) * ((A r).card : ℝ) :=
        mul_le_mul_of_nonneg_right (by linarith) (by positivity)
      exact sub_nonneg.mpr (pow_le_pow_left₀ h1 h2 2)
  have hsum : ∑ p, ∑ q, tau (Sum.elim (fun i : Fin k => chainL x (i.val + 1)) A p)
        (Sum.elim (fun i : Fin k => chainL x (i.val + 1)) A q)
      < ∑ p, ∑ q, tau (Sum.elim (fun i : Fin k => chainL x (i.val + 1) ∪ Q) A p)
        (Sum.elim (fun i : Fin k => chainL x (i.val + 1) ∪ Q) A q) := by
    rw [sum_sum_split (fun p q => tau (Sum.elim (fun i : Fin k => chainL x (i.val + 1)) A p)
        (Sum.elim (fun i : Fin k => chainL x (i.val + 1)) A q)),
      sum_sum_split (fun p q => tau (Sum.elim (fun i : Fin k => chainL x (i.val + 1) ∪ Q) A p)
        (Sum.elim (fun i : Fin k => chainL x (i.val + 1) ∪ Q) A q))]
    simp only [Sum.elim_inl, Sum.elim_inr]
    have hA1 : ∑ i : Fin k, ∑ j : Fin k, tau (chainL x (i.val + 1)) (chainL x (j.val + 1))
        < ∑ i : Fin k, ∑ j : Fin k,
          tau (chainL x (i.val + 1) ∪ Q) (chainL x (j.val + 1) ∪ Q) := by
      have heq : ∑ i : Fin k, ∑ j : Fin k,
          (tau (chainL x (i.val + 1) ∪ Q) (chainL x (j.val + 1) ∪ Q)
            - tau (chainL x (i.val + 1)) (chainL x (j.val + 1)))
          = ∑ a ∈ Finset.range k, ∑ b ∈ Finset.range k,
            phi (Fintype.card V : ℝ) (m : ℝ) a b := by
        rw [Finset.sum_range]
        refine Finset.sum_congr rfl (fun i _ => ?_)
        rw [Finset.sum_range]
        refine Finset.sum_congr rfl (fun j _ => ?_)
        have hi := i.2
        have hj := j.2
        rw [tau_chainLQ d.chain hQchain (by omega) (by omega),
          tau_chainL d.chain (by omega) (by omega), hmQ]
        unfold phi
        push_cast
        ring
      have hpos : 0 < ∑ i : Fin k, ∑ j : Fin k,
          (tau (chainL x (i.val + 1) ∪ Q) (chainL x (j.val + 1) ∪ Q)
            - tau (chainL x (i.val + 1)) (chainL x (j.val + 1))) := by
        rw [heq]
        exact hH
      simp only [Finset.sum_sub_distrib] at hpos
      linarith
    have hkeyFin : ∀ r : Rest G k x,
        ∑ i : Fin k, tau (chainL x (i.val + 1)) (A r)
          ≤ ∑ i : Fin k, tau (chainL x (i.val + 1) ∪ Q) (A r) := by
      intro r
      have h := hkey r
      rw [Finset.sum_range, Finset.sum_sub_distrib] at h
      linarith
    have hB1 : ∑ i : Fin k, ∑ r : Rest G k x, tau (chainL x (i.val + 1)) (A r)
        ≤ ∑ i : Fin k, ∑ r : Rest G k x, tau (chainL x (i.val + 1) ∪ Q) (A r) := by
      rw [Finset.sum_comm, Finset.sum_comm (s := (Finset.univ : Finset (Fin k)))]
      exact Finset.sum_le_sum (fun r _ => hkeyFin r)
    have hC1 : ∑ r : Rest G k x, ∑ j : Fin k, tau (A r) (chainL x (j.val + 1))
        ≤ ∑ r : Rest G k x, ∑ j : Fin k, tau (A r) (chainL x (j.val + 1) ∪ Q) := by
      refine Finset.sum_le_sum (fun r _ => ?_)
      simp only [tau_comm (A r)]
      exact hkeyFin r
    linarith
  refine ⟨G', hG'tree, Classical.decRel _, ?_⟩
  rw [bh_eq_family hG (eps0 G k x) d.eps0_mem d.eps0_bij _ hS0,
    bh_eq_family hG'tree (eps1 G k x (x k) c (x 0)) d.eps1_mem d.eps1_bij _ hS1]
  rw [div_eq_mul_inv, div_eq_mul_inv]
  exact mul_lt_mul_of_pos_right hsum (inv_pos.mpr hn)

end BiH
