/-
BiHArith: the arithmetic of the pendant-path shift. `phi` is the change of a pair of chain
edges; the double sum has a closed form, and the off-chain sums are non-negative.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHSide

namespace BiH

set_option linter.unusedSectionVars false

/-- The change in `tau` for a pair of chain edges with `a+1` and `b+1` chain vertices beyond them. -/
noncomputable def phi (n m : ℝ) (a b : ℕ) : ℝ :=
  (n * (((min (a + 1) (b + 1) : ℕ) : ℝ) + m) - ((a : ℝ) + 1 + m) * ((b : ℝ) + 1 + m)) ^ 2
    - (n * ((min (a + 1) (b + 1) : ℕ) : ℝ) - ((a : ℝ) + 1) * ((b : ℝ) + 1)) ^ 2

theorem sum_aux (m u v : ℝ) (K : ℕ) :
    ∑ a ∈ Finset.range K, (((a : ℝ) + 1 + m) ^ 2 * u ^ 2 - ((a : ℝ) + 1) ^ 2 * v ^ 2)
      = u ^ 2 * ((K : ℝ) * (K + 1) * (2 * K + 1) / 6 + m * K * (K + 1) + K * m ^ 2)
        - v ^ 2 * ((K : ℝ) * (K + 1) * (2 * K + 1) / 6) := by
  induction K with
  | zero => simp
  | succ K ih =>
    rw [Finset.sum_range_succ, ih]
    push_cast
    ring

theorem phi_left (n m : ℝ) {a k : ℕ} (h : a ≤ k) :
    phi n m a k = ((a : ℝ) + 1 + m) ^ 2 * (n - k - 1 - m) ^ 2
      - ((a : ℝ) + 1) ^ 2 * (n - k - 1) ^ 2 := by
  unfold phi
  rw [min_eq_left (by omega : a + 1 ≤ k + 1)]
  push_cast
  ring

theorem phi_right (n m : ℝ) {b k : ℕ} (h : b ≤ k) :
    phi n m k b = ((b : ℝ) + 1 + m) ^ 2 * (n - k - 1 - m) ^ 2
      - ((b : ℝ) + 1) ^ 2 * (n - k - 1) ^ 2 := by
  unfold phi
  rw [min_eq_right (by omega : b + 1 ≤ k + 1)]
  push_cast
  ring

/-- **The closed form of the chain double sum.** -/
theorem H_closed (n m : ℝ) (k : ℕ) :
    ∑ a ∈ Finset.range k, ∑ b ∈ Finset.range k, phi n m a b
      = m * (n - k - m - 1)
        * ((k : ℝ) * (k + 1) * (2 * k + 1) * (n - k) / 3 + m * (n - k - m - 1) * k ^ 2) := by
  induction k with
  | zero => simp
  | succ k ih =>
    have step : ∑ a ∈ Finset.range (k + 1), ∑ b ∈ Finset.range (k + 1), phi n m a b
        = ∑ a ∈ Finset.range k, ∑ b ∈ Finset.range k, phi n m a b
          + ∑ a ∈ Finset.range k, phi n m a k + ∑ b ∈ Finset.range k, phi n m k b
          + phi n m k k := by
      rw [Finset.sum_range_succ]
      simp only [Finset.sum_range_succ, Finset.sum_add_distrib]
      ring
    have h1 : ∑ a ∈ Finset.range k, phi n m a k
        = (n - k - 1 - m) ^ 2 * ((k : ℝ) * (k + 1) * (2 * k + 1) / 6 + m * k * (k + 1) + k * m ^ 2)
          - (n - k - 1) ^ 2 * ((k : ℝ) * (k + 1) * (2 * k + 1) / 6) := by
      rw [Finset.sum_congr rfl
        (fun a ha => phi_left n m (by have := Finset.mem_range.mp ha; omega))]
      exact sum_aux m _ _ k
    have h2 : ∑ b ∈ Finset.range k, phi n m k b
        = (n - k - 1 - m) ^ 2 * ((k : ℝ) * (k + 1) * (2 * k + 1) / 6 + m * k * (k + 1) + k * m ^ 2)
          - (n - k - 1) ^ 2 * ((k : ℝ) * (k + 1) * (2 * k + 1) / 6) := by
      rw [Finset.sum_congr rfl
        (fun b hb => phi_right n m (by have := Finset.mem_range.mp hb; omega))]
      exact sum_aux m _ _ k
    rw [step, ih, h1, h2, phi_left n m (le_refl k)]
    push_cast
    ring

theorem H_pos {n m : ℝ} {k : ℕ} (hk : 1 ≤ k) (hm : 1 ≤ m) (ht : 1 ≤ n - k - m - 1) :
    0 < ∑ a ∈ Finset.range k, ∑ b ∈ Finset.range k, phi n m a b := by
  rw [H_closed]
  have hk' : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk
  have h1 : (0 : ℝ) < (k : ℝ) := by linarith
  have h2 : 0 < n - k := by linarith
  have ha : 0 < (k : ℝ) * (k + 1) * (2 * k + 1) * (n - k) / 3 := by
    apply div_pos _ (by norm_num)
    exact mul_pos (mul_pos (mul_pos h1 (by linarith)) (by linarith)) h2
  have hb : 0 ≤ m * (n - k - m - 1) * (k : ℝ) ^ 2 :=
    mul_nonneg (mul_nonneg (by linarith) (by linarith)) (by positivity)
  exact mul_pos (mul_pos (by linarith) (by linarith)) (add_pos_of_pos_of_nonneg ha hb)

/-- The sum of the off-chain terms for an edge inside `Q`. -/
theorem rest_closed (n m a : ℝ) (k : ℕ) :
    ∑ i ∈ Finset.range k, (((n - ((i : ℝ) + 1) - m) * a) ^ 2 - (((i : ℝ) + 1) * a) ^ 2)
      = a ^ 2 * ((n - m) * k * (n - m - k - 1)) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Finset.sum_range_succ, ih]
    push_cast
    ring

theorem rest_nonneg {n m : ℝ} {k : ℕ} (a : ℝ) (h1 : 0 ≤ n - m) (h2 : 0 ≤ n - m - k - 1) :
    0 ≤ ∑ i ∈ Finset.range k, (((n - ((i : ℝ) + 1) - m) * a) ^ 2 - (((i : ℝ) + 1) * a) ^ 2) := by
  rw [rest_closed]
  exact mul_nonneg (by positivity) (mul_nonneg (mul_nonneg h1 (by positivity)) h2)

/-- Splitting a double sum over a disjoint union. -/
theorem sum_sum_split {ι κ : Type*} [Fintype ι] [Fintype κ] (F : ι ⊕ κ → ι ⊕ κ → ℝ) :
    ∑ p, ∑ q, F p q
      = ∑ i, ∑ j, F (Sum.inl i) (Sum.inl j) + ∑ i, ∑ r, F (Sum.inl i) (Sum.inr r)
        + ∑ r, ∑ j, F (Sum.inr r) (Sum.inl j) + ∑ r, ∑ r', F (Sum.inr r) (Sum.inr r') := by
  simp only [Fintype.sum_sum_type, Finset.sum_add_distrib]
  ring

end BiH
