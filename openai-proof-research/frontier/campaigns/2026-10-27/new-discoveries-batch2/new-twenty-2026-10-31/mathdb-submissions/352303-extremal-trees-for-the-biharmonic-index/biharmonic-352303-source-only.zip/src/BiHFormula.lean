/-
BiHFormula: the edge-pair formula for the biharmonic index of a tree,
`BH(T) = N(T) / n` with `N(T) = ∑_{e,f} (n·|A_e ∩ A_f| − a_e·a_f)²`.

MathDB 352303 (Z. Lin, arXiv:2110.09931), Conjecture 5.3.
-/
import BiHInc
import BiHInv
import BiHCut
import Mathlib.Data.Matrix.Mul

open Matrix

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V]

section

variable {G : SimpleGraph V} [DecidableRel G.Adj] [Fintype G.edgeSet]

/-- A sum of `0/1` indicators is the cardinality of the filtered set. -/
theorem sum_ite_one (p : V → Prop) [DecidablePred p] :
    ∑ v : V, (if p v then (1 : ℝ) else 0) = ((Finset.univ.filter p).card : ℝ) := by
  classical
  have h1 : (Finset.univ.filter p).card = ∑ v ∈ Finset.univ, (if p v then 1 else 0) := by
    rw [Finset.card_filter]
  rw [h1, Nat.cast_sum]
  exact Finset.sum_congr rfl (fun v _ => by split_ifs <;> simp)

/-- The size of the intersection of two cuts. -/
noncomputable def interSize (c : G.Coloring (Fin 2)) (e f : ↥G.edgeFinset) : ℕ := by
  classical exact (Finset.univ.filter (fun v : V => v ∈ cutSet c e ∧ v ∈ cutSet c f)).card

/-- The Gram entry of two cut vectors is the centred intersection size. -/
theorem sum_cutVec_mul [Nonempty V] (c : G.Coloring (Fin 2)) (e f : ↥G.edgeFinset) :
    ∑ v : V, cutVec c e v * cutVec c f v
      = (interSize c e f : ℝ)
        - (cutSize c e : ℝ) * (cutSize c f : ℝ) / (Fintype.card V : ℝ) := by
  classical
  have hcard : (Fintype.card V : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  set n : ℝ := (Fintype.card V : ℝ) with hn
  set ae : ℝ := (cutSize c e : ℝ) with hae
  set af : ℝ := (cutSize c f : ℝ) with haf
  have hSe : ∑ v : V, (if v ∈ cutSet c e then (1 : ℝ) else 0) = ae := by
    rw [sum_ite_one]; rfl
  have hSf : ∑ v : V, (if v ∈ cutSet c f then (1 : ℝ) else 0) = af := by
    rw [sum_ite_one]; rfl
  have hSef : ∑ v : V, (if v ∈ cutSet c e then (1 : ℝ) else 0)
      * (if v ∈ cutSet c f then (1 : ℝ) else 0) = (interSize c e f : ℝ) := by
    have hprod : ∀ v : V, (if v ∈ cutSet c e then (1 : ℝ) else 0)
        * (if v ∈ cutSet c f then (1 : ℝ) else 0)
        = if v ∈ cutSet c e ∧ v ∈ cutSet c f then (1 : ℝ) else 0 := by
      intro v; by_cases h1 : v ∈ cutSet c e <;> by_cases h2 : v ∈ cutSet c f <;> simp [h1, h2]
    rw [Finset.sum_congr rfl (fun v _ => hprod v), sum_ite_one]
    rfl
  calc ∑ v : V, cutVec c e v * cutVec c f v
      = ∑ v : V, ((if v ∈ cutSet c e then (1 : ℝ) else 0) - ae / n)
          * ((if v ∈ cutSet c f then (1 : ℝ) else 0) - af / n) := by
        refine Finset.sum_congr rfl (fun v _ => ?_)
        simp only [cutVec, ← hn, ← hae, ← haf]
    _ = ∑ v : V, ((if v ∈ cutSet c e then (1 : ℝ) else 0)
            * (if v ∈ cutSet c f then (1 : ℝ) else 0)
          - (af / n) * (if v ∈ cutSet c e then (1 : ℝ) else 0)
          - (ae / n) * (if v ∈ cutSet c f then (1 : ℝ) else 0)
          + (ae / n) * (af / n)) := by
        refine Finset.sum_congr rfl (fun v _ => ?_)
        ring
    _ = (∑ v : V, (if v ∈ cutSet c e then (1 : ℝ) else 0)
            * (if v ∈ cutSet c f then (1 : ℝ) else 0))
        - (af / n) * (∑ v : V, (if v ∈ cutSet c e then (1 : ℝ) else 0))
        - (ae / n) * (∑ v : V, (if v ∈ cutSet c f then (1 : ℝ) else 0))
        + n * ((ae / n) * (af / n)) := by
        rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, Finset.sum_sub_distrib,
          ← Finset.mul_sum, ← Finset.mul_sum, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
    _ = (interSize c e f : ℝ) - ae * af / n := by
        rw [hSef, hSe, hSf]
        have hn0 : n ≠ 0 := by rw [hn]; exact hcard
        field_simp
        ring

/-- **The edge-pair formula.** -/
theorem bh_eq_formula (hG : G.IsTree) :
    bh G = (∑ e : ↥G.edgeFinset, ∑ f : ↥G.edgeFinset,
        ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
          - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2)
      / (Fintype.card V : ℝ) := by
  classical
  haveI : Nonempty V := hG.connected.nonempty
  have hmain := bh_eq_card_mul_sum_sq G (sInc hG.coloringTwo) (cutMatrix hG.coloringTwo)
    (sInc_mul_transpose hG.coloringTwo).symm (sInc_transpose_mulVec_one hG.coloringTwo)
    (sInc_ker_const hG.coloringTwo hG) (sInc_transpose_mul_cutMatrix hG.coloringTwo hG)
    (sum_cutMatrix hG.coloringTwo) (lapMatrix_ker_const hG.coloringTwo hG)
  rw [hmain]
  have hcard : (Fintype.card V : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  have hpt : ∀ e f : ↥G.edgeFinset,
      (∑ v : V, cutMatrix hG.coloringTwo v e * cutMatrix hG.coloringTwo v f) ^ 2
      = ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
          - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2
        / (Fintype.card V : ℝ) ^ 2 := by
    intro e f
    have h1 : ∑ v : V, cutMatrix hG.coloringTwo v e * cutMatrix hG.coloringTwo v f
        = (interSize hG.coloringTwo e f : ℝ)
          - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)
            / (Fintype.card V : ℝ) := by
      simp only [cutMatrix]
      exact sum_cutVec_mul hG.coloringTwo e f
    rw [h1]
    field_simp
  rw [Finset.sum_congr rfl (fun e _ => Finset.sum_congr rfl (fun f _ => hpt e f))]
  have hinner : ∀ e : ↥G.edgeFinset,
      ∑ f : ↥G.edgeFinset,
        ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
          - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2
          / (Fintype.card V : ℝ) ^ 2
      = (∑ f : ↥G.edgeFinset,
        ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
          - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2)
        / (Fintype.card V : ℝ) ^ 2 :=
    fun e => (Finset.sum_div Finset.univ _ _).symm
  have houter :
      ∑ e : ↥G.edgeFinset,
        (∑ f : ↥G.edgeFinset,
          ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
            - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2)
          / (Fintype.card V : ℝ) ^ 2
      = (∑ e : ↥G.edgeFinset, ∑ f : ↥G.edgeFinset,
          ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
            - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2)
        / (Fintype.card V : ℝ) ^ 2 :=
    (Finset.sum_div Finset.univ _ _).symm
  rw [Finset.sum_congr rfl (fun e _ => hinner e), houter]
  field_simp

end

end BiH
