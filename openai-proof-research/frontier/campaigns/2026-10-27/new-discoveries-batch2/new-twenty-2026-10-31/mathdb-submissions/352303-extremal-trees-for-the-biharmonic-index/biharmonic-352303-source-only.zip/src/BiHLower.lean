/-
BiHLower: a first lower bound for the biharmonic index of a tree,
`BH(T) ≥ (n−1)³/n`, from the diagonal part of the edge-pair formula.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHFormula
import Mathlib.Combinatorics.SimpleGraph.Acyclic

open Matrix

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V]

section

variable {G : SimpleGraph V} [DecidableRel G.Adj] [Fintype G.edgeSet]

theorem interSize_self (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    interSize c e e = cutSize c e := by
  classical
  simp only [interSize, cutSize]
  congr 1
  exact Finset.filter_congr (fun v _ => by simp)

/-- Every cut side contains the sign-`+1` endpoint, so it is non-empty. -/
theorem one_le_cutSize (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) : 1 ≤ cutSize c e := by
  classical
  rw [cutSize]
  exact Finset.card_pos.mpr
    ⟨posEnd c e, Finset.mem_filter.mpr ⟨Finset.mem_univ _, posEnd_mem_cutSet c e⟩⟩

/-- For a tree, every edge has an endpoint outside the cut side, so the cut is proper. -/
theorem exists_not_mem_cutSet (c : G.Coloring (Fin 2)) (hG : G.IsTree) (e : ↥G.edgeFinset) :
    ∃ v : V, v ∉ cutSet c e := by
  classical
  have key : ∀ z : Sym2 V, z ∈ G.edgeSet → ∀ (e : ↥G.edgeFinset), (e : Sym2 V) = z →
      ∃ v : V, v ∉ cutSet c e := by
    intro z
    refine Sym2.ind (f := fun z => z ∈ G.edgeSet → ∀ (e : ↥G.edgeFinset), (e : Sym2 V) = z →
      ∃ v : V, v ∉ cutSet c e) ?_ z
    intro a b hmem e hpair
    have hab : G.Adj a b := hmem
    obtain ⟨ha, hb⟩ := mem_cutSet_pair c hG hab e hpair
    have hpe : posEnd c e ∈ s(a, b) := by rw [← hpair]; exact posEnd_mem c e
    rw [Sym2.mem_iff] at hpe
    rcases hpe with h1 | h1
    · refine ⟨b, fun hc => ?_⟩
      exact hab.ne ((hb.mp hc).trans h1).symm
    · refine ⟨a, fun hc => ?_⟩
      exact hab.ne ((ha.mp hc).trans h1)
  exact key (e : Sym2 V) (G.mem_edgeFinset.mp e.2) e rfl

/-- For a tree, a cut side is a proper subset. -/
theorem cutSize_le (c : G.Coloring (Fin 2)) (hG : G.IsTree) (e : ↥G.edgeFinset) :
    cutSize c e ≤ Fintype.card V - 1 := by
  classical
  obtain ⟨v, hv⟩ := exists_not_mem_cutSet c hG e
  have hlt : cutSize c e < Fintype.card V := by
    rw [cutSize]
    refine Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr
      ⟨Finset.filter_subset _ _, fun h => hv ?_⟩)
    have hv' : v ∈ Finset.univ.filter (fun v : V => v ∈ cutSet c e) := by
      rw [h]; exact Finset.mem_univ v
    exact (Finset.mem_filter.mp hv').2
  omega

/-- `a(n−a) ≥ n−1` for `1 ≤ a ≤ n−1`. -/
theorem cut_mul_ge (c : G.Coloring (Fin 2)) (hG : G.IsTree) (e : ↥G.edgeFinset) :
    (Fintype.card V : ℝ) - 1
      ≤ (cutSize c e : ℝ) * ((Fintype.card V : ℝ) - (cutSize c e : ℝ)) := by
  haveI : Nonempty V := hG.connected.nonempty
  have h1 : (1 : ℝ) ≤ (cutSize c e : ℝ) := by exact_mod_cast one_le_cutSize c e
  have h2 : (cutSize c e : ℝ) ≤ (Fintype.card V : ℝ) - 1 := by
    have h : cutSize c e + 1 ≤ Fintype.card V := by
      have h0 := cutSize_le c hG e
      have hpos : 1 ≤ Fintype.card V := Fintype.card_pos
      omega
    have h' : (cutSize c e : ℝ) + 1 ≤ (Fintype.card V : ℝ) := by exact_mod_cast h
    linarith
  have h3 : (0 : ℝ) ≤ ((cutSize c e : ℝ) - 1)
      * ((Fintype.card V : ℝ) - (cutSize c e : ℝ) - 1) :=
    mul_nonneg (by linarith) (by linarith)
  nlinarith

/-- **A lower bound: `BH(T) ≥ (n−1)³/n`.** -/
theorem bh_ge_cube (hG : G.IsTree) :
    bh G ≥ ((Fintype.card V : ℝ) - 1) ^ 3 / (Fintype.card V : ℝ) := by
  classical
  haveI : Nonempty V := hG.connected.nonempty
  have hn : 0 < (Fintype.card V : ℝ) := by exact_mod_cast Fintype.card_pos
  have hcardE : (Fintype.card ↥G.edgeFinset : ℝ) = (Fintype.card V : ℝ) - 1 := by
    have h := hG.card_edgeFinset
    have h2 : Fintype.card ↥G.edgeFinset = G.edgeFinset.card := Fintype.card_coe G.edgeFinset
    have h' : (G.edgeFinset.card : ℝ) + 1 = (Fintype.card V : ℝ) := by exact_mod_cast h
    have h'' : (Fintype.card ↥G.edgeFinset : ℝ) = (G.edgeFinset.card : ℝ) := by
      exact_mod_cast h2
    linarith
  have hdiag : ∀ e : ↥G.edgeFinset,
      ((Fintype.card V : ℝ) - 1) ^ 2
        ≤ ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e e : ℝ)
            - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo e : ℝ)) ^ 2 := by
    intro e
    have h1 : interSize hG.coloringTwo e e = cutSize hG.coloringTwo e := interSize_self _ e
    have h2 := cut_mul_ge hG.coloringTwo hG e
    have h3 : (Fintype.card V : ℝ) * (cutSize hG.coloringTwo e : ℝ)
        - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo e : ℝ)
        = (cutSize hG.coloringTwo e : ℝ)
          * ((Fintype.card V : ℝ) - (cutSize hG.coloringTwo e : ℝ)) := by ring
    rw [h1, h3]
    exact pow_le_pow_left₀ (by linarith) h2 2
  have hmain : ((Fintype.card V : ℝ) - 1) ^ 3
      ≤ ∑ e : ↥G.edgeFinset, ∑ f : ↥G.edgeFinset,
          ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
            - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2 := by
    calc ((Fintype.card V : ℝ) - 1) ^ 3
        = ((Fintype.card V : ℝ) - 1) * ((Fintype.card V : ℝ) - 1) ^ 2 := by ring
      _ = ∑ _e : ↥G.edgeFinset, ((Fintype.card V : ℝ) - 1) ^ 2 := by
            rw [Finset.sum_const, Finset.card_univ, ← hcardE, nsmul_eq_mul]
      _ ≤ ∑ e : ↥G.edgeFinset, ∑ f : ↥G.edgeFinset,
          ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
            - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2 := by
            refine Finset.sum_le_sum (fun e _ => ?_)
            refine le_trans (hdiag e) ?_
            exact Finset.single_le_sum
              (f := fun f : ↥G.edgeFinset =>
                ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
                  - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2)
              (fun f _ => sq_nonneg _) (Finset.mem_univ e)
  calc ((Fintype.card V : ℝ) - 1) ^ 3 / (Fintype.card V : ℝ)
      ≤ (∑ e : ↥G.edgeFinset, ∑ f : ↥G.edgeFinset,
          ((Fintype.card V : ℝ) * (interSize hG.coloringTwo e f : ℝ)
            - (cutSize hG.coloringTwo e : ℝ) * (cutSize hG.coloringTwo f : ℝ)) ^ 2)
        / (Fintype.card V : ℝ) := by
        exact div_le_div_of_nonneg_right hmain (le_of_lt hn)
    _ = bh G := (bh_eq_formula hG).symm

end

end BiH
