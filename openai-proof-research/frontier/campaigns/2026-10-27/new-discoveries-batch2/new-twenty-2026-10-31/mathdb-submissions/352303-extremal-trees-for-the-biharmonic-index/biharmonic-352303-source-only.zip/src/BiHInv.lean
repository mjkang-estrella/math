/-
BiHInv: the algebraic inverse formula.  If `B` is any matrix with `Bᵀ *ᵥ 1 = 0`, whose
transpose kills only constant vectors, and `X` is a matrix with `Bᵀ * X = 1` and zero column
sums, then `(Bᵀ B)⁻¹ = Xᵀ X`, and consequently `BH = n * ∑_{e,f} ⟨x_e, x_f⟩²`.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHBase
import BiHTrace
import BiHBridge
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.Data.Matrix.Mul

open Matrix

namespace BiH

variable {V E : Type*} [Fintype V] [DecidableEq V] [Fintype E] [DecidableEq E]

omit [DecidableEq V] in
/-- **The Gram inverse.** Under `Bᵀ *ᵥ 1 = 0`, `ker Bᵀ` = constants, `Bᵀ * X = 1` and
zero column sums for `X`, the matrix `Xᵀ X` is a right inverse of `Bᵀ B`. -/
theorem gram_mul_eq_one [Nonempty V]
    (B : Matrix V E ℝ) (X : Matrix V E ℝ)
    (hB1 : Bᵀ *ᵥ (fun _ => (1 : ℝ)) = 0)
    (hkerB : ∀ z : V → ℝ, Bᵀ *ᵥ z = 0 → ∀ i j : V, z i = z j)
    (hBX : Bᵀ * X = 1)
    (hXsum : ∀ f : E, ∑ v : V, X v f = 0) :
    (Bᵀ * B) * (Xᵀ * X) = 1 := by
  classical
  have hz : ∀ e : E, (fun v => ∑ g : E, (Bᵀ * B) e g * X v g) = fun v => B v e := by
    intro e
    have hsum0 : ∑ v : V, (∑ g : E, (Bᵀ * B) e g * X v g) = 0 := by
      rw [Finset.sum_comm]
      refine Finset.sum_eq_zero (fun g _ => ?_)
      rw [← Finset.mul_sum, hXsum g, mul_zero]
    have hc0 : ∑ v : V, B v e = 0 := by
      have h := congrFun hB1 e
      rw [Matrix.mulVec_apply_eq_sum] at h
      simp only [Matrix.transpose_apply, mul_one, Pi.zero_apply] at h
      simpa using h
    have hBeq : ∀ h : E, (∑ v : V, B v h * (∑ g : E, (Bᵀ * B) e g * X v g))
        = ∑ v : V, B v h * B v e := by
      intro h
      calc ∑ v : V, B v h * (∑ g : E, (Bᵀ * B) e g * X v g)
          = ∑ v : V, ∑ g : E, B v h * ((Bᵀ * B) e g * X v g) := by
            refine Finset.sum_congr rfl (fun v _ => ?_)
            rw [Finset.mul_sum]
        _ = ∑ g : E, ∑ v : V, B v h * ((Bᵀ * B) e g * X v g) := Finset.sum_comm
        _ = ∑ g : E, (Bᵀ * B) e g * (∑ v : V, B v h * X v g) := by
            refine Finset.sum_congr rfl (fun g _ => ?_)
            rw [Finset.mul_sum]
            exact Finset.sum_congr rfl (fun v _ => by ring)
        _ = ∑ g : E, (Bᵀ * B) e g * (Bᵀ * X) h g := by
            refine Finset.sum_congr rfl (fun g _ => ?_)
            simp only [Matrix.mul_apply, Matrix.transpose_apply]
        _ = ∑ g : E, (Bᵀ * B) e g * (1 : Matrix E E ℝ) h g := by rw [hBX]
        _ = ∑ g : E, if h = g then (Bᵀ * B) e g else 0 := by
            refine Finset.sum_congr rfl (fun g _ => ?_)
            rw [Matrix.one_apply]
            by_cases hg : h = g <;> simp [hg]
        _ = (Bᵀ * B) e h := by rw [Finset.sum_ite_eq]; simp
        _ = ∑ v : V, B v h * B v e := by
            rw [Matrix.mul_apply]; simp only [Matrix.transpose_apply]
            exact Finset.sum_congr rfl (fun v _ => by ring)
    have hsub : Bᵀ *ᵥ ((fun v => ∑ g : E, (Bᵀ * B) e g * X v g) - fun v => B v e) = 0 := by
      funext h
      rw [Matrix.mulVec_sub, Pi.sub_apply, Matrix.mulVec_apply_eq_sum, Matrix.mulVec_apply_eq_sum]
      simp only [Matrix.transpose_apply]
      rw [Pi.zero_apply, hBeq h, sub_self]
    have hconst := hkerB _ hsub
    have hsum_sub : ∑ v : V, ((∑ g : E, (Bᵀ * B) e g * X v g) - B v e) = 0 := by
      rw [Finset.sum_sub_distrib, hsum0, hc0, sub_zero]
    have hzero_all : ∀ v : V, ((∑ g : E, (Bᵀ * B) e g * X v g) - B v e) = 0 := by
      intro v
      have h2 : ∀ w : V, ((∑ g : E, (Bᵀ * B) e g * X w g) - B w e)
          = ((∑ g : E, (Bᵀ * B) e g * X v g) - B v e) := fun w => hconst w v
      rw [Finset.sum_congr rfl (fun w _ => h2 w), Finset.sum_const, Finset.card_univ,
        nsmul_eq_mul] at hsum_sub
      have hc : (Fintype.card V : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
      exact (mul_eq_zero.mp hsum_sub).resolve_left hc
    funext v
    exact sub_eq_zero.mp (hzero_all v)
  ext e f
  rw [Matrix.mul_apply, Matrix.one_apply]
  have hM' : ∀ g : E, (Xᵀ * X) g f = ∑ v : V, X v g * X v f := by
    intro g; rw [Matrix.mul_apply]; simp only [Matrix.transpose_apply]
  calc ∑ g : E, (Bᵀ * B) e g * (Xᵀ * X) g f
      = ∑ g : E, ∑ v : V, (Bᵀ * B) e g * (X v g * X v f) := by
        refine Finset.sum_congr rfl (fun g _ => ?_)
        rw [hM' g, Finset.mul_sum]
    _ = ∑ v : V, ∑ g : E, (Bᵀ * B) e g * (X v g * X v f) := Finset.sum_comm
    _ = ∑ v : V, (∑ g : E, (Bᵀ * B) e g * X v g) * X v f := by
        refine Finset.sum_congr rfl (fun v _ => ?_)
        rw [Finset.sum_mul]
        exact Finset.sum_congr rfl (fun g _ => by ring)
    _ = ∑ v : V, B v e * X v f := by
        refine Finset.sum_congr rfl (fun v _ => ?_)
        rw [congrFun (hz e) v]
    _ = (Bᵀ * X) e f := by
        rw [Matrix.mul_apply]; simp only [Matrix.transpose_apply]
    _ = (if e = f then (1 : ℝ) else 0) := by rw [hBX]; rw [Matrix.one_apply]

/-- **The biharmonic index through an explicit Gram matrix.** -/
theorem bh_eq_card_mul_sum_sq [Nonempty V]
    (G : SimpleGraph V) [DecidableRel G.Adj]
    (B : Matrix V E ℝ) (X : Matrix V E ℝ)
    (hL : G.lapMatrix ℝ = B * Bᵀ)
    (hB1 : Bᵀ *ᵥ (fun _ => (1 : ℝ)) = 0)
    (hkerB : ∀ z : V → ℝ, Bᵀ *ᵥ z = 0 → ∀ i j : V, z i = z j)
    (hBX : Bᵀ * X = 1)
    (hXsum : ∀ f : E, ∑ v : V, X v f = 0)
    (hkerL : ∀ x : V → ℝ, G.lapMatrix ℝ *ᵥ x = 0 → ∀ i j : V, x i = x j) :
    bh G = (Fintype.card V : ℝ) * ∑ e : E, ∑ f : E, (∑ v : V, X v e * X v f) ^ 2 := by
  classical
  have hMM' : (Bᵀ * B) * (Xᵀ * X) = 1 := gram_mul_eq_one B X hB1 hkerB hBX hXsum
  have hM'M : (Xᵀ * X) * (Bᵀ * B) = 1 := mul_eq_one_comm.mp hMM'
  have hbridge := bh_eq_card_mul_trace_inv_sq G B (Bᵀ * B) (Xᵀ * X) hL rfl hMM' hM'M hB1 hkerL
  rw [hbridge]
  congr 1
  have hA : ∀ e f : E, (Xᵀ * X) e f = ∑ v : V, X v e * X v f := by
    intro e f; rw [Matrix.mul_apply]; simp only [Matrix.transpose_apply]
  have hsym : ∀ e f : E, (Xᵀ * X) f e = ∑ v : V, X v e * X v f := by
    intro e f
    rw [hA f e]
    exact Finset.sum_congr rfl (fun v _ => by ring)
  rw [Matrix.trace]
  refine Finset.sum_congr rfl (fun e _ => ?_)
  rw [Matrix.diag, Matrix.mul_apply]
  refine Finset.sum_congr rfl (fun f _ => ?_)
  rw [hA e f, hsym e f, sq]

end BiH
