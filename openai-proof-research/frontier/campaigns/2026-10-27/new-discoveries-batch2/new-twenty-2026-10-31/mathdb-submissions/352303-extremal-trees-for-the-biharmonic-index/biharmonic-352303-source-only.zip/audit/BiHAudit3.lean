/-
BiHAudit3: axiom audit for the third-lane modules. Every `#print axioms` must report only
`propext`, `Classical.choice` and `Quot.sound`.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHSide
import BiHOffDiag
import BiHIso
import BiHChain
import BiHArith
import BiHShiftA
import BiHShiftB
import BiHEndpoint
import BiHPathValue

#print axioms BiH.bh_eq_family
#print axioms BiH.tau_congr_side
#print axioms BiH.cover
#print axioms BiH.one_le_tau_of_ne
#print axioms BiH.starN_div_le_bh
#print axioms BiH.allPendant_of_bh_eq
#print axioms BiH.bh_eq_starN_of_allPendant
#print axioms BiH.bh_congr_iso
#print axioms BiH.allPendant_starGraph
#print axioms BiH.iso_star_of_allPendant
#print axioms BiH.exists_chain
#print axioms BiH.iso_path_of_full
#print axioms BiH.H_closed
#print axioms BiH.H_pos
#print axioms BiH.rest_closed
#print axioms BiH.ShiftData.eps1_bij
#print axioms BiH.chainL_side
#print axioms BiH.shift_increases
#print axioms BiH.exists_maximizer
#print axioms BiH.iso_path_of_maximal
#print axioms BiH.bh_endpoint
#print axioms BiH.pathChain
#print axioms BiH.isTree_pathGraph
#print axioms BiH.bhPath_value
#print axioms BiH.bhPath_four
#print axioms BiH.bhStar_four
