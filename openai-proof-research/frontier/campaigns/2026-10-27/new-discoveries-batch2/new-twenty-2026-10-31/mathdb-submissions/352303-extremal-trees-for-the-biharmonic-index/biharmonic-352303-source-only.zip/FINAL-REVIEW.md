# FINAL-REVIEW: MathDB 352303, extremal biharmonic index of trees

Reviewer: Claude Opus 5.5, high effort, done personally. No subagents and no other model. Credit 0. Campaign 58 of 80 unchanged. Root alone adjudicates.

## Verdict

**TECHNICAL_PASS_ROOT_ADJUDICATION_PENDING.** I tried to break the claim and could not. `BiH.bh_endpoint` is the exact MathDB statement, and it compiles and kernel-checks from an empty build. Its closure uses only `propext`, `Classical.choice` and `Quot.sound`. Controls derived by hand from the literal mathlib eigenvalues, independent of the authors' proof chain, agree with it. Nothing I found affects validity or fidelity.

Two matters stay open for root and I did not resolve them: prior-art breadth (Gate F) and whether the result is routine (Gate G).

## Gate A: fresh extracted replay: PASS

The zip held 17 flat `.lean` files with no absolute path, parent reference or symlink, and all 17 matched `packet/SOURCE-HASHES.json`. Starting from empty `src/` and `build/`, all 17 modules in `packet/BUILD-ORDER.json` compiled and kernel-checked with exit 0 (labels `fresh_compile_*`, `fresh_check_*`). Each olean hash is the same after compile and after check. Details are in `results/FRESH-REPLAY.json`.

Each compile took 1.3 to 3.0 s, which looked too fast to me, so I tested it. The same wrapper rejected a false claim (`neg_a_expected_fail_31`, exit 1, `unsolved goals ⊢ False`) and a `sorry` (`neg_b_expected_fail_32`, exit 1). It also rejected my own deprecated lemma names and a failed `Decidable` synthesis. Lean reports `4.34.1`, githash `5045d0056413266e57c625dcd7c365b10e377c52`, from `#eval`-style `logInfo` inside the audit module. Elaboration is real.

## Gate B: source audit: PASS

I read all 17 sources in full. A comment-stripped keyword scan (`scan_src_16`) and my reading found no `sorry`, `admit`, `axiom`, `unsafe`, `partial`, `opaque`, `implemented_by`, `extern`, `native_decide`, `ofReduceBool`, `macro`, `syntax`, `elab`, `notation`, `run_cmd`, `attribute`, priority setting, `private` or `decide`. There is no redefinition of a mathlib name: every BiH-module constant in the closure lies in namespace `BiH` (0 outside it, from the walk).

The only `set_option`s are the linters `linter.unusedSectionVars`, `linter.style.haveILetI` and `linter.unusedVariables`. There are two instances: `instDecidableRelPathGraphFin` (an honest `decidable_of_iff` from `pathGraph_adj`, and a `Decidable` value cannot change `bh`, see `bh_inst`) and `instFintypeRest` (`Fintype.ofFinite` on a private edge subtype).

| Module | Role |
|---|---|
| BiHBase | Definitions `lapEigs`, `bh`, `starGraphFin`, `pathGraphFin`, `bhStar`, `bhPath`; exactly one zero eigenvalue for connected graphs |
| BiHTrace | Spectral form, trace of powers of an inverse for Hermitian matrices |
| BiHBridge | `bh G = n · tr(M'²)` from a factorization `L = BBᵀ` |
| BiHInc | Signed incidence matrix from a 2-colouring; `BBᵀ = L`, `Bᵀ1 = 0` |
| BiHInv | `(BᵀB)⁻¹ = XᵀX` for centred cut vectors |
| BiHCut | Cut sets of tree edges, kernel of L is the constants, `Bᵀx_e = e_e` |
| BiHFormula | Edge-pair formula `bh_eq_formula` |
| BiHLower | First lower bound `(n-1)³/n` |
| BiHSide | `IsSide`, `tau`, complement invariance, orientation-free `bh_eq_family` |
| BiHArith | `phi`, `H_closed`, `H_pos`, `rest_closed`, `rest_nonneg` |
| BiHOffDiag | Laminarity, `tau ≥ 1`, `starN_div_le_bh`, equality case, star value |
| BiHIso | `bh_congr_iso`, all-pendant tree is the star |
| BiHChain | Pendant chains, dichotomy, full chain is the path |
| BiHShiftA | Shifted graph and edge bijections |
| BiHShiftB | `shift_increases` |
| BiHEndpoint | `exists_maximizer`, `iso_path_of_maximal`, `bh_endpoint` |
| BiHPathValue | `bhPath_value`, `isTree_pathGraph`, `bhPath_four`, `bhStar_four` |

No theorem has a conclusion-bearing hypothesis. Multi-hypothesis lemmas (`bh_eq_card_mul_trace_inv_sq`, `bh_eq_card_mul_sum_sq`, `iso_path_of_maximal`, `shift_increases`) have every premise discharged by actual constructions, and `bh_endpoint` itself assumes only `5 ≤ n`, the cardinality, and `G.IsTree`.

## Gate C: axioms and dependencies: PASS

`AuditPrint` shows `[propext, Classical.choice, Quot.sound]` for all seven named theorems. `AuditWalk` walked the joint transitive constant closure of those seven through the environment API, covering type, value, constructors and recursor rules. Results:

- 36,296 constants, 0 missing.
- Kinds: axiom 3, ctor 901, def 8007, inductive 805, opaque 30, quot 4, rec 215, theorem 26331.
- Origin by top component: Aesop 1, Batteries 168, BiH* 286, Init 6546, Mathlib 29295.
- Axioms: exactly `propext`, `Classical.choice`, `Quot.sound`.
- 0 unsafe, 0 partial.
- `implemented_by` (5): `List.attachWith`, `Nat.repr`, `Lean.Name.anonymous`, `Lean.Name.num`, `Lean.Name.str`. These are compiler-only attributes on core constants and do not enter kernel reasoning.
- `opaque` (30): 28 `wrapped._@` `irreducible_def` wrappers in Mathlib, plus `Lean.opaqueId` and `String.Internal.append`. 57 `extern` core constants, 30 of them listed in the output.

My first attempt, `AuditAxioms` (with an explicit `import Lean`), hit the `-M3500` limit: true exit 250, Lean -6, `audit_axioms_compile_21`. The failure is retained. The changed lean version, without the extra import and filtering duplicates during the fold, fit. `AuditWalk` was also kernel-checked.

## Gate D: statement fidelity: PASS. This is the exact MathDB statement.

Elaborated statement, from `#check`:

`∀ {V : Type u_1} [Fintype V] [DecidableEq V] (n : ℕ) (hn : 5 ≤ n) (hV : Fintype.card V = n) (G : SimpleGraph V) [DecidableRel G.Adj], G.IsTree → bhStar n ⋯ ≤ bh G ∧ bh G ≤ bhPath n ∧ (bh G = bhStar n ⋯ ↔ Nonempty (G ≃g starGraphFin n ⋯)) ∧ (bh G = bhPath n ↔ Nonempty (G ≃g pathGraphFin n))`

Checked against `inputs/literal352303.json`, arXiv 2110.09931v1 (abstract and Conjecture 5.3 on p.10) and AIMS Math 7(4) 6050-6065 (Conjecture 5.3 retained verbatim):

- **BH.** The source prints `BH(G) = ½ΣΣ d_B²(u,v) = n Σ_{i=2}^n 1/λ_i²` with `λ_i` the i-th smallest Laplacian eigenvalue. `bh` is `(Fintype.card V) * Σ_i (if λ_i = 0 then 0 else λ_i⁻¹ ^ 2)`.
- **Eigenvalues of the actual Laplacian.** `lapEigs` is mathlib's `(G.isHermitian_lapMatrix ℝ).eigenvalues`. `lapMatrix` is `degMatrix − adjMatrix`, read in the pinned mathlib. `charpoly_eq` there gives `A.charpoly = ∏ (X − C λ_i)`, so the values are the eigenvalues with multiplicity.
- **Exactly one zero dropped.** `card_zero_eigs_of_connected` proves it, independently derived for star, path and fork in my controls (counts equal 1). Dropping zeros under `if` is equivalent to the source range `i = 2..n`.
- **Star.** `starGraphFin n` is `SimpleGraph.starGraph ⟨0, _⟩`, `fromRel fun v _ ↦ v = r`, so adjacency is `x ≠ y ∧ (x = r ∨ y = r)`: K_{1,n-1} on n labelled vertices.
- **Path.** `pathGraphFin n` is `pathGraph n = hasse (Fin n)` with `pathGraph_adj : u+1=v ∨ v+1=u`: P_n.
- **`bhStar`, `bhPath`** are `bh` of those concrete graphs (`#print`), not constants. Their exact values are proved and agree with the literal definition in my controls (`bhStar_five_eq`, `bhPath_five_eq`, `bhPath_authors_formula_five`).
- **Range** is exactly `5 ≤ n`, with no other premise.
- **Both inequalities and both equality characterizations** are present. `T_n = K_{1,n-1}` reads as graph isomorphism via `Nonempty (G ≃g ...)`, which is the standard meaning for an unlabelled tree.
- **`IsTree`** is `Connected` plus `IsAcyclic` (no cycles), so graph-theoretic.
- **`DecidableRel`, `Fintype`, `DecidableEq`** are arbitrary instance arguments and impose no restriction. `bh_inst` shows `bh` is instance-independent. The `by omega` arguments are proofs of `0 < n`, proof-irrelevant and derivable from `hn`.
- **Universe.** `Type u_1`, polymorphic. My `endpoint_universe_one` instantiates at `ULift.{1} (Fin 5)`, `endpoint_generic_type` at an arbitrary `α : Type`.

Note: the Lean uses the spectral form of BH. The source prints the double-distance form as equal to it. The equivalence is the routine `½ΣΣ (e_u-e_v)ᵀ L⁺² (e_u-e_v) = n tr L⁺²`, and I did not formalize it. This matches the task's stated definition.

## Gate E: semantic controls: PASS

`BiHControl1` imports only `BiHBase`, plus Mathlib tactics; `BiHControl2` imports `BiHControl1`. Neither touches the authors' proof chain. I derive exact values from the literal eigenvalues by proving `tr(A^k) = Σλ^k` from the spectral theorem and applying Newton's identities to exact integer power traces of hand-written Laplacians. Those Laplacians are checked entrywise against the literal `degree` and `Adj` by `decide +kernel`.

Hand-derived values and Lean results:

| Tree | Spectrum / traces | Value |
|---|---|---|
| K₂ | 0, 2 | **1/2** (`bh_K2`) |
| K_{1,4} | power traces 8, 28, 128, 628, 3128 | **76/5** (`star5_value`), exactly one zero eigenvalue |
| P₅ | 8, 22, 68, 222, 748 | **38** (`path5_value`), one zero |
| Fork (edges 01,12,23,24) | 8, 24, 86, 332, 1328 | **124/5** (`fork5_value`), one zero |

`fork5_between` shows `76/5 < 124/5 < 38`.

- `star5_not_other_models` proves `bh star5 ≠ 76/25` (no factor n), `≠ 16` (power 1) and `≠ 26/5` (eigenvalue 1 deduplicated, so multiplicity lost).
- A control with `⁻¹` power 1 (`Σ λ⁻¹ = 16/5`) is also computed.
- `BiHControlNegA` (false: no factor n) was rejected as expected.
- The dropped-zero point: because `(0:ℝ)⁻¹ = 0`, leaving a zero term in the sum would change nothing in Lean. What does matter is that exactly one eigenvalue is zero, which is proved.

`BiHControl3` ties these to the endpoint: applied to the fork it yields `¬ Nonempty` of isomorphism to star and path, and `bhPath_value 5` (the authors' double sum) equals my independently derived 38.

Also, `brute_force_trees_33` is an exact-rational check over all free trees up to n=13 (2,287 trees, matching the known counts 1,1,2,3,6,11,23,47,106,235,551,1301). Star is the unique minimizer and path the unique maximizer at every n ≥ 4 tested, with no violations. n = 2 and 3 are the single-tree cases. This is sanity only, not proof.

## Gate F: live prior art: bounded, no match found, INCOMPLETE

I read `inherited-denials.json` completely, in 24 contiguous chunks of at most 13,800 characters, before any network use. Two searches and two query strings of the four allowed, each precharged and saved verbatim as the next tool call (`search/plan*.json`, `search/response*.txt`). No GET requests were made.

Neither search surfaced a proof or disproof of Lin Conjecture 5.3 or Wei-Li-Yang Problem 6.3, or any theorem on reciprocal Laplacian moments of trees implying it. Zhou-Gutman-type extremal Laplacian coefficient results exist but do not imply this: BH = W²/n − 2c₃ with both W and c₃ rising toward the path, so coefficient monotonicity gives neither inequality.

**The item at MATCH 91(2) 285-286 remains unread. Its identity is unknown to me, it is closed under the inherited denials, and I did not try to reach it by any route or query.** If it bears on this conjecture the pass must be revisited, as root already recorded.

Unread and not ruled out:

- arXiv 2302.10491v1 and 2107.09162, which surfaced in search and whose content I did not read; one snippet-level summary says a separate arXiv paper covers the biharmonic index and Laplacian spectral ratio.
- A sum-of-powers paper at pure.skku.edu with sharp bounds for general real α.
- The sum-of-powers papers WLY names: Zhou LAA 429 (2008), Liu-Liu AML 24 (2011), Das-Xu-Liu LAA 439 (2013), Chen-Das DM 338 (2015). From memory only, and unverified, some of these treat trees for some ranges of α. If any covers α = −2 for trees it would matter, and I would have root check Zhou 2008 specifically.
- MathSciNet, zbMATH, Google Scholar and citing-work indexes of AIMS 2022: not covered.

This is not a worldwide novelty claim.

## Gate G: science: my own view: modest, borderline, not excluded by the campaign rule

**Strongest case for routine.** Given the edge-pair formula, which follows from classical data (BH = W²/n − 2c₃ with Kelmans' forest count), the lower bound is termwise with no obstacle and the upper bound is a shift identity. It is the Wiener-index proof one moment higher. The shift has no case analysis to speak of.

**Strongest case against.** A deliberate conjecture in a peer-reviewed paper, retained through revision and concretizing an explicitly open problem, settled in full with both equality characterizations. Coefficient monotonicity fails by sign and majorization fails for n ≥ 5. No published theorem or source-owned argument I read implies it, and no complete bridge exists. The campaign's routine exclusions (350767, 336276, 341690, 368315, 362080) each rested on a concrete reduction to a source or published theorem. Here only a template analogy is on the table.

**Does the formal route change my view?** Only slightly, and in the routine direction. `shift_increases` moves any subtree Q hanging off the end of any leaf chain to the far end. Only the chain edges' sides change (each gains Q), and everything reduces to `H_closed` and `rest_closed`. No deepest-branching choice, no two-pendant-paths structure and no relation between parameters are needed. That robustness supports the no-obstacle objection and adds no new invariant. Against that, it is not purely termwise: for an edge inside Q the individual terms `((n-i-1-m)a)² − ((i+1)a)²` can be negative and only the sum is nonnegative (`rest_closed`), and the closed form `H_closed` is a genuine computation. I would not call that a new idea.

I do not recommend exclusion on the analogy alone. But note the campaign's own lesson from 336276: a first creditable qualification is not reliable until a second adversarial pass has tried for a generic proof. This target has had one qualification. Root may want that second pass, and the Gate F citation checks, before crediting.

## Defects

| # | Severity | Detail |
|---|---|---|
| 1 | cosmetic | `BiHInc` header claims "full column rank for a tree"; no such theorem is in the module and none is needed |
| 2 | cosmetic | `BiHPathValue` calls `bhPath_four` and `bhStar_four` "negative controls"; they are positive value checks |
| 3 | low (documentary) | The Lean uses only the spectral form of BH; the double-distance form the source prints as equal is not formalized |

Defects affecting validity or fidelity: **0**.

## What I did not check, and process disclosures

- Upstream oleans are trusted, as `PINS.json` states. Mathlib metadata hashes match `PINS.json`, and the Lean version and githash come from Lean itself. The pinned mathlib commit itself was not independently confirmed: no git is allowed here and `lake-manifest.json` does not contain it.
- I did not read `inputs/author-candidate.md`, `inputs/author-formal-plan.md` or `inputs/lean-results.json`. I read `inputs/lean-SUMMARY.md`, `qualification-PROOF.md` and `qualification-REVIEW.md`.
- Independence caveat: the qualification reviewer and at least one author lane are also Claude Opus 5.5, so this is independent work but not independent of model family.
- Peer and author lanes were not touched.
- Retained failures, each with its true exit: `audit_axioms_compile_21` (250), `control1_compile_24` (1, deprecated `if_pos`/`if_neg`), `control2_compile_27` (1, `Decidable` synthesis, generalization, linter), and the two expected failures `neg_a_expected_fail_31` and `neg_b_expected_fail_32` (1). Every fix was a changed source; there were no unchanged retries.
- Display limit overruns: four single-run displays exceeded 15,000 characters counting the echoed receipt: `read_helpers_1` (18,959), `control1_compile_24` (16,944), `read_mathlib_defs_17` (17,029), `read_denials_0` (15,083). Some multi-run tool calls combining four Lean runs came close to or may have passed the limit in aggregate. Nothing was truncated by this, and the instruction was still not fully kept.
- Resource peaks are sampled only; native, transient and writer peaks are unknown.
- Search queries totalled two strings of the four allowed; I did not use the other two.
- Authored Lean and text files were written through `write_lane.py` directly with heredocs, not all under `run.py`, as TASK.txt permits for authored files.
