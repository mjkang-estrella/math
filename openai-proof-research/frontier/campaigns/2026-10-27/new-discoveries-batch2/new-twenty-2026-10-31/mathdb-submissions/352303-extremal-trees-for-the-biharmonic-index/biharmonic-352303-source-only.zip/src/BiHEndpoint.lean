/-
BiHEndpoint: the literal extremal biharmonic index theorem for trees on `n ≥ 5` vertices.

MathDB 352303 (Z. Lin, arXiv:2110.09931, Conjecture 5.3):
`BH(K_{1,n-1}) ≤ BH(T_n) ≤ BH(P_n)`, with equality on the left iff `T_n ≅ K_{1,n-1}` and on the
right iff `T_n ≅ P_n`.
-/
import BiHShiftB
import Mathlib.Data.Set.Finite.Lattice

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- `bh` does not depend on the decidability instance. -/
theorem bh_inst {G : SimpleGraph V} (i1 i2 : DecidableRel G.Adj) :
    @bh V _ _ G i1 = @bh V _ _ G i2 := by
  have h : i1 = i2 := Subsingleton.elim _ _
  rw [h]

/-- The biharmonic index with a canonical classical decidability instance. -/
noncomputable def bhC (G : SimpleGraph V) : ℝ := @bh V _ _ G (Classical.decRel _)

theorem bh_eq_bhC (G : SimpleGraph V) [DecidableRel G.Adj] : bh G = bhC G :=
  bh_inst _ _

theorem bhC_eq_of_iso {H : SimpleGraph V} {W : Type*} [Fintype W] [DecidableEq W]
    {P : SimpleGraph W} [DecidableRel P.Adj] (hH : H.IsTree) (ψ : H ≃g P) : bhC H = bh P := by
  classical
  exact (bh_inst (Classical.decRel _) _).trans (bh_congr_iso hH ψ)

/-- A maximizer of the biharmonic index among trees exists. -/
theorem exists_maximizer {G : SimpleGraph V} (hG : G.IsTree) :
    ∃ H : SimpleGraph V, H.IsTree ∧ ∀ T : SimpleGraph V, T.IsTree → bhC T ≤ bhC H :=
  Set.exists_max_image {T : SimpleGraph V | T.IsTree} bhC (Set.toFinite _) ⟨G, hG⟩

/-- A maximizing tree is a path. -/
theorem iso_path_of_maximal {n : ℕ} (hV : Fintype.card V = n) (hn : 2 ≤ n) {H : SimpleGraph V}
    (hH : H.IsTree) (hmax : ∀ T : SimpleGraph V, T.IsTree → bhC T ≤ bhC H) :
    Nonempty (H ≃g pathGraphFin n) := by
  classical
  haveI : Nontrivial V := Fintype.one_lt_card_iff_nontrivial.mp (by omega)
  obtain ⟨y, hy⟩ := hH.exists_vert_degree_one_of_nontrivial
  rw [SimpleGraph.degree_eq_one_iff_existsUnique_adj] at hy
  obtain ⟨v, hv, huniq⟩ := hy
  obtain ⟨k, x, hk, hx0, hc, hcase⟩ := exists_chain y v hv (fun u hu => huniq u hu)
  rcases hcase with hfull | ⟨c, b, hc1, hb1, hcb, hc2, hb2⟩
  · exact iso_path_of_full hV hH.connected.preconnected hc hk hfull
  · exfalso
    have d : ShiftData H k x c b := ⟨hc, hk, hc1, hb1, hcb, hc2, hb2⟩
    obtain ⟨G', hG', inst, hlt⟩ := @shift_increases V _ _ H (Classical.decRel _) hH k x c b d
    have h2 := hmax G' hG'
    have e1 : @bh V _ _ G' inst = bhC G' := bh_inst inst (Classical.decRel _)
    have h3 : bhC H < bhC G' := by
      rw [← e1]
      exact hlt
    exact absurd h2 (not_le.mpr h3)

/-- **The extremal biharmonic index theorem for trees (MathDB 352303).** For every `n ≥ 5`, every
finite vertex type `V` of cardinality `n` and every tree `G` on `V`:
`BH(K_{1,n-1}) ≤ BH(G) ≤ BH(P_n)`, with equality on the left iff `G ≅ K_{1,n-1}` and on the
right iff `G ≅ P_n`. -/
theorem bh_endpoint (n : ℕ) (hn : 5 ≤ n) (hV : Fintype.card V = n) (G : SimpleGraph V)
    [DecidableRel G.Adj] (hG : G.IsTree) :
    bhStar n (by omega) ≤ bh G ∧ bh G ≤ bhPath n ∧
      (bh G = bhStar n (by omega) ↔ Nonempty (G ≃g starGraphFin n (by omega))) ∧
      (bh G = bhPath n ↔ Nonempty (G ≃g pathGraphFin n)) := by
  classical
  have hn0 : 0 < n := by omega
  have hcardV : (Fintype.card V : ℝ) = (n : ℝ) := by exact_mod_cast hV
  have hstarVal : bhStar n hn0 = starN (n : ℝ) / (n : ℝ) := by
    unfold bhStar starGraphFin
    rw [bh_eq_starN_of_allPendant (SimpleGraph.isTree_starGraph _)
      (allPendant_starGraph _), Fintype.card_fin]
  obtain ⟨H, hH, hmax⟩ := exists_maximizer hG
  obtain ⟨ψ⟩ := iso_path_of_maximal hV (by omega) hH hmax
  have hHval : bhC H = bhPath n := bhC_eq_of_iso hH ψ
  refine ⟨?_, ?_, ⟨?_, ?_⟩, ⟨?_, ?_⟩⟩
  · rw [hstarVal, ← hcardV]
    exact starN_div_le_bh hG
  · rw [← hHval, bh_eq_bhC]
    exact hmax G hG
  · intro h
    rw [hstarVal, ← hcardV] at h
    exact iso_star_of_allPendant hV hn0 (by omega) hG (allPendant_of_bh_eq hG h)
  · rintro ⟨φ⟩
    exact bh_congr_iso hG φ
  · intro h
    apply iso_path_of_maximal hV (by omega) hG
    intro T hT
    rw [← bh_eq_bhC G, h, ← hHval]
    exact hmax T hT
  · rintro ⟨φ⟩
    exact bh_congr_iso hG φ

end BiH
