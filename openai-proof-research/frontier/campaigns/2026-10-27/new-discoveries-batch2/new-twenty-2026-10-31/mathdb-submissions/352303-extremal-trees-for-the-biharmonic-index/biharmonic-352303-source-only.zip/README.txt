Extremal trees for the biharmonic index - MathDB 352303 - source-only certificate

This archive contains the 17 Lean modules whose final theorem is BiH.bh_endpoint, in src/, plus audit and control modules in audit/. PINS.json gives Lean 4.34.1, mathlib d13f23b723b8a846827a245b89c10fc7d3f11612 and executable hashes. Upstream libraries are trusted read-only.

To rebuild: create an empty build directory, set LEAN_PATH to build followed by the pinned mathlib and dependency library paths, then for each module in BUILD-ORDER.json in order run lean -j1 -M3500 -DwarningAsError=true -o build/MODULE.olean src/MODULE.lean and leanchecker MODULE, with LEAN_NUM_THREADS=1. Use specific imports as shipped. A 6 GiB address-space limit is too small for this toolchain's import mapping; the checked runs used 32 GiB of address space and a 6 GiB real-memory guard. No olean is shipped. SOURCE-HASHES.json binds every production source.

An independent reviewer performed a fresh extracted replay of all 17 modules from an empty build. Only propext, Classical.choice and Quot.sound are transitive axioms over a closure of 36,296 constants. See FINAL-REVIEW.md and review.json.

Limits: bounded prior-art search with no citation index; Zhou LAA 429 (2008), Liu-Liu AML 24 (2011), Das-Xu-Liu LAA 439 (2013) and Chen-Das DM 338 (2015) were not read; a two-page item at MATCH 91(2) 285-286 surfaced in a search, is unread and unidentified, and could bear on this problem; only the spectral form of BH is formalized; upstream libraries were not rebuilt; no peer review, priority or worldwide novelty is claimed.
