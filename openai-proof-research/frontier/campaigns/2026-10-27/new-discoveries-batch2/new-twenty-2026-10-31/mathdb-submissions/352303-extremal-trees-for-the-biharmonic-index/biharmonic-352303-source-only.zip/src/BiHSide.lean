/-
BiHSide: sides of tree edges and the orientation-free form of the edge-pair formula.

`IsSide G e A` says that `e` has exactly one end in `A` and that no other edge of `G` crosses `A`.
For a connected graph this determines `A` up to complement, and `tau` is invariant under
complementing either argument, so `bh_eq_formula` holds for any choice of sides and any indexing
of the edges.

MathDB 352303 (Z. Lin, arXiv:2110.09931).
-/
import BiHFormula

namespace BiH

set_option linter.unusedSectionVars false
set_option linter.style.haveILetI false

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- `A` is a side of the edge `e` of `G`. -/
def IsSide (G : SimpleGraph V) (e : Sym2 V) (A : Finset V) : Prop :=
  (∃ a b, e = s(a, b) ∧ a ∈ A ∧ b ∉ A) ∧ ∀ u v, G.Adj u v → s(u, v) ≠ e → (u ∈ A ↔ v ∈ A)

/-- The squared Gram entry of two vertex sets. -/
noncomputable def tau (A B : Finset V) : ℝ :=
  ((Fintype.card V : ℝ) * ((A ∩ B).card : ℝ) - (A.card : ℝ) * (B.card : ℝ)) ^ 2

theorem tau_comm (A B : Finset V) : tau A B = tau B A := by
  unfold tau
  rw [Finset.inter_comm A B]
  ring

theorem card_compl_inter (A B : Finset V) : (Aᶜ ∩ B).card + (A ∩ B).card = B.card := by
  have h := Finset.card_sdiff_add_card_inter B A
  have h2 : B \ A = Aᶜ ∩ B := by
    ext v
    simp [and_comm]
  rw [h2, Finset.inter_comm B A] at h
  exact h

theorem tau_compl_left (A B : Finset V) : tau Aᶜ B = tau A B := by
  unfold tau
  have h1 : (((Aᶜ ∩ B).card : ℕ) : ℝ) = (B.card : ℝ) - ((A ∩ B).card : ℝ) := by
    have h := card_compl_inter A B
    have h' : ((Aᶜ ∩ B).card : ℝ) + ((A ∩ B).card : ℝ) = (B.card : ℝ) := by exact_mod_cast h
    linarith
  have h2 : ((Aᶜ.card : ℕ) : ℝ) = (Fintype.card V : ℝ) - (A.card : ℝ) := by
    have h : (A.card : ℝ) + (Aᶜ.card : ℝ) = (Fintype.card V : ℝ) := by
      exact_mod_cast Finset.card_add_card_compl A
    linarith
  rw [h1, h2]
  ring

theorem tau_compl_right (A B : Finset V) : tau A Bᶜ = tau A B := by
  rw [tau_comm, tau_compl_left, tau_comm]

theorem IsSide.compl {G : SimpleGraph V} {e : Sym2 V} {A : Finset V} (h : IsSide G e A) :
    IsSide G e Aᶜ := by
  obtain ⟨⟨a, b, he, ha, hb⟩, h2⟩ := h
  refine ⟨⟨b, a, by rw [he, Sym2.eq_swap], by simpa using hb, by simpa using ha⟩, ?_⟩
  intro u v huv hne
  simp only [Finset.mem_compl]
  exact not_congr (h2 u v huv hne)

theorem exists_pair (z : Sym2 V) : ∃ a b, z = s(a, b) := by
  induction z using Sym2.ind with
  | _ a b => exact ⟨a, b, rfl⟩

/-- A predicate preserved along edges holds at the end of every walk. -/
theorem walk_prop {G : SimpleGraph V} {P : V → Prop} (h : ∀ u v, G.Adj u v → P u → P v)
    {u v : V} (p : G.Walk u v) (hu : P u) : P v := by
  induction p with
  | nil => exact hu
  | cons hadj p ih => exact ih (h _ _ hadj hu)

/-- Two sides of `e` containing the same end coincide. -/
theorem side_eq_of_same_end {G : SimpleGraph V} (hconn : G.Preconnected) {e : Sym2 V}
    {A B : Finset V} (hA : IsSide G e A) (hB : IsSide G e B) {a b : V} (he : e = s(a, b))
    (haA : a ∈ A) (hbA : b ∉ A) (haB : a ∈ B) (hbB : b ∉ B) : A = B := by
  have key : ∀ u v, G.Adj u v → (u ∈ A ↔ u ∈ B) → (v ∈ A ↔ v ∈ B) := by
    intro u v huv h
    by_cases huve : s(u, v) = e
    · rw [he, Sym2.eq_iff] at huve
      rcases huve with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
      · exact ⟨fun h => absurd h hbA, fun h => absurd h hbB⟩
      · exact ⟨fun _ => haB, fun _ => haA⟩
    · rw [← hA.2 u v huv huve, ← hB.2 u v huv huve]
      exact h
  ext v
  obtain ⟨p⟩ := hconn a v
  exact walk_prop (P := fun z => z ∈ A ↔ z ∈ B) key p ⟨fun _ => haB, fun _ => haA⟩

/-- Two sides of the same edge agree up to complement. -/
theorem side_eq_or_compl {G : SimpleGraph V} (hconn : G.Preconnected) {e : Sym2 V}
    {A B : Finset V} (hA : IsSide G e A) (hB : IsSide G e B) : A = B ∨ A = Bᶜ := by
  obtain ⟨a, b, he, ha, hb⟩ := hA.1
  obtain ⟨a', b', he', ha', hb'⟩ := hB.1
  have h := he.symm.trans he'
  rw [Sym2.eq_iff] at h
  rcases h with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
  · exact Or.inl (side_eq_of_same_end hconn hA hB he ha hb ha' hb')
  · exact Or.inr (side_eq_of_same_end hconn hA hB.compl he ha hb
      (by simpa using hb') (by simpa using ha'))

theorem tau_congr_side {G : SimpleGraph V} (hconn : G.Preconnected) {e f : Sym2 V}
    {A A' B B' : Finset V} (hA : IsSide G e A) (hA' : IsSide G e A')
    (hB : IsSide G f B) (hB' : IsSide G f B') : tau A B = tau A' B' := by
  rcases side_eq_or_compl hconn hA hA' with rfl | rfl <;>
    rcases side_eq_or_compl hconn hB hB' with rfl | rfl <;>
    simp [tau_compl_left, tau_compl_right]

section

variable {G : SimpleGraph V} [DecidableRel G.Adj] [Fintype G.edgeSet]

/-- The side `cutSet` as a finset. -/
noncomputable def cutFin (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) : Finset V := by
  classical exact Finset.univ.filter (fun v : V => v ∈ cutSet c e)

theorem mem_cutFin (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) (v : V) :
    v ∈ cutFin c e ↔ v ∈ cutSet c e := by
  classical
  simp [cutFin]

theorem card_cutFin (c : G.Coloring (Fin 2)) (e : ↥G.edgeFinset) :
    (cutFin c e).card = cutSize c e := rfl

theorem card_inter_cutFin (c : G.Coloring (Fin 2)) (e f : ↥G.edgeFinset) :
    (cutFin c e ∩ cutFin c f).card = interSize c e f := by
  classical
  simp only [interSize]
  congr 1
  ext v
  simp [mem_cutFin]

theorem isSide_cutFin (c : G.Coloring (Fin 2)) (hG : G.IsTree) (e : ↥G.edgeFinset) :
    IsSide G (e : Sym2 V) (cutFin c e) := by
  classical
  obtain ⟨a, b, hpair⟩ := exists_pair (e : Sym2 V)
  have he : (e : Sym2 V) ∈ G.edgeSet := G.mem_edgeFinset.mp e.2
  have hab : G.Adj a b := by
    rw [hpair] at he
    exact he
  obtain ⟨ha, hb⟩ := mem_cutSet_pair c hG hab e hpair
  have hpe : posEnd c e ∈ s(a, b) := by
    rw [← hpair]
    exact posEnd_mem c e
  rw [Sym2.mem_iff] at hpe
  refine ⟨?_, ?_⟩
  · rcases hpe with h1 | h1
    · refine ⟨a, b, hpair, (mem_cutFin c e a).mpr (ha.mpr h1.symm), ?_⟩
      intro hb'
      have := hb.mp ((mem_cutFin c e b).mp hb')
      exact hab.ne (h1.symm.trans this.symm)
    · refine ⟨b, a, by rw [hpair, Sym2.eq_swap], (mem_cutFin c e b).mpr (hb.mpr h1.symm), ?_⟩
      intro ha'
      have := ha.mp ((mem_cutFin c e a).mp ha')
      exact hab.ne (this.trans h1)
  · intro u v huv hne
    rw [mem_cutFin, mem_cutFin]
    exact reachable_iff_of_ne huv hne (posEnd c e)

theorem tau_cutFin (c : G.Coloring (Fin 2)) (e f : ↥G.edgeFinset) :
    tau (cutFin c e) (cutFin c f)
      = ((Fintype.card V : ℝ) * (interSize c e f : ℝ)
          - (cutSize c e : ℝ) * (cutSize c f : ℝ)) ^ 2 := by
  unfold tau
  rw [card_inter_cutFin, card_cutFin, card_cutFin]

end

/-- **The orientation-free edge-pair formula**: any indexing of the edges and any choice of sides. -/
theorem bh_eq_family {G : SimpleGraph V} [DecidableRel G.Adj] (hG : G.IsTree) {ι : Type*}
    [Fintype ι] (ε : ι → Sym2 V) (hmem : ∀ i, ε i ∈ G.edgeSet)
    (hbij : ∀ e ∈ G.edgeSet, ∃! i, ε i = e) (S : ι → Finset V)
    (hS : ∀ i, IsSide G (ε i) (S i)) :
    bh G = (∑ i, ∑ j, tau (S i) (S j)) / (Fintype.card V : ℝ) := by
  classical
  rw [bh_eq_formula hG]
  congr 1
  let f : ι → ↥G.edgeFinset := fun i => ⟨ε i, G.mem_edgeFinset.mpr (hmem i)⟩
  have hf : Function.Bijective f := by
    constructor
    · intro i j hij
      have h : ε i = ε j := congrArg Subtype.val hij
      exact ExistsUnique.unique (hbij _ (hmem j)) h rfl
    · rintro ⟨e, he⟩
      obtain ⟨i, hi, _⟩ := hbij e (G.mem_edgeFinset.mp he)
      exact ⟨i, Subtype.ext hi⟩
  have hterm : ∀ i j, tau (S i) (S j)
      = ((Fintype.card V : ℝ) * (interSize hG.coloringTwo (f i) (f j) : ℝ)
        - (cutSize hG.coloringTwo (f i) : ℝ) * (cutSize hG.coloringTwo (f j) : ℝ)) ^ 2 := by
    intro i j
    rw [tau_congr_side hG.connected.preconnected (hS i) (isSide_cutFin hG.coloringTwo hG (f i))
      (hS j) (isSide_cutFin hG.coloringTwo hG (f j))]
    exact tau_cutFin _ _ _
  symm
  refine Fintype.sum_bijective f hf _ _ (fun i => ?_)
  exact Fintype.sum_bijective f hf _ _ (fun j => hterm i j)

end BiH
