/-
AuditPrint: reviewer-authored `#print axioms` and statement display. No explicit `import Lean`.
-/
import BiHPathValue

#print axioms BiH.bh_endpoint
#print axioms BiH.shift_increases
#print axioms BiH.exists_maximizer
#print axioms BiH.iso_path_of_maximal
#print axioms BiH.starN_div_le_bh
#print axioms BiH.iso_star_of_allPendant
#print axioms BiH.bhPath_value

#check @BiH.bh_endpoint
#print BiH.bh
#print BiH.lapEigs
#print BiH.bhStar
#print BiH.bhPath
#print BiH.starGraphFin
#print BiH.pathGraphFin
