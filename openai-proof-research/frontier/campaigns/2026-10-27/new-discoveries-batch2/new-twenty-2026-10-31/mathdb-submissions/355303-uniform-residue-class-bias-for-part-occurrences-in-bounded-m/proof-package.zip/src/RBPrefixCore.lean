import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Tactic.SplitIfs
namespace RBPrefix
open Polynomial
open scoped BigOperators
def weight (mark : Bool) (j : Nat) : Int := if mark then j else 1
def coeffRun (k : Nat) : List (Nat × Bool) → Nat → Int
| [], n => if n = 0 then 1 else 0
| (h,b)::hs, n => ∑ j ∈ Finset.range k, if j*h ≤ n then weight b j * coeffRun k hs (n-j*h) else 0
noncomputable def poly (k : Nat) : List (Nat × Bool) → Polynomial Int
| [] => 1
| (h,b)::hs => (∑ j ∈ Finset.range k, Polynomial.C (weight b j) * Polynomial.X^(j*h)) * poly k hs
theorem coeffRun_eq (k : Nat) (hs : List (Nat × Bool)) (n : Nat) :
  coeffRun k hs n = (poly k hs).coeff n := by
  induction hs generalizing n with
  | nil => simp [coeffRun, poly, Polynomial.coeff_one]
  | cons x hs ih =>
    rcases x with ⟨h,b⟩
    simp only [coeffRun, poly, Finset.sum_mul, Polynomial.finsetSum_coeff,
      mul_assoc, Polynomial.coeff_C_mul, Polynomial.coeff_X_pow_mul']
    simp only [← ih]
    apply Finset.sum_congr rfl
    intro j _
    split_ifs <;> simp_all
example : coeffRun 2 [(1,false),(2,false)] 3 = 1 := by decide
#print axioms coeffRun_eq
end RBPrefix
