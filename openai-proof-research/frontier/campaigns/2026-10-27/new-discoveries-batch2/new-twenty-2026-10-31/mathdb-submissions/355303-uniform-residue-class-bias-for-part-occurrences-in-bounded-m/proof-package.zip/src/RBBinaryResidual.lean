import RBCountMarked
import RBAbsorbResidual

noncomputable section
namespace RBBinary
open Finset PowerSeries

def allowed (h : ℕ) : Prop := h % 2 = 1 ∧ 9 ≤ h
instance (h : ℕ) : Decidable (allowed h) := inferInstanceAs (Decidable (_ ∧ _))
def factor (k h : ℕ) : PowerSeries ℤ := if allowed h then RBCount.Bf k h else 1
def residualCut (k N : ℕ) : PowerSeries ℤ := ∏ h ∈ Icc 1 N, factor k h

theorem coeff_factor (k h c : ℕ) (hh : 1 ≤ h) (hc : c < k) :
    coeff (c*h) (factor k h) = if allowed h ∨ c=0 then 1 else 0 := by
  by_cases ha : allowed h
  · simp [factor, ha, RBCount.coeff_Bf_mul k h c hh, hc]
  · simp [factor, ha, coeff_one, show h ≠ 0 by omega]

theorem support_factor (k h m : ℕ) (hk : 1 ≤ k) (hh : 1 ≤ h)
    (hm : coeff m (factor k h) ≠ 0) : h ∣ m ∧ m/h < k := by
  by_cases ha : allowed h
  · simp only [factor, ite_eq_left ha, RBCount.coeff_Bf k h m hh] at hm
    split_ifs at hm with h
    · exact h
    · contradiction
  · simp only [factor, ite_eq_right ha, coeff_one] at hm
    have hm0 : m=0 := by
      by_contra h
      simp [h] at hm
    subst m
    exact ⟨dvd_zero h, by simp only [Nat.zero_div]; omega⟩

theorem finite_weighted_count (k N n : ℕ) (hk : 1 ≤ k) (hn : n ≤ N) :
    coeff n (residualCut k N) =
      ∑ p ∈ Nat.Partition.countRestricted n k,
        ∏ h ∈ Icc 1 N, (if allowed h ∨ p.parts.count h = 0 then (1:ℤ) else 0) := by
  exact RBCount.coeff_prod_eq_sum_countRestricted hk hn (factor k)
    (fun h c => if allowed h ∨ c=0 then 1 else 0)
    (fun h hh c hc => coeff_factor k h c (mem_Icc.mp hh).1 hc)
    (fun h hh m hm => support_factor k h m hk (mem_Icc.mp hh).1 hm)

#print axioms finite_weighted_count
end RBBinary
