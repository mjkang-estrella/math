import RBWeakChain
import RBWeakAlg

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBWeakBinary (355303 uniform weak comparisons): `AdjWeakBinary`, unconditionally

`adjWeakBinary_holds : AdjWeakBinary` — for all `a ≥ 5` and all `n`: `C 2 (a+1) n ≤ C 2 a n`
(UNCHANGED prefix `C`). Non-exceptional pairs cancel the full chain of root `1`; if `2^w ∈ {a, a+1}`
then `2^w ≥ 8`, the chains of roots `3` and `5` are intact and `2^w = 3u + 5v` (coin kernel).
-/

namespace RBCount

/-- **G2.** -/
theorem adjWeakBinary_holds : AdjWeakBinary := by
  intro a n ha
  by_cases han : a + 1 ≤ n
  · by_cases hpow : ∃ w, 2 ^ w = a ∨ 2 ^ w = a + 1
    · obtain ⟨w, hx⟩ := hpow
      have hw3 : 3 ≤ w := by
        by_contra h
        have h1 : 2 ^ w ≤ 2 ^ 2 := Nat.pow_le_pow_right (by omega) (by omega)
        have h2 : (2 : ℕ) ^ 2 = 4 := by decide
        omega
      have hx8 : 8 ≤ 2 ^ w := by
        have h1 : 2 ^ 3 ≤ 2 ^ w := Nat.pow_le_pow_right (by omega) hw3
        have h2 : (2 : ℕ) ^ 3 = 8 := by decide
        omega
      have hxw : 2 ^ w = 2 ^ (w - 1) * 2 := by
        rw [← pow_succ, Nat.sub_add_cancel (by omega : 1 ≤ w)]
      have h4 : 4 ≤ 2 ^ (w - 1) := by
        have h1 : 2 ^ 2 ≤ 2 ^ (w - 1) := Nat.pow_le_pow_right (by omega) (by omega)
        have h2 : (2 : ℕ) ^ 2 = 4 := by decide
        omega
      have hlow : 2 ^ (w - 1) < a := by omega
      obtain ⟨u, v, huv⟩ : ∃ u v, 2 ^ w = 3 * u + 5 * v := by
        rcases (by omega : 2 ^ w % 3 = 0 ∨ 2 ^ w % 3 = 1 ∨ 2 ^ w % 3 = 2) with h | h | h
        · exact ⟨2 ^ w / 3, 0, by omega⟩
        · exact ⟨(2 ^ w - 10) / 3, 2, by omega⟩
        · exact ⟨(2 ^ w - 5) / 3, 1, by omega⟩
      exact weak_exc (p := 3) (q := 5) le_rfl (by omega) han (by omega) hx hlow (by omega)
        (by omega) (by decide) (by decide) (by decide)
        (fun _ => ⟨by omega, by omega⟩) (fun _ => ⟨by omega, by omega⟩)
        (NN_kernel_coin (by omega) (by omega) huv)
    · have hpow' : ∀ w, 2 ^ w ≠ a ∧ 2 ^ w ≠ a + 1 :=
        fun w => ⟨fun h => hpow ⟨w, Or.inl h⟩, fun h => hpow ⟨w, Or.inr h⟩⟩
      exact weak_NE le_rfl (by omega) han hpow'
  · rw [C_eq_zero_of_lt (by omega : n < a + 1)]
    exact Nat.zero_le _

end RBCount

#print axioms RBCount.adjWeakBinary_holds
