import RBAbsorbMinimum
noncomputable section
namespace RBAbsorb

def Fiber (n d : ℕ) := {s : Multiset ℕ // Valid s ∧ s.sum+d=n}
def fiberResidual {n d : ℕ} (p : Fiber n d) : Residual (n-d) :=
  ⟨⟨p.val, by intro i hi; have := (p.property.1 i hi).2; omega, by have := p.property.2; omega⟩, p.property.1⟩
theorem fiberResidual_injective (n d : ℕ) : Function.Injective (@fiberResidual n d) := by
  intro p q he
  exact Subtype.ext (congrArg (fun r => r.val.parts) he)
instance (n d : ℕ) : Fintype (Fiber n d) := Fintype.ofInjective fiberResidual (fiberResidual_injective n d)

def fiberEquiv (n d : ℕ) (hd : d≤n) : Fiber n d ≃ Residual (n-d) where
  toFun := fiberResidual
  invFun p := ⟨p.val.parts, p.property, by rw [p.val.parts_sum]; omega⟩
  left_inv _ := rfl
  right_inv p := by apply Subtype.ext; apply Nat.Partition.ext; rfl

def shifted (n d : ℕ) : ℤ := if d≤n then (count (n-d) : ℤ) else 0

theorem card_fiber (n d : ℕ) : (Fintype.card (Fiber n d) : ℤ) = shifted n d := by
  classical
  by_cases hd : d≤n
  · simp only [shifted, ite_eq_left hd]
    exact_mod_cast Fintype.card_congr (fiberEquiv n d hd)
  · have h : IsEmpty (Fiber n d) := ⟨by intro p; have := p.property.2; omega⟩
    let := h
    simp [shifted, hd]

theorem shifted_coeff (n d : ℕ) : shifted n d = PowerSeries.coeff n (PowerSeries.X^d * R) := by
  simp [shifted, PowerSeries.coeff_X_pow_mul', coeff_R]

def fiberLower {n d : ℕ} (p : Fiber n d) (w k : ℕ) (hw : w∈p.val)
    (hk : k%2=0) (hb : 9+k≤w) : Fiber n (d+k) :=
  ⟨lower p.val w k, lower_valid p.val w k p.property.1 hw hk hb, by
    have h := lower_weight p.val w k hw (by omega)
    have := p.property.2
    omega⟩
def fiberDelete {n d : ℕ} (p : Fiber n d) (w : ℕ) (hw : w∈p.val) : Fiber n (d+w) :=
  ⟨p.val.erase w, (fun x hx => p.property.1 x (Multiset.mem_of_mem_erase hx)), by
    have h := congrArg Multiset.sum (Multiset.cons_erase hw)
    simp only [Multiset.sum_cons] at h
    have := p.property.2
    omega⟩

theorem fiber_nonempty {n d : ℕ} (hd : d<n) (p : Fiber n d) : p.val ≠ 0 := by
  intro h
  have := p.property.2
  rw [h, Multiset.sum_zero] at this
  omega

def fmin {n d : ℕ} (hd : d<n) (p : Fiber n d) : ℕ :=
  Classical.choose (least_exists p.val (fiber_nonempty hd p))
theorem fmin_spec {n d : ℕ} (hd : d<n) (p : Fiber n d) : Least p.val (fmin hd p) :=
  Classical.choose_spec (least_exists p.val (fiber_nonempty hd p))
#print axioms card_fiber
end RBAbsorb
