import RBCountFactors
import RBCountOccurrence
import Mathlib.Algebra.BigOperators.GroupWithZero.Finset
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBCountMarked (355303 pilot B): exact finite marked-product coefficient identity

* `coeff_prod_eq_sum_countRestricted`: weight-preserving correspondence between
  `countRestricted n k` and the support of `coeff_prod` over `finsuppAntidiag (Icc 1 N) n`
  (public re-proof; Mathlib's GenFun helpers are private and are NOT used).
* `coeff_marked`: `coeff n (marked k a N) = C k a n` for `1 ≤ k`, `a ∈ [1,N]`, `n ≤ N`.
* `coeff_prodB`: `coeff n (prodB k N) = #(countRestricted n k)` for `1 ≤ k`, `n ≤ N`.
* stability in `N` and in `k`; `coeff_marked_sub`; truncation lemmas `coeff_mul_of_low_one`,
  `coeff_Bf_low`.  No infinite product, no topology, no Glaisher transport.
-/

namespace RBCount

open Finset

theorem toFinsuppAntidiag_apply' {n : ℕ} (p : n.Partition) (h : ℕ) :
    p.toFinsuppAntidiag h = p.parts.count h * h := rfl

theorem count_lt_of_mem_countRestricted {n k : ℕ} (hk : 1 ≤ k) {p : n.Partition}
    (hp : p ∈ Nat.Partition.countRestricted n k) (h : ℕ) : p.parts.count h < k := by
  by_cases hm : h ∈ p.parts
  · unfold Nat.Partition.countRestricted at hp
    rw [Finset.mem_filter] at hp
    exact hp.2 h hm
  · rw [count_eq_zero_of_not_mem' hm]
    omega

/-- Multiset assembled from a weight vector: each `h ∈ [1,N]` repeated `l h / h` times. -/
noncomputable def vecParts (N : ℕ) (l : ℕ →₀ ℕ) : Multiset ℕ :=
  ∑ h ∈ Icc 1 N, Multiset.replicate (l h / h) h

theorem count_vecParts (N : ℕ) (l : ℕ →₀ ℕ) (b : ℕ) :
    (vecParts N l).count b = if b ∈ Icc 1 N then l b / b else 0 := by
  unfold vecParts
  rw [Multiset.count_sum']
  simp only [Multiset.count_replicate]
  exact Finset.sum_ite_eq' (Icc 1 N) b (fun h => l h / h)

theorem mem_Icc_of_mem_vecParts {N : ℕ} {l : ℕ →₀ ℕ} {x : ℕ} (hx : x ∈ vecParts N l) :
    x ∈ Icc 1 N := by
  have h := Multiset.count_pos.mpr hx
  rw [count_vecParts] at h
  by_contra hn
  rw [ite_eq_right hn] at h
  exact Nat.lt_irrefl 0 h

theorem sum_vecParts {N : ℕ} {l : ℕ →₀ ℕ} (hdvd : ∀ h ∈ Icc 1 N, h ∣ l h) :
    (vecParts N l).sum = ∑ h ∈ Icc 1 N, l h := by
  unfold vecParts
  rw [Multiset.sum_sum]
  refine Finset.sum_congr rfl fun h hh => ?_
  simp only [Multiset.sum_replicate, smul_eq_mul, nsmul_eq_mul, Nat.cast_id]
  exact Nat.div_mul_cancel (hdvd h hh)

/-- Generic weight-preserving correspondence (bridge).  For factors `F h` (`h ∈ [1,N]`) whose
coefficient at `c * h` is `φ h c` for `c < k` and whose nonzero coefficients sit only at
multiples `c * h` with `c < k`, the degree-`n` coefficient (`n ≤ N`) of `∏ F h` is the sum over
`countRestricted n k` of `∏ φ h (multiplicity of h)`. -/
theorem coeff_prod_eq_sum_countRestricted {k N n : ℕ} (hk : 1 ≤ k) (hn : n ≤ N)
    (F : ℕ → PowerSeries ℤ) (φ : ℕ → ℕ → ℤ)
    (hF1 : ∀ h ∈ Icc 1 N, ∀ c, c < k → PowerSeries.coeff (c * h) (F h) = φ h c)
    (hF2 : ∀ h ∈ Icc 1 N, ∀ m, PowerSeries.coeff m (F h) ≠ 0 → h ∣ m ∧ m / h < k) :
    PowerSeries.coeff n (∏ h ∈ Icc 1 N, F h) =
      ∑ p ∈ Nat.Partition.countRestricted n k, ∏ h ∈ Icc 1 N, φ h (p.parts.count h) := by
  rw [PowerSeries.coeff_prod]
  symm
  apply Finset.sum_of_injOn (fun p : n.Partition => p.toFinsuppAntidiag)
  · intro p _ q _ hpq
    exact Nat.Partition.toFinsuppAntidiag_injective n hpq
  · intro p _
    exact Finset.mem_coe.mpr (Finset.finsuppAntidiag_mono
      (Finset.Icc_subset_Icc (le_refl 1) hn) n
      (Nat.Partition.toFinsuppAntidiag_mem_finsuppAntidiag p))
  · intro l hl hnot
    by_contra hne
    apply hnot
    have hne' := Finset.prod_ne_zero_iff.mp hne
    have hdiv : ∀ h ∈ Icc 1 N, h ∣ l h ∧ l h / h < k :=
      fun h hh => hF2 h hh (l h) (hne' h hh)
    obtain ⟨hlsum, hlsupp⟩ := Finset.mem_finsuppAntidiag.mp (Finset.mem_coe.mp hl)
    refine ⟨⟨vecParts N l, ?_, ?_⟩, ?_, ?_⟩
    · intro i hi
      have := Finset.mem_Icc.mp (mem_Icc_of_mem_vecParts hi)
      omega
    · rw [sum_vecParts (fun h hh => (hdiv h hh).1)]
      exact hlsum
    · rw [Finset.mem_coe]
      unfold Nat.Partition.countRestricted
      rw [Finset.mem_filter]
      refine ⟨Finset.mem_univ _, ?_⟩
      intro i hi
      have hiI := mem_Icc_of_mem_vecParts hi
      show (vecParts N l).count i < k
      rw [count_vecParts, ite_eq_left hiI]
      exact (hdiv i hiI).2
    · ext b
      show (vecParts N l).count b * b = l b
      rw [count_vecParts]
      split_ifs with hb
      · exact Nat.div_mul_cancel (hdiv b hb).1
      · have hlb : l b = 0 := by
          by_contra hlb
          exact hb (hlsupp (Finsupp.mem_support_iff.mpr hlb))
        rw [hlb, zero_mul]
  · intro p hp
    refine Finset.prod_congr rfl fun h hh => ?_
    rw [toFinsuppAntidiag_apply', hF1 h hh _ (count_lt_of_mem_countRestricted hk hp h)]

/-- (DESIGN M3.2) unmarked companion. -/
theorem coeff_prodB {k N n : ℕ} (hk : 1 ≤ k) (hn : n ≤ N) :
    PowerSeries.coeff n (prodB k N) = ((Nat.Partition.countRestricted n k).card : ℤ) := by
  unfold prodB
  rw [coeff_prod_eq_sum_countRestricted (φ := fun _ _ => 1) hk hn]
  · simp
  · intro h hh c hc
    show PowerSeries.coeff (c * h) (Bf k h) = 1
    rw [coeff_Bf_mul k h c (Finset.mem_Icc.mp hh).1, ite_eq_left hc]
  · intro h hh m hm
    exact dvd_of_coeff_Bf_ne_zero (Finset.mem_Icc.mp hh).1 hm

theorem marked_eq_prod {k a N : ℕ} (ha : a ∈ Icc 1 N) :
    marked k a N = ∏ h ∈ Icc 1 N, markedFactor k a h := by
  rw [← Finset.mul_prod_erase (Icc 1 N) (markedFactor k a) ha]
  unfold marked
  have h1 : markedFactor k a a = Af k a := by
    unfold markedFactor
    rw [ite_eq_left rfl]
  have h2 : ∏ x ∈ (Icc 1 N).erase a, markedFactor k a x = ∏ x ∈ (Icc 1 N).erase a, Bf k x :=
    Finset.prod_congr rfl fun h hh => by
      unfold markedFactor
      rw [ite_eq_right (Finset.ne_of_mem_erase hh)]
  rw [h1, h2]

/-- (DESIGN M3.1) exact marked coefficient identity. -/
theorem coeff_marked {k a N n : ℕ} (hk : 1 ≤ k) (ha : a ∈ Icc 1 N) (hn : n ≤ N) :
    PowerSeries.coeff n (marked k a N) = (C k a n : ℤ) := by
  rw [marked_eq_prod ha,
    coeff_prod_eq_sum_countRestricted (φ := fun h c => if h = a then (c : ℤ) else 1) hk hn]
  · unfold C
    rw [Nat.cast_sum]
    refine Finset.sum_congr rfl fun p _ => ?_
    rw [Finset.prod_eq_single_of_mem a ha]
    · show (if a = a then ((p.parts.count a : ℕ) : ℤ) else 1) = ((p.parts.count a : ℕ) : ℤ)
      rw [ite_eq_left rfl]
    · intro b _ hba
      show (if b = a then ((p.parts.count b : ℕ) : ℤ) else 1) = 1
      rw [ite_eq_right hba]
  · intro h hh c hc
    show PowerSeries.coeff (c * h) (markedFactor k a h) = if h = a then (c : ℤ) else 1
    unfold markedFactor
    by_cases hha : h = a
    · rw [ite_eq_left hha, ite_eq_left hha, hha, coeff_Af_mul k a c (Finset.mem_Icc.mp ha).1,
        ite_eq_left hc]
    · rw [ite_eq_right hha, ite_eq_right hha, coeff_Bf_mul k h c (Finset.mem_Icc.mp hh).1,
        ite_eq_left hc]
  · intro h hh m hm
    have hm' : PowerSeries.coeff m (markedFactor k a h) ≠ 0 := hm
    unfold markedFactor at hm'
    by_cases hha : h = a
    · rw [ite_eq_left hha] at hm'
      rw [hha]
      exact dvd_of_coeff_Af_ne_zero (Finset.mem_Icc.mp ha).1 hm'
    · rw [ite_eq_right hha] at hm'
      exact dvd_of_coeff_Bf_ne_zero (Finset.mem_Icc.mp hh).1 hm'

/-- Coefficient bridge for the adjacent marked difference. -/
theorem coeff_marked_sub {k a N n : ℕ} (hk : 1 ≤ k) (ha : 1 ≤ a) (haN : a + 1 ≤ N)
    (hn : n ≤ N) :
    PowerSeries.coeff n (marked k a N - marked k (a + 1) N) = (C k a n : ℤ) - C k (a + 1) n := by
  rw [map_sub, coeff_marked hk (Finset.mem_Icc.mpr ⟨ha, by omega⟩) hn,
    coeff_marked hk (Finset.mem_Icc.mpr ⟨by omega, haN⟩) hn]

/-- Stability of the marked coefficient in the cutoff `N`. -/
theorem coeff_marked_stable_N {k a N N' n : ℕ} (hk : 1 ≤ k) (ha : a ∈ Icc 1 N)
    (ha' : a ∈ Icc 1 N') (hn : n ≤ N) (hn' : n ≤ N') :
    PowerSeries.coeff n (marked k a N) = PowerSeries.coeff n (marked k a N') := by
  rw [coeff_marked hk ha hn, coeff_marked hk ha' hn']

/-- Stability of the unmarked coefficient in the cutoff `N`. -/
theorem coeff_prodB_stable_N {k N N' n : ℕ} (hk : 1 ≤ k) (hn : n ≤ N) (hn' : n ≤ N') :
    PowerSeries.coeff n (prodB k N) = PowerSeries.coeff n (prodB k N') := by
  rw [coeff_prodB hk hn, coeff_prodB hk hn']

/-- Stability of the marked coefficient in the multiplicity bound `k` (for `n < k, k'`). -/
theorem coeff_marked_stable_k {k k' a N n : ℕ} (hk : n < k) (hk' : n < k')
    (ha : a ∈ Icc 1 N) (hn : n ≤ N) :
    PowerSeries.coeff n (marked k a N) = PowerSeries.coeff n (marked k' a N) := by
  rw [coeff_marked (by omega) ha hn, coeff_marked (by omega) ha hn, C_stable hk hk']

/-- Truncation: a factor that is `≡ 1` through degree `n` does not change coefficient `n`. -/
theorem coeff_mul_of_low_one {n : ℕ} {G E : PowerSeries ℤ}
    (hE : ∀ j ≤ n, PowerSeries.coeff j E = if j = 0 then 1 else 0) :
    PowerSeries.coeff n (G * E) = PowerSeries.coeff n G := by
  rw [PowerSeries.coeff_mul, Finset.sum_eq_single (n, 0)]
  · show PowerSeries.coeff n G * PowerSeries.coeff 0 E = PowerSeries.coeff n G
    rw [hE 0 (Nat.zero_le n), ite_eq_left rfl, mul_one]
  · intro p hp hpn
    rw [Finset.mem_antidiagonal] at hp
    have h2 : p.2 ≠ 0 := by
      intro h0
      apply hpn
      ext
      · show p.1 = n
        omega
      · show p.2 = 0
        exact h0
    rw [hE p.2 (by omega), ite_eq_right h2, mul_zero]
  · intro hn
    exact absurd (Finset.mem_antidiagonal.mpr (by simp)) hn

/-- Truncation: a factor `Bf k h` with `h > j` is `≡ 1` at degree `j`. -/
theorem coeff_Bf_low {k h j : ℕ} (hk : 1 ≤ k) (hjh : j < h) :
    PowerSeries.coeff j (Bf k h) = if j = 0 then 1 else 0 := by
  rw [coeff_Bf k h j (by omega)]
  by_cases hj : j = 0
  · subst hj
    rw [ite_eq_left (show h ∣ 0 ∧ 0 / h < k from ⟨dvd_zero h, by rw [Nat.zero_div]; omega⟩),
      ite_eq_left rfl]
  · rw [ite_eq_right (show ¬ (h ∣ j ∧ j / h < k) from
        fun hd => hj (Nat.eq_zero_of_dvd_of_lt hd.1 hjh)), ite_eq_right hj]

end RBCount

#print axioms RBCount.coeff_prod_eq_sum_countRestricted
#print axioms RBCount.coeff_marked
#print axioms RBCount.coeff_prodB
#print axioms RBCount.coeff_marked_sub
#print axioms RBCount.coeff_marked_stable_N
#print axioms RBCount.coeff_marked_stable_k
#print axioms RBCount.coeff_mul_of_low_one
#print axioms RBCount.coeff_Bf_low
