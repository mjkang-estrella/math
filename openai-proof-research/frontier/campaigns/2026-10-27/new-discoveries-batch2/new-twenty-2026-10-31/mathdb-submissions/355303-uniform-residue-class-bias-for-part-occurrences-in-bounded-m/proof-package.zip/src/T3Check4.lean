import T3Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T3
theorem rec4_0 : ∀ n : Fin 15, tab (n.val+1680)=step tab (n.val+1680) := by decide
theorem rec4_1 : ∀ n : Fin 15, tab (n.val+1695)=step tab (n.val+1695) := by decide
theorem rec4_2 : ∀ n : Fin 15, tab (n.val+1710)=step tab (n.val+1710) := by decide
theorem rec4_3 : ∀ n : Fin 15, tab (n.val+1725)=step tab (n.val+1725) := by decide
theorem rec4_4 : ∀ n : Fin 15, tab (n.val+1740)=step tab (n.val+1740) := by decide
theorem rec4_5 : ∀ n : Fin 15, tab (n.val+1755)=step tab (n.val+1755) := by decide
theorem rec4_6 : ∀ n : Fin 15, tab (n.val+1770)=step tab (n.val+1770) := by decide
theorem rec4_7 : ∀ n : Fin 15, tab (n.val+1785)=step tab (n.val+1785) := by decide
theorem rec4_8 : ∀ n : Fin 15, tab (n.val+1800)=step tab (n.val+1800) := by decide
theorem rec4_9 : ∀ n : Fin 15, tab (n.val+1815)=step tab (n.val+1815) := by decide
theorem rec4_10 : ∀ n : Fin 15, tab (n.val+1830)=step tab (n.val+1830) := by decide
theorem rec4_11 : ∀ n : Fin 15, tab (n.val+1845)=step tab (n.val+1845) := by decide
theorem rec4_12 : ∀ n : Fin 15, tab (n.val+1860)=step tab (n.val+1860) := by decide
theorem rec4_13 : ∀ n : Fin 15, tab (n.val+1875)=step tab (n.val+1875) := by decide
theorem rec4_14 : ∀ n : Fin 15, tab (n.val+1890)=step tab (n.val+1890) := by decide
theorem rec4_15 : ∀ n : Fin 15, tab (n.val+1905)=step tab (n.val+1905) := by decide
theorem rec4_16 : ∀ n : Fin 15, tab (n.val+1920)=step tab (n.val+1920) := by decide
theorem rec4_17 : ∀ n : Fin 15, tab (n.val+1935)=step tab (n.val+1935) := by decide
theorem rec4_18 : ∀ n : Fin 15, tab (n.val+1950)=step tab (n.val+1950) := by decide
theorem rec4_19 : ∀ n : Fin 15, tab (n.val+1965)=step tab (n.val+1965) := by decide
theorem rec4_20 : ∀ n : Fin 15, tab (n.val+1980)=step tab (n.val+1980) := by decide
theorem rec4_21 : ∀ n : Fin 15, tab (n.val+1995)=step tab (n.val+1995) := by decide
theorem rec4_22 : ∀ n : Fin 15, tab (n.val+2010)=step tab (n.val+2010) := by decide
theorem rec4_23 : ∀ n : Fin 15, tab (n.val+2025)=step tab (n.val+2025) := by decide
theorem rec4_24 : ∀ n : Fin 15, tab (n.val+2040)=step tab (n.val+2040) := by decide
theorem rec4_25 : ∀ n : Fin 15, tab (n.val+2055)=step tab (n.val+2055) := by decide
theorem rec4_26 : ∀ n : Fin 15, tab (n.val+2070)=step tab (n.val+2070) := by decide
theorem rec4_27 : ∀ n : Fin 15, tab (n.val+2085)=step tab (n.val+2085) := by decide
theorem rec4 : ∀ n : Fin 420, tab (n.val+1680)=step tab (n.val+1680) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec4_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+1680=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec4_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+1695=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec4_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+1710=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec4_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+1725=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec4_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+1740=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec4_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+1755=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec4_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+1770=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec4_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+1785=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec4_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+1800=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec4_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+1815=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec4_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+1830=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec4_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+1845=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec4_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+1860=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec4_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+1875=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec4_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+1890=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec4_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+1905=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec4_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+1920=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec4_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+1935=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec4_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+1950=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec4_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+1965=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec4_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+1980=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec4_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+1995=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec4_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+2010=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec4_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+2025=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec4_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+2040=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec4_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+2055=n.val+1680 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec4_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+2070=n.val+1680 := by omega
    simpa only [he] using h
  have h := rec4_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+2085=n.val+1680 := by omega
  simpa only [he] using h
theorem rows4 : ∀ r : Fin 60,
  0 ≤ tab (r.val+240+2520) ∧
  0 ≤ tab (r.val+240+3360)-tab (r.val+240+2520) ∧
  0 ≤ tab (r.val+240+4200)-2*tab (r.val+240+3360)+tab (r.val+240+2520) ∧
  0 ≤ tab (r.val+240+5040)-3*tab (r.val+240+4200)+3*tab (r.val+240+3360)-tab (r.val+240+2520) := by decide
theorem pref4 : ∀ n : Fin 420, n.val+1680≠7 → n.val+1680≠12 → 0≤tab (n.val+1680) := by decide

#print axioms rec4
#print axioms rows4
#print axioms pref4
end T3
