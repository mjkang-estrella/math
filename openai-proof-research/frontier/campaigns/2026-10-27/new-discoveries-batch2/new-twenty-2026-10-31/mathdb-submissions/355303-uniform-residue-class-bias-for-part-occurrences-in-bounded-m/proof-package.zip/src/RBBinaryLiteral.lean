import RBBinaryResidual

noncomputable section
namespace RBBinary
open Finset PowerSeries

theorem count_le_sum (s : Multiset ℕ) (hs : ∀ x ∈ s, 1 ≤ x) (h : ℕ) :
    s.count h ≤ s.sum := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons a s ih =>
    have ha := hs a (by simp)
    have hi := ih (fun x hx => hs x (by simp [hx]))
    by_cases he : a=h
    · subst a
      simpa only [Multiset.count_cons_self, Multiset.sum_cons] using
        (show s.count h + 1 ≤ h+s.sum by omega)
    · simpa [he, Ne.symm he] using (show s.count h ≤ a+s.sum by omega)

theorem unrestricted (n k : ℕ) (hk : n < k) :
    Nat.Partition.countRestricted n k = univ := by
  ext p
  simp only [Nat.Partition.countRestricted, mem_filter, mem_univ, true_and, iff_true]
  intro h hh
  have hc := count_le_sum p.parts (fun x hx => p.parts_pos hx) h
  rw [p.parts_sum] at hc
  omega

theorem residual_weight {n N : ℕ} (hn : n ≤ N) (p : Nat.Partition n) :
    (∏ h ∈ Icc 1 N, (if allowed h ∨ p.parts.count h=0 then (1:ℤ) else 0)) =
      if (∀ w ∈ p.parts, allowed w) then 1 else 0 := by
  classical
  by_cases hp : ∀ w ∈ p.parts, allowed w
  · rw [ite_eq_left hp]
    apply prod_eq_one
    intro h hh
    by_cases hm : h ∈ p.parts
    · simp [hp h hm]
    · simp [hm]
  · rw [ite_eq_right hp]
    push Not at hp
    obtain ⟨w, hw, ha⟩ := hp
    apply prod_eq_zero (mem_Icc.mpr ⟨p.parts_pos hw, (Nat.Partition.le_of_mem_parts hw).trans hn⟩)
    have hc : p.parts.count w ≠ 0 := by
      have := Multiset.count_pos.mpr hw
      omega
    simp [ha,hc]

theorem residual_cutoff (n N k : ℕ) (hn : n ≤ N) (hk : n < k) :
    coeff n (residualCut k N) = coeff n RBAbsorb.R := by
  classical
  rw [finite_weighted_count k N n (by omega) hn, unrestricted n k hk]
  simp_rw [residual_weight hn]
  rw [RBAbsorb.coeff_R]
  have hc : RBAbsorb.count n =
      (univ.filter (fun p : Nat.Partition n => ∀ w ∈ p.parts, allowed w)).card := by
    exact Fintype.card_of_subtype (univ.filter (fun p : Nat.Partition n => ∀ w ∈ p.parts, allowed w)) (by intro p; simp only [mem_filter, mem_univ, true_and]; rfl)
  rw [hc]
  rw [Finset.card_filter]
  simp only [Nat.cast_sum, Nat.cast_ite, Nat.cast_one, Nat.cast_zero]

#print axioms residual_cutoff
end RBBinary
