import RBSharedSparse
namespace RBShared
open Polynomial
def unmarkedCheck (k N h : Nat) (p c : Nat → Int) : Bool :=
 (List.range (N+1)).all fun n => decide (c n - shift h c n = p n - shift (k*h) p n)
theorem unmarked_function_sound (k h N : Nat) (hh : 0 < h)
 (q : Polynomial Int) (p c : Nat → Int)
 (hp : ∀ n, n ≤ N → p n = q.coeff n)
 (hc : unmarkedCheck k N h p c = true) :
 ∀ n, n ≤ N → c n = (factor k h false*q).coeff n := by
 intro n
 induction n using Nat.strong_induction_on with
 | h n ih =>
  intro hn
  have he := (List.all_eq_true.mp hc) n (List.mem_range.mpr (by omega))
  simp only [decide_eq_true_eq] at he
  have hx : (1-X^h)*(factor k h false*q) = (1-X^(k*h))*q := by
   rw [←mul_assoc, factor_geometric]
  have ht := congrArg (fun t : Polynomial Int => t.coeff n) hx
  simp only [sub_mul, one_mul, Polynomial.coeff_sub, shifted_coeff] at ht
  have hs : shift h c n = shift h (factor k h false*q).coeff n := by
   unfold shift
   split_ifs
   · exact ih (n-h) (by omega) (by omega)
   · rfl
  rw [hs, hp n hn, shift_congr N (k*h) n _ _ hp hn] at he
  omega
theorem unmarked_transition (k N h : Nat) (r s : Nat → Int)
 (prev : RBStageFn.Sound k N (RBPrefix.factors h 0) r)
 (hc : unmarkedCheck k N (h+1) r s = true) :
 RBStageFn.Sound k N (RBPrefix.factors (h+1) 0) s := by
 have hp : ∀ n, n ≤ N → r n = (RBPrefix.poly k (RBPrefix.factors h 0)).coeff n := by
  intro n hn
  rw [prev n hn, RBPrefix.coeffRun_eq]
 intro n hn
 rw [RBPrefix.coeffRun_eq]
 have he : RBPrefix.poly k (RBPrefix.factors (h+1) 0) =
   factor k (h+1) false * RBPrefix.poly k (RBPrefix.factors h 0) := by
  simp [RBPrefix.factors, RBPrefix.poly, factor, RBPrefix.weight]
 rw [he]
 exact unmarked_function_sound k (h+1) N (by omega) _ r s hp hc n hn
#print axioms unmarked_transition
end RBShared
