import RBAbsorbFibers
noncomputable section
namespace RBAbsorb

theorem shifted_nonneg (n d : ℕ) : 0 ≤ shifted n d := by unfold shifted; split_ifs <;> positivity

theorem shifted_odd {n d : ℕ} (hb : d+9≤n) (ho : (n-d)%2=1) : 0<shifted n d := by
  rw [shifted, ite_eq_left (show d≤n by omega)]
  simpa only [coeff_R] using support_odd (n-d) ho (by omega)
theorem shifted_even {n d : ℕ} (hb : d+18≤n) (ho : (n-d)%2=0) : 0<shifted n d := by
  rw [shifted, ite_eq_left (show d≤n by omega)]
  simpa only [coeff_R] using support_even (n-d) ho (by omega)

theorem surplus1 (n : ℕ) (hn : 17≤n) : 0<shifted n 1 + shifted n 8 := by
  have h1 := shifted_nonneg n 1
  have h8 := shifted_nonneg n 8
  by_cases h17 : n=17
  · subst n
    have := shifted_odd (n:=17) (d:=8) (by omega) (by omega)
    omega
  · by_cases he : n%2=0
    · have := shifted_odd (n:=n) (d:=1) (by omega) (by omega)
      omega
    · have := shifted_even (n:=n) (d:=1) (by omega) (by omega)
      omega

theorem surplus2 (n : ℕ) (hn : 17≤n) : 0<shifted n 2 + shifted n 7 := by
  have h2 := shifted_nonneg n 2
  have h7 := shifted_nonneg n 7
  by_cases he : n%2=0
  · have := shifted_odd (n:=n) (d:=7) (by omega) (by omega)
    omega
  · have := shifted_odd (n:=n) (d:=2) (by omega) (by omega)
    omega

theorem surplus3 (n : ℕ) (hn : 17≤n) : 0<shifted n 3 + shifted n 8 := by
  have h3 := shifted_nonneg n 3
  have h8 := shifted_nonneg n 8
  by_cases he : n%2=0
  · have := shifted_odd (n:=n) (d:=3) (by omega) (by omega)
    omega
  · have := shifted_odd (n:=n) (d:=8) (by omega) (by omega)
    omega

theorem surplus4 (n : ℕ) (hn : 17≤n) : 0<shifted n 4 + shifted n 7 := by
  have h4 := shifted_nonneg n 4
  have h7 := shifted_nonneg n 7
  by_cases he : n%2=0
  · have := shifted_odd (n:=n) (d:=7) (by omega) (by omega)
    omega
  · have := shifted_odd (n:=n) (d:=4) (by omega) (by omega)
    omega
#print axioms surplus1
#print axioms surplus2
#print axioms surplus3
#print axioms surplus4
end RBAbsorb
