import T2Tail
noncomputable section
namespace T2
open PowerSeries
def sh (c : ℕ → ℤ) (d n : ℕ) : ℤ := if d≤n then c (n-d) else 0
def step (c : ℕ → ℤ) (n : ℕ) : ℤ := (if n=2 then 1 else 0)-(if n=4 then 1 else 0)+sh c 4 n+sh c 5 n+sh c 6 n+sh c 7 n-sh c 9 n-sh c 10 n-2*sh c 11 n-sh c 12 n-sh c 13 n+sh c 15 n+sh c 16 n+sh c 17 n+sh c 18 n-sh c 22 n
theorem original (n : ℕ) : coeff n rational = step (fun m => coeff m rational) n := by
  have he : denominator*rational = rational-(X^4*rational)-(X^5*rational)-(X^6*rational)-(X^7*rational)+(X^9*rational)+(X^10*rational)+2*(X^11*rational)+(X^12*rational)+(X^13*rational)-(X^15*rational)-(X^16*rational)-(X^17*rational)-(X^18*rational)+(X^22*rational) := by unfold denominator D; ring
  have h := congrArg (coeff n) denominator_rational
  rw [he] at h
  simp only [map_add,map_sub,coeff_ofNat_mul,coeff_X_pow_mul',numerator,coeff_X_pow] at h
  unfold step sh
  linear_combination h
theorem prefix_identification (t : ℕ → ℤ) (N : ℕ)
    (ht : ∀ n<N, t n=step t n) : ∀ n<N, coeff n rational=t n := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    intro hn
    have hsh : ∀ d, 0<d → sh (fun m => coeff m rational) d n=sh t d n := by
      intro d hd
      unfold sh
      split_ifs with hdn
      · exact ih (n-d) (by omega) (by omega)
      · rfl
    rw [original, ht n hn]
    simp only [step,hsh 4 (by decide),hsh 5 (by decide),hsh 6 (by decide),hsh 7 (by decide),hsh 9 (by decide),hsh 10 (by decide),hsh 11 (by decide),hsh 12 (by decide),hsh 13 (by decide),hsh 15 (by decide),hsh 16 (by decide),hsh 17 (by decide),hsh 18 (by decide),hsh 22 (by decide)]

#print axioms sh
#print axioms step
#print axioms original
#print axioms prefix_identification
end T2
