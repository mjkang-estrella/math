import RBPrefixEndpoint
namespace RBStage
open scoped BigOperators
open RBPrefix
def step (k N h : Nat) (b : Bool) (r : List Int) : List Int :=
 (List.range (N+1)).map (fun n => ∑ j ∈ Finset.range (cut k h n),
 if j*h ≤ n then weight b j * r.getD (n-j*h) 0 else 0)
def Sound (k N : Nat) (hs : List (Nat × Bool)) (r : List Int) : Prop :=
 ∀ n, n ≤ N → r.getD n 0 = coeffRun k hs n
theorem base (k N : Nat) : Sound k N [] ((List.range (N+1)).map (fun n => if n=0 then 1 else 0)) := by
 intro n hn
 simpa only [coeffRun] using get_map_range N n _ hn
theorem transition (k N h : Nat) (b : Bool) (hs : List (Nat × Bool))
 (r s : List Int) (prev : Sound k N hs r) (eqn : s = step k N h b r) :
 Sound k N ((h,b)::hs) s := by
 intro n hn
 rw [eqn]
 simp only [step, get_map_range N n _ hn, sum_cut, coeffRun]
 apply Finset.sum_congr rfl
 intro j _
 split_ifs with hj
 · rw [prev (n-j*h) (by omega)]
 · rfl
theorem factors_transition (k N h a : Nat) (r s : List Int)
 (prev : Sound k N (factors h a) r)
 (eqn : s = step k N (h+1) (h+1 == a) r) :
 Sound k N (factors (h+1) a) s := transition k N (h+1) _ _ r s prev eqn
theorem actual (k a n : Nat) (r : List Int)
 (hs : Sound k 142 (factors 142 a) r) (hn : n ≤ 142) :
 r.getD n 0 = (actualMarked k a).coeff n := by
 rw [hs n hn]
 exact count_meaning k a n
#print axioms transition
#print axioms actual
end RBStage
