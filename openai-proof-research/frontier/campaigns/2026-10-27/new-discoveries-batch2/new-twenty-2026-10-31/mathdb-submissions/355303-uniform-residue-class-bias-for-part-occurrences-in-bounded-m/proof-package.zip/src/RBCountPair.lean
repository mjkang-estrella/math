import RBCountMarked
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Ring

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBCountPair (355303 pilot B): difference factorisation and paired numerator

* `marked_sub` (DESIGN M3.3): finite-product difference factorisation.
* `pair_numerator` (DESIGN M3.4): `A_a B_{a+1} − A_{a+1} B_a = (1 − X) · pairF k a`, where
  `pairF k a = ∑_{i<k} ∑_{j<i} (i−j) X^((i+j)a+j) ∑_{e<i−j} X^e` (visibly nonnegative coefficients).
* `C_sub_C_succ_eq_coeff`: `C k a n − C k (a+1) n` as a coefficient of the finite factorised product.
These are helpers; NO adjacent comparison (W3/W2/S) is proved here.
-/

namespace RBCount

open Finset

theorem marked_sub {k a N : ℕ} (ha : 1 ≤ a) (haN : a + 1 ≤ N) :
    marked k a N - marked k (a + 1) N =
      (Af k a * Bf k (a + 1) - Af k (a + 1) * Bf k a) *
        ∏ h ∈ ((Icc 1 N).erase a).erase (a + 1), Bf k h := by
  have h1 : a + 1 ∈ (Icc 1 N).erase a :=
    Finset.mem_erase.mpr ⟨by omega, Finset.mem_Icc.mpr ⟨by omega, haN⟩⟩
  have h2 : a ∈ (Icc 1 N).erase (a + 1) :=
    Finset.mem_erase.mpr ⟨by omega, Finset.mem_Icc.mpr ⟨ha, by omega⟩⟩
  unfold marked
  rw [← Finset.mul_prod_erase ((Icc 1 N).erase a) (Bf k) h1,
    ← Finset.mul_prod_erase ((Icc 1 N).erase (a + 1)) (Bf k) h2,
    Finset.erase_right_comm (s := Icc 1 N) (a := a + 1) (b := a)]
  ring

/-- Paired numerator polynomial `F_a` of DESIGN M3.4. -/
noncomputable def pairF (k a : ℕ) : PowerSeries ℤ :=
  ∑ i ∈ range k, ∑ j ∈ range i,
    PowerSeries.C ((i - j : ℕ) : ℤ) *
      (PowerSeries.X ^ ((i + j) * a + j) * ∑ e ∈ range (i - j), PowerSeries.X ^ e)

theorem pair_term (k j a : ℕ) (hj : j < k) :
    PowerSeries.C (j : ℤ) * PowerSeries.X ^ (a * j) * PowerSeries.X ^ ((a + 1) * k)
        - PowerSeries.C (j : ℤ) * PowerSeries.X ^ ((a + 1) * j) * PowerSeries.X ^ (a * k)
        + (PowerSeries.C (k : ℤ) * (PowerSeries.X ^ (a * k) * PowerSeries.X ^ ((a + 1) * j))
          - PowerSeries.C (k : ℤ) * (PowerSeries.X ^ ((a + 1) * k) * PowerSeries.X ^ (a * j)))
      = (1 - PowerSeries.X) * (PowerSeries.C ((k - j : ℕ) : ℤ) *
          (PowerSeries.X ^ ((k + j) * a + j) * ∑ e ∈ range (k - j), PowerSeries.X ^ e)) := by
  obtain ⟨m, rfl⟩ : ∃ m, k = j + m := ⟨k - j, by omega⟩
  have hsub : j + m - j = m := by omega
  rw [hsub]
  have hc : PowerSeries.C (((j + m : ℕ) : ℤ)) =
      PowerSeries.C (j : ℤ) + PowerSeries.C (m : ℤ) := by
    rw [Nat.cast_add, map_add]
  rw [hc]
  have hg := mul_neg_geom_sum (PowerSeries.X : PowerSeries ℤ) m
  linear_combination (-(PowerSeries.C (m : ℤ) * PowerSeries.X ^ ((j + m + j) * a + j))) * hg

/-- (DESIGN M3.4) paired numerator identity. -/
theorem pair_numerator (k a : ℕ) :
    Af k a * Bf k (a + 1) - Af k (a + 1) * Bf k a = (1 - PowerSeries.X) * pairF k a := by
  induction k with
  | zero => simp [Af, Bf, pairF]
  | succ k ih =>
    have hA : ∀ h, Af (k + 1) h = Af k h + PowerSeries.C (k : ℤ) * PowerSeries.X ^ (h * k) := by
      intro h
      unfold Af
      rw [Finset.sum_range_succ]
    have hB : ∀ h, Bf (k + 1) h = Bf k h + PowerSeries.X ^ (h * k) := by
      intro h
      unfold Bf
      rw [Finset.sum_range_succ]
    have hF : pairF (k + 1) a = pairF k a + ∑ j ∈ range k,
        PowerSeries.C ((k - j : ℕ) : ℤ) *
          (PowerSeries.X ^ ((k + j) * a + j) * ∑ e ∈ range (k - j), PowerSeries.X ^ e) := by
      unfold pairF
      rw [Finset.sum_range_succ]
    have hL : Af k a * PowerSeries.X ^ ((a + 1) * k) - Af k (a + 1) * PowerSeries.X ^ (a * k)
        + (PowerSeries.C (k : ℤ) * (PowerSeries.X ^ (a * k) * Bf k (a + 1))
          - PowerSeries.C (k : ℤ) * (PowerSeries.X ^ ((a + 1) * k) * Bf k a))
        = ∑ j ∈ range k,
          (PowerSeries.C (j : ℤ) * PowerSeries.X ^ (a * j) * PowerSeries.X ^ ((a + 1) * k)
            - PowerSeries.C (j : ℤ) * PowerSeries.X ^ ((a + 1) * j) * PowerSeries.X ^ (a * k)
            + (PowerSeries.C (k : ℤ) * (PowerSeries.X ^ (a * k) * PowerSeries.X ^ ((a + 1) * j))
              - PowerSeries.C (k : ℤ) *
                (PowerSeries.X ^ ((a + 1) * k) * PowerSeries.X ^ (a * j)))) := by
      unfold Af Bf
      simp only [Finset.sum_mul, Finset.mul_sum, Finset.sum_add_distrib, Finset.sum_sub_distrib]
    have hcross : Af k a * PowerSeries.X ^ ((a + 1) * k) - Af k (a + 1) * PowerSeries.X ^ (a * k)
        + (PowerSeries.C (k : ℤ) * (PowerSeries.X ^ (a * k) * Bf k (a + 1))
          - PowerSeries.C (k : ℤ) * (PowerSeries.X ^ ((a + 1) * k) * Bf k a))
        = (1 - PowerSeries.X) * ∑ j ∈ range k,
          PowerSeries.C ((k - j : ℕ) : ℤ) *
            (PowerSeries.X ^ ((k + j) * a + j) * ∑ e ∈ range (k - j), PowerSeries.X ^ e) := by
      rw [hL, Finset.mul_sum]
      exact Finset.sum_congr rfl fun j hj => pair_term k j a (Finset.mem_range.mp hj)
    rw [hA, hA, hB, hB, hF]
    linear_combination ih + hcross

/-- Factorised marked difference: `(1 − X) · pairF · ∏ (remaining B)`. -/
theorem marked_sub_factor {k a N : ℕ} (ha : 1 ≤ a) (haN : a + 1 ≤ N) :
    marked k a N - marked k (a + 1) N =
      (1 - PowerSeries.X) * pairF k a * ∏ h ∈ ((Icc 1 N).erase a).erase (a + 1), Bf k h := by
  rw [marked_sub ha haN, pair_numerator]

/-- Native bridge: the adjacent count difference is a coefficient of the finite factorised
product (any cutoff `N ≥ max n (a+1)`). -/
theorem C_sub_C_succ_eq_coeff {k a N n : ℕ} (hk : 1 ≤ k) (ha : 1 ≤ a) (haN : a + 1 ≤ N)
    (hn : n ≤ N) :
    (C k a n : ℤ) - C k (a + 1) n =
      PowerSeries.coeff n ((1 - PowerSeries.X) * pairF k a *
        ∏ h ∈ ((Icc 1 N).erase a).erase (a + 1), Bf k h) := by
  rw [← marked_sub_factor ha haN, coeff_marked_sub hk ha haN hn]

end RBCount

#print axioms RBCount.marked_sub
#print axioms RBCount.pair_numerator
#print axioms RBCount.marked_sub_factor
#print axioms RBCount.C_sub_C_succ_eq_coeff
