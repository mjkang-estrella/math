import RBAbsorbFiberMaps
import RBAbsorbBounds
import RBAbsorbSurplus
noncomputable section
namespace RBAbsorb
open PowerSeries
theorem product1_positive (n : ℕ) (hn : 17≤n) : 0<coeff n (T1.rational*R) := by
  have hm := product_mono L1 T1.rational bound1 n
  rw [expand1] at hm
  have ha := shifted_absorb2 (n:=n) (d:=2) (by omega)
  have hs := surplus1 n hn
  norm_num at ha
  linarith
#print axioms product1_positive
theorem product2_positive (n : ℕ) (hn : 17≤n) : 0<coeff n (T2.rational*R) := by
  have hm := product_mono L2 T2.rational bound2 n
  rw [expand2] at hm
  have ha := shifted_absorb2 (n:=n) (d:=4) (by omega)
  have hs := surplus2 n hn
  norm_num at ha
  linarith
#print axioms product2_positive
theorem product3_positive (n : ℕ) (hn : 17≤n) : 0<coeff n (T3.rational*R) := by
  have hm := product_mono L3 T3.rational bound3 n
  rw [expand3] at hm
  have ha := shifted_absorb2 (n:=n) (d:=7) (by omega)
  have hb := shifted_absorb4 (n:=n) (d:=12) (by omega)
  have hs := surplus3 n hn
  norm_num at ha hb
  linarith
#print axioms product3_positive
theorem product4_positive (n : ℕ) (hn : 17≤n) : 0<coeff n (T4.rational*R) := by
  have hm := product_mono L4 T4.rational bound4 n
  rw [expand4] at hm
  have ha := shifted_absorb2 (n:=n) (d:=8) (by omega)
  have hs := surplus4 n hn
  norm_num at ha
  linarith
#print axioms product4_positive
theorem all_four (n : ℕ) (hn : 17≤n) :
    0<coeff n (T1.rational*R) ∧ 0<coeff n (T2.rational*R) ∧
    0<coeff n (T3.rational*R) ∧ 0<coeff n (T4.rational*R) :=
  ⟨product1_positive n hn, product2_positive n hn, product3_positive n hn, product4_positive n hn⟩
#print axioms all_four
end RBAbsorb
