import RBPrefixEndpoint
set_option maxRecDepth 1000000
set_option maxHeartbeats 0
namespace RBPrefix
open scoped BigOperators
def rowLength (k a : Nat) : Nat :=
 if (k = 2 ∧ a < 5) ∨ (k = 3 ∧ exceptional k a = true) then 0
 else a + (if exceptional k a then 23 else 119) + 1 - max (a+5) 17
def caseCount : Nat := ∑ d ∈ Finset.range 142, ∑ e ∈ Finset.range 22, rowLength (2+d) (2+e)
theorem caseCount_value : caseCount = 346186 := by decide
#print axioms caseCount_value
end RBPrefix
