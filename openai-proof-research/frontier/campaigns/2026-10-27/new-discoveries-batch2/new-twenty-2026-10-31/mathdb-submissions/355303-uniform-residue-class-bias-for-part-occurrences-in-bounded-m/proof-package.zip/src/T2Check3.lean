import T2Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T2
theorem rec3_0 : ∀ n : Fin 15, tab (n.val+1260)=step tab (n.val+1260) := by decide
theorem rec3_1 : ∀ n : Fin 15, tab (n.val+1275)=step tab (n.val+1275) := by decide
theorem rec3_2 : ∀ n : Fin 15, tab (n.val+1290)=step tab (n.val+1290) := by decide
theorem rec3_3 : ∀ n : Fin 15, tab (n.val+1305)=step tab (n.val+1305) := by decide
theorem rec3_4 : ∀ n : Fin 15, tab (n.val+1320)=step tab (n.val+1320) := by decide
theorem rec3_5 : ∀ n : Fin 15, tab (n.val+1335)=step tab (n.val+1335) := by decide
theorem rec3_6 : ∀ n : Fin 15, tab (n.val+1350)=step tab (n.val+1350) := by decide
theorem rec3_7 : ∀ n : Fin 15, tab (n.val+1365)=step tab (n.val+1365) := by decide
theorem rec3_8 : ∀ n : Fin 15, tab (n.val+1380)=step tab (n.val+1380) := by decide
theorem rec3_9 : ∀ n : Fin 15, tab (n.val+1395)=step tab (n.val+1395) := by decide
theorem rec3_10 : ∀ n : Fin 15, tab (n.val+1410)=step tab (n.val+1410) := by decide
theorem rec3_11 : ∀ n : Fin 15, tab (n.val+1425)=step tab (n.val+1425) := by decide
theorem rec3_12 : ∀ n : Fin 15, tab (n.val+1440)=step tab (n.val+1440) := by decide
theorem rec3_13 : ∀ n : Fin 15, tab (n.val+1455)=step tab (n.val+1455) := by decide
theorem rec3_14 : ∀ n : Fin 15, tab (n.val+1470)=step tab (n.val+1470) := by decide
theorem rec3_15 : ∀ n : Fin 15, tab (n.val+1485)=step tab (n.val+1485) := by decide
theorem rec3_16 : ∀ n : Fin 15, tab (n.val+1500)=step tab (n.val+1500) := by decide
theorem rec3_17 : ∀ n : Fin 15, tab (n.val+1515)=step tab (n.val+1515) := by decide
theorem rec3_18 : ∀ n : Fin 15, tab (n.val+1530)=step tab (n.val+1530) := by decide
theorem rec3_19 : ∀ n : Fin 15, tab (n.val+1545)=step tab (n.val+1545) := by decide
theorem rec3_20 : ∀ n : Fin 15, tab (n.val+1560)=step tab (n.val+1560) := by decide
theorem rec3_21 : ∀ n : Fin 15, tab (n.val+1575)=step tab (n.val+1575) := by decide
theorem rec3_22 : ∀ n : Fin 15, tab (n.val+1590)=step tab (n.val+1590) := by decide
theorem rec3_23 : ∀ n : Fin 15, tab (n.val+1605)=step tab (n.val+1605) := by decide
theorem rec3_24 : ∀ n : Fin 15, tab (n.val+1620)=step tab (n.val+1620) := by decide
theorem rec3_25 : ∀ n : Fin 15, tab (n.val+1635)=step tab (n.val+1635) := by decide
theorem rec3_26 : ∀ n : Fin 15, tab (n.val+1650)=step tab (n.val+1650) := by decide
theorem rec3_27 : ∀ n : Fin 15, tab (n.val+1665)=step tab (n.val+1665) := by decide
theorem rec3 : ∀ n : Fin 420, tab (n.val+1260)=step tab (n.val+1260) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec3_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+1260=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec3_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+1275=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec3_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+1290=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec3_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+1305=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec3_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+1320=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec3_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+1335=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec3_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+1350=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec3_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+1365=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec3_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+1380=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec3_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+1395=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec3_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+1410=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec3_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+1425=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec3_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+1440=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec3_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+1455=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec3_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+1470=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec3_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+1485=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec3_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+1500=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec3_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+1515=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec3_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+1530=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec3_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+1545=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec3_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+1560=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec3_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+1575=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec3_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+1590=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec3_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+1605=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec3_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+1620=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec3_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+1635=n.val+1260 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec3_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+1650=n.val+1260 := by omega
    simpa only [he] using h
  have h := rec3_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+1665=n.val+1260 := by omega
  simpa only [he] using h
theorem rows3 : ∀ r : Fin 60,
  0 ≤ tab (r.val+180+1260) ∧
  0 ≤ tab (r.val+180+1680)-tab (r.val+180+1260) ∧
  0 ≤ tab (r.val+180+2100)-2*tab (r.val+180+1680)+tab (r.val+180+1260) ∧
  0 ≤ tab (r.val+180+2520)-3*tab (r.val+180+2100)+3*tab (r.val+180+1680)-tab (r.val+180+1260) := by decide

#print axioms rec3
#print axioms rows3
end T2
