import RBStageFnBinary44
import Mathlib.Tactic.IntervalCases
namespace RBStageFn
open RBPrefix
set_option maxRecDepth 100000
set_option maxHeartbeats 0
def binaryRow : Nat → Nat → Int
| 5 => f2a5h142
| 6 => f2a6h142
| 7 => f2a7h142
| 8 => f2a8h142
| 9 => f2a9h142
| 10 => f2a10h142
| 11 => f2a11h142
| 12 => f2a12h142
| 13 => f2a13h142
| 14 => f2a14h142
| 15 => f2a15h142
| 16 => f2a16h142
| 17 => f2a17h142
| 18 => f2a18h142
| 19 => f2a19h142
| 20 => f2a20h142
| 21 => f2a21h142
| 22 => f2a22h142
| 23 => f2a23h142
| 24 => f2a24h142
| _ => fun _ => 0
theorem binaryRow_sound (a : Nat) (ha : 5 ≤ a ∧ a ≤ 24) : Sound 2 142 (factors 142 a) (binaryRow a) := by
 rcases ha with ⟨hl, hu⟩
 interval_cases a <;> first
 | exact f2a5h142s
 | exact f2a6h142s
 | exact f2a7h142s
 | exact f2a8h142s
 | exact f2a9h142s
 | exact f2a10h142s
 | exact f2a11h142s
 | exact f2a12h142s
 | exact f2a13h142s
 | exact f2a14h142s
 | exact f2a15h142s
 | exact f2a16h142s
 | exact f2a17h142s
 | exact f2a18h142s
 | exact f2a19h142s
 | exact f2a20h142s
 | exact f2a21h142s
 | exact f2a22h142s
 | exact f2a23h142s
 | exact f2a24h142s
def binaryCheck : Bool := (List.range 24).all fun a =>
 (List.range 143).all fun n => if Required 2 a n then
 decide (binaryRow (a+1) n < binaryRow a n) else true
theorem binaryCheck_verified : binaryCheck = true := by decide
theorem binary_actual (a n : Nat) (hr : Required 2 a n) :
 (actualMarked 2 (a+1)).coeff n < (actualMarked 2 a).coeff n := by
 have b := required_bounds hr
 have ha : 5 ≤ a := hr.2.2.2.2.1 rfl
 have hau : a ≤ 23 := hr.2.2.2.1
 have hc := binaryCheck_verified
 simp only [binaryCheck, List.all_eq_true] at hc
 have hd := hc a (List.mem_range.mpr b.1) n (List.mem_range.mpr b.2)
 have hv : binaryRow (a+1) n < binaryRow a n := by
  simpa only [ite_eq_left hr, decide_eq_true_eq] using hd
 rw [actual 2 (a+1) n _ (binaryRow_sound _ (by omega)) (by omega),
     actual 2 a n _ (binaryRow_sound _ (by omega)) (by omega)] at hv
 exact hv
#print axioms binaryRow_sound
#print axioms binaryCheck_verified
#print axioms binary_actual
end RBStageFn
