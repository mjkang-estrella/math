import RBWeakGe3
import RBWeakBinary
import RBCountAssembly

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBWeakExport (355303 uniform weak comparisons): expanded unconditional endpoints

* `adjWeakGe3_expanded`, `adjWeakBinary_expanded`: the two adjacent comparisons, statements expanded.
* `nativeWeak_clause`: the FULL native weak residue clause (first conjunct of `NativeEndpoint`), with NO hypothesis.
* `nativeEndpoint_iff_strict`: `NativeEndpoint` is equivalent to its strict clause alone (exact remaining gap).
* `nativeEndpoint_of_adjStrict`: CONDITIONAL corollary; `AdjStrict` is NOT proved anywhere in this lane.
-/

namespace RBCount

theorem adjWeakGe3_expanded :
    ∀ k a n : ℕ, 3 ≤ k → 1 ≤ a → C k (a + 1) n ≤ C k a n :=
  adjWeakGe3_holds

theorem adjWeakBinary_expanded :
    ∀ a n : ℕ, 5 ≤ a → C 2 (a + 1) n ≤ C 2 a n :=
  adjWeakBinary_holds

/-- **G3.** The full native weak residue clause, unconditional. -/
theorem nativeWeak_clause :
    ∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
      D k s t n ≤ D k r t n := by
  intro k t r s n hk ht hr hrs hst hn
  have h := weak_chain (t := t) (n := n) adjWeakGe3_holds hk hr (s - r - 1) (by omega)
  have e : r + (s - r - 1) + 1 = s := by omega
  rw [e] at h
  exact h

/-- The literal endpoint is equivalent to its (UNPROVED) strict clause. -/
theorem nativeEndpoint_iff_strict :
    NativeEndpoint ↔
      (∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
        D k s t n < D k r t n) := by
  unfold NativeEndpoint
  exact ⟨fun h => h.2, fun h => ⟨nativeWeak_clause, h⟩⟩

/-- CONDITIONAL on the unproved `AdjStrict` (explicit hypothesis, not an axiom). -/
theorem nativeEndpoint_of_adjStrict (hS : AdjStrict) : NativeEndpoint :=
  conditional_nativeEndpoint_of_adjacent_comparisons adjWeakGe3_holds adjWeakBinary_holds hS

end RBCount

#print axioms RBCount.adjWeakGe3_holds
#print axioms RBCount.adjWeakBinary_holds
#print axioms RBCount.adjWeakGe3_expanded
#print axioms RBCount.adjWeakBinary_expanded
#print axioms RBCount.nativeWeak_clause
#print axioms RBCount.nativeEndpoint_iff_strict
#print axioms RBCount.nativeEndpoint_of_adjStrict
