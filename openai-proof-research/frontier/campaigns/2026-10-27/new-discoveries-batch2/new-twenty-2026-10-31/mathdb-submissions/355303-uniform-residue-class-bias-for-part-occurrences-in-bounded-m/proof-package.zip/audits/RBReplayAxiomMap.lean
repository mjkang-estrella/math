import RBReplayUnconditional
import RB355303Audit

/-!
# RBReplayAxiomMap — exhaustive independent constant/axiom/import audit (MathDB 355303 replay, Opus r1)

Meta-level only: ordinary total (non-`partial`, non-`unsafe`) functions and one `run_cmd`.
It traverses the ACTUAL kernel expressions (type and value) of every constant reachable from every
constant of every project module (all upstream constants included) — it does NOT consult the
precomputed axiom extension that `#print axioms` uses for imported declarations.
Dependency rules mirror `Lean.CollectAxioms.collect` of the pinned Lean 4.34.1; cycles
(inductive ↔ constructor) are resolved by a monotone fixed point (exact reachability union).
Output: `MOD` lines (olean header imports), one `DECL` line per project constant
(module, name, kind, flags, transitive axioms), and global `SUMMARY`/`REACH_*`/`PROOF_*` lines.
-/

open Lean Elab Command

namespace RBReplayAxiomMap

/-- Direct dependencies, mirroring `Lean.CollectAxioms.collect`. -/
def deps (ci : ConstantInfo) : Array Name :=
  match ci with
  | .axiomInfo v => v.type.getUsedConstants
  | .defnInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .thmInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .opaqueInfo v => v.type.getUsedConstants ++ v.value.getUsedConstants
  | .quotInfo _ => #[]
  | .ctorInfo v => v.type.getUsedConstants
  | .recInfo v => v.type.getUsedConstants
  | .inductInfo v => v.type.getUsedConstants ++ v.ctors.toArray

def kindStr : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "thm"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quot"
  | .inductInfo _ => "induct"
  | .ctorInfo _ => "ctor"
  | .recInfo _ => "rec"

def isPartialDef : ConstantInfo → Bool
  | .defnInfo v => v.safety == .partial
  | _ => false

def isAxiomInfo : ConstantInfo → Bool
  | .axiomInfo _ => true
  | _ => false

def isOpaqueInfo : ConstantInfo → Bool
  | .opaqueInfo _ => true
  | _ => false

/-- Flat (dot-free) module names other than `Init` are exactly the project modules. -/
def isProjectModule (m : Name) : Bool :=
  m.getPrefix == .anonymous && m != `Init

/-- DFS from `roots`: postorder, direct-dependency cache, missing names, completion flag. -/
def reach (env : Environment) (roots : Array Name) (fuel : Nat) :
    Array Name × Std.HashMap Name (Array Name) × Array Name × Bool := Id.run do
  let mut cache : Std.HashMap Name (Array Name) := {}
  let mut order : Array Name := #[]
  let mut missing : Array Name := #[]
  let mut stack : Array (Name × Bool) := roots.map (fun n => (n, false))
  let mut finished := false
  for _ in [0:fuel] do
    if stack.isEmpty then
      finished := true
      break
    let (c, expanded) := stack.back!
    stack := stack.pop
    if expanded then
      order := order.push c
    else if !cache.contains c then
      let ds := match env.find? c with
        | some ci => deps ci
        | none => #[]
      if (env.find? c).isNone then
        missing := missing.push c
      cache := cache.insert c ds
      stack := stack.push (c, true)
      for d in ds do
        unless cache.contains d do
          stack := stack.push (d, false)
  return (order, cache, missing, finished)

/-- Least fixed point of `ax c = own c ∪ ⋃_{d ∈ deps c} ax d` over the reached constants. -/
def axiomsFix (env : Environment) (order : Array Name) (cache : Std.HashMap Name (Array Name))
    (maxPasses : Nat) : Std.HashMap Name (Array Name) × Nat × Bool := Id.run do
  let mut ax : Std.HashMap Name (Array Name) := {}
  let mut passes := 0
  let mut stable := false
  for _ in [0:maxPasses] do
    passes := passes + 1
    let mut changed := false
    for c in order do
      let old := ax.getD c #[]
      let mut acc := old
      match env.find? c with
      | some ci =>
        if isAxiomInfo ci && !acc.contains c then
          acc := acc.push c
      | none => pure ()
      for d in cache.getD c #[] do
        for a in ax.getD d #[] do
          unless acc.contains a do
            acc := acc.push a
      if acc.size != old.size then
        changed := true
        ax := ax.insert c acc
    if !changed then
      stable := true
      break
  return (ax, passes, stable)

def joinNames (xs : Array Name) : String :=
  String.intercalate "," ((xs.map toString).qsort (· < ·)).toList

/-- Global facts about a reached constant set. -/
def reachFacts (env : Environment) (order : Array Name) :
    Array Name × Array Name × Array Name × Nat × Nat := Id.run do
  let mut axs : Array Name := #[]
  let mut uns : Array Name := #[]
  let mut par : Array Name := #[]
  let mut impl := 0
  let mut ext := 0
  for c in order do
    match env.find? c with
    | some ci =>
      if isAxiomInfo ci then axs := axs.push c
      if ci.isUnsafe then uns := uns.push c
      if isPartialDef ci then par := par.push c
    | none => pure ()
    if (Compiler.getImplementedBy? env c).isSome then impl := impl + 1
    if isExtern env c then ext := ext + 1
  return (axs, uns, par, impl, ext)

end RBReplayAxiomMap

open RBReplayAxiomMap in
set_option maxHeartbeats 0 in
set_option maxRecDepth 100000 in
run_cmd do
  let env ← getEnv
  let mods := env.header.moduleNames
  let mut lines : Array String := #[]
  let mut projIdx : Std.HashSet Nat := {}
  for i in [0:mods.size] do
    let m := mods[i]!
    if isProjectModule m then
      projIdx := projIdx.insert i
      let imps := (env.header.moduleData[i]!.imports.map (fun im => im.module.toString)).toList
      lines := lines.push s!"MOD\t{i}\t{m}\t{String.intercalate "," imps}"
  let roots : Array Name := env.constants.fold (fun acc n _ =>
    match env.getModuleIdxFor? n with
    | some idx => if projIdx.contains idx.toNat then acc.push n else acc
    | none => acc.push n) #[]
  let (order, cache, missing, finished) := reach env roots 2000000000
  let (ax, passes, stable) := axiomsFix env order cache 64
  let std : Array String := #["Classical.choice", "Quot.sound", "propext"]
  let mut nonStd : Nat := 0
  for c in roots do
    let modName := match env.getModuleIdxFor? c with
      | some idx => (mods[idx.toNat]!).toString
      | none => "RBReplayAxiomMap"
    let mut kind := "MISSING"
    let mut flags := ""
    match env.find? c with
    | some ci =>
      kind := kindStr ci
      if ci.isUnsafe then flags := flags ++ "U"
      if isPartialDef ci then flags := flags ++ "P"
      if isOpaqueInfo ci then flags := flags ++ "O"
      if isAxiomInfo ci then flags := flags ++ "A"
    | none => pure ()
    if (Compiler.getImplementedBy? env c).isSome then flags := flags ++ "I"
    if isExtern env c then flags := flags ++ "E"
    if c.toString.endsWith "_unsafe_rec" then flags := flags ++ "R"
    let axs := ax.getD c #[]
    if axs.any (fun a => !std.contains a.toString) then nonStd := nonStd + 1
    lines := lines.push s!"DECL\t{modName}\t{c}\t{kind}\t{if flags.isEmpty then "-" else flags}\t{joinNames axs}"
  let (rAx, rUn, rPa, rIm, rEx) := reachFacts env order
  lines := lines.push s!"SUMMARY\tprojectModules={projIdx.size}\troots={roots.size}\treachable={order.size}\tmissing={missing.size}\tdfsFinished={finished}\tpasses={passes}\tstable={stable}\tnonStdRoots={nonStd}"
  lines := lines.push s!"REACH_AXIOMS\t{joinNames rAx}"
  lines := lines.push s!"REACH_UNSAFE\t{rUn.size}\t{joinNames (rUn.extract 0 200)}"
  lines := lines.push s!"REACH_PARTIAL\t{rPa.size}\t{joinNames (rPa.extract 0 200)}"
  lines := lines.push s!"REACH_IMPLEMENTED_BY\t{rIm}"
  lines := lines.push s!"REACH_EXTERN\t{rEx}"
  lines := lines.push s!"MISSING\t{joinNames (missing.extract 0 200)}"
  let proofRoots : Array Name := #[``RB355303.original_weak, ``RB355303.original_strict,
    ``RB355303.nativeEndpoint, ``RB355303.finitePrefixPolynomial, ``RBSharedClosed.full_table,
    ``RBReplayAudit.conjecture_1_4, ``RBReplayAudit.weak_literal, ``RBReplayAudit.strict_literal,
    ``RBReplayAudit.weak_spelled, ``RBReplayAudit.strict_spelled, ``RBReplayAudit.weak_modEq,
    ``RBReplayAudit.strict_modEq, ``RBReplayAudit.weak_top_dvd, ``RBReplayAudit.strict_top_dvd]
  let (pOrder, _, pMissing, pFin) := reach env proofRoots 2000000000
  let (pAx, pUn, pPa, pIm, pEx) := reachFacts env pOrder
  let mut pProj := 0
  for c in pOrder do
    match env.getModuleIdxFor? c with
    | some idx => if projIdx.contains idx.toNat then pProj := pProj + 1
    | none => pure ()
  lines := lines.push s!"PROOF_CLOSURE\treachable={pOrder.size}\tprojectConstants={pProj}\tmissing={pMissing.size}\tfinished={pFin}"
  lines := lines.push s!"PROOF_AXIOMS\t{joinNames pAx}"
  lines := lines.push s!"PROOF_UNSAFE\t{pUn.size}\t{joinNames (pUn.extract 0 200)}"
  lines := lines.push s!"PROOF_PARTIAL\t{pPa.size}\t{joinNames (pPa.extract 0 200)}"
  lines := lines.push s!"PROOF_IMPLEMENTED_BY\t{pIm}\tPROOF_EXTERN\t{pEx}"
  for r in proofRoots do
    lines := lines.push s!"ROOT_AXIOMS\t{r}\t{joinNames (ax.getD r #[])}"
  logInfo (String.intercalate "\n" lines.toList)
