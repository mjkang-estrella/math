import T4Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T4
theorem rec0_0 : ∀ n : Fin 15, tab (n.val+0)=step tab (n.val+0) := by decide
theorem rec0_1 : ∀ n : Fin 15, tab (n.val+15)=step tab (n.val+15) := by decide
theorem rec0_2 : ∀ n : Fin 15, tab (n.val+30)=step tab (n.val+30) := by decide
theorem rec0_3 : ∀ n : Fin 15, tab (n.val+45)=step tab (n.val+45) := by decide
theorem rec0_4 : ∀ n : Fin 15, tab (n.val+60)=step tab (n.val+60) := by decide
theorem rec0_5 : ∀ n : Fin 15, tab (n.val+75)=step tab (n.val+75) := by decide
theorem rec0_6 : ∀ n : Fin 15, tab (n.val+90)=step tab (n.val+90) := by decide
theorem rec0_7 : ∀ n : Fin 15, tab (n.val+105)=step tab (n.val+105) := by decide
theorem rec0_8 : ∀ n : Fin 15, tab (n.val+120)=step tab (n.val+120) := by decide
theorem rec0_9 : ∀ n : Fin 15, tab (n.val+135)=step tab (n.val+135) := by decide
theorem rec0_10 : ∀ n : Fin 15, tab (n.val+150)=step tab (n.val+150) := by decide
theorem rec0_11 : ∀ n : Fin 15, tab (n.val+165)=step tab (n.val+165) := by decide
theorem rec0_12 : ∀ n : Fin 15, tab (n.val+180)=step tab (n.val+180) := by decide
theorem rec0_13 : ∀ n : Fin 15, tab (n.val+195)=step tab (n.val+195) := by decide
theorem rec0_14 : ∀ n : Fin 15, tab (n.val+210)=step tab (n.val+210) := by decide
theorem rec0_15 : ∀ n : Fin 15, tab (n.val+225)=step tab (n.val+225) := by decide
theorem rec0_16 : ∀ n : Fin 15, tab (n.val+240)=step tab (n.val+240) := by decide
theorem rec0_17 : ∀ n : Fin 15, tab (n.val+255)=step tab (n.val+255) := by decide
theorem rec0_18 : ∀ n : Fin 15, tab (n.val+270)=step tab (n.val+270) := by decide
theorem rec0_19 : ∀ n : Fin 15, tab (n.val+285)=step tab (n.val+285) := by decide
theorem rec0_20 : ∀ n : Fin 15, tab (n.val+300)=step tab (n.val+300) := by decide
theorem rec0_21 : ∀ n : Fin 15, tab (n.val+315)=step tab (n.val+315) := by decide
theorem rec0_22 : ∀ n : Fin 15, tab (n.val+330)=step tab (n.val+330) := by decide
theorem rec0_23 : ∀ n : Fin 15, tab (n.val+345)=step tab (n.val+345) := by decide
theorem rec0_24 : ∀ n : Fin 15, tab (n.val+360)=step tab (n.val+360) := by decide
theorem rec0_25 : ∀ n : Fin 15, tab (n.val+375)=step tab (n.val+375) := by decide
theorem rec0_26 : ∀ n : Fin 15, tab (n.val+390)=step tab (n.val+390) := by decide
theorem rec0_27 : ∀ n : Fin 15, tab (n.val+405)=step tab (n.val+405) := by decide
theorem rec0 : ∀ n : Fin 420, tab (n.val+0)=step tab (n.val+0) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec0_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+0=n.val+0 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec0_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+15=n.val+0 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec0_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+30=n.val+0 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec0_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+45=n.val+0 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec0_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+60=n.val+0 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec0_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+75=n.val+0 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec0_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+90=n.val+0 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec0_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+105=n.val+0 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec0_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+120=n.val+0 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec0_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+135=n.val+0 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec0_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+150=n.val+0 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec0_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+165=n.val+0 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec0_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+180=n.val+0 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec0_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+195=n.val+0 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec0_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+210=n.val+0 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec0_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+225=n.val+0 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec0_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+240=n.val+0 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec0_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+255=n.val+0 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec0_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+270=n.val+0 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec0_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+285=n.val+0 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec0_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+300=n.val+0 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec0_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+315=n.val+0 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec0_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+330=n.val+0 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec0_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+345=n.val+0 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec0_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+360=n.val+0 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec0_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+375=n.val+0 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec0_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+390=n.val+0 := by omega
    simpa only [he] using h
  have h := rec0_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+405=n.val+0 := by omega
  simpa only [he] using h
theorem rows0 : ∀ r : Fin 60,
  0 ≤ tab (r.val+0+2520) ∧
  0 ≤ tab (r.val+0+3360)-tab (r.val+0+2520) ∧
  0 ≤ tab (r.val+0+4200)-2*tab (r.val+0+3360)+tab (r.val+0+2520) ∧
  0 ≤ tab (r.val+0+5040)-3*tab (r.val+0+4200)+3*tab (r.val+0+3360)-tab (r.val+0+2520) := by decide
theorem pref0 : ∀ n : Fin 420, n.val+0≠8 → 0≤tab (n.val+0) := by decide

#print axioms rec0
#print axioms rows0
#print axioms pref0
end T4
