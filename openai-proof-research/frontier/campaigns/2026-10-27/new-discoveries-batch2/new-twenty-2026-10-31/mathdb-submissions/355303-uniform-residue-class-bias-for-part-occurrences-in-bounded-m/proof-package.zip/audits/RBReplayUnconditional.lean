import RB355303Final

/-!
# RBReplayUnconditional — independent expanded UNCONDITIONAL audit (MathDB 355303 replay, Opus r1)

Every statement below is written directly in Mathlib vocabulary (`Nat.Partition.countRestricted` or its
literal unfolding, `Multiset.filter`/`Multiset.card`/`Multiset.countP`, `%`, `Nat.ModEq`, `∣`) with NO
hypothesis other than the literal parameter ranges of Conjecture 1.4 (arXiv:2207.04352v1).
Each is proved only from the closed theorems `RB355303.original_weak` / `RB355303.original_strict`.
No table, endpoint, `RBCount`/`RBAssemble` definition or other premise appears in any statement.
No new axiom, no `sorry`, no `native_decide`, no `unsafe`.
-/

namespace RBReplayAudit

/-- Weak clause: `k ≥ 3, t ≥ 6, 1 ≤ r < s ≤ t, n ≥ 1`; occurrences counted with multiplicity. -/
theorem weak_literal :
    ∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = s % t) p.parts).card) ≤
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = r % t) p.parts).card) :=
  fun k t r s n h1 h2 h3 h4 h5 h6 => RB355303.original_weak k t r s n h1 h2 h3 h4 h5 h6

/-- Strict clause: `k ≥ 2`, same `t, r, s` domain, `n > max (t + 3) 16`. -/
theorem strict_literal :
    ∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = s % t) p.parts).card) <
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = r % t) p.parts).card) :=
  fun k t r s n h1 h2 h3 h4 h5 h6 => RB355303.original_strict k t r s n h1 h2 h3 h4 h5 h6

/-- Both clauses of Conjecture 1.4 together. -/
theorem conjecture_1_4 :
    (∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = s % t) p.parts).card) ≤
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = r % t) p.parts).card)) ∧
    (∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = s % t) p.parts).card) <
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (Multiset.filter (fun x => x % t = r % t) p.parts).card)) :=
  ⟨weak_literal, strict_literal⟩

/-- Mathlib's restricted-partition finset IS "every part size occurs fewer than `k` times". -/
theorem countRestricted_spelled (n k : ℕ) :
    (Finset.univ.filter fun p : n.Partition => ∀ i ∈ p.parts, p.parts.count i < k) =
      Nat.Partition.countRestricted n k := rfl

/-- Weak clause with the restricted partitions unfolded and occurrences as `countP`. -/
theorem weak_spelled :
    ∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
      (∑ p ∈ Finset.univ.filter (fun p : n.Partition => ∀ i ∈ p.parts, p.parts.count i < k),
          p.parts.countP (fun x => x % t = s % t)) ≤
      (∑ p ∈ Finset.univ.filter (fun p : n.Partition => ∀ i ∈ p.parts, p.parts.count i < k),
          p.parts.countP (fun x => x % t = r % t)) := by
  intro k t r s n h1 h2 h3 h4 h5 h6
  rw [countRestricted_spelled]
  simp only [Multiset.countP_eq_card_filter]
  exact RB355303.original_weak k t r s n h1 h2 h3 h4 h5 h6

/-- Strict clause with the restricted partitions unfolded and occurrences as `countP`. -/
theorem strict_spelled :
    ∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
      (∑ p ∈ Finset.univ.filter (fun p : n.Partition => ∀ i ∈ p.parts, p.parts.count i < k),
          p.parts.countP (fun x => x % t = s % t)) <
      (∑ p ∈ Finset.univ.filter (fun p : n.Partition => ∀ i ∈ p.parts, p.parts.count i < k),
          p.parts.countP (fun x => x % t = r % t)) := by
  intro k t r s n h1 h2 h3 h4 h5 h6
  rw [countRestricted_spelled]
  simp only [Multiset.countP_eq_card_filter]
  exact RB355303.original_strict k t r s n h1 h2 h3 h4 h5 h6

/-- Residue classes as `Nat.ModEq` (congruence modulo `t`), weak clause. -/
theorem weak_modEq :
    ∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (p.parts.filter (fun x => Nat.ModEq t x s)).card) ≤
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (p.parts.filter (fun x => Nat.ModEq t x r)).card) := by
  intro k t r s n h1 h2 h3 h4 h5 h6
  have e : ∀ (c : ℕ) (p : n.Partition),
      p.parts.filter (fun x => Nat.ModEq t x c) = p.parts.filter (fun x => x % t = c % t) :=
    fun c p => Multiset.filter_congr (fun x _ => Iff.rfl)
  simp only [e]
  exact RB355303.original_weak k t r s n h1 h2 h3 h4 h5 h6

/-- Residue classes as `Nat.ModEq` (congruence modulo `t`), strict clause. -/
theorem strict_modEq :
    ∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (p.parts.filter (fun x => Nat.ModEq t x s)).card) <
      (∑ p ∈ Nat.Partition.countRestricted n k,
          (p.parts.filter (fun x => Nat.ModEq t x r)).card) := by
  intro k t r s n h1 h2 h3 h4 h5 h6
  have e : ∀ (c : ℕ) (p : n.Partition),
      p.parts.filter (fun x => Nat.ModEq t x c) = p.parts.filter (fun x => x % t = c % t) :=
    fun c p => Multiset.filter_congr (fun x _ => Iff.rfl)
  simp only [e]
  exact RB355303.original_strict k t r s n h1 h2 h3 h4 h5 h6

/-- `s = t` means residue zero: the class of `t` is the multiples of `t` (weak clause). -/
theorem weak_top_dvd :
    ∀ k t r n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < t → 1 ≤ n →
      (∑ p ∈ Nat.Partition.countRestricted n k, (p.parts.filter (fun x => t ∣ x)).card) ≤
      (∑ p ∈ Nat.Partition.countRestricted n k, (p.parts.filter (fun x => x % t = r)).card) := by
  intro k t r n h1 h2 h3 h4 h5
  have hr : r % t = r := Nat.mod_eq_of_lt h4
  have e1 : ∀ p : n.Partition,
      p.parts.filter (fun x => t ∣ x) = p.parts.filter (fun x => x % t = t % t) :=
    fun p => Multiset.filter_congr (fun x _ => by rw [Nat.mod_self, Nat.dvd_iff_mod_eq_zero])
  have e2 : ∀ p : n.Partition,
      p.parts.filter (fun x => x % t = r) = p.parts.filter (fun x => x % t = r % t) :=
    fun p => Multiset.filter_congr (fun x _ => by rw [hr])
  simp only [e1, e2]
  exact RB355303.original_weak k t r t n h1 h2 h3 h4 le_rfl h5

/-- `s = t` means residue zero (strict clause). -/
theorem strict_top_dvd :
    ∀ k t r n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < t → max (t + 3) 16 < n →
      (∑ p ∈ Nat.Partition.countRestricted n k, (p.parts.filter (fun x => t ∣ x)).card) <
      (∑ p ∈ Nat.Partition.countRestricted n k, (p.parts.filter (fun x => x % t = r)).card) := by
  intro k t r n h1 h2 h3 h4 h5
  have hr : r % t = r := Nat.mod_eq_of_lt h4
  have e1 : ∀ p : n.Partition,
      p.parts.filter (fun x => t ∣ x) = p.parts.filter (fun x => x % t = t % t) :=
    fun p => Multiset.filter_congr (fun x _ => by rw [Nat.mod_self, Nat.dvd_iff_mod_eq_zero])
  have e2 : ∀ p : n.Partition,
      p.parts.filter (fun x => x % t = r) = p.parts.filter (fun x => x % t = r % t) :=
    fun p => Multiset.filter_congr (fun x _ => by rw [hr])
  simp only [e1, e2]
  exact RB355303.original_strict k t r t n h1 h2 h3 h4 le_rfl h5

/-- Non-vacuity of both hypothesis domains. -/
theorem domains_inhabited :
    (∃ k t r s n : ℕ, 3 ≤ k ∧ 6 ≤ t ∧ 1 ≤ r ∧ r < s ∧ s ≤ t ∧ 1 ≤ n) ∧
    (∃ k t r s n : ℕ, 2 ≤ k ∧ 6 ≤ t ∧ 1 ≤ r ∧ r < s ∧ s ≤ t ∧ max (t + 3) 16 < n) :=
  ⟨⟨3, 6, 1, 6, 1, by decide⟩, ⟨2, 6, 1, 6, 17, by decide⟩⟩

end RBReplayAudit

#eval Lean.versionString
#print axioms RBReplayAudit.weak_literal
#print axioms RBReplayAudit.strict_literal
#print axioms RBReplayAudit.conjecture_1_4
#print axioms RBReplayAudit.countRestricted_spelled
#print axioms RBReplayAudit.weak_spelled
#print axioms RBReplayAudit.strict_spelled
#print axioms RBReplayAudit.weak_modEq
#print axioms RBReplayAudit.strict_modEq
#print axioms RBReplayAudit.weak_top_dvd
#print axioms RBReplayAudit.strict_top_dvd
#print axioms RBReplayAudit.domains_inhabited
#print axioms RB355303.finitePrefixPolynomial
#print axioms RB355303.original_weak
#print axioms RB355303.original_strict
#print RBAssemble.FinitePrefixPolynomial
#check @RBSharedClosed.full_table
#check @RB355303.finitePrefixPolynomial
set_option pp.fullNames true in
#check @RBReplayAudit.conjecture_1_4
set_option pp.all true in
#check @RBReplayAudit.strict_literal
set_option pp.all true in
#check @RBReplayAudit.weak_literal
