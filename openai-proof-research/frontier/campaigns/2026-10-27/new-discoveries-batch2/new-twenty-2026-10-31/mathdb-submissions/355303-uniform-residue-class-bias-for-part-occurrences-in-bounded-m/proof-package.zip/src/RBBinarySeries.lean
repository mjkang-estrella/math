import RBBinaryLiteral
import RBWeakChain
noncomputable section
namespace RBBinary
open Finset PowerSeries
local notation "𝔛" => (X : PowerSeries ℤ)

def Agree (N : ℕ) (f g : PowerSeries ℤ) : Prop := ∀ n ≤ N, coeff n f = coeff n g

theorem agree_mul {N : ℕ} {f f' g g' : PowerSeries ℤ}
    (hf : Agree N f f') (hg : Agree N g g') : Agree N (f*g) (f'*g') := by
  intro n hn
  simp only [coeff_mul]
  apply sum_congr rfl
  intro p hp
  have h := mem_antidiagonal.mp hp
  rw [hf p.1 (by omega), hg p.2 (by omega)]

theorem agree_prod {ι : Type*} (s : Finset ι) (N : ℕ) (f g : ι → PowerSeries ℤ)
    (h : ∀ i ∈ s, Agree N (f i) (g i)) : Agree N (∏ i ∈ s, f i) (∏ i ∈ s, g i) := by
  classical
  induction s using Finset.induction_on with
  | empty => intro n hn; simp
  | @insert i s hi ih =>
    simp only [prod_insert hi]
    apply agree_mul (h i (by simp))
    apply ih
    intro j hj
    exact h j (by simp [hj])

theorem finite_geometric (k h : ℕ) (hh : 1 ≤ h) :
    RBCount.Bf k h = (1-𝔛^(h*k))*RBCount.gI h := by
  calc
    RBCount.Bf k h = RBCount.Bf k h * ((1-𝔛^h)*RBCount.gI h) := by
      rw [RBCount.one_sub_mul_gI hh, mul_one]
    _ = (1-𝔛^(h*k))*RBCount.gI h := by
      rw [← mul_assoc, mul_comm (RBCount.Bf k h), RBCount.one_sub_mul_Bf]

theorem geometric_cutoff (k h N : ℕ) (hh : 1 ≤ h) (hk : N < h*k) :
    Agree N (RBCount.Bf k h) (RBCount.gI h) := by
  rw [finite_geometric k h hh]
  intro n hn
  exact RBCount.coeff_one_sub_X_pow_mul (by omega) _

def residualGeometric (N : ℕ) : PowerSeries ℤ :=
  ∏ h ∈ Icc 1 N, if allowed h then RBCount.gI h else 1

theorem geometric_residual_cutoff (n N : ℕ) (hn : n ≤ N) :
    coeff n (residualGeometric N) = coeff n RBAbsorb.R := by
  have h : Agree n (residualCut (n+1) N) (residualGeometric N) := by
    apply agree_prod (Icc 1 N) n (factor (n+1))
      (fun h => if allowed h then RBCount.gI h else 1)
    intro h hh
    by_cases ha : allowed h
    · simp only [factor, ite_eq_left ha]
      apply geometric_cutoff (n+1) h n (mem_Icc.mp hh).1
      have := (mem_Icc.mp hh).1
      nlinarith
    · simp only [factor, ite_eq_right ha]
      intro j hj
      rfl
  rw [← h n (le_refl n), residual_cutoff n N (n+1) hn (by omega)]

theorem residual_stable (n N N' : ℕ) (h : n ≤ N) (h' : n ≤ N') :
    coeff n (residualGeometric N) = coeff n (residualGeometric N') := by
  rw [geometric_residual_cutoff n N h, geometric_residual_cutoff n N' h']

#print axioms geometric_residual_cutoff
#print axioms residual_stable
end RBBinary
