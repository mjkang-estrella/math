import RBSharedLow
set_option maxRecDepth 100000
namespace RBShared
open Polynomial
theorem low_fraction (N : Nat) (D A B R S : Polynomial Int) (hd : D.coeff 0=1)
 (hDA : D*A=R) (hDB : D*B=S) (hS : Low N S 1) : Low N A (B*R) := by
 apply low_cancel D A (B*R) hd
 intro n hn
 have he := low_mul hS (low_refl N R)
 have hDR : D*(B*R)=S*R := by rw [←mul_assoc,hDB]
 rw [hDA,hDR]
 exact (congrArg (fun p : Polynomial Int => p.coeff n) (one_mul R)).symm.trans (he n hn).symm
noncomputable def numerator (k : Nat) : Nat → Polynomial Int
| 0 => 1
| h+1 => (1-X^(k*(h+1))) * numerator k h
theorem numerator_zero (H : Nat) : (numerator 1 H).coeff 0 = 1 := by
 induction H with
 | zero => simp [numerator]
 | succ H ih => simp [numerator, Polynomial.mul_coeff_zero, ih, Polynomial.coeff_X_pow]
theorem numerator_high (k H N : Nat) (hk : N < k) : Low N (numerator k H) 1 := by
 induction H with
 | zero => exact low_refl N 1
 | succ H ih =>
  intro n hn
  rw [numerator, sub_mul, one_mul, Polynomial.coeff_sub, shifted_coeff]
  have hd : N < k*(H+1) := by
   have hm := Nat.mul_le_mul_left k (show 1 ≤ H+1 by omega)
   simp only [Nat.mul_one] at hm
   omega
  rw [shift, ite_eq_right (by omega), sub_zero]
  exact ih n hn
theorem geometric_product (k H : Nat) :
 numerator 1 H * RBPrefix.poly k (RBPrefix.factors H 0) = numerator k H := by
 induction H with
 | zero => simp [numerator, RBPrefix.factors, RBPrefix.poly]
 | succ H ih =>
  have he : RBPrefix.poly k (RBPrefix.factors (H+1) 0) =
   factor k (H+1) false * RBPrefix.poly k (RBPrefix.factors H 0) := by
   simp [RBPrefix.factors, RBPrefix.poly, factor, RBPrefix.weight]
  calc
   _ = ((1-X^(H+1))*factor k (H+1) false) *
      (numerator 1 H * RBPrefix.poly k (RBPrefix.factors H 0)) := by
       rw [numerator,he]
       simp only [Nat.one_mul]
       ring
   _ = numerator k (H+1) := by rw [factor_geometric,ih]; rfl
theorem poly_actual_zero (k : Nat) :
 RBPrefix.poly k (RBPrefix.factors 142 0) = RBPrefix.actualMarked k 0 := by
 apply Polynomial.ext
 intro n
 rw [← RBPrefix.coeffRun_eq]
 exact RBPrefix.count_meaning k 0 n
theorem universal_product_bridge (k : Nat) :
 Low 142 (RBPrefix.actualMarked k 0) (RBPrefix.actualMarked 143 0 * numerator k 142) := by
 have hp := geometric_product k 142
 rw [poly_actual_zero] at hp
 have hq := geometric_product 143 142
 rw [poly_actual_zero] at hq
 exact low_fraction 142 (numerator 1 142) (RBPrefix.actualMarked k 0)
  (RBPrefix.actualMarked 143 0) (numerator k 142) (numerator 143 142)
  (numerator_zero 142) hp hq (numerator_high 143 142 142 (by decide))
theorem numerator_tail (k cut H N : Nat) (hc : cut ≤ H) (hx : N < k*(cut+1)) :
 Low N (numerator k H) (numerator k cut) := by
 obtain ⟨r,rfl⟩ := Nat.exists_eq_add_of_le hc
 induction r with
 | zero => simpa only [Nat.add_zero] using low_refl N (numerator k cut)
 | succ r ih =>
  intro n hn
  rw [Nat.add_succ,numerator,sub_mul,one_mul,Polynomial.coeff_sub,shifted_coeff]
  have hd : N < k*(cut+r+1) := by
   have hm := Nat.mul_le_mul_left k (show cut+1 ≤ cut+r+1 by omega)
   omega
  rw [shift,ite_eq_right (by omega),sub_zero]
  exact ih (by omega) n hn
#print axioms universal_product_bridge
#print axioms numerator_tail
end RBShared
