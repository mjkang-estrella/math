import T3Support
import Tail
import Newton
import Mathlib.Tactic.LinearCombination

set_option maxRecDepth 4000
noncomputable section
namespace T3
open T1 (newton jet_formula bound_mul)
open PowerSeries

theorem coeff_shift (s : PowerSeries ℤ) (n d : ℕ) (hd : d≤n) :
    coeff n (X^d*s)=coeff (n-d) s := by
  conv_lhs => rw [← Nat.sub_add_cancel hd]
  exact coeff_X_pow_mul s d (n-d)

theorem fourth (r u : ℕ) :
    coeff (r+840*(u+4)) rational - 4*coeff (r+840*(u+3)) rational +
    6*coeff (r+840*(u+2)) rational - 4*coeff (r+840*(u+1)) rational +
    coeff (r+840*u) rational = 0 := by
  have he : (1-(X : PowerSeries ℤ)^840)^4*rational = rational -
      4*(X^840*rational)+6*(X^1680*rational)-4*(X^2520*rational)+X^3360*rational := by ring
  have h := congrArg (coeff (r+840*(u+4))) cleared_rational
  rw [he,bound_Z _ (by omega)] at h
  simp only [map_add,map_sub,coeff_ofNat_mul] at h
  rw [coeff_shift _ _ 840 (by omega),coeff_shift _ _ 1680 (by omega),
      coeff_shift _ _ 2520 (by omega),coeff_shift _ _ 3360 (by omega)] at h
  have h1 : r+840*(u+4)-840=r+840*(u+3) := by omega
  have h2 : r+840*(u+4)-1680=r+840*(u+2) := by omega
  have h3 : r+840*(u+4)-2520=r+840*(u+1) := by omega
  have h4 : r+840*(u+4)-3360=r+840*u := by
    have e : r+840*(u+4)=(r+840*u)+3360 := by ring
    rw [e, Nat.add_sub_cancel]
  simpa only [h1,h2,h3,h4] using h

def diff (f : ℕ → ℤ) (u : ℕ) : ℤ := f (u+1)-f u

theorem fourth_newton (f : ℕ → ℤ)
    (h : ∀ u, f (u+4)-4*f (u+3)+6*f (u+2)-4*f (u+1)+f u=0) :
    ∀ u, f u = newton (f 0) (diff f 0) (diff (diff f) 0)
      (diff (diff (diff f)) 0) u := by
  apply jet_formula f (diff f) (diff (diff f)) (diff (diff (diff f)))
  · intro u; simp [diff]
  · intro u; simp [diff]
  · intro u; simp [diff]
  · intro u
    have hu := h u
    simp only [diff] at *
    linear_combination hu

#print axioms coeff_shift
#print axioms fourth
#print axioms diff
#print axioms fourth_newton
end T3
