import T2Finite
import Mathlib.RingTheory.PowerSeries.Inverse

noncomputable section
namespace T2
open PowerSeries
open scoped BigOperators

def denominator : PowerSeries ℤ := D X
def numerator : PowerSeries ℤ := X^2-X^4

theorem denominator_constant : constantCoeff denominator = 1 := by
  simp [denominator,D]

def rational : PowerSeries ℤ := invOfUnit denominator (1 : ℤˣ) * numerator

theorem denominator_rational : denominator * rational = numerator := by
  unfold rational
  rw [← mul_assoc, mul_invOfUnit denominator (1 : ℤˣ) denominator_constant, one_mul]

theorem denominator_unique (s : PowerSeries ℤ)
    (h : denominator * s = numerator) : s = rational := by
  calc
    s = (invOfUnit denominator (1 : ℤˣ) * denominator) * s := by
      rw [invOfUnit_mul denominator (1 : ℤˣ) denominator_constant, one_mul]
    _ = rational := by rw [mul_assoc,h]; rfl

def DenRec (c : ℕ → ℤ) : Prop := ∀ n,
  (∑ p ∈ Finset.antidiagonal n, coeff p.1 denominator * c p.2) =
    (if n=2 then 1 else 0) - (if n=4 then 1 else 0)

theorem recurrence_iff (c : ℕ → ℤ) : DenRec c ↔
    denominator * mk c = numerator := by
  constructor
  · intro h
    ext n
    simpa [coeff_mul,numerator,coeff_X,coeff_X_pow] using h n
  · intro h n
    have hn := congrArg (coeff n) h
    simpa [coeff_mul,numerator,coeff_X,coeff_X_pow] using hn

theorem recurrence_unique : ∃! c : ℕ → ℤ, DenRec c := by
  refine ⟨fun n => coeff n rational, ?_, ?_⟩
  · apply (recurrence_iff _).mpr
    have hm : (mk fun n => coeff n rational) = rational := by ext n; simp
    rw [hm]; exact denominator_rational
  · intro c hc
    have h := denominator_unique (mk c) ((recurrence_iff c).mp hc)
    funext n
    simpa using congrArg (coeff n) h

theorem cleared_rational : (1-(X : PowerSeries ℤ)^420)^4*rational = Z X := by
  apply (mul_left_cancel₀ (show denominator ≠ 0 by
    intro h; have h0 := congrArg constantCoeff h
    simp [denominator_constant] at h0))
  calc
    denominator * ((1-X^420)^4*rational) = (1-X^420)^4*numerator := by
      rw [mul_left_comm,denominator_rational]
    _ = denominator * Z X := by
      change (1-X^420)^4*numerator = D X * Z X
      rw [finite_identity]; unfold numerator; ring

#print axioms denominator
#print axioms numerator
#print axioms denominator_constant
#print axioms rational
#print axioms denominator_rational
#print axioms denominator_unique
#print axioms DenRec
#print axioms recurrence_iff
#print axioms recurrence_unique
#print axioms cleared_rational
end T2
