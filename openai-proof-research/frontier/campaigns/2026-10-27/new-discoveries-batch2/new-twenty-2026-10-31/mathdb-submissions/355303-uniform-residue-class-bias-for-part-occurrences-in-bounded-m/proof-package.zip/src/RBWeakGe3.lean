import RBWeakChain
import RBWeakAlg

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBWeakGe3 (355303 uniform weak comparisons): `AdjWeakGe3`, unconditionally

`adjWeakGe3_holds : AdjWeakGe3` — for all natural `k ≥ 3`, `a ≥ 1`, `n`: `C k (a+1) n ≤ C k a n`,
with the UNCHANGED prefix definition of `C` (occurrences in partitions with multiplicities `< k`).
Cases: `a + 1 > n` (trivial); `a = 1` (`weak_a1`, chain from `k`, plus root `3` for even `k`);
`k^w ∈ {a, a+1}` with `w ≥ 1` (`weak_power`); otherwise `weak_NE`. Composite `k` is included.
-/

namespace RBCount

open Finset

local notation "𝔛" => (PowerSeries.X : PowerSeries ℤ)

/-- The case `a = 1`. -/
theorem weak_a1 {k n : ℕ} (hk : 3 ≤ k) (hn : 2 ≤ n) : C k (1 + 1) n ≤ C k 1 n := by
  have hk2 : 2 ≤ k := by omega
  have hk1 : ¬ k ∣ 1 := fun h => by
    have := Nat.le_of_dvd one_pos h
    omega
  have hpn := pair_numerator k 1
  rw [show (1 : ℕ) + 1 = 2 from rfl] at hpn
  have hN := N1_gI k (by omega)
  obtain ⟨m, hm1, hm2⟩ := exists_len hk2 (le_refl 1) 1 n
  have hbig : ∀ j, k ≤ 1 * k ^ (j + 1) := fun j => by
    have := Nat.pow_le_pow_right (by omega : k > 0) (by omega : 1 ≤ j + 1)
    rw [pow_one] at this
    omega
  have tk := chain_tele k 1 1 m
  rw [show 1 * k ^ 1 = k by simp] at tk
  obtain ⟨r, hr⟩ : ∃ r, k = 2 * r + 1 ∨ k = 2 * r := ⟨k / 2, by omega⟩
  rcases hr with hodd | heven
  · apply weak_of_subset (k := k) (a := 1) (by omega) le_rfl (by omega) (chainSet k 1 1 m)
    · intro y hy
      have hsub := chainSet_subset hk2 (le_refl 1) hm1 hy
      obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
      have := hbig j
      exact Finset.mem_erase.mpr ⟨by omega, Finset.mem_erase.mpr ⟨by omega, hsub⟩⟩
    · intro Y hY
      rw [prod_chainSet hk2 (le_refl 1) (Bf k)]
      set P := ∏ j ∈ range m, Bf k (1 * k ^ (j + 1)) with hP
      have e1 : (1 - 𝔛) * pairF k 1 * P * Y = ((1 - 𝔛) * pairF k 1 * Y) * P := by ring
      rw [e1, coeff_mul_tele (by omega) hm2 tk]
      have e2 : (1 - 𝔛) * pairF k 1 * Y * gI k =
          ((Af k 1 * Bf k 2 - Af k 2 * Bf k 1) * gI k) * Y := by
        rw [hpn]
        ring
      rw [e2, hN]
      obtain ⟨r', rfl⟩ : ∃ r', k = 2 * r' + 1 := ⟨r, hodd⟩
      exact NN_mul (NN_Hk_odd r') hY n
  · have hk3 : ¬ k ∣ 3 := fun h => by
      have := Nat.le_of_dvd (by omega) h
      omega
    obtain ⟨m3, hm31, hm32⟩ := exists_len hk2 (by omega : 1 ≤ 3) 0 n
    have t3 := chain_tele k 3 0 m3
    rw [show 3 * k ^ 0 = 3 by simp] at t3
    have dj : Disjoint (chainSet k 1 1 m) (chainSet k 3 0 m3) :=
      disjoint_chainSet hk2 hk1 hk3 (by omega)
    apply weak_of_subset (k := k) (a := 1) (by omega) le_rfl (by omega)
      (chainSet k 1 1 m ∪ chainSet k 3 0 m3)
    · intro y hy
      rcases Finset.mem_union.mp hy with hy | hy
      · have hsub := chainSet_subset hk2 (le_refl 1) hm1 hy
        obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
        have := hbig j
        exact Finset.mem_erase.mpr ⟨by omega, Finset.mem_erase.mpr ⟨by omega, hsub⟩⟩
      · have hsub := chainSet_subset hk2 (by omega : 1 ≤ 3) hm31 hy
        obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
        have hpos : 0 < k ^ (j + 0) := pow_pos (by omega) _
        exact Finset.mem_erase.mpr ⟨by omega, Finset.mem_erase.mpr ⟨by omega, hsub⟩⟩
    · intro Y hY
      rw [Finset.prod_union dj, prod_chainSet hk2 (le_refl 1) (Bf k),
        prod_chainSet hk2 (by omega : 1 ≤ 3) (Bf k)]
      set P := ∏ j ∈ range m, Bf k (1 * k ^ (j + 1)) with hP
      set P3 := ∏ j ∈ range m3, Bf k (3 * k ^ (j + 0)) with hP3
      have e1 : (1 - 𝔛) * pairF k 1 * (P * P3) * Y = ((1 - 𝔛) * pairF k 1 * Y * P3) * P := by ring
      rw [e1, coeff_mul_tele (by omega) hm2 tk]
      have e2 : (1 - 𝔛) * pairF k 1 * Y * P3 * gI k = ((1 - 𝔛) * pairF k 1 * Y * gI k) * P3 := by
        ring
      rw [e2, coeff_mul_tele (by omega) hm32 t3]
      have e3 : (1 - 𝔛) * pairF k 1 * Y * gI k * gI 3 =
          ((Af k 1 * Bf k 2 - Af k 2 * Bf k 1) * gI k) * gI 3 * Y := by
        rw [hpn]
        ring
      rw [e3, hN]
      obtain ⟨t, rfl⟩ : ∃ t, k = 2 * t + 4 := ⟨r - 2, by omega⟩
      exact NN_mul (NN_Hk_even t) hY n

/-- One marked size is a power `k^w`, `w ≥ 1` (here `a ≥ 2`). -/
theorem weak_power {k a n w : ℕ} (hk : 3 ≤ k) (ha : 2 ≤ a) (han : a + 1 ≤ n) (hw : 1 ≤ w)
    (hx : k ^ w = a ∨ k ^ w = a + 1) : C k (a + 1) n ≤ C k a n := by
  have hk2 : 2 ≤ k := by omega
  have hxw : k ^ w = k ^ (w - 1) * k := by rw [← pow_succ, Nat.sub_add_cancel hw]
  have ht1 : 0 < k ^ (w - 1) := pow_pos (by omega) _
  have hmul : k ^ (w - 1) * 3 ≤ k ^ (w - 1) * k := Nat.mul_le_mul_left _ hk
  have hlow : k ^ (w - 1) < a := by omega
  have hxk : k ≤ k ^ w := by
    have := Nat.pow_le_pow_right (by omega : k > 0) hw
    rwa [pow_one] at this
  by_cases hk3 : k = 3
  · subst hk3
    by_cases hw1 : w = 1
    · subst hw1
      rcases hx with hxa | hxa
      · have ha3 : a = 3 := by
          have h := hxa
          rw [pow_one] at h
          omega
        subst ha3
        exact weak_exc (p := 2) (q := 5) (by omega) (by omega) han le_rfl (Or.inl hxa) hlow
          (by omega) (by omega) (by decide) (by decide) (by decide)
          (fun _ => ⟨by decide, by decide⟩) (fun _ => ⟨by decide, by decide⟩) NN_kernel_three_three
      · have ha2 : a = 2 := by
          have h := hxa
          rw [pow_one] at h
          omega
        subst ha2
        exact weak_exc (p := 4) (q := 5) (by omega) (by omega) han le_rfl (Or.inr hxa) hlow
          (by omega) (by omega) (by decide) (by decide) (by decide)
          (fun _ => ⟨by decide, by decide⟩) (fun _ => ⟨by decide, by decide⟩) NN_kernel_three_two
    · have h9a : 3 ^ 2 ≤ 3 ^ w := Nat.pow_le_pow_right (by omega) (by omega)
      have h9b : (3 : ℕ) ^ 2 = 9 := by decide
      have hodd : 3 ^ w % 2 = 1 := by
        rw [Nat.pow_mod]
        simp
      obtain ⟨u, hu⟩ : ∃ u, 3 ^ w = 2 * u + 5 * 1 := ⟨(3 ^ w - 5) / 2, by omega⟩
      exact weak_exc (p := 2) (q := 5) (by omega) (by omega) han hw hx hlow
        (by omega) (by omega) (by decide) (by decide) (by decide)
        (fun _ => ⟨by omega, by omega⟩) (fun _ => ⟨by omega, by omega⟩)
        (NN_kernel_coin (by omega) (by omega) hu)
  · have hk4 : 4 ≤ k := by omega
    have hk2d : ¬ k ∣ 2 := fun h => by
      have := Nat.le_of_dvd (by omega) h
      omega
    have hk3d : ¬ k ∣ 3 := fun h => by
      have := Nat.le_of_dvd (by omega) h
      omega
    obtain ⟨r, hr⟩ : ∃ r, k = 2 * r + 1 ∨ k = 2 * r := ⟨k / 2, by omega⟩
    rcases hr with hodd | heven
    · have hxo : k ^ w % 2 = 1 := by
        rw [Nat.pow_mod, show k % 2 = 1 by omega]
        simp
      obtain ⟨u, hu⟩ : ∃ u, k ^ w = 2 * u + 3 * 1 := ⟨(k ^ w - 3) / 2, by omega⟩
      exact weak_exc (p := 2) (q := 3) hk2 (by omega) han hw hx hlow le_rfl (by omega)
        (by decide) hk2d hk3d (fun _ => ⟨by omega, by omega⟩) (fun _ => ⟨by omega, by omega⟩)
        (NN_kernel_coin (by omega) (by omega) hu)
    · have hxe : k ^ w = 2 * (k ^ (w - 1) * r) := by
        rw [hxw, heven]
        ring
      by_cases h43 : k = 4 ∧ a = 3
      · obtain ⟨hk4', ha3⟩ := h43
        have hk5d : ¬ k ∣ 5 := by
          rw [hk4']
          decide
        exact weak_exc (p := 2) (q := 5) hk2 (by omega) han hw hx hlow le_rfl (by omega)
          (by decide) hk2d hk5d (fun _ => ⟨by omega, by omega⟩) (fun _ => ⟨by omega, by omega⟩)
          (NN_kernel_coin (u := k ^ (w - 1) * r) (v := 0) (by omega) (by omega) (by omega))
      · exact weak_exc (p := 2) (q := 3) hk2 (by omega) han hw hx hlow le_rfl (by omega)
          (by decide) hk2d hk3d
          (fun h => ⟨by omega, fun ha3 => h43 ⟨by omega, ha3⟩⟩) (fun _ => ⟨by omega, by omega⟩)
          (NN_kernel_coin (u := k ^ (w - 1) * r) (v := 0) (by omega) (by omega) (by omega))

/-- **G1.** The unchanged adjacent weak comparison for all `k ≥ 3`, `a ≥ 1`, `n`. -/
theorem adjWeakGe3_holds : AdjWeakGe3 := by
  intro k a n hk ha
  by_cases han : a + 1 ≤ n
  · by_cases ha1 : a = 1
    · subst ha1
      exact weak_a1 hk (by omega)
    · by_cases hpow : ∃ w, k ^ w = a ∨ k ^ w = a + 1
      · obtain ⟨w, hw⟩ := hpow
        have hw1 : 1 ≤ w := by
          rcases Nat.eq_zero_or_pos w with h | h
          · subst h
            rw [pow_zero] at hw
            omega
          · exact h
        exact weak_power hk (by omega) han hw1 hw
      · have hpow' : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1 :=
          fun w => ⟨fun h => hpow ⟨w, Or.inl h⟩, fun h => hpow ⟨w, Or.inr h⟩⟩
        exact weak_NE (by omega) ha han hpow'
  · rw [C_eq_zero_of_lt (by omega : n < a + 1)]
    exact Nat.zero_le _

end RBCount

#print axioms RBCount.weak_a1
#print axioms RBCount.weak_power
#print axioms RBCount.adjWeakGe3_holds
