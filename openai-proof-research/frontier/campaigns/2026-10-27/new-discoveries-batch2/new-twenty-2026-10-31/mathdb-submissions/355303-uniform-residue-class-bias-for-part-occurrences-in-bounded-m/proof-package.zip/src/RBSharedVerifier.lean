import RBSharedFactor
namespace RBShared
open Polynomial
open scoped BigOperators
theorem factor_coeff (k a n : Nat) (b : Bool) (p : Polynomial Int) :
 (factor k a b * p).coeff n = ∑ j ∈ Finset.range k,
 if j*a ≤ n then RBPrefix.weight b j * p.coeff (n-j*a) else 0 := by
 simp only [factor, Finset.sum_mul, Polynomial.finsetSum_coeff,
   mul_assoc, Polynomial.coeff_C_mul, Polynomial.coeff_X_pow_mul']
 apply Finset.sum_congr rfl
 intro j _
 split_ifs <;> simp_all
theorem convolution_injective (k a N : Nat) (hk : 0 < k) (ha : 0 < a)
 (f g : Nat → Int)
 (h : ∀ n, n ≤ N →
  (∑ j ∈ Finset.range k, if j*a ≤ n then f (n-j*a) else 0) =
  ∑ j ∈ Finset.range k, if j*a ≤ n then g (n-j*a) else 0) :
 ∀ n, n ≤ N → f n = g n := by
 intro n
 induction n using Nat.strong_induction_on with
 | h n ih =>
  intro hn
  obtain ⟨q, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hk)
  have he := h n hn
  simp only [Finset.sum_range_succ', Nat.zero_mul, Nat.zero_le,
   ite_true, Nat.sub_zero] at he
  have ht : (∑ j ∈ Finset.range q, if (j+1)*a ≤ n then f (n-(j+1)*a) else 0) =
    ∑ j ∈ Finset.range q, if (j+1)*a ≤ n then g (n-(j+1)*a) else 0 := by
   apply Finset.sum_congr rfl
   intro j _
   split_ifs with hj
   · have hp : 0 < (j+1)*a := Nat.mul_pos (by omega) ha
     exact ih (n-(j+1)*a) (by omega) (by omega)
   · rfl
  rw [ht] at he
  exact add_left_cancel he
theorem marked_row_sound (k a N : Nat) (hk : 0 < k) (ha : 1 ≤ a) (ha' : a ≤ 142)
 (r s : List Int)
 (hp : ∀ n, n ≤ N → r.getD n 0 = (RBPrefix.actualMarked k 0).coeff n)
 (he : RBStage.step k N a false s = RBStage.step k N a true r) :
 ∀ n, n ≤ N → s.getD n 0 = (RBPrefix.actualMarked k a).coeff n := by
 apply convolution_injective k a N hk ha
 intro n hn
 have eqn := congrArg (fun t : List Int => t.getD n 0) he
 simp only [RBStage.step, RBPrefix.get_map_range N n _ hn, RBPrefix.sum_cut] at eqn
 have hr : (∑ j ∈ Finset.range k,
   if j*a ≤ n then RBPrefix.weight true j * r.getD (n-j*a) 0 else 0) =
   (factor k a true * RBPrefix.actualMarked k 0).coeff n := by
  rw [factor_coeff]
  apply Finset.sum_congr rfl
  intro j _
  split_ifs with hj
  · rw [hp (n-j*a) (by omega)]
  · rfl
 rw [hr, ← marked_factor k a ha ha', factor_coeff] at eqn
 simpa only [RBPrefix.weight, Bool.false_eq_true, ite_false, one_mul] using eqn
#print axioms convolution_injective
#print axioms marked_row_sound
end RBShared
