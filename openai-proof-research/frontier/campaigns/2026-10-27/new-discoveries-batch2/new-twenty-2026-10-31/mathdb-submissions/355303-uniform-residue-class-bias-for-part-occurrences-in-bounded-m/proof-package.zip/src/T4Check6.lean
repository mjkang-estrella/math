import T4Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T4
theorem rec6_0 : ∀ n : Fin 15, tab (n.val+2520)=step tab (n.val+2520) := by decide
theorem rec6_1 : ∀ n : Fin 15, tab (n.val+2535)=step tab (n.val+2535) := by decide
theorem rec6_2 : ∀ n : Fin 15, tab (n.val+2550)=step tab (n.val+2550) := by decide
theorem rec6_3 : ∀ n : Fin 15, tab (n.val+2565)=step tab (n.val+2565) := by decide
theorem rec6_4 : ∀ n : Fin 15, tab (n.val+2580)=step tab (n.val+2580) := by decide
theorem rec6_5 : ∀ n : Fin 15, tab (n.val+2595)=step tab (n.val+2595) := by decide
theorem rec6_6 : ∀ n : Fin 15, tab (n.val+2610)=step tab (n.val+2610) := by decide
theorem rec6_7 : ∀ n : Fin 15, tab (n.val+2625)=step tab (n.val+2625) := by decide
theorem rec6_8 : ∀ n : Fin 15, tab (n.val+2640)=step tab (n.val+2640) := by decide
theorem rec6_9 : ∀ n : Fin 15, tab (n.val+2655)=step tab (n.val+2655) := by decide
theorem rec6_10 : ∀ n : Fin 15, tab (n.val+2670)=step tab (n.val+2670) := by decide
theorem rec6_11 : ∀ n : Fin 15, tab (n.val+2685)=step tab (n.val+2685) := by decide
theorem rec6_12 : ∀ n : Fin 15, tab (n.val+2700)=step tab (n.val+2700) := by decide
theorem rec6_13 : ∀ n : Fin 15, tab (n.val+2715)=step tab (n.val+2715) := by decide
theorem rec6_14 : ∀ n : Fin 15, tab (n.val+2730)=step tab (n.val+2730) := by decide
theorem rec6_15 : ∀ n : Fin 15, tab (n.val+2745)=step tab (n.val+2745) := by decide
theorem rec6_16 : ∀ n : Fin 15, tab (n.val+2760)=step tab (n.val+2760) := by decide
theorem rec6_17 : ∀ n : Fin 15, tab (n.val+2775)=step tab (n.val+2775) := by decide
theorem rec6_18 : ∀ n : Fin 15, tab (n.val+2790)=step tab (n.val+2790) := by decide
theorem rec6_19 : ∀ n : Fin 15, tab (n.val+2805)=step tab (n.val+2805) := by decide
theorem rec6_20 : ∀ n : Fin 15, tab (n.val+2820)=step tab (n.val+2820) := by decide
theorem rec6_21 : ∀ n : Fin 15, tab (n.val+2835)=step tab (n.val+2835) := by decide
theorem rec6_22 : ∀ n : Fin 15, tab (n.val+2850)=step tab (n.val+2850) := by decide
theorem rec6_23 : ∀ n : Fin 15, tab (n.val+2865)=step tab (n.val+2865) := by decide
theorem rec6_24 : ∀ n : Fin 15, tab (n.val+2880)=step tab (n.val+2880) := by decide
theorem rec6_25 : ∀ n : Fin 15, tab (n.val+2895)=step tab (n.val+2895) := by decide
theorem rec6_26 : ∀ n : Fin 15, tab (n.val+2910)=step tab (n.val+2910) := by decide
theorem rec6_27 : ∀ n : Fin 15, tab (n.val+2925)=step tab (n.val+2925) := by decide
theorem rec6 : ∀ n : Fin 420, tab (n.val+2520)=step tab (n.val+2520) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec6_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+2520=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec6_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+2535=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec6_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+2550=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec6_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+2565=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec6_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+2580=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec6_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+2595=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec6_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+2610=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec6_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+2625=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec6_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+2640=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec6_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+2655=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec6_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+2670=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec6_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+2685=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec6_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+2700=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec6_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+2715=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec6_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+2730=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec6_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+2745=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec6_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+2760=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec6_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+2775=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec6_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+2790=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec6_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+2805=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec6_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+2820=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec6_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+2835=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec6_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+2850=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec6_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+2865=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec6_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+2880=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec6_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+2895=n.val+2520 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec6_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+2910=n.val+2520 := by omega
    simpa only [he] using h
  have h := rec6_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+2925=n.val+2520 := by omega
  simpa only [he] using h
theorem rows6 : ∀ r : Fin 60,
  0 ≤ tab (r.val+360+2520) ∧
  0 ≤ tab (r.val+360+3360)-tab (r.val+360+2520) ∧
  0 ≤ tab (r.val+360+4200)-2*tab (r.val+360+3360)+tab (r.val+360+2520) ∧
  0 ≤ tab (r.val+360+5040)-3*tab (r.val+360+4200)+3*tab (r.val+360+3360)-tab (r.val+360+2520) := by decide

#print axioms rec6
#print axioms rows6
end T4
