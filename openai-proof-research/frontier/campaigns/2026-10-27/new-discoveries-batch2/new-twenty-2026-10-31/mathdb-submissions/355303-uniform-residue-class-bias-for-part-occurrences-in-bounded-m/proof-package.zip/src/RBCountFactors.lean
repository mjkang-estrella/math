import RBCountDefs
import Mathlib.RingTheory.PowerSeries.Basic

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBCountFactors (355303 pilot B): finite factors and their coefficients

Ring: `PowerSeries ℤ`.  All objects are FINITE sums/products (no infinite product).
* `Bf k h = ∑_{i<k} X^(h i)`, `Af k h = ∑_{i<k} i · X^(h i)`;
* `markedFactor`, `marked k a N = Af k a * ∏_{h ∈ [1,N] \ {a}} Bf k h`, `prodB k N = ∏_{h ∈ [1,N]} Bf k h`;
* `coeff_Bf`, `coeff_Af` (DESIGN coeff_B / coeff_A) and the multiplicity forms.
-/

namespace RBCount

open Finset

/-- `B_h = ∑_{i<k} X^(h i)`. -/
noncomputable def Bf (k h : ℕ) : PowerSeries ℤ :=
  ∑ i ∈ range k, PowerSeries.X ^ (h * i)

/-- `A_h = ∑_{i<k} i X^(h i)` (marks each occurrence of the size `h`). -/
noncomputable def Af (k h : ℕ) : PowerSeries ℤ :=
  ∑ i ∈ range k, PowerSeries.C (i : ℤ) * PowerSeries.X ^ (h * i)

/-- Factor at size `h` of the marked product with marked size `a`. -/
noncomputable def markedFactor (k a h : ℕ) : PowerSeries ℤ :=
  if h = a then Af k a else Bf k h

/-- Finite marked product over the positive sizes `h ≤ N`. -/
noncomputable def marked (k a N : ℕ) : PowerSeries ℤ :=
  Af k a * ∏ h ∈ (Icc 1 N).erase a, Bf k h

/-- Finite unmarked product over the positive sizes `h ≤ N`. -/
noncomputable def prodB (k N : ℕ) : PowerSeries ℤ :=
  ∏ h ∈ Icc 1 N, Bf k h

/-- (DESIGN coeff_B) -/
theorem coeff_Bf (k h m : ℕ) (hh : 1 ≤ h) :
    PowerSeries.coeff m (Bf k h) = if h ∣ m ∧ m / h < k then 1 else 0 := by
  unfold Bf
  rw [map_sum]
  simp only [PowerSeries.coeff_X_pow]
  split_ifs with hc
  · obtain ⟨hd, hlt⟩ := hc
    rw [Finset.sum_eq_single (m / h)]
    · rw [ite_eq_left (Nat.mul_div_cancel' hd).symm]
    · intro i _ hi
      rw [ite_eq_right]
      intro hm
      apply hi
      rw [hm, Nat.mul_div_cancel_left i (by omega : 0 < h)]
    · intro hn
      exact absurd (Finset.mem_range.mpr hlt) hn
  · apply Finset.sum_eq_zero
    intro i hi
    rw [ite_eq_right]
    intro hm
    apply hc
    refine ⟨⟨i, hm⟩, ?_⟩
    rw [hm, Nat.mul_div_cancel_left i (by omega : 0 < h)]
    exact Finset.mem_range.mp hi

/-- (DESIGN coeff_A) -/
theorem coeff_Af (k h m : ℕ) (hh : 1 ≤ h) :
    PowerSeries.coeff m (Af k h) = if h ∣ m ∧ m / h < k then ((m / h : ℕ) : ℤ) else 0 := by
  unfold Af
  rw [map_sum]
  simp only [PowerSeries.coeff_C_mul, PowerSeries.coeff_X_pow]
  split_ifs with hc
  · obtain ⟨hd, hlt⟩ := hc
    rw [Finset.sum_eq_single (m / h)]
    · rw [ite_eq_left (Nat.mul_div_cancel' hd).symm, mul_one]
    · intro i _ hi
      rw [ite_eq_right, mul_zero]
      intro hm
      apply hi
      rw [hm, Nat.mul_div_cancel_left i (by omega : 0 < h)]
    · intro hn
      exact absurd (Finset.mem_range.mpr hlt) hn
  · apply Finset.sum_eq_zero
    intro i hi
    rw [ite_eq_right, mul_zero]
    intro hm
    apply hc
    refine ⟨⟨i, hm⟩, ?_⟩
    rw [hm, Nat.mul_div_cancel_left i (by omega : 0 < h)]
    exact Finset.mem_range.mp hi

theorem coeff_Bf_mul (k h c : ℕ) (hh : 1 ≤ h) :
    PowerSeries.coeff (c * h) (Bf k h) = if c < k then 1 else 0 := by
  rw [coeff_Bf k h (c * h) hh, Nat.mul_div_cancel c (by omega : 0 < h)]
  by_cases hc : c < k
  · rw [ite_eq_left (show h ∣ c * h ∧ c < k from ⟨⟨c, Nat.mul_comm c h⟩, hc⟩), ite_eq_left hc]
  · rw [ite_eq_right (show ¬ (h ∣ c * h ∧ c < k) from fun hh' => hc hh'.2), ite_eq_right hc]

theorem coeff_Af_mul (k h c : ℕ) (hh : 1 ≤ h) :
    PowerSeries.coeff (c * h) (Af k h) = if c < k then (c : ℤ) else 0 := by
  rw [coeff_Af k h (c * h) hh, Nat.mul_div_cancel c (by omega : 0 < h)]
  by_cases hc : c < k
  · rw [ite_eq_left (show h ∣ c * h ∧ c < k from ⟨⟨c, Nat.mul_comm c h⟩, hc⟩), ite_eq_left hc]
  · rw [ite_eq_right (show ¬ (h ∣ c * h ∧ c < k) from fun hh' => hc hh'.2), ite_eq_right hc]

theorem dvd_of_coeff_Bf_ne_zero {k h m : ℕ} (hh : 1 ≤ h)
    (hne : PowerSeries.coeff m (Bf k h) ≠ 0) : h ∣ m ∧ m / h < k := by
  rw [coeff_Bf k h m hh] at hne
  by_contra hc
  exact hne (ite_eq_right hc)

theorem dvd_of_coeff_Af_ne_zero {k h m : ℕ} (hh : 1 ≤ h)
    (hne : PowerSeries.coeff m (Af k h) ≠ 0) : h ∣ m ∧ m / h < k := by
  rw [coeff_Af k h m hh] at hne
  by_contra hc
  exact hne (ite_eq_right hc)

end RBCount

#print axioms RBCount.coeff_Bf
#print axioms RBCount.coeff_Af
