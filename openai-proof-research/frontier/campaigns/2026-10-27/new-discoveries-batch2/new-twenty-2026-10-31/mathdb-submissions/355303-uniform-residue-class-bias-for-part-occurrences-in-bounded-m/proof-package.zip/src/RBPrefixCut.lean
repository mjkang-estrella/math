import RBPrefixCoverage
namespace RBPrefix
open scoped BigOperators
def cut (k h n : Nat) : Nat := if h=0 then k else min k (n/h+1)
theorem sum_cut (k h n : Nat) (v : Nat → Int) :
 (∑ j ∈ Finset.range (cut k h n), if j*h ≤ n then v j else 0) =
 ∑ j ∈ Finset.range k, if j*h ≤ n then v j else 0 := by
 cases h with
 | zero => simp [cut]
 | succ h =>
   apply Finset.sum_subset
   · intro j hj
     have hh : j < min k (n/(h+1)+1) := by simpa [cut] using hj
     exact Finset.mem_range.mpr (by omega)
   · intro j hj hnot
     have hjk : j < k := Finset.mem_range.mp hj
     have hjc : ¬ j < min k (n/(h+1)+1) := by simpa [cut] using hnot
     have hh : n/(h+1) < j := by omega
     have ht := (Nat.div_lt_iff_lt_mul (Nat.zero_lt_succ h)).mp hh
     simp [Nat.not_le.mpr ht]
def memoCut (k N : Nat) : List (Nat × Bool) → List Int
| [] => (List.range (N+1)).map (fun n => if n=0 then 1 else 0)
| (h,b)::hs =>
 let prev := memoCut k N hs
 (List.range (N+1)).map (fun n => ∑ j ∈ Finset.range (cut k h n),
   if j*h ≤ n then weight b j * prev.getD (n-j*h) 0 else 0)
theorem memoCut_eq (k N : Nat) (hs : List (Nat × Bool)) (n : Nat) (hn : n ≤ N) :
 (memoCut k N hs).getD n 0 = coeffRun k hs n := by
 induction hs generalizing n with
 | nil => simpa only [memoCut, coeffRun] using get_map_range N n _ hn
 | cons x hs ih =>
   rcases x with ⟨h,b⟩
   simp only [memoCut, get_map_range N n _ hn, sum_cut, coeffRun]
   apply Finset.sum_congr rfl
   intro j _
   split_ifs with hj
   · rw [ih (n-j*h) (by omega)]
   · rfl
def cutCount (k a n : Nat) : Int := (memoCut k 142 (factors 142 a)).getD n 0
theorem cutCount_eq (k a n : Nat) (hn : n ≤ 142) : cutCount k a n = count k a 142 n := memoCut_eq _ _ _ _ hn
#print axioms memoCut_eq
end RBPrefix
