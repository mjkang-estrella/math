import T2Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T2
theorem rec2_0 : ∀ n : Fin 15, tab (n.val+840)=step tab (n.val+840) := by decide
theorem rec2_1 : ∀ n : Fin 15, tab (n.val+855)=step tab (n.val+855) := by decide
theorem rec2_2 : ∀ n : Fin 15, tab (n.val+870)=step tab (n.val+870) := by decide
theorem rec2_3 : ∀ n : Fin 15, tab (n.val+885)=step tab (n.val+885) := by decide
theorem rec2_4 : ∀ n : Fin 15, tab (n.val+900)=step tab (n.val+900) := by decide
theorem rec2_5 : ∀ n : Fin 15, tab (n.val+915)=step tab (n.val+915) := by decide
theorem rec2_6 : ∀ n : Fin 15, tab (n.val+930)=step tab (n.val+930) := by decide
theorem rec2_7 : ∀ n : Fin 15, tab (n.val+945)=step tab (n.val+945) := by decide
theorem rec2_8 : ∀ n : Fin 15, tab (n.val+960)=step tab (n.val+960) := by decide
theorem rec2_9 : ∀ n : Fin 15, tab (n.val+975)=step tab (n.val+975) := by decide
theorem rec2_10 : ∀ n : Fin 15, tab (n.val+990)=step tab (n.val+990) := by decide
theorem rec2_11 : ∀ n : Fin 15, tab (n.val+1005)=step tab (n.val+1005) := by decide
theorem rec2_12 : ∀ n : Fin 15, tab (n.val+1020)=step tab (n.val+1020) := by decide
theorem rec2_13 : ∀ n : Fin 15, tab (n.val+1035)=step tab (n.val+1035) := by decide
theorem rec2_14 : ∀ n : Fin 15, tab (n.val+1050)=step tab (n.val+1050) := by decide
theorem rec2_15 : ∀ n : Fin 15, tab (n.val+1065)=step tab (n.val+1065) := by decide
theorem rec2_16 : ∀ n : Fin 15, tab (n.val+1080)=step tab (n.val+1080) := by decide
theorem rec2_17 : ∀ n : Fin 15, tab (n.val+1095)=step tab (n.val+1095) := by decide
theorem rec2_18 : ∀ n : Fin 15, tab (n.val+1110)=step tab (n.val+1110) := by decide
theorem rec2_19 : ∀ n : Fin 15, tab (n.val+1125)=step tab (n.val+1125) := by decide
theorem rec2_20 : ∀ n : Fin 15, tab (n.val+1140)=step tab (n.val+1140) := by decide
theorem rec2_21 : ∀ n : Fin 15, tab (n.val+1155)=step tab (n.val+1155) := by decide
theorem rec2_22 : ∀ n : Fin 15, tab (n.val+1170)=step tab (n.val+1170) := by decide
theorem rec2_23 : ∀ n : Fin 15, tab (n.val+1185)=step tab (n.val+1185) := by decide
theorem rec2_24 : ∀ n : Fin 15, tab (n.val+1200)=step tab (n.val+1200) := by decide
theorem rec2_25 : ∀ n : Fin 15, tab (n.val+1215)=step tab (n.val+1215) := by decide
theorem rec2_26 : ∀ n : Fin 15, tab (n.val+1230)=step tab (n.val+1230) := by decide
theorem rec2_27 : ∀ n : Fin 15, tab (n.val+1245)=step tab (n.val+1245) := by decide
theorem rec2 : ∀ n : Fin 420, tab (n.val+840)=step tab (n.val+840) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec2_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+840=n.val+840 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec2_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+855=n.val+840 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec2_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+870=n.val+840 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec2_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+885=n.val+840 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec2_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+900=n.val+840 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec2_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+915=n.val+840 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec2_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+930=n.val+840 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec2_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+945=n.val+840 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec2_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+960=n.val+840 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec2_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+975=n.val+840 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec2_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+990=n.val+840 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec2_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+1005=n.val+840 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec2_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+1020=n.val+840 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec2_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+1035=n.val+840 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec2_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+1050=n.val+840 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec2_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+1065=n.val+840 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec2_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+1080=n.val+840 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec2_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+1095=n.val+840 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec2_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+1110=n.val+840 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec2_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+1125=n.val+840 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec2_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+1140=n.val+840 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec2_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+1155=n.val+840 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec2_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+1170=n.val+840 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec2_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+1185=n.val+840 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec2_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+1200=n.val+840 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec2_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+1215=n.val+840 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec2_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+1230=n.val+840 := by omega
    simpa only [he] using h
  have h := rec2_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+1245=n.val+840 := by omega
  simpa only [he] using h
theorem rows2 : ∀ r : Fin 60,
  0 ≤ tab (r.val+120+1260) ∧
  0 ≤ tab (r.val+120+1680)-tab (r.val+120+1260) ∧
  0 ≤ tab (r.val+120+2100)-2*tab (r.val+120+1680)+tab (r.val+120+1260) ∧
  0 ≤ tab (r.val+120+2520)-3*tab (r.val+120+2100)+3*tab (r.val+120+1680)-tab (r.val+120+1260) := by decide
theorem pref2 : ∀ n : Fin 420, n.val+840≠4 → 0≤tab (n.val+840) := by decide

#print axioms rec2
#print axioms rows2
#print axioms pref2
end T2
