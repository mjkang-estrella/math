import RBSharedSparseAlgebra
import RBSharedFn
set_option maxRecDepth 100000
namespace RBShared
open Polynomial
open scoped BigOperators
def shift (d : Nat) (f : Nat → Int) (n : Nat) : Int := if d ≤ n then f (n-d) else 0
def sparseLeft (k a : Nat) (c : Nat → Int) (n : Nat) : Int :=
 c n - shift a c n - shift (k*a) c n + shift ((k+1)*a) c n
def sparseRight (k a : Nat) (p : Nat → Int) (n : Nat) : Int :=
 shift a p n - (k : Int)*shift (k*a) p n + ((k : Int)-1)*shift ((k+1)*a) p n
theorem shifted_coeff (d n : Nat) (p : Polynomial Int) :
 (X^d*p).coeff n = shift d p.coeff n := by
 rw [Polynomial.coeff_X_pow_mul']
 unfold shift
 split_ifs <;> simp_all
theorem sparse_actual (k a n : Nat) (ha : 1 ≤ a) (ha' : a ≤ 142) :
 sparseLeft k a (RBPrefix.actualMarked k a).coeff n =
 sparseRight k a (RBPrefix.actualMarked k 0).coeff n := by
 have e := congrArg (fun p : Polynomial Int => p.coeff n) (sparse_marked_factor k a ha ha')
 have hm (p : Polynomial Int) : ((1-X^a)*(1-X^(k*a)))*p =
  p-X^a*p-X^(k*a)*p+X^((k+1)*a)*p := by
  rw [Nat.add_mul, one_mul, pow_add]
  ring
 rw [hm] at e
 simp only [sub_mul, add_mul, mul_assoc, Polynomial.coeff_add,
  Polynomial.coeff_sub, Polynomial.coeff_C_mul, shifted_coeff] at e
 simp only [← Nat.add_mul] at e
 simpa only [sparseLeft, sparseRight, sub_mul] using e
def sparseCheck (k N a : Nat) (p c : Nat → Int) : Bool :=
 (List.range (N+1)).all fun n => decide (sparseLeft k a c n = sparseRight k a p n)
theorem shift_congr (N d n : Nat) (f g : Nat → Int)
 (h : ∀ m, m ≤ N → f m = g m) (hn : n ≤ N) : shift d f n = shift d g n := by
 unfold shift
 split_ifs
 · exact h (n-d) (by omega)
 · rfl
theorem sparse_function_sound (k a N : Nat) (hk : 0 < k) (ha : 1 ≤ a) (ha' : a ≤ 142)
 (p c : Nat → Int)
 (hp : ∀ n, n ≤ N → p n = (RBPrefix.actualMarked k 0).coeff n)
 (hc : sparseCheck k N a p c = true) :
 ∀ n, n ≤ N → c n = (RBPrefix.actualMarked k a).coeff n := by
 intro n
 induction n using Nat.strong_induction_on with
 | h n ih =>
  intro hn
  have he := (List.all_eq_true.mp hc) n (List.mem_range.mpr (by omega))
  simp only [decide_eq_true_eq] at he
  have hr : sparseRight k a p n = sparseRight k a (RBPrefix.actualMarked k 0).coeff n := by
   unfold sparseRight
   rw [shift_congr N a n _ _ hp hn, shift_congr N (k*a) n _ _ hp hn,
     shift_congr N ((k+1)*a) n _ _ hp hn]
  have hs (d : Nat) (hd : 0 < d) : shift d c n = shift d (RBPrefix.actualMarked k a).coeff n := by
   unfold shift
   split_ifs
   · exact ih (n-d) (by omega) (by omega)
   · rfl
  rw [hr] at he
  unfold sparseLeft at he
  rw [hs a ha, hs (k*a) (Nat.mul_pos hk ha),
   hs ((k+1)*a) (Nat.mul_pos (by omega) ha)] at he
  have ht := sparse_actual k a n ha ha'
  unfold sparseLeft at ht
  omega
#print axioms sparse_actual
#print axioms sparse_function_sound
end RBShared
