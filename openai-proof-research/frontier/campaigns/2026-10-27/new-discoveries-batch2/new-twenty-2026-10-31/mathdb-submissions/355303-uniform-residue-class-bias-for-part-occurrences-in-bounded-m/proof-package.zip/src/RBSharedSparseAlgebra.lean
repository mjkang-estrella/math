import RBSharedFactor
namespace RBShared
open Polynomial
open scoped BigOperators
theorem geometric (x : Polynomial Int) (k : Nat) :
 (1-x) * (∑ j ∈ Finset.range k, x^j) = 1-x^k := by
 induction k with
 | zero => simp
 | succ k ih =>
  rw [Finset.sum_range_succ, mul_add, ih, pow_succ]
  ring
theorem weighted_geometric (x : Polynomial Int) (k : Nat) :
 (1-x)^2 * (∑ j ∈ Finset.range k, (j : Polynomial Int)*x^j) =
 x - (k : Polynomial Int)*x^k + ((k : Polynomial Int)-1)*x^(k+1) := by
 induction k with
 | zero => simp
 | succ k ih =>
  rw [Finset.sum_range_succ, mul_add, ih]
  simp only [Nat.cast_add, Nat.cast_one, pow_succ]
  ring
theorem factor_geometric (k a : Nat) :
 (1-X^a) * factor k a false = 1-X^(k*a) := by
 have he : factor k a false = ∑ j ∈ Finset.range k, (X^a : Polynomial Int)^j := by
  simp [factor, RBPrefix.weight, pow_mul, Nat.mul_comm]
 rw [he, geometric]
 simp [← pow_mul, Nat.mul_comm]
theorem factor_weighted_geometric (k a : Nat) :
 (1-X^a)^2 * factor k a true =
 X^a - C (k : Int)*X^(k*a) + C ((k : Int)-1)*X^((k+1)*a) := by
 have he : factor k a true = ∑ j ∈ Finset.range k,
   (j : Polynomial Int)*(X^a)^j := by
  simp [factor, RBPrefix.weight, pow_mul, Nat.mul_comm]
 rw [he, weighted_geometric]
 simp [← pow_mul, Nat.mul_comm]
theorem sparse_marked_factor (k a : Nat) (ha : 1 ≤ a) (ha' : a ≤ 142) :
 ((1-X^a)*(1-X^(k*a))) * RBPrefix.actualMarked k a =
 (X^a - C (k : Int)*X^(k*a) + C ((k : Int)-1)*X^((k+1)*a)) * RBPrefix.actualMarked k 0 := by
 have h := congrArg (fun p : Polynomial Int => (1-X^a)^2 * p) (marked_factor k a ha ha')
 have hu := factor_geometric k a
 have hv := factor_weighted_geometric k a
 calc
  _ = (1-X^a) * ((1-X^a)*factor k a false) * RBPrefix.actualMarked k a := by rw [hu]
  _ = (1-X^a)^2 * (factor k a false * RBPrefix.actualMarked k a) := by ring
  _ = (1-X^a)^2 * (factor k a true * RBPrefix.actualMarked k 0) := h
  _ = _ := by rw [← mul_assoc, hv]
#print axioms sparse_marked_factor
end RBShared
