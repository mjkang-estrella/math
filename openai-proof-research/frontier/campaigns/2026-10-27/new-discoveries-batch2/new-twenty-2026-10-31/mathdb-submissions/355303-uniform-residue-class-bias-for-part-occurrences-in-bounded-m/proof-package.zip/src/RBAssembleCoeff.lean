import RBPrefixEndpoint
import RBCountMarked

/-!
# RBAssembleCoeff (355303, formal-opus-r4-restart1): finite polynomial coefficients = native `C`

The ORIGINAL finite polynomial `RBPrefix.actualMarked k a` (unchanged paid definition) has, in every
degree `n ≤ 142`, exactly the coefficient `(RBCount.C k a n : ℤ)` of the UNCHANGED native count,
for `1 ≤ k` and `1 ≤ a ≤ 142`.  Proof: the coefficient-preserving ring hom `ℤ[X] →+* ℤ⟦X⟧` maps the
polynomial factorwise onto the paid marked product `RBCount.marked k a 142`, whose coefficients are
`C` by the paid theorem `RBCount.coeff_marked`.
-/

namespace RBAssemble

open Finset

/-- The coercion of the original finite polynomial is the shifted product of the paid marked factors. -/
theorem coe_actualMarked (k a : ℕ) :
    ((RBPrefix.actualMarked k a : Polynomial ℤ) : PowerSeries ℤ) =
      ∏ h ∈ range 142, RBCount.markedFactor k a (h + 1) := by
  have e : ((RBPrefix.actualMarked k a : Polynomial ℤ) : PowerSeries ℤ) =
      Polynomial.coeToPowerSeries.ringHom (RBPrefix.actualMarked k a) := by
    rw [Polynomial.coeToPowerSeries.ringHom_apply]
  rw [e]
  unfold RBPrefix.actualMarked
  rw [map_prod]
  refine prod_congr rfl fun h _ => ?_
  rw [map_sum]
  unfold RBCount.markedFactor
  by_cases hh : h + 1 = a
  · rw [ite_eq_left hh]
    unfold RBCount.Af
    refine sum_congr rfl fun j _ => ?_
    have hb : (h + 1 == a) = true := beq_iff_eq.mpr hh
    rw [map_mul, map_pow, Polynomial.coeToPowerSeries.ringHom_apply,
      Polynomial.coeToPowerSeries.ringHom_apply, Polynomial.coe_C, Polynomial.coe_X, ite_eq_left hb,
      ← hh, Nat.mul_comm j (h + 1)]
  · rw [ite_eq_right hh]
    unfold RBCount.Bf
    refine sum_congr rfl fun j _ => ?_
    have hb : ¬ (h + 1 == a) = true := fun e => hh (beq_iff_eq.mp e)
    rw [map_mul, map_pow, Polynomial.coeToPowerSeries.ringHom_apply,
      Polynomial.coeToPowerSeries.ringHom_apply, Polynomial.coe_C, Polynomial.coe_X, ite_eq_right hb,
      map_one, one_mul, Nat.mul_comm j (h + 1)]

/-- Reindexing `range 142` (shift by one) onto `Icc 1 142`. -/
theorem prod_shift (k a : ℕ) :
    ∏ h ∈ range 142, RBCount.markedFactor k a (h + 1) =
      ∏ h ∈ Icc 1 142, RBCount.markedFactor k a h := by
  refine prod_nbij' (fun h => h + 1) (fun h => h - 1) ?_ ?_ ?_ ?_ ?_
  · intro x hx
    rw [mem_range] at hx
    rw [mem_Icc]
    omega
  · intro x hx
    rw [mem_Icc] at hx
    rw [mem_range]
    omega
  · intro x _
    show x + 1 - 1 = x
    omega
  · intro x hx
    rw [mem_Icc] at hx
    show x - 1 + 1 = x
    omega
  · intro x _
    rfl

/-- The coercion of the original finite polynomial is the paid finite marked product. -/
theorem coe_actualMarked_eq_marked {k a : ℕ} (ha : 1 ≤ a) (ha' : a ≤ 142) :
    ((RBPrefix.actualMarked k a : Polynomial ℤ) : PowerSeries ℤ) = RBCount.marked k a 142 := by
  rw [coe_actualMarked, prod_shift, RBCount.marked_eq_prod (mem_Icc.mpr ⟨ha, ha'⟩)]

/-- **Coefficient bridge.** Original finite polynomial coefficient = unchanged native `RBCount.C`. -/
theorem coeff_actualMarked {k a n : ℕ} (hk : 1 ≤ k) (ha : 1 ≤ a) (ha' : a ≤ 142) (hn : n ≤ 142) :
    (RBPrefix.actualMarked k a).coeff n = (RBCount.C k a n : ℤ) := by
  rw [← Polynomial.coeff_coe, coe_actualMarked_eq_marked ha ha']
  exact RBCount.coeff_marked hk (mem_Icc.mpr ⟨ha, ha'⟩) hn

/-- Expanded form for the full prefix range used by `RBPrefix.Required` (`k ≥ 2`). -/
theorem coeff_actualMarked_range :
    ∀ k a n : ℕ, 2 ≤ k → 1 ≤ a → a ≤ 142 → n ≤ 142 →
      (RBPrefix.actualMarked k a).coeff n = (RBCount.C k a n : ℤ) :=
  fun k a n hk ha ha' hn => coeff_actualMarked (by omega) ha ha' hn

end RBAssemble

#print axioms RBAssemble.coe_actualMarked
#print axioms RBAssemble.prod_shift
#print axioms RBAssemble.coe_actualMarked_eq_marked
#print axioms RBAssemble.coeff_actualMarked
#print axioms RBAssemble.coeff_actualMarked_range
