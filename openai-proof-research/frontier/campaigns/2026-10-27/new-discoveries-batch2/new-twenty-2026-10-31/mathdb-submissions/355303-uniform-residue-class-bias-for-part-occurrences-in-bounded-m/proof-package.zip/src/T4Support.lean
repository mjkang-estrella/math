import T4Semantics
import Support
noncomputable section
namespace T4
open PowerSeries
open T1 (Bound bound_mul bound_sub bound_pow bound_geom)
theorem bound_Z : Bound (Z (X : PowerSeries ℤ)) 3346 := by
  unfold Z G
  apply bound_mul (b := 2512) (c := 834)
  · apply bound_mul (b := 1674) (c := 838)
    · apply bound_mul (b := 843) (c := 831)
      · apply bound_mul (b := 10) (c := 833)
        · apply bound_mul (b := 5) (c := 5)
          · exact bound_pow 4 5 (by decide)
          · exact bound_sub (by simpa using bound_pow 0 5 (by decide)) (bound_pow 4 5 (by decide))
        · exact bound_geom 8 105 833 (by intro i hi; omega)
      · exact bound_geom 10 84 831 (by intro i hi; omega)
    · exact bound_geom 3 280 838 (by intro i hi; omega)
  · exact bound_geom 7 120 834 (by intro i hi; omega)

#print axioms bound_Z
end T4
