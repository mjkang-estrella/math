import T3Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T3
theorem rec13_0 : ∀ n : Fin 15, tab (n.val+5460)=step tab (n.val+5460) := by decide
theorem rec13_1 : ∀ n : Fin 15, tab (n.val+5475)=step tab (n.val+5475) := by decide
theorem rec13_2 : ∀ n : Fin 15, tab (n.val+5490)=step tab (n.val+5490) := by decide
theorem rec13_3 : ∀ n : Fin 15, tab (n.val+5505)=step tab (n.val+5505) := by decide
theorem rec13_4 : ∀ n : Fin 15, tab (n.val+5520)=step tab (n.val+5520) := by decide
theorem rec13_5 : ∀ n : Fin 15, tab (n.val+5535)=step tab (n.val+5535) := by decide
theorem rec13_6 : ∀ n : Fin 15, tab (n.val+5550)=step tab (n.val+5550) := by decide
theorem rec13_7 : ∀ n : Fin 15, tab (n.val+5565)=step tab (n.val+5565) := by decide
theorem rec13_8 : ∀ n : Fin 15, tab (n.val+5580)=step tab (n.val+5580) := by decide
theorem rec13_9 : ∀ n : Fin 15, tab (n.val+5595)=step tab (n.val+5595) := by decide
theorem rec13_10 : ∀ n : Fin 15, tab (n.val+5610)=step tab (n.val+5610) := by decide
theorem rec13_11 : ∀ n : Fin 15, tab (n.val+5625)=step tab (n.val+5625) := by decide
theorem rec13_12 : ∀ n : Fin 15, tab (n.val+5640)=step tab (n.val+5640) := by decide
theorem rec13_13 : ∀ n : Fin 15, tab (n.val+5655)=step tab (n.val+5655) := by decide
theorem rec13_14 : ∀ n : Fin 15, tab (n.val+5670)=step tab (n.val+5670) := by decide
theorem rec13_15 : ∀ n : Fin 15, tab (n.val+5685)=step tab (n.val+5685) := by decide
theorem rec13_16 : ∀ n : Fin 15, tab (n.val+5700)=step tab (n.val+5700) := by decide
theorem rec13_17 : ∀ n : Fin 15, tab (n.val+5715)=step tab (n.val+5715) := by decide
theorem rec13_18 : ∀ n : Fin 15, tab (n.val+5730)=step tab (n.val+5730) := by decide
theorem rec13_19 : ∀ n : Fin 15, tab (n.val+5745)=step tab (n.val+5745) := by decide
theorem rec13_20 : ∀ n : Fin 15, tab (n.val+5760)=step tab (n.val+5760) := by decide
theorem rec13_21 : ∀ n : Fin 15, tab (n.val+5775)=step tab (n.val+5775) := by decide
theorem rec13_22 : ∀ n : Fin 15, tab (n.val+5790)=step tab (n.val+5790) := by decide
theorem rec13_23 : ∀ n : Fin 15, tab (n.val+5805)=step tab (n.val+5805) := by decide
theorem rec13_24 : ∀ n : Fin 15, tab (n.val+5820)=step tab (n.val+5820) := by decide
theorem rec13_25 : ∀ n : Fin 15, tab (n.val+5835)=step tab (n.val+5835) := by decide
theorem rec13_26 : ∀ n : Fin 15, tab (n.val+5850)=step tab (n.val+5850) := by decide
theorem rec13_27 : ∀ n : Fin 15, tab (n.val+5865)=step tab (n.val+5865) := by decide
theorem rec13 : ∀ n : Fin 420, tab (n.val+5460)=step tab (n.val+5460) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec13_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+5460=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec13_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+5475=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec13_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+5490=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec13_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+5505=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec13_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+5520=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec13_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+5535=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec13_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+5550=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec13_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+5565=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec13_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+5580=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec13_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+5595=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec13_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+5610=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec13_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+5625=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec13_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+5640=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec13_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+5655=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec13_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+5670=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec13_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+5685=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec13_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+5700=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec13_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+5715=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec13_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+5730=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec13_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+5745=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec13_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+5760=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec13_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+5775=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec13_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+5790=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec13_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+5805=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec13_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+5820=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec13_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+5835=n.val+5460 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec13_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+5850=n.val+5460 := by omega
    simpa only [he] using h
  have h := rec13_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+5865=n.val+5460 := by omega
  simpa only [he] using h
theorem rows13 : ∀ r : Fin 60,
  0 ≤ tab (r.val+780+2520) ∧
  0 ≤ tab (r.val+780+3360)-tab (r.val+780+2520) ∧
  0 ≤ tab (r.val+780+4200)-2*tab (r.val+780+3360)+tab (r.val+780+2520) ∧
  0 ≤ tab (r.val+780+5040)-3*tab (r.val+780+4200)+3*tab (r.val+780+3360)-tab (r.val+780+2520) := by decide

#print axioms rec13
#print axioms rows13
end T3
