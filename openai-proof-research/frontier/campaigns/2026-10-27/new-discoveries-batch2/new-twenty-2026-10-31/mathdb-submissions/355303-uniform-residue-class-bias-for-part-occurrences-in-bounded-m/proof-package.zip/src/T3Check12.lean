import T3Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T3
theorem rec12_0 : ∀ n : Fin 15, tab (n.val+5040)=step tab (n.val+5040) := by decide
theorem rec12_1 : ∀ n : Fin 15, tab (n.val+5055)=step tab (n.val+5055) := by decide
theorem rec12_2 : ∀ n : Fin 15, tab (n.val+5070)=step tab (n.val+5070) := by decide
theorem rec12_3 : ∀ n : Fin 15, tab (n.val+5085)=step tab (n.val+5085) := by decide
theorem rec12_4 : ∀ n : Fin 15, tab (n.val+5100)=step tab (n.val+5100) := by decide
theorem rec12_5 : ∀ n : Fin 15, tab (n.val+5115)=step tab (n.val+5115) := by decide
theorem rec12_6 : ∀ n : Fin 15, tab (n.val+5130)=step tab (n.val+5130) := by decide
theorem rec12_7 : ∀ n : Fin 15, tab (n.val+5145)=step tab (n.val+5145) := by decide
theorem rec12_8 : ∀ n : Fin 15, tab (n.val+5160)=step tab (n.val+5160) := by decide
theorem rec12_9 : ∀ n : Fin 15, tab (n.val+5175)=step tab (n.val+5175) := by decide
theorem rec12_10 : ∀ n : Fin 15, tab (n.val+5190)=step tab (n.val+5190) := by decide
theorem rec12_11 : ∀ n : Fin 15, tab (n.val+5205)=step tab (n.val+5205) := by decide
theorem rec12_12 : ∀ n : Fin 15, tab (n.val+5220)=step tab (n.val+5220) := by decide
theorem rec12_13 : ∀ n : Fin 15, tab (n.val+5235)=step tab (n.val+5235) := by decide
theorem rec12_14 : ∀ n : Fin 15, tab (n.val+5250)=step tab (n.val+5250) := by decide
theorem rec12_15 : ∀ n : Fin 15, tab (n.val+5265)=step tab (n.val+5265) := by decide
theorem rec12_16 : ∀ n : Fin 15, tab (n.val+5280)=step tab (n.val+5280) := by decide
theorem rec12_17 : ∀ n : Fin 15, tab (n.val+5295)=step tab (n.val+5295) := by decide
theorem rec12_18 : ∀ n : Fin 15, tab (n.val+5310)=step tab (n.val+5310) := by decide
theorem rec12_19 : ∀ n : Fin 15, tab (n.val+5325)=step tab (n.val+5325) := by decide
theorem rec12_20 : ∀ n : Fin 15, tab (n.val+5340)=step tab (n.val+5340) := by decide
theorem rec12_21 : ∀ n : Fin 15, tab (n.val+5355)=step tab (n.val+5355) := by decide
theorem rec12_22 : ∀ n : Fin 15, tab (n.val+5370)=step tab (n.val+5370) := by decide
theorem rec12_23 : ∀ n : Fin 15, tab (n.val+5385)=step tab (n.val+5385) := by decide
theorem rec12_24 : ∀ n : Fin 15, tab (n.val+5400)=step tab (n.val+5400) := by decide
theorem rec12_25 : ∀ n : Fin 15, tab (n.val+5415)=step tab (n.val+5415) := by decide
theorem rec12_26 : ∀ n : Fin 15, tab (n.val+5430)=step tab (n.val+5430) := by decide
theorem rec12_27 : ∀ n : Fin 15, tab (n.val+5445)=step tab (n.val+5445) := by decide
theorem rec12 : ∀ n : Fin 420, tab (n.val+5040)=step tab (n.val+5040) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec12_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+5040=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec12_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+5055=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec12_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+5070=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec12_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+5085=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec12_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+5100=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec12_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+5115=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec12_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+5130=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec12_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+5145=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec12_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+5160=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec12_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+5175=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec12_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+5190=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec12_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+5205=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec12_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+5220=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec12_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+5235=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec12_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+5250=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec12_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+5265=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec12_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+5280=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec12_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+5295=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec12_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+5310=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec12_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+5325=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec12_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+5340=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec12_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+5355=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec12_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+5370=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec12_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+5385=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec12_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+5400=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec12_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+5415=n.val+5040 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec12_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+5430=n.val+5040 := by omega
    simpa only [he] using h
  have h := rec12_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+5445=n.val+5040 := by omega
  simpa only [he] using h
theorem rows12 : ∀ r : Fin 60,
  0 ≤ tab (r.val+720+2520) ∧
  0 ≤ tab (r.val+720+3360)-tab (r.val+720+2520) ∧
  0 ≤ tab (r.val+720+4200)-2*tab (r.val+720+3360)+tab (r.val+720+2520) ∧
  0 ≤ tab (r.val+720+5040)-3*tab (r.val+720+4200)+3*tab (r.val+720+3360)-tab (r.val+720+2520) := by decide

#print axioms rec12
#print axioms rows12
end T3
