import T4Check0
import T4Check1
import T4Check2
import T4Check3
import T4Check4
import T4Check5
import T4Check6
import T4Check7
import T4Check8
import T4Check9
import T4Check10
import T4Check11
import T4Check12
import T4Check13
namespace T4
theorem tab_recurrence : ∀ n : Fin 5880, tab n = step tab n := by
  intro n
  by_cases h0 : n.val < 420
  · have he : n.val-0+0=n.val := by omega
    have h := rec0 ⟨n.val-0,by omega⟩
    simpa only [he] using h
  by_cases h1 : n.val < 840
  · have he : n.val-420+420=n.val := by omega
    have h := rec1 ⟨n.val-420,by omega⟩
    simpa only [he] using h
  by_cases h2 : n.val < 1260
  · have he : n.val-840+840=n.val := by omega
    have h := rec2 ⟨n.val-840,by omega⟩
    simpa only [he] using h
  by_cases h3 : n.val < 1680
  · have he : n.val-1260+1260=n.val := by omega
    have h := rec3 ⟨n.val-1260,by omega⟩
    simpa only [he] using h
  by_cases h4 : n.val < 2100
  · have he : n.val-1680+1680=n.val := by omega
    have h := rec4 ⟨n.val-1680,by omega⟩
    simpa only [he] using h
  by_cases h5 : n.val < 2520
  · have he : n.val-2100+2100=n.val := by omega
    have h := rec5 ⟨n.val-2100,by omega⟩
    simpa only [he] using h
  by_cases h6 : n.val < 2940
  · have he : n.val-2520+2520=n.val := by omega
    have h := rec6 ⟨n.val-2520,by omega⟩
    simpa only [he] using h
  by_cases h7 : n.val < 3360
  · have he : n.val-2940+2940=n.val := by omega
    have h := rec7 ⟨n.val-2940,by omega⟩
    simpa only [he] using h
  by_cases h8 : n.val < 3780
  · have he : n.val-3360+3360=n.val := by omega
    have h := rec8 ⟨n.val-3360,by omega⟩
    simpa only [he] using h
  by_cases h9 : n.val < 4200
  · have he : n.val-3780+3780=n.val := by omega
    have h := rec9 ⟨n.val-3780,by omega⟩
    simpa only [he] using h
  by_cases h10 : n.val < 4620
  · have he : n.val-4200+4200=n.val := by omega
    have h := rec10 ⟨n.val-4200,by omega⟩
    simpa only [he] using h
  by_cases h11 : n.val < 5040
  · have he : n.val-4620+4620=n.val := by omega
    have h := rec11 ⟨n.val-4620,by omega⟩
    simpa only [he] using h
  by_cases h12 : n.val < 5460
  · have he : n.val-5040+5040=n.val := by omega
    have h := rec12 ⟨n.val-5040,by omega⟩
    simpa only [he] using h
  have he : n.val-5460+5460=n.val := by omega
  have h := rec13 ⟨n.val-5460,by omega⟩
  simpa only [he] using h
theorem tab_prefix : ∀ n : Fin 2520, n.val≠8 → 0≤tab n := by
  intro n hn8
  by_cases h0 : n.val < 420
  · have he : n.val-0+0=n.val := by omega
    have h := pref0 ⟨n.val-0,by omega⟩ (by simpa only [he] using hn8)
    simpa only [he] using h
  by_cases h1 : n.val < 840
  · have he : n.val-420+420=n.val := by omega
    have h := pref1 ⟨n.val-420,by omega⟩ (by simpa only [he] using hn8)
    simpa only [he] using h
  by_cases h2 : n.val < 1260
  · have he : n.val-840+840=n.val := by omega
    have h := pref2 ⟨n.val-840,by omega⟩ (by simpa only [he] using hn8)
    simpa only [he] using h
  by_cases h3 : n.val < 1680
  · have he : n.val-1260+1260=n.val := by omega
    have h := pref3 ⟨n.val-1260,by omega⟩ (by simpa only [he] using hn8)
    simpa only [he] using h
  by_cases h4 : n.val < 2100
  · have he : n.val-1680+1680=n.val := by omega
    have h := pref4 ⟨n.val-1680,by omega⟩ (by simpa only [he] using hn8)
    simpa only [he] using h
  have he : n.val-2100+2100=n.val := by omega
  have h := pref5 ⟨n.val-2100,by omega⟩ (by simpa only [he] using hn8)
  simpa only [he] using h
theorem tab_rows : ∀ r : Fin 840, 0 ≤ tab (r+2520) ∧ 0 ≤ tab (r+3360)-tab (r+2520) ∧ 0 ≤ tab (r+4200)-2*tab (r+3360)+tab (r+2520) ∧ 0 ≤ tab (r+5040)-3*tab (r+4200)+3*tab (r+3360)-tab (r+2520) := by
  intro r
  by_cases h0 : r.val < 60
  · have he : r.val-0+0=r.val := by omega
    have h := rows0 ⟨r.val-0,by omega⟩
    simpa only [he] using h
  by_cases h1 : r.val < 120
  · have he : r.val-60+60=r.val := by omega
    have h := rows1 ⟨r.val-60,by omega⟩
    simpa only [he] using h
  by_cases h2 : r.val < 180
  · have he : r.val-120+120=r.val := by omega
    have h := rows2 ⟨r.val-120,by omega⟩
    simpa only [he] using h
  by_cases h3 : r.val < 240
  · have he : r.val-180+180=r.val := by omega
    have h := rows3 ⟨r.val-180,by omega⟩
    simpa only [he] using h
  by_cases h4 : r.val < 300
  · have he : r.val-240+240=r.val := by omega
    have h := rows4 ⟨r.val-240,by omega⟩
    simpa only [he] using h
  by_cases h5 : r.val < 360
  · have he : r.val-300+300=r.val := by omega
    have h := rows5 ⟨r.val-300,by omega⟩
    simpa only [he] using h
  by_cases h6 : r.val < 420
  · have he : r.val-360+360=r.val := by omega
    have h := rows6 ⟨r.val-360,by omega⟩
    simpa only [he] using h
  by_cases h7 : r.val < 480
  · have he : r.val-420+420=r.val := by omega
    have h := rows7 ⟨r.val-420,by omega⟩
    simpa only [he] using h
  by_cases h8 : r.val < 540
  · have he : r.val-480+480=r.val := by omega
    have h := rows8 ⟨r.val-480,by omega⟩
    simpa only [he] using h
  by_cases h9 : r.val < 600
  · have he : r.val-540+540=r.val := by omega
    have h := rows9 ⟨r.val-540,by omega⟩
    simpa only [he] using h
  by_cases h10 : r.val < 660
  · have he : r.val-600+600=r.val := by omega
    have h := rows10 ⟨r.val-600,by omega⟩
    simpa only [he] using h
  by_cases h11 : r.val < 720
  · have he : r.val-660+660=r.val := by omega
    have h := rows11 ⟨r.val-660,by omega⟩
    simpa only [he] using h
  by_cases h12 : r.val < 780
  · have he : r.val-720+720=r.val := by omega
    have h := rows12 ⟨r.val-720,by omega⟩
    simpa only [he] using h
  have he : r.val-780+780=r.val := by omega
  have h := rows13 ⟨r.val-780,by omega⟩
  simpa only [he] using h
theorem tab_negative8 : tab 8=-1 := by decide

#print axioms tab_recurrence
#print axioms tab_prefix
#print axioms tab_rows
#print axioms tab_negative8
end T4
