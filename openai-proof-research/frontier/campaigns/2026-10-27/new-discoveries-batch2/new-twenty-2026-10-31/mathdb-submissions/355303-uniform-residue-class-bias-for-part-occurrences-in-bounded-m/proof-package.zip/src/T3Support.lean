import T3Semantics
import Support
noncomputable section
namespace T3
open PowerSeries
open T1 (Bound bound_mul bound_sub bound_pow bound_geom)
theorem bound_Z : Bound (Z (X : PowerSeries ℤ)) 3347 := by
  unfold Z G
  apply bound_mul (b := 2513) (c := 834)
  · apply bound_mul (b := 1677) (c := 836)
    · apply bound_mul (b := 842) (c := 835)
      · apply bound_mul (b := 9) (c := 833)
        · apply bound_mul (b := 4) (c := 5)
          · exact bound_pow 3 4 (by decide)
          · exact bound_sub (by simpa using bound_pow 0 5 (by decide)) (bound_pow 4 5 (by decide))
        · exact bound_geom 8 105 833 (by intro i hi; omega)
      · exact bound_geom 6 140 835 (by intro i hi; omega)
    · exact bound_geom 5 168 836 (by intro i hi; omega)
  · exact bound_geom 7 120 834 (by intro i hi; omega)

#print axioms bound_Z
end T3
