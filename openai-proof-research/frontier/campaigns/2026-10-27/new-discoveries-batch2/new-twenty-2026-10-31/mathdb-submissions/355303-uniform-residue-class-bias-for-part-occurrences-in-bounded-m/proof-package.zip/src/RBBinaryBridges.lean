import RBBinaryMarked
import RBAbsorbProducts
noncomputable section
namespace RBBinary
open PowerSeries
local notation "𝔛" => (X : PowerSeries ℤ)

theorem identify (a : ℕ) (den num t v : PowerSeries ℤ) (ha : 1 ≤ a)
    (hc : constantCoeff den = 1) (ht : den*t=num)
    (hd : u a*v=den) (hn : (𝔛^a-𝔛^(a+1))*v=num) : native a=t*RBAbsorb.R := by
  have h := native_cleared a ha
  have he : den*native a = den*(t*RBAbsorb.R) := by
    rw [← mul_assoc,ht,←hd,←hn]
    linear_combination v*h
  have h' := congrArg (fun f => invOfUnit den (1:ℤˣ)*f) he
  simpa only [←mul_assoc, invOfUnit_mul den (1:ℤˣ) hc, one_mul] using h'

theorem series1 : native 1 = T1.rational*RBAbsorb.R := by
  apply identify 1 T1.denominator T1.numerator T1.rational 1 (by decide)
    T1.denominator_constant T1.denominator_rational
  · unfold u b lowDen d T1.denominator T1.D
    norm_num
    ring
  · unfold T1.numerator
    norm_num

theorem series2 : native 2 = T2.rational*RBAbsorb.R := by
  apply identify 2 T2.denominator T2.numerator T2.rational (1+𝔛) (by decide)
    T2.denominator_constant T2.denominator_rational
  · unfold u b lowDen d T2.denominator T2.D
    norm_num
    ring
  · unfold T2.numerator
    norm_num
    ring

theorem series3 : native 3 = T3.rational*RBAbsorb.R := by
  apply identify 3 T3.denominator T3.numerator T3.rational (1+𝔛+𝔛^2+𝔛^3) (by decide)
    T3.denominator_constant T3.denominator_rational
  · unfold u b lowDen d T3.denominator T3.D
    norm_num
    ring
  · unfold T3.numerator
    norm_num
    ring

theorem series4 : native 4 = T4.rational*RBAbsorb.R := by
  apply identify 4 T4.denominator T4.numerator T4.rational (1+𝔛+𝔛^2+𝔛^3) (by decide)
    T4.denominator_constant T4.denominator_rational
  · unfold u b lowDen d T4.denominator T4.D
    norm_num
    ring
  · unfold T4.numerator
    norm_num
    ring

theorem bridge1 (n : ℕ) :
    (RBCount.C 2 1 n : ℤ)-RBCount.C 2 2 n = coeff n (T1.rational*RBAbsorb.R) := by
  simpa only [native, coeff_mk] using congrArg (coeff n) series1

theorem bridge2 (n : ℕ) :
    (RBCount.C 2 2 n : ℤ)-RBCount.C 2 3 n = coeff n (T2.rational*RBAbsorb.R) := by
  simpa only [native, coeff_mk] using congrArg (coeff n) series2

theorem bridge3 (n : ℕ) :
    (RBCount.C 2 3 n : ℤ)-RBCount.C 2 4 n = coeff n (T3.rational*RBAbsorb.R) := by
  simpa only [native, coeff_mk] using congrArg (coeff n) series3

theorem bridge4 (n : ℕ) :
    (RBCount.C 2 4 n : ℤ)-RBCount.C 2 5 n = coeff n (T4.rational*RBAbsorb.R) := by
  simpa only [native, coeff_mk] using congrArg (coeff n) series4

#print axioms bridge1
#print axioms bridge2
#print axioms bridge3
#print axioms bridge4
end RBBinary
