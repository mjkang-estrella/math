import RBPrefixCore
import Lean.Elab.Tactic.Omega
namespace RBPrefix
open scoped BigOperators
def factors : Nat → Nat → List (Nat × Bool)
| 0, _ => []
| h+1, a => (h+1, h+1 == a) :: factors h a
def count (k a H n : Nat) : Int := coeffRun k (factors H a) n
def Comparison (k a n : Nat) : Prop := count k (a+1) 142 n < count k a 142 n
instance (k a n : Nat) : Decidable (Comparison k a n) := inferInstanceAs (Decidable (_ < _))
def positivePower (k x : Nat) : Bool := (List.range (x+1)).any (fun e => 0 < e && k^e == x)
def exceptional (k a : Nat) : Bool := positivePower k a || positivePower k (a+1)
def Required (k a n : Nat) : Prop :=
  2 ≤ k ∧ k ≤ 143 ∧ 2 ≤ a ∧ a ≤ 23 ∧ (k = 2 → 5 ≤ a) ∧
  ¬ (k = 3 ∧ exceptional k a = true) ∧ max (a+5) 17 ≤ n ∧
  n ≤ a + (if exceptional k a then 23 else 119)
instance (k a n : Nat) : Decidable (Required k a n) := by unfold Required; infer_instance
def checkBox (lo hi : Nat) : Bool :=
  (List.range (hi-lo)).all fun d =>
  (List.range 24).all fun a =>
  (List.range 143).all fun n =>
  if Required (lo+d) a n then decide (Comparison (lo+d) a n) else true

theorem box_sound {lo hi k a n : Nat} (h : checkBox lo hi = true)
 (hk : lo ≤ k ∧ k < hi) (ha : a < 24) (hn : n < 143)
 (r : Required k a n) : Comparison k a n := by
  simp only [checkBox, List.all_eq_true] at h
  have h1 := h (k-lo) (List.mem_range.mpr (by omega))
  have h2 := h1 a (List.mem_range.mpr ha)
  have h3 := h2 n (List.mem_range.mpr hn)
  have he : lo + (k-lo) = k := by omega
  simpa [he, r] using h3
theorem required_bounds {k a n : Nat} (h : Required k a n) : a < 24 ∧ n < 143 := by
  rcases h with ⟨_,_,_,ha,_,_,_,hn⟩
  split_ifs at hn <;> omega
theorem full_sound (h : checkBox 2 144 = true) :
 ∀ k a n, Required k a n → Comparison k a n := by
  intro k a n r
  have b := required_bounds r
  exact box_sound h ⟨r.1, by have := r.2.1; omega⟩ b.1 b.2 r
#print axioms box_sound
#print axioms full_sound
end RBPrefix
