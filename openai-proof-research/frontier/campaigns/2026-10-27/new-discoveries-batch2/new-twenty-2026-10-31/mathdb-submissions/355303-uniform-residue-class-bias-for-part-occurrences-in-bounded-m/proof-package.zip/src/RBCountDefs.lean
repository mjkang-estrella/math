import Mathlib.Combinatorics.Enumerative.Partition.Basic

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBCountDefs (355303 pilot A): literal native count semantics

`C k a n` and `D k r t n` are defined directly on Mathlib's
`Nat.Partition.countRestricted n k` (partitions of `n` in which every part size
occurs fewer than `k` times), counting OCCURRENCES with multiplicity.
For `r = t` the residue condition `x % t = t % t` is `x % t = 0`.

`NativeEndpoint` is the literal endpoint text proposed in producer/DESIGN.md §1.
Its fidelity to the native source is a ROOT GATE (OB1/OB2), not established here.

`AdjWeakGe3`, `AdjWeakBinary`, `AdjStrict` are NAMED adjacent comparison statements
to be supplied later.  They are NOT proved in this pilot and are NOT axioms; they
appear only as explicit hypotheses of the conditional assembly theorem.
-/

namespace RBCount

open Finset

/-- Total number of occurrences (with multiplicity) of the part size `a`, summed over
the partitions of `n` with every multiplicity `< k`. -/
def C (k a n : ℕ) : ℕ :=
  ∑ p ∈ Nat.Partition.countRestricted n k, p.parts.count a

/-- Total number of occurrences (with multiplicity) of parts `x ≡ r (mod t)`, summed over
the partitions of `n` with every multiplicity `< k`. -/
def D (k r t n : ℕ) : ℕ :=
  ∑ p ∈ Nat.Partition.countRestricted n k, (p.parts.filter (fun x => x % t = r % t)).card

/-- Literal native endpoint (proposal text of DESIGN §1; source binding is a root gate). -/
def NativeEndpoint : Prop :=
  (∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
      D k s t n ≤ D k r t n) ∧
  (∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
      D k s t n < D k r t n)

/-- Named adjacent comparison statement (weak, `k ≥ 3`). NOT proved in this pilot. -/
def AdjWeakGe3 : Prop :=
  ∀ k a n : ℕ, 3 ≤ k → 1 ≤ a → C k (a + 1) n ≤ C k a n

/-- Named adjacent comparison statement (weak, `k = 2`, `a ≥ 5`). NOT proved in this pilot. -/
def AdjWeakBinary : Prop :=
  ∀ a n : ℕ, 5 ≤ a → C 2 (a + 1) n ≤ C 2 a n

/-- Named adjacent comparison statement (strict tail). NOT proved in this pilot. -/
def AdjStrict : Prop :=
  ∀ k a n : ℕ, 2 ≤ k → 1 ≤ a → max (a + 4) 16 < n → C k (a + 1) n < C k a n

end RBCount
