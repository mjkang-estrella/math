import RBStageCore
namespace RBStageFn
open RBPrefix
open scoped BigOperators
def Sound (k N : Nat) (hs : List (Nat × Bool)) (r : Nat → Int) : Prop :=
 ∀ n, n ≤ N → r n = coeffRun k hs n
def rowCheck (k N h : Nat) (b : Bool) (r s : Nat → Int) : Bool :=
 (List.range (N+1)).all fun n => decide (s n = ∑ j ∈ Finset.range (cut k h n),
 if j*h ≤ n then weight b j * r (n-j*h) else 0)
theorem base (k N : Nat) : Sound k N [] (fun n => if n=0 then 1 else 0) := by
 intro n _; rfl
theorem transition (k N h a : Nat) (r s : Nat → Int)
 (prev : Sound k N (factors h a) r)
 (check : rowCheck k N (h+1) (h+1 == a) r s = true) :
 Sound k N (factors (h+1) a) s := by
 intro n hn
 simp only [rowCheck, List.all_eq_true] at check
 have eqn := check n (List.mem_range.mpr (by omega))
 simp only [decide_eq_true_eq] at eqn
 rw [eqn, sum_cut]
 simp only [factors, coeffRun]
 apply Finset.sum_congr rfl
 intro j _
 split_ifs with hj
 · rw [prev (n-j*(h+1)) (by omega)]
 · rfl
theorem actual (k a n : Nat) (r : Nat → Int)
 (hs : Sound k 142 (factors 142 a) r) (hn : n ≤ 142) :
 r n = (actualMarked k a).coeff n := by
 rw [hs n hn]
 exact count_meaning k a n
#print axioms transition
#print axioms actual
end RBStageFn
