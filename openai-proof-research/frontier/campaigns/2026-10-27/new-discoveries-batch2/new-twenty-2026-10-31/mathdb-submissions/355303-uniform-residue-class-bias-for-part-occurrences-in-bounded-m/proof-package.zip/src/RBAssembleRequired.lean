import RBPrefixEndpoint
import RBStrictReduce

/-!
# RBAssembleRequired (355303, formal-opus-r4-restart1): Boolean `Required` = strict finite-case conditions

For `k ≥ 2` the original Boolean `RBPrefix.exceptional k a` (built from `RBPrefix.positivePower`) is `true`
exactly when `RBStrict.StrictExc k a` (pure powers `k^e`, `e ≥ 1`, equal to `a` or `a+1`), via the paid
theorem `RBPrefix.positivePower_iff`.  Consequently the ORIGINAL `RBPrefix.Required k a n` is equivalent to the
exact hypothesis list of `RBStrict.FinitePrefixNative`, with all bounds inclusive.
-/

namespace RBAssemble

/-- Boolean exceptional flag = `StrictExc` (pure powers), for `k ≥ 2`. -/
theorem exceptional_iff {k a : ℕ} (hk : 2 ≤ k) :
    RBPrefix.exceptional k a = true ↔ RBStrict.StrictExc k a := by
  unfold RBPrefix.exceptional RBStrict.StrictExc
  rw [Bool.or_eq_true, RBPrefix.positivePower_iff k a hk, RBPrefix.positivePower_iff k (a + 1) hk]
  constructor
  · rintro (⟨e, he, hx⟩ | ⟨e, he, hx⟩)
    · exact ⟨e, by omega, Or.inl hx.symm⟩
    · exact ⟨e, by omega, Or.inr hx.symm⟩
  · rintro ⟨e, he, hx | hx⟩
    · exact Or.inl ⟨e, by omega, hx.symm⟩
    · exact Or.inr ⟨e, by omega, hx.symm⟩

/-- The original finite case predicate `Required` is EXACTLY the hypothesis list of
`RBStrict.FinitePrefixNative` (inclusive bounds on both sides). -/
theorem required_iff {k a n : ℕ} :
    RBPrefix.Required k a n ↔
      (2 ≤ k ∧ k ≤ 143 ∧ 2 ≤ a ∧ a ≤ 23 ∧ (k = 2 → 5 ≤ a) ∧ ¬ (k = 3 ∧ RBStrict.StrictExc k a) ∧
        max (a + 5) 17 ≤ n ∧ (RBStrict.StrictExc k a → n ≤ a + 23) ∧
        (¬ RBStrict.StrictExc k a → n ≤ a + 119)) := by
  constructor
  · rintro ⟨hk, hk', ha, ha', h2, h3, hn, hn'⟩
    have E := exceptional_iff (a := a) hk
    refine ⟨hk, hk', ha, ha', h2, fun h => h3 ⟨h.1, E.mpr h.2⟩, hn, fun h => ?_, fun h => ?_⟩
    · rw [ite_eq_left (E.mpr h)] at hn'
      exact hn'
    · rw [ite_eq_right (fun e => h (E.mp e))] at hn'
      exact hn'
  · rintro ⟨hk, hk', ha, ha', h2, h3, hn, hE, hN⟩
    have E := exceptional_iff (a := a) hk
    refine ⟨hk, hk', ha, ha', h2, fun h => h3 ⟨h.1, E.mp h.2⟩, hn, ?_⟩
    by_cases he : RBPrefix.exceptional k a = true
    · rw [ite_eq_left he]
      exact hE (E.mp he)
    · rw [ite_eq_right he]
      exact hN (fun s => he (E.mpr s))

end RBAssemble

#print axioms RBAssemble.exceptional_iff
#print axioms RBAssemble.required_iff
