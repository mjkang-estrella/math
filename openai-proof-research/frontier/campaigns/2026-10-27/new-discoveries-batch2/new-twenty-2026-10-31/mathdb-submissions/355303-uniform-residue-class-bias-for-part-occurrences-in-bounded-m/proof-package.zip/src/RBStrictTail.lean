import RBStrictCore

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBStrictTail (355303 strict support): region A (`a ≥ 24`, all `k ≥ 2`, `n ≥ a + 5`) and
region D tails (`2 ≤ a`, non-exceptional `n ≥ a + 120`; `a ≤ 23` exceptional, `k ≠ 3`, `n ≥ a + 24`).
-/

namespace RBStrict

open RBCount Finset

local notation "𝔛" => (PowerSeries.X : PowerSeries ℤ)

theorem strict_one_single {k a n y : ℕ} (hk : 2 ≤ k) (ha : 1 ≤ a)
    (hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1) (hy1 : 1 ≤ y) (hya : y < a) (hn : n = a + y)
    (hny : ∀ j, k ^ j ≠ y) : C k (a + 1) n < C k a n := by
  have hG := good_single (y := y) hy1 (by omega) (by omega) (by omega)
    (fun h => by
      rcases h with h | ⟨j, hj⟩
      · exact h
      · exact hny j (by rw [hj, one_mul])) (good_NE (n := n) hk hpow)
  exact strict_of_good (by omega) ha (by omega) hG (NN_mul (NN_pairF k a) (NN_Bf k y))
    (Sup_mul (NN_pairF k a) (NN_Bf k y) (Sup_pairF hk)
      (Sup_Bf (k := k) (i := 1) hy1 (by omega)) (by omega))

theorem strict_two_single {k a n y1 y2 : ℕ} (hk : 2 ≤ k) (ha : 1 ≤ a)
    (hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1) (h1 : 1 ≤ y1) (h2 : 1 ≤ y2) (hne : y1 ≠ y2)
    (h1a : y1 < a) (h2a : y2 < a) (hn : n = a + y1 + y2) (hn1 : ∀ j, k ^ j ≠ y1)
    (hn2 : ∀ j, k ^ j ≠ y2) : C k (a + 1) n < C k a n := by
  have hG1 := good_single (y := y1) h1 (by omega) (by omega) (by omega)
    (fun h => by
      rcases h with h | ⟨j, hj⟩
      · exact h
      · exact hn1 j (by rw [hj, one_mul])) (good_NE (n := n) hk hpow)
  have hG2 := good_single (y := y2) h2 (by omega) (by omega) (by omega)
    (fun h => by
      rcases h with (h | ⟨j, hj⟩) | h
      · exact h
      · exact hn2 j (by rw [hj, one_mul])
      · exact hne h.symm) hG1
  exact strict_of_good (by omega) ha (by omega) hG2
    (NN_mul (NN_mul (NN_pairF k a) (NN_Bf k y1)) (NN_Bf k y2))
    (Sup_mul (NN_mul (NN_pairF k a) (NN_Bf k y1)) (NN_Bf k y2)
      (Sup_mul (NN_pairF k a) (NN_Bf k y1) (Sup_pairF hk) (Sup_Bf (k := k) (i := 1) h1 (by omega)) rfl)
      (Sup_Bf (k := k) (i := 1) h2 (by omega)) (by omega))

/-- Region A, non-exceptional, `5 ≤ n - a ≤ 23`: one or two unmarked single factors. -/
theorem strictA_small {k a n : ℕ} (hk : 2 ≤ k) (ha : 24 ≤ a)
    (hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1) (hn1 : a + 5 ≤ n) (hn2 : n ≤ a + 23) :
    C k (a + 1) n < C k a n := by
  obtain ⟨m, rfl⟩ : ∃ m, n = a + m := ⟨n - a, by omega⟩
  by_cases hp : ∀ j, k ^ j ≠ m
  · exact strict_one_single hk (by omega) hpow (by omega) (by omega) rfl hp
  · obtain ⟨v, hv⟩ := not_forall.mp hp
    have hv' : k ^ v = m := Classical.not_not.mp hv
    have hv1 : 1 ≤ v := by
      rcases Nat.eq_zero_or_pos v with h | h
      · rw [h, pow_zero] at hv'
        omega
      · exact h
    have hkm : k ∣ m := by
      rw [← hv']
      exact dvd_pow_self k (by omega)
    by_cases hk3 : 3 ≤ k
    · have hk2 : ¬ k ∣ 2 := fun h => by
        have := Nat.le_of_dvd (by norm_num) h
        omega
      have hkm2 : ¬ k ∣ m - 2 := fun h => hk2 ((Nat.dvd_add_right h).mp
        (by rwa [Nat.sub_add_cancel (by omega : 2 ≤ m)]))
      exact strict_two_single hk (by omega) hpow (by norm_num : 1 ≤ 2) (by omega : 1 ≤ m - 2)
        (by omega) (by omega) (by omega) (by omega) (notPow (le_refl 2) hk2) (notPow (by omega) hkm2)
    · have hk2 : k = 2 := by omega
      subst hk2
      have hv4 : v ≤ 4 := by
        by_contra h
        have := Nat.pow_le_pow_right (by norm_num : 2 > 0) (by omega : 5 ≤ v)
        norm_num at this
        omega
      have hv3 : 3 ≤ v := by
        by_contra h
        have := Nat.pow_le_pow_right (by norm_num : 2 > 0) (by omega : v ≤ 2)
        norm_num at this
        omega
      rcases (show v = 3 ∨ v = 4 by omega) with rfl | rfl
      · norm_num at hv'
        subst hv'
        exact strict_two_single (by norm_num) (by omega) hpow (by norm_num : 1 ≤ 3)
          (by norm_num : 1 ≤ 5) (by norm_num) (by omega) (by omega) (by omega)
          (notPow (by norm_num) (by decide)) (notPow (by norm_num) (by decide))
      · norm_num at hv'
        subst hv'
        exact strict_two_single (by norm_num) (by omega) hpow (by norm_num : 1 ≤ 3)
          (by norm_num : 1 ≤ 13) (by norm_num) (by omega) (by omega) (by omega)
          (notPow (by norm_num) (by decide)) (notPow (by norm_num) (by decide))

theorem mem5_le {x : ℕ} (hx : x ∈ ({1, 2, 3, 5, 7} : Finset ℕ)) : x ≤ 7 := by
  simp only [Finset.mem_insert, Finset.mem_singleton] at hx
  omega

theorem hit_dvd {k c j x : ℕ} (hc : c ≤ 7) (hx : 8 ≤ x) (h : c * k ^ j = x) : k ∣ x := by
  cases j with
  | zero =>
    rw [pow_zero, mul_one] at h
    omega
  | succ j => exact ⟨c * k ^ j, by rw [← h, pow_succ]; ring⟩

theorem hit_unique {k a x y i j : ℕ} (hk : 2 ≤ k) (ha : 8 ≤ a) (hx7 : x ≤ 7) (hy7 : y ≤ 7)
    (hxk : ¬ k ∣ x) (hyk : ¬ k ∣ y) (hi : x * k ^ i = a ∨ x * k ^ i = a + 1)
    (hj : y * k ^ j = a ∨ y * k ^ j = a + 1) : x = y := by
  have hk1 := not_dvd_one hk
  rcases hi with hi | hi <;> rcases hj with hj | hj
  · exact (root_unique hk hxk hyk (hi.trans hj.symm)).1
  · exact absurd ((Nat.dvd_add_right (hit_dvd hx7 (by omega) hi)).mp (hit_dvd hy7 (by omega) hj)) hk1
  · exact absurd ((Nat.dvd_add_right (hit_dvd hy7 (by omega) hj)).mp (hit_dvd hx7 (by omega) hi)) hk1
  · exact (root_unique hk hxk hyk (hi.trans hj.symm)).1

/-- Region A, non-exceptional, `n - a ≥ 24`: two intact chains among roots `2, 3, 5, 7`. -/
theorem strictA_big {k a n : ℕ} (hk : 2 ≤ k) (ha : 24 ≤ a)
    (hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1) (hn : a + 24 ≤ n) : C k (a + 1) n < C k a n := by
  have hk1 := not_dvd_one hk
  obtain ⟨p, hp, q, hq, hpq, ⟨hp1, hp2, hp3⟩, ⟨hq1, hq2, hq3⟩⟩ :=
    two_good ({1, 2, 3, 5, 7} : Finset ℕ) (by decide) (fun c => k ∣ c)
      (fun c => ¬ k ∣ c ∧ ∃ j, c * k ^ j = a ∨ c * k ^ j = a + 1) (fun c => c = 1)
      (dvd_at_most_one hk (by decide))
      (fun x hx y hy hx' hy' => by
        obtain ⟨hx1, i, hi⟩ := hx'
        obtain ⟨hy1, j, hj⟩ := hy'
        exact hit_unique hk (by omega) (mem5_le hx) (mem5_le hy) hx1 hy1 hi hj)
      (fun x _ y _ hx hy => hx.trans hy.symm)
  have hkp : ¬ k ∣ p := hp1
  have hkq : ¬ k ∣ q := hq1
  have hp1' : p ≠ 1 := hp3
  have hq1' : q ≠ 1 := hq3
  have havp : ∀ j, p * k ^ j ≠ a ∧ p * k ^ j ≠ a + 1 := fun j =>
    ⟨fun h => hp2 ⟨hkp, j, Or.inl h⟩, fun h => hp2 ⟨hkp, j, Or.inr h⟩⟩
  have havq : ∀ j, q * k ^ j ≠ a ∧ q * k ^ j ≠ a + 1 := fun j =>
    ⟨fun h => hq2 ⟨hkq, j, Or.inl h⟩, fun h => hq2 ⟨hkq, j, Or.inr h⟩⟩
  have Gp := good_chain (c := p) hk (pos_of_not_dvd hkp) havp (fun j h => by
      rcases h with h | h
      · exact h
      · exact not_root hk hkp hk1 hp1' h) (good_NE (n := n) hk hpow)
  have Gq := good_chain (c := q) hk (pos_of_not_dvd hkq) havq (fun j h => by
      rcases h with (h | h) | h
      · exact h
      · exact not_root hk hkq hk1 hq1' h
      · exact not_root hk hkq hkp (Ne.symm hpq) h) Gp
  have hp' : p = 2 ∨ p = 3 ∨ p = 5 ∨ p = 7 := by
    simp only [Finset.mem_insert, Finset.mem_singleton] at hp
    omega
  have hq' : q = 2 ∨ q = 3 ∨ q = 5 ∨ q = 7 := by
    simp only [Finset.mem_insert, Finset.mem_singleton] at hq
    omega
  have hpl : p ∈ [2, 3, 5, 7] := by rcases hp' with h | h | h | h <;> subst h <;> decide
  have hql : q ∈ [2, 3, 5, 7] := by rcases hq' with h | h | h | h <;> subst h <;> decide
  obtain ⟨i, hi, j, l, hm⟩ := rep2_of_pairsOK (by decide : pairsOK [2, 3, 5, 7] 24 = true)
    hpl hql hpq (pos_of_not_dvd hkq) (n - a) (by omega)
  exact strict_of_good (by omega) (by omega) (by omega) Gq
    (NN_mul (NN_mul (NN_pairF k a) (NN_gI p)) (NN_gI q))
    (Sup_mul (NN_mul (NN_pairF k a) (NN_gI p)) (NN_gI q)
      (Sup_mul (NN_pairF k a) (NN_gI p) (Sup_pairF hk) (Sup_gI p i) rfl) (Sup_gI q (j + l))
      (by rw [Nat.mul_add]; omega))

/-- Region A, exceptional (`k^w ∈ {a, a+1}`), `n ≥ a + 5`. -/
theorem strictA_exc {k a n w : ℕ} (hk : 2 ≤ k) (ha : 24 ≤ a) (hw : 1 ≤ w)
    (hx : k ^ w = a ∨ k ^ w = a + 1) (hn : a + 5 ≤ n) : C k (a + 1) n < C k a n := by
  have hlow := hlow_of hk hw hx (by omega)
  have hx24 : 24 ≤ k ^ w := by omega
  rcases (show k = 2 ∨ k = 3 ∨ 4 ≤ k by omega) with rfl | rfl | hk4
  · have hw5 : 5 ≤ w := by
      by_contra h
      have := Nat.pow_le_pow_right (by norm_num : 2 > 0) (by omega : w ≤ 4)
      norm_num at this
      omega
    have hx32 : 32 ≤ 2 ^ w := by
      have := Nat.pow_le_pow_right (by norm_num : 2 > 0) hw5
      norm_num at this
      exact this
    obtain ⟨i, hi, j, l, hm⟩ :=
      rep3_of_win (by norm_num) (by decide : win3 5 3 3 7 2 5 = true) (n - a) (by omega)
    exact strict_exc3 (p := 5) (q := 3) (c := 7) (u := (2 ^ w - 3 * ((2 * 2 ^ w) % 5)) / 5)
      (v := (2 * 2 ^ w) % 5) (by norm_num) (by omega) (by omega) hw hx hlow (by norm_num)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by decide) (by decide)
      (by decide) (fun _ => ⟨by omega, by omega, by omega⟩) (fun _ => ⟨by omega, by omega, by omega⟩)
      (by omega) ⟨i, by omega, j, l, by omega⟩
  · have hodd : 3 ^ w % 2 = 1 := by
      rw [Nat.pow_mod]
      norm_num
    obtain ⟨i, hi, j, l, hm⟩ :=
      rep3_of_win (by norm_num) (by decide : win3 5 3 2 2 1 5 = true) (n - a) (by omega)
    exact strict_exc2 (p := 5) (q := 2) (u := 3) (v := (3 ^ w - 15) / 2) (by norm_num) (by omega)
      (by omega) hw hx hlow (by norm_num) (by norm_num) (by norm_num) (by decide) (by decide)
      (fun _ => ⟨by omega, by omega⟩) (fun _ => ⟨by omega, by omega⟩) (by omega)
      ⟨i, hi, j + l, by rw [Nat.mul_add]; omega⟩
  · have hk2 : ¬ k ∣ 2 := fun h => by
      have := Nat.le_of_dvd (by norm_num) h
      omega
    have hk3 : ¬ k ∣ 3 := fun h => by
      have := Nat.le_of_dvd (by norm_num) h
      omega
    obtain ⟨i, hi, j, l, hm⟩ :=
      rep3_of_win (by norm_num) (by decide : win3 2 3 3 3 1 5 = true) (n - a) (by omega)
    by_cases hpar : k ^ w % 2 = 0
    · exact strict_exc2 (p := 2) (q := 3) (u := k ^ w / 2) (v := 0) hk (by omega) (by omega) hw hx
        hlow (by norm_num) (by norm_num) (by norm_num) hk2 hk3 (fun _ => ⟨by omega, by omega⟩)
        (fun _ => ⟨by omega, by omega⟩) (by omega) ⟨i, by omega, j + l, by rw [Nat.mul_add]; omega⟩
    · exact strict_exc2 (p := 2) (q := 3) (u := (k ^ w - 3) / 2) (v := 1) hk (by omega) (by omega)
        hw hx hlow (by norm_num) (by norm_num) (by norm_num) hk2 hk3 (fun _ => ⟨by omega, by omega⟩)
        (fun _ => ⟨by omega, by omega⟩) (by omega) ⟨i, by omega, j + l, by rw [Nat.mul_add]; omega⟩

/-- REGION A (closed): every `k ≥ 2`, `a ≥ 24`, `n ≥ a + 5`. -/
theorem strict_a24 {k a n : ℕ} (hk : 2 ≤ k) (ha : 24 ≤ a) (hn : a + 5 ≤ n) :
    C k (a + 1) n < C k a n := by
  by_cases hE : ∃ w, 1 ≤ w ∧ (k ^ w = a ∨ k ^ w = a + 1)
  · obtain ⟨w, hw, hx⟩ := hE
    exact strictA_exc hk ha hw hx hn
  · have hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1 := fun w => by
      rcases Nat.eq_zero_or_pos w with h | h
      · rw [h, pow_zero]
        omega
      · exact ⟨fun e => hE ⟨w, h, Or.inl e⟩, fun e => hE ⟨w, h, Or.inr e⟩⟩
    by_cases hm : n ≤ a + 23
    · exact strictA_small hk ha hpow hn hm
    · exact strictA_big hk ha hpow (by omega)

theorem mem13 {x : ℕ} (hx : x ∈ ({3, 5, 7, 11, 13} : Finset ℕ)) :
    x = 3 ∨ x = 5 ∨ x = 7 ∨ x = 11 ∨ x = 13 := by
  simpa only [Finset.mem_insert, Finset.mem_singleton] using hx

/-- REGION D (non-exceptional tail, conductor 120): any `k ≥ 2`, `a ≥ 2`, `n ≥ a + 120`. -/
theorem strict_small_NE {k a n : ℕ} (hk : 2 ≤ k) (ha : 2 ≤ a)
    (hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1) (hn : a + 120 ≤ n) : C k (a + 1) n < C k a n := by
  have hk1 := not_dvd_one hk
  obtain ⟨p, hp, q, hq, hpq, ⟨hp1, hp2, hp3⟩, ⟨hq1, hq2, hq3⟩⟩ :=
    two_good ({3, 5, 7, 11, 13} : Finset ℕ) (by decide) (fun c => k ∣ c)
      (fun c => ¬ k ∣ c ∧ ∃ j, c * k ^ j = a) (fun c => ¬ k ∣ c ∧ ∃ j, c * k ^ j = a + 1)
      (dvd_at_most_one hk (by decide))
      (fun x _ y _ hx hy => by
        obtain ⟨hx1, i, hi⟩ := hx
        obtain ⟨hy1, j, hj⟩ := hy
        exact (root_unique hk hx1 hy1 (hi.trans hj.symm)).1)
      (fun x _ y _ hx hy => by
        obtain ⟨hx1, i, hi⟩ := hx
        obtain ⟨hy1, j, hj⟩ := hy
        exact (root_unique hk hx1 hy1 (hi.trans hj.symm)).1)
  have hkp : ¬ k ∣ p := hp1
  have hkq : ¬ k ∣ q := hq1
  have hp' := mem13 hp
  have hq' := mem13 hq
  have hp1' : p ≠ 1 := by omega
  have hq1' : q ≠ 1 := by omega
  have havp : ∀ j, p * k ^ j ≠ a ∧ p * k ^ j ≠ a + 1 := fun j =>
    ⟨fun h => hp2 ⟨hkp, j, h⟩, fun h => hp3 ⟨hkp, j, h⟩⟩
  have havq : ∀ j, q * k ^ j ≠ a ∧ q * k ^ j ≠ a + 1 := fun j =>
    ⟨fun h => hq2 ⟨hkq, j, h⟩, fun h => hq3 ⟨hkq, j, h⟩⟩
  have Gp := good_chain (c := p) hk (pos_of_not_dvd hkp) havp (fun j h => by
      rcases h with h | h
      · exact h
      · exact not_root hk hkp hk1 hp1' h) (good_NE (n := n) hk hpow)
  have Gq := good_chain (c := q) hk (pos_of_not_dvd hkq) havq (fun j h => by
      rcases h with (h | h) | h
      · exact h
      · exact not_root hk hkq hk1 hq1' h
      · exact not_root hk hkq hkp (Ne.symm hpq) h) Gp
  have hpl : p ∈ [3, 5, 7, 11, 13] := by rcases hp' with h | h | h | h | h <;> subst h <;> decide
  have hql : q ∈ [3, 5, 7, 11, 13] := by rcases hq' with h | h | h | h | h <;> subst h <;> decide
  obtain ⟨i, hi, j, l, hm⟩ := rep2_of_pairsOK (by decide : pairsOK [3, 5, 7, 11, 13] 120 = true)
    hpl hql hpq (pos_of_not_dvd hkq) (n - a) (by omega)
  exact strict_of_good (by omega) (by omega) (by omega) Gq
    (NN_mul (NN_mul (NN_pairF k a) (NN_gI p)) (NN_gI q))
    (Sup_mul (NN_mul (NN_pairF k a) (NN_gI p)) (NN_gI q)
      (Sup_mul (NN_pairF k a) (NN_gI p) (Sup_pairF hk) (Sup_gI p i) rfl) (Sup_gI q (j + l))
      (by rw [Nat.mul_add]; omega))

/-- REGION D (exceptional tail, conductor 24): `k ≠ 3`, `2 ≤ a ≤ 23` (`k = 2 → a ≥ 5`),
`k^w ∈ {a, a+1}`, `n ≥ a + 24`. -/
theorem strict_small_exc {k a n w : ℕ} (hk : 2 ≤ k) (hk3 : k ≠ 3) (ha : 2 ≤ a) (ha23 : a ≤ 23)
    (hk2 : k = 2 → 5 ≤ a) (hw : 1 ≤ w) (hx : k ^ w = a ∨ k ^ w = a + 1) (hn : a + 24 ≤ n) :
    C k (a + 1) n < C k a n := by
  have hlow := hlow_of hk hw hx ha
  have hkw : k ≤ k ^ w := by
    have := Nat.pow_le_pow_right (by omega : k > 0) hw
    rwa [pow_one] at this
  rcases (show k = 2 ∨ 4 ≤ k by omega) with rfl | hk4
  · have h5 := hk2 rfl
    have hw3 : 3 ≤ w := by
      by_contra h
      have := Nat.pow_le_pow_right (by norm_num : 2 > 0) (by omega : w ≤ 2)
      norm_num at this
      omega
    have hw4 : w ≤ 4 := by
      by_contra h
      have := Nat.pow_le_pow_right (by norm_num : 2 > 0) (by omega : 5 ≤ w)
      norm_num at this
      omega
    obtain ⟨i, hi, j, l, hm⟩ :=
      rep3_of_win (by norm_num) (by decide : win3 5 1 3 11 3 24 = true) (n - a) (by omega)
    rcases (show w = 3 ∨ w = 4 by omega) with rfl | rfl
    · exact strict_exc3 (p := 5) (q := 3) (c := 11) (u := 1) (v := 1) (by norm_num) (by omega)
        (by omega) (by norm_num) hx hlow (by norm_num) (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num) (by decide) (by decide) (by decide)
        (fun h => by norm_num at h; omega) (fun h => by norm_num at h; omega) (by norm_num)
        ⟨i, hi, j, l, by omega⟩
    · exact strict_exc3 (p := 5) (q := 3) (c := 11) (u := 2) (v := 2) (by norm_num) (by omega)
        (by omega) (by norm_num) hx hlow (by norm_num) (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num) (by decide) (by decide) (by decide)
        (fun h => by norm_num at h; omega) (fun h => by norm_num at h; omega) (by norm_num)
        ⟨i, by omega, j, l, by omega⟩
  · by_cases h43 : k = 4 ∧ a = 3
    · obtain ⟨rfl, rfl⟩ := h43
      have hw1 : w = 1 := by
        by_contra h
        have := Nat.pow_le_pow_right (by norm_num : 4 > 0) (by omega : 2 ≤ w)
        norm_num at this
        omega
      subst hw1
      obtain ⟨i, hi, j, l, hm⟩ :=
        rep3_of_win (by norm_num) (by decide : win3 2 1 5 7 5 24 = true) (n - 3) (by omega)
      exact strict_exc3 (p := 2) (q := 5) (c := 7) (u := 2) (v := 0) (by norm_num) (by norm_num)
        (by omega) le_rfl hx hlow (by norm_num) (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num) (by decide) (by decide) (by decide)
        (fun _ => ⟨by norm_num, by norm_num, by norm_num⟩) (fun h => by norm_num at h)
        (by norm_num) ⟨i, by omega, j, l, by omega⟩
    · have hkx4 : 4 ≤ k ^ w := le_trans hk4 hkw
      obtain ⟨c, hc, c', hc', hcc', ⟨hc1, hc2, hc3⟩, _⟩ :=
        two_good ({1, 5, 7, 11, 13} : Finset ℕ) (by decide) (fun c => k ∣ c)
          (fun c => (k ^ w = a + 1 ∧ c = a) ∨ (k ^ w = a ∧ c = a + 1)) (fun c => c = 1)
          (dvd_at_most_one hk (by decide))
          (fun x _ y _ hx' hy' => by
            rcases hx' with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> rcases hy' with ⟨h3, h4⟩ | ⟨h3, h4⟩ <;> omega)
          (fun x _ y _ hx' hy' => hx'.trans hy'.symm)
      have hkc : ¬ k ∣ c := hc1
      have hcn : ¬ ((k ^ w = a + 1 ∧ c = a) ∨ (k ^ w = a ∧ c = a + 1)) := hc2
      have hcne1 : c ≠ 1 := hc3
      have hcmem : c = 5 ∨ c = 7 ∨ c = 11 ∨ c = 13 := by
        simp only [Finset.mem_insert, Finset.mem_singleton] at hc
        omega
      have hcl : c ∈ [5, 7, 11, 13] := by
        rcases hcmem with h | h | h | h <;> subst h <;> decide
      have hall : ([5, 7, 11, 13] : List ℕ).all (fun c => win3 2 1 3 c 3 24) = true := by decide
      have hwin : win3 2 1 3 c 3 24 = true := List.all_eq_true.mp hall c hcl
      obtain ⟨i, hi, j, l, hm⟩ := rep3_of_win (by norm_num) hwin (n - a) (by omega)
      have hk2' : ¬ k ∣ 2 := fun h => by
        have := Nat.le_of_dvd (by norm_num) h
        omega
      have hk3' : ¬ k ∣ 3 := fun h => by
        have := Nat.le_of_dvd (by norm_num) h
        omega
      by_cases hpar : k ^ w % 2 = 0
      · exact strict_exc3 (p := 2) (q := 3) (c := c) (u := k ^ w / 2) (v := 0) hk (by omega)
          (by omega) hw hx hlow (by norm_num) (by norm_num) hcne1 (by norm_num) (by omega)
          (by omega) hk2' hk3' hkc (fun _ => ⟨by omega, by omega, by omega⟩)
          (fun _ => ⟨by omega, by omega, by omega⟩) (by omega) ⟨i, by omega, j, l, by omega⟩
      · exact strict_exc3 (p := 2) (q := 3) (c := c) (u := (k ^ w - 3) / 2) (v := 1) hk (by omega)
          (by omega) hw hx hlow (by norm_num) (by norm_num) hcne1 (by norm_num) (by omega)
          (by omega) hk2' hk3' hkc (fun _ => ⟨by omega, by omega, by omega⟩)
          (fun _ => ⟨by omega, by omega, by omega⟩) (by omega) ⟨i, by omega, j, l, by omega⟩

end RBStrict

#print axioms RBStrict.strict_a24
#print axioms RBStrict.strict_small_NE
#print axioms RBStrict.strict_small_exc
