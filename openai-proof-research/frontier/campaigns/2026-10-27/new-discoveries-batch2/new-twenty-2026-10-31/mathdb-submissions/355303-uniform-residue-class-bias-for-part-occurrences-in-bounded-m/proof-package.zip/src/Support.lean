import Semantics
import Lean.Elab.Tactic.Omega

noncomputable section
namespace T1
open PowerSeries
open scoped BigOperators

def Bound (s : PowerSeries ℤ) (b : ℕ) : Prop := ∀ n, b≤n → coeff n s=0

theorem bound_mul {s t : PowerSeries ℤ} {b c : ℕ}
    (hs : Bound s b) (ht : Bound t c) : Bound (s*t) (b+c) := by
  intro n hn
  rw [coeff_mul]
  apply Finset.sum_eq_zero
  intro p hp
  have hpn := Finset.mem_antidiagonal.mp hp
  by_cases h : b≤p.1
  · rw [hs p.1 h,zero_mul]
  · rw [ht p.2 (by omega),mul_zero]

theorem bound_sub {s t : PowerSeries ℤ} {b : ℕ}
    (hs : Bound s b) (ht : Bound t b) : Bound (s-t) b := by
  intro n hn
  simp only [map_sub,hs n hn,ht n hn,sub_self]

theorem bound_pow (d b : ℕ) (hd : d<b) : Bound ((X : PowerSeries ℤ)^d) b := by
  intro n hn
  rw [coeff_X_pow,ite_eq_right (by omega)]

theorem bound_geom (d m b : ℕ) (h : ∀ i<m, d*i<b) :
    Bound (geom ((X : PowerSeries ℤ)^d) m) b := by
  intro n hn
  simp only [geom,map_sum]
  apply Finset.sum_eq_zero
  intro i hi
  rw [← pow_mul,coeff_X_pow,ite_eq_right (by have := h i (Finset.mem_range.mp hi); omega)]

theorem bound_Z : Bound (Z (X : PowerSeries ℤ)) 1669 := by
  unfold Z G
  apply bound_mul (b := 1255) (c := 414)
  · apply bound_mul (b := 839) (c := 416)
    · apply bound_mul (b := 422) (c := 417)
      · apply bound_mul (b := 4) (c := 418)
        · apply bound_mul (b := 2) (c := 2)
          · simpa using bound_pow 1 2 (by decide)
          · exact bound_sub (by simpa using bound_pow 0 2 (by decide))
              (by simpa using bound_pow 1 2 (by decide))
        · exact bound_geom 3 140 418 (by intro i hi; omega)
      · exact bound_geom 4 105 417 (by intro i hi; omega)
    · exact bound_geom 5 84 416 (by intro i hi; omega)
  · exact bound_geom 7 60 414 (by intro i hi; omega)

#print axioms Bound
#print axioms bound_mul
#print axioms bound_sub
#print axioms bound_pow
#print axioms bound_geom
#print axioms bound_Z
end T1
