import T3Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T3
theorem rec5_0 : ∀ n : Fin 15, tab (n.val+2100)=step tab (n.val+2100) := by decide
theorem rec5_1 : ∀ n : Fin 15, tab (n.val+2115)=step tab (n.val+2115) := by decide
theorem rec5_2 : ∀ n : Fin 15, tab (n.val+2130)=step tab (n.val+2130) := by decide
theorem rec5_3 : ∀ n : Fin 15, tab (n.val+2145)=step tab (n.val+2145) := by decide
theorem rec5_4 : ∀ n : Fin 15, tab (n.val+2160)=step tab (n.val+2160) := by decide
theorem rec5_5 : ∀ n : Fin 15, tab (n.val+2175)=step tab (n.val+2175) := by decide
theorem rec5_6 : ∀ n : Fin 15, tab (n.val+2190)=step tab (n.val+2190) := by decide
theorem rec5_7 : ∀ n : Fin 15, tab (n.val+2205)=step tab (n.val+2205) := by decide
theorem rec5_8 : ∀ n : Fin 15, tab (n.val+2220)=step tab (n.val+2220) := by decide
theorem rec5_9 : ∀ n : Fin 15, tab (n.val+2235)=step tab (n.val+2235) := by decide
theorem rec5_10 : ∀ n : Fin 15, tab (n.val+2250)=step tab (n.val+2250) := by decide
theorem rec5_11 : ∀ n : Fin 15, tab (n.val+2265)=step tab (n.val+2265) := by decide
theorem rec5_12 : ∀ n : Fin 15, tab (n.val+2280)=step tab (n.val+2280) := by decide
theorem rec5_13 : ∀ n : Fin 15, tab (n.val+2295)=step tab (n.val+2295) := by decide
theorem rec5_14 : ∀ n : Fin 15, tab (n.val+2310)=step tab (n.val+2310) := by decide
theorem rec5_15 : ∀ n : Fin 15, tab (n.val+2325)=step tab (n.val+2325) := by decide
theorem rec5_16 : ∀ n : Fin 15, tab (n.val+2340)=step tab (n.val+2340) := by decide
theorem rec5_17 : ∀ n : Fin 15, tab (n.val+2355)=step tab (n.val+2355) := by decide
theorem rec5_18 : ∀ n : Fin 15, tab (n.val+2370)=step tab (n.val+2370) := by decide
theorem rec5_19 : ∀ n : Fin 15, tab (n.val+2385)=step tab (n.val+2385) := by decide
theorem rec5_20 : ∀ n : Fin 15, tab (n.val+2400)=step tab (n.val+2400) := by decide
theorem rec5_21 : ∀ n : Fin 15, tab (n.val+2415)=step tab (n.val+2415) := by decide
theorem rec5_22 : ∀ n : Fin 15, tab (n.val+2430)=step tab (n.val+2430) := by decide
theorem rec5_23 : ∀ n : Fin 15, tab (n.val+2445)=step tab (n.val+2445) := by decide
theorem rec5_24 : ∀ n : Fin 15, tab (n.val+2460)=step tab (n.val+2460) := by decide
theorem rec5_25 : ∀ n : Fin 15, tab (n.val+2475)=step tab (n.val+2475) := by decide
theorem rec5_26 : ∀ n : Fin 15, tab (n.val+2490)=step tab (n.val+2490) := by decide
theorem rec5_27 : ∀ n : Fin 15, tab (n.val+2505)=step tab (n.val+2505) := by decide
theorem rec5 : ∀ n : Fin 420, tab (n.val+2100)=step tab (n.val+2100) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec5_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+2100=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec5_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+2115=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec5_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+2130=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec5_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+2145=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec5_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+2160=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec5_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+2175=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec5_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+2190=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec5_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+2205=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec5_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+2220=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec5_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+2235=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec5_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+2250=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec5_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+2265=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec5_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+2280=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec5_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+2295=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec5_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+2310=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec5_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+2325=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec5_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+2340=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec5_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+2355=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec5_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+2370=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec5_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+2385=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec5_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+2400=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec5_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+2415=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec5_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+2430=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec5_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+2445=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec5_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+2460=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec5_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+2475=n.val+2100 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec5_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+2490=n.val+2100 := by omega
    simpa only [he] using h
  have h := rec5_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+2505=n.val+2100 := by omega
  simpa only [he] using h
theorem rows5 : ∀ r : Fin 60,
  0 ≤ tab (r.val+300+2520) ∧
  0 ≤ tab (r.val+300+3360)-tab (r.val+300+2520) ∧
  0 ≤ tab (r.val+300+4200)-2*tab (r.val+300+3360)+tab (r.val+300+2520) ∧
  0 ≤ tab (r.val+300+5040)-3*tab (r.val+300+4200)+3*tab (r.val+300+3360)-tab (r.val+300+2520) := by decide
theorem pref5 : ∀ n : Fin 420, n.val+2100≠7 → n.val+2100≠12 → 0≤tab (n.val+2100) := by decide

#print axioms rec5
#print axioms rows5
#print axioms pref5
end T3
