#!/usr/bin/env python3
"""Verify/extract the portable source packet; standard library, no Lean/network."""
import argparse,hashlib,json,pathlib,zipfile
p=argparse.ArgumentParser();p.add_argument('archive');p.add_argument('--extract',type=pathlib.Path);a=p.parse_args()
with zipfile.ZipFile(a.archive) as z:
 names=z.namelist();assert len(names)==len(set(names)), 'duplicate ZIP member'
 for n in names:
  q=pathlib.PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts
  assert (z.getinfo(n).external_attr>>16)&0o170000 != 0o120000, 'symlink member'
 m=json.loads(z.read('manifest.json'));assert set(names)==set(m['files'])|{'manifest.json'}
 for n,h in m['files'].items():
  b=z.read(n);assert len(b)==h['bytes'] and hashlib.sha256(b).hexdigest()==h['sha256'],n
 idx=json.loads(z.read('source-index.json'));assert len(idx)==332
 for r in idx:
  b=z.read(r['path']);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
 if a.extract:
  dest=a.extract.resolve();dest.mkdir(parents=True,exist_ok=True)
  for n in names:
   target=(dest/n).resolve();assert target.is_relative_to(dest)
   assert not target.is_symlink();target.parent.mkdir(parents=True,exist_ok=True)
   target.write_bytes(z.read(n))
 print(json.dumps({'status':'PASS','canonical_sources':332,'members':len(names),'extracted':str(a.extract) if a.extract else None,'compiler_calls':0,'network':0}))
