# MathDB 355303 - independent manuscript / statement / package review

Lane: `regular-bias-manuscript-independent-review-opus-20261116-r1`. Claude Opus 5.5, high effort, independent reviewer. I had no part in authoring. 2026-11-16, CPU 0,1.
Formal 0, science 0, HTTP 0, search 0, subagents 0, credit 0. Root alone adjudicates.

## Reviewed objects (all owned, untrusted copies; frozen-before 1118/1118 PASS)

| Object | SHA256 (prefix) | Bytes |
|---|---|---|
| `MANUSCRIPT-manuscript.md` = `MANUSCRIPT-final-paper.md` (byte-identical) | 25d626c3c652d52d | 41,035 |
| `MANUSCRIPT-proof-package.zip` | fd4b3da141e959b7 | 6,832,035 |
| `MANUSCRIPT-crosswalk.json` (34 steps) | equals ZIP member | 417,725 |
| Native JO22 v1 PDF `sources/current-native-v1.pdf` | ac58acf3e8b77762 | 326,671 |
| Retained MathDB 355303 raw projection (granted copy `grant-copy/`) | 04a58a2d43009ac9 | 1,916 |
| Independent replay report | fbfa76d06baf312b (= replay seal `report_sha256`) | 17,827 |
| Prior bounded qualification | 0f03e9ae109ae74a | 24,544 |

## Verdicts

| Gate | Verdict | Anchors |
|---|---|---|
| MG1: five strict-support regions | **PASS** | s3, s5a-s5e, s7 |
| MG2: k=2, a=1..4 binary pairs | **PASS**, with a disclosed computer-assisted certificate limit | s6.1-s6.3 |
| MG3: a=1 exception | **PASS** | s4, s5b, s6 |
| MG4: replay and trust history | **PASS** (documentary) | s10, s11 |
| MG5: bounded prior, attribution, significance framing | **PASS-BOUNDED**, minor attribution notes O4/O5 | s9, refs |
| MG6: literal native Conj 1.4 and MathDB snapshot | **PASS** | s1, refs |
| Whole paper | **PASS** recommendation | |
| Portable package | **PASS** | |

The whole-paper verdict means a standalone human-checkable proof. Its two finite components are explicitly declared computer-assisted, kernel-reduced exact certificates: the s7 box (7.2), and the T_a coefficient arrays for 25<=n<7P_a. Their method is fully specified and justified in prose. No objection below is mathematical; all are editorial or attribution items. I made NO repair to any sealed file. This is not acceptance, novelty certification or credit.

## Mathematics personally reconstructed (by hand, no computation tools)

**s1-s2 statement and generating functions.**
- Occurrence counting with multiplicity matches the native definition. Residue t is read as 0.
- Identity (2.1) holds.
- I re-derived the pair identity: A_aB_{a+1}-A_{a+1}B_a = sum_{i>j}(i-j)q^{(i+j)a+j}(1-q^{i-j}) = (1-q)F_{k,a}.
- F has nonnegative coefficients, and its q^a coefficient is 1 (i=1, j=0). For k=2, F=q^a.

**s3 chain and coin tools.**
- Telescoping and the punctured chain (3.1) hold.
- Coin identity (3.2) splits as (1-q^{pu})+q^{pu}(1-q^{qv}).
- The (3.4) kernel holds; chain elements above x are >=2x>a+1.
- All 5 windows and the 4 (2,1,3,c,24) tables were re-verified entry by entry. Examples: 25=5+2x10; 26=7x2+12; 28=4x7.
- The short-window continuation lemma is correct.

**s4 weak inequality.**
- (4.1) and (4.2) were expanded term by term. The pairs have equal parity, so division by 1-q^2 is nonnegative.
- The root-2 chain avoids the marks: 3^w+-1 = 2*3^j forces w<=1, and a=2 is excluded.
- I checked (4.3) by clearing denominators: q^2+2q^4+q^5-q^7-2q^8-q^10 on both sides.
- (4.4): I derived H_k/(1-q^{2k}) from y d/dy log B.
- Odd and even square decompositions of H_k were checked by coefficient count.
- (4.5) D*Q_4 = q+q^3-4q^4+q^5-q^9+4q^10-q^11-q^13 = H_4(1-q^6), computed coefficient by coefficient.
- k=3, a=1: (1-q)F_{3,1} = (q+q^2)(1-q^3), giving kernel (q+q^2)g_4g_5.
- For k=4, the obstruction a=3, x=4 is the only collision, and (1-q^4)g_2 = 1+q^2.
- For k=2, a>=5: x in <3,5> for x>=8; the remainder-1 case needs x>=16.

**s5 strict regions (MG1).**
- 5A: the root-count argument {1,2,3,5,7} minus (divisible, hit, 1) leaves >=2, with conductor <=24.
  - B_m, or B_2B_{m-2} (resp. 3+5, 3+13), are disjoint from the chain and the marks.
  - k=2: v=2x mod 5 makes x-3v divisible by 5, with u>=4.
  - k=3: 3^w+-1 lies in neither chain 2 nor chain 5.
  - k>=4: (2,3) with u>=11.
- 5B: (5.1) follows from (4.4) and B_1B_2.
  - k=4: n=17..22 witnesses re-checked; B_5 exponent is 0 or 5.
  - The recursion H_k = q^2H_{k-2}+q(1-q^{k-1})^2 was verified.
  - For odd and even k>=5, the residue witness has i<=2<k-1.
- 5C: (5.4) was verified by clearing denominators. a=2 witnesses 17..20 hold; for a=8,9, x=9=5+2*2.
- 5D: {3,5,7,11,13} minus 3 leaves >=2, with conductor <=120.
- 5E: the root-11 repair is valid for a in {7,8,15,16}; 8=5+3 and 16=10+6. The k=4, a=3 case uses (2,5,7) with 4=2*2.
  - The c-selection count is 4-1-1>=2.

**s6 binary pairs (MG2), with the corrected residual R.**
- P_2 = prod over odd c of g_c, so R = prod over odd c>=9 of g_c has UNRESTRICTED multiplicities. The correction is right.
- All four T_a were re-derived via 1/(1+q^h) = (1-q^h)g_{2h}.
- **All 4x25 listed coefficients were recomputed by hand.** I counted partitions into {3,4,5,7}, {4,5,6,7}, {5,6,7,8} and {3,7,8,10}. All 100 values match, including the negatives c_1(2), c_2(4), c_3(7), c_3(12), c_4(8).
  - L_1..L_4 agree with those values.
- Newton tail: deg N_a = a+delta+4P-sum h_i = 1663, 1662, 3341, 3340, each <4P = 1680, 1680, 3360, 3360. So every residue numerator has x-degree <=3 and the sequence is cubic for all u>=0. The (6.3) argument is valid.
- Injections (6.5) and (6.6) were verified:
  - The new minimum w-2 (resp. w-4) is unique, so the inverse is well defined.
  - Repeated minima are harmless.
  - Tags separate the targets.
  - d<n is needed, since F(n,n) = {empty}; all d<=12<17.
- Absorption arithmetic (6.8) was re-done for all four. For L_3, two absorptions consume 2q^16, q^21, q^23 exactly.
- Parity witnesses: r(odd>=9)>0 and r(even>=18)>0. Each bound at n>=17 has an odd argument >=9, or an even argument >=18.
- **Independent consistency evidence:** Craig v5 p2 footnote 2 lists the distinct-part counterexample tuples (1,2,2),(2,3,4),(2,4,4),(3,4,7),(4,5,8). These coincide with the negative atoms.

**s7-s8 finite closure and assembly.**
- The (7.1) case split covers every (k,a,n) with n>=max(a+5,17).
- (7.2) bounds: n<=a+119<=142.
- For k>=143 and n<=142, all multiplicities are <143, so C_k = C_143.
- An exceptional pair with a<=23 forces k<=24.
- (7.3) follows from sum_{j<k} j y^j = (y-ky^k+(k-1)y^{k+1})/(1-y)^2, and (7.4) follows from it.
- (7.5) holds mod X^143.
- s8 telescope:
  - n>=t+4>=a+5 for a<=t-1.
  - j>=1 terms use the weak inequality; for k=2 they start at a>=r+t>=7.
- Both clauses are proved in their literal form.

## Prose to checked code comparison

- `RBCountDefs.C/D` and `RB355303.original_weak/strict` match the native clauses exactly, including max(t+3) 16 < n.
- Pinned Mathlib text, read under the standard-library grant, gives `countRestricted n m := univ.filter (forall i in parts, parts.count i < m)`.
- `RBAbsorb.Residual` = partitions with all parts odd and >=9; this matches s6.1.
- `RBPrefixCheck.Required` equals (7.2) term for term. `exceptional` = positivePower a or a+1.
- `RBStrictReduce.adjStrict_of_premises` dispatches exactly as s7, including `stability_143` and the k>143 rewrite.
- `L1..L4`, `shifted_absorb2/4` and `surplus3` match (6.4), (6.7) and (6.8).
- `bridge1..4` are literal on `RBCount.C 2`.
- Crosswalk steps S1-S8B name these declarations.
- Most of the other proof bodies (RBStrictTail/Low/Core etc.) were not read line by line. My PASS rests on the prose proofs I reconstructed above, plus the kernel replay as separate evidence.

## Package verification (in memory, no extraction to disk, no execution of package code)

- 357 members: 332 `src/`, 2 `audits/`, 5 `primaries/`, 3 `binding/`, 6 `evidence/`, and 9 top-level files.
- Safety and metadata:
  - 0 absolute, `..`, backslash or colon paths.
  - 0 symlink modes, 0 duplicates, 0 directories.
  - CRC `testzip` passes.
  - Every member has date 2026-11-16 00:00, mode 0644, deflate, create_system 3, empty extras and comment, sorted order.
  - "Deterministic metadata" is therefore confirmed. Byte-level determinism across zlib versions is not claimed, and was not tested.
- Hashes:
  - All 332 `src/` members match `AUTHOR-CANONICAL-SOURCE-INDEX.json` (sha 97ff4bf1...) in hash and bytes.
  - The same 332 files match my lane's `src/`.
  - They also match the independent replay lane's sealed `src/` and `producer/extracted/` entries (REPLAY-PHYSICAL-SHA256-SEAL). There are 0 mismatches across all comparisons.
- `audits/RBReplay{AxiomMap,Unconditional}.lean` equal the replay's own audit sources. They are not in the 332-entry index.
- The version probe is NOT in the ZIP. It exists only as an owned extra in `src/`.
- The manifest's 356 entries are all verified. Manuscript, crosswalk, MG-resolution, indexes, pins (Lean 4.34.1, mathlib d13f23b7...), the 5 primaries, binding, qualification, root adjudication and the replay report/seal all equal the owned copies.
- I read `extract_package.py`: it checks traversal, symlinks, duplicates, the manifest and the index, using the standard library only. I did not run it.

## Statement fidelity (MG6)

- I rendered native pp1, 4 and 5 myself via the PDF skill and read them visually.
  - p5 Conj 1.4: weak for t>=6, 1<=r<s<=t, k>=3, n>=1; strict for k>=2 and n>max{t+3,16}.
  - The p1 abstract defines k-regular as multiplicity <k.
  - The p4 Theorem 1.3 and its Remark are as described in s9.
- The JO-U22 p2 text notes that "k-regular" is used for both classes and that JO uses the multiplicity class.
- Under the k-indivisible reading the conjectured order fails; see native Fig. 2 p4, e.g. k=2, t=7. The multiplicity reading is therefore the only coherent one.
- The granted raw record (1,916 B, sha 04a58a2d...) equals the ZIP `binding/` copy byte for byte. It states the same quantifiers: header k>=3, with strict "for k>=2". The theorem covers both readings.
- Retained snapshot only; no live MathDB status is claimed.

## MG4 replay and trust history

s10 agrees with the full replay report, which I read in full. Matching points:
- 332/332 fresh compile plus a separate leanchecker check, plus 2 audits.
- 670/768 markers used. #612 is INTERRUPTED/UNKNOWN and charged; position 305 was retried as `r1`.
- 68,573-constant closure, using only the three standard axioms.
- max wall 33.83 s; RSS 3.03 GB.
- Trust base: binaries, upstream oleans, GMP; leanchecker uses the same kernel.
- Deviations stay UNWAIVED.
- s10 contains no stale campaign counts.

## Objections (non-blocking; none affects a proof step; I made none of these edits)

- **O1, s3/s5b:** the conductor lemma is stated for "distinct primes" but applied to (4,5) in 5B. The proof is valid for coprime p,q; the wording should say "coprime".
- **O2, s3 table:** rows (5,3,2,2,5) and (2,3,3,3,5) list c=q as a placeholder. This is explained only later in 5A; annotate it in the table.
- **O3, s6.2:** "degree <4P_a" is asserted without the numbers. Display sum h_i = 19/22/26/28 and degrees 1663/1662/3341/3340.
- **O4, refs:** Craig v5 and HN24 publication leads known to the qualification are omitted. These are RNT DOI 10.1007/s40993-022-00355-4 and 10.1007/s40993-025-00684-0. JO-U22/JO-N23 DOIs are given, so the treatment is inconsistent. Cite them as leads whose final bodies are unread.
- **O5, s9 attribution:** credit Craig v5 footnote 2 (p2) as the prior numerical observation of exactly the distinct-part small exceptions that s6 absorbs. Also note that the native p4 Remark shows the strict threshold is sharp: equality at n=t+3 for k=2.
- **O6, s6.1:** "exact cancellation of the odd root 1,3,5,7 factors" is loose, because g_3, g_5, g_7 remain in the T_a. It is a regrouping.
- **O7, s5c:** "so j>=0" can be sharpened to j>=1. Harmless.
- **O8, s10, optional:** disclose the `RBPrefix.*._unsafe_rec` codegen helpers outside the proof closure that the replay reports.
- **O9, package:** `evidence/old-author-outline.md` keeps the superseded "distinct odd" R. s6.1 discloses the correction; a manifest "superseded" label would help.

## MG5: significance framing and strongest contrary case

- I visually checked every s9 description of the five primaries against the pages:
  - Craig pp2-3: n>400t^2/3; Cor 1.3 for t<=10, n>8.
  - JO-U22 Thm 1.1: coprime, digamma, k-indivisible.
  - JO-N23 Thm 1.1: No Ties.
  - HN24 Thm 2.2: unmarked p_k(a)p_k(b)>p_k(a+b).
  - All descriptions are accurate.
- The paper keeps the FULL uniform native question. It claims only the whole combination and disclaims the tools, helpers, isolated computations and formalization.
- My strongest routine objection:
  - For unrestricted partitions, C(a;n) = sum_j p(n-ja) is trivially decreasing in a.
  - Bounded multiplicity adds the signed term -k*sum_j p_k(n-jka), so a natural expert might expect a short classical proof of the adjacent comparison.
  - The proof here instead needs root-collision case analysis, the exact signed H_k analysis at a=1, binary negative atoms (which genuinely occur, per Craig), and a uniform strict support reduction recovering the sharp boundary.
  - I found no full bridge in the read material and cannot exhibit one. With zero search budget I make no worldwide claim.
- Whether this meets the substantive-credit standard is root's call. The manuscript's bounded statement of the case is accurate and not overclaimed.

## Hostile edge cases checked by hand

- Residue s=t, read as 0. n=0.
- a=1 with 1 in chain 1. Small k=3, 4 at a=1.
- k=2 with x in {8,16,32}. k=3 with x in {3,9,27}. k=4 with a=3.
- k=t-adjacent values of k.
- k>143 saturation. n=17 and n=t+4 thresholds.
- For d=n, injection failure is avoided.
- The u>=1 requirement in every coin use.
- The c_3(12) negative atom: [q^12]T_3R = c_3(12)+c_3(3)r(9) = 0, so this is not a counterexample.
- Window starts m0=5 against n>=a+5.

## Read / unread inventory

- **Read in full:** TASK; the override; the model policy; the three applicable AGENTS (in bounded slices).
- **Read in full:** the root controls (whole-ordinary intake, final bounded adjudication).
- **Read in full:** the author's MG-resolution, result, REPORT and the entire 41,035-byte manuscript (30 slices).
- **Read in full:** the replay report (13 slices), the prior qualification (18 slices), the PDF skill, the raw snapshot and provenance.
- **Read in part:** the crosswalk structure and S1-S8 declaration lists. The ~300k of transitive dependency lists were not read.
- **Read in part:** Lean files RBCountDefs, RB355303Final, and key definitions in RBAbsorbResidual, RBPrefixCheck, RBStrictReduce, RBAbsorbBounds/FiberMaps/Surplus and RBBinaryBridges.
- **Read in part:** pinned Mathlib Partition/Basic.lean lines 53-60 and 205-222.
- **Visual:** native pp1, 4, 5; Craig v5 pp2-3; Unexpected p2; NoTies p2; Heim v1 p5.
- **Unread, as disclosed limits:**
  - most of the 332 module bodies and the 50 MB shard data (the kernel checks them);
  - `CONDITIONAL-ASSEMBLY-PAPER.md` and `AUTHOR-FINAL-PAPER.md` (50 MB), and the export index body;
  - FIRST/PARENT-ATTEMPT receipts;
  - SOURCE-OWNERSHIP, inherited-denials and additional-work-restrictions bodies (structure only; no network was used, so no request screen was needed);
  - all other campaign controls in `inputs/`;
  - publisher-final bodies of the companions.

## Process and resources

- Every command after the bootstrap/verifier used `run.py` on CPU 0,1; every write used `write_lane.py`.
- Science runs 0; formal 0; HTTP 0; search 0. Renders and hashes were documentary.
- **UNWAIVED deviations:**
  1. Before the bootstrap I ran 4 direct-shell inventory/read commands. One printed TASK.txt plus helper scripts (about 16k chars) in a single display. That exceeded the 2000/2400/6000 limits and was not bounded slicing. Two listings also exceeded the 2400-char payload.
  2. Run `fin1` produced 2,081 chars, above the 2000 logical-slice limit, and the runner truncated it. I did not treat the unseen tail as read; it was re-run as `fin2`.
  3. `inv1` contained a no-op shell heredoc prefix.
  4. PNG views used the read-only image viewer.
- All inherited, author and replay deviations remain UNWAIVED.
- Passing hashes are custody only, not process cleanliness or scientific acceptance.

## Independence and separation

- I am independent of the author lane, and this is a fresh review.
- My verdicts in this report:
  - **Ordinary correctness** of the prose: PASS.
  - **Source fidelity:** PASS.
  - **Package custody:** PASS.
- Not decided here:
  - **Significance:** bounded; root's call.
  - **Formal readiness:** the replay passed earlier. This review made no formal calls.
  - **Acceptance:** root.
- Editorial items O1-O9 are author work if root wants them; they would need only a light re-check.
