import RBSharedVerifier
import RBStageFnCore
namespace RBShared
open scoped BigOperators
def conv (k a : Nat) (b : Bool) (f : Nat → Int) (n : Nat) : Int :=
 ∑ j ∈ Finset.range (RBPrefix.cut k a n), if j*a ≤ n then RBPrefix.weight b j * f (n-j*a) else 0
def markedCheck (k N a : Nat) (p c : Nat → Int) : Bool :=
 (List.range (N+1)).all fun n => decide (conv k a false c n = conv k a true p n)
theorem marked_function_sound (k a N : Nat) (hk : 0 < k) (ha : 1 ≤ a) (ha' : a ≤ 142)
 (p c : Nat → Int)
 (hp : ∀ n, n ≤ N → p n = (RBPrefix.actualMarked k 0).coeff n)
 (he : markedCheck k N a p c = true) :
 ∀ n, n ≤ N → c n = (RBPrefix.actualMarked k a).coeff n := by
 apply convolution_injective k a N hk ha
 intro n hn
 have eqn := (List.all_eq_true.mp he) n (List.mem_range.mpr (by omega))
 simp only [decide_eq_true_eq, conv, RBPrefix.sum_cut] at eqn
 have hr : (∑ j ∈ Finset.range k,
   if j*a ≤ n then RBPrefix.weight true j * p (n-j*a) else 0) =
   (factor k a true * RBPrefix.actualMarked k 0).coeff n := by
  rw [factor_coeff]
  apply Finset.sum_congr rfl
  intro j _
  split_ifs with hj
  · rw [hp (n-j*a) (by omega)]
  · rfl
 rw [hr, ← marked_factor k a ha ha', factor_coeff] at eqn
 simpa only [RBPrefix.weight, Bool.false_eq_true, ite_false, one_mul] using eqn
def comparisonCheck (k a : Nat) (s t : Nat → Int) : Bool :=
 (List.range 143).all fun n => if RBPrefix.Required k a n then decide (t n < s n) else true
theorem comparison_sound (k a : Nat) (s t : Nat → Int)
 (hs : ∀ n, n ≤ 142 → s n = (RBPrefix.actualMarked k a).coeff n)
 (ht : ∀ n, n ≤ 142 → t n = (RBPrefix.actualMarked k (a+1)).coeff n)
 (hc : comparisonCheck k a s t = true) :
 ∀ n, RBPrefix.Required k a n →
 (RBPrefix.actualMarked k (a+1)).coeff n < (RBPrefix.actualMarked k a).coeff n := by
 intro n hn
 have hb := (RBPrefix.required_bounds hn).2
 have he : t n < s n := by
  have h := (List.all_eq_true.mp hc) n (List.mem_range.mpr hb)
  simpa [hn] using h
 rw [hs n (by omega), ht n (by omega)] at he
 exact he
#print axioms marked_function_sound
#print axioms comparison_sound
end RBShared
