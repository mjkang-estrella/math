import RBCountOccurrence
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Nat.ModEq
import Mathlib.Algebra.Order.Group.Int
import Mathlib.Algebra.Order.Ring.Int

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBCountAssembly (355303 pilot A): adjacent residue differences and CONDITIONAL assembly

* `D_sub_D_succ_range` (all `k r t n`): exact adjacent residue difference as a finite sum.
* `D_sub_D_succ` (`1 ≤ r < t`): the DESIGN M2.1 form over `[1, n]`; the top summand keeps
  `C k (n+1) n`, which is `0` by `C_top_zero`.
* `conditional_nativeEndpoint_of_adjacent_comparisons`: the native endpoint
  CONDITIONAL ONLY on the three named statements `AdjWeakGe3`, `AdjWeakBinary`, `AdjStrict`,
  which are NOT proved here.  This is NOT a proof of the full target.
-/

namespace RBCount

open Finset

theorem succ_mod_iff (a r t : ℕ) : (a + 1) % t = (r + 1) % t ↔ a % t = r % t := by
  constructor
  · intro h
    have h' : Nat.ModEq t (a + 1) (r + 1) := h
    exact Nat.ModEq.add_right_cancel' 1 h'
  · intro h
    have h' : Nat.ModEq t a r := h
    exact Nat.ModEq.add_right 1 h'

/-- Exact adjacent residue difference (valid for all parameters). -/
theorem D_sub_D_succ_range (k r t n : ℕ) :
    (D k r t n : ℤ) - D k (r + 1) t n =
      ∑ a ∈ range (n + 1), if a % t = r % t then ((C k a n : ℤ) - C k (a + 1) n) else 0 := by
  have h1 : (D k r t n : ℤ) =
      ∑ a ∈ range (n + 1), if a % t = r % t then (C k a n : ℤ) else 0 := by
    rw [D_eq_sum_range k r t n (n + 1) (Nat.lt_succ_self n)]
    simp only [Nat.cast_sum, Nat.cast_ite, Nat.cast_zero]
  have h2 : (D k (r + 1) t n : ℤ) =
      ∑ a ∈ range (n + 1), if a % t = r % t then (C k (a + 1) n : ℤ) else 0 := by
    rw [D_eq_sum_range k (r + 1) t n (n + 1 + 1) (by omega), Finset.sum_range_succ']
    simp only [C_size_zero, Nat.cast_add, Nat.cast_sum, Nat.cast_ite, Nat.cast_zero, ite_self,
      add_zero, succ_mod_iff]
  rw [h1, h2, ← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl fun a _ => ?_
  split_ifs <;> simp

/-- (M2.1) DESIGN form: for `1 ≤ r < t`, the difference is a sum over `a ∈ [1, n]`,
`a ≡ r (mod t)`, of `C a − C (a+1)`; the summand `a = n` contains `C k (n+1) n = 0`. -/
theorem D_sub_D_succ (k r t n : ℕ) (hr : 1 ≤ r) (hrt : r < t) :
    (D k r t n : ℤ) - D k (r + 1) t n =
      ∑ a ∈ (Icc 1 n).filter (fun a => a % t = r % t), ((C k a n : ℤ) - C k (a + 1) n) := by
  rw [D_sub_D_succ_range, Finset.sum_filter]
  symm
  apply Finset.sum_subset
  · intro x hx
    rw [Finset.mem_Icc] at hx
    exact Finset.mem_range.mpr (by omega)
  · intro x hx hx'
    have hx0 : x = 0 := by
      rw [Finset.mem_Icc] at hx'
      rw [Finset.mem_range] at hx
      omega
    subst hx0
    have h0 : ¬ (0 % t = r % t) := by
      rw [Nat.zero_mod, Nat.mod_eq_of_lt hrt]
      omega
    exact ite_eq_right h0

theorem D_succ_le_of_weak (hW : AdjWeakGe3) {k u t n : ℕ} (hk : 3 ≤ k) (hu : 1 ≤ u)
    (hut : u < t) : D k (u + 1) t n ≤ D k u t n := by
  have hnn : (0 : ℤ) ≤ (D k u t n : ℤ) - D k (u + 1) t n := by
    rw [D_sub_D_succ_range]
    apply Finset.sum_nonneg
    intro a _
    split_ifs with ha
    · have ha1 : 1 ≤ a := by
        rcases Nat.eq_zero_or_pos a with h0 | h0
        · subst h0
          rw [Nat.zero_mod, Nat.mod_eq_of_lt hut] at ha
          omega
        · exact h0
      have := hW k a n hk ha1
      omega
    · exact le_refl 0
  omega

theorem D_succ_lt_of_tails (hW3 : AdjWeakGe3) (hW2 : AdjWeakBinary) (hS : AdjStrict)
    {k u t n : ℕ} (hk : 2 ≤ k) (ht : 6 ≤ t) (hu : 1 ≤ u) (hut : u < t)
    (hn : max (t + 3) 16 < n) : D k (u + 1) t n < D k u t n := by
  have hn' := max_lt_iff.mp hn
  have hpos : (0 : ℤ) < (D k u t n : ℤ) - D k (u + 1) t n := by
    rw [D_sub_D_succ_range]
    apply Finset.sum_pos'
    · intro a _
      split_ifs with ha
      · have hau : a % t = u := by rw [ha, Nat.mod_eq_of_lt hut]
        by_cases hlt : a < t
        · have hau' : a = u := by
            rw [Nat.mod_eq_of_lt hlt] at hau
            exact hau
          rw [hau']
          have := hS k u n hk hu (max_lt_iff.mpr ⟨by omega, by omega⟩)
          omega
        · rcases Nat.lt_or_ge k 3 with hk3 | hk3
          · have hk2 : k = 2 := by omega
            subst hk2
            have := hW2 a n (by omega)
            omega
          · have := hW3 k a n hk3 (by omega)
            omega
      · exact le_refl 0
    · refine ⟨u, Finset.mem_range.mpr (by omega), ?_⟩
      rw [ite_eq_left rfl]
      have := hS k u n hk hu (max_lt_iff.mpr ⟨by omega, by omega⟩)
      omega
  omega

theorem weak_chain (hW : AdjWeakGe3) {k t n r : ℕ} (hk : 3 ≤ k) (hr : 1 ≤ r) :
    ∀ d : ℕ, r + d + 1 ≤ t → D k (r + d + 1) t n ≤ D k r t n := by
  intro d
  induction d with
  | zero =>
    intro h
    rw [Nat.add_zero]
    exact D_succ_le_of_weak hW hk hr (by omega)
  | succ d ih =>
    intro h
    have h1 := ih (by omega)
    have h2 := D_succ_le_of_weak (u := r + d + 1) (t := t) (n := n) hW hk (by omega) (by omega)
    have e : r + (d + 1) + 1 = r + d + 1 + 1 := by omega
    rw [e]
    exact le_trans h2 h1

theorem strict_chain (hW3 : AdjWeakGe3) (hW2 : AdjWeakBinary) (hS : AdjStrict)
    {k t n r : ℕ} (hk : 2 ≤ k) (ht : 6 ≤ t) (hn : max (t + 3) 16 < n) (hr : 1 ≤ r) :
    ∀ d : ℕ, r + d + 1 ≤ t → D k (r + d + 1) t n < D k r t n := by
  intro d
  induction d with
  | zero =>
    intro h
    rw [Nat.add_zero]
    exact D_succ_lt_of_tails hW3 hW2 hS hk ht hr (by omega) hn
  | succ d ih =>
    intro h
    have h1 := ih (by omega)
    have h2 := D_succ_lt_of_tails (u := r + d + 1) hW3 hW2 hS hk ht (by omega) (by omega) hn
    have e : r + (d + 1) + 1 = r + d + 1 + 1 := by omega
    rw [e]
    exact lt_trans h2 h1

/-- CONDITIONAL assembly (DESIGN M2.2): the native endpoint follows from the three NAMED
adjacent comparison statements, which are hypotheses here and are NOT proved in this pilot.
This theorem is NOT a proof of the full target. -/
theorem conditional_nativeEndpoint_of_adjacent_comparisons
    (hW3 : AdjWeakGe3) (hW2 : AdjWeakBinary) (hS : AdjStrict) : NativeEndpoint := by
  refine ⟨?_, ?_⟩
  · intro k t r s n hk ht hr hrs hst hn
    have h := weak_chain (t := t) (n := n) hW3 hk hr (s - r - 1) (by omega)
    have e : r + (s - r - 1) + 1 = s := by omega
    rw [e] at h
    exact h
  · intro k t r s n hk ht hr hrs hst hn
    have h := strict_chain (t := t) (n := n) hW3 hW2 hS hk ht hn hr (s - r - 1) (by omega)
    have e : r + (s - r - 1) + 1 = s := by omega
    rw [e] at h
    exact h

end RBCount

#print axioms RBCount.D_sub_D_succ_range
#print axioms RBCount.D_sub_D_succ
#print axioms RBCount.conditional_nativeEndpoint_of_adjacent_comparisons
