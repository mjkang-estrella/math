import RBSharedClosed
import RBAssembleEndpoint

namespace RB355303

/-- Exact compatibility, with no computed or external premise. -/
theorem finitePrefixPolynomial : RBAssemble.FinitePrefixPolynomial :=
  RBSharedClosed.full_table

theorem finitePrefixNative : RBStrict.FinitePrefixNative :=
  RBAssemble.finitePrefixNative_of_polynomial finitePrefixPolynomial

theorem adjStrict : RBCount.AdjStrict :=
  RBAssemble.adjStrict_of_finitePrefixPolynomial finitePrefixPolynomial

theorem nativeEndpoint : RBCount.NativeEndpoint :=
  RBAssemble.nativeEndpoint_of_finitePrefixPolynomial finitePrefixPolynomial

theorem original_weak :
    ∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
        (p.parts.filter (fun x => x % t = s % t)).card) ≤
      (∑ p ∈ Nat.Partition.countRestricted n k,
        (p.parts.filter (fun x => x % t = r % t)).card) :=
  nativeEndpoint.1

theorem original_strict :
    ∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
      (∑ p ∈ Nat.Partition.countRestricted n k,
        (p.parts.filter (fun x => x % t = s % t)).card) <
      (∑ p ∈ Nat.Partition.countRestricted n k,
        (p.parts.filter (fun x => x % t = r % t)).card) :=
  nativeEndpoint.2

end RB355303
