import T2Data0
set_option maxRecDepth 16000
namespace T2
def tab (n : ℕ) : ℤ :=
  match n/64 with
  | 0 => block0[n%64]!
  | 1 => block1[n%64]!
  | 2 => block2[n%64]!
  | 3 => block3[n%64]!
  | 4 => block4[n%64]!
  | 5 => block5[n%64]!
  | 6 => block6[n%64]!
  | 7 => block7[n%64]!
  | 8 => block8[n%64]!
  | 9 => block9[n%64]!
  | 10 => block10[n%64]!
  | 11 => block11[n%64]!
  | 12 => block12[n%64]!
  | 13 => block13[n%64]!
  | 14 => block14[n%64]!
  | 15 => block15[n%64]!
  | 16 => block16[n%64]!
  | 17 => block17[n%64]!
  | 18 => block18[n%64]!
  | 19 => block19[n%64]!
  | 20 => block20[n%64]!
  | 21 => block21[n%64]!
  | 22 => block22[n%64]!
  | 23 => block23[n%64]!
  | 24 => block24[n%64]!
  | 25 => block25[n%64]!
  | 26 => block26[n%64]!
  | 27 => block27[n%64]!
  | 28 => block28[n%64]!
  | 29 => block29[n%64]!
  | 30 => block30[n%64]!
  | 31 => block31[n%64]!
  | 32 => block32[n%64]!
  | 33 => block33[n%64]!
  | 34 => block34[n%64]!
  | 35 => block35[n%64]!
  | 36 => block36[n%64]!
  | 37 => block37[n%64]!
  | 38 => block38[n%64]!
  | 39 => block39[n%64]!
  | 40 => block40[n%64]!
  | 41 => block41[n%64]!
  | 42 => block42[n%64]!
  | 43 => block43[n%64]!
  | 44 => block44[n%64]!
  | 45 => block45[n%64]!
  | _ => 0
#print axioms tab
end T2
