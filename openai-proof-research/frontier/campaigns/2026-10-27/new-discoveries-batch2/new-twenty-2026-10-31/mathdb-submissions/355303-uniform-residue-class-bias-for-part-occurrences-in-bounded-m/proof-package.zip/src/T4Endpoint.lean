import T4Literals

noncomputable section
namespace T4
open T1 (newton newton_nonneg)
open PowerSeries

theorem prefix_correct (n : ℕ) (hn : n<5880) : coeff n rational=tab n :=
  prefix_identification tab 5880 (fun m hm => tab_recurrence ⟨m,hm⟩) n hn

def grid (r u : ℕ) : ℤ := coeff (r+840*(u+3)) rational

theorem grid_newton (r u : ℕ) : grid r u =
    newton (grid r 0) (diff (grid r) 0) (diff (diff (grid r)) 0)
      (diff (diff (diff (grid r))) 0) u := by
  apply fourth_newton
  intro v
  simpa [grid,Nat.add_assoc] using fourth r (v+3)

theorem grid_seeds (r : ℕ) (hr : r<840) :
    0≤grid r 0 ∧ 0≤diff (grid r) 0 ∧ 0≤diff (diff (grid r)) 0 ∧
      0≤diff (diff (diff (grid r))) 0 := by
  have ht := tab_rows ⟨r,hr⟩
  have h0 := prefix_correct (r+2520) (by omega)
  have h1 := prefix_correct (r+3360) (by omega)
  have h2 := prefix_correct (r+4200) (by omega)
  have h3 := prefix_correct (r+5040) (by omega)
  norm_num [grid,diff] at *
  rw [h0,h1,h2,h3]
  constructor
  · exact ht.1
  constructor
  · exact ht.2.1
  constructor
  · linear_combination ht.2.2.1
  · linear_combination ht.2.2.2

theorem grid_nonnegative (r u : ℕ) (hr : r<840) : 0≤grid r u := by
  rw [grid_newton]
  obtain ⟨h0,h1,h2,h3⟩ := grid_seeds r hr
  exact newton_nonneg _ _ _ _ h0 h1 h2 h3 u

theorem coefficient_negative8 : coeff 8 rational = -1 := by
  rw [prefix_correct 8 (by decide)]
  exact tab_negative8
theorem coefficient_nonnegative (n : ℕ) (hn8 : n≠8) : 0≤coeff n rational := by
  by_cases h : n<2520
  · rw [prefix_correct n (by omega)]
    exact tab_prefix ⟨n,h⟩ hn8
  · have hr : n%840<840 := Nat.mod_lt n (by decide)
    have hq : 3≤n/840 := by omega
    have he : n=n%840+840*((n/840-3)+3) := by omega
    rw [he]
    exact grid_nonnegative (n%840) (n/840-3) hr
theorem literal_endpoint : ∃! s : PowerSeries ℤ,
  ((1-X^8)*(1-X^10)*(1-X^3)*(1-X^7))*s=X^4-X^8 ∧ coeff 8 s = -1 ∧ (∀ n : ℕ, n≠8 → 0≤coeff n s) := by
  refine ⟨rational, ⟨denominator_rational,coefficient_negative8,coefficient_nonnegative⟩, ?_⟩
  intro s hs
  exact denominator_unique s hs.1
#print axioms prefix_correct
#print axioms grid
#print axioms grid_newton
#print axioms grid_seeds
#print axioms grid_nonnegative
#print axioms coefficient_negative8
#print axioms coefficient_nonnegative
#print axioms literal_endpoint
end T4
