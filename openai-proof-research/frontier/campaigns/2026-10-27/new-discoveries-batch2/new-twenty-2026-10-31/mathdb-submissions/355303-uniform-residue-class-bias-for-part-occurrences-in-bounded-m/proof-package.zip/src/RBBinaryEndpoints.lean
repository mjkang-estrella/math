import RBBinaryBridges
noncomputable section
namespace RBBinary
open PowerSeries

def LowBinaryNative : Prop := ∀ a n : ℕ, 1 ≤ a → a ≤ 4 → 17 ≤ n →
  RBCount.C 2 (a+1) n < RBCount.C 2 a n

theorem strict1 (n : ℕ) (hn : 17 ≤ n) : RBCount.C 2 2 n < RBCount.C 2 1 n := by
  have h := RBAbsorb.product1_positive n hn
  rw [←bridge1 n] at h
  omega

theorem strict2 (n : ℕ) (hn : 17 ≤ n) : RBCount.C 2 3 n < RBCount.C 2 2 n := by
  have h := RBAbsorb.product2_positive n hn
  rw [←bridge2 n] at h
  omega

theorem strict3 (n : ℕ) (hn : 17 ≤ n) : RBCount.C 2 4 n < RBCount.C 2 3 n := by
  have h := RBAbsorb.product3_positive n hn
  rw [←bridge3 n] at h
  omega

theorem strict4 (n : ℕ) (hn : 17 ≤ n) : RBCount.C 2 5 n < RBCount.C 2 4 n := by
  have h := RBAbsorb.product4_positive n hn
  rw [←bridge4 n] at h
  omega

theorem lowBinaryNative_holds : LowBinaryNative := by
  intro a n ha ha4 hn
  have h : a=1 ∨ a=2 ∨ a=3 ∨ a=4 := by omega
  rcases h with rfl | rfl | rfl | rfl
  · exact strict1 n hn
  · exact strict2 n hn
  · exact strict3 n hn
  · exact strict4 n hn

#print LowBinaryNative
#print lowBinaryNative_holds
#print axioms strict1
#print axioms strict2
#print axioms strict3
#print axioms strict4
#print axioms lowBinaryNative_holds
#eval Lean.versionString
end RBBinary
