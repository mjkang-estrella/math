import RBSharedFn
namespace RBShared
theorem assemble22 (Q : Nat → Prop)
 (h2 : Q 2)
 (h3 : Q 3)
 (h4 : Q 4)
 (h5 : Q 5)
 (h6 : Q 6)
 (h7 : Q 7)
 (h8 : Q 8)
 (h9 : Q 9)
 (h10 : Q 10)
 (h11 : Q 11)
 (h12 : Q 12)
 (h13 : Q 13)
 (h14 : Q 14)
 (h15 : Q 15)
 (h16 : Q 16)
 (h17 : Q 17)
 (h18 : Q 18)
 (h19 : Q 19)
 (h20 : Q 20)
 (h21 : Q 21)
 (h22 : Q 22)
 (h23 : Q 23) : ∀ a, 2 ≤ a → a ≤ 23 → Q a := by
 intro a hl hh
 have hc : a = 2 ∨ a = 3 ∨ a = 4 ∨ a = 5 ∨ a = 6 ∨ a = 7 ∨ a = 8 ∨ a = 9 ∨ a = 10 ∨ a = 11 ∨ a = 12 ∨ a = 13 ∨ a = 14 ∨ a = 15 ∨ a = 16 ∨ a = 17 ∨ a = 18 ∨ a = 19 ∨ a = 20 ∨ a = 21 ∨ a = 22 ∨ a = 23 := by omega
 rcases hc with e2 | e3 | e4 | e5 | e6 | e7 | e8 | e9 | e10 | e11 | e12 | e13 | e14 | e15 | e16 | e17 | e18 | e19 | e20 | e21 | e22 | e23
 · simpa only [e2] using h2
 · simpa only [e3] using h3
 · simpa only [e4] using h4
 · simpa only [e5] using h5
 · simpa only [e6] using h6
 · simpa only [e7] using h7
 · simpa only [e8] using h8
 · simpa only [e9] using h9
 · simpa only [e10] using h10
 · simpa only [e11] using h11
 · simpa only [e12] using h12
 · simpa only [e13] using h13
 · simpa only [e14] using h14
 · simpa only [e15] using h15
 · simpa only [e16] using h16
 · simpa only [e17] using h17
 · simpa only [e18] using h18
 · simpa only [e19] using h19
 · simpa only [e20] using h20
 · simpa only [e21] using h21
 · simpa only [e22] using h22
 · simpa only [e23] using h23
#print axioms assemble22
end RBShared
