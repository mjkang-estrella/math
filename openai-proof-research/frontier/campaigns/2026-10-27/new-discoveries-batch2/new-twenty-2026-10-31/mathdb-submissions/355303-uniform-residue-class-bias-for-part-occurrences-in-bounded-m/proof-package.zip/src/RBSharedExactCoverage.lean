import RBPrefixCard
import RBSharedRange
set_option maxRecDepth 100000
namespace RBShared
open scoped BigOperators
theorem window_exact (lo hi n : Nat) (hl : lo ≤ hi+1) :
 (∃ t, t < hi+1-lo ∧ n=lo+t) ↔ lo ≤ n ∧ n ≤ hi := by
 constructor
 · rintro ⟨t,ht,hn⟩; omega
 · rintro ⟨hn,hn'⟩
   exact ⟨n-lo,by omega,by omega⟩
theorem rowLength_exact (k a n : Nat) (hk : 2 ≤ k) (hk' : k ≤ 143)
 (ha : 2 ≤ a) (ha' : a ≤ 23) :
 (∃ t, t < RBPrefix.rowLength k a ∧ n = max (a+5) 17 + t) ↔ RBPrefix.Required k a n := by
 let B := (k = 2 ∧ a < 5) ∨ (k = 3 ∧ RBPrefix.exceptional k a = true)
 have hr : RBPrefix.Required k a n ↔ ¬B ∧ max (a+5) 17 ≤ n ∧
   n ≤ a+(if RBPrefix.exceptional k a then 23 else 119) := by
  constructor
  · rintro ⟨_,_,_,_,h2,h3,hl,hu⟩
    refine ⟨?_,hl,hu⟩
    rintro (hb|hb)
    · have := h2 hb.1; omega
    · exact h3 hb
  · rintro ⟨hb,hl,hu⟩
    refine ⟨hk,hk',ha,ha',?_,?_,hl,hu⟩
    · intro hk2
      by_contra hh
      exact hb (Or.inl ⟨hk2,by omega⟩)
    · intro hh
      exact hb (Or.inr hh)
 have hl : max (a+5) 17 ≤ a+(if RBPrefix.exceptional k a then 23 else 119)+1 := by
  split_ifs <;> omega
 by_cases hb : B
 · change (∃ t, t < (if B then 0 else _) ∧ n=_) ↔ _
   rw [ite_eq_left hb,hr]
   constructor
   · rintro ⟨t,ht,_⟩; omega
   · intro hh; exact False.elim (hh.1 hb)
 · change (∃ t, t < (if B then 0 else _) ∧ n=_) ↔ _
   rw [ite_eq_right hb,hr]
   constructor
   · intro hh
     exact ⟨hb,(window_exact _ _ _ hl).mp hh⟩
   · intro hh
     exact (window_exact _ _ _ hl).mpr hh.2
abbrev Index := Σ d : Fin 142, Σ e : Fin 22, Fin (RBPrefix.rowLength (2+d) (2+e))
def caseMap (i : Index) : Nat × Nat × Nat :=
 (2+i.1.val, 2+i.2.1.val, max (2+i.2.1.val+5) 17 + i.2.2.val)
theorem caseMap_injective : Function.Injective caseMap := by
 rintro ⟨d,e,t⟩ ⟨d',e',t'⟩ h
 have hd : d = d' := by
  apply Fin.ext
  have he := congrArg Prod.fst h
  simp only [caseMap] at he
  omega
 subst d'
 have he : e = e' := by
  apply Fin.ext
  have he := congrArg (fun x : Nat × Nat × Nat => x.2.1) h
  simp only [caseMap] at he
  omega
 subst e'
 have ht : t = t' := by
  apply Fin.ext
  have he := congrArg (fun x : Nat × Nat × Nat => x.2.2) h
  simp only [caseMap] at he
  omega
 subst t'
 rfl
def coverage : Finset (Nat × Nat × Nat) := Finset.univ.image caseMap
theorem coverage_exact (k a n : Nat) : (k,a,n) ∈ coverage ↔ RBPrefix.Required k a n := by
 constructor
 · intro h
   obtain ⟨i, _, hi⟩ := Finset.mem_image.mp h
   obtain ⟨d,e,t⟩ := i
   cases hi
   apply (rowLength_exact (2+d) (2+e) _ (by omega) (by omega) (by omega) (by omega)).mp
   exact ⟨t.val,t.isLt,rfl⟩
 · intro r
   have hk := r.1
   have hk' := r.2.1
   have ha := r.2.2.1
   have ha' := r.2.2.2.1
   obtain ⟨t,ht,hn⟩ := (rowLength_exact k a n hk hk' ha ha').mpr r
   have hd : k = 2+(k-2) := by omega
   have he : a = 2+(a-2) := by omega
   let i : Index := ⟨⟨k-2,by omega⟩,⟨a-2,by omega⟩,⟨t,by simpa only [←hd,←he] using ht⟩⟩
   refine Finset.mem_image.mpr ⟨i,Finset.mem_univ _,?_⟩
   change (2+(k-2),2+(a-2),max (2+(a-2)+5) 17+t) = (k,a,n)
   rw [←hd,←he,←hn]
theorem coverage_card : coverage.card = 346186 := by
 rw [coverage, Finset.card_image_of_injective _ caseMap_injective, Finset.card_univ]
 simp only [Index, Fintype.card_sigma, Fintype.card_fin]
 exact RBPrefix.caseCount_value
#print axioms coverage_exact
#print axioms coverage_card
end RBShared
