import RBStrictTail
import RBStrictLow
import RBWeakExport

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBStrictReduce (355303): exact reduction of the UNCHANGED `RBCount.AdjStrict` to two explicit
premises, and the conditional native endpoint.

`LowBinaryNative` and `FinitePrefixNative` are NOT proved here; they are explicit hypotheses.
`StrictExc k a` : `a` or `a + 1` equals `k^e` with `e ≥ 1`.
`FinitePrefixNative` is EXACTLY the original finite Required set: `2 ≤ k ≤ 143`, `2 ≤ a ≤ 23`
(`k = 2 → a ≥ 5`), all pairs except `k = 3` exceptional, `max (a+5) 17 ≤ n ≤ a + 23` (exceptional)
or `≤ a + 119` (otherwise), inclusive.
-/

namespace RBStrict

open RBCount

def StrictExc (k a : ℕ) : Prop := ∃ e : ℕ, 1 ≤ e ∧ (a = k ^ e ∨ a + 1 = k ^ e)

def LowBinaryNative : Prop :=
  ∀ a n : ℕ, 1 ≤ a → a ≤ 4 → 17 ≤ n → C 2 (a + 1) n < C 2 a n

def FinitePrefixNative : Prop :=
  ∀ k a n : ℕ, 2 ≤ k → k ≤ 143 → 2 ≤ a → a ≤ 23 → (k = 2 → 5 ≤ a) → ¬ (k = 3 ∧ StrictExc k a) →
    max (a + 5) 17 ≤ n → (StrictExc k a → n ≤ a + 23) → (¬ StrictExc k a → n ≤ a + 119) →
      C k (a + 1) n < C k a n

theorem pow_ge_self {k e : ℕ} (hk : 1 ≤ k) (he : 1 ≤ e) : k ≤ k ^ e := by
  have := Nat.pow_le_pow_right (by omega : k > 0) he
  rwa [pow_one] at this

theorem not_exc_pow {k a : ℕ} (ha : 2 ≤ a) (hE : ¬ StrictExc k a) :
    ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1 := by
  intro w
  rcases Nat.eq_zero_or_pos w with h | h
  · rw [h, pow_zero]
    omega
  · exact ⟨fun e => hE ⟨w, h, Or.inl e.symm⟩, fun e => hE ⟨w, h, Or.inr e.symm⟩⟩

theorem k3_exc_small {a : ℕ} (ha : 2 ≤ a) (ha23 : a ≤ 23) (hE : StrictExc 3 a) :
    a = 2 ∨ a = 3 ∨ a = 8 ∨ a = 9 := by
  obtain ⟨e, he, hx⟩ := hE
  have he2 : e ≤ 2 := by
    by_contra h
    have := Nat.pow_le_pow_right (by norm_num : 3 > 0) (by omega : 3 ≤ e)
    norm_num at this
    omega
  rcases (show e = 1 ∨ e = 2 by omega) with rfl | rfl
  · norm_num at hx
    omega
  · norm_num at hx
    omega

/-! ## Closed regions (expanded statements) -/

/-- All `k ≥ 2`, `a ≥ 24`, literal threshold. -/
theorem region_a24 : ∀ k a n : ℕ, 2 ≤ k → 24 ≤ a → max (a + 4) 16 < n →
    C k (a + 1) n < C k a n := fun k a n hk ha hn => by
  have := le_max_left (a + 4) 16
  exact strict_a24 hk ha (by omega)

/-- All `k ≥ 3`, `a = 1`, `n > 16`. -/
theorem region_a1 : ∀ k n : ℕ, 3 ≤ k → 16 < n → C k (1 + 1) n < C k 1 n :=
  fun k n hk hn => strict_a1 hk (by omega)

/-- All `k = 3` exceptional pairs, literal threshold. -/
theorem region_k3_exc : ∀ a n : ℕ, 1 ≤ a → StrictExc 3 a → max (a + 4) 16 < n →
    C 3 (a + 1) n < C 3 a n := by
  intro a n ha hE hn
  have h1 := le_max_left (a + 4) 16
  have h2 := le_max_right (a + 4) 16
  by_cases h24 : 24 ≤ a
  · exact strict_a24 (by norm_num) h24 (by omega)
  · have ha2 : 2 ≤ a := by
      obtain ⟨e, he, hx⟩ := hE
      have := pow_ge_self (k := 3) (by norm_num) he
      omega
    exact strict_k3_small (k3_exc_small ha2 (by omega) hE) (by omega)

/-- Non-exceptional tail (conductor 120), all `k ≥ 2`, `a ≥ 2`. -/
theorem region_small_NE : ∀ k a n : ℕ, 2 ≤ k → 2 ≤ a → ¬ StrictExc k a → a + 120 ≤ n →
    C k (a + 1) n < C k a n :=
  fun k a n hk ha hE hn => strict_small_NE hk ha (not_exc_pow ha hE) hn

/-- Exceptional tail (conductor 24), `k ≠ 3`, `2 ≤ a ≤ 23`, `k = 2 → a ≥ 5`. -/
theorem region_small_exc : ∀ k a n : ℕ, 2 ≤ k → k ≠ 3 → 2 ≤ a → a ≤ 23 → (k = 2 → 5 ≤ a) →
    StrictExc k a → a + 24 ≤ n → C k (a + 1) n < C k a n := by
  intro k a n hk hk3 ha ha23 hk2 hE hn
  obtain ⟨e, he, hx⟩ := hE
  exact strict_small_exc hk hk3 ha ha23 hk2 he (hx.imp Eq.symm Eq.symm) hn

/-- Native `k`-stability used for `k ≥ 143`, `n ≤ 142`. -/
theorem stability_143 : ∀ k a n : ℕ, 143 ≤ k → n ≤ 142 → C k a n = C 143 a n :=
  fun k a n hk hn => C_stable (by omega) (by omega)

/-! ## Exact reduction -/

theorem adjStrict_of_premises (hL : LowBinaryNative) (hF : FinitePrefixNative) : AdjStrict := by
  intro k a n hk ha hn
  have hn1 := le_max_left (a + 4) 16
  have hn2 := le_max_right (a + 4) 16
  by_cases hlow : k = 2 ∧ a ≤ 4
  · obtain ⟨rfl, h4⟩ := hlow
    exact hL a n ha h4 (by omega)
  by_cases ha1 : a = 1
  · subst ha1
    exact strict_a1 (by omega) (by omega)
  by_cases ha24 : 24 ≤ a
  · exact strict_a24 hk ha24 (by omega)
  have ha2 : 2 ≤ a := by omega
  have hk2 : k = 2 → 5 ≤ a := fun h => by omega
  have hmax : max (a + 5) 17 ≤ n := max_le (by omega) (by omega)
  by_cases hE : StrictExc k a
  · by_cases hk3 : k = 3
    · subst hk3
      exact strict_k3_small (k3_exc_small ha2 (by omega) hE) (by omega)
    · by_cases hbig : a + 24 ≤ n
      · obtain ⟨e, he, hx⟩ := hE
        exact strict_small_exc hk hk3 ha2 (by omega) hk2 he (hx.imp Eq.symm Eq.symm) hbig
      · have hk143 : k ≤ 143 := by
          obtain ⟨e, he, hx⟩ := hE
          have := pow_ge_self (by omega : 1 ≤ k) he
          omega
        exact hF k a n hk hk143 ha2 (by omega) hk2 (fun h => hk3 h.1) hmax (fun _ => by omega)
          (fun h => absurd hE h)
  · by_cases hbig : a + 120 ≤ n
    · exact strict_small_NE hk ha2 (not_exc_pow ha2 hE) hbig
    · by_cases hk143 : k ≤ 143
      · exact hF k a n hk hk143 ha2 (by omega) hk2 (fun h => hE h.2) hmax (fun h => absurd h hE)
          (fun _ => by omega)
      · have hE143 : ¬ StrictExc 143 a := fun ⟨e, he, hx⟩ => by
          have := pow_ge_self (k := 143) (by norm_num) he
          omega
        rw [C_stable (k := k) (k' := 143) (a := a + 1) (n := n) (by omega) (by omega),
          C_stable (k := k) (k' := 143) (a := a) (n := n) (by omega) (by omega)]
        exact hF 143 a n (by norm_num) le_rfl ha2 (by omega) (fun h => absurd h (by norm_num))
          (fun h => hE143 h.2) hmax (fun h => absurd h hE143) (fun _ => by omega)

/-- Expanded form of the reduction. -/
theorem adjStrict_expanded_of_premises (hL : LowBinaryNative) (hF : FinitePrefixNative) :
    ∀ k a n : ℕ, 2 ≤ k → 1 ≤ a → max (a + 4) 16 < n → C k (a + 1) n < C k a n :=
  adjStrict_of_premises hL hF

/-- CONDITIONAL native endpoint (weak clause unconditional from the paid prefix). -/
theorem nativeEndpoint_of_premises (hL : LowBinaryNative) (hF : FinitePrefixNative) :
    NativeEndpoint :=
  nativeEndpoint_of_adjStrict (adjStrict_of_premises hL hF)

theorem nativeStrict_of_premises (hL : LowBinaryNative) (hF : FinitePrefixNative) :
    ∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
      D k s t n < D k r t n :=
  (nativeEndpoint_of_premises hL hF).2

end RBStrict

#print axioms RBStrict.region_a24
#print axioms RBStrict.region_a1
#print axioms RBStrict.region_k3_exc
#print axioms RBStrict.region_small_NE
#print axioms RBStrict.region_small_exc
#print axioms RBStrict.stability_143
#print axioms RBStrict.adjStrict_of_premises
#print axioms RBStrict.nativeEndpoint_of_premises
#print axioms RBStrict.nativeStrict_of_premises
