import Endpoint
import T2Endpoint
import T3Endpoint
import T4Endpoint
noncomputable section
open PowerSeries
namespace T1
def smallValues : Array ℤ := #[0,1,-1,0,1,0,0,0,1,0,0,1,0,1,0,1,1,0,1,1,1,1,1,1,1]
def small (n : ℕ) : ℤ := smallValues[n]!
theorem small_rational : ∀ n : Fin 25, coeff n rational=small n := by
  have h : ∀ n : Fin 25, tab n=small n := by decide
  intro n
  rw [prefix_correct n (by omega)]
  exact h n
theorem small_of_denominator (s : PowerSeries ℤ) (h : denominator*s=numerator) : ∀ n : Fin 25, coeff n s=small n := by
  rw [denominator_unique s h]
  exact small_rational
theorem atom0 : coeff 0 rational = (0 : ℤ) := small_rational ⟨0,by decide⟩
theorem atom1 : coeff 1 rational = (1 : ℤ) := small_rational ⟨1,by decide⟩
theorem atom2 : coeff 2 rational = (-1 : ℤ) := small_rational ⟨2,by decide⟩
theorem atom3 : coeff 3 rational = (0 : ℤ) := small_rational ⟨3,by decide⟩
theorem atom4 : coeff 4 rational = (1 : ℤ) := small_rational ⟨4,by decide⟩
theorem atom5 : coeff 5 rational = (0 : ℤ) := small_rational ⟨5,by decide⟩
theorem atom6 : coeff 6 rational = (0 : ℤ) := small_rational ⟨6,by decide⟩
theorem atom7 : coeff 7 rational = (0 : ℤ) := small_rational ⟨7,by decide⟩
theorem atom8 : coeff 8 rational = (1 : ℤ) := small_rational ⟨8,by decide⟩
theorem atom9 : coeff 9 rational = (0 : ℤ) := small_rational ⟨9,by decide⟩
theorem atom10 : coeff 10 rational = (0 : ℤ) := small_rational ⟨10,by decide⟩
theorem atom11 : coeff 11 rational = (1 : ℤ) := small_rational ⟨11,by decide⟩
theorem atom12 : coeff 12 rational = (0 : ℤ) := small_rational ⟨12,by decide⟩
theorem atom13 : coeff 13 rational = (1 : ℤ) := small_rational ⟨13,by decide⟩
theorem atom14 : coeff 14 rational = (0 : ℤ) := small_rational ⟨14,by decide⟩
theorem atom15 : coeff 15 rational = (1 : ℤ) := small_rational ⟨15,by decide⟩
theorem atom16 : coeff 16 rational = (1 : ℤ) := small_rational ⟨16,by decide⟩
theorem atom17 : coeff 17 rational = (0 : ℤ) := small_rational ⟨17,by decide⟩
theorem atom18 : coeff 18 rational = (1 : ℤ) := small_rational ⟨18,by decide⟩
theorem atom19 : coeff 19 rational = (1 : ℤ) := small_rational ⟨19,by decide⟩
theorem atom20 : coeff 20 rational = (1 : ℤ) := small_rational ⟨20,by decide⟩
theorem atom21 : coeff 21 rational = (1 : ℤ) := small_rational ⟨21,by decide⟩
theorem atom22 : coeff 22 rational = (1 : ℤ) := small_rational ⟨22,by decide⟩
theorem atom23 : coeff 23 rational = (1 : ℤ) := small_rational ⟨23,by decide⟩
theorem atom24 : coeff 24 rational = (1 : ℤ) := small_rational ⟨24,by decide⟩
#print axioms smallValues
#print axioms small
#print axioms small_rational
#print axioms small_of_denominator
#print axioms atom0
#print axioms atom1
#print axioms atom2
#print axioms atom3
#print axioms atom4
#print axioms atom5
#print axioms atom6
#print axioms atom7
#print axioms atom8
#print axioms atom9
#print axioms atom10
#print axioms atom11
#print axioms atom12
#print axioms atom13
#print axioms atom14
#print axioms atom15
#print axioms atom16
#print axioms atom17
#print axioms atom18
#print axioms atom19
#print axioms atom20
#print axioms atom21
#print axioms atom22
#print axioms atom23
#print axioms atom24
end T1
namespace T2
def smallValues : Array ℤ := #[0,0,1,0,-1,0,1,1,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1]
def small (n : ℕ) : ℤ := smallValues[n]!
theorem small_rational : ∀ n : Fin 25, coeff n rational=small n := by
  have h : ∀ n : Fin 25, tab n=small n := by decide
  intro n
  rw [prefix_correct n (by omega)]
  exact h n
theorem small_of_denominator (s : PowerSeries ℤ) (h : denominator*s=numerator) : ∀ n : Fin 25, coeff n s=small n := by
  rw [denominator_unique s h]
  exact small_rational
theorem atom0 : coeff 0 rational = (0 : ℤ) := small_rational ⟨0,by decide⟩
theorem atom1 : coeff 1 rational = (0 : ℤ) := small_rational ⟨1,by decide⟩
theorem atom2 : coeff 2 rational = (1 : ℤ) := small_rational ⟨2,by decide⟩
theorem atom3 : coeff 3 rational = (0 : ℤ) := small_rational ⟨3,by decide⟩
theorem atom4 : coeff 4 rational = (-1 : ℤ) := small_rational ⟨4,by decide⟩
theorem atom5 : coeff 5 rational = (0 : ℤ) := small_rational ⟨5,by decide⟩
theorem atom6 : coeff 6 rational = (1 : ℤ) := small_rational ⟨6,by decide⟩
theorem atom7 : coeff 7 rational = (1 : ℤ) := small_rational ⟨7,by decide⟩
theorem atom8 : coeff 8 rational = (0 : ℤ) := small_rational ⟨8,by decide⟩
theorem atom9 : coeff 9 rational = (0 : ℤ) := small_rational ⟨9,by decide⟩
theorem atom10 : coeff 10 rational = (0 : ℤ) := small_rational ⟨10,by decide⟩
theorem atom11 : coeff 11 rational = (0 : ℤ) := small_rational ⟨11,by decide⟩
theorem atom12 : coeff 12 rational = (1 : ℤ) := small_rational ⟨12,by decide⟩
theorem atom13 : coeff 13 rational = (1 : ℤ) := small_rational ⟨13,by decide⟩
theorem atom14 : coeff 14 rational = (1 : ℤ) := small_rational ⟨14,by decide⟩
theorem atom15 : coeff 15 rational = (0 : ℤ) := small_rational ⟨15,by decide⟩
theorem atom16 : coeff 16 rational = (0 : ℤ) := small_rational ⟨16,by decide⟩
theorem atom17 : coeff 17 rational = (1 : ℤ) := small_rational ⟨17,by decide⟩
theorem atom18 : coeff 18 rational = (1 : ℤ) := small_rational ⟨18,by decide⟩
theorem atom19 : coeff 19 rational = (1 : ℤ) := small_rational ⟨19,by decide⟩
theorem atom20 : coeff 20 rational = (1 : ℤ) := small_rational ⟨20,by decide⟩
theorem atom21 : coeff 21 rational = (1 : ℤ) := small_rational ⟨21,by decide⟩
theorem atom22 : coeff 22 rational = (1 : ℤ) := small_rational ⟨22,by decide⟩
theorem atom23 : coeff 23 rational = (1 : ℤ) := small_rational ⟨23,by decide⟩
theorem atom24 : coeff 24 rational = (1 : ℤ) := small_rational ⟨24,by decide⟩
#print axioms smallValues
#print axioms small
#print axioms small_rational
#print axioms small_of_denominator
#print axioms atom0
#print axioms atom1
#print axioms atom2
#print axioms atom3
#print axioms atom4
#print axioms atom5
#print axioms atom6
#print axioms atom7
#print axioms atom8
#print axioms atom9
#print axioms atom10
#print axioms atom11
#print axioms atom12
#print axioms atom13
#print axioms atom14
#print axioms atom15
#print axioms atom16
#print axioms atom17
#print axioms atom18
#print axioms atom19
#print axioms atom20
#print axioms atom21
#print axioms atom22
#print axioms atom23
#print axioms atom24
end T2
namespace T3
def smallValues : Array ℤ := #[0,0,0,1,0,0,0,-1,1,1,1,1,-1,0,0,1,2,1,1,0,0,1,1,2,2]
def small (n : ℕ) : ℤ := smallValues[n]!
theorem small_rational : ∀ n : Fin 25, coeff n rational=small n := by
  have h : ∀ n : Fin 25, tab n=small n := by decide
  intro n
  rw [prefix_correct n (by omega)]
  exact h n
theorem small_of_denominator (s : PowerSeries ℤ) (h : denominator*s=numerator) : ∀ n : Fin 25, coeff n s=small n := by
  rw [denominator_unique s h]
  exact small_rational
theorem atom0 : coeff 0 rational = (0 : ℤ) := small_rational ⟨0,by decide⟩
theorem atom1 : coeff 1 rational = (0 : ℤ) := small_rational ⟨1,by decide⟩
theorem atom2 : coeff 2 rational = (0 : ℤ) := small_rational ⟨2,by decide⟩
theorem atom3 : coeff 3 rational = (1 : ℤ) := small_rational ⟨3,by decide⟩
theorem atom4 : coeff 4 rational = (0 : ℤ) := small_rational ⟨4,by decide⟩
theorem atom5 : coeff 5 rational = (0 : ℤ) := small_rational ⟨5,by decide⟩
theorem atom6 : coeff 6 rational = (0 : ℤ) := small_rational ⟨6,by decide⟩
theorem atom7 : coeff 7 rational = (-1 : ℤ) := small_rational ⟨7,by decide⟩
theorem atom8 : coeff 8 rational = (1 : ℤ) := small_rational ⟨8,by decide⟩
theorem atom9 : coeff 9 rational = (1 : ℤ) := small_rational ⟨9,by decide⟩
theorem atom10 : coeff 10 rational = (1 : ℤ) := small_rational ⟨10,by decide⟩
theorem atom11 : coeff 11 rational = (1 : ℤ) := small_rational ⟨11,by decide⟩
theorem atom12 : coeff 12 rational = (-1 : ℤ) := small_rational ⟨12,by decide⟩
theorem atom13 : coeff 13 rational = (0 : ℤ) := small_rational ⟨13,by decide⟩
theorem atom14 : coeff 14 rational = (0 : ℤ) := small_rational ⟨14,by decide⟩
theorem atom15 : coeff 15 rational = (1 : ℤ) := small_rational ⟨15,by decide⟩
theorem atom16 : coeff 16 rational = (2 : ℤ) := small_rational ⟨16,by decide⟩
theorem atom17 : coeff 17 rational = (1 : ℤ) := small_rational ⟨17,by decide⟩
theorem atom18 : coeff 18 rational = (1 : ℤ) := small_rational ⟨18,by decide⟩
theorem atom19 : coeff 19 rational = (0 : ℤ) := small_rational ⟨19,by decide⟩
theorem atom20 : coeff 20 rational = (0 : ℤ) := small_rational ⟨20,by decide⟩
theorem atom21 : coeff 21 rational = (1 : ℤ) := small_rational ⟨21,by decide⟩
theorem atom22 : coeff 22 rational = (1 : ℤ) := small_rational ⟨22,by decide⟩
theorem atom23 : coeff 23 rational = (2 : ℤ) := small_rational ⟨23,by decide⟩
theorem atom24 : coeff 24 rational = (2 : ℤ) := small_rational ⟨24,by decide⟩
theorem atom16_two_colors : 2≤coeff 16 rational := le_of_eq atom16.symm
#print axioms smallValues
#print axioms small
#print axioms small_rational
#print axioms small_of_denominator
#print axioms atom0
#print axioms atom1
#print axioms atom2
#print axioms atom3
#print axioms atom4
#print axioms atom5
#print axioms atom6
#print axioms atom7
#print axioms atom8
#print axioms atom9
#print axioms atom10
#print axioms atom11
#print axioms atom12
#print axioms atom13
#print axioms atom14
#print axioms atom15
#print axioms atom16
#print axioms atom17
#print axioms atom18
#print axioms atom19
#print axioms atom20
#print axioms atom21
#print axioms atom22
#print axioms atom23
#print axioms atom24
#print axioms atom16_two_colors
end T3
namespace T4
def smallValues : Array ℤ := #[0,0,0,0,1,0,0,1,-1,0,1,0,1,1,1,0,0,1,0,1,2,1,1,1,1]
def small (n : ℕ) : ℤ := smallValues[n]!
theorem small_rational : ∀ n : Fin 25, coeff n rational=small n := by
  have h : ∀ n : Fin 25, tab n=small n := by decide
  intro n
  rw [prefix_correct n (by omega)]
  exact h n
theorem small_of_denominator (s : PowerSeries ℤ) (h : denominator*s=numerator) : ∀ n : Fin 25, coeff n s=small n := by
  rw [denominator_unique s h]
  exact small_rational
theorem atom0 : coeff 0 rational = (0 : ℤ) := small_rational ⟨0,by decide⟩
theorem atom1 : coeff 1 rational = (0 : ℤ) := small_rational ⟨1,by decide⟩
theorem atom2 : coeff 2 rational = (0 : ℤ) := small_rational ⟨2,by decide⟩
theorem atom3 : coeff 3 rational = (0 : ℤ) := small_rational ⟨3,by decide⟩
theorem atom4 : coeff 4 rational = (1 : ℤ) := small_rational ⟨4,by decide⟩
theorem atom5 : coeff 5 rational = (0 : ℤ) := small_rational ⟨5,by decide⟩
theorem atom6 : coeff 6 rational = (0 : ℤ) := small_rational ⟨6,by decide⟩
theorem atom7 : coeff 7 rational = (1 : ℤ) := small_rational ⟨7,by decide⟩
theorem atom8 : coeff 8 rational = (-1 : ℤ) := small_rational ⟨8,by decide⟩
theorem atom9 : coeff 9 rational = (0 : ℤ) := small_rational ⟨9,by decide⟩
theorem atom10 : coeff 10 rational = (1 : ℤ) := small_rational ⟨10,by decide⟩
theorem atom11 : coeff 11 rational = (0 : ℤ) := small_rational ⟨11,by decide⟩
theorem atom12 : coeff 12 rational = (1 : ℤ) := small_rational ⟨12,by decide⟩
theorem atom13 : coeff 13 rational = (1 : ℤ) := small_rational ⟨13,by decide⟩
theorem atom14 : coeff 14 rational = (1 : ℤ) := small_rational ⟨14,by decide⟩
theorem atom15 : coeff 15 rational = (0 : ℤ) := small_rational ⟨15,by decide⟩
theorem atom16 : coeff 16 rational = (0 : ℤ) := small_rational ⟨16,by decide⟩
theorem atom17 : coeff 17 rational = (1 : ℤ) := small_rational ⟨17,by decide⟩
theorem atom18 : coeff 18 rational = (0 : ℤ) := small_rational ⟨18,by decide⟩
theorem atom19 : coeff 19 rational = (1 : ℤ) := small_rational ⟨19,by decide⟩
theorem atom20 : coeff 20 rational = (2 : ℤ) := small_rational ⟨20,by decide⟩
theorem atom21 : coeff 21 rational = (1 : ℤ) := small_rational ⟨21,by decide⟩
theorem atom22 : coeff 22 rational = (1 : ℤ) := small_rational ⟨22,by decide⟩
theorem atom23 : coeff 23 rational = (1 : ℤ) := small_rational ⟨23,by decide⟩
theorem atom24 : coeff 24 rational = (1 : ℤ) := small_rational ⟨24,by decide⟩
#print axioms smallValues
#print axioms small
#print axioms small_rational
#print axioms small_of_denominator
#print axioms atom0
#print axioms atom1
#print axioms atom2
#print axioms atom3
#print axioms atom4
#print axioms atom5
#print axioms atom6
#print axioms atom7
#print axioms atom8
#print axioms atom9
#print axioms atom10
#print axioms atom11
#print axioms atom12
#print axioms atom13
#print axioms atom14
#print axioms atom15
#print axioms atom16
#print axioms atom17
#print axioms atom18
#print axioms atom19
#print axioms atom20
#print axioms atom21
#print axioms atom22
#print axioms atom23
#print axioms atom24
end T4
