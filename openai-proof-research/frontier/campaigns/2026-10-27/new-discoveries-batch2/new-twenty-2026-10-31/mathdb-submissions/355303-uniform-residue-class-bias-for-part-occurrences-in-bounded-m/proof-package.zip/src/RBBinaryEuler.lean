import RBBinarySeries
noncomputable section
namespace RBBinary
open Finset PowerSeries
local notation "𝔛" => (X : PowerSeries ℤ)
def d (h : ℕ) : PowerSeries ℤ := 1-𝔛^h
def oddDen (N : ℕ) : PowerSeries ℤ := ∏ h ∈ Icc 1 N, if h%2=1 then d h else 1
def evenDen (N : ℕ) : PowerSeries ℤ := ∏ h ∈ Icc 1 N, if h%2=0 then d h else 1
def evenInv (N : ℕ) : PowerSeries ℤ := ∏ h ∈ Icc 1 N, if h%2=0 then RBCount.gI h else 1

theorem even_inverse (N : ℕ) : evenDen N * evenInv N = 1 := by
  unfold evenDen evenInv
  rw [← prod_mul_distrib]
  apply prod_eq_one
  intro h hh
  by_cases he : h%2=0
  · simp only [ite_eq_left he]
    exact RBCount.one_sub_mul_gI (mem_Icc.mp hh).1
  · simp [he]

theorem denominator_split (N : ℕ) :
    (∏ h ∈ Icc 1 N, d h) = oddDen N * evenDen N := by
  unfold oddDen evenDen
  rw [← prod_mul_distrib]
  apply prod_congr rfl
  intro h hh
  have hm : h%2=0 ∨ h%2=1 := by omega
  rcases hm with hm | hm <;> simp [hm]

theorem doubled_low (N : ℕ) :
    (∏ h ∈ (Icc 1 N).filter (fun h => 2*h ≤ N), d (2*h)) = evenDen N := by
  classical
  have hs : ((Icc 1 N).filter (fun h => 2*h ≤ N)).image (fun h => 2*h) =
      (Icc 1 N).filter (fun h => h%2=0) := by
    ext m
    simp only [mem_image, mem_filter, mem_Icc]
    constructor
    · rintro ⟨h, ⟨⟨hh,hn⟩,hm⟩,rfl⟩
      omega
    · rintro ⟨⟨hm,hn⟩,he⟩
      refine ⟨m/2, ?_, ?_⟩ <;> omega
  have hi : Function.Injective (fun h : ℕ => 2*h) := by intro a b h; change 2*a=2*b at h; omega
  rw [← Finset.prod_image (fun a _ b _ h => hi h), hs]
  simp only [prod_filter, evenDen]

theorem euler_cleared (N : ℕ) :
    Agree N (RBCount.prodB 2 N * oddDen N) 1 := by
  classical
  have hq : Agree N (∏ h ∈ Icc 1 N, d (2*h)) (evenDen N) := by
    rw [← doubled_low N, prod_filter]
    apply agree_prod
    intro h hh n hn
    by_cases he : 2*h ≤ N
    · simp [he]
    · simp only [ite_eq_right he, d, map_sub, coeff_one, coeff_X_pow]
      have hh' : 2*h ≠ n := by omega
      simp [Ne.symm hh']
  have halg : RBCount.prodB 2 N * (∏ h ∈ Icc 1 N, d h) =
      ∏ h ∈ Icc 1 N, d (2*h) := by
    unfold RBCount.prodB
    rw [← prod_mul_distrib]
    apply prod_congr rfl
    intro h hh
    rw [mul_comm]
    simpa [d, mul_comm] using RBCount.one_sub_mul_Bf 2 h
  rw [denominator_split] at halg
  have ht : Agree N ((RBCount.prodB 2 N * oddDen N)*evenDen N) (evenDen N) := by
    rw [mul_assoc, halg]
    exact hq
  have h := agree_mul ht (show Agree N (evenInv N) (evenInv N) from fun _ _ => rfl)
  simpa only [mul_assoc, even_inverse, mul_one] using h

#print axioms euler_cleared
end RBBinary
