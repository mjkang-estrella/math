import T4Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T4
theorem rec8_0 : ∀ n : Fin 15, tab (n.val+3360)=step tab (n.val+3360) := by decide
theorem rec8_1 : ∀ n : Fin 15, tab (n.val+3375)=step tab (n.val+3375) := by decide
theorem rec8_2 : ∀ n : Fin 15, tab (n.val+3390)=step tab (n.val+3390) := by decide
theorem rec8_3 : ∀ n : Fin 15, tab (n.val+3405)=step tab (n.val+3405) := by decide
theorem rec8_4 : ∀ n : Fin 15, tab (n.val+3420)=step tab (n.val+3420) := by decide
theorem rec8_5 : ∀ n : Fin 15, tab (n.val+3435)=step tab (n.val+3435) := by decide
theorem rec8_6 : ∀ n : Fin 15, tab (n.val+3450)=step tab (n.val+3450) := by decide
theorem rec8_7 : ∀ n : Fin 15, tab (n.val+3465)=step tab (n.val+3465) := by decide
theorem rec8_8 : ∀ n : Fin 15, tab (n.val+3480)=step tab (n.val+3480) := by decide
theorem rec8_9 : ∀ n : Fin 15, tab (n.val+3495)=step tab (n.val+3495) := by decide
theorem rec8_10 : ∀ n : Fin 15, tab (n.val+3510)=step tab (n.val+3510) := by decide
theorem rec8_11 : ∀ n : Fin 15, tab (n.val+3525)=step tab (n.val+3525) := by decide
theorem rec8_12 : ∀ n : Fin 15, tab (n.val+3540)=step tab (n.val+3540) := by decide
theorem rec8_13 : ∀ n : Fin 15, tab (n.val+3555)=step tab (n.val+3555) := by decide
theorem rec8_14 : ∀ n : Fin 15, tab (n.val+3570)=step tab (n.val+3570) := by decide
theorem rec8_15 : ∀ n : Fin 15, tab (n.val+3585)=step tab (n.val+3585) := by decide
theorem rec8_16 : ∀ n : Fin 15, tab (n.val+3600)=step tab (n.val+3600) := by decide
theorem rec8_17 : ∀ n : Fin 15, tab (n.val+3615)=step tab (n.val+3615) := by decide
theorem rec8_18 : ∀ n : Fin 15, tab (n.val+3630)=step tab (n.val+3630) := by decide
theorem rec8_19 : ∀ n : Fin 15, tab (n.val+3645)=step tab (n.val+3645) := by decide
theorem rec8_20 : ∀ n : Fin 15, tab (n.val+3660)=step tab (n.val+3660) := by decide
theorem rec8_21 : ∀ n : Fin 15, tab (n.val+3675)=step tab (n.val+3675) := by decide
theorem rec8_22 : ∀ n : Fin 15, tab (n.val+3690)=step tab (n.val+3690) := by decide
theorem rec8_23 : ∀ n : Fin 15, tab (n.val+3705)=step tab (n.val+3705) := by decide
theorem rec8_24 : ∀ n : Fin 15, tab (n.val+3720)=step tab (n.val+3720) := by decide
theorem rec8_25 : ∀ n : Fin 15, tab (n.val+3735)=step tab (n.val+3735) := by decide
theorem rec8_26 : ∀ n : Fin 15, tab (n.val+3750)=step tab (n.val+3750) := by decide
theorem rec8_27 : ∀ n : Fin 15, tab (n.val+3765)=step tab (n.val+3765) := by decide
theorem rec8 : ∀ n : Fin 420, tab (n.val+3360)=step tab (n.val+3360) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec8_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+3360=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec8_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+3375=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec8_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+3390=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec8_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+3405=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec8_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+3420=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec8_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+3435=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec8_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+3450=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec8_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+3465=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec8_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+3480=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec8_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+3495=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec8_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+3510=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec8_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+3525=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec8_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+3540=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec8_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+3555=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec8_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+3570=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec8_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+3585=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec8_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+3600=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec8_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+3615=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec8_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+3630=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec8_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+3645=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec8_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+3660=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec8_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+3675=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec8_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+3690=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec8_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+3705=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec8_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+3720=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec8_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+3735=n.val+3360 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec8_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+3750=n.val+3360 := by omega
    simpa only [he] using h
  have h := rec8_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+3765=n.val+3360 := by omega
  simpa only [he] using h
theorem rows8 : ∀ r : Fin 60,
  0 ≤ tab (r.val+480+2520) ∧
  0 ≤ tab (r.val+480+3360)-tab (r.val+480+2520) ∧
  0 ≤ tab (r.val+480+4200)-2*tab (r.val+480+3360)+tab (r.val+480+2520) ∧
  0 ≤ tab (r.val+480+5040)-3*tab (r.val+480+4200)+3*tab (r.val+480+3360)-tab (r.val+480+2520) := by decide

#print axioms rec8
#print axioms rows8
end T4
