import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Linarith

namespace T1

def newton (a b c d : ℤ) (u : ℕ) : ℤ :=
  a + (u.choose 1 : ℤ)*b + (u.choose 2 : ℤ)*c + (u.choose 3 : ℤ)*d

theorem newton_zero (a b c d : ℤ) : newton a b c d 0 = a := by simp [newton]

theorem newton_step (a b c d : ℤ) (u : ℕ) :
    newton a b c d (u+1) = newton (a+b) (b+c) (c+d) d u := by
  simp only [newton, Nat.choose_succ_succ, Nat.choose_zero_right, Nat.cast_add,
    Nat.cast_one]
  ring

theorem newton_nonneg (a b c d : ℤ) (ha : 0≤a) (hb : 0≤b)
    (hc : 0≤c) (hd : 0≤d) (u : ℕ) : 0 ≤ newton a b c d u := by
  unfold newton
  positivity

-- All four coordinates are advanced by Pascal, retaining multiplicities.
theorem jet_formula (A B C E : ℕ → ℤ)
    (hA : ∀ u, A (u+1)=A u+B u)
    (hB : ∀ u, B (u+1)=B u+C u)
    (hC : ∀ u, C (u+1)=C u+E u)
    (hE : ∀ u, E (u+1)=E u) :
    ∀ u, A u=newton (A 0) (B 0) (C 0) (E 0) u := by
  have hall : ∀ u,
      A u=newton (A 0) (B 0) (C 0) (E 0) u ∧
      B u=newton (B 0) (C 0) (E 0) 0 u ∧
      C u=newton (C 0) (E 0) 0 0 u ∧ E u=E 0 := by
    intro u
    induction u with
    | zero => simp [newton]
    | succ u ih =>
      rcases ih with ⟨ia,ib,ic,ie⟩
      rw [hA,hB,hC,hE,ia,ib,ic,ie]
      rw [newton_step,newton_step,newton_step]
      simp only [newton]
      constructor
      · ring
      constructor
      · ring
      constructor
      · ring
      · exact True.intro
  exact fun u => (hall u).1

#print axioms newton
#print axioms newton_zero
#print axioms newton_step
#print axioms newton_nonneg
#print axioms jet_formula
end T1
