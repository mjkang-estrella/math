import Mathlib.RingTheory.PowerSeries.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum

namespace T2
open scoped BigOperators

def geom {R : Type*} [CommRing R] (x : R) (n : ℕ) : R := ∑ i ∈ Finset.range n, x ^ i

theorem geometric {R : Type*} [CommRing R] (x : R) (n : ℕ) :
    (1-x)*geom x n = 1-x^n := by
  induction n with
  | zero => simp [geom]
  | succ n ih =>
    simp only [geom, Finset.sum_range_succ] at *
    rw [mul_add, ih, pow_succ]
    ring

def G {R : Type*} [CommRing R] (x : R) (d : ℕ) : R := geom (x^d) (420/d)
def D {R : Type*} [CommRing R] (x : R) : R := (1-x^4)*(1-x^6)*(1-x^5)*(1-x^7)
def Z {R : Type*} [CommRing R] (x : R) : R := x^2*(1-x^2)*G x 4*G x 6*G x 5*G x 7

theorem factor {R : Type*} [CommRing R] (x : R) (d : ℕ)
    (hd : d*(420/d)=420) : (1-x^d)*G x d=1-x^420 := by
  simpa only [G, ← pow_mul, hd] using geometric (x^d) (420/d)

theorem finite_identity {R : Type*} [CommRing R] (x : R) :
    D x * Z x = x^2*(1-x^2)*(1-x^420)^4 := by
  have h4 := factor x 4 (by decide)
  have h6 := factor x 6 (by decide)
  have h5 := factor x 5 (by decide)
  have h7 := factor x 7 (by decide)
  calc
    D x * Z x = x^2*(1-x^2)*((1-x^4)*G x 4)*((1-x^6)*G x 6)*((1-x^5)*G x 5)*((1-x^7)*G x 7) := by unfold D Z; ring
    _ = x^2*(1-x^2)*(1-x^420)^4 := by rw [h4,h6,h5,h7]; ring

#print axioms geom
#print axioms geometric
#print axioms G
#print axioms D
#print axioms Z
#print axioms factor
#print axioms finite_identity
end T2
