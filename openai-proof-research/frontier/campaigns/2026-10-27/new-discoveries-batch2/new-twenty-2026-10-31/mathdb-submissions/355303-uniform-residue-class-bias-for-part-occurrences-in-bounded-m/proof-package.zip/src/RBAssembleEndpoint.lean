import RBAssembleCoeff
import RBAssembleRequired
import RBBinaryEndpoints

/-!
# RBAssembleEndpoint (355303, formal-opus-r4-restart1): one-premise conditional assembly

`FinitePrefixPolynomial` is the SINGLE remaining premise, stated over the ORIGINAL finite polynomials
`RBPrefix.actualMarked` and the ORIGINAL predicate `RBPrefix.Required` (not `cutBox`, not external data).
Proved here:
* `FinitePrefixPolynomial ↔ RBStrict.FinitePrefixNative` (via the coefficient and Required bridges);
* `RBStrict.LowBinaryNative` from the paid closed `RBBinary.lowBinaryNative_holds` (same literal predicate);
* `FinitePrefixPolynomial → RBCount.AdjStrict` and `→ RBCount.NativeEndpoint` (UNCHANGED paid definitions),
  also in fully expanded form; and conversely `RBCount.AdjStrict → FinitePrefixPolynomial`.
`FinitePrefixPolynomial` itself is NOT proved or evaluated here.
-/

namespace RBAssemble

/-- The ONE finite polynomial table premise (exact original polynomials and `Required`). -/
def FinitePrefixPolynomial : Prop :=
  ∀ k a n : ℕ, RBPrefix.Required k a n →
    (RBPrefix.actualMarked k (a + 1)).coeff n < (RBPrefix.actualMarked k a).coeff n

theorem finitePrefixNative_of_polynomial (hP : FinitePrefixPolynomial) :
    RBStrict.FinitePrefixNative := by
  intro k a n hk hk' ha ha' h2 h3 hn hE hN
  have r : RBPrefix.Required k a n := required_iff.mpr ⟨hk, hk', ha, ha', h2, h3, hn, hE, hN⟩
  obtain ⟨b1, b2⟩ := RBPrefix.required_bounds r
  have hc := hP k a n r
  rw [coeff_actualMarked (k := k) (a := a + 1) (n := n) (by omega) (by omega) (by omega) (by omega),
    coeff_actualMarked (k := k) (a := a) (n := n) (by omega) (by omega) (by omega) (by omega)] at hc
  exact_mod_cast hc

theorem polynomial_of_finitePrefixNative (hF : RBStrict.FinitePrefixNative) :
    FinitePrefixPolynomial := by
  intro k a n r
  obtain ⟨hk, hk', ha, ha', h2, h3, hn, hE, hN⟩ := required_iff.mp r
  obtain ⟨b1, b2⟩ := RBPrefix.required_bounds r
  have hc := hF k a n hk hk' ha ha' h2 h3 hn hE hN
  rw [coeff_actualMarked (k := k) (a := a + 1) (n := n) (by omega) (by omega) (by omega) (by omega),
    coeff_actualMarked (k := k) (a := a) (n := n) (by omega) (by omega) (by omega) (by omega)]
  exact_mod_cast hc

/-- Proved equivalence of the polynomial premise and the native finite premise. -/
theorem finitePrefixPolynomial_iff : FinitePrefixPolynomial ↔ RBStrict.FinitePrefixNative :=
  ⟨finitePrefixNative_of_polynomial, polynomial_of_finitePrefixNative⟩

/-- Adapter only (NOT evaluated here): the paid Boolean table check would discharge the premise. -/
theorem finitePrefixPolynomial_of_cutBox (h : RBPrefix.cutBox 2 144 = true) :
    FinitePrefixPolynomial :=
  RBPrefix.finite_product_endpoint h

/-- The two low-binary predicates are the same literal term over the same `RBCount.C`. -/
theorem lowBinary_def_eq : RBStrict.LowBinaryNative = RBBinary.LowBinaryNative := rfl

/-- Closed low-binary premise, instantiated from the paid unconditional theorem. -/
theorem lowBinaryNative : RBStrict.LowBinaryNative := RBBinary.lowBinaryNative_holds

theorem adjStrict_of_finitePrefixPolynomial (hP : FinitePrefixPolynomial) : RBCount.AdjStrict :=
  RBStrict.adjStrict_of_premises lowBinaryNative (finitePrefixNative_of_polynomial hP)

theorem nativeEndpoint_of_finitePrefixPolynomial (hP : FinitePrefixPolynomial) :
    RBCount.NativeEndpoint :=
  RBStrict.nativeEndpoint_of_premises lowBinaryNative (finitePrefixNative_of_polynomial hP)

/-- Converse: the premise is no stronger than the unchanged `AdjStrict`. -/
theorem finitePrefixPolynomial_of_adjStrict (h : RBCount.AdjStrict) : FinitePrefixPolynomial := by
  apply polynomial_of_finitePrefixNative
  intro k a n hk hk' ha ha' h2 h3 hn hE hN
  have h5 : a + 5 ≤ n := le_trans (le_max_left (a + 5) 17) hn
  have h17 : 17 ≤ n := le_trans (le_max_right (a + 5) 17) hn
  exact h k a n hk (by omega) (max_lt (by omega) (by omega))

theorem finitePrefixPolynomial_iff_adjStrict : FinitePrefixPolynomial ↔ RBCount.AdjStrict :=
  ⟨adjStrict_of_finitePrefixPolynomial, finitePrefixPolynomial_of_adjStrict⟩

/-- Expanded conditional strict adjacency (unchanged `RBCount.C`). -/
theorem adjStrict_expanded
    (hP : ∀ k a n : ℕ, RBPrefix.Required k a n →
      (RBPrefix.actualMarked k (a + 1)).coeff n < (RBPrefix.actualMarked k a).coeff n) :
    ∀ k a n : ℕ, 2 ≤ k → 1 ≤ a → max (a + 4) 16 < n → RBCount.C k (a + 1) n < RBCount.C k a n :=
  adjStrict_of_finitePrefixPolynomial hP

/-- Expanded conditional native endpoint: full original weak and strict quantifiers, ONE premise. -/
theorem nativeEndpoint_expanded
    (hP : ∀ k a n : ℕ, RBPrefix.Required k a n →
      (RBPrefix.actualMarked k (a + 1)).coeff n < (RBPrefix.actualMarked k a).coeff n) :
    (∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
        RBCount.D k s t n ≤ RBCount.D k r t n) ∧
    (∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
        RBCount.D k s t n < RBCount.D k r t n) :=
  nativeEndpoint_of_finitePrefixPolynomial hP

set_option maxRecDepth 100000 in
/-- Same, with `Required` and `actualMarked` literally unfolded in the premise. -/
theorem nativeEndpoint_literal
    (hP : ∀ k a n : ℕ,
      (2 ≤ k ∧ k ≤ 143 ∧ 2 ≤ a ∧ a ≤ 23 ∧ (k = 2 → 5 ≤ a) ∧
        ¬ (k = 3 ∧ RBPrefix.exceptional k a = true) ∧ max (a + 5) 17 ≤ n ∧
        n ≤ a + (if RBPrefix.exceptional k a then 23 else 119)) →
      (∏ h ∈ Finset.range 142, ∑ j ∈ Finset.range k,
          Polynomial.C (if h + 1 == a + 1 then (j : ℤ) else 1) * Polynomial.X ^ (j * (h + 1))).coeff n <
        (∏ h ∈ Finset.range 142, ∑ j ∈ Finset.range k,
          Polynomial.C (if h + 1 == a then (j : ℤ) else 1) * Polynomial.X ^ (j * (h + 1))).coeff n) :
    (∀ k t r s n : ℕ, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n →
        RBCount.D k s t n ≤ RBCount.D k r t n) ∧
    (∀ k t r s n : ℕ, 2 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → max (t + 3) 16 < n →
        RBCount.D k s t n < RBCount.D k r t n) :=
  nativeEndpoint_of_finitePrefixPolynomial hP

end RBAssemble

#print RBAssemble.FinitePrefixPolynomial
#print axioms RBAssemble.finitePrefixNative_of_polynomial
#print axioms RBAssemble.polynomial_of_finitePrefixNative
#print axioms RBAssemble.finitePrefixPolynomial_iff
#print axioms RBAssemble.finitePrefixPolynomial_of_cutBox
#print axioms RBAssemble.lowBinary_def_eq
#print axioms RBAssemble.lowBinaryNative
#print axioms RBAssemble.adjStrict_of_finitePrefixPolynomial
#print axioms RBAssemble.nativeEndpoint_of_finitePrefixPolynomial
#print axioms RBAssemble.finitePrefixPolynomial_of_adjStrict
#print axioms RBAssemble.finitePrefixPolynomial_iff_adjStrict
#print axioms RBAssemble.adjStrict_expanded
#print axioms RBAssemble.nativeEndpoint_expanded
#print axioms RBAssemble.nativeEndpoint_literal
