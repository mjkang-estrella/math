import T2Check0
import T2Check1
import T2Check2
import T2Check3
import T2Check4
import T2Check5
import T2Check6
namespace T2
theorem tab_recurrence : ∀ n : Fin 2940, tab n = step tab n := by
  intro n
  by_cases h0 : n.val < 420
  · have he : n.val-0+0=n.val := by omega
    have h := rec0 ⟨n.val-0,by omega⟩
    simpa only [he] using h
  by_cases h1 : n.val < 840
  · have he : n.val-420+420=n.val := by omega
    have h := rec1 ⟨n.val-420,by omega⟩
    simpa only [he] using h
  by_cases h2 : n.val < 1260
  · have he : n.val-840+840=n.val := by omega
    have h := rec2 ⟨n.val-840,by omega⟩
    simpa only [he] using h
  by_cases h3 : n.val < 1680
  · have he : n.val-1260+1260=n.val := by omega
    have h := rec3 ⟨n.val-1260,by omega⟩
    simpa only [he] using h
  by_cases h4 : n.val < 2100
  · have he : n.val-1680+1680=n.val := by omega
    have h := rec4 ⟨n.val-1680,by omega⟩
    simpa only [he] using h
  by_cases h5 : n.val < 2520
  · have he : n.val-2100+2100=n.val := by omega
    have h := rec5 ⟨n.val-2100,by omega⟩
    simpa only [he] using h
  have he : n.val-2520+2520=n.val := by omega
  have h := rec6 ⟨n.val-2520,by omega⟩
  simpa only [he] using h
theorem tab_prefix : ∀ n : Fin 1260, n.val≠4 → 0≤tab n := by
  intro n hn4
  by_cases h0 : n.val < 420
  · have he : n.val-0+0=n.val := by omega
    have h := pref0 ⟨n.val-0,by omega⟩ (by simpa only [he] using hn4)
    simpa only [he] using h
  by_cases h1 : n.val < 840
  · have he : n.val-420+420=n.val := by omega
    have h := pref1 ⟨n.val-420,by omega⟩ (by simpa only [he] using hn4)
    simpa only [he] using h
  have he : n.val-840+840=n.val := by omega
  have h := pref2 ⟨n.val-840,by omega⟩ (by simpa only [he] using hn4)
  simpa only [he] using h
theorem tab_rows : ∀ r : Fin 420, 0 ≤ tab (r+1260) ∧ 0 ≤ tab (r+1680)-tab (r+1260) ∧ 0 ≤ tab (r+2100)-2*tab (r+1680)+tab (r+1260) ∧ 0 ≤ tab (r+2520)-3*tab (r+2100)+3*tab (r+1680)-tab (r+1260) := by
  intro r
  by_cases h0 : r.val < 60
  · have he : r.val-0+0=r.val := by omega
    have h := rows0 ⟨r.val-0,by omega⟩
    simpa only [he] using h
  by_cases h1 : r.val < 120
  · have he : r.val-60+60=r.val := by omega
    have h := rows1 ⟨r.val-60,by omega⟩
    simpa only [he] using h
  by_cases h2 : r.val < 180
  · have he : r.val-120+120=r.val := by omega
    have h := rows2 ⟨r.val-120,by omega⟩
    simpa only [he] using h
  by_cases h3 : r.val < 240
  · have he : r.val-180+180=r.val := by omega
    have h := rows3 ⟨r.val-180,by omega⟩
    simpa only [he] using h
  by_cases h4 : r.val < 300
  · have he : r.val-240+240=r.val := by omega
    have h := rows4 ⟨r.val-240,by omega⟩
    simpa only [he] using h
  by_cases h5 : r.val < 360
  · have he : r.val-300+300=r.val := by omega
    have h := rows5 ⟨r.val-300,by omega⟩
    simpa only [he] using h
  have he : r.val-360+360=r.val := by omega
  have h := rows6 ⟨r.val-360,by omega⟩
  simpa only [he] using h
theorem tab_negative4 : tab 4=-1 := by decide

#print axioms tab_recurrence
#print axioms tab_prefix
#print axioms tab_rows
#print axioms tab_negative4
end T2
