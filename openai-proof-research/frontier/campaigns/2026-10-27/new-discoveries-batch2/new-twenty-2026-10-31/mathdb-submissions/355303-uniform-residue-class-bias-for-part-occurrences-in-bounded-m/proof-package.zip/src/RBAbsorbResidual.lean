import Mathlib.Combinatorics.Enumerative.Partition.Basic
import Mathlib.RingTheory.PowerSeries.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.IntervalCases
import Mathlib.Tactic.SplitIfs
noncomputable section
namespace RBAbsorb
open PowerSeries

def Residual (n : ℕ) := {p : Nat.Partition n // ∀ w ∈ p.parts, w % 2 = 1 ∧ 9 ≤ w}
instance (n : ℕ) : Fintype (Residual n) := by
  classical
  unfold Residual
  infer_instance
def count (n : ℕ) : ℕ := Fintype.card (Residual n)
def R : PowerSeries ℤ := PowerSeries.mk fun n => (count n : ℤ)
@[simp] theorem coeff_R (n : ℕ) : coeff n R = (count n : ℤ) := by simp [R]
theorem count_nonneg (n : ℕ) : (0 : ℤ) ≤ count n := Int.natCast_nonneg _

def empty : Residual 0 := ⟨⟨0, by simp, by simp⟩, by simp⟩
def singleton (n : ℕ) (ho : n % 2 = 1) (hn : 9 ≤ n) : Residual n :=
  ⟨⟨{n}, by simpa using (show 0 < n by omega), by simp⟩, by simpa using And.intro ho hn⟩
def pair (n : ℕ) (he : n % 2 = 0) (hn : 18 ≤ n) : Residual n := by
  refine ⟨{ parts := 9 ::ₘ (n-9) ::ₘ 0, parts_pos := ?_, parts_sum := ?_ }, ?_⟩
  · intro i hi
    simp only [Multiset.mem_cons, Multiset.notMem_zero, or_false] at hi
    rcases hi with rfl | rfl <;> omega
  · simp only [Multiset.sum_cons, Multiset.sum_zero]; omega
  · intro w hw
    simp only [Multiset.mem_cons, Multiset.notMem_zero, or_false] at hw
    rcases hw with rfl | rfl <;> omega
theorem support_zero : 0 < coeff 0 R := by
  rw [coeff_R]; exact_mod_cast (Fintype.card_pos_iff.mpr ⟨empty⟩)
theorem support_odd (n : ℕ) (ho : n % 2 = 1) (hn : 9 ≤ n) : 0 < coeff n R := by
  rw [coeff_R]; exact_mod_cast (Fintype.card_pos_iff.mpr ⟨singleton n ho hn⟩)
theorem support_even (n : ℕ) (he : n % 2 = 0) (hn : 18 ≤ n) : 0 < coeff n R := by
  rw [coeff_R]; exact_mod_cast (Fintype.card_pos_iff.mpr ⟨pair n he hn⟩)

theorem convolution (T : PowerSeries ℤ) (n : ℕ) :
    coeff n (T * R) = ∑ p ∈ Finset.antidiagonal n, coeff p.1 T * (count p.2 : ℤ) := by
  simpa only [coeff_R] using PowerSeries.coeff_mul n T R
#print axioms convolution
#print axioms support_odd
#print axioms support_even
end RBAbsorb
