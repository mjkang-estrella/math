import T3Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T3
theorem rec9_0 : ∀ n : Fin 15, tab (n.val+3780)=step tab (n.val+3780) := by decide
theorem rec9_1 : ∀ n : Fin 15, tab (n.val+3795)=step tab (n.val+3795) := by decide
theorem rec9_2 : ∀ n : Fin 15, tab (n.val+3810)=step tab (n.val+3810) := by decide
theorem rec9_3 : ∀ n : Fin 15, tab (n.val+3825)=step tab (n.val+3825) := by decide
theorem rec9_4 : ∀ n : Fin 15, tab (n.val+3840)=step tab (n.val+3840) := by decide
theorem rec9_5 : ∀ n : Fin 15, tab (n.val+3855)=step tab (n.val+3855) := by decide
theorem rec9_6 : ∀ n : Fin 15, tab (n.val+3870)=step tab (n.val+3870) := by decide
theorem rec9_7 : ∀ n : Fin 15, tab (n.val+3885)=step tab (n.val+3885) := by decide
theorem rec9_8 : ∀ n : Fin 15, tab (n.val+3900)=step tab (n.val+3900) := by decide
theorem rec9_9 : ∀ n : Fin 15, tab (n.val+3915)=step tab (n.val+3915) := by decide
theorem rec9_10 : ∀ n : Fin 15, tab (n.val+3930)=step tab (n.val+3930) := by decide
theorem rec9_11 : ∀ n : Fin 15, tab (n.val+3945)=step tab (n.val+3945) := by decide
theorem rec9_12 : ∀ n : Fin 15, tab (n.val+3960)=step tab (n.val+3960) := by decide
theorem rec9_13 : ∀ n : Fin 15, tab (n.val+3975)=step tab (n.val+3975) := by decide
theorem rec9_14 : ∀ n : Fin 15, tab (n.val+3990)=step tab (n.val+3990) := by decide
theorem rec9_15 : ∀ n : Fin 15, tab (n.val+4005)=step tab (n.val+4005) := by decide
theorem rec9_16 : ∀ n : Fin 15, tab (n.val+4020)=step tab (n.val+4020) := by decide
theorem rec9_17 : ∀ n : Fin 15, tab (n.val+4035)=step tab (n.val+4035) := by decide
theorem rec9_18 : ∀ n : Fin 15, tab (n.val+4050)=step tab (n.val+4050) := by decide
theorem rec9_19 : ∀ n : Fin 15, tab (n.val+4065)=step tab (n.val+4065) := by decide
theorem rec9_20 : ∀ n : Fin 15, tab (n.val+4080)=step tab (n.val+4080) := by decide
theorem rec9_21 : ∀ n : Fin 15, tab (n.val+4095)=step tab (n.val+4095) := by decide
theorem rec9_22 : ∀ n : Fin 15, tab (n.val+4110)=step tab (n.val+4110) := by decide
theorem rec9_23 : ∀ n : Fin 15, tab (n.val+4125)=step tab (n.val+4125) := by decide
theorem rec9_24 : ∀ n : Fin 15, tab (n.val+4140)=step tab (n.val+4140) := by decide
theorem rec9_25 : ∀ n : Fin 15, tab (n.val+4155)=step tab (n.val+4155) := by decide
theorem rec9_26 : ∀ n : Fin 15, tab (n.val+4170)=step tab (n.val+4170) := by decide
theorem rec9_27 : ∀ n : Fin 15, tab (n.val+4185)=step tab (n.val+4185) := by decide
theorem rec9 : ∀ n : Fin 420, tab (n.val+3780)=step tab (n.val+3780) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec9_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+3780=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec9_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+3795=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec9_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+3810=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec9_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+3825=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec9_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+3840=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec9_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+3855=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec9_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+3870=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec9_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+3885=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec9_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+3900=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec9_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+3915=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec9_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+3930=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec9_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+3945=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec9_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+3960=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec9_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+3975=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec9_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+3990=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec9_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+4005=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec9_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+4020=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec9_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+4035=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec9_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+4050=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec9_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+4065=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec9_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+4080=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec9_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+4095=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec9_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+4110=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec9_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+4125=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec9_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+4140=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec9_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+4155=n.val+3780 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec9_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+4170=n.val+3780 := by omega
    simpa only [he] using h
  have h := rec9_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+4185=n.val+3780 := by omega
  simpa only [he] using h
theorem rows9 : ∀ r : Fin 60,
  0 ≤ tab (r.val+540+2520) ∧
  0 ≤ tab (r.val+540+3360)-tab (r.val+540+2520) ∧
  0 ≤ tab (r.val+540+4200)-2*tab (r.val+540+3360)+tab (r.val+540+2520) ∧
  0 ≤ tab (r.val+540+5040)-3*tab (r.val+540+4200)+3*tab (r.val+540+3360)-tab (r.val+540+2520) := by decide

#print axioms rec9
#print axioms rows9
end T3
