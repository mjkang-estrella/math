import T4Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T4
theorem rec11_0 : ∀ n : Fin 15, tab (n.val+4620)=step tab (n.val+4620) := by decide
theorem rec11_1 : ∀ n : Fin 15, tab (n.val+4635)=step tab (n.val+4635) := by decide
theorem rec11_2 : ∀ n : Fin 15, tab (n.val+4650)=step tab (n.val+4650) := by decide
theorem rec11_3 : ∀ n : Fin 15, tab (n.val+4665)=step tab (n.val+4665) := by decide
theorem rec11_4 : ∀ n : Fin 15, tab (n.val+4680)=step tab (n.val+4680) := by decide
theorem rec11_5 : ∀ n : Fin 15, tab (n.val+4695)=step tab (n.val+4695) := by decide
theorem rec11_6 : ∀ n : Fin 15, tab (n.val+4710)=step tab (n.val+4710) := by decide
theorem rec11_7 : ∀ n : Fin 15, tab (n.val+4725)=step tab (n.val+4725) := by decide
theorem rec11_8 : ∀ n : Fin 15, tab (n.val+4740)=step tab (n.val+4740) := by decide
theorem rec11_9 : ∀ n : Fin 15, tab (n.val+4755)=step tab (n.val+4755) := by decide
theorem rec11_10 : ∀ n : Fin 15, tab (n.val+4770)=step tab (n.val+4770) := by decide
theorem rec11_11 : ∀ n : Fin 15, tab (n.val+4785)=step tab (n.val+4785) := by decide
theorem rec11_12 : ∀ n : Fin 15, tab (n.val+4800)=step tab (n.val+4800) := by decide
theorem rec11_13 : ∀ n : Fin 15, tab (n.val+4815)=step tab (n.val+4815) := by decide
theorem rec11_14 : ∀ n : Fin 15, tab (n.val+4830)=step tab (n.val+4830) := by decide
theorem rec11_15 : ∀ n : Fin 15, tab (n.val+4845)=step tab (n.val+4845) := by decide
theorem rec11_16 : ∀ n : Fin 15, tab (n.val+4860)=step tab (n.val+4860) := by decide
theorem rec11_17 : ∀ n : Fin 15, tab (n.val+4875)=step tab (n.val+4875) := by decide
theorem rec11_18 : ∀ n : Fin 15, tab (n.val+4890)=step tab (n.val+4890) := by decide
theorem rec11_19 : ∀ n : Fin 15, tab (n.val+4905)=step tab (n.val+4905) := by decide
theorem rec11_20 : ∀ n : Fin 15, tab (n.val+4920)=step tab (n.val+4920) := by decide
theorem rec11_21 : ∀ n : Fin 15, tab (n.val+4935)=step tab (n.val+4935) := by decide
theorem rec11_22 : ∀ n : Fin 15, tab (n.val+4950)=step tab (n.val+4950) := by decide
theorem rec11_23 : ∀ n : Fin 15, tab (n.val+4965)=step tab (n.val+4965) := by decide
theorem rec11_24 : ∀ n : Fin 15, tab (n.val+4980)=step tab (n.val+4980) := by decide
theorem rec11_25 : ∀ n : Fin 15, tab (n.val+4995)=step tab (n.val+4995) := by decide
theorem rec11_26 : ∀ n : Fin 15, tab (n.val+5010)=step tab (n.val+5010) := by decide
theorem rec11_27 : ∀ n : Fin 15, tab (n.val+5025)=step tab (n.val+5025) := by decide
theorem rec11 : ∀ n : Fin 420, tab (n.val+4620)=step tab (n.val+4620) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec11_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+4620=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec11_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+4635=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec11_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+4650=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec11_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+4665=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec11_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+4680=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec11_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+4695=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec11_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+4710=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec11_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+4725=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec11_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+4740=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec11_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+4755=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec11_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+4770=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec11_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+4785=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec11_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+4800=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec11_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+4815=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec11_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+4830=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec11_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+4845=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec11_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+4860=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec11_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+4875=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec11_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+4890=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec11_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+4905=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec11_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+4920=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec11_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+4935=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec11_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+4950=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec11_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+4965=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec11_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+4980=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec11_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+4995=n.val+4620 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec11_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+5010=n.val+4620 := by omega
    simpa only [he] using h
  have h := rec11_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+5025=n.val+4620 := by omega
  simpa only [he] using h
theorem rows11 : ∀ r : Fin 60,
  0 ≤ tab (r.val+660+2520) ∧
  0 ≤ tab (r.val+660+3360)-tab (r.val+660+2520) ∧
  0 ≤ tab (r.val+660+4200)-2*tab (r.val+660+3360)+tab (r.val+660+2520) ∧
  0 ≤ tab (r.val+660+5040)-3*tab (r.val+660+4200)+3*tab (r.val+660+3360)-tab (r.val+660+2520) := by decide

#print axioms rec11
#print axioms rows11
end T4
