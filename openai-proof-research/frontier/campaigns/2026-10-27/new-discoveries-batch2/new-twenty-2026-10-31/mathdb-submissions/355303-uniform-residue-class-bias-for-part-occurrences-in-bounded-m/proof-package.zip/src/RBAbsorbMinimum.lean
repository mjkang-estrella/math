import RBAbsorbResidual
noncomputable section
namespace RBAbsorb

def Valid (s : Multiset ℕ) : Prop := ∀ w ∈ s, w % 2 = 1 ∧ 9 ≤ w
def Least (s : Multiset ℕ) (w : ℕ) : Prop := w ∈ s ∧ ∀ x ∈ s, w ≤ x
def lower (s : Multiset ℕ) (w k : ℕ) : Multiset ℕ := (w-k) ::ₘ s.erase w

theorem least_exists (s : Multiset ℕ) (hs : s ≠ 0) : ∃ w, Least s w := by
  classical
  have hn : s.toFinset.Nonempty := by
    by_contra h
    have hz : s.toFinset = ∅ := Finset.not_nonempty_iff_eq_empty.mp h
    exact hs (by simpa using hz)
  refine ⟨s.toFinset.min' hn, ?_, ?_⟩
  · simpa using Finset.min'_mem s.toFinset hn
  · intro x hx
    exact Finset.min'_le _ _ (by simpa using hx)

theorem lower_weight (s : Multiset ℕ) (w k : ℕ) (hw : w ∈ s) (hk : k ≤ w) :
    (lower s w k).sum + k = s.sum := by
  have he := congrArg Multiset.sum (Multiset.cons_erase hw)
  simp only [Multiset.sum_cons] at he
  simp only [lower, Multiset.sum_cons]
  omega

theorem lower_valid (s : Multiset ℕ) (w k : ℕ) (hv : Valid s)
    (hw : w ∈ s) (hk : k % 2 = 0) (hbound : 9+k ≤ w) : Valid (lower s w k) := by
  intro x hx
  simp only [lower, Multiset.mem_cons] at hx
  rcases hx with rfl | hx
  · have ho := (hv w hw).1
    constructor <;> omega
  · exact hv x (Multiset.mem_of_mem_erase hx)

theorem lower_tail_strict (s : Multiset ℕ) (w k : ℕ) (hw : Least s w) (hk : 0 < k)
    (hkw : k ≤ w) : ∀ x ∈ s.erase w, w-k < x := by
  intro x hx
  have hl := hw.2 x (Multiset.mem_of_mem_erase hx)
  omega

theorem lower_least (s : Multiset ℕ) (w k : ℕ) (hw : Least s w) :
    Least (lower s w k) (w-k) := by
  constructor
  · simp [lower]
  · intro x hx
    simp only [lower, Multiset.mem_cons] at hx
    rcases hx with rfl | hx
    · exact le_refl _
    · exact le_trans (Nat.sub_le w k) (hw.2 x (Multiset.mem_of_mem_erase hx))

theorem least_unique {s : Multiset ℕ} {w v : ℕ} (hw : Least s w) (hv : Least s v) : w=v :=
  le_antisymm (hw.2 v hv.1) (hv.2 w hw.1)

theorem lower_injective {s t : Multiset ℕ} {w v k : ℕ}
    (hw : Least s w) (hv : Least t v) (hkw : k ≤ w) (hkv : k ≤ v)
    (he : lower s w k = lower t v k) : s=t := by
  have hm : w-k = v-k := least_unique (lower_least s w k hw) (he ▸ lower_least t v k hv)
  have h : w=v := by omega
  subst v
  have ht : s.erase w = t.erase w := by simpa only [lower, Multiset.cons_inj_right] using he
  calc s = w ::ₘ s.erase w := (Multiset.cons_erase hw.1).symm
       _ = w ::ₘ t.erase w := congrArg (fun u => w ::ₘ u) ht
       _ = t := Multiset.cons_erase hv.1

theorem deletion_injective {s t : Multiset ℕ} {w : ℕ} (hs : w ∈ s) (ht : w ∈ t)
    (he : s.erase w = t.erase w) : s=t := by
  rw [← Multiset.cons_erase hs, ← Multiset.cons_erase ht, he]

-- The replacement occurs exactly once, even if the old minimum was repeated.
theorem lower_unique_new (s : Multiset ℕ) (w k : ℕ) (hw : Least s w)
    (hk : 0 < k) (hkw : k ≤ w) : (lower s w k).count (w-k) = 1 := by
  have hn : w-k ∉ s.erase w := by
    intro h
    have := lower_tail_strict s w k hw hk hkw (w-k) h
    omega
  simp [lower, Multiset.count_eq_zero.mpr hn]
#print axioms lower_injective
#print axioms lower_unique_new
#print axioms lower_weight
end RBAbsorb
