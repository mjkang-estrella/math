import RBWeakChain

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBStrictCore (355303 strict support): positivity, deletion invariant, pigeonhole, windows

* `Sup f m` : coefficient `m` of `f` is `> 0`; products/sums of NN series.
* `Good k a n P K` : some deleted set `S ⊆ [1,n] \ {a, a+1}` (elements satisfying `P`) with
  `coeff n ((1-X) F ∏_S B · Y) = coeff n (K · Y)` for every `Y`.
* `strict_of_good` : NN `K` with `coeff n K > 0` gives `C k (a+1) n < C k a n`.
* `two_good` (pigeonhole), `window_ind`, Bool windows `win3`, `pairsOK` (checked by `decide`).
No new axiom; C, D and all prefix definitions are unchanged.
-/

namespace RBStrict

open RBCount Finset

local notation "𝔛" => (PowerSeries.X : PowerSeries ℤ)

/-- Positive coefficient. -/
def Sup (f : PowerSeries ℤ) (m : ℕ) : Prop := 0 < PowerSeries.coeff m f

theorem coeff_mul_ge {f g : PowerSeries ℤ} (hf : NN f) (hg : NN g) (i j : ℕ) :
    PowerSeries.coeff i f * PowerSeries.coeff j g ≤ PowerSeries.coeff (i + j) (f * g) := by
  have hmem : ((i, j) : ℕ × ℕ) ∈ Finset.antidiagonal (i + j) := Finset.mem_antidiagonal.mpr rfl
  rw [PowerSeries.coeff_mul]
  exact Finset.single_le_sum
    (f := fun p : ℕ × ℕ => PowerSeries.coeff p.1 f * PowerSeries.coeff p.2 g)
    (fun p _ => mul_nonneg (hf p.1) (hg p.2)) hmem

theorem Sup_mul {f g : PowerSeries ℤ} {i j m : ℕ} (hf : NN f) (hg : NN g) (h1 : Sup f i)
    (h2 : Sup g j) (hm : i + j = m) : Sup (f * g) m := by
  subst hm
  exact lt_of_lt_of_le (mul_pos h1 h2) (coeff_mul_ge hf hg i j)

theorem Sup_add_left {f g : PowerSeries ℤ} {m : ℕ} (h : Sup f m) (hg : NN g) : Sup (f + g) m := by
  show 0 < PowerSeries.coeff m (f + g)
  rw [map_add]
  exact add_pos_of_pos_of_nonneg h (hg m)

theorem Sup_add_right {f g : PowerSeries ℤ} {m : ℕ} (hf : NN f) (h : Sup g m) : Sup (f + g) m := by
  show 0 < PowerSeries.coeff m (f + g)
  rw [map_add]
  exact add_pos_of_nonneg_of_pos (hf m) h

theorem Sup_X_pow (e : ℕ) : Sup (𝔛 ^ e) e := by
  show 0 < PowerSeries.coeff e (𝔛 ^ e)
  rw [PowerSeries.coeff_X_pow_self]
  exact one_pos

theorem Sup_X : Sup 𝔛 1 := by
  have h := Sup_X_pow 1
  rwa [pow_one] at h

theorem Sup_gI (c u : ℕ) : Sup (gI c) (c * u) := by
  show 0 < PowerSeries.coeff (c * u) (gI c)
  unfold gI
  rw [PowerSeries.coeff_mk, ite_eq_left (Nat.dvd_mul_right c u)]
  exact one_pos

theorem Sup_Bf {k h i : ℕ} (hh : 1 ≤ h) (hi : i < k) : Sup (Bf k h) (i * h) := by
  show 0 < PowerSeries.coeff (i * h) (Bf k h)
  rw [coeff_Bf_mul k h i hh, ite_eq_left hi]
  exact one_pos

theorem coeff_le_sum {ι : Type*} {s : Finset ι} {f : ι → PowerSeries ℤ} (h : ∀ i ∈ s, NN (f i))
    {i0 : ι} (hi : i0 ∈ s) (m : ℕ) :
    PowerSeries.coeff m (f i0) ≤ PowerSeries.coeff m (∑ i ∈ s, f i) := by
  rw [map_sum]
  exact Finset.single_le_sum (f := fun i => PowerSeries.coeff m (f i)) (fun i hi => h i hi m) hi

/-- The `i = 1, j = 0` term of `pairF` is `X^a`. -/
theorem Sup_pairF {k a : ℕ} (hk : 2 ≤ k) : Sup (pairF k a) a := by
  show 0 < PowerSeries.coeff a (pairF k a)
  unfold pairF
  refine lt_of_lt_of_le ?_ (coeff_le_sum (by
      intro i _
      exact NN_sum _ _ fun j _ => NN_mul (NN_C_natCast _) (NN_mul (NN_X_pow _)
        (NN_sum _ _ fun e _ => NN_X_pow _))) (Finset.mem_range.mpr (by omega : 1 < k)) a)
  refine lt_of_lt_of_le ?_ (coeff_le_sum (by
      intro j _
      exact NN_mul (NN_C_natCast _) (NN_mul (NN_X_pow _) (NN_sum _ _ fun e _ => NN_X_pow _)))
      (Finset.mem_range.mpr (by omega : 0 < 1)) a)
  simp

theorem Sup_coin {p q u v i j : ℕ} (hp : 1 ≤ p) (hq : 1 ≤ q) (hi : i < u) :
    Sup ((1 - 𝔛 ^ (p * u + q * v)) * gI p * gI q) (p * i + q * j) := by
  rw [coin hp hq u v]
  exact Sup_add_left (Sup_mul (NN_Bf _ _) (NN_gI _) (Sup_Bf (k := u) hp hi) (Sup_gI q j) (by ring))
    (NN_mul (NN_mul (NN_X_pow _) (NN_Bf _ _)) (NN_gI _))

/-! ## Deletion invariant -/

/-- A deleted set `S` (inside the marked-erased range, all elements satisfying `P`) whose
factors, together with `(1-X) F`, agree with `K` at degree `n` against every cofactor. -/
def Good (k a n : ℕ) (P : ℕ → Prop) (K : PowerSeries ℤ) : Prop :=
  ∃ S : Finset ℕ, S ⊆ ((Icc 1 n).erase a).erase (a + 1) ∧ (∀ y ∈ S, P y) ∧
    ∀ Y : PowerSeries ℤ, PowerSeries.coeff n ((1 - 𝔛) * pairF k a * (∏ h ∈ S, Bf k h) * Y) =
      PowerSeries.coeff n (K * Y)

theorem good_base (k a n : ℕ) : Good k a n (fun _ => False) ((1 - 𝔛) * pairF k a) := by
  refine ⟨∅, Finset.empty_subset _, fun y hy => by simp at hy, fun Y => ?_⟩
  rw [Finset.prod_empty, mul_one]

theorem good_mono {k a n : ℕ} {P Q : ℕ → Prop} {K : PowerSeries ℤ} (hG : Good k a n P K)
    (h : ∀ y, P y → Q y) : Good k a n Q K := by
  obtain ⟨S, hS, hP, he⟩ := hG
  exact ⟨S, hS, fun y hy => h y (hP y hy), he⟩

theorem good_eq {k a n : ℕ} {P : ℕ → Prop} {K K' : PowerSeries ℤ} (hG : Good k a n P K)
    (e : K = K') : Good k a n P K' := by
  rw [← e]
  exact hG

theorem good_add {k a n : ℕ} {P : ℕ → Prop} {K : PowerSeries ℤ} (T : Finset ℕ)
    (hT : T ⊆ ((Icc 1 n).erase a).erase (a + 1)) (hd : ∀ y ∈ T, ¬ P y) (hG : Good k a n P K) :
    Good k a n (fun y => P y ∨ y ∈ T) (K * ∏ h ∈ T, Bf k h) := by
  obtain ⟨S, hS, hP, he⟩ := hG
  have dj : Disjoint S T := Finset.disjoint_left.mpr fun y h1 h2 => hd y h2 (hP y h1)
  refine ⟨S ∪ T, Finset.union_subset hS hT, fun y hy => ?_, fun Y => ?_⟩
  · rcases Finset.mem_union.mp hy with h | h
    · exact Or.inl (hP y h)
    · exact Or.inr h
  · rw [Finset.prod_union dj]
    have e1 := he ((∏ h ∈ T, Bf k h) * Y)
    calc PowerSeries.coeff n ((1 - 𝔛) * pairF k a * ((∏ h ∈ S, Bf k h) * ∏ h ∈ T, Bf k h) * Y)
        = PowerSeries.coeff n ((1 - 𝔛) * pairF k a * (∏ h ∈ S, Bf k h) *
            ((∏ h ∈ T, Bf k h) * Y)) := by congr 1; ring
      _ = PowerSeries.coeff n (K * ((∏ h ∈ T, Bf k h) * Y)) := e1
      _ = PowerSeries.coeff n (K * (∏ h ∈ T, Bf k h) * Y) := by congr 1; ring

theorem good_single {k a n y : ℕ} {P : ℕ → Prop} {K : PowerSeries ℤ} (hy1 : 1 ≤ y) (hyn : y ≤ n)
    (hya : y ≠ a) (hya1 : y ≠ a + 1) (hd : ¬ P y) (hG : Good k a n P K) :
    Good k a n (fun z => P z ∨ z = y) (K * Bf k y) := by
  have h := good_add {y} (by
      intro z hz
      rw [Finset.mem_singleton] at hz
      rw [hz]
      exact Finset.mem_erase.mpr ⟨hya1, Finset.mem_erase.mpr ⟨hya, Finset.mem_Icc.mpr ⟨hy1, hyn⟩⟩⟩)
    (fun z hz => by
      rw [Finset.mem_singleton] at hz
      rw [hz]
      exact hd) hG
  rw [Finset.prod_singleton] at h
  exact good_mono h fun z hz => hz.imp id Finset.mem_singleton.mp

theorem good_trunc {k a n c M : ℕ} {P : ℕ → Prop} {K Q : PowerSeries ℤ} (hc : 1 ≤ c) (hM : n < M)
    (hQ : (1 - 𝔛 ^ c) * Q = 1 - 𝔛 ^ M) (hG : Good k a n P (K * Q)) : Good k a n P (K * gI c) := by
  obtain ⟨S, hS, hP, he⟩ := hG
  refine ⟨S, hS, hP, fun Y => ?_⟩
  rw [he Y]
  calc PowerSeries.coeff n (K * Q * Y) = PowerSeries.coeff n ((K * Y) * Q) := by congr 1; ring
    _ = PowerSeries.coeff n ((K * Y) * gI c) := coeff_mul_tele hc hM hQ _
    _ = PowerSeries.coeff n (K * gI c * Y) := by congr 1; ring

/-- Full chain `{c k^j}` (avoiding both marks, disjoint from `P`) replaced by `gI c`. -/
theorem good_chain {k a n c : ℕ} {P : ℕ → Prop} {K : PowerSeries ℤ} (hk : 2 ≤ k) (hc : 1 ≤ c)
    (hav : ∀ j, c * k ^ j ≠ a ∧ c * k ^ j ≠ a + 1) (hd : ∀ j, ¬ P (c * k ^ j))
    (hG : Good k a n P K) : Good k a n (fun y => P y ∨ ∃ j, y = c * k ^ j) (K * gI c) := by
  obtain ⟨m, hm1, hm2⟩ := exists_len hk hc 0 n
  have hsub : chainSet k c 0 m ⊆ ((Icc 1 n).erase a).erase (a + 1) := by
    intro y hy
    have hs := chainSet_subset hk hc hm1 hy
    obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
    rw [Nat.add_zero] at hs ⊢
    exact Finset.mem_erase.mpr ⟨(hav j).2, Finset.mem_erase.mpr ⟨(hav j).1, hs⟩⟩
  have h1 := good_add (chainSet k c 0 m) hsub (fun y hy => by
    obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
    rw [Nat.add_zero]
    exact hd j) hG
  rw [prod_chainSet hk hc (Bf k)] at h1
  have t := chain_tele k c 0 m
  rw [pow_zero, mul_one] at t
  have h2 := good_trunc hc hm2 t h1
  refine good_mono h2 fun y hy => ?_
  rcases hy with hy | hy
  · exact Or.inl hy
  · obtain ⟨j, _, rfl⟩ := mem_chainSet.mp hy
    exact Or.inr ⟨j + 0, rfl⟩

/-- Partial root-1 chain `{k^j : j < w}` (all below `a`): kernel `(1 - X^(k^w)) F`. -/
theorem good_exc_base {k a n w : ℕ} (hk : 2 ≤ k) (hw : 1 ≤ w) (hlow : k ^ (w - 1) < a)
    (han : a + 1 ≤ n) :
    Good k a n (fun y => ∃ j, y = 1 * k ^ j) ((1 - 𝔛 ^ (k ^ w)) * pairF k a) := by
  have hsub : chainSet k 1 0 w ⊆ ((Icc 1 n).erase a).erase (a + 1) := by
    intro y hy
    obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
    have hle : k ^ (j + 0) ≤ k ^ (w - 1) := Nat.pow_le_pow_right (by omega) (by omega)
    have hpos : 0 < k ^ (j + 0) := pow_pos (by omega) _
    exact Finset.mem_erase.mpr ⟨by omega, Finset.mem_erase.mpr ⟨by omega,
      Finset.mem_Icc.mpr ⟨by omega, by omega⟩⟩⟩
  have h1 := good_add (chainSet k 1 0 w) hsub (fun y _ h => h) (good_base k a n)
  rw [prod_chainSet hk (le_refl 1) (Bf k)] at h1
  have t0 := chain_tele k 1 0 w
  rw [show 1 * k ^ 0 = 1 by simp, show 1 * k ^ (w + 0) = k ^ w by simp, pow_one] at t0
  have e : (1 - 𝔛) * pairF k a * ∏ j ∈ range w, Bf k (1 * k ^ (j + 0)) =
      (1 - 𝔛 ^ (k ^ w)) * pairF k a := by
    rw [← t0]
    ring
  rw [e] at h1
  refine good_mono h1 fun y hy => ?_
  rcases hy with hy | hy
  · exact False.elim hy
  · obtain ⟨j, _, rfl⟩ := mem_chainSet.mp hy
    exact ⟨j + 0, rfl⟩

/-- Strictness from a good kernel with a positive coefficient at `n`. -/
theorem strict_of_good {k a n : ℕ} {P : ℕ → Prop} {K : PowerSeries ℤ} (hk : 1 ≤ k) (ha : 1 ≤ a)
    (han : a + 1 ≤ n) (hG : Good k a n P K) (hK : NN K) (hpos : Sup K n) :
    C k (a + 1) n < C k a n := by
  obtain ⟨S, hS, hP, he⟩ := hG
  have e := C_sub_C_succ_eq_coeff (k := k) (a := a) (N := n) (n := n) hk ha han le_rfl
  rw [← Finset.prod_sdiff hS] at e
  have hY : NN (∏ h ∈ (((Icc 1 n).erase a).erase (a + 1)) \ S, Bf k h) :=
    NN_prod _ _ fun h _ => NN_Bf k h
  have hY0 : PowerSeries.coeff 0 (∏ h ∈ (((Icc 1 n).erase a).erase (a + 1)) \ S, Bf k h) = 1 := by
    rw [PowerSeries.coeff_zero_eq_constantCoeff_apply, map_prod]
    apply Finset.prod_eq_one
    intro h hh
    have hh1 : 1 ≤ h := (Finset.mem_Icc.mp (Finset.mem_of_mem_erase
      (Finset.mem_of_mem_erase (Finset.mem_sdiff.mp hh).1))).1
    rw [← PowerSeries.coeff_zero_eq_constantCoeff_apply, coeff_Bf_low hk (by omega : 0 < h)]
    simp
  have e2 : (1 - 𝔛) * pairF k a * ((∏ h ∈ (((Icc 1 n).erase a).erase (a + 1)) \ S, Bf k h) *
      ∏ h ∈ S, Bf k h) = (1 - 𝔛) * pairF k a * (∏ h ∈ S, Bf k h) *
      ∏ h ∈ (((Icc 1 n).erase a).erase (a + 1)) \ S, Bf k h := by ring
  rw [e2, he] at e
  have h3 := coeff_mul_ge hK hY n 0
  rw [hY0, mul_one, add_zero] at h3
  have h4 : 0 < PowerSeries.coeff n K := hpos
  omega

/-! ## Marks, roots, pigeonhole -/

theorem not_dvd_one {k : ℕ} (hk : 2 ≤ k) : ¬ k ∣ 1 := fun h => by
  have := Nat.le_of_dvd one_pos h
  omega

theorem not_root {k c c' j : ℕ} (hk : 2 ≤ k) (hc : ¬ k ∣ c) (hc' : ¬ k ∣ c') (hne : c ≠ c') :
    ¬ ∃ j', c * k ^ j = c' * k ^ j' := fun ⟨j', h⟩ => hne (root_unique hk hc hc' h).1

theorem not_root_k {k c j : ℕ} (hk : 2 ≤ k) (hc : ¬ k ∣ c) (hc1 : c ≠ 1) :
    ¬ ∃ j', c * k ^ j = k * k ^ j' := fun ⟨j', h⟩ =>
  hc1 (root_unique hk hc (not_dvd_one hk) (h.trans (by ring : k * k ^ j' = 1 * k ^ (j' + 1)))).1

/-- A root `c ≠ 1`, `k ∤ c`, different from the unmarked neighbour avoids both marks. -/
theorem avoid_exc {k a w c : ℕ} (hk : 2 ≤ k) (hw : 1 ≤ w) (hx : k ^ w = a ∨ k ^ w = a + 1)
    (hc : ¬ k ∣ c) (hc1 : c ≠ 1) (h1 : k ^ w = a + 1 → c ≠ a) (h2 : k ^ w = a → c ≠ a + 1) :
    ∀ j, c * k ^ j ≠ a ∧ c * k ^ j ≠ a + 1 := by
  have hk1 := not_dvd_one hk
  have hkw : k ∣ k ^ w := by
    obtain ⟨w', rfl⟩ := Nat.exists_eq_add_of_le hw
    exact ⟨k ^ w', by ring⟩
  intro j
  rcases hx with hxa | hxa
  · have hka : k ∣ a := hxa ▸ hkw
    have hnd : ¬ k ∣ a + 1 := fun h => hk1 ((Nat.dvd_add_right hka).mp h)
    refine ⟨fun h => hc1 (root_unique hk hc hk1
      (h.trans (show a = 1 * k ^ w by rw [← hxa, one_mul]))).1, fun h => ?_⟩
    exact h2 hxa (root_unique hk hc hnd (h.trans (show a + 1 = (a + 1) * k ^ 0 by
      rw [pow_zero, mul_one]))).1
  · have hka : k ∣ a + 1 := hxa ▸ hkw
    have hnd : ¬ k ∣ a := fun h => hk1 ((Nat.dvd_add_right h).mp hka)
    refine ⟨fun h => ?_, fun h => hc1 (root_unique hk hc hk1
      (h.trans (show a + 1 = 1 * k ^ w by rw [← hxa, one_mul]))).1⟩
    exact h1 hxa (root_unique hk hc hnd (h.trans (show a = a * k ^ 0 by
      rw [pow_zero, mul_one]))).1

theorem hlow_of {k a w : ℕ} (hk : 2 ≤ k) (hw : 1 ≤ w) (hx : k ^ w = a ∨ k ^ w = a + 1)
    (ha : 2 ≤ a) : k ^ (w - 1) < a := by
  have hxw : k ^ w = k ^ (w - 1) * k := by rw [← pow_succ, Nat.sub_add_cancel hw]
  have ht1 : 0 < k ^ (w - 1) := pow_pos (by omega) _
  have hmul : k ^ (w - 1) * 2 ≤ k ^ (w - 1) * k := Nat.mul_le_mul_left _ hk
  omega

theorem notPow {k y : ℕ} (hy : 2 ≤ y) (hky : ¬ k ∣ y) : ∀ j, k ^ j ≠ y := by
  intro j h
  cases j with
  | zero =>
    rw [pow_zero] at h
    omega
  | succ j => exact hky ⟨k ^ j, by rw [← h, pow_succ, mul_comm]⟩

theorem two_good (s : Finset ℕ) (hs : 5 ≤ s.card) (B1 B2 B3 : ℕ → Prop)
    (h1 : ∀ x ∈ s, ∀ y ∈ s, B1 x → B1 y → x = y) (h2 : ∀ x ∈ s, ∀ y ∈ s, B2 x → B2 y → x = y)
    (h3 : ∀ x ∈ s, ∀ y ∈ s, B3 x → B3 y → x = y) :
    ∃ p ∈ s, ∃ q ∈ s, p ≠ q ∧ (¬ B1 p ∧ ¬ B2 p ∧ ¬ B3 p) ∧ (¬ B1 q ∧ ¬ B2 q ∧ ¬ B3 q) := by
  classical
  have c1 : (s.filter B1).card ≤ 1 := Finset.card_le_one.mpr fun x hx y hy =>
    h1 x (Finset.mem_filter.mp hx).1 y (Finset.mem_filter.mp hy).1 (Finset.mem_filter.mp hx).2
      (Finset.mem_filter.mp hy).2
  have c2 : (s.filter B2).card ≤ 1 := Finset.card_le_one.mpr fun x hx y hy =>
    h2 x (Finset.mem_filter.mp hx).1 y (Finset.mem_filter.mp hy).1 (Finset.mem_filter.mp hx).2
      (Finset.mem_filter.mp hy).2
  have c3 : (s.filter B3).card ≤ 1 := Finset.card_le_one.mpr fun x hx y hy =>
    h3 x (Finset.mem_filter.mp hx).1 y (Finset.mem_filter.mp hy).1 (Finset.mem_filter.mp hx).2
      (Finset.mem_filter.mp hy).2
  have hsub : s ⊆ s.filter (fun x => ¬ B1 x ∧ ¬ B2 x ∧ ¬ B3 x) ∪
      (s.filter B1 ∪ (s.filter B2 ∪ s.filter B3)) := by
    intro x hx
    simp only [Finset.mem_union, Finset.mem_filter]
    by_cases g1 : B1 x
    · exact Or.inr (Or.inl ⟨hx, g1⟩)
    · by_cases g2 : B2 x
      · exact Or.inr (Or.inr (Or.inl ⟨hx, g2⟩))
      · by_cases g3 : B3 x
        · exact Or.inr (Or.inr (Or.inr ⟨hx, g3⟩))
        · exact Or.inl ⟨hx, g1, g2, g3⟩
  have k1 := Finset.card_le_card hsub
  have k2 := Finset.card_union_le (s.filter (fun x => ¬ B1 x ∧ ¬ B2 x ∧ ¬ B3 x))
    (s.filter B1 ∪ (s.filter B2 ∪ s.filter B3))
  have k3 := Finset.card_union_le (s.filter B1) (s.filter B2 ∪ s.filter B3)
  have k4 := Finset.card_union_le (s.filter B2) (s.filter B3)
  have hG : 1 < (s.filter (fun x => ¬ B1 x ∧ ¬ B2 x ∧ ¬ B3 x)).card := by omega
  obtain ⟨p, hp, q, hq, hpq⟩ := Finset.one_lt_card.mp hG
  rw [Finset.mem_filter] at hp hq
  exact ⟨p, hp.1, q, hq.1, hpq, hp.2, hq.2⟩

theorem dvd_at_most_one {k : ℕ} (hk : 2 ≤ k) {s : Finset ℕ}
    (hcop : ∀ x ∈ s, ∀ y ∈ s, x ≠ y → Nat.gcd x y = 1) :
    ∀ x ∈ s, ∀ y ∈ s, k ∣ x → k ∣ y → x = y := by
  intro x hx y hy h1 h2
  by_contra hne
  have := Nat.le_of_dvd one_pos ((hcop x hx y hy hne) ▸ Nat.dvd_gcd h1 h2)
  omega

/-! ## Representability windows (Bool checks are evaluated by `decide`) -/

theorem window_ind (q m0 : ℕ) (hq : 1 ≤ q) {R : ℕ → Prop}
    (hw : ∀ m, m0 ≤ m → m < m0 + q → R m) (hs : ∀ m, R m → R (m + q)) :
    ∀ m, m0 ≤ m → R m := by
  intro m
  induction m using Nat.strong_induction_on with
  | _ m ih =>
    intro hm
    by_cases h : m < m0 + q
    · exact hw m hm h
    · have h2 := hs (m - q) (ih (m - q) (by omega) (by omega))
      rwa [Nat.sub_add_cancel (by omega : q ≤ m)] at h2

/-- Window check: every `m0 + t`, `t < q`, is `p i + c l + (multiple of q)` with `i < I`, `l < L`. -/
def win3 (p I q c L m0 : ℕ) : Bool :=
  (List.range q).all fun t => (List.range I).any fun i => (List.range L).any fun l =>
    decide (p * i + c * l ≤ m0 + t) && (m0 + t - p * i - c * l) % q == 0

theorem rep3_of_win {p I q c L m0 : ℕ} (hq : 1 ≤ q) (h : win3 p I q c L m0 = true) :
    ∀ m, m0 ≤ m → ∃ i < I, ∃ j l, m = p * i + q * j + c * l := by
  refine window_ind (R := fun m => ∃ i < I, ∃ j l, m = p * i + q * j + c * l) q m0 hq ?_ ?_
  · intro m hm1 hm2
    simp only [win3, List.all_eq_true, List.any_eq_true, List.mem_range, Bool.and_eq_true,
      decide_eq_true_eq, beq_iff_eq] at h
    obtain ⟨i, hi, l, hl, hle, hmod⟩ := h (m - m0) (by omega)
    have hd := Nat.div_add_mod (m0 + (m - m0) - p * i - c * l) q
    rw [hmod, add_zero] at hd
    exact ⟨i, hi, (m0 + (m - m0) - p * i - c * l) / q, l, by omega⟩
  · rintro m ⟨i, hi, j, l, rfl⟩
    exact ⟨i, hi, j + 1, l, by ring⟩

/-- All ordered pairs of distinct list elements have a window from `m0`. -/
def pairsOK (s : List ℕ) (m0 : ℕ) : Bool :=
  s.all fun p => s.all fun q => (p == q) || win3 p q q q 1 m0

theorem rep2_of_pairsOK {s : List ℕ} {m0 : ℕ} (h : pairsOK s m0 = true) {p q : ℕ} (hp : p ∈ s)
    (hq : q ∈ s) (hpq : p ≠ q) (hq1 : 1 ≤ q) :
    ∀ m, m0 ≤ m → ∃ i < q, ∃ j l, m = p * i + q * j + q * l := by
  simp only [pairsOK, List.all_eq_true, Bool.or_eq_true, beq_iff_eq] at h
  rcases h p hp q hq with h' | h'
  · exact absurd h' hpq
  · exact rep3_of_win hq1 h'

/-! ## Kernels -/

theorem exc_kernel2 {k a w p q u v i j m : ℕ} (hk : 2 ≤ k) (hp : 1 ≤ p) (hq : 1 ≤ q)
    (hx : k ^ w = p * u + q * v) (hi : i < u) (hm : m = a + p * i + q * j) :
    NN ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q) ∧
      Sup ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q) m := by
  rw [hx]
  have e : (1 - 𝔛 ^ (p * u + q * v)) * pairF k a * gI p * gI q =
      pairF k a * ((1 - 𝔛 ^ (p * u + q * v)) * gI p * gI q) := by ring
  rw [e]
  have hc := NN_coin (u := u) (v := v) hp hq
  exact ⟨NN_mul (NN_pairF k a) hc,
    Sup_mul (NN_pairF k a) hc (Sup_pairF hk) (Sup_coin (v := v) (j := j) hp hq hi) (by omega)⟩

theorem exc_kernel3 {k a w p q c u v i j l m : ℕ} (hk : 2 ≤ k) (hp : 1 ≤ p) (hq : 1 ≤ q)
    (hx : k ^ w = p * u + q * v) (hi : i < u) (hm : m = a + p * i + q * j + c * l) :
    NN ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q * gI c) ∧
      Sup ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q * gI c) m := by
  obtain ⟨h1, h2⟩ := exc_kernel2 (j := j) (m := a + p * i + q * j) hk hp hq hx hi rfl
  exact ⟨NN_mul h1 (NN_gI c), Sup_mul h1 (NN_gI c) h2 (Sup_gI c l) (by omega)⟩

theorem pos_of_not_dvd {k p : ℕ} (h : ¬ k ∣ p) : 1 ≤ p :=
  Nat.pos_of_ne_zero fun h0 => h (h0 ▸ dvd_zero k)

/-- Exceptional: partial root-1 chain and chains `p, q`. -/
theorem good_exc2 {k a n w p q : ℕ} (hk : 2 ≤ k) (hw : 1 ≤ w) (hx : k ^ w = a ∨ k ^ w = a + 1)
    (hlow : k ^ (w - 1) < a) (han : a + 1 ≤ n) (hp1 : p ≠ 1) (hq1 : q ≠ 1) (hpq : p ≠ q)
    (hkp : ¬ k ∣ p) (hkq : ¬ k ∣ q)
    (hyp : k ^ w = a + 1 → p ≠ a ∧ q ≠ a) (hyq : k ^ w = a → p ≠ a + 1 ∧ q ≠ a + 1) :
    ∃ P, Good k a n P ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q) := by
  have hk1 := not_dvd_one hk
  have G0 := good_exc_base (n := n) hk hw hlow han
  have Gp := good_chain (c := p) hk (pos_of_not_dvd hkp)
    (avoid_exc hk hw hx hkp hp1 (fun h => (hyp h).1) (fun h => (hyq h).1))
    (fun j => not_root hk hkp hk1 hp1) G0
  have Gq := good_chain (c := q) hk (pos_of_not_dvd hkq)
    (avoid_exc hk hw hx hkq hq1 (fun h => (hyp h).2) (fun h => (hyq h).2))
    (fun j h => by
      rcases h with h | h
      · exact not_root hk hkq hk1 hq1 h
      · exact not_root hk hkq hkp (Ne.symm hpq) h) Gp
  exact ⟨_, Gq⟩

/-- Exceptional: partial root-1 chain and chains `p, q, c`. -/
theorem good_exc3 {k a n w p q c : ℕ} (hk : 2 ≤ k) (hw : 1 ≤ w) (hx : k ^ w = a ∨ k ^ w = a + 1)
    (hlow : k ^ (w - 1) < a) (han : a + 1 ≤ n) (hp1 : p ≠ 1) (hq1 : q ≠ 1) (hc1 : c ≠ 1)
    (hpq : p ≠ q) (hpc : p ≠ c) (hqc : q ≠ c) (hkp : ¬ k ∣ p) (hkq : ¬ k ∣ q) (hkc : ¬ k ∣ c)
    (hyp : k ^ w = a + 1 → p ≠ a ∧ q ≠ a ∧ c ≠ a)
    (hyq : k ^ w = a → p ≠ a + 1 ∧ q ≠ a + 1 ∧ c ≠ a + 1) :
    ∃ P, Good k a n P ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q * gI c) := by
  have hk1 := not_dvd_one hk
  have G0 := good_exc_base (n := n) hk hw hlow han
  have Gp := good_chain (c := p) hk (pos_of_not_dvd hkp)
    (avoid_exc hk hw hx hkp hp1 (fun h => (hyp h).1) (fun h => (hyq h).1))
    (fun j => not_root hk hkp hk1 hp1) G0
  have Gq := good_chain (c := q) hk (pos_of_not_dvd hkq)
    (avoid_exc hk hw hx hkq hq1 (fun h => (hyp h).2.1) (fun h => (hyq h).2.1))
    (fun j h => by
      rcases h with h | h
      · exact not_root hk hkq hk1 hq1 h
      · exact not_root hk hkq hkp (Ne.symm hpq) h) Gp
  have Gc := good_chain (c := c) hk (pos_of_not_dvd hkc)
    (avoid_exc hk hw hx hkc hc1 (fun h => (hyp h).2.2) (fun h => (hyq h).2.2))
    (fun j h => by
      rcases h with (h | h) | h
      · exact not_root hk hkc hk1 hc1 h
      · exact not_root hk hkc hkp (Ne.symm hpc) h
      · exact not_root hk hkc hkq (Ne.symm hqc) h) Gq
  exact ⟨_, Gc⟩

theorem strict_exc2 {k a n w p q u v : ℕ} (hk : 2 ≤ k) (ha : 1 ≤ a) (han : a + 1 ≤ n) (hw : 1 ≤ w)
    (hx : k ^ w = a ∨ k ^ w = a + 1) (hlow : k ^ (w - 1) < a) (hp1 : p ≠ 1) (hq1 : q ≠ 1)
    (hpq : p ≠ q) (hkp : ¬ k ∣ p) (hkq : ¬ k ∣ q)
    (hyp : k ^ w = a + 1 → p ≠ a ∧ q ≠ a) (hyq : k ^ w = a → p ≠ a + 1 ∧ q ≠ a + 1)
    (hu : k ^ w = p * u + q * v) (hrep : ∃ i < u, ∃ j, n = a + p * i + q * j) :
    C k (a + 1) n < C k a n := by
  obtain ⟨P, G⟩ := good_exc2 (n := n) hk hw hx hlow han hp1 hq1 hpq hkp hkq hyp hyq
  obtain ⟨i, hi, j, hn⟩ := hrep
  obtain ⟨hNN, hS⟩ := exc_kernel2 hk (pos_of_not_dvd hkp) (pos_of_not_dvd hkq) hu hi hn
  exact strict_of_good (by omega) ha han G hNN hS

theorem strict_exc3 {k a n w p q c u v : ℕ} (hk : 2 ≤ k) (ha : 1 ≤ a) (han : a + 1 ≤ n)
    (hw : 1 ≤ w) (hx : k ^ w = a ∨ k ^ w = a + 1) (hlow : k ^ (w - 1) < a) (hp1 : p ≠ 1)
    (hq1 : q ≠ 1) (hc1 : c ≠ 1) (hpq : p ≠ q) (hpc : p ≠ c) (hqc : q ≠ c) (hkp : ¬ k ∣ p)
    (hkq : ¬ k ∣ q) (hkc : ¬ k ∣ c)
    (hyp : k ^ w = a + 1 → p ≠ a ∧ q ≠ a ∧ c ≠ a)
    (hyq : k ^ w = a → p ≠ a + 1 ∧ q ≠ a + 1 ∧ c ≠ a + 1)
    (hu : k ^ w = p * u + q * v) (hrep : ∃ i < u, ∃ j l, n = a + p * i + q * j + c * l) :
    C k (a + 1) n < C k a n := by
  obtain ⟨P, G⟩ := good_exc3 (n := n) hk hw hx hlow han hp1 hq1 hc1 hpq hpc hqc hkp hkq hkc hyp hyq
  obtain ⟨i, hi, j, l, hn⟩ := hrep
  obtain ⟨hNN, hS⟩ := exc_kernel3 hk (pos_of_not_dvd hkp) (pos_of_not_dvd hkq) hu hi hn
  exact strict_of_good (by omega) ha han G hNN hS

/-- Non-exceptional: full root-1 chain cancels `1 - X`. -/
theorem good_NE {k a n : ℕ} (hk : 2 ≤ k) (hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1) :
    Good k a n (fun y => False ∨ ∃ j, y = 1 * k ^ j) (pairF k a) := by
  have h := good_chain (c := 1) hk (le_refl 1) (fun j => by rw [one_mul]; exact hpow j)
    (fun j h => h) (good_base k a n)
  refine good_eq h ?_
  have hg := one_sub_mul_gI (le_refl 1)
  rw [pow_one] at hg
  linear_combination (pairF k a) * hg

end RBStrict

#print axioms RBStrict.strict_of_good
#print axioms RBStrict.good_chain
#print axioms RBStrict.good_exc_base
#print axioms RBStrict.two_good
#print axioms RBStrict.rep3_of_win
#print axioms RBStrict.strict_exc2
#print axioms RBStrict.strict_exc3
#print axioms RBStrict.good_NE
#print axioms RBStrict.Sup_pairF
