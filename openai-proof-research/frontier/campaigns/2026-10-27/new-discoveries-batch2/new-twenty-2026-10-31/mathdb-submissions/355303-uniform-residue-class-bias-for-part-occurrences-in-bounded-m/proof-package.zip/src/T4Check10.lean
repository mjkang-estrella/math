import T4Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T4
theorem rec10_0 : ∀ n : Fin 15, tab (n.val+4200)=step tab (n.val+4200) := by decide
theorem rec10_1 : ∀ n : Fin 15, tab (n.val+4215)=step tab (n.val+4215) := by decide
theorem rec10_2 : ∀ n : Fin 15, tab (n.val+4230)=step tab (n.val+4230) := by decide
theorem rec10_3 : ∀ n : Fin 15, tab (n.val+4245)=step tab (n.val+4245) := by decide
theorem rec10_4 : ∀ n : Fin 15, tab (n.val+4260)=step tab (n.val+4260) := by decide
theorem rec10_5 : ∀ n : Fin 15, tab (n.val+4275)=step tab (n.val+4275) := by decide
theorem rec10_6 : ∀ n : Fin 15, tab (n.val+4290)=step tab (n.val+4290) := by decide
theorem rec10_7 : ∀ n : Fin 15, tab (n.val+4305)=step tab (n.val+4305) := by decide
theorem rec10_8 : ∀ n : Fin 15, tab (n.val+4320)=step tab (n.val+4320) := by decide
theorem rec10_9 : ∀ n : Fin 15, tab (n.val+4335)=step tab (n.val+4335) := by decide
theorem rec10_10 : ∀ n : Fin 15, tab (n.val+4350)=step tab (n.val+4350) := by decide
theorem rec10_11 : ∀ n : Fin 15, tab (n.val+4365)=step tab (n.val+4365) := by decide
theorem rec10_12 : ∀ n : Fin 15, tab (n.val+4380)=step tab (n.val+4380) := by decide
theorem rec10_13 : ∀ n : Fin 15, tab (n.val+4395)=step tab (n.val+4395) := by decide
theorem rec10_14 : ∀ n : Fin 15, tab (n.val+4410)=step tab (n.val+4410) := by decide
theorem rec10_15 : ∀ n : Fin 15, tab (n.val+4425)=step tab (n.val+4425) := by decide
theorem rec10_16 : ∀ n : Fin 15, tab (n.val+4440)=step tab (n.val+4440) := by decide
theorem rec10_17 : ∀ n : Fin 15, tab (n.val+4455)=step tab (n.val+4455) := by decide
theorem rec10_18 : ∀ n : Fin 15, tab (n.val+4470)=step tab (n.val+4470) := by decide
theorem rec10_19 : ∀ n : Fin 15, tab (n.val+4485)=step tab (n.val+4485) := by decide
theorem rec10_20 : ∀ n : Fin 15, tab (n.val+4500)=step tab (n.val+4500) := by decide
theorem rec10_21 : ∀ n : Fin 15, tab (n.val+4515)=step tab (n.val+4515) := by decide
theorem rec10_22 : ∀ n : Fin 15, tab (n.val+4530)=step tab (n.val+4530) := by decide
theorem rec10_23 : ∀ n : Fin 15, tab (n.val+4545)=step tab (n.val+4545) := by decide
theorem rec10_24 : ∀ n : Fin 15, tab (n.val+4560)=step tab (n.val+4560) := by decide
theorem rec10_25 : ∀ n : Fin 15, tab (n.val+4575)=step tab (n.val+4575) := by decide
theorem rec10_26 : ∀ n : Fin 15, tab (n.val+4590)=step tab (n.val+4590) := by decide
theorem rec10_27 : ∀ n : Fin 15, tab (n.val+4605)=step tab (n.val+4605) := by decide
theorem rec10 : ∀ n : Fin 420, tab (n.val+4200)=step tab (n.val+4200) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec10_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+4200=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec10_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+4215=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec10_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+4230=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec10_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+4245=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec10_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+4260=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec10_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+4275=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec10_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+4290=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec10_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+4305=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec10_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+4320=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec10_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+4335=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec10_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+4350=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec10_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+4365=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec10_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+4380=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec10_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+4395=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec10_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+4410=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec10_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+4425=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec10_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+4440=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec10_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+4455=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec10_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+4470=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec10_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+4485=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec10_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+4500=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec10_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+4515=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec10_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+4530=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec10_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+4545=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec10_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+4560=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec10_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+4575=n.val+4200 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec10_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+4590=n.val+4200 := by omega
    simpa only [he] using h
  have h := rec10_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+4605=n.val+4200 := by omega
  simpa only [he] using h
theorem rows10 : ∀ r : Fin 60,
  0 ≤ tab (r.val+600+2520) ∧
  0 ≤ tab (r.val+600+3360)-tab (r.val+600+2520) ∧
  0 ≤ tab (r.val+600+4200)-2*tab (r.val+600+3360)+tab (r.val+600+2520) ∧
  0 ≤ tab (r.val+600+5040)-3*tab (r.val+600+4200)+3*tab (r.val+600+3360)-tab (r.val+600+2520) := by decide

#print axioms rec10
#print axioms rows10
end T4
