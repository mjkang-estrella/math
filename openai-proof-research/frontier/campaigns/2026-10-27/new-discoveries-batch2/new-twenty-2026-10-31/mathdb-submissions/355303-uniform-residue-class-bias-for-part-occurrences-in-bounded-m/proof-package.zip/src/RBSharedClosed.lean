import RBSharedRange
import RBSharedExactCoverage
import RBStageFnBinaryEndpoint
import RBSharedF3
import RBSharedF4
import RBSharedF5
import RBSharedF6
import RBSharedF7
import RBSharedF8
import RBSharedF9
import RBSharedF10
import RBSharedF11
import RBSharedF12
import RBSharedF13
import RBSharedF14
import RBSharedF15
import RBSharedF16
import RBSharedF17
import RBSharedF18
import RBSharedF19
import RBSharedF20
import RBSharedF21
import RBSharedF22
import RBSharedF23
import RBSharedF24
import RBSharedF25
import RBSharedF26
import RBSharedF27
import RBSharedF28
import RBSharedF29
import RBSharedF30
import RBSharedF31
import RBSharedF32
import RBSharedF33
import RBSharedF34
import RBSharedF35
import RBSharedF36
import RBSharedF37
import RBSharedF38
import RBSharedF39
import RBSharedF40
import RBSharedF41
import RBSharedF42
import RBSharedF43
import RBSharedF44
import RBSharedF45
import RBSharedF46
import RBSharedF47
import RBSharedF48
import RBSharedF49
import RBSharedF50
import RBSharedF51
import RBSharedF52
import RBSharedF53
import RBSharedF54
import RBSharedF55
import RBSharedF56
import RBSharedF57
import RBSharedF58
import RBSharedF59
import RBSharedF60
import RBSharedF61
import RBSharedF62
import RBSharedF63
import RBSharedF64
import RBSharedF65
import RBSharedF66
import RBSharedF67
import RBSharedF68
import RBSharedF69
import RBSharedF70
import RBSharedF71
import RBSharedF72
import RBSharedF73
import RBSharedF74
import RBSharedF75
import RBSharedF76
import RBSharedF77
import RBSharedF78
import RBSharedF79
import RBSharedF80
import RBSharedF81
import RBSharedF82
import RBSharedF83
import RBSharedF84
import RBSharedF85
import RBSharedF86
import RBSharedF87
import RBSharedF88
import RBSharedF89
import RBSharedF90
import RBSharedF91
import RBSharedF92
import RBSharedF93
import RBSharedF94
import RBSharedF95
import RBSharedF96
import RBSharedF97
import RBSharedF98
import RBSharedF99
import RBSharedF100
import RBSharedF101
import RBSharedF102
import RBSharedF103
import RBSharedF104
import RBSharedF105
import RBSharedF106
import RBSharedF107
import RBSharedF108
import RBSharedF109
import RBSharedF110
import RBSharedF111
import RBSharedF112
import RBSharedF113
import RBSharedF114
import RBSharedF115
import RBSharedF116
import RBSharedF117
import RBSharedF118
import RBSharedF119
import RBSharedF120
import RBSharedF121
import RBSharedF122
import RBSharedF123
import RBSharedF124
import RBSharedF125
import RBSharedF126
import RBSharedF127
import RBSharedF128
import RBSharedF129
import RBSharedF130
import RBSharedF131
import RBSharedF132
import RBSharedF133
import RBSharedF134
import RBSharedF135
import RBSharedF136
import RBSharedF137
import RBSharedF138
import RBSharedF139
import RBSharedF140
import RBSharedF141
import RBSharedF142
import RBSharedF143
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RBSharedClosed
open Polynomial RBPrefix RBShared
open scoped BigOperators
theorem normalize_existing (k a b : Nat) (hb : b=a+1)
 (h : ∀ n, Required k a n → (actualMarked k b).coeff n < (actualMarked k a).coeff n) :
 ∀ n, Required k a n → (actualMarked k (a+1)).coeff n < (actualMarked k a).coeff n := by
 intro n hr
 simpa only [hb] using h n hr
def Block (lo hi : Nat) : Prop := ∀ k a n, lo ≤ k → k < hi → Required k a n →
 (actualMarked k (a+1)).coeff n < (actualMarked k a).coeff n
theorem join_block (lo mid hi : Nat) (hl : Block lo mid) (hr : Block mid hi) : Block lo hi := by
 intro k a n hk hk' h
 by_cases hm : k < mid
 · exact hl k a n hk hm h
 · exact hr k a n (by omega) hk' h
theorem singleton_block (k : Nat)
 (h : ∀ a n, Required k a n → (actualMarked k (a+1)).coeff n < (actualMarked k a).coeff n) : Block k (k+1) := by
 intro j a n hj hj' r
 have he : j=k := by omega
 subst j
 exact h a n r

theorem shard2 : ∀ a n, Required 2 a n → (actualMarked 2 (a+1)).coeff n < (actualMarked 2 a).coeff n :=
 RBStageFn.binary_actual
theorem shard3 : ∀ a n, Required 3 a n → (actualMarked 3 (a+1)).coeff n < (actualMarked 3 a).coeff n :=
 RBSharedF3.shard
theorem shard4 : ∀ a n, Required 4 a n → (actualMarked 4 (a+1)).coeff n < (actualMarked 4 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 4 b n → (actualMarked 4 (b+1)).coeff n < (actualMarked 4 b).coeff n)
   ((normalize_existing 4 2 3 (by decide) RBSharedF4.claim2) n) ((normalize_existing 4 3 4 (by decide) RBSharedF4.claim3) n) ((normalize_existing 4 4 5 (by decide) RBSharedF4.claim4) n) ((normalize_existing 4 5 6 (by decide) RBSharedF4.claim5) n) ((normalize_existing 4 6 7 (by decide) RBSharedF4.claim6) n) ((normalize_existing 4 7 8 (by decide) RBSharedF4.claim7) n) ((normalize_existing 4 8 9 (by decide) RBSharedF4.claim8) n) ((normalize_existing 4 9 10 (by decide) RBSharedF4.claim9) n) ((normalize_existing 4 10 11 (by decide) RBSharedF4.claim10) n) ((normalize_existing 4 11 12 (by decide) RBSharedF4.claim11) n) ((normalize_existing 4 12 13 (by decide) RBSharedF4.claim12) n) ((normalize_existing 4 13 14 (by decide) RBSharedF4.claim13) n) ((normalize_existing 4 14 15 (by decide) RBSharedF4.claim14) n) ((normalize_existing 4 15 16 (by decide) RBSharedF4.claim15) n) ((normalize_existing 4 16 17 (by decide) RBSharedF4.claim16) n) ((normalize_existing 4 17 18 (by decide) RBSharedF4.claim17) n) ((normalize_existing 4 18 19 (by decide) RBSharedF4.claim18) n) ((normalize_existing 4 19 20 (by decide) RBSharedF4.claim19) n) ((normalize_existing 4 20 21 (by decide) RBSharedF4.claim20) n) ((normalize_existing 4 21 22 (by decide) RBSharedF4.claim21) n) ((normalize_existing 4 22 23 (by decide) RBSharedF4.claim22) n) ((normalize_existing 4 23 24 (by decide) RBSharedF4.claim23) n) a r.2.2.1 r.2.2.2.1 r
theorem shard5 : ∀ a n, Required 5 a n → (actualMarked 5 (a+1)).coeff n < (actualMarked 5 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 5 b n → (actualMarked 5 (b+1)).coeff n < (actualMarked 5 b).coeff n)
   (RBSharedF5.claim2 n) (RBSharedF5.claim3 n) (RBSharedF5.claim4 n) (RBSharedF5.claim5 n) (RBSharedF5.claim6 n) (RBSharedF5.claim7 n) (RBSharedF5.claim8 n) (RBSharedF5.claim9 n) (RBSharedF5.claim10 n) (RBSharedF5.claim11 n) (RBSharedF5.claim12 n) (RBSharedF5.claim13 n) (RBSharedF5.claim14 n) (RBSharedF5.claim15 n) (RBSharedF5.claim16 n) (RBSharedF5.claim17 n) (RBSharedF5.claim18 n) (RBSharedF5.claim19 n) (RBSharedF5.claim20 n) (RBSharedF5.claim21 n) (RBSharedF5.claim22 n) (RBSharedF5.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard6 : ∀ a n, Required 6 a n → (actualMarked 6 (a+1)).coeff n < (actualMarked 6 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 6 b n → (actualMarked 6 (b+1)).coeff n < (actualMarked 6 b).coeff n)
   (RBSharedF6.claim2 n) (RBSharedF6.claim3 n) (RBSharedF6.claim4 n) (RBSharedF6.claim5 n) (RBSharedF6.claim6 n) (RBSharedF6.claim7 n) (RBSharedF6.claim8 n) (RBSharedF6.claim9 n) (RBSharedF6.claim10 n) (RBSharedF6.claim11 n) (RBSharedF6.claim12 n) (RBSharedF6.claim13 n) (RBSharedF6.claim14 n) (RBSharedF6.claim15 n) (RBSharedF6.claim16 n) (RBSharedF6.claim17 n) (RBSharedF6.claim18 n) (RBSharedF6.claim19 n) (RBSharedF6.claim20 n) (RBSharedF6.claim21 n) (RBSharedF6.claim22 n) (RBSharedF6.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard7 : ∀ a n, Required 7 a n → (actualMarked 7 (a+1)).coeff n < (actualMarked 7 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 7 b n → (actualMarked 7 (b+1)).coeff n < (actualMarked 7 b).coeff n)
   (RBSharedF7.claim2 n) (RBSharedF7.claim3 n) (RBSharedF7.claim4 n) (RBSharedF7.claim5 n) (RBSharedF7.claim6 n) (RBSharedF7.claim7 n) (RBSharedF7.claim8 n) (RBSharedF7.claim9 n) (RBSharedF7.claim10 n) (RBSharedF7.claim11 n) (RBSharedF7.claim12 n) (RBSharedF7.claim13 n) (RBSharedF7.claim14 n) (RBSharedF7.claim15 n) (RBSharedF7.claim16 n) (RBSharedF7.claim17 n) (RBSharedF7.claim18 n) (RBSharedF7.claim19 n) (RBSharedF7.claim20 n) (RBSharedF7.claim21 n) (RBSharedF7.claim22 n) (RBSharedF7.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard8 : ∀ a n, Required 8 a n → (actualMarked 8 (a+1)).coeff n < (actualMarked 8 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 8 b n → (actualMarked 8 (b+1)).coeff n < (actualMarked 8 b).coeff n)
   (RBSharedF8.claim2 n) (RBSharedF8.claim3 n) (RBSharedF8.claim4 n) (RBSharedF8.claim5 n) (RBSharedF8.claim6 n) (RBSharedF8.claim7 n) (RBSharedF8.claim8 n) (RBSharedF8.claim9 n) (RBSharedF8.claim10 n) (RBSharedF8.claim11 n) (RBSharedF8.claim12 n) (RBSharedF8.claim13 n) (RBSharedF8.claim14 n) (RBSharedF8.claim15 n) (RBSharedF8.claim16 n) (RBSharedF8.claim17 n) (RBSharedF8.claim18 n) (RBSharedF8.claim19 n) (RBSharedF8.claim20 n) (RBSharedF8.claim21 n) (RBSharedF8.claim22 n) (RBSharedF8.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard9 : ∀ a n, Required 9 a n → (actualMarked 9 (a+1)).coeff n < (actualMarked 9 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 9 b n → (actualMarked 9 (b+1)).coeff n < (actualMarked 9 b).coeff n)
   (RBSharedF9.claim2 n) (RBSharedF9.claim3 n) (RBSharedF9.claim4 n) (RBSharedF9.claim5 n) (RBSharedF9.claim6 n) (RBSharedF9.claim7 n) (RBSharedF9.claim8 n) (RBSharedF9.claim9 n) (RBSharedF9.claim10 n) (RBSharedF9.claim11 n) (RBSharedF9.claim12 n) (RBSharedF9.claim13 n) (RBSharedF9.claim14 n) (RBSharedF9.claim15 n) (RBSharedF9.claim16 n) (RBSharedF9.claim17 n) (RBSharedF9.claim18 n) (RBSharedF9.claim19 n) (RBSharedF9.claim20 n) (RBSharedF9.claim21 n) (RBSharedF9.claim22 n) (RBSharedF9.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard10 : ∀ a n, Required 10 a n → (actualMarked 10 (a+1)).coeff n < (actualMarked 10 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 10 b n → (actualMarked 10 (b+1)).coeff n < (actualMarked 10 b).coeff n)
   (RBSharedF10.claim2 n) (RBSharedF10.claim3 n) (RBSharedF10.claim4 n) (RBSharedF10.claim5 n) (RBSharedF10.claim6 n) (RBSharedF10.claim7 n) (RBSharedF10.claim8 n) (RBSharedF10.claim9 n) (RBSharedF10.claim10 n) (RBSharedF10.claim11 n) (RBSharedF10.claim12 n) (RBSharedF10.claim13 n) (RBSharedF10.claim14 n) (RBSharedF10.claim15 n) (RBSharedF10.claim16 n) (RBSharedF10.claim17 n) (RBSharedF10.claim18 n) (RBSharedF10.claim19 n) (RBSharedF10.claim20 n) (RBSharedF10.claim21 n) (RBSharedF10.claim22 n) (RBSharedF10.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard11 : ∀ a n, Required 11 a n → (actualMarked 11 (a+1)).coeff n < (actualMarked 11 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 11 b n → (actualMarked 11 (b+1)).coeff n < (actualMarked 11 b).coeff n)
   (RBSharedF11.claim2 n) (RBSharedF11.claim3 n) (RBSharedF11.claim4 n) (RBSharedF11.claim5 n) (RBSharedF11.claim6 n) (RBSharedF11.claim7 n) (RBSharedF11.claim8 n) (RBSharedF11.claim9 n) (RBSharedF11.claim10 n) (RBSharedF11.claim11 n) (RBSharedF11.claim12 n) (RBSharedF11.claim13 n) (RBSharedF11.claim14 n) (RBSharedF11.claim15 n) (RBSharedF11.claim16 n) (RBSharedF11.claim17 n) (RBSharedF11.claim18 n) (RBSharedF11.claim19 n) (RBSharedF11.claim20 n) (RBSharedF11.claim21 n) (RBSharedF11.claim22 n) (RBSharedF11.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard12 : ∀ a n, Required 12 a n → (actualMarked 12 (a+1)).coeff n < (actualMarked 12 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 12 b n → (actualMarked 12 (b+1)).coeff n < (actualMarked 12 b).coeff n)
   (RBSharedF12.claim2 n) (RBSharedF12.claim3 n) (RBSharedF12.claim4 n) (RBSharedF12.claim5 n) (RBSharedF12.claim6 n) (RBSharedF12.claim7 n) (RBSharedF12.claim8 n) (RBSharedF12.claim9 n) (RBSharedF12.claim10 n) (RBSharedF12.claim11 n) (RBSharedF12.claim12 n) (RBSharedF12.claim13 n) (RBSharedF12.claim14 n) (RBSharedF12.claim15 n) (RBSharedF12.claim16 n) (RBSharedF12.claim17 n) (RBSharedF12.claim18 n) (RBSharedF12.claim19 n) (RBSharedF12.claim20 n) (RBSharedF12.claim21 n) (RBSharedF12.claim22 n) (RBSharedF12.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard13 : ∀ a n, Required 13 a n → (actualMarked 13 (a+1)).coeff n < (actualMarked 13 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 13 b n → (actualMarked 13 (b+1)).coeff n < (actualMarked 13 b).coeff n)
   (RBSharedF13.claim2 n) (RBSharedF13.claim3 n) (RBSharedF13.claim4 n) (RBSharedF13.claim5 n) (RBSharedF13.claim6 n) (RBSharedF13.claim7 n) (RBSharedF13.claim8 n) (RBSharedF13.claim9 n) (RBSharedF13.claim10 n) (RBSharedF13.claim11 n) (RBSharedF13.claim12 n) (RBSharedF13.claim13 n) (RBSharedF13.claim14 n) (RBSharedF13.claim15 n) (RBSharedF13.claim16 n) (RBSharedF13.claim17 n) (RBSharedF13.claim18 n) (RBSharedF13.claim19 n) (RBSharedF13.claim20 n) (RBSharedF13.claim21 n) (RBSharedF13.claim22 n) (RBSharedF13.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard14 : ∀ a n, Required 14 a n → (actualMarked 14 (a+1)).coeff n < (actualMarked 14 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 14 b n → (actualMarked 14 (b+1)).coeff n < (actualMarked 14 b).coeff n)
   (RBSharedF14.claim2 n) (RBSharedF14.claim3 n) (RBSharedF14.claim4 n) (RBSharedF14.claim5 n) (RBSharedF14.claim6 n) (RBSharedF14.claim7 n) (RBSharedF14.claim8 n) (RBSharedF14.claim9 n) (RBSharedF14.claim10 n) (RBSharedF14.claim11 n) (RBSharedF14.claim12 n) (RBSharedF14.claim13 n) (RBSharedF14.claim14 n) (RBSharedF14.claim15 n) (RBSharedF14.claim16 n) (RBSharedF14.claim17 n) (RBSharedF14.claim18 n) (RBSharedF14.claim19 n) (RBSharedF14.claim20 n) (RBSharedF14.claim21 n) (RBSharedF14.claim22 n) (RBSharedF14.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard15 : ∀ a n, Required 15 a n → (actualMarked 15 (a+1)).coeff n < (actualMarked 15 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 15 b n → (actualMarked 15 (b+1)).coeff n < (actualMarked 15 b).coeff n)
   (RBSharedF15.claim2 n) (RBSharedF15.claim3 n) (RBSharedF15.claim4 n) (RBSharedF15.claim5 n) (RBSharedF15.claim6 n) (RBSharedF15.claim7 n) (RBSharedF15.claim8 n) (RBSharedF15.claim9 n) (RBSharedF15.claim10 n) (RBSharedF15.claim11 n) (RBSharedF15.claim12 n) (RBSharedF15.claim13 n) (RBSharedF15.claim14 n) (RBSharedF15.claim15 n) (RBSharedF15.claim16 n) (RBSharedF15.claim17 n) (RBSharedF15.claim18 n) (RBSharedF15.claim19 n) (RBSharedF15.claim20 n) (RBSharedF15.claim21 n) (RBSharedF15.claim22 n) (RBSharedF15.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard16 : ∀ a n, Required 16 a n → (actualMarked 16 (a+1)).coeff n < (actualMarked 16 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 16 b n → (actualMarked 16 (b+1)).coeff n < (actualMarked 16 b).coeff n)
   (RBSharedF16.claim2 n) (RBSharedF16.claim3 n) (RBSharedF16.claim4 n) (RBSharedF16.claim5 n) (RBSharedF16.claim6 n) (RBSharedF16.claim7 n) (RBSharedF16.claim8 n) (RBSharedF16.claim9 n) (RBSharedF16.claim10 n) (RBSharedF16.claim11 n) (RBSharedF16.claim12 n) (RBSharedF16.claim13 n) (RBSharedF16.claim14 n) (RBSharedF16.claim15 n) (RBSharedF16.claim16 n) (RBSharedF16.claim17 n) (RBSharedF16.claim18 n) (RBSharedF16.claim19 n) (RBSharedF16.claim20 n) (RBSharedF16.claim21 n) (RBSharedF16.claim22 n) (RBSharedF16.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard17 : ∀ a n, Required 17 a n → (actualMarked 17 (a+1)).coeff n < (actualMarked 17 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 17 b n → (actualMarked 17 (b+1)).coeff n < (actualMarked 17 b).coeff n)
   (RBSharedF17.claim2 n) (RBSharedF17.claim3 n) (RBSharedF17.claim4 n) (RBSharedF17.claim5 n) (RBSharedF17.claim6 n) (RBSharedF17.claim7 n) (RBSharedF17.claim8 n) (RBSharedF17.claim9 n) (RBSharedF17.claim10 n) (RBSharedF17.claim11 n) (RBSharedF17.claim12 n) (RBSharedF17.claim13 n) (RBSharedF17.claim14 n) (RBSharedF17.claim15 n) (RBSharedF17.claim16 n) (RBSharedF17.claim17 n) (RBSharedF17.claim18 n) (RBSharedF17.claim19 n) (RBSharedF17.claim20 n) (RBSharedF17.claim21 n) (RBSharedF17.claim22 n) (RBSharedF17.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard18 : ∀ a n, Required 18 a n → (actualMarked 18 (a+1)).coeff n < (actualMarked 18 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 18 b n → (actualMarked 18 (b+1)).coeff n < (actualMarked 18 b).coeff n)
   (RBSharedF18.claim2 n) (RBSharedF18.claim3 n) (RBSharedF18.claim4 n) (RBSharedF18.claim5 n) (RBSharedF18.claim6 n) (RBSharedF18.claim7 n) (RBSharedF18.claim8 n) (RBSharedF18.claim9 n) (RBSharedF18.claim10 n) (RBSharedF18.claim11 n) (RBSharedF18.claim12 n) (RBSharedF18.claim13 n) (RBSharedF18.claim14 n) (RBSharedF18.claim15 n) (RBSharedF18.claim16 n) (RBSharedF18.claim17 n) (RBSharedF18.claim18 n) (RBSharedF18.claim19 n) (RBSharedF18.claim20 n) (RBSharedF18.claim21 n) (RBSharedF18.claim22 n) (RBSharedF18.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard19 : ∀ a n, Required 19 a n → (actualMarked 19 (a+1)).coeff n < (actualMarked 19 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 19 b n → (actualMarked 19 (b+1)).coeff n < (actualMarked 19 b).coeff n)
   (RBSharedF19.claim2 n) (RBSharedF19.claim3 n) (RBSharedF19.claim4 n) (RBSharedF19.claim5 n) (RBSharedF19.claim6 n) (RBSharedF19.claim7 n) (RBSharedF19.claim8 n) (RBSharedF19.claim9 n) (RBSharedF19.claim10 n) (RBSharedF19.claim11 n) (RBSharedF19.claim12 n) (RBSharedF19.claim13 n) (RBSharedF19.claim14 n) (RBSharedF19.claim15 n) (RBSharedF19.claim16 n) (RBSharedF19.claim17 n) (RBSharedF19.claim18 n) (RBSharedF19.claim19 n) (RBSharedF19.claim20 n) (RBSharedF19.claim21 n) (RBSharedF19.claim22 n) (RBSharedF19.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard20 : ∀ a n, Required 20 a n → (actualMarked 20 (a+1)).coeff n < (actualMarked 20 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 20 b n → (actualMarked 20 (b+1)).coeff n < (actualMarked 20 b).coeff n)
   (RBSharedF20.claim2 n) (RBSharedF20.claim3 n) (RBSharedF20.claim4 n) (RBSharedF20.claim5 n) (RBSharedF20.claim6 n) (RBSharedF20.claim7 n) (RBSharedF20.claim8 n) (RBSharedF20.claim9 n) (RBSharedF20.claim10 n) (RBSharedF20.claim11 n) (RBSharedF20.claim12 n) (RBSharedF20.claim13 n) (RBSharedF20.claim14 n) (RBSharedF20.claim15 n) (RBSharedF20.claim16 n) (RBSharedF20.claim17 n) (RBSharedF20.claim18 n) (RBSharedF20.claim19 n) (RBSharedF20.claim20 n) (RBSharedF20.claim21 n) (RBSharedF20.claim22 n) (RBSharedF20.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard21 : ∀ a n, Required 21 a n → (actualMarked 21 (a+1)).coeff n < (actualMarked 21 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 21 b n → (actualMarked 21 (b+1)).coeff n < (actualMarked 21 b).coeff n)
   (RBSharedF21.claim2 n) (RBSharedF21.claim3 n) (RBSharedF21.claim4 n) (RBSharedF21.claim5 n) (RBSharedF21.claim6 n) (RBSharedF21.claim7 n) (RBSharedF21.claim8 n) (RBSharedF21.claim9 n) (RBSharedF21.claim10 n) (RBSharedF21.claim11 n) (RBSharedF21.claim12 n) (RBSharedF21.claim13 n) (RBSharedF21.claim14 n) (RBSharedF21.claim15 n) (RBSharedF21.claim16 n) (RBSharedF21.claim17 n) (RBSharedF21.claim18 n) (RBSharedF21.claim19 n) (RBSharedF21.claim20 n) (RBSharedF21.claim21 n) (RBSharedF21.claim22 n) (RBSharedF21.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard22 : ∀ a n, Required 22 a n → (actualMarked 22 (a+1)).coeff n < (actualMarked 22 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 22 b n → (actualMarked 22 (b+1)).coeff n < (actualMarked 22 b).coeff n)
   (RBSharedF22.claim2 n) (RBSharedF22.claim3 n) (RBSharedF22.claim4 n) (RBSharedF22.claim5 n) (RBSharedF22.claim6 n) (RBSharedF22.claim7 n) (RBSharedF22.claim8 n) (RBSharedF22.claim9 n) (RBSharedF22.claim10 n) (RBSharedF22.claim11 n) (RBSharedF22.claim12 n) (RBSharedF22.claim13 n) (RBSharedF22.claim14 n) (RBSharedF22.claim15 n) (RBSharedF22.claim16 n) (RBSharedF22.claim17 n) (RBSharedF22.claim18 n) (RBSharedF22.claim19 n) (RBSharedF22.claim20 n) (RBSharedF22.claim21 n) (RBSharedF22.claim22 n) (RBSharedF22.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard23 : ∀ a n, Required 23 a n → (actualMarked 23 (a+1)).coeff n < (actualMarked 23 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 23 b n → (actualMarked 23 (b+1)).coeff n < (actualMarked 23 b).coeff n)
   (RBSharedF23.claim2 n) (RBSharedF23.claim3 n) (RBSharedF23.claim4 n) (RBSharedF23.claim5 n) (RBSharedF23.claim6 n) (RBSharedF23.claim7 n) (RBSharedF23.claim8 n) (RBSharedF23.claim9 n) (RBSharedF23.claim10 n) (RBSharedF23.claim11 n) (RBSharedF23.claim12 n) (RBSharedF23.claim13 n) (RBSharedF23.claim14 n) (RBSharedF23.claim15 n) (RBSharedF23.claim16 n) (RBSharedF23.claim17 n) (RBSharedF23.claim18 n) (RBSharedF23.claim19 n) (RBSharedF23.claim20 n) (RBSharedF23.claim21 n) (RBSharedF23.claim22 n) (RBSharedF23.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard24 : ∀ a n, Required 24 a n → (actualMarked 24 (a+1)).coeff n < (actualMarked 24 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 24 b n → (actualMarked 24 (b+1)).coeff n < (actualMarked 24 b).coeff n)
   (RBSharedF24.claim2 n) (RBSharedF24.claim3 n) (RBSharedF24.claim4 n) (RBSharedF24.claim5 n) (RBSharedF24.claim6 n) (RBSharedF24.claim7 n) (RBSharedF24.claim8 n) (RBSharedF24.claim9 n) (RBSharedF24.claim10 n) (RBSharedF24.claim11 n) (RBSharedF24.claim12 n) (RBSharedF24.claim13 n) (RBSharedF24.claim14 n) (RBSharedF24.claim15 n) (RBSharedF24.claim16 n) (RBSharedF24.claim17 n) (RBSharedF24.claim18 n) (RBSharedF24.claim19 n) (RBSharedF24.claim20 n) (RBSharedF24.claim21 n) (RBSharedF24.claim22 n) (RBSharedF24.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard25 : ∀ a n, Required 25 a n → (actualMarked 25 (a+1)).coeff n < (actualMarked 25 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 25 b n → (actualMarked 25 (b+1)).coeff n < (actualMarked 25 b).coeff n)
   (RBSharedF25.claim2 n) (RBSharedF25.claim3 n) (RBSharedF25.claim4 n) (RBSharedF25.claim5 n) (RBSharedF25.claim6 n) (RBSharedF25.claim7 n) (RBSharedF25.claim8 n) (RBSharedF25.claim9 n) (RBSharedF25.claim10 n) (RBSharedF25.claim11 n) (RBSharedF25.claim12 n) (RBSharedF25.claim13 n) (RBSharedF25.claim14 n) (RBSharedF25.claim15 n) (RBSharedF25.claim16 n) (RBSharedF25.claim17 n) (RBSharedF25.claim18 n) (RBSharedF25.claim19 n) (RBSharedF25.claim20 n) (RBSharedF25.claim21 n) (RBSharedF25.claim22 n) (RBSharedF25.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard26 : ∀ a n, Required 26 a n → (actualMarked 26 (a+1)).coeff n < (actualMarked 26 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 26 b n → (actualMarked 26 (b+1)).coeff n < (actualMarked 26 b).coeff n)
   (RBSharedF26.claim2 n) (RBSharedF26.claim3 n) (RBSharedF26.claim4 n) (RBSharedF26.claim5 n) (RBSharedF26.claim6 n) (RBSharedF26.claim7 n) (RBSharedF26.claim8 n) (RBSharedF26.claim9 n) (RBSharedF26.claim10 n) (RBSharedF26.claim11 n) (RBSharedF26.claim12 n) (RBSharedF26.claim13 n) (RBSharedF26.claim14 n) (RBSharedF26.claim15 n) (RBSharedF26.claim16 n) (RBSharedF26.claim17 n) (RBSharedF26.claim18 n) (RBSharedF26.claim19 n) (RBSharedF26.claim20 n) (RBSharedF26.claim21 n) (RBSharedF26.claim22 n) (RBSharedF26.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard27 : ∀ a n, Required 27 a n → (actualMarked 27 (a+1)).coeff n < (actualMarked 27 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 27 b n → (actualMarked 27 (b+1)).coeff n < (actualMarked 27 b).coeff n)
   (RBSharedF27.claim2 n) (RBSharedF27.claim3 n) (RBSharedF27.claim4 n) (RBSharedF27.claim5 n) (RBSharedF27.claim6 n) (RBSharedF27.claim7 n) (RBSharedF27.claim8 n) (RBSharedF27.claim9 n) (RBSharedF27.claim10 n) (RBSharedF27.claim11 n) (RBSharedF27.claim12 n) (RBSharedF27.claim13 n) (RBSharedF27.claim14 n) (RBSharedF27.claim15 n) (RBSharedF27.claim16 n) (RBSharedF27.claim17 n) (RBSharedF27.claim18 n) (RBSharedF27.claim19 n) (RBSharedF27.claim20 n) (RBSharedF27.claim21 n) (RBSharedF27.claim22 n) (RBSharedF27.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard28 : ∀ a n, Required 28 a n → (actualMarked 28 (a+1)).coeff n < (actualMarked 28 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 28 b n → (actualMarked 28 (b+1)).coeff n < (actualMarked 28 b).coeff n)
   (RBSharedF28.claim2 n) (RBSharedF28.claim3 n) (RBSharedF28.claim4 n) (RBSharedF28.claim5 n) (RBSharedF28.claim6 n) (RBSharedF28.claim7 n) (RBSharedF28.claim8 n) (RBSharedF28.claim9 n) (RBSharedF28.claim10 n) (RBSharedF28.claim11 n) (RBSharedF28.claim12 n) (RBSharedF28.claim13 n) (RBSharedF28.claim14 n) (RBSharedF28.claim15 n) (RBSharedF28.claim16 n) (RBSharedF28.claim17 n) (RBSharedF28.claim18 n) (RBSharedF28.claim19 n) (RBSharedF28.claim20 n) (RBSharedF28.claim21 n) (RBSharedF28.claim22 n) (RBSharedF28.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard29 : ∀ a n, Required 29 a n → (actualMarked 29 (a+1)).coeff n < (actualMarked 29 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 29 b n → (actualMarked 29 (b+1)).coeff n < (actualMarked 29 b).coeff n)
   (RBSharedF29.claim2 n) (RBSharedF29.claim3 n) (RBSharedF29.claim4 n) (RBSharedF29.claim5 n) (RBSharedF29.claim6 n) (RBSharedF29.claim7 n) (RBSharedF29.claim8 n) (RBSharedF29.claim9 n) (RBSharedF29.claim10 n) (RBSharedF29.claim11 n) (RBSharedF29.claim12 n) (RBSharedF29.claim13 n) (RBSharedF29.claim14 n) (RBSharedF29.claim15 n) (RBSharedF29.claim16 n) (RBSharedF29.claim17 n) (RBSharedF29.claim18 n) (RBSharedF29.claim19 n) (RBSharedF29.claim20 n) (RBSharedF29.claim21 n) (RBSharedF29.claim22 n) (RBSharedF29.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard30 : ∀ a n, Required 30 a n → (actualMarked 30 (a+1)).coeff n < (actualMarked 30 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 30 b n → (actualMarked 30 (b+1)).coeff n < (actualMarked 30 b).coeff n)
   (RBSharedF30.claim2 n) (RBSharedF30.claim3 n) (RBSharedF30.claim4 n) (RBSharedF30.claim5 n) (RBSharedF30.claim6 n) (RBSharedF30.claim7 n) (RBSharedF30.claim8 n) (RBSharedF30.claim9 n) (RBSharedF30.claim10 n) (RBSharedF30.claim11 n) (RBSharedF30.claim12 n) (RBSharedF30.claim13 n) (RBSharedF30.claim14 n) (RBSharedF30.claim15 n) (RBSharedF30.claim16 n) (RBSharedF30.claim17 n) (RBSharedF30.claim18 n) (RBSharedF30.claim19 n) (RBSharedF30.claim20 n) (RBSharedF30.claim21 n) (RBSharedF30.claim22 n) (RBSharedF30.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard31 : ∀ a n, Required 31 a n → (actualMarked 31 (a+1)).coeff n < (actualMarked 31 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 31 b n → (actualMarked 31 (b+1)).coeff n < (actualMarked 31 b).coeff n)
   (RBSharedF31.claim2 n) (RBSharedF31.claim3 n) (RBSharedF31.claim4 n) (RBSharedF31.claim5 n) (RBSharedF31.claim6 n) (RBSharedF31.claim7 n) (RBSharedF31.claim8 n) (RBSharedF31.claim9 n) (RBSharedF31.claim10 n) (RBSharedF31.claim11 n) (RBSharedF31.claim12 n) (RBSharedF31.claim13 n) (RBSharedF31.claim14 n) (RBSharedF31.claim15 n) (RBSharedF31.claim16 n) (RBSharedF31.claim17 n) (RBSharedF31.claim18 n) (RBSharedF31.claim19 n) (RBSharedF31.claim20 n) (RBSharedF31.claim21 n) (RBSharedF31.claim22 n) (RBSharedF31.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard32 : ∀ a n, Required 32 a n → (actualMarked 32 (a+1)).coeff n < (actualMarked 32 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 32 b n → (actualMarked 32 (b+1)).coeff n < (actualMarked 32 b).coeff n)
   (RBSharedF32.claim2 n) (RBSharedF32.claim3 n) (RBSharedF32.claim4 n) (RBSharedF32.claim5 n) (RBSharedF32.claim6 n) (RBSharedF32.claim7 n) (RBSharedF32.claim8 n) (RBSharedF32.claim9 n) (RBSharedF32.claim10 n) (RBSharedF32.claim11 n) (RBSharedF32.claim12 n) (RBSharedF32.claim13 n) (RBSharedF32.claim14 n) (RBSharedF32.claim15 n) (RBSharedF32.claim16 n) (RBSharedF32.claim17 n) (RBSharedF32.claim18 n) (RBSharedF32.claim19 n) (RBSharedF32.claim20 n) (RBSharedF32.claim21 n) (RBSharedF32.claim22 n) (RBSharedF32.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard33 : ∀ a n, Required 33 a n → (actualMarked 33 (a+1)).coeff n < (actualMarked 33 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 33 b n → (actualMarked 33 (b+1)).coeff n < (actualMarked 33 b).coeff n)
   (RBSharedF33.claim2 n) (RBSharedF33.claim3 n) (RBSharedF33.claim4 n) (RBSharedF33.claim5 n) (RBSharedF33.claim6 n) (RBSharedF33.claim7 n) (RBSharedF33.claim8 n) (RBSharedF33.claim9 n) (RBSharedF33.claim10 n) (RBSharedF33.claim11 n) (RBSharedF33.claim12 n) (RBSharedF33.claim13 n) (RBSharedF33.claim14 n) (RBSharedF33.claim15 n) (RBSharedF33.claim16 n) (RBSharedF33.claim17 n) (RBSharedF33.claim18 n) (RBSharedF33.claim19 n) (RBSharedF33.claim20 n) (RBSharedF33.claim21 n) (RBSharedF33.claim22 n) (RBSharedF33.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard34 : ∀ a n, Required 34 a n → (actualMarked 34 (a+1)).coeff n < (actualMarked 34 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 34 b n → (actualMarked 34 (b+1)).coeff n < (actualMarked 34 b).coeff n)
   (RBSharedF34.claim2 n) (RBSharedF34.claim3 n) (RBSharedF34.claim4 n) (RBSharedF34.claim5 n) (RBSharedF34.claim6 n) (RBSharedF34.claim7 n) (RBSharedF34.claim8 n) (RBSharedF34.claim9 n) (RBSharedF34.claim10 n) (RBSharedF34.claim11 n) (RBSharedF34.claim12 n) (RBSharedF34.claim13 n) (RBSharedF34.claim14 n) (RBSharedF34.claim15 n) (RBSharedF34.claim16 n) (RBSharedF34.claim17 n) (RBSharedF34.claim18 n) (RBSharedF34.claim19 n) (RBSharedF34.claim20 n) (RBSharedF34.claim21 n) (RBSharedF34.claim22 n) (RBSharedF34.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard35 : ∀ a n, Required 35 a n → (actualMarked 35 (a+1)).coeff n < (actualMarked 35 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 35 b n → (actualMarked 35 (b+1)).coeff n < (actualMarked 35 b).coeff n)
   (RBSharedF35.claim2 n) (RBSharedF35.claim3 n) (RBSharedF35.claim4 n) (RBSharedF35.claim5 n) (RBSharedF35.claim6 n) (RBSharedF35.claim7 n) (RBSharedF35.claim8 n) (RBSharedF35.claim9 n) (RBSharedF35.claim10 n) (RBSharedF35.claim11 n) (RBSharedF35.claim12 n) (RBSharedF35.claim13 n) (RBSharedF35.claim14 n) (RBSharedF35.claim15 n) (RBSharedF35.claim16 n) (RBSharedF35.claim17 n) (RBSharedF35.claim18 n) (RBSharedF35.claim19 n) (RBSharedF35.claim20 n) (RBSharedF35.claim21 n) (RBSharedF35.claim22 n) (RBSharedF35.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard36 : ∀ a n, Required 36 a n → (actualMarked 36 (a+1)).coeff n < (actualMarked 36 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 36 b n → (actualMarked 36 (b+1)).coeff n < (actualMarked 36 b).coeff n)
   (RBSharedF36.claim2 n) (RBSharedF36.claim3 n) (RBSharedF36.claim4 n) (RBSharedF36.claim5 n) (RBSharedF36.claim6 n) (RBSharedF36.claim7 n) (RBSharedF36.claim8 n) (RBSharedF36.claim9 n) (RBSharedF36.claim10 n) (RBSharedF36.claim11 n) (RBSharedF36.claim12 n) (RBSharedF36.claim13 n) (RBSharedF36.claim14 n) (RBSharedF36.claim15 n) (RBSharedF36.claim16 n) (RBSharedF36.claim17 n) (RBSharedF36.claim18 n) (RBSharedF36.claim19 n) (RBSharedF36.claim20 n) (RBSharedF36.claim21 n) (RBSharedF36.claim22 n) (RBSharedF36.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard37 : ∀ a n, Required 37 a n → (actualMarked 37 (a+1)).coeff n < (actualMarked 37 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 37 b n → (actualMarked 37 (b+1)).coeff n < (actualMarked 37 b).coeff n)
   (RBSharedF37.claim2 n) (RBSharedF37.claim3 n) (RBSharedF37.claim4 n) (RBSharedF37.claim5 n) (RBSharedF37.claim6 n) (RBSharedF37.claim7 n) (RBSharedF37.claim8 n) (RBSharedF37.claim9 n) (RBSharedF37.claim10 n) (RBSharedF37.claim11 n) (RBSharedF37.claim12 n) (RBSharedF37.claim13 n) (RBSharedF37.claim14 n) (RBSharedF37.claim15 n) (RBSharedF37.claim16 n) (RBSharedF37.claim17 n) (RBSharedF37.claim18 n) (RBSharedF37.claim19 n) (RBSharedF37.claim20 n) (RBSharedF37.claim21 n) (RBSharedF37.claim22 n) (RBSharedF37.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard38 : ∀ a n, Required 38 a n → (actualMarked 38 (a+1)).coeff n < (actualMarked 38 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 38 b n → (actualMarked 38 (b+1)).coeff n < (actualMarked 38 b).coeff n)
   (RBSharedF38.claim2 n) (RBSharedF38.claim3 n) (RBSharedF38.claim4 n) (RBSharedF38.claim5 n) (RBSharedF38.claim6 n) (RBSharedF38.claim7 n) (RBSharedF38.claim8 n) (RBSharedF38.claim9 n) (RBSharedF38.claim10 n) (RBSharedF38.claim11 n) (RBSharedF38.claim12 n) (RBSharedF38.claim13 n) (RBSharedF38.claim14 n) (RBSharedF38.claim15 n) (RBSharedF38.claim16 n) (RBSharedF38.claim17 n) (RBSharedF38.claim18 n) (RBSharedF38.claim19 n) (RBSharedF38.claim20 n) (RBSharedF38.claim21 n) (RBSharedF38.claim22 n) (RBSharedF38.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard39 : ∀ a n, Required 39 a n → (actualMarked 39 (a+1)).coeff n < (actualMarked 39 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 39 b n → (actualMarked 39 (b+1)).coeff n < (actualMarked 39 b).coeff n)
   (RBSharedF39.claim2 n) (RBSharedF39.claim3 n) (RBSharedF39.claim4 n) (RBSharedF39.claim5 n) (RBSharedF39.claim6 n) (RBSharedF39.claim7 n) (RBSharedF39.claim8 n) (RBSharedF39.claim9 n) (RBSharedF39.claim10 n) (RBSharedF39.claim11 n) (RBSharedF39.claim12 n) (RBSharedF39.claim13 n) (RBSharedF39.claim14 n) (RBSharedF39.claim15 n) (RBSharedF39.claim16 n) (RBSharedF39.claim17 n) (RBSharedF39.claim18 n) (RBSharedF39.claim19 n) (RBSharedF39.claim20 n) (RBSharedF39.claim21 n) (RBSharedF39.claim22 n) (RBSharedF39.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard40 : ∀ a n, Required 40 a n → (actualMarked 40 (a+1)).coeff n < (actualMarked 40 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 40 b n → (actualMarked 40 (b+1)).coeff n < (actualMarked 40 b).coeff n)
   (RBSharedF40.claim2 n) (RBSharedF40.claim3 n) (RBSharedF40.claim4 n) (RBSharedF40.claim5 n) (RBSharedF40.claim6 n) (RBSharedF40.claim7 n) (RBSharedF40.claim8 n) (RBSharedF40.claim9 n) (RBSharedF40.claim10 n) (RBSharedF40.claim11 n) (RBSharedF40.claim12 n) (RBSharedF40.claim13 n) (RBSharedF40.claim14 n) (RBSharedF40.claim15 n) (RBSharedF40.claim16 n) (RBSharedF40.claim17 n) (RBSharedF40.claim18 n) (RBSharedF40.claim19 n) (RBSharedF40.claim20 n) (RBSharedF40.claim21 n) (RBSharedF40.claim22 n) (RBSharedF40.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard41 : ∀ a n, Required 41 a n → (actualMarked 41 (a+1)).coeff n < (actualMarked 41 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 41 b n → (actualMarked 41 (b+1)).coeff n < (actualMarked 41 b).coeff n)
   (RBSharedF41.claim2 n) (RBSharedF41.claim3 n) (RBSharedF41.claim4 n) (RBSharedF41.claim5 n) (RBSharedF41.claim6 n) (RBSharedF41.claim7 n) (RBSharedF41.claim8 n) (RBSharedF41.claim9 n) (RBSharedF41.claim10 n) (RBSharedF41.claim11 n) (RBSharedF41.claim12 n) (RBSharedF41.claim13 n) (RBSharedF41.claim14 n) (RBSharedF41.claim15 n) (RBSharedF41.claim16 n) (RBSharedF41.claim17 n) (RBSharedF41.claim18 n) (RBSharedF41.claim19 n) (RBSharedF41.claim20 n) (RBSharedF41.claim21 n) (RBSharedF41.claim22 n) (RBSharedF41.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard42 : ∀ a n, Required 42 a n → (actualMarked 42 (a+1)).coeff n < (actualMarked 42 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 42 b n → (actualMarked 42 (b+1)).coeff n < (actualMarked 42 b).coeff n)
   (RBSharedF42.claim2 n) (RBSharedF42.claim3 n) (RBSharedF42.claim4 n) (RBSharedF42.claim5 n) (RBSharedF42.claim6 n) (RBSharedF42.claim7 n) (RBSharedF42.claim8 n) (RBSharedF42.claim9 n) (RBSharedF42.claim10 n) (RBSharedF42.claim11 n) (RBSharedF42.claim12 n) (RBSharedF42.claim13 n) (RBSharedF42.claim14 n) (RBSharedF42.claim15 n) (RBSharedF42.claim16 n) (RBSharedF42.claim17 n) (RBSharedF42.claim18 n) (RBSharedF42.claim19 n) (RBSharedF42.claim20 n) (RBSharedF42.claim21 n) (RBSharedF42.claim22 n) (RBSharedF42.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard43 : ∀ a n, Required 43 a n → (actualMarked 43 (a+1)).coeff n < (actualMarked 43 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 43 b n → (actualMarked 43 (b+1)).coeff n < (actualMarked 43 b).coeff n)
   (RBSharedF43.claim2 n) (RBSharedF43.claim3 n) (RBSharedF43.claim4 n) (RBSharedF43.claim5 n) (RBSharedF43.claim6 n) (RBSharedF43.claim7 n) (RBSharedF43.claim8 n) (RBSharedF43.claim9 n) (RBSharedF43.claim10 n) (RBSharedF43.claim11 n) (RBSharedF43.claim12 n) (RBSharedF43.claim13 n) (RBSharedF43.claim14 n) (RBSharedF43.claim15 n) (RBSharedF43.claim16 n) (RBSharedF43.claim17 n) (RBSharedF43.claim18 n) (RBSharedF43.claim19 n) (RBSharedF43.claim20 n) (RBSharedF43.claim21 n) (RBSharedF43.claim22 n) (RBSharedF43.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard44 : ∀ a n, Required 44 a n → (actualMarked 44 (a+1)).coeff n < (actualMarked 44 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 44 b n → (actualMarked 44 (b+1)).coeff n < (actualMarked 44 b).coeff n)
   (RBSharedF44.claim2 n) (RBSharedF44.claim3 n) (RBSharedF44.claim4 n) (RBSharedF44.claim5 n) (RBSharedF44.claim6 n) (RBSharedF44.claim7 n) (RBSharedF44.claim8 n) (RBSharedF44.claim9 n) (RBSharedF44.claim10 n) (RBSharedF44.claim11 n) (RBSharedF44.claim12 n) (RBSharedF44.claim13 n) (RBSharedF44.claim14 n) (RBSharedF44.claim15 n) (RBSharedF44.claim16 n) (RBSharedF44.claim17 n) (RBSharedF44.claim18 n) (RBSharedF44.claim19 n) (RBSharedF44.claim20 n) (RBSharedF44.claim21 n) (RBSharedF44.claim22 n) (RBSharedF44.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard45 : ∀ a n, Required 45 a n → (actualMarked 45 (a+1)).coeff n < (actualMarked 45 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 45 b n → (actualMarked 45 (b+1)).coeff n < (actualMarked 45 b).coeff n)
   (RBSharedF45.claim2 n) (RBSharedF45.claim3 n) (RBSharedF45.claim4 n) (RBSharedF45.claim5 n) (RBSharedF45.claim6 n) (RBSharedF45.claim7 n) (RBSharedF45.claim8 n) (RBSharedF45.claim9 n) (RBSharedF45.claim10 n) (RBSharedF45.claim11 n) (RBSharedF45.claim12 n) (RBSharedF45.claim13 n) (RBSharedF45.claim14 n) (RBSharedF45.claim15 n) (RBSharedF45.claim16 n) (RBSharedF45.claim17 n) (RBSharedF45.claim18 n) (RBSharedF45.claim19 n) (RBSharedF45.claim20 n) (RBSharedF45.claim21 n) (RBSharedF45.claim22 n) (RBSharedF45.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard46 : ∀ a n, Required 46 a n → (actualMarked 46 (a+1)).coeff n < (actualMarked 46 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 46 b n → (actualMarked 46 (b+1)).coeff n < (actualMarked 46 b).coeff n)
   (RBSharedF46.claim2 n) (RBSharedF46.claim3 n) (RBSharedF46.claim4 n) (RBSharedF46.claim5 n) (RBSharedF46.claim6 n) (RBSharedF46.claim7 n) (RBSharedF46.claim8 n) (RBSharedF46.claim9 n) (RBSharedF46.claim10 n) (RBSharedF46.claim11 n) (RBSharedF46.claim12 n) (RBSharedF46.claim13 n) (RBSharedF46.claim14 n) (RBSharedF46.claim15 n) (RBSharedF46.claim16 n) (RBSharedF46.claim17 n) (RBSharedF46.claim18 n) (RBSharedF46.claim19 n) (RBSharedF46.claim20 n) (RBSharedF46.claim21 n) (RBSharedF46.claim22 n) (RBSharedF46.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard47 : ∀ a n, Required 47 a n → (actualMarked 47 (a+1)).coeff n < (actualMarked 47 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 47 b n → (actualMarked 47 (b+1)).coeff n < (actualMarked 47 b).coeff n)
   (RBSharedF47.claim2 n) (RBSharedF47.claim3 n) (RBSharedF47.claim4 n) (RBSharedF47.claim5 n) (RBSharedF47.claim6 n) (RBSharedF47.claim7 n) (RBSharedF47.claim8 n) (RBSharedF47.claim9 n) (RBSharedF47.claim10 n) (RBSharedF47.claim11 n) (RBSharedF47.claim12 n) (RBSharedF47.claim13 n) (RBSharedF47.claim14 n) (RBSharedF47.claim15 n) (RBSharedF47.claim16 n) (RBSharedF47.claim17 n) (RBSharedF47.claim18 n) (RBSharedF47.claim19 n) (RBSharedF47.claim20 n) (RBSharedF47.claim21 n) (RBSharedF47.claim22 n) (RBSharedF47.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard48 : ∀ a n, Required 48 a n → (actualMarked 48 (a+1)).coeff n < (actualMarked 48 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 48 b n → (actualMarked 48 (b+1)).coeff n < (actualMarked 48 b).coeff n)
   (RBSharedF48.claim2 n) (RBSharedF48.claim3 n) (RBSharedF48.claim4 n) (RBSharedF48.claim5 n) (RBSharedF48.claim6 n) (RBSharedF48.claim7 n) (RBSharedF48.claim8 n) (RBSharedF48.claim9 n) (RBSharedF48.claim10 n) (RBSharedF48.claim11 n) (RBSharedF48.claim12 n) (RBSharedF48.claim13 n) (RBSharedF48.claim14 n) (RBSharedF48.claim15 n) (RBSharedF48.claim16 n) (RBSharedF48.claim17 n) (RBSharedF48.claim18 n) (RBSharedF48.claim19 n) (RBSharedF48.claim20 n) (RBSharedF48.claim21 n) (RBSharedF48.claim22 n) (RBSharedF48.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard49 : ∀ a n, Required 49 a n → (actualMarked 49 (a+1)).coeff n < (actualMarked 49 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 49 b n → (actualMarked 49 (b+1)).coeff n < (actualMarked 49 b).coeff n)
   (RBSharedF49.claim2 n) (RBSharedF49.claim3 n) (RBSharedF49.claim4 n) (RBSharedF49.claim5 n) (RBSharedF49.claim6 n) (RBSharedF49.claim7 n) (RBSharedF49.claim8 n) (RBSharedF49.claim9 n) (RBSharedF49.claim10 n) (RBSharedF49.claim11 n) (RBSharedF49.claim12 n) (RBSharedF49.claim13 n) (RBSharedF49.claim14 n) (RBSharedF49.claim15 n) (RBSharedF49.claim16 n) (RBSharedF49.claim17 n) (RBSharedF49.claim18 n) (RBSharedF49.claim19 n) (RBSharedF49.claim20 n) (RBSharedF49.claim21 n) (RBSharedF49.claim22 n) (RBSharedF49.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard50 : ∀ a n, Required 50 a n → (actualMarked 50 (a+1)).coeff n < (actualMarked 50 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 50 b n → (actualMarked 50 (b+1)).coeff n < (actualMarked 50 b).coeff n)
   (RBSharedF50.claim2 n) (RBSharedF50.claim3 n) (RBSharedF50.claim4 n) (RBSharedF50.claim5 n) (RBSharedF50.claim6 n) (RBSharedF50.claim7 n) (RBSharedF50.claim8 n) (RBSharedF50.claim9 n) (RBSharedF50.claim10 n) (RBSharedF50.claim11 n) (RBSharedF50.claim12 n) (RBSharedF50.claim13 n) (RBSharedF50.claim14 n) (RBSharedF50.claim15 n) (RBSharedF50.claim16 n) (RBSharedF50.claim17 n) (RBSharedF50.claim18 n) (RBSharedF50.claim19 n) (RBSharedF50.claim20 n) (RBSharedF50.claim21 n) (RBSharedF50.claim22 n) (RBSharedF50.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard51 : ∀ a n, Required 51 a n → (actualMarked 51 (a+1)).coeff n < (actualMarked 51 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 51 b n → (actualMarked 51 (b+1)).coeff n < (actualMarked 51 b).coeff n)
   (RBSharedF51.claim2 n) (RBSharedF51.claim3 n) (RBSharedF51.claim4 n) (RBSharedF51.claim5 n) (RBSharedF51.claim6 n) (RBSharedF51.claim7 n) (RBSharedF51.claim8 n) (RBSharedF51.claim9 n) (RBSharedF51.claim10 n) (RBSharedF51.claim11 n) (RBSharedF51.claim12 n) (RBSharedF51.claim13 n) (RBSharedF51.claim14 n) (RBSharedF51.claim15 n) (RBSharedF51.claim16 n) (RBSharedF51.claim17 n) (RBSharedF51.claim18 n) (RBSharedF51.claim19 n) (RBSharedF51.claim20 n) (RBSharedF51.claim21 n) (RBSharedF51.claim22 n) (RBSharedF51.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard52 : ∀ a n, Required 52 a n → (actualMarked 52 (a+1)).coeff n < (actualMarked 52 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 52 b n → (actualMarked 52 (b+1)).coeff n < (actualMarked 52 b).coeff n)
   (RBSharedF52.claim2 n) (RBSharedF52.claim3 n) (RBSharedF52.claim4 n) (RBSharedF52.claim5 n) (RBSharedF52.claim6 n) (RBSharedF52.claim7 n) (RBSharedF52.claim8 n) (RBSharedF52.claim9 n) (RBSharedF52.claim10 n) (RBSharedF52.claim11 n) (RBSharedF52.claim12 n) (RBSharedF52.claim13 n) (RBSharedF52.claim14 n) (RBSharedF52.claim15 n) (RBSharedF52.claim16 n) (RBSharedF52.claim17 n) (RBSharedF52.claim18 n) (RBSharedF52.claim19 n) (RBSharedF52.claim20 n) (RBSharedF52.claim21 n) (RBSharedF52.claim22 n) (RBSharedF52.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard53 : ∀ a n, Required 53 a n → (actualMarked 53 (a+1)).coeff n < (actualMarked 53 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 53 b n → (actualMarked 53 (b+1)).coeff n < (actualMarked 53 b).coeff n)
   (RBSharedF53.claim2 n) (RBSharedF53.claim3 n) (RBSharedF53.claim4 n) (RBSharedF53.claim5 n) (RBSharedF53.claim6 n) (RBSharedF53.claim7 n) (RBSharedF53.claim8 n) (RBSharedF53.claim9 n) (RBSharedF53.claim10 n) (RBSharedF53.claim11 n) (RBSharedF53.claim12 n) (RBSharedF53.claim13 n) (RBSharedF53.claim14 n) (RBSharedF53.claim15 n) (RBSharedF53.claim16 n) (RBSharedF53.claim17 n) (RBSharedF53.claim18 n) (RBSharedF53.claim19 n) (RBSharedF53.claim20 n) (RBSharedF53.claim21 n) (RBSharedF53.claim22 n) (RBSharedF53.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard54 : ∀ a n, Required 54 a n → (actualMarked 54 (a+1)).coeff n < (actualMarked 54 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 54 b n → (actualMarked 54 (b+1)).coeff n < (actualMarked 54 b).coeff n)
   (RBSharedF54.claim2 n) (RBSharedF54.claim3 n) (RBSharedF54.claim4 n) (RBSharedF54.claim5 n) (RBSharedF54.claim6 n) (RBSharedF54.claim7 n) (RBSharedF54.claim8 n) (RBSharedF54.claim9 n) (RBSharedF54.claim10 n) (RBSharedF54.claim11 n) (RBSharedF54.claim12 n) (RBSharedF54.claim13 n) (RBSharedF54.claim14 n) (RBSharedF54.claim15 n) (RBSharedF54.claim16 n) (RBSharedF54.claim17 n) (RBSharedF54.claim18 n) (RBSharedF54.claim19 n) (RBSharedF54.claim20 n) (RBSharedF54.claim21 n) (RBSharedF54.claim22 n) (RBSharedF54.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard55 : ∀ a n, Required 55 a n → (actualMarked 55 (a+1)).coeff n < (actualMarked 55 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 55 b n → (actualMarked 55 (b+1)).coeff n < (actualMarked 55 b).coeff n)
   (RBSharedF55.claim2 n) (RBSharedF55.claim3 n) (RBSharedF55.claim4 n) (RBSharedF55.claim5 n) (RBSharedF55.claim6 n) (RBSharedF55.claim7 n) (RBSharedF55.claim8 n) (RBSharedF55.claim9 n) (RBSharedF55.claim10 n) (RBSharedF55.claim11 n) (RBSharedF55.claim12 n) (RBSharedF55.claim13 n) (RBSharedF55.claim14 n) (RBSharedF55.claim15 n) (RBSharedF55.claim16 n) (RBSharedF55.claim17 n) (RBSharedF55.claim18 n) (RBSharedF55.claim19 n) (RBSharedF55.claim20 n) (RBSharedF55.claim21 n) (RBSharedF55.claim22 n) (RBSharedF55.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard56 : ∀ a n, Required 56 a n → (actualMarked 56 (a+1)).coeff n < (actualMarked 56 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 56 b n → (actualMarked 56 (b+1)).coeff n < (actualMarked 56 b).coeff n)
   (RBSharedF56.claim2 n) (RBSharedF56.claim3 n) (RBSharedF56.claim4 n) (RBSharedF56.claim5 n) (RBSharedF56.claim6 n) (RBSharedF56.claim7 n) (RBSharedF56.claim8 n) (RBSharedF56.claim9 n) (RBSharedF56.claim10 n) (RBSharedF56.claim11 n) (RBSharedF56.claim12 n) (RBSharedF56.claim13 n) (RBSharedF56.claim14 n) (RBSharedF56.claim15 n) (RBSharedF56.claim16 n) (RBSharedF56.claim17 n) (RBSharedF56.claim18 n) (RBSharedF56.claim19 n) (RBSharedF56.claim20 n) (RBSharedF56.claim21 n) (RBSharedF56.claim22 n) (RBSharedF56.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard57 : ∀ a n, Required 57 a n → (actualMarked 57 (a+1)).coeff n < (actualMarked 57 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 57 b n → (actualMarked 57 (b+1)).coeff n < (actualMarked 57 b).coeff n)
   (RBSharedF57.claim2 n) (RBSharedF57.claim3 n) (RBSharedF57.claim4 n) (RBSharedF57.claim5 n) (RBSharedF57.claim6 n) (RBSharedF57.claim7 n) (RBSharedF57.claim8 n) (RBSharedF57.claim9 n) (RBSharedF57.claim10 n) (RBSharedF57.claim11 n) (RBSharedF57.claim12 n) (RBSharedF57.claim13 n) (RBSharedF57.claim14 n) (RBSharedF57.claim15 n) (RBSharedF57.claim16 n) (RBSharedF57.claim17 n) (RBSharedF57.claim18 n) (RBSharedF57.claim19 n) (RBSharedF57.claim20 n) (RBSharedF57.claim21 n) (RBSharedF57.claim22 n) (RBSharedF57.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard58 : ∀ a n, Required 58 a n → (actualMarked 58 (a+1)).coeff n < (actualMarked 58 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 58 b n → (actualMarked 58 (b+1)).coeff n < (actualMarked 58 b).coeff n)
   (RBSharedF58.claim2 n) (RBSharedF58.claim3 n) (RBSharedF58.claim4 n) (RBSharedF58.claim5 n) (RBSharedF58.claim6 n) (RBSharedF58.claim7 n) (RBSharedF58.claim8 n) (RBSharedF58.claim9 n) (RBSharedF58.claim10 n) (RBSharedF58.claim11 n) (RBSharedF58.claim12 n) (RBSharedF58.claim13 n) (RBSharedF58.claim14 n) (RBSharedF58.claim15 n) (RBSharedF58.claim16 n) (RBSharedF58.claim17 n) (RBSharedF58.claim18 n) (RBSharedF58.claim19 n) (RBSharedF58.claim20 n) (RBSharedF58.claim21 n) (RBSharedF58.claim22 n) (RBSharedF58.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard59 : ∀ a n, Required 59 a n → (actualMarked 59 (a+1)).coeff n < (actualMarked 59 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 59 b n → (actualMarked 59 (b+1)).coeff n < (actualMarked 59 b).coeff n)
   (RBSharedF59.claim2 n) (RBSharedF59.claim3 n) (RBSharedF59.claim4 n) (RBSharedF59.claim5 n) (RBSharedF59.claim6 n) (RBSharedF59.claim7 n) (RBSharedF59.claim8 n) (RBSharedF59.claim9 n) (RBSharedF59.claim10 n) (RBSharedF59.claim11 n) (RBSharedF59.claim12 n) (RBSharedF59.claim13 n) (RBSharedF59.claim14 n) (RBSharedF59.claim15 n) (RBSharedF59.claim16 n) (RBSharedF59.claim17 n) (RBSharedF59.claim18 n) (RBSharedF59.claim19 n) (RBSharedF59.claim20 n) (RBSharedF59.claim21 n) (RBSharedF59.claim22 n) (RBSharedF59.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard60 : ∀ a n, Required 60 a n → (actualMarked 60 (a+1)).coeff n < (actualMarked 60 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 60 b n → (actualMarked 60 (b+1)).coeff n < (actualMarked 60 b).coeff n)
   (RBSharedF60.claim2 n) (RBSharedF60.claim3 n) (RBSharedF60.claim4 n) (RBSharedF60.claim5 n) (RBSharedF60.claim6 n) (RBSharedF60.claim7 n) (RBSharedF60.claim8 n) (RBSharedF60.claim9 n) (RBSharedF60.claim10 n) (RBSharedF60.claim11 n) (RBSharedF60.claim12 n) (RBSharedF60.claim13 n) (RBSharedF60.claim14 n) (RBSharedF60.claim15 n) (RBSharedF60.claim16 n) (RBSharedF60.claim17 n) (RBSharedF60.claim18 n) (RBSharedF60.claim19 n) (RBSharedF60.claim20 n) (RBSharedF60.claim21 n) (RBSharedF60.claim22 n) (RBSharedF60.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard61 : ∀ a n, Required 61 a n → (actualMarked 61 (a+1)).coeff n < (actualMarked 61 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 61 b n → (actualMarked 61 (b+1)).coeff n < (actualMarked 61 b).coeff n)
   (RBSharedF61.claim2 n) (RBSharedF61.claim3 n) (RBSharedF61.claim4 n) (RBSharedF61.claim5 n) (RBSharedF61.claim6 n) (RBSharedF61.claim7 n) (RBSharedF61.claim8 n) (RBSharedF61.claim9 n) (RBSharedF61.claim10 n) (RBSharedF61.claim11 n) (RBSharedF61.claim12 n) (RBSharedF61.claim13 n) (RBSharedF61.claim14 n) (RBSharedF61.claim15 n) (RBSharedF61.claim16 n) (RBSharedF61.claim17 n) (RBSharedF61.claim18 n) (RBSharedF61.claim19 n) (RBSharedF61.claim20 n) (RBSharedF61.claim21 n) (RBSharedF61.claim22 n) (RBSharedF61.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard62 : ∀ a n, Required 62 a n → (actualMarked 62 (a+1)).coeff n < (actualMarked 62 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 62 b n → (actualMarked 62 (b+1)).coeff n < (actualMarked 62 b).coeff n)
   (RBSharedF62.claim2 n) (RBSharedF62.claim3 n) (RBSharedF62.claim4 n) (RBSharedF62.claim5 n) (RBSharedF62.claim6 n) (RBSharedF62.claim7 n) (RBSharedF62.claim8 n) (RBSharedF62.claim9 n) (RBSharedF62.claim10 n) (RBSharedF62.claim11 n) (RBSharedF62.claim12 n) (RBSharedF62.claim13 n) (RBSharedF62.claim14 n) (RBSharedF62.claim15 n) (RBSharedF62.claim16 n) (RBSharedF62.claim17 n) (RBSharedF62.claim18 n) (RBSharedF62.claim19 n) (RBSharedF62.claim20 n) (RBSharedF62.claim21 n) (RBSharedF62.claim22 n) (RBSharedF62.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard63 : ∀ a n, Required 63 a n → (actualMarked 63 (a+1)).coeff n < (actualMarked 63 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 63 b n → (actualMarked 63 (b+1)).coeff n < (actualMarked 63 b).coeff n)
   (RBSharedF63.claim2 n) (RBSharedF63.claim3 n) (RBSharedF63.claim4 n) (RBSharedF63.claim5 n) (RBSharedF63.claim6 n) (RBSharedF63.claim7 n) (RBSharedF63.claim8 n) (RBSharedF63.claim9 n) (RBSharedF63.claim10 n) (RBSharedF63.claim11 n) (RBSharedF63.claim12 n) (RBSharedF63.claim13 n) (RBSharedF63.claim14 n) (RBSharedF63.claim15 n) (RBSharedF63.claim16 n) (RBSharedF63.claim17 n) (RBSharedF63.claim18 n) (RBSharedF63.claim19 n) (RBSharedF63.claim20 n) (RBSharedF63.claim21 n) (RBSharedF63.claim22 n) (RBSharedF63.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard64 : ∀ a n, Required 64 a n → (actualMarked 64 (a+1)).coeff n < (actualMarked 64 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 64 b n → (actualMarked 64 (b+1)).coeff n < (actualMarked 64 b).coeff n)
   (RBSharedF64.claim2 n) (RBSharedF64.claim3 n) (RBSharedF64.claim4 n) (RBSharedF64.claim5 n) (RBSharedF64.claim6 n) (RBSharedF64.claim7 n) (RBSharedF64.claim8 n) (RBSharedF64.claim9 n) (RBSharedF64.claim10 n) (RBSharedF64.claim11 n) (RBSharedF64.claim12 n) (RBSharedF64.claim13 n) (RBSharedF64.claim14 n) (RBSharedF64.claim15 n) (RBSharedF64.claim16 n) (RBSharedF64.claim17 n) (RBSharedF64.claim18 n) (RBSharedF64.claim19 n) (RBSharedF64.claim20 n) (RBSharedF64.claim21 n) (RBSharedF64.claim22 n) (RBSharedF64.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard65 : ∀ a n, Required 65 a n → (actualMarked 65 (a+1)).coeff n < (actualMarked 65 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 65 b n → (actualMarked 65 (b+1)).coeff n < (actualMarked 65 b).coeff n)
   (RBSharedF65.claim2 n) (RBSharedF65.claim3 n) (RBSharedF65.claim4 n) (RBSharedF65.claim5 n) (RBSharedF65.claim6 n) (RBSharedF65.claim7 n) (RBSharedF65.claim8 n) (RBSharedF65.claim9 n) (RBSharedF65.claim10 n) (RBSharedF65.claim11 n) (RBSharedF65.claim12 n) (RBSharedF65.claim13 n) (RBSharedF65.claim14 n) (RBSharedF65.claim15 n) (RBSharedF65.claim16 n) (RBSharedF65.claim17 n) (RBSharedF65.claim18 n) (RBSharedF65.claim19 n) (RBSharedF65.claim20 n) (RBSharedF65.claim21 n) (RBSharedF65.claim22 n) (RBSharedF65.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard66 : ∀ a n, Required 66 a n → (actualMarked 66 (a+1)).coeff n < (actualMarked 66 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 66 b n → (actualMarked 66 (b+1)).coeff n < (actualMarked 66 b).coeff n)
   (RBSharedF66.claim2 n) (RBSharedF66.claim3 n) (RBSharedF66.claim4 n) (RBSharedF66.claim5 n) (RBSharedF66.claim6 n) (RBSharedF66.claim7 n) (RBSharedF66.claim8 n) (RBSharedF66.claim9 n) (RBSharedF66.claim10 n) (RBSharedF66.claim11 n) (RBSharedF66.claim12 n) (RBSharedF66.claim13 n) (RBSharedF66.claim14 n) (RBSharedF66.claim15 n) (RBSharedF66.claim16 n) (RBSharedF66.claim17 n) (RBSharedF66.claim18 n) (RBSharedF66.claim19 n) (RBSharedF66.claim20 n) (RBSharedF66.claim21 n) (RBSharedF66.claim22 n) (RBSharedF66.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard67 : ∀ a n, Required 67 a n → (actualMarked 67 (a+1)).coeff n < (actualMarked 67 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 67 b n → (actualMarked 67 (b+1)).coeff n < (actualMarked 67 b).coeff n)
   (RBSharedF67.claim2 n) (RBSharedF67.claim3 n) (RBSharedF67.claim4 n) (RBSharedF67.claim5 n) (RBSharedF67.claim6 n) (RBSharedF67.claim7 n) (RBSharedF67.claim8 n) (RBSharedF67.claim9 n) (RBSharedF67.claim10 n) (RBSharedF67.claim11 n) (RBSharedF67.claim12 n) (RBSharedF67.claim13 n) (RBSharedF67.claim14 n) (RBSharedF67.claim15 n) (RBSharedF67.claim16 n) (RBSharedF67.claim17 n) (RBSharedF67.claim18 n) (RBSharedF67.claim19 n) (RBSharedF67.claim20 n) (RBSharedF67.claim21 n) (RBSharedF67.claim22 n) (RBSharedF67.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard68 : ∀ a n, Required 68 a n → (actualMarked 68 (a+1)).coeff n < (actualMarked 68 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 68 b n → (actualMarked 68 (b+1)).coeff n < (actualMarked 68 b).coeff n)
   (RBSharedF68.claim2 n) (RBSharedF68.claim3 n) (RBSharedF68.claim4 n) (RBSharedF68.claim5 n) (RBSharedF68.claim6 n) (RBSharedF68.claim7 n) (RBSharedF68.claim8 n) (RBSharedF68.claim9 n) (RBSharedF68.claim10 n) (RBSharedF68.claim11 n) (RBSharedF68.claim12 n) (RBSharedF68.claim13 n) (RBSharedF68.claim14 n) (RBSharedF68.claim15 n) (RBSharedF68.claim16 n) (RBSharedF68.claim17 n) (RBSharedF68.claim18 n) (RBSharedF68.claim19 n) (RBSharedF68.claim20 n) (RBSharedF68.claim21 n) (RBSharedF68.claim22 n) (RBSharedF68.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard69 : ∀ a n, Required 69 a n → (actualMarked 69 (a+1)).coeff n < (actualMarked 69 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 69 b n → (actualMarked 69 (b+1)).coeff n < (actualMarked 69 b).coeff n)
   (RBSharedF69.claim2 n) (RBSharedF69.claim3 n) (RBSharedF69.claim4 n) (RBSharedF69.claim5 n) (RBSharedF69.claim6 n) (RBSharedF69.claim7 n) (RBSharedF69.claim8 n) (RBSharedF69.claim9 n) (RBSharedF69.claim10 n) (RBSharedF69.claim11 n) (RBSharedF69.claim12 n) (RBSharedF69.claim13 n) (RBSharedF69.claim14 n) (RBSharedF69.claim15 n) (RBSharedF69.claim16 n) (RBSharedF69.claim17 n) (RBSharedF69.claim18 n) (RBSharedF69.claim19 n) (RBSharedF69.claim20 n) (RBSharedF69.claim21 n) (RBSharedF69.claim22 n) (RBSharedF69.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard70 : ∀ a n, Required 70 a n → (actualMarked 70 (a+1)).coeff n < (actualMarked 70 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 70 b n → (actualMarked 70 (b+1)).coeff n < (actualMarked 70 b).coeff n)
   (RBSharedF70.claim2 n) (RBSharedF70.claim3 n) (RBSharedF70.claim4 n) (RBSharedF70.claim5 n) (RBSharedF70.claim6 n) (RBSharedF70.claim7 n) (RBSharedF70.claim8 n) (RBSharedF70.claim9 n) (RBSharedF70.claim10 n) (RBSharedF70.claim11 n) (RBSharedF70.claim12 n) (RBSharedF70.claim13 n) (RBSharedF70.claim14 n) (RBSharedF70.claim15 n) (RBSharedF70.claim16 n) (RBSharedF70.claim17 n) (RBSharedF70.claim18 n) (RBSharedF70.claim19 n) (RBSharedF70.claim20 n) (RBSharedF70.claim21 n) (RBSharedF70.claim22 n) (RBSharedF70.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard71 : ∀ a n, Required 71 a n → (actualMarked 71 (a+1)).coeff n < (actualMarked 71 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 71 b n → (actualMarked 71 (b+1)).coeff n < (actualMarked 71 b).coeff n)
   (RBSharedF71.claim2 n) (RBSharedF71.claim3 n) (RBSharedF71.claim4 n) (RBSharedF71.claim5 n) (RBSharedF71.claim6 n) (RBSharedF71.claim7 n) (RBSharedF71.claim8 n) (RBSharedF71.claim9 n) (RBSharedF71.claim10 n) (RBSharedF71.claim11 n) (RBSharedF71.claim12 n) (RBSharedF71.claim13 n) (RBSharedF71.claim14 n) (RBSharedF71.claim15 n) (RBSharedF71.claim16 n) (RBSharedF71.claim17 n) (RBSharedF71.claim18 n) (RBSharedF71.claim19 n) (RBSharedF71.claim20 n) (RBSharedF71.claim21 n) (RBSharedF71.claim22 n) (RBSharedF71.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard72 : ∀ a n, Required 72 a n → (actualMarked 72 (a+1)).coeff n < (actualMarked 72 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 72 b n → (actualMarked 72 (b+1)).coeff n < (actualMarked 72 b).coeff n)
   (RBSharedF72.claim2 n) (RBSharedF72.claim3 n) (RBSharedF72.claim4 n) (RBSharedF72.claim5 n) (RBSharedF72.claim6 n) (RBSharedF72.claim7 n) (RBSharedF72.claim8 n) (RBSharedF72.claim9 n) (RBSharedF72.claim10 n) (RBSharedF72.claim11 n) (RBSharedF72.claim12 n) (RBSharedF72.claim13 n) (RBSharedF72.claim14 n) (RBSharedF72.claim15 n) (RBSharedF72.claim16 n) (RBSharedF72.claim17 n) (RBSharedF72.claim18 n) (RBSharedF72.claim19 n) (RBSharedF72.claim20 n) (RBSharedF72.claim21 n) (RBSharedF72.claim22 n) (RBSharedF72.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard73 : ∀ a n, Required 73 a n → (actualMarked 73 (a+1)).coeff n < (actualMarked 73 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 73 b n → (actualMarked 73 (b+1)).coeff n < (actualMarked 73 b).coeff n)
   (RBSharedF73.claim2 n) (RBSharedF73.claim3 n) (RBSharedF73.claim4 n) (RBSharedF73.claim5 n) (RBSharedF73.claim6 n) (RBSharedF73.claim7 n) (RBSharedF73.claim8 n) (RBSharedF73.claim9 n) (RBSharedF73.claim10 n) (RBSharedF73.claim11 n) (RBSharedF73.claim12 n) (RBSharedF73.claim13 n) (RBSharedF73.claim14 n) (RBSharedF73.claim15 n) (RBSharedF73.claim16 n) (RBSharedF73.claim17 n) (RBSharedF73.claim18 n) (RBSharedF73.claim19 n) (RBSharedF73.claim20 n) (RBSharedF73.claim21 n) (RBSharedF73.claim22 n) (RBSharedF73.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard74 : ∀ a n, Required 74 a n → (actualMarked 74 (a+1)).coeff n < (actualMarked 74 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 74 b n → (actualMarked 74 (b+1)).coeff n < (actualMarked 74 b).coeff n)
   (RBSharedF74.claim2 n) (RBSharedF74.claim3 n) (RBSharedF74.claim4 n) (RBSharedF74.claim5 n) (RBSharedF74.claim6 n) (RBSharedF74.claim7 n) (RBSharedF74.claim8 n) (RBSharedF74.claim9 n) (RBSharedF74.claim10 n) (RBSharedF74.claim11 n) (RBSharedF74.claim12 n) (RBSharedF74.claim13 n) (RBSharedF74.claim14 n) (RBSharedF74.claim15 n) (RBSharedF74.claim16 n) (RBSharedF74.claim17 n) (RBSharedF74.claim18 n) (RBSharedF74.claim19 n) (RBSharedF74.claim20 n) (RBSharedF74.claim21 n) (RBSharedF74.claim22 n) (RBSharedF74.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard75 : ∀ a n, Required 75 a n → (actualMarked 75 (a+1)).coeff n < (actualMarked 75 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 75 b n → (actualMarked 75 (b+1)).coeff n < (actualMarked 75 b).coeff n)
   (RBSharedF75.claim2 n) (RBSharedF75.claim3 n) (RBSharedF75.claim4 n) (RBSharedF75.claim5 n) (RBSharedF75.claim6 n) (RBSharedF75.claim7 n) (RBSharedF75.claim8 n) (RBSharedF75.claim9 n) (RBSharedF75.claim10 n) (RBSharedF75.claim11 n) (RBSharedF75.claim12 n) (RBSharedF75.claim13 n) (RBSharedF75.claim14 n) (RBSharedF75.claim15 n) (RBSharedF75.claim16 n) (RBSharedF75.claim17 n) (RBSharedF75.claim18 n) (RBSharedF75.claim19 n) (RBSharedF75.claim20 n) (RBSharedF75.claim21 n) (RBSharedF75.claim22 n) (RBSharedF75.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard76 : ∀ a n, Required 76 a n → (actualMarked 76 (a+1)).coeff n < (actualMarked 76 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 76 b n → (actualMarked 76 (b+1)).coeff n < (actualMarked 76 b).coeff n)
   (RBSharedF76.claim2 n) (RBSharedF76.claim3 n) (RBSharedF76.claim4 n) (RBSharedF76.claim5 n) (RBSharedF76.claim6 n) (RBSharedF76.claim7 n) (RBSharedF76.claim8 n) (RBSharedF76.claim9 n) (RBSharedF76.claim10 n) (RBSharedF76.claim11 n) (RBSharedF76.claim12 n) (RBSharedF76.claim13 n) (RBSharedF76.claim14 n) (RBSharedF76.claim15 n) (RBSharedF76.claim16 n) (RBSharedF76.claim17 n) (RBSharedF76.claim18 n) (RBSharedF76.claim19 n) (RBSharedF76.claim20 n) (RBSharedF76.claim21 n) (RBSharedF76.claim22 n) (RBSharedF76.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard77 : ∀ a n, Required 77 a n → (actualMarked 77 (a+1)).coeff n < (actualMarked 77 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 77 b n → (actualMarked 77 (b+1)).coeff n < (actualMarked 77 b).coeff n)
   (RBSharedF77.claim2 n) (RBSharedF77.claim3 n) (RBSharedF77.claim4 n) (RBSharedF77.claim5 n) (RBSharedF77.claim6 n) (RBSharedF77.claim7 n) (RBSharedF77.claim8 n) (RBSharedF77.claim9 n) (RBSharedF77.claim10 n) (RBSharedF77.claim11 n) (RBSharedF77.claim12 n) (RBSharedF77.claim13 n) (RBSharedF77.claim14 n) (RBSharedF77.claim15 n) (RBSharedF77.claim16 n) (RBSharedF77.claim17 n) (RBSharedF77.claim18 n) (RBSharedF77.claim19 n) (RBSharedF77.claim20 n) (RBSharedF77.claim21 n) (RBSharedF77.claim22 n) (RBSharedF77.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard78 : ∀ a n, Required 78 a n → (actualMarked 78 (a+1)).coeff n < (actualMarked 78 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 78 b n → (actualMarked 78 (b+1)).coeff n < (actualMarked 78 b).coeff n)
   (RBSharedF78.claim2 n) (RBSharedF78.claim3 n) (RBSharedF78.claim4 n) (RBSharedF78.claim5 n) (RBSharedF78.claim6 n) (RBSharedF78.claim7 n) (RBSharedF78.claim8 n) (RBSharedF78.claim9 n) (RBSharedF78.claim10 n) (RBSharedF78.claim11 n) (RBSharedF78.claim12 n) (RBSharedF78.claim13 n) (RBSharedF78.claim14 n) (RBSharedF78.claim15 n) (RBSharedF78.claim16 n) (RBSharedF78.claim17 n) (RBSharedF78.claim18 n) (RBSharedF78.claim19 n) (RBSharedF78.claim20 n) (RBSharedF78.claim21 n) (RBSharedF78.claim22 n) (RBSharedF78.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard79 : ∀ a n, Required 79 a n → (actualMarked 79 (a+1)).coeff n < (actualMarked 79 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 79 b n → (actualMarked 79 (b+1)).coeff n < (actualMarked 79 b).coeff n)
   (RBSharedF79.claim2 n) (RBSharedF79.claim3 n) (RBSharedF79.claim4 n) (RBSharedF79.claim5 n) (RBSharedF79.claim6 n) (RBSharedF79.claim7 n) (RBSharedF79.claim8 n) (RBSharedF79.claim9 n) (RBSharedF79.claim10 n) (RBSharedF79.claim11 n) (RBSharedF79.claim12 n) (RBSharedF79.claim13 n) (RBSharedF79.claim14 n) (RBSharedF79.claim15 n) (RBSharedF79.claim16 n) (RBSharedF79.claim17 n) (RBSharedF79.claim18 n) (RBSharedF79.claim19 n) (RBSharedF79.claim20 n) (RBSharedF79.claim21 n) (RBSharedF79.claim22 n) (RBSharedF79.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard80 : ∀ a n, Required 80 a n → (actualMarked 80 (a+1)).coeff n < (actualMarked 80 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 80 b n → (actualMarked 80 (b+1)).coeff n < (actualMarked 80 b).coeff n)
   (RBSharedF80.claim2 n) (RBSharedF80.claim3 n) (RBSharedF80.claim4 n) (RBSharedF80.claim5 n) (RBSharedF80.claim6 n) (RBSharedF80.claim7 n) (RBSharedF80.claim8 n) (RBSharedF80.claim9 n) (RBSharedF80.claim10 n) (RBSharedF80.claim11 n) (RBSharedF80.claim12 n) (RBSharedF80.claim13 n) (RBSharedF80.claim14 n) (RBSharedF80.claim15 n) (RBSharedF80.claim16 n) (RBSharedF80.claim17 n) (RBSharedF80.claim18 n) (RBSharedF80.claim19 n) (RBSharedF80.claim20 n) (RBSharedF80.claim21 n) (RBSharedF80.claim22 n) (RBSharedF80.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard81 : ∀ a n, Required 81 a n → (actualMarked 81 (a+1)).coeff n < (actualMarked 81 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 81 b n → (actualMarked 81 (b+1)).coeff n < (actualMarked 81 b).coeff n)
   (RBSharedF81.claim2 n) (RBSharedF81.claim3 n) (RBSharedF81.claim4 n) (RBSharedF81.claim5 n) (RBSharedF81.claim6 n) (RBSharedF81.claim7 n) (RBSharedF81.claim8 n) (RBSharedF81.claim9 n) (RBSharedF81.claim10 n) (RBSharedF81.claim11 n) (RBSharedF81.claim12 n) (RBSharedF81.claim13 n) (RBSharedF81.claim14 n) (RBSharedF81.claim15 n) (RBSharedF81.claim16 n) (RBSharedF81.claim17 n) (RBSharedF81.claim18 n) (RBSharedF81.claim19 n) (RBSharedF81.claim20 n) (RBSharedF81.claim21 n) (RBSharedF81.claim22 n) (RBSharedF81.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard82 : ∀ a n, Required 82 a n → (actualMarked 82 (a+1)).coeff n < (actualMarked 82 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 82 b n → (actualMarked 82 (b+1)).coeff n < (actualMarked 82 b).coeff n)
   (RBSharedF82.claim2 n) (RBSharedF82.claim3 n) (RBSharedF82.claim4 n) (RBSharedF82.claim5 n) (RBSharedF82.claim6 n) (RBSharedF82.claim7 n) (RBSharedF82.claim8 n) (RBSharedF82.claim9 n) (RBSharedF82.claim10 n) (RBSharedF82.claim11 n) (RBSharedF82.claim12 n) (RBSharedF82.claim13 n) (RBSharedF82.claim14 n) (RBSharedF82.claim15 n) (RBSharedF82.claim16 n) (RBSharedF82.claim17 n) (RBSharedF82.claim18 n) (RBSharedF82.claim19 n) (RBSharedF82.claim20 n) (RBSharedF82.claim21 n) (RBSharedF82.claim22 n) (RBSharedF82.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard83 : ∀ a n, Required 83 a n → (actualMarked 83 (a+1)).coeff n < (actualMarked 83 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 83 b n → (actualMarked 83 (b+1)).coeff n < (actualMarked 83 b).coeff n)
   (RBSharedF83.claim2 n) (RBSharedF83.claim3 n) (RBSharedF83.claim4 n) (RBSharedF83.claim5 n) (RBSharedF83.claim6 n) (RBSharedF83.claim7 n) (RBSharedF83.claim8 n) (RBSharedF83.claim9 n) (RBSharedF83.claim10 n) (RBSharedF83.claim11 n) (RBSharedF83.claim12 n) (RBSharedF83.claim13 n) (RBSharedF83.claim14 n) (RBSharedF83.claim15 n) (RBSharedF83.claim16 n) (RBSharedF83.claim17 n) (RBSharedF83.claim18 n) (RBSharedF83.claim19 n) (RBSharedF83.claim20 n) (RBSharedF83.claim21 n) (RBSharedF83.claim22 n) (RBSharedF83.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard84 : ∀ a n, Required 84 a n → (actualMarked 84 (a+1)).coeff n < (actualMarked 84 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 84 b n → (actualMarked 84 (b+1)).coeff n < (actualMarked 84 b).coeff n)
   (RBSharedF84.claim2 n) (RBSharedF84.claim3 n) (RBSharedF84.claim4 n) (RBSharedF84.claim5 n) (RBSharedF84.claim6 n) (RBSharedF84.claim7 n) (RBSharedF84.claim8 n) (RBSharedF84.claim9 n) (RBSharedF84.claim10 n) (RBSharedF84.claim11 n) (RBSharedF84.claim12 n) (RBSharedF84.claim13 n) (RBSharedF84.claim14 n) (RBSharedF84.claim15 n) (RBSharedF84.claim16 n) (RBSharedF84.claim17 n) (RBSharedF84.claim18 n) (RBSharedF84.claim19 n) (RBSharedF84.claim20 n) (RBSharedF84.claim21 n) (RBSharedF84.claim22 n) (RBSharedF84.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard85 : ∀ a n, Required 85 a n → (actualMarked 85 (a+1)).coeff n < (actualMarked 85 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 85 b n → (actualMarked 85 (b+1)).coeff n < (actualMarked 85 b).coeff n)
   (RBSharedF85.claim2 n) (RBSharedF85.claim3 n) (RBSharedF85.claim4 n) (RBSharedF85.claim5 n) (RBSharedF85.claim6 n) (RBSharedF85.claim7 n) (RBSharedF85.claim8 n) (RBSharedF85.claim9 n) (RBSharedF85.claim10 n) (RBSharedF85.claim11 n) (RBSharedF85.claim12 n) (RBSharedF85.claim13 n) (RBSharedF85.claim14 n) (RBSharedF85.claim15 n) (RBSharedF85.claim16 n) (RBSharedF85.claim17 n) (RBSharedF85.claim18 n) (RBSharedF85.claim19 n) (RBSharedF85.claim20 n) (RBSharedF85.claim21 n) (RBSharedF85.claim22 n) (RBSharedF85.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard86 : ∀ a n, Required 86 a n → (actualMarked 86 (a+1)).coeff n < (actualMarked 86 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 86 b n → (actualMarked 86 (b+1)).coeff n < (actualMarked 86 b).coeff n)
   (RBSharedF86.claim2 n) (RBSharedF86.claim3 n) (RBSharedF86.claim4 n) (RBSharedF86.claim5 n) (RBSharedF86.claim6 n) (RBSharedF86.claim7 n) (RBSharedF86.claim8 n) (RBSharedF86.claim9 n) (RBSharedF86.claim10 n) (RBSharedF86.claim11 n) (RBSharedF86.claim12 n) (RBSharedF86.claim13 n) (RBSharedF86.claim14 n) (RBSharedF86.claim15 n) (RBSharedF86.claim16 n) (RBSharedF86.claim17 n) (RBSharedF86.claim18 n) (RBSharedF86.claim19 n) (RBSharedF86.claim20 n) (RBSharedF86.claim21 n) (RBSharedF86.claim22 n) (RBSharedF86.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard87 : ∀ a n, Required 87 a n → (actualMarked 87 (a+1)).coeff n < (actualMarked 87 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 87 b n → (actualMarked 87 (b+1)).coeff n < (actualMarked 87 b).coeff n)
   (RBSharedF87.claim2 n) (RBSharedF87.claim3 n) (RBSharedF87.claim4 n) (RBSharedF87.claim5 n) (RBSharedF87.claim6 n) (RBSharedF87.claim7 n) (RBSharedF87.claim8 n) (RBSharedF87.claim9 n) (RBSharedF87.claim10 n) (RBSharedF87.claim11 n) (RBSharedF87.claim12 n) (RBSharedF87.claim13 n) (RBSharedF87.claim14 n) (RBSharedF87.claim15 n) (RBSharedF87.claim16 n) (RBSharedF87.claim17 n) (RBSharedF87.claim18 n) (RBSharedF87.claim19 n) (RBSharedF87.claim20 n) (RBSharedF87.claim21 n) (RBSharedF87.claim22 n) (RBSharedF87.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard88 : ∀ a n, Required 88 a n → (actualMarked 88 (a+1)).coeff n < (actualMarked 88 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 88 b n → (actualMarked 88 (b+1)).coeff n < (actualMarked 88 b).coeff n)
   (RBSharedF88.claim2 n) (RBSharedF88.claim3 n) (RBSharedF88.claim4 n) (RBSharedF88.claim5 n) (RBSharedF88.claim6 n) (RBSharedF88.claim7 n) (RBSharedF88.claim8 n) (RBSharedF88.claim9 n) (RBSharedF88.claim10 n) (RBSharedF88.claim11 n) (RBSharedF88.claim12 n) (RBSharedF88.claim13 n) (RBSharedF88.claim14 n) (RBSharedF88.claim15 n) (RBSharedF88.claim16 n) (RBSharedF88.claim17 n) (RBSharedF88.claim18 n) (RBSharedF88.claim19 n) (RBSharedF88.claim20 n) (RBSharedF88.claim21 n) (RBSharedF88.claim22 n) (RBSharedF88.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard89 : ∀ a n, Required 89 a n → (actualMarked 89 (a+1)).coeff n < (actualMarked 89 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 89 b n → (actualMarked 89 (b+1)).coeff n < (actualMarked 89 b).coeff n)
   (RBSharedF89.claim2 n) (RBSharedF89.claim3 n) (RBSharedF89.claim4 n) (RBSharedF89.claim5 n) (RBSharedF89.claim6 n) (RBSharedF89.claim7 n) (RBSharedF89.claim8 n) (RBSharedF89.claim9 n) (RBSharedF89.claim10 n) (RBSharedF89.claim11 n) (RBSharedF89.claim12 n) (RBSharedF89.claim13 n) (RBSharedF89.claim14 n) (RBSharedF89.claim15 n) (RBSharedF89.claim16 n) (RBSharedF89.claim17 n) (RBSharedF89.claim18 n) (RBSharedF89.claim19 n) (RBSharedF89.claim20 n) (RBSharedF89.claim21 n) (RBSharedF89.claim22 n) (RBSharedF89.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard90 : ∀ a n, Required 90 a n → (actualMarked 90 (a+1)).coeff n < (actualMarked 90 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 90 b n → (actualMarked 90 (b+1)).coeff n < (actualMarked 90 b).coeff n)
   (RBSharedF90.claim2 n) (RBSharedF90.claim3 n) (RBSharedF90.claim4 n) (RBSharedF90.claim5 n) (RBSharedF90.claim6 n) (RBSharedF90.claim7 n) (RBSharedF90.claim8 n) (RBSharedF90.claim9 n) (RBSharedF90.claim10 n) (RBSharedF90.claim11 n) (RBSharedF90.claim12 n) (RBSharedF90.claim13 n) (RBSharedF90.claim14 n) (RBSharedF90.claim15 n) (RBSharedF90.claim16 n) (RBSharedF90.claim17 n) (RBSharedF90.claim18 n) (RBSharedF90.claim19 n) (RBSharedF90.claim20 n) (RBSharedF90.claim21 n) (RBSharedF90.claim22 n) (RBSharedF90.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard91 : ∀ a n, Required 91 a n → (actualMarked 91 (a+1)).coeff n < (actualMarked 91 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 91 b n → (actualMarked 91 (b+1)).coeff n < (actualMarked 91 b).coeff n)
   (RBSharedF91.claim2 n) (RBSharedF91.claim3 n) (RBSharedF91.claim4 n) (RBSharedF91.claim5 n) (RBSharedF91.claim6 n) (RBSharedF91.claim7 n) (RBSharedF91.claim8 n) (RBSharedF91.claim9 n) (RBSharedF91.claim10 n) (RBSharedF91.claim11 n) (RBSharedF91.claim12 n) (RBSharedF91.claim13 n) (RBSharedF91.claim14 n) (RBSharedF91.claim15 n) (RBSharedF91.claim16 n) (RBSharedF91.claim17 n) (RBSharedF91.claim18 n) (RBSharedF91.claim19 n) (RBSharedF91.claim20 n) (RBSharedF91.claim21 n) (RBSharedF91.claim22 n) (RBSharedF91.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard92 : ∀ a n, Required 92 a n → (actualMarked 92 (a+1)).coeff n < (actualMarked 92 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 92 b n → (actualMarked 92 (b+1)).coeff n < (actualMarked 92 b).coeff n)
   (RBSharedF92.claim2 n) (RBSharedF92.claim3 n) (RBSharedF92.claim4 n) (RBSharedF92.claim5 n) (RBSharedF92.claim6 n) (RBSharedF92.claim7 n) (RBSharedF92.claim8 n) (RBSharedF92.claim9 n) (RBSharedF92.claim10 n) (RBSharedF92.claim11 n) (RBSharedF92.claim12 n) (RBSharedF92.claim13 n) (RBSharedF92.claim14 n) (RBSharedF92.claim15 n) (RBSharedF92.claim16 n) (RBSharedF92.claim17 n) (RBSharedF92.claim18 n) (RBSharedF92.claim19 n) (RBSharedF92.claim20 n) (RBSharedF92.claim21 n) (RBSharedF92.claim22 n) (RBSharedF92.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard93 : ∀ a n, Required 93 a n → (actualMarked 93 (a+1)).coeff n < (actualMarked 93 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 93 b n → (actualMarked 93 (b+1)).coeff n < (actualMarked 93 b).coeff n)
   (RBSharedF93.claim2 n) (RBSharedF93.claim3 n) (RBSharedF93.claim4 n) (RBSharedF93.claim5 n) (RBSharedF93.claim6 n) (RBSharedF93.claim7 n) (RBSharedF93.claim8 n) (RBSharedF93.claim9 n) (RBSharedF93.claim10 n) (RBSharedF93.claim11 n) (RBSharedF93.claim12 n) (RBSharedF93.claim13 n) (RBSharedF93.claim14 n) (RBSharedF93.claim15 n) (RBSharedF93.claim16 n) (RBSharedF93.claim17 n) (RBSharedF93.claim18 n) (RBSharedF93.claim19 n) (RBSharedF93.claim20 n) (RBSharedF93.claim21 n) (RBSharedF93.claim22 n) (RBSharedF93.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard94 : ∀ a n, Required 94 a n → (actualMarked 94 (a+1)).coeff n < (actualMarked 94 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 94 b n → (actualMarked 94 (b+1)).coeff n < (actualMarked 94 b).coeff n)
   (RBSharedF94.claim2 n) (RBSharedF94.claim3 n) (RBSharedF94.claim4 n) (RBSharedF94.claim5 n) (RBSharedF94.claim6 n) (RBSharedF94.claim7 n) (RBSharedF94.claim8 n) (RBSharedF94.claim9 n) (RBSharedF94.claim10 n) (RBSharedF94.claim11 n) (RBSharedF94.claim12 n) (RBSharedF94.claim13 n) (RBSharedF94.claim14 n) (RBSharedF94.claim15 n) (RBSharedF94.claim16 n) (RBSharedF94.claim17 n) (RBSharedF94.claim18 n) (RBSharedF94.claim19 n) (RBSharedF94.claim20 n) (RBSharedF94.claim21 n) (RBSharedF94.claim22 n) (RBSharedF94.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard95 : ∀ a n, Required 95 a n → (actualMarked 95 (a+1)).coeff n < (actualMarked 95 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 95 b n → (actualMarked 95 (b+1)).coeff n < (actualMarked 95 b).coeff n)
   (RBSharedF95.claim2 n) (RBSharedF95.claim3 n) (RBSharedF95.claim4 n) (RBSharedF95.claim5 n) (RBSharedF95.claim6 n) (RBSharedF95.claim7 n) (RBSharedF95.claim8 n) (RBSharedF95.claim9 n) (RBSharedF95.claim10 n) (RBSharedF95.claim11 n) (RBSharedF95.claim12 n) (RBSharedF95.claim13 n) (RBSharedF95.claim14 n) (RBSharedF95.claim15 n) (RBSharedF95.claim16 n) (RBSharedF95.claim17 n) (RBSharedF95.claim18 n) (RBSharedF95.claim19 n) (RBSharedF95.claim20 n) (RBSharedF95.claim21 n) (RBSharedF95.claim22 n) (RBSharedF95.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard96 : ∀ a n, Required 96 a n → (actualMarked 96 (a+1)).coeff n < (actualMarked 96 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 96 b n → (actualMarked 96 (b+1)).coeff n < (actualMarked 96 b).coeff n)
   (RBSharedF96.claim2 n) (RBSharedF96.claim3 n) (RBSharedF96.claim4 n) (RBSharedF96.claim5 n) (RBSharedF96.claim6 n) (RBSharedF96.claim7 n) (RBSharedF96.claim8 n) (RBSharedF96.claim9 n) (RBSharedF96.claim10 n) (RBSharedF96.claim11 n) (RBSharedF96.claim12 n) (RBSharedF96.claim13 n) (RBSharedF96.claim14 n) (RBSharedF96.claim15 n) (RBSharedF96.claim16 n) (RBSharedF96.claim17 n) (RBSharedF96.claim18 n) (RBSharedF96.claim19 n) (RBSharedF96.claim20 n) (RBSharedF96.claim21 n) (RBSharedF96.claim22 n) (RBSharedF96.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard97 : ∀ a n, Required 97 a n → (actualMarked 97 (a+1)).coeff n < (actualMarked 97 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 97 b n → (actualMarked 97 (b+1)).coeff n < (actualMarked 97 b).coeff n)
   (RBSharedF97.claim2 n) (RBSharedF97.claim3 n) (RBSharedF97.claim4 n) (RBSharedF97.claim5 n) (RBSharedF97.claim6 n) (RBSharedF97.claim7 n) (RBSharedF97.claim8 n) (RBSharedF97.claim9 n) (RBSharedF97.claim10 n) (RBSharedF97.claim11 n) (RBSharedF97.claim12 n) (RBSharedF97.claim13 n) (RBSharedF97.claim14 n) (RBSharedF97.claim15 n) (RBSharedF97.claim16 n) (RBSharedF97.claim17 n) (RBSharedF97.claim18 n) (RBSharedF97.claim19 n) (RBSharedF97.claim20 n) (RBSharedF97.claim21 n) (RBSharedF97.claim22 n) (RBSharedF97.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard98 : ∀ a n, Required 98 a n → (actualMarked 98 (a+1)).coeff n < (actualMarked 98 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 98 b n → (actualMarked 98 (b+1)).coeff n < (actualMarked 98 b).coeff n)
   (RBSharedF98.claim2 n) (RBSharedF98.claim3 n) (RBSharedF98.claim4 n) (RBSharedF98.claim5 n) (RBSharedF98.claim6 n) (RBSharedF98.claim7 n) (RBSharedF98.claim8 n) (RBSharedF98.claim9 n) (RBSharedF98.claim10 n) (RBSharedF98.claim11 n) (RBSharedF98.claim12 n) (RBSharedF98.claim13 n) (RBSharedF98.claim14 n) (RBSharedF98.claim15 n) (RBSharedF98.claim16 n) (RBSharedF98.claim17 n) (RBSharedF98.claim18 n) (RBSharedF98.claim19 n) (RBSharedF98.claim20 n) (RBSharedF98.claim21 n) (RBSharedF98.claim22 n) (RBSharedF98.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard99 : ∀ a n, Required 99 a n → (actualMarked 99 (a+1)).coeff n < (actualMarked 99 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 99 b n → (actualMarked 99 (b+1)).coeff n < (actualMarked 99 b).coeff n)
   (RBSharedF99.claim2 n) (RBSharedF99.claim3 n) (RBSharedF99.claim4 n) (RBSharedF99.claim5 n) (RBSharedF99.claim6 n) (RBSharedF99.claim7 n) (RBSharedF99.claim8 n) (RBSharedF99.claim9 n) (RBSharedF99.claim10 n) (RBSharedF99.claim11 n) (RBSharedF99.claim12 n) (RBSharedF99.claim13 n) (RBSharedF99.claim14 n) (RBSharedF99.claim15 n) (RBSharedF99.claim16 n) (RBSharedF99.claim17 n) (RBSharedF99.claim18 n) (RBSharedF99.claim19 n) (RBSharedF99.claim20 n) (RBSharedF99.claim21 n) (RBSharedF99.claim22 n) (RBSharedF99.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard100 : ∀ a n, Required 100 a n → (actualMarked 100 (a+1)).coeff n < (actualMarked 100 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 100 b n → (actualMarked 100 (b+1)).coeff n < (actualMarked 100 b).coeff n)
   (RBSharedF100.claim2 n) (RBSharedF100.claim3 n) (RBSharedF100.claim4 n) (RBSharedF100.claim5 n) (RBSharedF100.claim6 n) (RBSharedF100.claim7 n) (RBSharedF100.claim8 n) (RBSharedF100.claim9 n) (RBSharedF100.claim10 n) (RBSharedF100.claim11 n) (RBSharedF100.claim12 n) (RBSharedF100.claim13 n) (RBSharedF100.claim14 n) (RBSharedF100.claim15 n) (RBSharedF100.claim16 n) (RBSharedF100.claim17 n) (RBSharedF100.claim18 n) (RBSharedF100.claim19 n) (RBSharedF100.claim20 n) (RBSharedF100.claim21 n) (RBSharedF100.claim22 n) (RBSharedF100.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard101 : ∀ a n, Required 101 a n → (actualMarked 101 (a+1)).coeff n < (actualMarked 101 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 101 b n → (actualMarked 101 (b+1)).coeff n < (actualMarked 101 b).coeff n)
   (RBSharedF101.claim2 n) (RBSharedF101.claim3 n) (RBSharedF101.claim4 n) (RBSharedF101.claim5 n) (RBSharedF101.claim6 n) (RBSharedF101.claim7 n) (RBSharedF101.claim8 n) (RBSharedF101.claim9 n) (RBSharedF101.claim10 n) (RBSharedF101.claim11 n) (RBSharedF101.claim12 n) (RBSharedF101.claim13 n) (RBSharedF101.claim14 n) (RBSharedF101.claim15 n) (RBSharedF101.claim16 n) (RBSharedF101.claim17 n) (RBSharedF101.claim18 n) (RBSharedF101.claim19 n) (RBSharedF101.claim20 n) (RBSharedF101.claim21 n) (RBSharedF101.claim22 n) (RBSharedF101.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard102 : ∀ a n, Required 102 a n → (actualMarked 102 (a+1)).coeff n < (actualMarked 102 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 102 b n → (actualMarked 102 (b+1)).coeff n < (actualMarked 102 b).coeff n)
   (RBSharedF102.claim2 n) (RBSharedF102.claim3 n) (RBSharedF102.claim4 n) (RBSharedF102.claim5 n) (RBSharedF102.claim6 n) (RBSharedF102.claim7 n) (RBSharedF102.claim8 n) (RBSharedF102.claim9 n) (RBSharedF102.claim10 n) (RBSharedF102.claim11 n) (RBSharedF102.claim12 n) (RBSharedF102.claim13 n) (RBSharedF102.claim14 n) (RBSharedF102.claim15 n) (RBSharedF102.claim16 n) (RBSharedF102.claim17 n) (RBSharedF102.claim18 n) (RBSharedF102.claim19 n) (RBSharedF102.claim20 n) (RBSharedF102.claim21 n) (RBSharedF102.claim22 n) (RBSharedF102.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard103 : ∀ a n, Required 103 a n → (actualMarked 103 (a+1)).coeff n < (actualMarked 103 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 103 b n → (actualMarked 103 (b+1)).coeff n < (actualMarked 103 b).coeff n)
   (RBSharedF103.claim2 n) (RBSharedF103.claim3 n) (RBSharedF103.claim4 n) (RBSharedF103.claim5 n) (RBSharedF103.claim6 n) (RBSharedF103.claim7 n) (RBSharedF103.claim8 n) (RBSharedF103.claim9 n) (RBSharedF103.claim10 n) (RBSharedF103.claim11 n) (RBSharedF103.claim12 n) (RBSharedF103.claim13 n) (RBSharedF103.claim14 n) (RBSharedF103.claim15 n) (RBSharedF103.claim16 n) (RBSharedF103.claim17 n) (RBSharedF103.claim18 n) (RBSharedF103.claim19 n) (RBSharedF103.claim20 n) (RBSharedF103.claim21 n) (RBSharedF103.claim22 n) (RBSharedF103.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard104 : ∀ a n, Required 104 a n → (actualMarked 104 (a+1)).coeff n < (actualMarked 104 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 104 b n → (actualMarked 104 (b+1)).coeff n < (actualMarked 104 b).coeff n)
   (RBSharedF104.claim2 n) (RBSharedF104.claim3 n) (RBSharedF104.claim4 n) (RBSharedF104.claim5 n) (RBSharedF104.claim6 n) (RBSharedF104.claim7 n) (RBSharedF104.claim8 n) (RBSharedF104.claim9 n) (RBSharedF104.claim10 n) (RBSharedF104.claim11 n) (RBSharedF104.claim12 n) (RBSharedF104.claim13 n) (RBSharedF104.claim14 n) (RBSharedF104.claim15 n) (RBSharedF104.claim16 n) (RBSharedF104.claim17 n) (RBSharedF104.claim18 n) (RBSharedF104.claim19 n) (RBSharedF104.claim20 n) (RBSharedF104.claim21 n) (RBSharedF104.claim22 n) (RBSharedF104.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard105 : ∀ a n, Required 105 a n → (actualMarked 105 (a+1)).coeff n < (actualMarked 105 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 105 b n → (actualMarked 105 (b+1)).coeff n < (actualMarked 105 b).coeff n)
   (RBSharedF105.claim2 n) (RBSharedF105.claim3 n) (RBSharedF105.claim4 n) (RBSharedF105.claim5 n) (RBSharedF105.claim6 n) (RBSharedF105.claim7 n) (RBSharedF105.claim8 n) (RBSharedF105.claim9 n) (RBSharedF105.claim10 n) (RBSharedF105.claim11 n) (RBSharedF105.claim12 n) (RBSharedF105.claim13 n) (RBSharedF105.claim14 n) (RBSharedF105.claim15 n) (RBSharedF105.claim16 n) (RBSharedF105.claim17 n) (RBSharedF105.claim18 n) (RBSharedF105.claim19 n) (RBSharedF105.claim20 n) (RBSharedF105.claim21 n) (RBSharedF105.claim22 n) (RBSharedF105.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard106 : ∀ a n, Required 106 a n → (actualMarked 106 (a+1)).coeff n < (actualMarked 106 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 106 b n → (actualMarked 106 (b+1)).coeff n < (actualMarked 106 b).coeff n)
   (RBSharedF106.claim2 n) (RBSharedF106.claim3 n) (RBSharedF106.claim4 n) (RBSharedF106.claim5 n) (RBSharedF106.claim6 n) (RBSharedF106.claim7 n) (RBSharedF106.claim8 n) (RBSharedF106.claim9 n) (RBSharedF106.claim10 n) (RBSharedF106.claim11 n) (RBSharedF106.claim12 n) (RBSharedF106.claim13 n) (RBSharedF106.claim14 n) (RBSharedF106.claim15 n) (RBSharedF106.claim16 n) (RBSharedF106.claim17 n) (RBSharedF106.claim18 n) (RBSharedF106.claim19 n) (RBSharedF106.claim20 n) (RBSharedF106.claim21 n) (RBSharedF106.claim22 n) (RBSharedF106.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard107 : ∀ a n, Required 107 a n → (actualMarked 107 (a+1)).coeff n < (actualMarked 107 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 107 b n → (actualMarked 107 (b+1)).coeff n < (actualMarked 107 b).coeff n)
   (RBSharedF107.claim2 n) (RBSharedF107.claim3 n) (RBSharedF107.claim4 n) (RBSharedF107.claim5 n) (RBSharedF107.claim6 n) (RBSharedF107.claim7 n) (RBSharedF107.claim8 n) (RBSharedF107.claim9 n) (RBSharedF107.claim10 n) (RBSharedF107.claim11 n) (RBSharedF107.claim12 n) (RBSharedF107.claim13 n) (RBSharedF107.claim14 n) (RBSharedF107.claim15 n) (RBSharedF107.claim16 n) (RBSharedF107.claim17 n) (RBSharedF107.claim18 n) (RBSharedF107.claim19 n) (RBSharedF107.claim20 n) (RBSharedF107.claim21 n) (RBSharedF107.claim22 n) (RBSharedF107.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard108 : ∀ a n, Required 108 a n → (actualMarked 108 (a+1)).coeff n < (actualMarked 108 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 108 b n → (actualMarked 108 (b+1)).coeff n < (actualMarked 108 b).coeff n)
   (RBSharedF108.claim2 n) (RBSharedF108.claim3 n) (RBSharedF108.claim4 n) (RBSharedF108.claim5 n) (RBSharedF108.claim6 n) (RBSharedF108.claim7 n) (RBSharedF108.claim8 n) (RBSharedF108.claim9 n) (RBSharedF108.claim10 n) (RBSharedF108.claim11 n) (RBSharedF108.claim12 n) (RBSharedF108.claim13 n) (RBSharedF108.claim14 n) (RBSharedF108.claim15 n) (RBSharedF108.claim16 n) (RBSharedF108.claim17 n) (RBSharedF108.claim18 n) (RBSharedF108.claim19 n) (RBSharedF108.claim20 n) (RBSharedF108.claim21 n) (RBSharedF108.claim22 n) (RBSharedF108.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard109 : ∀ a n, Required 109 a n → (actualMarked 109 (a+1)).coeff n < (actualMarked 109 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 109 b n → (actualMarked 109 (b+1)).coeff n < (actualMarked 109 b).coeff n)
   (RBSharedF109.claim2 n) (RBSharedF109.claim3 n) (RBSharedF109.claim4 n) (RBSharedF109.claim5 n) (RBSharedF109.claim6 n) (RBSharedF109.claim7 n) (RBSharedF109.claim8 n) (RBSharedF109.claim9 n) (RBSharedF109.claim10 n) (RBSharedF109.claim11 n) (RBSharedF109.claim12 n) (RBSharedF109.claim13 n) (RBSharedF109.claim14 n) (RBSharedF109.claim15 n) (RBSharedF109.claim16 n) (RBSharedF109.claim17 n) (RBSharedF109.claim18 n) (RBSharedF109.claim19 n) (RBSharedF109.claim20 n) (RBSharedF109.claim21 n) (RBSharedF109.claim22 n) (RBSharedF109.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard110 : ∀ a n, Required 110 a n → (actualMarked 110 (a+1)).coeff n < (actualMarked 110 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 110 b n → (actualMarked 110 (b+1)).coeff n < (actualMarked 110 b).coeff n)
   (RBSharedF110.claim2 n) (RBSharedF110.claim3 n) (RBSharedF110.claim4 n) (RBSharedF110.claim5 n) (RBSharedF110.claim6 n) (RBSharedF110.claim7 n) (RBSharedF110.claim8 n) (RBSharedF110.claim9 n) (RBSharedF110.claim10 n) (RBSharedF110.claim11 n) (RBSharedF110.claim12 n) (RBSharedF110.claim13 n) (RBSharedF110.claim14 n) (RBSharedF110.claim15 n) (RBSharedF110.claim16 n) (RBSharedF110.claim17 n) (RBSharedF110.claim18 n) (RBSharedF110.claim19 n) (RBSharedF110.claim20 n) (RBSharedF110.claim21 n) (RBSharedF110.claim22 n) (RBSharedF110.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard111 : ∀ a n, Required 111 a n → (actualMarked 111 (a+1)).coeff n < (actualMarked 111 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 111 b n → (actualMarked 111 (b+1)).coeff n < (actualMarked 111 b).coeff n)
   (RBSharedF111.claim2 n) (RBSharedF111.claim3 n) (RBSharedF111.claim4 n) (RBSharedF111.claim5 n) (RBSharedF111.claim6 n) (RBSharedF111.claim7 n) (RBSharedF111.claim8 n) (RBSharedF111.claim9 n) (RBSharedF111.claim10 n) (RBSharedF111.claim11 n) (RBSharedF111.claim12 n) (RBSharedF111.claim13 n) (RBSharedF111.claim14 n) (RBSharedF111.claim15 n) (RBSharedF111.claim16 n) (RBSharedF111.claim17 n) (RBSharedF111.claim18 n) (RBSharedF111.claim19 n) (RBSharedF111.claim20 n) (RBSharedF111.claim21 n) (RBSharedF111.claim22 n) (RBSharedF111.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard112 : ∀ a n, Required 112 a n → (actualMarked 112 (a+1)).coeff n < (actualMarked 112 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 112 b n → (actualMarked 112 (b+1)).coeff n < (actualMarked 112 b).coeff n)
   (RBSharedF112.claim2 n) (RBSharedF112.claim3 n) (RBSharedF112.claim4 n) (RBSharedF112.claim5 n) (RBSharedF112.claim6 n) (RBSharedF112.claim7 n) (RBSharedF112.claim8 n) (RBSharedF112.claim9 n) (RBSharedF112.claim10 n) (RBSharedF112.claim11 n) (RBSharedF112.claim12 n) (RBSharedF112.claim13 n) (RBSharedF112.claim14 n) (RBSharedF112.claim15 n) (RBSharedF112.claim16 n) (RBSharedF112.claim17 n) (RBSharedF112.claim18 n) (RBSharedF112.claim19 n) (RBSharedF112.claim20 n) (RBSharedF112.claim21 n) (RBSharedF112.claim22 n) (RBSharedF112.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard113 : ∀ a n, Required 113 a n → (actualMarked 113 (a+1)).coeff n < (actualMarked 113 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 113 b n → (actualMarked 113 (b+1)).coeff n < (actualMarked 113 b).coeff n)
   (RBSharedF113.claim2 n) (RBSharedF113.claim3 n) (RBSharedF113.claim4 n) (RBSharedF113.claim5 n) (RBSharedF113.claim6 n) (RBSharedF113.claim7 n) (RBSharedF113.claim8 n) (RBSharedF113.claim9 n) (RBSharedF113.claim10 n) (RBSharedF113.claim11 n) (RBSharedF113.claim12 n) (RBSharedF113.claim13 n) (RBSharedF113.claim14 n) (RBSharedF113.claim15 n) (RBSharedF113.claim16 n) (RBSharedF113.claim17 n) (RBSharedF113.claim18 n) (RBSharedF113.claim19 n) (RBSharedF113.claim20 n) (RBSharedF113.claim21 n) (RBSharedF113.claim22 n) (RBSharedF113.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard114 : ∀ a n, Required 114 a n → (actualMarked 114 (a+1)).coeff n < (actualMarked 114 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 114 b n → (actualMarked 114 (b+1)).coeff n < (actualMarked 114 b).coeff n)
   (RBSharedF114.claim2 n) (RBSharedF114.claim3 n) (RBSharedF114.claim4 n) (RBSharedF114.claim5 n) (RBSharedF114.claim6 n) (RBSharedF114.claim7 n) (RBSharedF114.claim8 n) (RBSharedF114.claim9 n) (RBSharedF114.claim10 n) (RBSharedF114.claim11 n) (RBSharedF114.claim12 n) (RBSharedF114.claim13 n) (RBSharedF114.claim14 n) (RBSharedF114.claim15 n) (RBSharedF114.claim16 n) (RBSharedF114.claim17 n) (RBSharedF114.claim18 n) (RBSharedF114.claim19 n) (RBSharedF114.claim20 n) (RBSharedF114.claim21 n) (RBSharedF114.claim22 n) (RBSharedF114.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard115 : ∀ a n, Required 115 a n → (actualMarked 115 (a+1)).coeff n < (actualMarked 115 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 115 b n → (actualMarked 115 (b+1)).coeff n < (actualMarked 115 b).coeff n)
   (RBSharedF115.claim2 n) (RBSharedF115.claim3 n) (RBSharedF115.claim4 n) (RBSharedF115.claim5 n) (RBSharedF115.claim6 n) (RBSharedF115.claim7 n) (RBSharedF115.claim8 n) (RBSharedF115.claim9 n) (RBSharedF115.claim10 n) (RBSharedF115.claim11 n) (RBSharedF115.claim12 n) (RBSharedF115.claim13 n) (RBSharedF115.claim14 n) (RBSharedF115.claim15 n) (RBSharedF115.claim16 n) (RBSharedF115.claim17 n) (RBSharedF115.claim18 n) (RBSharedF115.claim19 n) (RBSharedF115.claim20 n) (RBSharedF115.claim21 n) (RBSharedF115.claim22 n) (RBSharedF115.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard116 : ∀ a n, Required 116 a n → (actualMarked 116 (a+1)).coeff n < (actualMarked 116 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 116 b n → (actualMarked 116 (b+1)).coeff n < (actualMarked 116 b).coeff n)
   (RBSharedF116.claim2 n) (RBSharedF116.claim3 n) (RBSharedF116.claim4 n) (RBSharedF116.claim5 n) (RBSharedF116.claim6 n) (RBSharedF116.claim7 n) (RBSharedF116.claim8 n) (RBSharedF116.claim9 n) (RBSharedF116.claim10 n) (RBSharedF116.claim11 n) (RBSharedF116.claim12 n) (RBSharedF116.claim13 n) (RBSharedF116.claim14 n) (RBSharedF116.claim15 n) (RBSharedF116.claim16 n) (RBSharedF116.claim17 n) (RBSharedF116.claim18 n) (RBSharedF116.claim19 n) (RBSharedF116.claim20 n) (RBSharedF116.claim21 n) (RBSharedF116.claim22 n) (RBSharedF116.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard117 : ∀ a n, Required 117 a n → (actualMarked 117 (a+1)).coeff n < (actualMarked 117 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 117 b n → (actualMarked 117 (b+1)).coeff n < (actualMarked 117 b).coeff n)
   (RBSharedF117.claim2 n) (RBSharedF117.claim3 n) (RBSharedF117.claim4 n) (RBSharedF117.claim5 n) (RBSharedF117.claim6 n) (RBSharedF117.claim7 n) (RBSharedF117.claim8 n) (RBSharedF117.claim9 n) (RBSharedF117.claim10 n) (RBSharedF117.claim11 n) (RBSharedF117.claim12 n) (RBSharedF117.claim13 n) (RBSharedF117.claim14 n) (RBSharedF117.claim15 n) (RBSharedF117.claim16 n) (RBSharedF117.claim17 n) (RBSharedF117.claim18 n) (RBSharedF117.claim19 n) (RBSharedF117.claim20 n) (RBSharedF117.claim21 n) (RBSharedF117.claim22 n) (RBSharedF117.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard118 : ∀ a n, Required 118 a n → (actualMarked 118 (a+1)).coeff n < (actualMarked 118 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 118 b n → (actualMarked 118 (b+1)).coeff n < (actualMarked 118 b).coeff n)
   (RBSharedF118.claim2 n) (RBSharedF118.claim3 n) (RBSharedF118.claim4 n) (RBSharedF118.claim5 n) (RBSharedF118.claim6 n) (RBSharedF118.claim7 n) (RBSharedF118.claim8 n) (RBSharedF118.claim9 n) (RBSharedF118.claim10 n) (RBSharedF118.claim11 n) (RBSharedF118.claim12 n) (RBSharedF118.claim13 n) (RBSharedF118.claim14 n) (RBSharedF118.claim15 n) (RBSharedF118.claim16 n) (RBSharedF118.claim17 n) (RBSharedF118.claim18 n) (RBSharedF118.claim19 n) (RBSharedF118.claim20 n) (RBSharedF118.claim21 n) (RBSharedF118.claim22 n) (RBSharedF118.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard119 : ∀ a n, Required 119 a n → (actualMarked 119 (a+1)).coeff n < (actualMarked 119 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 119 b n → (actualMarked 119 (b+1)).coeff n < (actualMarked 119 b).coeff n)
   (RBSharedF119.claim2 n) (RBSharedF119.claim3 n) (RBSharedF119.claim4 n) (RBSharedF119.claim5 n) (RBSharedF119.claim6 n) (RBSharedF119.claim7 n) (RBSharedF119.claim8 n) (RBSharedF119.claim9 n) (RBSharedF119.claim10 n) (RBSharedF119.claim11 n) (RBSharedF119.claim12 n) (RBSharedF119.claim13 n) (RBSharedF119.claim14 n) (RBSharedF119.claim15 n) (RBSharedF119.claim16 n) (RBSharedF119.claim17 n) (RBSharedF119.claim18 n) (RBSharedF119.claim19 n) (RBSharedF119.claim20 n) (RBSharedF119.claim21 n) (RBSharedF119.claim22 n) (RBSharedF119.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard120 : ∀ a n, Required 120 a n → (actualMarked 120 (a+1)).coeff n < (actualMarked 120 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 120 b n → (actualMarked 120 (b+1)).coeff n < (actualMarked 120 b).coeff n)
   (RBSharedF120.claim2 n) (RBSharedF120.claim3 n) (RBSharedF120.claim4 n) (RBSharedF120.claim5 n) (RBSharedF120.claim6 n) (RBSharedF120.claim7 n) (RBSharedF120.claim8 n) (RBSharedF120.claim9 n) (RBSharedF120.claim10 n) (RBSharedF120.claim11 n) (RBSharedF120.claim12 n) (RBSharedF120.claim13 n) (RBSharedF120.claim14 n) (RBSharedF120.claim15 n) (RBSharedF120.claim16 n) (RBSharedF120.claim17 n) (RBSharedF120.claim18 n) (RBSharedF120.claim19 n) (RBSharedF120.claim20 n) (RBSharedF120.claim21 n) (RBSharedF120.claim22 n) (RBSharedF120.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard121 : ∀ a n, Required 121 a n → (actualMarked 121 (a+1)).coeff n < (actualMarked 121 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 121 b n → (actualMarked 121 (b+1)).coeff n < (actualMarked 121 b).coeff n)
   (RBSharedF121.claim2 n) (RBSharedF121.claim3 n) (RBSharedF121.claim4 n) (RBSharedF121.claim5 n) (RBSharedF121.claim6 n) (RBSharedF121.claim7 n) (RBSharedF121.claim8 n) (RBSharedF121.claim9 n) (RBSharedF121.claim10 n) (RBSharedF121.claim11 n) (RBSharedF121.claim12 n) (RBSharedF121.claim13 n) (RBSharedF121.claim14 n) (RBSharedF121.claim15 n) (RBSharedF121.claim16 n) (RBSharedF121.claim17 n) (RBSharedF121.claim18 n) (RBSharedF121.claim19 n) (RBSharedF121.claim20 n) (RBSharedF121.claim21 n) (RBSharedF121.claim22 n) (RBSharedF121.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard122 : ∀ a n, Required 122 a n → (actualMarked 122 (a+1)).coeff n < (actualMarked 122 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 122 b n → (actualMarked 122 (b+1)).coeff n < (actualMarked 122 b).coeff n)
   (RBSharedF122.claim2 n) (RBSharedF122.claim3 n) (RBSharedF122.claim4 n) (RBSharedF122.claim5 n) (RBSharedF122.claim6 n) (RBSharedF122.claim7 n) (RBSharedF122.claim8 n) (RBSharedF122.claim9 n) (RBSharedF122.claim10 n) (RBSharedF122.claim11 n) (RBSharedF122.claim12 n) (RBSharedF122.claim13 n) (RBSharedF122.claim14 n) (RBSharedF122.claim15 n) (RBSharedF122.claim16 n) (RBSharedF122.claim17 n) (RBSharedF122.claim18 n) (RBSharedF122.claim19 n) (RBSharedF122.claim20 n) (RBSharedF122.claim21 n) (RBSharedF122.claim22 n) (RBSharedF122.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard123 : ∀ a n, Required 123 a n → (actualMarked 123 (a+1)).coeff n < (actualMarked 123 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 123 b n → (actualMarked 123 (b+1)).coeff n < (actualMarked 123 b).coeff n)
   (RBSharedF123.claim2 n) (RBSharedF123.claim3 n) (RBSharedF123.claim4 n) (RBSharedF123.claim5 n) (RBSharedF123.claim6 n) (RBSharedF123.claim7 n) (RBSharedF123.claim8 n) (RBSharedF123.claim9 n) (RBSharedF123.claim10 n) (RBSharedF123.claim11 n) (RBSharedF123.claim12 n) (RBSharedF123.claim13 n) (RBSharedF123.claim14 n) (RBSharedF123.claim15 n) (RBSharedF123.claim16 n) (RBSharedF123.claim17 n) (RBSharedF123.claim18 n) (RBSharedF123.claim19 n) (RBSharedF123.claim20 n) (RBSharedF123.claim21 n) (RBSharedF123.claim22 n) (RBSharedF123.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard124 : ∀ a n, Required 124 a n → (actualMarked 124 (a+1)).coeff n < (actualMarked 124 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 124 b n → (actualMarked 124 (b+1)).coeff n < (actualMarked 124 b).coeff n)
   (RBSharedF124.claim2 n) (RBSharedF124.claim3 n) (RBSharedF124.claim4 n) (RBSharedF124.claim5 n) (RBSharedF124.claim6 n) (RBSharedF124.claim7 n) (RBSharedF124.claim8 n) (RBSharedF124.claim9 n) (RBSharedF124.claim10 n) (RBSharedF124.claim11 n) (RBSharedF124.claim12 n) (RBSharedF124.claim13 n) (RBSharedF124.claim14 n) (RBSharedF124.claim15 n) (RBSharedF124.claim16 n) (RBSharedF124.claim17 n) (RBSharedF124.claim18 n) (RBSharedF124.claim19 n) (RBSharedF124.claim20 n) (RBSharedF124.claim21 n) (RBSharedF124.claim22 n) (RBSharedF124.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard125 : ∀ a n, Required 125 a n → (actualMarked 125 (a+1)).coeff n < (actualMarked 125 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 125 b n → (actualMarked 125 (b+1)).coeff n < (actualMarked 125 b).coeff n)
   (RBSharedF125.claim2 n) (RBSharedF125.claim3 n) (RBSharedF125.claim4 n) (RBSharedF125.claim5 n) (RBSharedF125.claim6 n) (RBSharedF125.claim7 n) (RBSharedF125.claim8 n) (RBSharedF125.claim9 n) (RBSharedF125.claim10 n) (RBSharedF125.claim11 n) (RBSharedF125.claim12 n) (RBSharedF125.claim13 n) (RBSharedF125.claim14 n) (RBSharedF125.claim15 n) (RBSharedF125.claim16 n) (RBSharedF125.claim17 n) (RBSharedF125.claim18 n) (RBSharedF125.claim19 n) (RBSharedF125.claim20 n) (RBSharedF125.claim21 n) (RBSharedF125.claim22 n) (RBSharedF125.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard126 : ∀ a n, Required 126 a n → (actualMarked 126 (a+1)).coeff n < (actualMarked 126 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 126 b n → (actualMarked 126 (b+1)).coeff n < (actualMarked 126 b).coeff n)
   (RBSharedF126.claim2 n) (RBSharedF126.claim3 n) (RBSharedF126.claim4 n) (RBSharedF126.claim5 n) (RBSharedF126.claim6 n) (RBSharedF126.claim7 n) (RBSharedF126.claim8 n) (RBSharedF126.claim9 n) (RBSharedF126.claim10 n) (RBSharedF126.claim11 n) (RBSharedF126.claim12 n) (RBSharedF126.claim13 n) (RBSharedF126.claim14 n) (RBSharedF126.claim15 n) (RBSharedF126.claim16 n) (RBSharedF126.claim17 n) (RBSharedF126.claim18 n) (RBSharedF126.claim19 n) (RBSharedF126.claim20 n) (RBSharedF126.claim21 n) (RBSharedF126.claim22 n) (RBSharedF126.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard127 : ∀ a n, Required 127 a n → (actualMarked 127 (a+1)).coeff n < (actualMarked 127 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 127 b n → (actualMarked 127 (b+1)).coeff n < (actualMarked 127 b).coeff n)
   (RBSharedF127.claim2 n) (RBSharedF127.claim3 n) (RBSharedF127.claim4 n) (RBSharedF127.claim5 n) (RBSharedF127.claim6 n) (RBSharedF127.claim7 n) (RBSharedF127.claim8 n) (RBSharedF127.claim9 n) (RBSharedF127.claim10 n) (RBSharedF127.claim11 n) (RBSharedF127.claim12 n) (RBSharedF127.claim13 n) (RBSharedF127.claim14 n) (RBSharedF127.claim15 n) (RBSharedF127.claim16 n) (RBSharedF127.claim17 n) (RBSharedF127.claim18 n) (RBSharedF127.claim19 n) (RBSharedF127.claim20 n) (RBSharedF127.claim21 n) (RBSharedF127.claim22 n) (RBSharedF127.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard128 : ∀ a n, Required 128 a n → (actualMarked 128 (a+1)).coeff n < (actualMarked 128 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 128 b n → (actualMarked 128 (b+1)).coeff n < (actualMarked 128 b).coeff n)
   (RBSharedF128.claim2 n) (RBSharedF128.claim3 n) (RBSharedF128.claim4 n) (RBSharedF128.claim5 n) (RBSharedF128.claim6 n) (RBSharedF128.claim7 n) (RBSharedF128.claim8 n) (RBSharedF128.claim9 n) (RBSharedF128.claim10 n) (RBSharedF128.claim11 n) (RBSharedF128.claim12 n) (RBSharedF128.claim13 n) (RBSharedF128.claim14 n) (RBSharedF128.claim15 n) (RBSharedF128.claim16 n) (RBSharedF128.claim17 n) (RBSharedF128.claim18 n) (RBSharedF128.claim19 n) (RBSharedF128.claim20 n) (RBSharedF128.claim21 n) (RBSharedF128.claim22 n) (RBSharedF128.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard129 : ∀ a n, Required 129 a n → (actualMarked 129 (a+1)).coeff n < (actualMarked 129 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 129 b n → (actualMarked 129 (b+1)).coeff n < (actualMarked 129 b).coeff n)
   (RBSharedF129.claim2 n) (RBSharedF129.claim3 n) (RBSharedF129.claim4 n) (RBSharedF129.claim5 n) (RBSharedF129.claim6 n) (RBSharedF129.claim7 n) (RBSharedF129.claim8 n) (RBSharedF129.claim9 n) (RBSharedF129.claim10 n) (RBSharedF129.claim11 n) (RBSharedF129.claim12 n) (RBSharedF129.claim13 n) (RBSharedF129.claim14 n) (RBSharedF129.claim15 n) (RBSharedF129.claim16 n) (RBSharedF129.claim17 n) (RBSharedF129.claim18 n) (RBSharedF129.claim19 n) (RBSharedF129.claim20 n) (RBSharedF129.claim21 n) (RBSharedF129.claim22 n) (RBSharedF129.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard130 : ∀ a n, Required 130 a n → (actualMarked 130 (a+1)).coeff n < (actualMarked 130 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 130 b n → (actualMarked 130 (b+1)).coeff n < (actualMarked 130 b).coeff n)
   (RBSharedF130.claim2 n) (RBSharedF130.claim3 n) (RBSharedF130.claim4 n) (RBSharedF130.claim5 n) (RBSharedF130.claim6 n) (RBSharedF130.claim7 n) (RBSharedF130.claim8 n) (RBSharedF130.claim9 n) (RBSharedF130.claim10 n) (RBSharedF130.claim11 n) (RBSharedF130.claim12 n) (RBSharedF130.claim13 n) (RBSharedF130.claim14 n) (RBSharedF130.claim15 n) (RBSharedF130.claim16 n) (RBSharedF130.claim17 n) (RBSharedF130.claim18 n) (RBSharedF130.claim19 n) (RBSharedF130.claim20 n) (RBSharedF130.claim21 n) (RBSharedF130.claim22 n) (RBSharedF130.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard131 : ∀ a n, Required 131 a n → (actualMarked 131 (a+1)).coeff n < (actualMarked 131 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 131 b n → (actualMarked 131 (b+1)).coeff n < (actualMarked 131 b).coeff n)
   (RBSharedF131.claim2 n) (RBSharedF131.claim3 n) (RBSharedF131.claim4 n) (RBSharedF131.claim5 n) (RBSharedF131.claim6 n) (RBSharedF131.claim7 n) (RBSharedF131.claim8 n) (RBSharedF131.claim9 n) (RBSharedF131.claim10 n) (RBSharedF131.claim11 n) (RBSharedF131.claim12 n) (RBSharedF131.claim13 n) (RBSharedF131.claim14 n) (RBSharedF131.claim15 n) (RBSharedF131.claim16 n) (RBSharedF131.claim17 n) (RBSharedF131.claim18 n) (RBSharedF131.claim19 n) (RBSharedF131.claim20 n) (RBSharedF131.claim21 n) (RBSharedF131.claim22 n) (RBSharedF131.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard132 : ∀ a n, Required 132 a n → (actualMarked 132 (a+1)).coeff n < (actualMarked 132 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 132 b n → (actualMarked 132 (b+1)).coeff n < (actualMarked 132 b).coeff n)
   (RBSharedF132.claim2 n) (RBSharedF132.claim3 n) (RBSharedF132.claim4 n) (RBSharedF132.claim5 n) (RBSharedF132.claim6 n) (RBSharedF132.claim7 n) (RBSharedF132.claim8 n) (RBSharedF132.claim9 n) (RBSharedF132.claim10 n) (RBSharedF132.claim11 n) (RBSharedF132.claim12 n) (RBSharedF132.claim13 n) (RBSharedF132.claim14 n) (RBSharedF132.claim15 n) (RBSharedF132.claim16 n) (RBSharedF132.claim17 n) (RBSharedF132.claim18 n) (RBSharedF132.claim19 n) (RBSharedF132.claim20 n) (RBSharedF132.claim21 n) (RBSharedF132.claim22 n) (RBSharedF132.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard133 : ∀ a n, Required 133 a n → (actualMarked 133 (a+1)).coeff n < (actualMarked 133 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 133 b n → (actualMarked 133 (b+1)).coeff n < (actualMarked 133 b).coeff n)
   (RBSharedF133.claim2 n) (RBSharedF133.claim3 n) (RBSharedF133.claim4 n) (RBSharedF133.claim5 n) (RBSharedF133.claim6 n) (RBSharedF133.claim7 n) (RBSharedF133.claim8 n) (RBSharedF133.claim9 n) (RBSharedF133.claim10 n) (RBSharedF133.claim11 n) (RBSharedF133.claim12 n) (RBSharedF133.claim13 n) (RBSharedF133.claim14 n) (RBSharedF133.claim15 n) (RBSharedF133.claim16 n) (RBSharedF133.claim17 n) (RBSharedF133.claim18 n) (RBSharedF133.claim19 n) (RBSharedF133.claim20 n) (RBSharedF133.claim21 n) (RBSharedF133.claim22 n) (RBSharedF133.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard134 : ∀ a n, Required 134 a n → (actualMarked 134 (a+1)).coeff n < (actualMarked 134 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 134 b n → (actualMarked 134 (b+1)).coeff n < (actualMarked 134 b).coeff n)
   (RBSharedF134.claim2 n) (RBSharedF134.claim3 n) (RBSharedF134.claim4 n) (RBSharedF134.claim5 n) (RBSharedF134.claim6 n) (RBSharedF134.claim7 n) (RBSharedF134.claim8 n) (RBSharedF134.claim9 n) (RBSharedF134.claim10 n) (RBSharedF134.claim11 n) (RBSharedF134.claim12 n) (RBSharedF134.claim13 n) (RBSharedF134.claim14 n) (RBSharedF134.claim15 n) (RBSharedF134.claim16 n) (RBSharedF134.claim17 n) (RBSharedF134.claim18 n) (RBSharedF134.claim19 n) (RBSharedF134.claim20 n) (RBSharedF134.claim21 n) (RBSharedF134.claim22 n) (RBSharedF134.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard135 : ∀ a n, Required 135 a n → (actualMarked 135 (a+1)).coeff n < (actualMarked 135 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 135 b n → (actualMarked 135 (b+1)).coeff n < (actualMarked 135 b).coeff n)
   (RBSharedF135.claim2 n) (RBSharedF135.claim3 n) (RBSharedF135.claim4 n) (RBSharedF135.claim5 n) (RBSharedF135.claim6 n) (RBSharedF135.claim7 n) (RBSharedF135.claim8 n) (RBSharedF135.claim9 n) (RBSharedF135.claim10 n) (RBSharedF135.claim11 n) (RBSharedF135.claim12 n) (RBSharedF135.claim13 n) (RBSharedF135.claim14 n) (RBSharedF135.claim15 n) (RBSharedF135.claim16 n) (RBSharedF135.claim17 n) (RBSharedF135.claim18 n) (RBSharedF135.claim19 n) (RBSharedF135.claim20 n) (RBSharedF135.claim21 n) (RBSharedF135.claim22 n) (RBSharedF135.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard136 : ∀ a n, Required 136 a n → (actualMarked 136 (a+1)).coeff n < (actualMarked 136 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 136 b n → (actualMarked 136 (b+1)).coeff n < (actualMarked 136 b).coeff n)
   (RBSharedF136.claim2 n) (RBSharedF136.claim3 n) (RBSharedF136.claim4 n) (RBSharedF136.claim5 n) (RBSharedF136.claim6 n) (RBSharedF136.claim7 n) (RBSharedF136.claim8 n) (RBSharedF136.claim9 n) (RBSharedF136.claim10 n) (RBSharedF136.claim11 n) (RBSharedF136.claim12 n) (RBSharedF136.claim13 n) (RBSharedF136.claim14 n) (RBSharedF136.claim15 n) (RBSharedF136.claim16 n) (RBSharedF136.claim17 n) (RBSharedF136.claim18 n) (RBSharedF136.claim19 n) (RBSharedF136.claim20 n) (RBSharedF136.claim21 n) (RBSharedF136.claim22 n) (RBSharedF136.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard137 : ∀ a n, Required 137 a n → (actualMarked 137 (a+1)).coeff n < (actualMarked 137 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 137 b n → (actualMarked 137 (b+1)).coeff n < (actualMarked 137 b).coeff n)
   (RBSharedF137.claim2 n) (RBSharedF137.claim3 n) (RBSharedF137.claim4 n) (RBSharedF137.claim5 n) (RBSharedF137.claim6 n) (RBSharedF137.claim7 n) (RBSharedF137.claim8 n) (RBSharedF137.claim9 n) (RBSharedF137.claim10 n) (RBSharedF137.claim11 n) (RBSharedF137.claim12 n) (RBSharedF137.claim13 n) (RBSharedF137.claim14 n) (RBSharedF137.claim15 n) (RBSharedF137.claim16 n) (RBSharedF137.claim17 n) (RBSharedF137.claim18 n) (RBSharedF137.claim19 n) (RBSharedF137.claim20 n) (RBSharedF137.claim21 n) (RBSharedF137.claim22 n) (RBSharedF137.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard138 : ∀ a n, Required 138 a n → (actualMarked 138 (a+1)).coeff n < (actualMarked 138 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 138 b n → (actualMarked 138 (b+1)).coeff n < (actualMarked 138 b).coeff n)
   (RBSharedF138.claim2 n) (RBSharedF138.claim3 n) (RBSharedF138.claim4 n) (RBSharedF138.claim5 n) (RBSharedF138.claim6 n) (RBSharedF138.claim7 n) (RBSharedF138.claim8 n) (RBSharedF138.claim9 n) (RBSharedF138.claim10 n) (RBSharedF138.claim11 n) (RBSharedF138.claim12 n) (RBSharedF138.claim13 n) (RBSharedF138.claim14 n) (RBSharedF138.claim15 n) (RBSharedF138.claim16 n) (RBSharedF138.claim17 n) (RBSharedF138.claim18 n) (RBSharedF138.claim19 n) (RBSharedF138.claim20 n) (RBSharedF138.claim21 n) (RBSharedF138.claim22 n) (RBSharedF138.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard139 : ∀ a n, Required 139 a n → (actualMarked 139 (a+1)).coeff n < (actualMarked 139 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 139 b n → (actualMarked 139 (b+1)).coeff n < (actualMarked 139 b).coeff n)
   (RBSharedF139.claim2 n) (RBSharedF139.claim3 n) (RBSharedF139.claim4 n) (RBSharedF139.claim5 n) (RBSharedF139.claim6 n) (RBSharedF139.claim7 n) (RBSharedF139.claim8 n) (RBSharedF139.claim9 n) (RBSharedF139.claim10 n) (RBSharedF139.claim11 n) (RBSharedF139.claim12 n) (RBSharedF139.claim13 n) (RBSharedF139.claim14 n) (RBSharedF139.claim15 n) (RBSharedF139.claim16 n) (RBSharedF139.claim17 n) (RBSharedF139.claim18 n) (RBSharedF139.claim19 n) (RBSharedF139.claim20 n) (RBSharedF139.claim21 n) (RBSharedF139.claim22 n) (RBSharedF139.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard140 : ∀ a n, Required 140 a n → (actualMarked 140 (a+1)).coeff n < (actualMarked 140 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 140 b n → (actualMarked 140 (b+1)).coeff n < (actualMarked 140 b).coeff n)
   (RBSharedF140.claim2 n) (RBSharedF140.claim3 n) (RBSharedF140.claim4 n) (RBSharedF140.claim5 n) (RBSharedF140.claim6 n) (RBSharedF140.claim7 n) (RBSharedF140.claim8 n) (RBSharedF140.claim9 n) (RBSharedF140.claim10 n) (RBSharedF140.claim11 n) (RBSharedF140.claim12 n) (RBSharedF140.claim13 n) (RBSharedF140.claim14 n) (RBSharedF140.claim15 n) (RBSharedF140.claim16 n) (RBSharedF140.claim17 n) (RBSharedF140.claim18 n) (RBSharedF140.claim19 n) (RBSharedF140.claim20 n) (RBSharedF140.claim21 n) (RBSharedF140.claim22 n) (RBSharedF140.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard141 : ∀ a n, Required 141 a n → (actualMarked 141 (a+1)).coeff n < (actualMarked 141 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 141 b n → (actualMarked 141 (b+1)).coeff n < (actualMarked 141 b).coeff n)
   (RBSharedF141.claim2 n) (RBSharedF141.claim3 n) (RBSharedF141.claim4 n) (RBSharedF141.claim5 n) (RBSharedF141.claim6 n) (RBSharedF141.claim7 n) (RBSharedF141.claim8 n) (RBSharedF141.claim9 n) (RBSharedF141.claim10 n) (RBSharedF141.claim11 n) (RBSharedF141.claim12 n) (RBSharedF141.claim13 n) (RBSharedF141.claim14 n) (RBSharedF141.claim15 n) (RBSharedF141.claim16 n) (RBSharedF141.claim17 n) (RBSharedF141.claim18 n) (RBSharedF141.claim19 n) (RBSharedF141.claim20 n) (RBSharedF141.claim21 n) (RBSharedF141.claim22 n) (RBSharedF141.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard142 : ∀ a n, Required 142 a n → (actualMarked 142 (a+1)).coeff n < (actualMarked 142 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 142 b n → (actualMarked 142 (b+1)).coeff n < (actualMarked 142 b).coeff n)
   (RBSharedF142.claim2 n) (RBSharedF142.claim3 n) (RBSharedF142.claim4 n) (RBSharedF142.claim5 n) (RBSharedF142.claim6 n) (RBSharedF142.claim7 n) (RBSharedF142.claim8 n) (RBSharedF142.claim9 n) (RBSharedF142.claim10 n) (RBSharedF142.claim11 n) (RBSharedF142.claim12 n) (RBSharedF142.claim13 n) (RBSharedF142.claim14 n) (RBSharedF142.claim15 n) (RBSharedF142.claim16 n) (RBSharedF142.claim17 n) (RBSharedF142.claim18 n) (RBSharedF142.claim19 n) (RBSharedF142.claim20 n) (RBSharedF142.claim21 n) (RBSharedF142.claim22 n) (RBSharedF142.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem shard143 : ∀ a n, Required 143 a n → (actualMarked 143 (a+1)).coeff n < (actualMarked 143 a).coeff n :=
 by
  intro a n r
  exact assemble22 (fun b => Required 143 b n → (actualMarked 143 (b+1)).coeff n < (actualMarked 143 b).coeff n)
   (RBSharedF143.claim2 n) (RBSharedF143.claim3 n) (RBSharedF143.claim4 n) (RBSharedF143.claim5 n) (RBSharedF143.claim6 n) (RBSharedF143.claim7 n) (RBSharedF143.claim8 n) (RBSharedF143.claim9 n) (RBSharedF143.claim10 n) (RBSharedF143.claim11 n) (RBSharedF143.claim12 n) (RBSharedF143.claim13 n) (RBSharedF143.claim14 n) (RBSharedF143.claim15 n) (RBSharedF143.claim16 n) (RBSharedF143.claim17 n) (RBSharedF143.claim18 n) (RBSharedF143.claim19 n) (RBSharedF143.claim20 n) (RBSharedF143.claim21 n) (RBSharedF143.claim22 n) (RBSharedF143.claim23 n) a r.2.2.1 r.2.2.2.1 r
theorem complete_block : Block 2 144 := (join_block 2 73 144 (join_block 2 37 73 (join_block 2 19 37 (join_block 2 10 19 (join_block 2 6 10 (join_block 2 4 6 (join_block 2 3 4 (singleton_block 2 shard2) (singleton_block 3 shard3)) (join_block 4 5 6 (singleton_block 4 shard4) (singleton_block 5 shard5))) (join_block 6 8 10 (join_block 6 7 8 (singleton_block 6 shard6) (singleton_block 7 shard7)) (join_block 8 9 10 (singleton_block 8 shard8) (singleton_block 9 shard9)))) (join_block 10 14 19 (join_block 10 12 14 (join_block 10 11 12 (singleton_block 10 shard10) (singleton_block 11 shard11)) (join_block 12 13 14 (singleton_block 12 shard12) (singleton_block 13 shard13))) (join_block 14 16 19 (join_block 14 15 16 (singleton_block 14 shard14) (singleton_block 15 shard15)) (join_block 16 17 19 (singleton_block 16 shard16) (join_block 17 18 19 (singleton_block 17 shard17) (singleton_block 18 shard18)))))) (join_block 19 28 37 (join_block 19 23 28 (join_block 19 21 23 (join_block 19 20 21 (singleton_block 19 shard19) (singleton_block 20 shard20)) (join_block 21 22 23 (singleton_block 21 shard21) (singleton_block 22 shard22))) (join_block 23 25 28 (join_block 23 24 25 (singleton_block 23 shard23) (singleton_block 24 shard24)) (join_block 25 26 28 (singleton_block 25 shard25) (join_block 26 27 28 (singleton_block 26 shard26) (singleton_block 27 shard27))))) (join_block 28 32 37 (join_block 28 30 32 (join_block 28 29 30 (singleton_block 28 shard28) (singleton_block 29 shard29)) (join_block 30 31 32 (singleton_block 30 shard30) (singleton_block 31 shard31))) (join_block 32 34 37 (join_block 32 33 34 (singleton_block 32 shard32) (singleton_block 33 shard33)) (join_block 34 35 37 (singleton_block 34 shard34) (join_block 35 36 37 (singleton_block 35 shard35) (singleton_block 36 shard36))))))) (join_block 37 55 73 (join_block 37 46 55 (join_block 37 41 46 (join_block 37 39 41 (join_block 37 38 39 (singleton_block 37 shard37) (singleton_block 38 shard38)) (join_block 39 40 41 (singleton_block 39 shard39) (singleton_block 40 shard40))) (join_block 41 43 46 (join_block 41 42 43 (singleton_block 41 shard41) (singleton_block 42 shard42)) (join_block 43 44 46 (singleton_block 43 shard43) (join_block 44 45 46 (singleton_block 44 shard44) (singleton_block 45 shard45))))) (join_block 46 50 55 (join_block 46 48 50 (join_block 46 47 48 (singleton_block 46 shard46) (singleton_block 47 shard47)) (join_block 48 49 50 (singleton_block 48 shard48) (singleton_block 49 shard49))) (join_block 50 52 55 (join_block 50 51 52 (singleton_block 50 shard50) (singleton_block 51 shard51)) (join_block 52 53 55 (singleton_block 52 shard52) (join_block 53 54 55 (singleton_block 53 shard53) (singleton_block 54 shard54)))))) (join_block 55 64 73 (join_block 55 59 64 (join_block 55 57 59 (join_block 55 56 57 (singleton_block 55 shard55) (singleton_block 56 shard56)) (join_block 57 58 59 (singleton_block 57 shard57) (singleton_block 58 shard58))) (join_block 59 61 64 (join_block 59 60 61 (singleton_block 59 shard59) (singleton_block 60 shard60)) (join_block 61 62 64 (singleton_block 61 shard61) (join_block 62 63 64 (singleton_block 62 shard62) (singleton_block 63 shard63))))) (join_block 64 68 73 (join_block 64 66 68 (join_block 64 65 66 (singleton_block 64 shard64) (singleton_block 65 shard65)) (join_block 66 67 68 (singleton_block 66 shard66) (singleton_block 67 shard67))) (join_block 68 70 73 (join_block 68 69 70 (singleton_block 68 shard68) (singleton_block 69 shard69)) (join_block 70 71 73 (singleton_block 70 shard70) (join_block 71 72 73 (singleton_block 71 shard71) (singleton_block 72 shard72)))))))) (join_block 73 108 144 (join_block 73 90 108 (join_block 73 81 90 (join_block 73 77 81 (join_block 73 75 77 (join_block 73 74 75 (singleton_block 73 shard73) (singleton_block 74 shard74)) (join_block 75 76 77 (singleton_block 75 shard75) (singleton_block 76 shard76))) (join_block 77 79 81 (join_block 77 78 79 (singleton_block 77 shard77) (singleton_block 78 shard78)) (join_block 79 80 81 (singleton_block 79 shard79) (singleton_block 80 shard80)))) (join_block 81 85 90 (join_block 81 83 85 (join_block 81 82 83 (singleton_block 81 shard81) (singleton_block 82 shard82)) (join_block 83 84 85 (singleton_block 83 shard83) (singleton_block 84 shard84))) (join_block 85 87 90 (join_block 85 86 87 (singleton_block 85 shard85) (singleton_block 86 shard86)) (join_block 87 88 90 (singleton_block 87 shard87) (join_block 88 89 90 (singleton_block 88 shard88) (singleton_block 89 shard89)))))) (join_block 90 99 108 (join_block 90 94 99 (join_block 90 92 94 (join_block 90 91 92 (singleton_block 90 shard90) (singleton_block 91 shard91)) (join_block 92 93 94 (singleton_block 92 shard92) (singleton_block 93 shard93))) (join_block 94 96 99 (join_block 94 95 96 (singleton_block 94 shard94) (singleton_block 95 shard95)) (join_block 96 97 99 (singleton_block 96 shard96) (join_block 97 98 99 (singleton_block 97 shard97) (singleton_block 98 shard98))))) (join_block 99 103 108 (join_block 99 101 103 (join_block 99 100 101 (singleton_block 99 shard99) (singleton_block 100 shard100)) (join_block 101 102 103 (singleton_block 101 shard101) (singleton_block 102 shard102))) (join_block 103 105 108 (join_block 103 104 105 (singleton_block 103 shard103) (singleton_block 104 shard104)) (join_block 105 106 108 (singleton_block 105 shard105) (join_block 106 107 108 (singleton_block 106 shard106) (singleton_block 107 shard107))))))) (join_block 108 126 144 (join_block 108 117 126 (join_block 108 112 117 (join_block 108 110 112 (join_block 108 109 110 (singleton_block 108 shard108) (singleton_block 109 shard109)) (join_block 110 111 112 (singleton_block 110 shard110) (singleton_block 111 shard111))) (join_block 112 114 117 (join_block 112 113 114 (singleton_block 112 shard112) (singleton_block 113 shard113)) (join_block 114 115 117 (singleton_block 114 shard114) (join_block 115 116 117 (singleton_block 115 shard115) (singleton_block 116 shard116))))) (join_block 117 121 126 (join_block 117 119 121 (join_block 117 118 119 (singleton_block 117 shard117) (singleton_block 118 shard118)) (join_block 119 120 121 (singleton_block 119 shard119) (singleton_block 120 shard120))) (join_block 121 123 126 (join_block 121 122 123 (singleton_block 121 shard121) (singleton_block 122 shard122)) (join_block 123 124 126 (singleton_block 123 shard123) (join_block 124 125 126 (singleton_block 124 shard124) (singleton_block 125 shard125)))))) (join_block 126 135 144 (join_block 126 130 135 (join_block 126 128 130 (join_block 126 127 128 (singleton_block 126 shard126) (singleton_block 127 shard127)) (join_block 128 129 130 (singleton_block 128 shard128) (singleton_block 129 shard129))) (join_block 130 132 135 (join_block 130 131 132 (singleton_block 130 shard130) (singleton_block 131 shard131)) (join_block 132 133 135 (singleton_block 132 shard132) (join_block 133 134 135 (singleton_block 133 shard133) (singleton_block 134 shard134))))) (join_block 135 139 144 (join_block 135 137 139 (join_block 135 136 137 (singleton_block 135 shard135) (singleton_block 136 shard136)) (join_block 137 138 139 (singleton_block 137 shard137) (singleton_block 138 shard138))) (join_block 139 141 144 (join_block 139 140 141 (singleton_block 139 shard139) (singleton_block 140 shard140)) (join_block 141 142 144 (singleton_block 141 shard141) (join_block 142 143 144 (singleton_block 142 shard142) (singleton_block 143 shard143)))))))))
theorem full_table (k a n : Nat) (hr : Required k a n) :
 (actualMarked k (a+1)).coeff n < (actualMarked k a).coeff n :=
 complete_block k a n hr.1 (by have h := hr.2.1; omega) hr
theorem exceptional_iff (k a : Nat) (hk : 2 ≤ k) : exceptional k a = true ↔
 (∃ e : Nat, 0<e ∧ k^e=a) ∨ (∃ e : Nat, 0<e ∧ k^e=a+1) := by
 simp only [exceptional, Bool.or_eq_true, positivePower_iff k a hk, positivePower_iff k (a+1) hk]

theorem expanded_polynomial_endpoint (k a n : Nat)
 (hk : 2 ≤ k) (hku : k ≤ 143) (ha : 2 ≤ a) (hau : a ≤ 23)
 (hbin : k=2 → 5 ≤ a) (hskip : ¬(k=3 ∧ ((∃ e : Nat, 0<e ∧ k^e=a) ∨ (∃ e : Nat, 0<e ∧ k^e=a+1))))
 (hlo : max (a+5) 17 ≤ n)
 (hpos : ((∃ e : Nat, 0<e ∧ k^e=a) ∨ (∃ e : Nat, 0<e ∧ k^e=a+1)) → n ≤ a+23) (hneg : ¬((∃ e : Nat, 0<e ∧ k^e=a) ∨ (∃ e : Nat, 0<e ∧ k^e=a+1)) → n ≤ a+119) :
 (∏ h ∈ Finset.range 142, ∑ j ∈ Finset.range k,
  Polynomial.C (if h+1 == (a+1) then (j : Int) else 1) * Polynomial.X^(j*(h+1))).coeff n <
 (∏ h ∈ Finset.range 142, ∑ j ∈ Finset.range k,
  Polynomial.C (if h+1 == a then (j : Int) else 1) * Polynomial.X^(j*(h+1))).coeff n := by
 have heq := exceptional_iff k a hk
 have hr : Required k a n := by
  refine ⟨hk,hku,ha,hau,hbin,?_,hlo,?_⟩
  · rintro ⟨hk3,he⟩
    exact hskip ⟨hk3,heq.mp he⟩
  · by_cases he : exceptional k a = true
    · rw [ite_eq_left he]
      exact hpos (heq.mp he)
    · rw [ite_eq_right he]
      exact hneg (fun h => he (heq.mpr h))
 change (actualMarked k (a+1)).coeff n < (actualMarked k a).coeff n
 exact full_table k a n hr

theorem all_covered (t : Nat × Nat × Nat) (ht : t ∈ RBShared.coverage) :
 (actualMarked t.1 (t.2.1+1)).coeff t.2.2 < (actualMarked t.1 t.2.1).coeff t.2.2 :=
 full_table t.1 t.2.1 t.2.2 ((RBShared.coverage_exact _ _ _).mp ht)
theorem actual_case_count : RBShared.coverage.card = 346186 := RBShared.coverage_card
#print axioms full_table
#print axioms expanded_polynomial_endpoint
#print axioms all_covered
#print axioms actual_case_count
end RBSharedClosed

