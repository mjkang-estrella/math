import RBWeakNN
import Mathlib.Data.Nat.Find

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBWeakChain (355303 uniform weak comparisons): finite primitive chains and the two reductions

* `chainSet k c s m = {c k^(j+s) : j < m}`; telescoping `(1 - X^(c k^s)) ∏_{j<m} B_{c k^(j+s)} = 1 - X^(c k^(m+s))`;
  chain lengths with `c k^(j+s) ≤ n < c k^(m+s)` (`Nat.find`); root uniqueness and disjointness.
* `weak_of_subset`: the prefix bridge `C_sub_C_succ_eq_coeff` (cutoff `N = n`) plus deletion of an arbitrary
  sub-family `S` of the remaining factors, whose complement is coefficientwise nonnegative.
* `weak_NE`: neither marked size is a power of `k` (full chain of root `1` cancels `1 - X`).
* `weak_exc`: one marked size is `k^w`, `w ≥ 1`; partial chain of root `1` gives `1 - X^(k^w)`, two further chains
  with roots `p ≠ q` (not divisible by `k`, avoiding the neighbour) are replaced by `gI p`, `gI q` below degree `n`.
-/

namespace RBCount

open Finset

local notation "𝔛" => (PowerSeries.X : PowerSeries ℤ)

/-- The chain `{c k^(j+s) : j < m}`. -/
def chainSet (k c s m : ℕ) : Finset ℕ := (range m).image fun j => c * k ^ (j + s)

theorem mem_chainSet {k c s m y : ℕ} : y ∈ chainSet k c s m ↔ ∃ j < m, c * k ^ (j + s) = y := by
  unfold chainSet
  simp only [Finset.mem_image, Finset.mem_range]

theorem prod_chainSet {k c s m : ℕ} (hk : 2 ≤ k) (hc : 1 ≤ c) (F : ℕ → PowerSeries ℤ) :
    ∏ h ∈ chainSet k c s m, F h = ∏ j ∈ range m, F (c * k ^ (j + s)) := by
  unfold chainSet
  apply Finset.prod_image
  intro i _ j _ hij
  have h1 : k ^ (i + s) = k ^ (j + s) := Nat.eq_of_mul_eq_mul_left (by omega) hij
  have h2 := Nat.pow_right_injective hk h1
  omega

theorem chain_tele (k c s m : ℕ) :
    (1 - 𝔛 ^ (c * k ^ s)) * ∏ j ∈ range m, Bf k (c * k ^ (j + s)) = 1 - 𝔛 ^ (c * k ^ (m + s)) := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [Finset.prod_range_succ, ← mul_assoc, ih, one_sub_mul_Bf]
    rw [show c * k ^ (m + 1 + s) = c * k ^ (m + s) * k by ring]

theorem lt_pow_two_le {k : ℕ} (hk : 2 ≤ k) : ∀ n : ℕ, n < k ^ n
  | 0 => by simp
  | n + 1 => by
    have ih := lt_pow_two_le hk n
    have h2 : k ^ n * 2 ≤ k ^ n * k := Nat.mul_le_mul_left (k ^ n) hk
    rw [pow_succ]
    omega

theorem exists_len {k : ℕ} (hk : 2 ≤ k) {c : ℕ} (hc : 1 ≤ c) (s n : ℕ) :
    ∃ m, (∀ j < m, c * k ^ (j + s) ≤ n) ∧ n < c * k ^ (m + s) := by
  have hex : ∃ m, n < c * k ^ (m + s) := by
    refine ⟨n, ?_⟩
    have h1 := lt_pow_two_le hk n
    have h2 : k ^ n ≤ k ^ (n + s) := Nat.pow_le_pow_right (by omega) (by omega)
    have h3 : 1 * k ^ (n + s) ≤ c * k ^ (n + s) := Nat.mul_le_mul_right (k ^ (n + s)) hc
    omega
  refine ⟨Nat.find hex, fun j hj => ?_, Nat.find_spec hex⟩
  have := Nat.find_min hex hj
  omega

theorem chainSet_subset {k c s m n : ℕ} (hk : 2 ≤ k) (hc : 1 ≤ c)
    (hm : ∀ j < m, c * k ^ (j + s) ≤ n) : chainSet k c s m ⊆ Icc 1 n := by
  intro y hy
  obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
  have hpos : 0 < k ^ (j + s) := pow_pos (by omega) _
  have hcp : 0 < c * k ^ (j + s) := mul_pos (by omega) hpos
  exact Finset.mem_Icc.mpr ⟨by omega, hm j hj⟩

/-- Root uniqueness: `c k^i = c' k^j` with `k ∤ c, c'` forces `c = c'` and `i = j`. -/
theorem root_unique {k c c' i j : ℕ} (hk : 2 ≤ k) (hc : ¬ k ∣ c) (hc' : ¬ k ∣ c')
    (h : c * k ^ i = c' * k ^ j) : c = c' ∧ i = j := by
  have hkpos : 0 < k := by omega
  rcases lt_trichotomy i j with hij | hij | hij
  · exfalso
    obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_lt hij
    have e : c * k ^ i = (c' * k ^ (d + 1)) * k ^ i := by rw [h]; ring
    have e2 : c = c' * k ^ (d + 1) := Nat.eq_of_mul_eq_mul_right (pow_pos hkpos i) e
    exact hc ⟨c' * k ^ d, by rw [e2]; ring⟩
  · rw [hij] at h
    exact ⟨Nat.eq_of_mul_eq_mul_right (pow_pos hkpos j) h, hij⟩
  · exfalso
    obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_lt hij
    have e : c' * k ^ j = (c * k ^ (d + 1)) * k ^ j := by rw [← h]; ring
    have e2 : c' = c * k ^ (d + 1) := Nat.eq_of_mul_eq_mul_right (pow_pos hkpos j) e
    exact hc' ⟨c * k ^ d, by rw [e2]; ring⟩

theorem chain_elem_ne {k c j s y c0 w0 : ℕ} (hk : 2 ≤ k) (hc : ¬ k ∣ c) (hc0 : ¬ k ∣ c0)
    (hy : y = c0 * k ^ w0) (hne : c ≠ c0) : c * k ^ (j + s) ≠ y := fun h =>
  hne (root_unique hk hc hc0 (h.trans hy)).1

theorem disjoint_chainSet {k c c' s s' m m' : ℕ} (hk : 2 ≤ k) (hc : ¬ k ∣ c) (hc' : ¬ k ∣ c')
    (hne : c ≠ c') : Disjoint (chainSet k c s m) (chainSet k c' s' m') := by
  rw [Finset.disjoint_left]
  intro y h1 h2
  obtain ⟨i, _, hi⟩ := mem_chainSet.mp h1
  obtain ⟨j, _, hj⟩ := mem_chainSet.mp h2
  exact hne (root_unique hk hc hc' (hi.trans hj.symm)).1

/-- Deletion reduction: it suffices to control the coefficient with any sub-family `S` of the remaining
factors, against every coefficientwise nonnegative cofactor `Y`. -/
theorem weak_of_subset {k a n : ℕ} (hk : 1 ≤ k) (ha : 1 ≤ a) (han : a + 1 ≤ n) (S : Finset ℕ)
    (hS : S ⊆ ((Icc 1 n).erase a).erase (a + 1))
    (h : ∀ Y : PowerSeries ℤ, NN Y →
      0 ≤ PowerSeries.coeff n ((1 - 𝔛) * pairF k a * (∏ h ∈ S, Bf k h) * Y)) :
    C k (a + 1) n ≤ C k a n := by
  have e := C_sub_C_succ_eq_coeff (k := k) (a := a) (N := n) (n := n) hk ha han le_rfl
  rw [← Finset.prod_sdiff hS] at e
  have hY : NN (∏ h ∈ (((Icc 1 n).erase a).erase (a + 1)) \ S, Bf k h) :=
    NN_prod _ _ fun h _ => NN_Bf k h
  have h2 := h _ hY
  have e2 : (1 - 𝔛) * pairF k a * ((∏ h ∈ (((Icc 1 n).erase a).erase (a + 1)) \ S, Bf k h) *
      ∏ h ∈ S, Bf k h) = (1 - 𝔛) * pairF k a * (∏ h ∈ S, Bf k h) *
      ∏ h ∈ (((Icc 1 n).erase a).erase (a + 1)) \ S, Bf k h := by ring
  rw [e2] at e
  omega

/-- Non-exceptional case: neither marked size is a power of `k`. -/
theorem weak_NE {k a n : ℕ} (hk : 2 ≤ k) (ha : 1 ≤ a) (han : a + 1 ≤ n)
    (hpow : ∀ w, k ^ w ≠ a ∧ k ^ w ≠ a + 1) : C k (a + 1) n ≤ C k a n := by
  obtain ⟨m, hm1, hm2⟩ := exists_len hk (le_refl 1) 0 n
  apply weak_of_subset (by omega) ha han (chainSet k 1 0 m)
  · intro y hy
    have hsub := chainSet_subset hk (le_refl 1) hm1 hy
    obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
    have e : 1 * k ^ (j + 0) = k ^ j := by simp
    rw [e] at hsub ⊢
    exact Finset.mem_erase.mpr ⟨(hpow j).2, Finset.mem_erase.mpr ⟨(hpow j).1, hsub⟩⟩
  · intro Y hY
    rw [prod_chainSet hk (le_refl 1) (Bf k)]
    have t := chain_tele k 1 0 m
    rw [show 1 * k ^ 0 = 1 by simp] at t
    set P := ∏ j ∈ range m, Bf k (1 * k ^ (j + 0)) with hP
    have e1 : (1 - 𝔛) * pairF k a * P * Y = ((1 - 𝔛) * pairF k a * Y) * P := by ring
    rw [e1, coeff_mul_tele (le_refl 1) hm2 t]
    have hg := one_sub_mul_gI (le_refl 1)
    rw [pow_one] at hg
    have e2 : (1 - 𝔛) * pairF k a * Y * gI 1 = pairF k a * Y := by
      linear_combination (pairF k a * Y) * hg
    rw [e2]
    exact NN_mul (NN_pairF k a) hY n

/-- Exceptional case: `k^w ∈ {a, a+1}` with `w ≥ 1`; kernel supplied by `hK`. -/
theorem weak_exc {k a n w p q : ℕ} (hk : 2 ≤ k) (ha : 1 ≤ a) (han : a + 1 ≤ n) (hw : 1 ≤ w)
    (hx : k ^ w = a ∨ k ^ w = a + 1) (hlow : k ^ (w - 1) < a)
    (hp : 2 ≤ p) (hq : 2 ≤ q) (hpq : p ≠ q) (hkp : ¬ k ∣ p) (hkq : ¬ k ∣ q)
    (hyp : k ^ w = a + 1 → a ≠ p ∧ a ≠ q) (hyq : k ^ w = a → a + 1 ≠ p ∧ a + 1 ≠ q)
    (hK : NN ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q)) :
    C k (a + 1) n ≤ C k a n := by
  have hk1 : ¬ k ∣ 1 := fun h => by
    have := Nat.le_of_dvd one_pos h
    omega
  have hkw : k ∣ k ^ w := by
    obtain ⟨w', rfl⟩ := Nat.exists_eq_add_of_le hw
    exact ⟨k ^ w', by ring⟩
  have hmark : ∀ c, ¬ k ∣ c → 2 ≤ c → (k ^ w = a + 1 → a ≠ c) → (k ^ w = a → a + 1 ≠ c) →
      ∀ j, c * k ^ (j + 0) ≠ a ∧ c * k ^ (j + 0) ≠ a + 1 := by
    intro c hc hc2 h1 h2 j
    rcases hx with hxa | hxa
    · have hka : k ∣ a := hxa ▸ hkw
      have hnd : ¬ k ∣ a + 1 := fun h => hk1 ((Nat.dvd_add_right hka).mp h)
      exact ⟨chain_elem_ne (w0 := w) hk hc hk1 (by rw [← hxa, one_mul]) (by omega),
        chain_elem_ne (w0 := 0) hk hc hnd (by rw [pow_zero, mul_one]) (fun h => h2 hxa h.symm)⟩
    · have hka : k ∣ a + 1 := hxa ▸ hkw
      have hnd : ¬ k ∣ a := fun h => hk1 ((Nat.dvd_add_right h).mp hka)
      exact ⟨chain_elem_ne (w0 := 0) hk hc hnd (by rw [pow_zero, mul_one]) (fun h => h1 hxa h.symm),
        chain_elem_ne (w0 := w) hk hc hk1 (by rw [← hxa, one_mul]) (by omega)⟩
  obtain ⟨mp, hmp1, hmp2⟩ := exists_len hk (by omega : 1 ≤ p) 0 n
  obtain ⟨mq, hmq1, hmq2⟩ := exists_len hk (by omega : 1 ≤ q) 0 n
  have hPp := hmark p hkp hp (fun h => (hyp h).1) (fun h => (hyq h).1)
  have hPq := hmark q hkq hq (fun h => (hyp h).2) (fun h => (hyq h).2)
  apply weak_of_subset (by omega) ha han
    (chainSet k 1 0 w ∪ (chainSet k p 0 mp ∪ chainSet k q 0 mq))
  · intro y hy
    rw [Finset.mem_union, Finset.mem_union] at hy
    rcases hy with hy | hy | hy
    · obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
      have hle : k ^ (j + 0) ≤ k ^ (w - 1) := Nat.pow_le_pow_right (by omega) (by omega)
      have hpos : 0 < k ^ (j + 0) := pow_pos (by omega) _
      exact Finset.mem_erase.mpr ⟨by omega, Finset.mem_erase.mpr ⟨by omega,
        Finset.mem_Icc.mpr ⟨by omega, by omega⟩⟩⟩
    · have hsub := chainSet_subset hk (by omega : 1 ≤ p) hmp1 hy
      obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
      exact Finset.mem_erase.mpr ⟨(hPp j).2, Finset.mem_erase.mpr ⟨(hPp j).1, hsub⟩⟩
    · have hsub := chainSet_subset hk (by omega : 1 ≤ q) hmq1 hy
      obtain ⟨j, hj, rfl⟩ := mem_chainSet.mp hy
      exact Finset.mem_erase.mpr ⟨(hPq j).2, Finset.mem_erase.mpr ⟨(hPq j).1, hsub⟩⟩
  · intro Y hY
    have d1 : Disjoint (chainSet k 1 0 w) (chainSet k p 0 mp) :=
      disjoint_chainSet hk hk1 hkp (by omega)
    have d2 : Disjoint (chainSet k 1 0 w) (chainSet k q 0 mq) :=
      disjoint_chainSet hk hk1 hkq (by omega)
    have d3 : Disjoint (chainSet k p 0 mp) (chainSet k q 0 mq) := disjoint_chainSet hk hkp hkq hpq
    rw [Finset.prod_union (Finset.disjoint_union_right.mpr ⟨d1, d2⟩), Finset.prod_union d3,
      prod_chainSet hk (le_refl 1) (Bf k), prod_chainSet hk (by omega : 1 ≤ p) (Bf k),
      prod_chainSet hk (by omega : 1 ≤ q) (Bf k)]
    have t0 := chain_tele k 1 0 w
    have tp := chain_tele k p 0 mp
    have tq := chain_tele k q 0 mq
    rw [show 1 * k ^ 0 = 1 by simp, show 1 * k ^ (w + 0) = k ^ w by simp, pow_one] at t0
    rw [show p * k ^ 0 = p by simp] at tp
    rw [show q * k ^ 0 = q by simp] at tq
    set P0 := ∏ j ∈ range w, Bf k (1 * k ^ (j + 0)) with hP0
    set Pp := ∏ j ∈ range mp, Bf k (p * k ^ (j + 0)) with hPp'
    set Pq := ∏ j ∈ range mq, Bf k (q * k ^ (j + 0)) with hPq'
    have e1 : (1 - 𝔛) * pairF k a * (P0 * (Pp * Pq)) * Y =
        ((1 - 𝔛) * P0 * pairF k a * Y * Pq) * Pp := by ring
    rw [e1, coeff_mul_tele (by omega) hmp2 tp]
    have e2 : (1 - 𝔛) * P0 * pairF k a * Y * Pq * gI p =
        ((1 - 𝔛) * P0 * pairF k a * Y * gI p) * Pq := by ring
    rw [e2, coeff_mul_tele (by omega) hmq2 tq, t0]
    have e3 : (1 - 𝔛 ^ (k ^ w)) * pairF k a * Y * gI p * gI q =
        ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q) * Y := by ring
    rw [e3]
    exact NN_mul hK hY n

end RBCount

#print axioms RBCount.root_unique
#print axioms RBCount.weak_of_subset
#print axioms RBCount.weak_NE
#print axioms RBCount.weak_exc
