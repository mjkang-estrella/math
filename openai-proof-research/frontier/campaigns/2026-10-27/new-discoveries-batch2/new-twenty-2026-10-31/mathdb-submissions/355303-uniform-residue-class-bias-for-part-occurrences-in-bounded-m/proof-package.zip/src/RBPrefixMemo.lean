import RBPrefixCheck
import Mathlib.Data.List.GetD
namespace RBPrefix
open scoped BigOperators
def memo (k N : Nat) : List (Nat × Bool) → List Int
| [] => (List.range (N+1)).map (fun n => if n=0 then 1 else 0)
| (h,b)::hs =>
 let prev := memo k N hs
 (List.range (N+1)).map (fun n => ∑ j ∈ Finset.range k,
   if j*h ≤ n then weight b j * prev.getD (n-j*h) 0 else 0)
theorem get_map_range (N n : Nat) (f : Nat → Int) (hn : n ≤ N) :
 ((List.range (N+1)).map f).getD n 0 = f n := by
 simp [List.getD_eq_getElem?_getD, Nat.lt_succ_of_le hn]
theorem memo_eq (k N : Nat) (hs : List (Nat × Bool)) (n : Nat) (hn : n ≤ N) :
 (memo k N hs).getD n 0 = coeffRun k hs n := by
 induction hs generalizing n with
 | nil => simpa only [memo, coeffRun] using get_map_range N n _ hn
 | cons x hs ih =>
   rcases x with ⟨h,b⟩
   simp only [memo, get_map_range N n _ hn, coeffRun]
   apply Finset.sum_congr rfl
   intro j _
   split_ifs with hj
   · rw [ih (n-j*h) (by omega)]
   · rfl
def fastCount (k a n : Nat) : Int := (memo k 142 (factors 142 a)).getD n 0
theorem fastCount_eq (k a n : Nat) (hn : n ≤ 142) : fastCount k a n = count k a 142 n := memo_eq _ _ _ _ hn
#print axioms memo_eq
end RBPrefix
