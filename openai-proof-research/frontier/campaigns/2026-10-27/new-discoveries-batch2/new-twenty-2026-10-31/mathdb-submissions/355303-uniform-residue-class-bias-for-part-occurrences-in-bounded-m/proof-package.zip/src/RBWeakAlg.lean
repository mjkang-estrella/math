import RBWeakNN

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBWeakAlg (355303 uniform weak comparisons): symbolic kernels

* `Af_closed`: `A_h (1 - X^h)^2 = X^h (1 - X^(hk)) - k X^(hk) (1 - X^h)` (saturation term retained).
* `Hk k = X * Bf k 2 - k X^k`, `Hk (k+2) = X^2 Hk k + X (1 - X^(k+1))^2`.
* `N1_gI`: `(A_1 B_2 - A_2 B_1) * gI k = Hk k * gI 1 * gI 2` (from a polynomial identity in `X, X^k, k`).
* `NN_Hk_odd`, `NN_Hk_even` (base `H_4 (1 - X^6) = (1-X)(1-X^2)(1-X^3) Q4`).
* `NN_kernel_coin`, and the two explicit `k = 3` kernels for the marked pairs `(2,3)` and `(3,4)`.
-/

namespace RBCount

open Finset

local notation "𝔛" => (PowerSeries.X : PowerSeries ℤ)

theorem Af_closed (k h : ℕ) :
    Af k h * (1 - 𝔛 ^ h) ^ 2 =
      𝔛 ^ h * (1 - 𝔛 ^ (h * k)) - (k : PowerSeries ℤ) * 𝔛 ^ (h * k) * (1 - 𝔛 ^ h) := by
  induction k with
  | zero => simp [Af]
  | succ k ih =>
    have hA : Af (k + 1) h = Af k h + PowerSeries.C (k : ℤ) * 𝔛 ^ (h * k) := by
      unfold Af
      rw [Finset.sum_range_succ]
    rw [hA, map_natCast]
    push_cast
    linear_combination ih

/-- `H_k = X ∑_{j<k} X^(2j) - k X^k`. -/
noncomputable def Hk (k : ℕ) : PowerSeries ℤ := 𝔛 * Bf k 2 - (k : PowerSeries ℤ) * 𝔛 ^ k

theorem Hk_closed (k : ℕ) :
    Hk k * (1 - 𝔛 ^ 2) = 𝔛 * (1 - 𝔛 ^ (2 * k)) - (k : PowerSeries ℤ) * 𝔛 ^ k * (1 - 𝔛 ^ 2) := by
  have g := one_sub_mul_Bf k 2
  unfold Hk
  linear_combination 𝔛 * g

theorem Hk_succ_succ (k : ℕ) : Hk (k + 2) = 𝔛 ^ 2 * Hk k + 𝔛 * (1 - 𝔛 ^ (k + 1)) ^ 2 := by
  have g := one_sub_mul_Bf k 2
  have hB : Bf (k + 2) 2 = Bf k 2 + 𝔛 ^ (2 * k) + 𝔛 ^ (2 * (k + 1)) := by
    unfold Bf
    rw [Finset.sum_range_succ, Finset.sum_range_succ]
  unfold Hk
  rw [hB]
  push_cast
  linear_combination 𝔛 * g

theorem N1_full (k : ℕ) :
    (Af k 1 * Bf k 2 - Af k 2 * Bf k 1) * (1 - 𝔛) ^ 2 * (1 - 𝔛 ^ 2) ^ 2 =
      Hk k * (1 - 𝔛 ^ k) * (1 - 𝔛) * (1 - 𝔛 ^ 2) := by
  have hA1 := Af_closed k 1
  have hA2 := Af_closed k 2
  have hB1 := one_sub_mul_Bf k 1
  have hB2 := one_sub_mul_Bf k 2
  have hH := Hk_closed k
  linear_combination (Bf k 2 * (1 - 𝔛 ^ 2) * (1 - 𝔛 ^ 2)) * hA1
    + ((𝔛 * (1 - 𝔛 ^ k) - (k : PowerSeries ℤ) * 𝔛 ^ k * (1 - 𝔛)) * (1 - 𝔛 ^ 2)) * hB2
    - (Bf k 1 * (1 - 𝔛) * (1 - 𝔛)) * hA2
    - ((𝔛 ^ 2 * (1 - 𝔛 ^ (2 * k)) - (k : PowerSeries ℤ) * 𝔛 ^ (2 * k) * (1 - 𝔛 ^ 2)) * (1 - 𝔛)) * hB1
    - ((1 - 𝔛 ^ k) * (1 - 𝔛)) * hH

theorem N1_gI (k : ℕ) (hk : 1 ≤ k) :
    (Af k 1 * Bf k 2 - Af k 2 * Bf k 1) * gI k = Hk k * gI 1 * gI 2 := by
  have hfull := N1_full k
  have e1 := one_sub_mul_gI (le_refl 1)
  have e2 := one_sub_mul_gI (by omega : 1 ≤ 2)
  have ek := one_sub_mul_gI hk
  rw [pow_one] at e1
  set N := Af k 1 * Bf k 2 - Af k 2 * Bf k 1 with hN
  linear_combination (gI k * gI 1 ^ 2 * gI 2 ^ 2) * hfull
    + (-(N * gI k) * (((1 - 𝔛) * gI 1) + 1) * ((1 - 𝔛 ^ 2) * gI 2) ^ 2
        + Hk k * gI 1 * gI 2 * ((1 - 𝔛 ^ 2) * gI 2)) * e1
    + (-(N * gI k) * (((1 - 𝔛 ^ 2) * gI 2) + 1) + Hk k * gI 1 * gI 2) * e2
    + (Hk k * gI 1 * gI 2 * ((1 - 𝔛) * gI 1) * ((1 - 𝔛 ^ 2) * gI 2)) * ek

theorem NN_Hk_odd (t : ℕ) : NN (Hk (2 * t + 1) * gI 1 * gI 2) := by
  induction t with
  | zero =>
    have h1 : Hk (2 * 0 + 1) = 0 := by simp [Hk, Bf]
    rw [h1, zero_mul, zero_mul]
    exact NN_zero
  | succ t ih =>
    rw [show 2 * (t + 1) + 1 = 2 * t + 1 + 2 by ring, Hk_succ_succ]
    have e : (𝔛 ^ 2 * Hk (2 * t + 1) + 𝔛 * (1 - 𝔛 ^ (2 * t + 1 + 1)) ^ 2) * gI 1 * gI 2 =
        𝔛 ^ 2 * (Hk (2 * t + 1) * gI 1 * gI 2) +
          𝔛 * ((1 - 𝔛 ^ (1 * (2 * t + 2))) * gI 1) * ((1 - 𝔛 ^ (2 * (t + 1))) * gI 2) := by ring
    rw [e, gI_mul_geom (le_refl 1), gI_mul_geom (by omega : 1 ≤ 2)]
    exact NN_add (NN_mul (NN_X_pow 2) ih) (NN_mul (NN_mul NN_X (NN_Bf _ _)) (NN_Bf _ _))

/-- `Q4 = X + X^2 + 3X^3 + 3X^5 + X^6 + X^7`, written as a sum of monomials. -/
noncomputable def Q4 : PowerSeries ℤ :=
  𝔛 + 𝔛 ^ 2 + 𝔛 ^ 3 + 𝔛 ^ 3 + 𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 5 + 𝔛 ^ 5 + 𝔛 ^ 6 + 𝔛 ^ 7

theorem NN_Q4 : NN Q4 := by
  unfold Q4
  exact NN_add (NN_add (NN_add (NN_add (NN_add (NN_add (NN_add (NN_add (NN_add NN_X (NN_X_pow 2))
    (NN_X_pow 3)) (NN_X_pow 3)) (NN_X_pow 3)) (NN_X_pow 5)) (NN_X_pow 5)) (NN_X_pow 5))
    (NN_X_pow 6)) (NN_X_pow 7)

theorem Hk_four_cert : Hk 4 * (1 - 𝔛 ^ 6) = (1 - 𝔛) * (1 - 𝔛 ^ 2) * (1 - 𝔛 ^ 3) * Q4 := by
  simp only [Hk, Bf, Q4, Finset.sum_range_succ, Finset.sum_range_zero, Nat.cast_ofNat]
  ring

theorem Hk_four_gI : Hk 4 * gI 1 * gI 2 * gI 3 = Q4 * gI 6 := by
  have h4 := Hk_four_cert
  have e1 := one_sub_mul_gI (le_refl 1)
  have e2 := one_sub_mul_gI (by omega : 1 ≤ 2)
  have e3 := one_sub_mul_gI (by omega : 1 ≤ 3)
  have e6 := one_sub_mul_gI (by omega : 1 ≤ 6)
  rw [pow_one] at e1
  linear_combination (gI 1 * gI 2 * gI 3 * gI 6) * h4 - (Hk 4 * gI 1 * gI 2 * gI 3) * e6
    + (Q4 * gI 6 * (((1 - 𝔛 ^ 2) * gI 2) * ((1 - 𝔛 ^ 3) * gI 3))) * e1
    + (Q4 * gI 6 * ((1 - 𝔛 ^ 3) * gI 3)) * e2 + (Q4 * gI 6) * e3

theorem NN_Hk_even (t : ℕ) : NN (Hk (2 * t + 4) * gI 1 * gI 2 * gI 3) := by
  induction t with
  | zero =>
    rw [show 2 * 0 + 4 = 4 by rfl, Hk_four_gI]
    exact NN_mul NN_Q4 (NN_gI 6)
  | succ t ih =>
    rw [show 2 * (t + 1) + 4 = 2 * t + 4 + 2 by ring, Hk_succ_succ]
    have e : (𝔛 ^ 2 * Hk (2 * t + 4) + 𝔛 * (1 - 𝔛 ^ (2 * t + 4 + 1)) ^ 2) * gI 1 * gI 2 * gI 3 =
        𝔛 ^ 2 * (Hk (2 * t + 4) * gI 1 * gI 2 * gI 3) +
          𝔛 * ((1 - 𝔛 ^ (1 * (2 * t + 5))) * gI 1) *
            ((1 - 𝔛 ^ (2 * (t + 1) + 3 * 1)) * gI 2 * gI 3) := by ring
    rw [e, gI_mul_geom (le_refl 1)]
    exact NN_add (NN_mul (NN_X_pow 2) ih)
      (NN_mul (NN_mul NN_X (NN_Bf _ _)) (NN_coin (by omega) (by omega) _ _))

/-- Coin kernel: `NN ((1 - X^(k^w)) F gI p gI q)` whenever `k^w = p u + q v`. -/
theorem NN_kernel_coin {k a p q u v w : ℕ} (hp : 1 ≤ p) (hq : 1 ≤ q) (h : k ^ w = p * u + q * v) :
    NN ((1 - 𝔛 ^ (k ^ w)) * pairF k a * gI p * gI q) := by
  rw [h]
  have e : (1 - 𝔛 ^ (p * u + q * v)) * pairF k a * gI p * gI q =
      pairF k a * ((1 - 𝔛 ^ (p * u + q * v)) * gI p * gI q) := by ring
  rw [e]
  exact NN_mul (NN_pairF k a) (NN_coin hp hq u v)

theorem pairF_three (a : ℕ) :
    pairF 3 a = 𝔛 ^ a + 2 * 𝔛 ^ (2 * a) * (1 + 𝔛) + 𝔛 ^ (3 * a + 1) := by
  simp [pairF, Finset.sum_range_succ, map_ofNat]
  ring

/-- `k = 3`, marked pair `(2,3)` (`a + 1 = 3`): roots `4, 5`. -/
theorem NN_kernel_three_two : NN ((1 - 𝔛 ^ (3 ^ 1)) * pairF 3 2 * gI 4 * gI 5) := by
  have e4 := one_sub_mul_gI (by omega : 1 ≤ 4)
  have e5 := one_sub_mul_gI (by omega : 1 ≤ 5)
  have h : (1 - 𝔛 ^ (3 ^ 1)) * pairF 3 2 * gI 4 * gI 5 =
      𝔛 ^ 2 * gI 4 + (𝔛 ^ 4 * gI 5 + 𝔛 ^ 4 * gI 5) + 𝔛 ^ 5 * gI 4 := by
    rw [pairF_three]
    linear_combination (𝔛 ^ 2 * gI 4 + 𝔛 ^ 5 * gI 4) * e5 + (2 * 𝔛 ^ 4 * gI 5) * e4
  rw [h]
  exact NN_add (NN_add (NN_mul (NN_X_pow 2) (NN_gI 4))
    (NN_add (NN_mul (NN_X_pow 4) (NN_gI 5)) (NN_mul (NN_X_pow 4) (NN_gI 5))))
    (NN_mul (NN_X_pow 5) (NN_gI 4))

/-- `k = 3`, marked pair `(3,4)` (`a = 3`): root `2` (root `5` unused). -/
theorem NN_kernel_three_three : NN ((1 - 𝔛 ^ (3 ^ 1)) * pairF 3 3 * gI 2 * gI 5) := by
  have e2 := one_sub_mul_gI (by omega : 1 ≤ 2)
  have h : (1 - 𝔛 ^ (3 ^ 1)) * pairF 3 3 * gI 2 * gI 5 =
      (𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 7 + 𝔛 ^ 9 + 𝔛 ^ 11 + 𝔛 ^ 6 + 𝔛 ^ 8 + 𝔛 ^ 7 + 𝔛 ^ 7) * gI 5 := by
    rw [pairF_three]
    linear_combination
      ((𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 7 + 𝔛 ^ 9 + 𝔛 ^ 11 + 𝔛 ^ 6 + 𝔛 ^ 8 + 𝔛 ^ 7 + 𝔛 ^ 7) * gI 5) * e2
  rw [h]
  exact NN_mul (NN_add (NN_add (NN_add (NN_add (NN_add (NN_add (NN_add (NN_add (NN_X_pow 3)
    (NN_X_pow 5)) (NN_X_pow 7)) (NN_X_pow 9)) (NN_X_pow 11)) (NN_X_pow 6)) (NN_X_pow 8))
    (NN_X_pow 7)) (NN_X_pow 7)) (NN_gI 5)

end RBCount

#print axioms RBCount.N1_gI
#print axioms RBCount.NN_Hk_odd
#print axioms RBCount.NN_Hk_even
#print axioms RBCount.NN_kernel_three_two
#print axioms RBCount.NN_kernel_three_three
