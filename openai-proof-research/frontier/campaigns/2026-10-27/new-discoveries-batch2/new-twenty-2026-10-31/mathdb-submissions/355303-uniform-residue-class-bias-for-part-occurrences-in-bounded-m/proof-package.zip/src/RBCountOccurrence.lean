import RBCountDefs
import Mathlib.Algebra.Order.BigOperators.Group.Multiset

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBCountOccurrence (355303 pilot A): finite occurrence decomposition

* `C_size_zero`, `C_eq_zero_of_lt`, `C_top_zero`: vanishing of `C` at size `0` and above `n`.
* `D_eq_sum_C_of`, `D_eq_sum_C`, `D_eq_sum_range`: FINITE decomposition of `D` as a sum of `C`
  over the actual positive part sizes in the residue class (no progression series).
* `countRestricted_eq_univ`, `C_stable`, `D_stable`: `k`-stability for `n < k`.
-/

namespace RBCount

open Finset

theorem count_eq_zero_of_not_mem' {s : Multiset ℕ} {a : ℕ} (h : a ∉ s) : s.count a = 0 := by
  by_contra hne
  exact h (Multiset.count_pos.mp (Nat.pos_of_ne_zero hne))

/-- No partition has a part of size `0`. -/
theorem C_size_zero (k n : ℕ) : C k 0 n = 0 := by
  unfold C
  apply Finset.sum_eq_zero
  intro p _
  apply count_eq_zero_of_not_mem'
  intro h
  exact Nat.lt_irrefl 0 (p.parts_pos h)

/-- (M1.2) Sizes above `n` never occur. -/
theorem C_eq_zero_of_lt {k a n : ℕ} (h : n < a) : C k a n = 0 := by
  unfold C
  apply Finset.sum_eq_zero
  intro p _
  apply count_eq_zero_of_not_mem'
  intro ha
  have := Nat.Partition.le_of_mem_parts ha
  omega

/-- Top boundary: `C k (n+1) n = 0`. -/
theorem C_top_zero (k n : ℕ) : C k (n + 1) n = 0 :=
  C_eq_zero_of_lt (Nat.lt_succ_self n)

theorem card_filter_eq_sum_count {n : ℕ} (p : n.Partition) (S : Finset ℕ)
    (hS : ∀ x, 1 ≤ x → x ≤ n → x ∈ S) (P : ℕ → Prop) [DecidablePred P] :
    (p.parts.filter P).card = ∑ a ∈ S.filter P, p.parts.count a := by
  have hms : ∀ a ∈ p.parts.filter P, a ∈ S := by
    intro a ha
    have ha' := Multiset.mem_of_mem_filter ha
    exact hS a (p.parts_pos ha') (Nat.Partition.le_of_mem_parts ha')
  rw [← Multiset.sum_count_eq_card hms, Finset.sum_filter]
  refine Finset.sum_congr rfl fun a _ => ?_
  rw [Multiset.count_filter]

/-- Finite decomposition over any finite index set containing `[1, n]`. -/
theorem D_eq_sum_C_of (k r t n : ℕ) (S : Finset ℕ) (hS : ∀ x, 1 ≤ x → x ≤ n → x ∈ S) :
    D k r t n = ∑ a ∈ S.filter (fun a => a % t = r % t), C k a n := by
  unfold D C
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl fun p _ => card_filter_eq_sum_count p S hS _

/-- (M1.1) `D = Σ C` over the actual positive sizes `a ∈ [1, n]` with `a ≡ r (mod t)`. -/
theorem D_eq_sum_C (k r t n : ℕ) :
    D k r t n = ∑ a ∈ (Icc 1 n).filter (fun a => a % t = r % t), C k a n :=
  D_eq_sum_C_of k r t n (Icc 1 n) fun x h1 h2 => Finset.mem_Icc.mpr ⟨h1, h2⟩

/-- Range form of the decomposition, for any cutoff `m > n`. -/
theorem D_eq_sum_range (k r t n m : ℕ) (hm : n < m) :
    D k r t n = ∑ a ∈ range m, if a % t = r % t then C k a n else 0 := by
  rw [D_eq_sum_C_of k r t n (range m) (fun x _ h2 => Finset.mem_range.mpr (by omega)),
    Finset.sum_filter]

theorem card_parts_le {n : ℕ} (p : n.Partition) : Multiset.card p.parts ≤ n := by
  have h := Multiset.card_nsmul_le_sum (fun x (hx : x ∈ p.parts) => (p.parts_pos hx : 1 ≤ x))
  have h2 : Multiset.card p.parts • (1 : ℕ) = Multiset.card p.parts := by simp
  rw [h2, p.parts_sum] at h
  exact h

/-- For `n < k` the multiplicity restriction is vacuous. -/
theorem countRestricted_eq_univ {n k : ℕ} (hk : n < k) :
    Nat.Partition.countRestricted n k = Finset.univ := by
  unfold Nat.Partition.countRestricted
  apply Finset.filter_true_of_mem
  intro p _ i _
  exact lt_of_le_of_lt ((Multiset.count_le_card i p.parts).trans (card_parts_le p)) hk

/-- (M1.3) `k`-stability. -/
theorem C_stable {k k' a n : ℕ} (hk : n < k) (hk' : n < k') : C k a n = C k' a n := by
  unfold C
  rw [countRestricted_eq_univ hk, countRestricted_eq_univ hk']

theorem D_stable {k k' r t n : ℕ} (hk : n < k) (hk' : n < k') : D k r t n = D k' r t n := by
  unfold D
  rw [countRestricted_eq_univ hk, countRestricted_eq_univ hk']

end RBCount

#print axioms RBCount.D_eq_sum_C
#print axioms RBCount.D_eq_sum_range
#print axioms RBCount.C_eq_zero_of_lt
#print axioms RBCount.C_stable
