import RBAbsorbFibers
noncomputable section
namespace RBAbsorb

def fmap2 {n d : ℕ} (hd : d<n) (p : Fiber n d) : Fiber n (d+2) ⊕ Fiber n (d+9) := by
  let w := fmin hd p
  have hw := fmin_spec hd p
  by_cases h : w=9
  · exact Sum.inr (fiberDelete p 9 (by simpa only [show fmin hd p=9 from h] using hw.1))
  · have hb : 11≤w := by have := p.property.1 w hw.1; omega
    exact Sum.inl (fiberLower p w 2 hw.1 rfl hb)

theorem fmap2_injective {n d : ℕ} (hd : d<n) : Function.Injective (fmap2 hd) := by
  intro p q he
  unfold fmap2 at he
  dsimp only at he
  split_ifs at he
  all_goals simp only [Sum.inl.injEq, Sum.inr.injEq] at he
  all_goals apply Subtype.ext
  all_goals first
    | exact deletion_injective (s:=p.val) (t:=q.val) (w:=9)
        (by simpa only [show fmin hd p=9 by assumption] using (fmin_spec hd p).1)
        (by simpa only [show fmin hd q=9 by assumption] using (fmin_spec hd q).1)
        (congrArg Subtype.val he)
    | have hp := (p.property.1 _ (fmin_spec hd p).1).2
      have hq := (q.property.1 _ (fmin_spec hd q).1).2
      exact lower_injective (k:=2) (fmin_spec hd p) (fmin_spec hd q)
        (by omega) (by omega) (congrArg Subtype.val he)

theorem shifted_absorb2 {n d : ℕ} (hd : d<n) : shifted n d ≤ shifted n (d+2) + shifted n (d+9) := by
  have h := Fintype.card_le_of_injective (fmap2 hd) (fmap2_injective hd)
  rw [Fintype.card_sum] at h
  have hh : (Fintype.card (Fiber n d) : ℤ) ≤ (Fintype.card (Fiber n (d+2)) : ℤ) + (Fintype.card (Fiber n (d+9)) : ℤ) := by exact_mod_cast h
  simpa only [card_fiber] using hh

def fmap4 {n d : ℕ} (hd : d<n) (p : Fiber n d) :
    Fiber n (d+4) ⊕ (Fiber n (d+9) ⊕ Fiber n (d+11)) := by
  let w := fmin hd p
  have hw := fmin_spec hd p
  by_cases h9 : w=9
  · exact Sum.inr (Sum.inl (fiberDelete p 9 (by simpa only [show fmin hd p=9 from h9] using hw.1)))
  · by_cases h11 : w=11
    · exact Sum.inr (Sum.inr (fiberDelete p 11 (by simpa only [show fmin hd p=11 from h11] using hw.1)))
    · have hb : 13≤w := by have := p.property.1 w hw.1; omega
      exact Sum.inl (fiberLower p w 4 hw.1 rfl hb)

theorem fmap4_injective {n d : ℕ} (hd : d<n) : Function.Injective (fmap4 hd) := by
  intro p q he
  unfold fmap4 at he
  dsimp only at he
  split_ifs at he
  all_goals simp only [Sum.inl.injEq, Sum.inr.injEq, Sum.inl_ne_inr, Sum.inr_ne_inl] at he
  all_goals apply Subtype.ext
  all_goals first
    | exact deletion_injective (s:=p.val) (t:=q.val) (w:=9)
        (by simpa only [show fmin hd p=9 by assumption] using (fmin_spec hd p).1)
        (by simpa only [show fmin hd q=9 by assumption] using (fmin_spec hd q).1)
        (congrArg Subtype.val he)
    | exact deletion_injective (s:=p.val) (t:=q.val) (w:=11)
        (by simpa only [show fmin hd p=11 by assumption] using (fmin_spec hd p).1)
        (by simpa only [show fmin hd q=11 by assumption] using (fmin_spec hd q).1)
        (congrArg Subtype.val he)
    | have hp := (p.property.1 _ (fmin_spec hd p).1).2
      have hq := (q.property.1 _ (fmin_spec hd q).1).2
      exact lower_injective (k:=4) (fmin_spec hd p) (fmin_spec hd q)
        (by omega) (by omega) (congrArg Subtype.val he)

theorem shifted_absorb4 {n d : ℕ} (hd : d<n) : shifted n d ≤ shifted n (d+4) + (shifted n (d+9) + shifted n (d+11)) := by
  have h := Fintype.card_le_of_injective (fmap4 hd) (fmap4_injective hd)
  simp only [Fintype.card_sum] at h
  have hh : (Fintype.card (Fiber n d) : ℤ) ≤ (Fintype.card (Fiber n (d+4)) : ℤ) + ((Fintype.card (Fiber n (d+9)) : ℤ) + (Fintype.card (Fiber n (d+11)) : ℤ)) := by exact_mod_cast h
  simpa only [card_fiber] using hh
#print axioms shifted_absorb2
#print axioms shifted_absorb4
end RBAbsorb
