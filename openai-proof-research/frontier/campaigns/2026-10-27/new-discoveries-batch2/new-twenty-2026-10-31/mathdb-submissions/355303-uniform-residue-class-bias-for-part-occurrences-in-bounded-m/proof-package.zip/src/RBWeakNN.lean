import RBCountPair
import Mathlib.Algebra.Order.BigOperators.Group.Finset

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBWeakNN (355303 uniform weak comparisons): nonnegative coefficient algebra

* `NN f` : every coefficient of `f : PowerSeries ℤ` is `≥ 0`; closure under `+`, `*`, powers of `X`,
  natural constants, finite sums and products; `NN (Bf k h)`, `NN (pairF k a)`.
* `gI c` : the formal series `∑_{c ∣ m} X^m` (coefficient meaning by definition), with
  `(1 - X^c) * gI c = 1` for `c ≥ 1` and `(1 - X^(c*u)) * gI c = Bf u c`.
* truncation `coeff n ((1 - X^M) * F) = coeff n F` for `n < M`; the coin identity.
No infinite product, no analytic statement, no axiom.
-/

namespace RBCount

open Finset

local notation "𝔛" => (PowerSeries.X : PowerSeries ℤ)

/-- Coefficientwise nonnegativity. -/
def NN (f : PowerSeries ℤ) : Prop := ∀ m, 0 ≤ PowerSeries.coeff m f

theorem NN_zero : NN 0 := fun m => by simp

theorem NN_one : NN 1 := fun m => by
  rw [PowerSeries.coeff_one]
  split_ifs <;> simp

theorem NN_add {f g : PowerSeries ℤ} (hf : NN f) (hg : NN g) : NN (f + g) := fun m => by
  rw [map_add]
  exact add_nonneg (hf m) (hg m)

theorem NN_mul {f g : PowerSeries ℤ} (hf : NN f) (hg : NN g) : NN (f * g) := fun m => by
  rw [PowerSeries.coeff_mul]
  exact Finset.sum_nonneg fun p _ => mul_nonneg (hf p.1) (hg p.2)

theorem NN_X_pow (e : ℕ) : NN (𝔛 ^ e) := fun m => by
  rw [PowerSeries.coeff_X_pow]
  split_ifs <;> simp

theorem NN_X : NN 𝔛 := by
  have h := NN_X_pow 1
  rwa [pow_one] at h

theorem NN_C_natCast (c : ℕ) : NN (PowerSeries.C (c : ℤ)) := fun m => by
  rw [PowerSeries.coeff_C]
  split_ifs <;> simp

theorem NN_sum {ι : Type*} (s : Finset ι) (f : ι → PowerSeries ℤ) (h : ∀ i ∈ s, NN (f i)) :
    NN (∑ i ∈ s, f i) := fun m => by
  rw [map_sum]
  exact Finset.sum_nonneg fun i hi => h i hi m

theorem NN_prod {ι : Type*} (s : Finset ι) (f : ι → PowerSeries ℤ) (h : ∀ i ∈ s, NN (f i)) :
    NN (∏ i ∈ s, f i) :=
  Finset.prod_induction f NN (fun _ _ ha hb => NN_mul ha hb) NN_one h

theorem NN_Bf (k h : ℕ) : NN (Bf k h) := by
  unfold Bf
  exact NN_sum _ _ fun i _ => NN_X_pow _

theorem NN_pairF (k a : ℕ) : NN (pairF k a) := by
  unfold pairF
  exact NN_sum _ _ fun i _ => NN_sum _ _ fun j _ =>
    NN_mul (NN_C_natCast _) (NN_mul (NN_X_pow _) (NN_sum _ _ fun e _ => NN_X_pow _))

/-- The formal series `∑_{c ∣ m} X^m` (for `c ≥ 1` the inverse of `1 - X^c`). -/
noncomputable def gI (c : ℕ) : PowerSeries ℤ :=
  PowerSeries.mk fun m => if c ∣ m then 1 else 0

theorem NN_gI (c : ℕ) : NN (gI c) := fun m => by
  unfold gI
  rw [PowerSeries.coeff_mk]
  split_ifs <;> simp

theorem one_sub_mul_gI {c : ℕ} (hc : 1 ≤ c) : (1 - 𝔛 ^ c) * gI c = 1 := by
  ext m
  rw [sub_mul, one_mul, map_sub, PowerSeries.coeff_X_pow_mul', PowerSeries.coeff_one]
  unfold gI
  simp only [PowerSeries.coeff_mk]
  by_cases hm : c ≤ m
  · rw [ite_eq_left hm]
    obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_le hm
    have h1 : c + d - c = d := by omega
    rw [h1]
    have h2 : c ∣ c + d ↔ c ∣ d := Nat.dvd_add_right (dvd_refl c)
    have h3 : c + d ≠ 0 := by omega
    by_cases hd : c ∣ d
    · rw [ite_eq_left (h2.mpr hd), ite_eq_left hd, ite_eq_right h3, sub_self]
    · rw [ite_eq_right (fun h => hd (h2.mp h)), ite_eq_right hd, ite_eq_right h3, sub_self]
  · rw [ite_eq_right hm, sub_zero]
    by_cases h0 : m = 0
    · subst h0
      simp
    · have hnd : ¬ c ∣ m := fun h => by
        have := Nat.le_of_dvd (by omega) h
        omega
      rw [ite_eq_right hnd, ite_eq_right h0]

theorem coeff_one_sub_X_pow_mul {n M : ℕ} (h : n < M) (F : PowerSeries ℤ) :
    PowerSeries.coeff n ((1 - 𝔛 ^ M) * F) = PowerSeries.coeff n F := by
  rw [sub_mul, one_mul, map_sub, PowerSeries.coeff_X_pow_mul', ite_eq_right (by omega), sub_zero]

theorem one_sub_mul_Bf (k c : ℕ) : (1 - 𝔛 ^ c) * Bf k c = 1 - 𝔛 ^ (c * k) := by
  unfold Bf
  have h : ∀ i, 𝔛 ^ (c * i) = (𝔛 ^ c) ^ i := fun i => pow_mul _ _ _
  simp_rw [h]
  rw [mul_neg_geom_sum]

theorem gI_mul_geom {c : ℕ} (hc : 1 ≤ c) (u : ℕ) : (1 - 𝔛 ^ (c * u)) * gI c = Bf u c := by
  rw [← one_sub_mul_Bf u c]
  calc (1 - 𝔛 ^ c) * Bf u c * gI c = Bf u c * ((1 - 𝔛 ^ c) * gI c) := by ring
    _ = Bf u c := by rw [one_sub_mul_gI hc, mul_one]

/-- Replacing a telescoping factor by the formal inverse below degree `M`. -/
theorem coeff_mul_tele {n M c : ℕ} (hc : 1 ≤ c) (hM : n < M) {P : PowerSeries ℤ}
    (hP : (1 - 𝔛 ^ c) * P = 1 - 𝔛 ^ M) (F : PowerSeries ℤ) :
    PowerSeries.coeff n (F * P) = PowerSeries.coeff n (F * gI c) := by
  have hg := one_sub_mul_gI hc
  have e : F * P = (1 - 𝔛 ^ M) * (F * gI c) := by
    rw [← hP]
    linear_combination (-(F * P)) * hg
  rw [e, coeff_one_sub_X_pow_mul hM]

/-- Coin identity. -/
theorem coin {p q : ℕ} (hp : 1 ≤ p) (hq : 1 ≤ q) (u v : ℕ) :
    (1 - 𝔛 ^ (p * u + q * v)) * gI p * gI q = Bf u p * gI q + 𝔛 ^ (p * u) * Bf v q * gI p := by
  have e1 := gI_mul_geom hp u
  have e2 := gI_mul_geom hq v
  rw [pow_add]
  linear_combination (gI q) * e1 + (𝔛 ^ (p * u) * gI p) * e2

theorem NN_coin {p q : ℕ} (hp : 1 ≤ p) (hq : 1 ≤ q) (u v : ℕ) :
    NN ((1 - 𝔛 ^ (p * u + q * v)) * gI p * gI q) := by
  rw [coin hp hq u v]
  exact NN_add (NN_mul (NN_Bf _ _) (NN_gI _)) (NN_mul (NN_mul (NN_X_pow _) (NN_Bf _ _)) (NN_gI _))

end RBCount

#print axioms RBCount.one_sub_mul_gI
#print axioms RBCount.coeff_mul_tele
#print axioms RBCount.NN_coin
#print axioms RBCount.NN_pairF
