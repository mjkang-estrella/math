import RBPrefixCut
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RBPrefix
open Polynomial
open scoped BigOperators
def cutBox (lo hi : Nat) : Bool :=
 (List.range (hi-lo)).all fun d =>
 (List.range 24).all fun a =>
 (List.range 143).all fun n =>
 if Required (lo+d) a n then decide (cutCount (lo+d) (a+1) n < cutCount (lo+d) a n) else true
theorem cutBox_sound {lo hi : Nat} (h : cutBox lo hi = true) :
 ∀ k a n, lo ≤ k → k < hi → Required k a n → Comparison k a n := by
 intro k a n hl hh r
 have b := required_bounds r
 simp only [cutBox, List.all_eq_true] at h
 have h1 := h (k-lo) (List.mem_range.mpr (by omega))
 have h2 := h1 a (List.mem_range.mpr b.1)
 have h3 := h2 n (List.mem_range.mpr b.2)
 have he : lo + (k-lo) = k := by omega
 have hd : cutCount k (a+1) n < cutCount k a n := by simpa only [he, ite_eq_left r, decide_eq_true_eq] using h3
 rw [cutCount_eq k (a+1) n (by omega), cutCount_eq k a n (by omega)] at hd
 exact hd
theorem join_shards {lo mid hi : Nat}
 (h1 : ∀ k a n, lo ≤ k → k < mid → Required k a n → Comparison k a n)
 (h2 : ∀ k a n, mid ≤ k → k < hi → Required k a n → Comparison k a n) :
 ∀ k a n, lo ≤ k → k < hi → Required k a n → Comparison k a n := by
 intro k a n hl hh r
 by_cases hm : k < mid
 · exact h1 k a n hl hm r
 · exact h2 k a n (by omega) hh r
noncomputable def actualMarked (k a : Nat) : Polynomial Int :=
 ∏ h ∈ Finset.range 142, ∑ j ∈ Finset.range k,
 Polynomial.C (if h+1 == a then (j : Int) else 1) * Polynomial.X^(j*(h+1))
theorem count_meaning (k a n : Nat) : count k a 142 n = (actualMarked k a).coeff n := by
 rw [count, coeffRun_eq, expanded_product]
 rfl
theorem finite_product_endpoint (h : cutBox 2 144 = true) :
 ∀ k a n, Required k a n → (actualMarked k (a+1)).coeff n < (actualMarked k a).coeff n := by
 intro k a n r
 have hk : k < 144 := by have := r.2.1; omega
 have hd := cutBox_sound h k a n r.1 hk r
 change count k (a+1) 142 n < count k a 142 n at hd
 simpa only [count_meaning] using hd
#print axioms finite_product_endpoint
#print axioms join_shards
end RBPrefix
