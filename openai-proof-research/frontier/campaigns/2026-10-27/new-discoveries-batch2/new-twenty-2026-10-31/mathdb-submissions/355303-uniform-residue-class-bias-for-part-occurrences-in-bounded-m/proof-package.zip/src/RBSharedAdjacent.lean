import RBSharedNumerator
namespace RBShared
theorem interval_neighbor_sound (k a b : Nat) (hb : b=a+1) (ex : Bool) (s t : Nat → Int)
 (he : RBPrefix.exceptional k a = ex)
 (hs : ∀ n, n ≤ 142 → s n = (RBPrefix.actualMarked k a).coeff n)
 (ht : ∀ n, n ≤ 142 → t n = (RBPrefix.actualMarked k b).coeff n)
 (hc : intervalCheck (max (a+5) 17) (a+(if ex then 23 else 119)) s t = true) :
 ∀ n, RBPrefix.Required k a n →
 (RBPrefix.actualMarked k (a+1)).coeff n < (RBPrefix.actualMarked k a).coeff n := by
 intro n hr
 have hn := (RBPrefix.required_bounds hr).2
 have hl := hr.2.2.2.2.2.2.1
 have hu := hr.2.2.2.2.2.2.2
 rw [he] at hu
 have hd := (List.all_eq_true.mp hc) (n-max (a+5) 17) (List.mem_range.mpr (by omega))
 have hidx : max (a+5) 17 + (n-max (a+5) 17) = n := by omega
 have hv : t n < s n := by simpa only [hidx, decide_eq_true_eq] using hd
 rw [hs n (by omega), ht n (by omega)] at hv
 simpa only [hb] using hv
#print axioms interval_neighbor_sound
end RBShared
