import RBStageCore
import Mathlib.Tactic.Ring
namespace RBShared
open Polynomial
open scoped BigOperators
noncomputable def factor (k a : Nat) (marked : Bool) : Polynomial Int :=
 ∑ j ∈ Finset.range k, C (RBPrefix.weight marked j) * X^(j*a)
theorem marked_factor (k a : Nat) (ha : 1 ≤ a) (ha' : a ≤ 142) :
 factor k a false * RBPrefix.actualMarked k a =
 factor k a true * RBPrefix.actualMarked k 0 := by
 classical
 let s := Finset.range 142
 let u := fun h => factor k (h+1) false
 let v := fun h => factor k (h+1) (h+1 == a)
 have hm : a-1 ∈ s := Finset.mem_range.mpr (by omega)
 have hu : RBPrefix.actualMarked k 0 = ∏ h ∈ s, u h := by
  apply Finset.prod_congr rfl
  intro h _
  simp [u, factor, RBPrefix.weight]
 have hv : RBPrefix.actualMarked k a = ∏ h ∈ s, v h := rfl
 have he : (∏ h ∈ s.erase (a-1), v h) = ∏ h ∈ s.erase (a-1), u h := by
  apply Finset.prod_congr rfl
  intro h hh
  have hn : h ≠ a-1 := (Finset.mem_erase.mp hh).1
  have hn' : h+1 ≠ a := by omega
  have hb : (h+1 == a) = false := beq_eq_false_iff_ne.mpr hn'
  simp only [v, u, hb]
 have ea : a-1+1 = a := by omega
 rw [hv, hu, ← Finset.mul_prod_erase s v hm, ← Finset.mul_prod_erase s u hm, he]
 simp only [v, u, ea, beq_self_eq_true]
 ring
#print axioms marked_factor
end RBShared
