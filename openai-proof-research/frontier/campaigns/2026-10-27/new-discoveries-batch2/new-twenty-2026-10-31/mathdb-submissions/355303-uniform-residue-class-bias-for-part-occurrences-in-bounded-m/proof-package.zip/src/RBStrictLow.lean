import RBStrictCore
import RBWeakAlg

set_option linter.unusedVariables false
set_option linter.unusedSimpArgs false

/-!
# RBStrictLow (355303 strict support): region B (`a = 1`, `k ≥ 3`, `n ≥ 17`) and
region C (`k = 3`, exceptional `a ∈ {2, 3, 8, 9}`, `n ≥ 17`).
-/

namespace RBStrict

open RBCount Finset

local notation "𝔛" => (PowerSeries.X : PowerSeries ℤ)

theorem a1_kernel (k : ℕ) (hk : 1 ≤ k) : (1 - 𝔛) * pairF k 1 * gI k = Hk k * gI 1 * gI 2 := by
  have hpn := pair_numerator k 1
  rw [show (1 : ℕ) + 1 = 2 from rfl] at hpn
  rw [← hpn]
  exact N1_gI k hk

/-- Chain from `k` (`k^(j+1)`, root 1 above the marks `1, 2`). -/
theorem good_a1_base {k n : ℕ} (hk : 3 ≤ k) :
    Good k 1 n (fun y => False ∨ ∃ j, y = k * k ^ j) ((1 - 𝔛) * pairF k 1 * gI k) :=
  good_chain (c := k) (by omega) (by omega) (fun j => by
      have h1 : 1 ≤ k ^ j := Nat.one_le_pow _ _ (by omega)
      have h2 : k * 1 ≤ k * k ^ j := Nat.mul_le_mul_left k h1
      constructor <;> omega) (fun j h => h) (good_base k 1 n)

theorem strict_a1_k3 {n : ℕ} (hn : 17 ≤ n) : C 3 (1 + 1) n < C 3 1 n := by
  have G1 := good_a1_base (n := n) (le_refl 3)
  have G2 := good_chain (c := 4) (by norm_num) (by norm_num) (fun j => by
      have h1 : 1 ≤ 3 ^ j := Nat.one_le_pow _ _ (by norm_num)
      constructor <;> omega)
    (fun j h => by
      rcases h with h | h
      · exact h
      · exact not_root_k (by norm_num) (by decide) (by norm_num) h) G1
  have G3 := good_chain (c := 5) (by norm_num) (by norm_num) (fun j => by
      have h1 : 1 ≤ 3 ^ j := Nat.one_le_pow _ _ (by norm_num)
      constructor <;> omega)
    (fun j h => by
      rcases h with (h | h) | h
      · exact h
      · exact not_root_k (by norm_num) (by decide) (by norm_num) h
      · exact not_root (by norm_num) (by decide) (by decide) (by norm_num) h) G2
  have hH : Hk 3 = (𝔛 + 𝔛 ^ 2) * (1 - 𝔛) * (1 - 𝔛 ^ 2) := by
    unfold Hk Bf
    simp only [Finset.sum_range_succ, Finset.sum_range_zero, Nat.cast_ofNat]
    ring
  have e : (1 - 𝔛) * pairF 3 1 * gI 3 * gI 4 * gI 5 = (𝔛 + 𝔛 ^ 2) * gI 4 * gI 5 := by
    have g1 := one_sub_mul_gI (by norm_num : 1 ≤ 1)
    have g2 := one_sub_mul_gI (by norm_num : 1 ≤ 2)
    rw [pow_one] at g1
    rw [a1_kernel 3 (by norm_num), hH]
    linear_combination ((𝔛 + 𝔛 ^ 2) * gI 4 * gI 5 * ((1 - 𝔛 ^ 2) * gI 2)) * g1 +
      ((𝔛 + 𝔛 ^ 2) * gI 4 * gI 5) * g2
  have G4 := good_eq G3 e
  obtain ⟨i, hi, j, l, hm⟩ :=
    rep3_of_win (by norm_num) (by decide : win3 4 5 5 5 1 12 = true) (n - 1) (by omega)
  have hA : NN (𝔛 + 𝔛 ^ 2) := NN_add NN_X (NN_X_pow 2)
  exact strict_of_good (by norm_num) le_rfl (by omega) G4
    (NN_mul (NN_mul hA (NN_gI 4)) (NN_gI 5))
    (Sup_mul (NN_mul hA (NN_gI 4)) (NN_gI 5)
      (Sup_mul hA (NN_gI 4) (Sup_add_left Sup_X (NN_X_pow 2)) (Sup_gI 4 i) rfl)
      (Sup_gI 5 (j + l)) (by rw [Nat.mul_add]; omega))

theorem strict_a1_k4 {n : ℕ} (hn : 17 ≤ n) : C 4 (1 + 1) n < C 4 1 n := by
  have G1 := good_a1_base (n := n) (by norm_num : 3 ≤ 4)
  have G2 := good_chain (c := 3) (by norm_num) (by norm_num) (fun j => by
      have h1 : 1 ≤ 4 ^ j := Nat.one_le_pow _ _ (by norm_num)
      constructor <;> omega)
    (fun j h => by
      rcases h with h | h
      · exact h
      · exact not_root_k (by norm_num) (by decide) (by norm_num) h) G1
  have G3 := good_single (y := 5) (by norm_num) (by omega) (by norm_num) (by norm_num)
    (fun h => by
      rcases h with (h | ⟨j, hj⟩) | ⟨j, hj⟩
      · exact h
      · omega
      · omega) G2
  have hQ : Q4 = 𝔛 * Bf 3 1 + 𝔛 ^ 5 * Bf 2 1 + (𝔛 ^ 3 + 𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 5 + 𝔛 ^ 7) := by
    unfold Q4 Bf
    simp only [Finset.sum_range_succ, Finset.sum_range_zero]
    ring
  have e : (1 - 𝔛) * pairF 4 1 * gI 4 * gI 3 * Bf 4 5 =
      𝔛 * Bf 3 1 * gI 6 * Bf 4 5 + 𝔛 ^ 5 * Bf 2 1 * gI 6 * Bf 4 5 +
        (𝔛 ^ 3 + 𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 5 + 𝔛 ^ 7) * gI 6 * Bf 4 5 := by
    rw [a1_kernel 4 (by norm_num), Hk_four_gI, hQ]
    ring
  have G4 := good_eq G3 e
  have hR : NN (𝔛 ^ 3 + 𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 5 + 𝔛 ^ 7) :=
    NN_add (NN_add (NN_add (NN_add (NN_X_pow 3) (NN_X_pow 3)) (NN_X_pow 5)) (NN_X_pow 5)) (NN_X_pow 7)
  have N1 : NN (𝔛 * Bf 3 1 * gI 6 * Bf 4 5) :=
    NN_mul (NN_mul (NN_mul NN_X (NN_Bf 3 1)) (NN_gI 6)) (NN_Bf 4 5)
  have N2 : NN (𝔛 ^ 5 * Bf 2 1 * gI 6 * Bf 4 5) :=
    NN_mul (NN_mul (NN_mul (NN_X_pow 5) (NN_Bf 2 1)) (NN_gI 6)) (NN_Bf 4 5)
  have N3 : NN ((𝔛 ^ 3 + 𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 5 + 𝔛 ^ 7) * gI 6 * Bf 4 5) :=
    NN_mul (NN_mul hR (NN_gI 6)) (NN_Bf 4 5)
  have hW : ∀ m, 17 ≤ m → (∃ i < 3, ∃ j, ∃ l < 4, m = 1 + i + 6 * j + 5 * l) ∨
      (∃ i < 2, ∃ j, ∃ l < 4, m = 5 + i + 6 * j + 5 * l) := by
    refine window_ind (R := fun m => (∃ i < 3, ∃ j, ∃ l < 4, m = 1 + i + 6 * j + 5 * l) ∨
      (∃ i < 2, ∃ j, ∃ l < 4, m = 5 + i + 6 * j + 5 * l)) 6 17 (by norm_num) ?_ ?_
    · intro m h1 h2
      rcases (show m = 17 ∨ m = 18 ∨ m = 19 ∨ m = 20 ∨ m = 21 ∨ m = 22 by omega) with
        rfl | rfl | rfl | rfl | rfl | rfl
      · exact Or.inr ⟨0, by norm_num, 2, 0, by norm_num, by norm_num⟩
      · exact Or.inr ⟨1, by norm_num, 2, 0, by norm_num, by norm_num⟩
      · exact Or.inl ⟨0, by norm_num, 3, 0, by norm_num, by norm_num⟩
      · exact Or.inl ⟨1, by norm_num, 3, 0, by norm_num, by norm_num⟩
      · exact Or.inl ⟨2, by norm_num, 3, 0, by norm_num, by norm_num⟩
      · exact Or.inr ⟨0, by norm_num, 2, 1, by norm_num, by norm_num⟩
    · rintro m (⟨i, hi, j, l, hl, rfl⟩ | ⟨i, hi, j, l, hl, rfl⟩)
      · exact Or.inl ⟨i, hi, j + 1, l, hl, by ring⟩
      · exact Or.inr ⟨i, hi, j + 1, l, hl, by ring⟩
  have hS : Sup (𝔛 * Bf 3 1 * gI 6 * Bf 4 5 + 𝔛 ^ 5 * Bf 2 1 * gI 6 * Bf 4 5 +
      (𝔛 ^ 3 + 𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 5 + 𝔛 ^ 7) * gI 6 * Bf 4 5) n := by
    rcases hW n hn with ⟨i, hi, j, l, hl, hn'⟩ | ⟨i, hi, j, l, hl, hn'⟩
    · exact Sup_add_left (Sup_add_left
        (Sup_mul (NN_mul (NN_mul NN_X (NN_Bf 3 1)) (NN_gI 6)) (NN_Bf 4 5)
          (Sup_mul (NN_mul NN_X (NN_Bf 3 1)) (NN_gI 6)
            (Sup_mul NN_X (NN_Bf 3 1) Sup_X (Sup_Bf (k := 3) (h := 1) (i := i) le_rfl hi) rfl)
            (Sup_gI 6 j) rfl)
          (Sup_Bf (k := 4) (h := 5) (i := l) (by norm_num) hl) (by omega)) N2) N3
    · exact Sup_add_left (Sup_add_right N1
        (Sup_mul (NN_mul (NN_mul (NN_X_pow 5) (NN_Bf 2 1)) (NN_gI 6)) (NN_Bf 4 5)
          (Sup_mul (NN_mul (NN_X_pow 5) (NN_Bf 2 1)) (NN_gI 6)
            (Sup_mul (NN_X_pow 5) (NN_Bf 2 1) (Sup_X_pow 5)
              (Sup_Bf (k := 2) (h := 1) (i := i) le_rfl hi) rfl)
            (Sup_gI 6 j) rfl)
          (Sup_Bf (k := 4) (h := 5) (i := l) (by norm_num) hl) (by omega))) N3
  exact strict_of_good (by norm_num) le_rfl (by omega) G4 (NN_add (NN_add N1 N2) N3) hS

theorem strict_a1_odd {s n : ℕ} (hs : 1 ≤ s) (hn : 17 ≤ n) :
    C (2 * s + 3) (1 + 1) n < C (2 * s + 3) 1 n := by
  have hk : 3 ≤ 2 * s + 3 := by omega
  have hk3 : ¬ (2 * s + 3) ∣ 3 := fun h => by
    have := Nat.le_of_dvd (by norm_num) h
    omega
  have G1 := good_a1_base (n := n) hk
  have G2 := good_chain (c := 3) (by omega) (by norm_num) (fun j => by
      have h1 : 1 ≤ (2 * s + 3) ^ j := Nat.one_le_pow _ _ (by omega)
      constructor <;> omega)
    (fun j h => by
      rcases h with h | h
      · exact h
      · exact not_root_k (by omega) hk3 (by norm_num) h) G1
  have hH : Hk (2 * s + 3) = 𝔛 ^ 2 * Hk (2 * s + 1) + 𝔛 * (1 - 𝔛 ^ (2 * s + 1 + 1)) ^ 2 := by
    rw [show 2 * s + 3 = 2 * s + 1 + 2 by ring]
    exact Hk_succ_succ (2 * s + 1)
  have e : (1 - 𝔛) * pairF (2 * s + 3) 1 * gI (2 * s + 3) * gI 3 =
      𝔛 ^ 2 * (Hk (2 * s + 1) * gI 1 * gI 2) * gI 3 +
        𝔛 * Bf (2 * s + 2) 1 * Bf (s + 1) 2 * gI 3 := by
    rw [a1_kernel _ (by omega), hH]
    have g1 := gI_mul_geom (le_refl 1) (2 * s + 2)
    have g2 := gI_mul_geom (by norm_num : 1 ≤ 2) (s + 1)
    rw [← g1, ← g2]
    ring
  have G3 := good_eq G2 e
  have N1 : NN (𝔛 ^ 2 * (Hk (2 * s + 1) * gI 1 * gI 2) * gI 3) :=
    NN_mul (NN_mul (NN_X_pow 2) (NN_Hk_odd s)) (NN_gI 3)
  have N2 : NN (𝔛 * Bf (2 * s + 2) 1 * Bf (s + 1) 2 * gI 3) :=
    NN_mul (NN_mul (NN_mul NN_X (NN_Bf _ _)) (NN_Bf _ _)) (NN_gI 3)
  exact strict_of_good (by omega) le_rfl (by omega) G3 (NN_add N1 N2)
    (Sup_add_right N1
      (Sup_mul (NN_mul (NN_mul NN_X (NN_Bf _ _)) (NN_Bf _ _)) (NN_gI 3)
        (Sup_mul (NN_mul NN_X (NN_Bf _ _)) (NN_Bf _ _)
          (Sup_mul NN_X (NN_Bf _ _) Sup_X
            (Sup_Bf (k := 2 * s + 2) (h := 1) (i := (n - 1) % 3) le_rfl (by omega)) rfl)
          (Sup_Bf (k := s + 1) (h := 2) (i := 0) (by norm_num) (by omega)) rfl)
        (Sup_gI 3 ((n - 1) / 3)) (by omega)))

theorem strict_a1_even {t n : ℕ} (hn : 17 ≤ n) :
    C (2 * t + 6) (1 + 1) n < C (2 * t + 6) 1 n := by
  have hk : 3 ≤ 2 * t + 6 := by omega
  have hk3 : ¬ (2 * t + 6) ∣ 3 := fun h => by
    have := Nat.le_of_dvd (by norm_num) h
    omega
  have G1 := good_a1_base (n := n) hk
  have G2 := good_chain (c := 3) (by omega) (by norm_num) (fun j => by
      have h1 : 1 ≤ (2 * t + 6) ^ j := Nat.one_le_pow _ _ (by omega)
      constructor <;> omega)
    (fun j h => by
      rcases h with h | h
      · exact h
      · exact not_root_k (by omega) hk3 (by norm_num) h) G1
  have hH : Hk (2 * t + 6) = 𝔛 ^ 2 * Hk (2 * t + 4) + 𝔛 * (1 - 𝔛 ^ (2 * t + 4 + 1)) ^ 2 := by
    rw [show 2 * t + 6 = 2 * t + 4 + 2 by ring]
    exact Hk_succ_succ (2 * t + 4)
  have e : (1 - 𝔛) * pairF (2 * t + 6) 1 * gI (2 * t + 6) * gI 3 =
      𝔛 ^ 2 * (Hk (2 * t + 4) * gI 1 * gI 2 * gI 3) +
        𝔛 * Bf (2 * t + 5) 1 * ((1 - 𝔛 ^ (2 * (t + 1) + 3 * 1)) * gI 2 * gI 3) := by
    rw [a1_kernel _ (by omega), hH]
    have g1 := gI_mul_geom (le_refl 1) (2 * t + 5)
    rw [← g1]
    ring
  have G3 := good_eq G2 e
  have N1 : NN (𝔛 ^ 2 * (Hk (2 * t + 4) * gI 1 * gI 2 * gI 3)) :=
    NN_mul (NN_X_pow 2) (NN_Hk_even t)
  have hc := NN_coin (u := t + 1) (v := 1) (by norm_num : 1 ≤ 2) (by norm_num : 1 ≤ 3)
  have N2 : NN (𝔛 * Bf (2 * t + 5) 1 * ((1 - 𝔛 ^ (2 * (t + 1) + 3 * 1)) * gI 2 * gI 3)) :=
    NN_mul (NN_mul NN_X (NN_Bf _ _)) hc
  exact strict_of_good (by omega) le_rfl (by omega) G3 (NN_add N1 N2)
    (Sup_add_right N1
      (Sup_mul (NN_mul NN_X (NN_Bf _ _)) hc
        (Sup_mul NN_X (NN_Bf _ _) Sup_X
          (Sup_Bf (k := 2 * t + 5) (h := 1) (i := (n - 1) % 3) le_rfl (by omega)) rfl)
        (Sup_coin (p := 2) (q := 3) (u := t + 1) (v := 1) (i := 0) (j := (n - 1) / 3)
          (by norm_num) (by norm_num) (by omega)) (by omega)))

/-- REGION B (closed): `a = 1`, every `k ≥ 3`, `n ≥ 17`. -/
theorem strict_a1 {k n : ℕ} (hk : 3 ≤ k) (hn : 17 ≤ n) : C k (1 + 1) n < C k 1 n := by
  by_cases h3 : k = 3
  · subst h3
    exact strict_a1_k3 hn
  by_cases h4 : k = 4
  · subst h4
    exact strict_a1_k4 hn
  by_cases hodd : k % 2 = 1
  · obtain ⟨s, rfl⟩ : ∃ s, k = 2 * s + 3 := ⟨(k - 3) / 2, by omega⟩
    exact strict_a1_odd (by omega) hn
  · obtain ⟨t, rfl⟩ : ∃ t, k = 2 * t + 6 := ⟨(k - 6) / 2, by omega⟩
    exact strict_a1_even hn

theorem strict_k3_a2 {n : ℕ} (hn : 17 ≤ n) : C 3 (2 + 1) n < C 3 2 n := by
  obtain ⟨P, G⟩ := good_exc3 (k := 3) (a := 2) (n := n) (w := 1) (p := 4) (q := 5) (c := 7)
    (by norm_num) le_rfl (Or.inr (by norm_num)) (by norm_num) (by omega) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by decide) (by decide)
    (by decide) (fun _ => ⟨by norm_num, by norm_num, by norm_num⟩) (fun h => by norm_num at h)
  have e : (1 - 𝔛 ^ (3 ^ 1)) * pairF 3 2 * gI 4 * gI 5 * gI 7 =
      𝔛 ^ 2 * gI 4 * gI 7 + (𝔛 ^ 4 * gI 5 * gI 7 + 𝔛 ^ 4 * gI 5 * gI 7) + 𝔛 ^ 5 * gI 4 * gI 7 := by
    have e4 := one_sub_mul_gI (by norm_num : 1 ≤ 4)
    have e5 := one_sub_mul_gI (by norm_num : 1 ≤ 5)
    rw [pairF_three]
    linear_combination (𝔛 ^ 2 * gI 4 * gI 7 + 𝔛 ^ 5 * gI 4 * gI 7) * e5 +
      (2 * 𝔛 ^ 4 * gI 5 * gI 7) * e4
  have G' := good_eq G e
  have NA : NN (𝔛 ^ 2 * gI 4 * gI 7) := NN_mul (NN_mul (NN_X_pow 2) (NN_gI 4)) (NN_gI 7)
  have NB : NN (𝔛 ^ 4 * gI 5 * gI 7 + 𝔛 ^ 4 * gI 5 * gI 7) :=
    NN_add (NN_mul (NN_mul (NN_X_pow 4) (NN_gI 5)) (NN_gI 7))
      (NN_mul (NN_mul (NN_X_pow 4) (NN_gI 5)) (NN_gI 7))
  have NC : NN (𝔛 ^ 5 * gI 4 * gI 7) := NN_mul (NN_mul (NN_X_pow 5) (NN_gI 4)) (NN_gI 7)
  have hW : ∀ m, 17 ≤ m → (∃ j l, m = 2 + 4 * j + 7 * l) ∨ (∃ j l, m = 5 + 4 * j + 7 * l) := by
    refine window_ind (R := fun m => (∃ j l, m = 2 + 4 * j + 7 * l) ∨
      (∃ j l, m = 5 + 4 * j + 7 * l)) 4 17 (by norm_num) ?_ ?_
    · intro m h1 h2
      rcases (show m = 17 ∨ m = 18 ∨ m = 19 ∨ m = 20 by omega) with rfl | rfl | rfl | rfl
      · exact Or.inr ⟨3, 0, by norm_num⟩
      · exact Or.inl ⟨4, 0, by norm_num⟩
      · exact Or.inr ⟨0, 2, by norm_num⟩
      · exact Or.inl ⟨1, 2, by norm_num⟩
    · rintro m (⟨j, l, rfl⟩ | ⟨j, l, rfl⟩)
      · exact Or.inl ⟨j + 1, l, by ring⟩
      · exact Or.inr ⟨j + 1, l, by ring⟩
  have hS : Sup (𝔛 ^ 2 * gI 4 * gI 7 + (𝔛 ^ 4 * gI 5 * gI 7 + 𝔛 ^ 4 * gI 5 * gI 7) +
      𝔛 ^ 5 * gI 4 * gI 7) n := by
    rcases hW n hn with ⟨j, l, hn'⟩ | ⟨j, l, hn'⟩
    · exact Sup_add_left (Sup_add_left
        (Sup_mul (NN_mul (NN_X_pow 2) (NN_gI 4)) (NN_gI 7)
          (Sup_mul (NN_X_pow 2) (NN_gI 4) (Sup_X_pow 2) (Sup_gI 4 j) rfl) (Sup_gI 7 l)
          (by omega)) NB) NC
    · exact Sup_add_right (NN_add NA NB)
        (Sup_mul (NN_mul (NN_X_pow 5) (NN_gI 4)) (NN_gI 7)
          (Sup_mul (NN_X_pow 5) (NN_gI 4) (Sup_X_pow 5) (Sup_gI 4 j) rfl) (Sup_gI 7 l)
          (by omega))
  exact strict_of_good (by norm_num) (by norm_num) (by omega) G' (NN_add (NN_add NA NB) NC) hS

theorem strict_k3_a3 {n : ℕ} (hn : 17 ≤ n) : C 3 (3 + 1) n < C 3 3 n := by
  obtain ⟨P, G⟩ := good_exc2 (k := 3) (a := 3) (n := n) (w := 1) (p := 2) (q := 5)
    (by norm_num) le_rfl (Or.inl (by norm_num)) (by norm_num) (by omega) (by norm_num)
    (by norm_num) (by norm_num) (by decide) (by decide) (fun h => by norm_num at h)
    (fun _ => ⟨by norm_num, by norm_num⟩)
  have e : (1 - 𝔛 ^ (3 ^ 1)) * pairF 3 3 * gI 2 * gI 5 =
      𝔛 ^ 5 * Bf 5 1 * gI 5 + (𝔛 ^ 3 + 𝔛 ^ 7 + 𝔛 ^ 11 + 𝔛 ^ 7) * gI 5 := by
    have e2 := one_sub_mul_gI (by norm_num : 1 ≤ 2)
    have hB : Bf 5 1 = 1 + 𝔛 + 𝔛 ^ 2 + 𝔛 ^ 3 + 𝔛 ^ 4 := by
      unfold Bf
      simp only [Finset.sum_range_succ, Finset.sum_range_zero]
      ring
    rw [pairF_three, hB]
    linear_combination
      ((𝔛 ^ 3 + 𝔛 ^ 5 + 𝔛 ^ 7 + 𝔛 ^ 9 + 𝔛 ^ 11 + 𝔛 ^ 6 + 𝔛 ^ 8 + 𝔛 ^ 7 + 𝔛 ^ 7) * gI 5) * e2
  have G' := good_eq G e
  have N1 : NN (𝔛 ^ 5 * Bf 5 1 * gI 5) := NN_mul (NN_mul (NN_X_pow 5) (NN_Bf 5 1)) (NN_gI 5)
  have N2 : NN ((𝔛 ^ 3 + 𝔛 ^ 7 + 𝔛 ^ 11 + 𝔛 ^ 7) * gI 5) :=
    NN_mul (NN_add (NN_add (NN_add (NN_X_pow 3) (NN_X_pow 7)) (NN_X_pow 11)) (NN_X_pow 7)) (NN_gI 5)
  exact strict_of_good (by norm_num) (by norm_num) (by omega) G' (NN_add N1 N2)
    (Sup_add_left
      (Sup_mul (NN_mul (NN_X_pow 5) (NN_Bf 5 1)) (NN_gI 5)
        (Sup_mul (NN_X_pow 5) (NN_Bf 5 1) (Sup_X_pow 5)
          (Sup_Bf (k := 5) (h := 1) (i := (n - 5) % 5) le_rfl (Nat.mod_lt _ (by norm_num))) rfl)
        (Sup_gI 5 ((n - 5) / 5)) (by omega)) N2)

theorem strict_k3_a89 {a n : ℕ} (ha : a = 8 ∨ a = 9) (hn : 17 ≤ n) : C 3 (a + 1) n < C 3 a n := by
  have hx : 3 ^ 2 = a ∨ 3 ^ 2 = a + 1 := by
    rcases ha with rfl | rfl
    · exact Or.inr (by norm_num)
    · exact Or.inl (by norm_num)
  have hlow : 3 ^ (2 - 1) < a := by
    rcases ha with rfl | rfl <;> norm_num
  have hrep : ∃ i < 1, ∃ j l, n = a + 5 * i + 2 * j + 7 * l := by
    by_cases hpar : (n - a) % 2 = 0
    · exact ⟨0, by norm_num, (n - a) / 2, 0, by omega⟩
    · exact ⟨0, by norm_num, (n - a - 7) / 2, 1, by omega⟩
  exact strict_exc3 (k := 3) (w := 2) (p := 5) (q := 2) (c := 7) (u := 1) (v := 2) (by norm_num)
    (by omega) (by omega) (by norm_num) hx hlow (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num) (by decide) (by decide) (by decide)
    (fun _ => ⟨by omega, by omega, by omega⟩) (fun _ => ⟨by omega, by omega, by omega⟩)
    (by norm_num) hrep

/-- REGION C (small part, closed): `k = 3`, `a ∈ {2, 3, 8, 9}`, `n ≥ 17`. -/
theorem strict_k3_small {a n : ℕ} (ha : a = 2 ∨ a = 3 ∨ a = 8 ∨ a = 9) (hn : 17 ≤ n) :
    C 3 (a + 1) n < C 3 a n := by
  rcases ha with rfl | rfl | h | h
  · exact strict_k3_a2 hn
  · exact strict_k3_a3 hn
  · exact strict_k3_a89 (Or.inl h) hn
  · exact strict_k3_a89 (Or.inr h) hn

end RBStrict

#print axioms RBStrict.strict_a1
#print axioms RBStrict.strict_k3_small
