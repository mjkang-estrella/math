import T2Semantics
import Support
noncomputable section
namespace T2
open PowerSeries
open T1 (Bound bound_mul bound_sub bound_pow bound_geom)
theorem bound_Z : Bound (Z (X : PowerSeries ℤ)) 1668 := by
  unfold Z G
  apply bound_mul (b := 1254) (c := 414)
  · apply bound_mul (b := 838) (c := 416)
    · apply bound_mul (b := 423) (c := 415)
      · apply bound_mul (b := 6) (c := 417)
        · apply bound_mul (b := 3) (c := 3)
          · exact bound_pow 2 3 (by decide)
          · exact bound_sub (by simpa using bound_pow 0 3 (by decide)) (bound_pow 2 3 (by decide))
        · exact bound_geom 4 105 417 (by intro i hi; omega)
      · exact bound_geom 6 70 415 (by intro i hi; omega)
    · exact bound_geom 5 84 416 (by intro i hi; omega)
  · exact bound_geom 7 60 414 (by intro i hi; omega)

#print axioms bound_Z
end T2
