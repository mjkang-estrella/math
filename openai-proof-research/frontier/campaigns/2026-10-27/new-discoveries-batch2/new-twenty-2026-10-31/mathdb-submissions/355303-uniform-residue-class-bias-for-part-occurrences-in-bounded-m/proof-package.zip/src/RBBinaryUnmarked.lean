import RBBinaryEuler
noncomputable section
namespace RBBinary
open Finset PowerSeries

def lowDen : PowerSeries ℤ := d 1*d 3*d 5*d 7

theorem odd_residual_cancel (N : ℕ) (hN : 7 ≤ N) :
    oddDen N * residualGeometric N = lowDen := by
  classical
  unfold oddDen residualGeometric
  rw [← prod_mul_distrib]
  have hp : ∀ h ∈ Icc 1 N,
      (if h%2=1 then d h else 1)*(if allowed h then RBCount.gI h else 1) =
        if h ∈ ({1,3,5,7} : Finset ℕ) then d h else 1 := by
    intro h hh
    have hh0 := (mem_Icc.mp hh).1
    by_cases ho : h%2=1
    · by_cases ha : 9 ≤ h
      · have hal : allowed h := ⟨ho,ha⟩
        have hnot : h ∉ ({1,3,5,7}:Finset ℕ) := by simp only [mem_insert,mem_singleton]; omega
        simp only [ite_eq_left ho, ite_eq_left hal, ite_eq_right hnot]
        exact RBCount.one_sub_mul_gI hh0
      · have hal : ¬ allowed h := fun x => ha x.2
        have hm : h ∈ ({1,3,5,7}:Finset ℕ) := by simp only [mem_insert,mem_singleton]; omega
        simp [ho,hal,hm]
    · have hal : ¬allowed h := fun x => ho x.1
      have hm : h ∉ ({1,3,5,7}:Finset ℕ) := by simp only [mem_insert,mem_singleton]; omega
      simp [ho,hal,hm]
  rw [prod_congr rfl hp, ← prod_filter]
  have hs : (Icc 1 N).filter (fun h => h ∈ ({1,3,5,7}:Finset ℕ)) = {1,3,5,7} := by
    ext h
    simp only [mem_filter,mem_Icc,mem_insert,mem_singleton]
    omega
  rw [hs]
  norm_num [Finset.prod_insert, Finset.prod_singleton]
  unfold lowDen
  ring

theorem unmarked_low_cleared (N : ℕ) (hN : 7 ≤ N) :
    Agree N (RBCount.prodB 2 N * lowDen) (residualGeometric N) := by
  have h := agree_mul (euler_cleared N)
    (show Agree N (residualGeometric N) (residualGeometric N) from fun _ _ => rfl)
  simpa only [mul_assoc, odd_residual_cancel N hN, one_mul] using h

#print axioms unmarked_low_cleared
end RBBinary
