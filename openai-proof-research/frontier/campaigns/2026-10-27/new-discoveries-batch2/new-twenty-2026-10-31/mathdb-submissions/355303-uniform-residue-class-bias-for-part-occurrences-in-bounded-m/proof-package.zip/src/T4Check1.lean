import T4Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T4
theorem rec1_0 : ∀ n : Fin 15, tab (n.val+420)=step tab (n.val+420) := by decide
theorem rec1_1 : ∀ n : Fin 15, tab (n.val+435)=step tab (n.val+435) := by decide
theorem rec1_2 : ∀ n : Fin 15, tab (n.val+450)=step tab (n.val+450) := by decide
theorem rec1_3 : ∀ n : Fin 15, tab (n.val+465)=step tab (n.val+465) := by decide
theorem rec1_4 : ∀ n : Fin 15, tab (n.val+480)=step tab (n.val+480) := by decide
theorem rec1_5 : ∀ n : Fin 15, tab (n.val+495)=step tab (n.val+495) := by decide
theorem rec1_6 : ∀ n : Fin 15, tab (n.val+510)=step tab (n.val+510) := by decide
theorem rec1_7 : ∀ n : Fin 15, tab (n.val+525)=step tab (n.val+525) := by decide
theorem rec1_8 : ∀ n : Fin 15, tab (n.val+540)=step tab (n.val+540) := by decide
theorem rec1_9 : ∀ n : Fin 15, tab (n.val+555)=step tab (n.val+555) := by decide
theorem rec1_10 : ∀ n : Fin 15, tab (n.val+570)=step tab (n.val+570) := by decide
theorem rec1_11 : ∀ n : Fin 15, tab (n.val+585)=step tab (n.val+585) := by decide
theorem rec1_12 : ∀ n : Fin 15, tab (n.val+600)=step tab (n.val+600) := by decide
theorem rec1_13 : ∀ n : Fin 15, tab (n.val+615)=step tab (n.val+615) := by decide
theorem rec1_14 : ∀ n : Fin 15, tab (n.val+630)=step tab (n.val+630) := by decide
theorem rec1_15 : ∀ n : Fin 15, tab (n.val+645)=step tab (n.val+645) := by decide
theorem rec1_16 : ∀ n : Fin 15, tab (n.val+660)=step tab (n.val+660) := by decide
theorem rec1_17 : ∀ n : Fin 15, tab (n.val+675)=step tab (n.val+675) := by decide
theorem rec1_18 : ∀ n : Fin 15, tab (n.val+690)=step tab (n.val+690) := by decide
theorem rec1_19 : ∀ n : Fin 15, tab (n.val+705)=step tab (n.val+705) := by decide
theorem rec1_20 : ∀ n : Fin 15, tab (n.val+720)=step tab (n.val+720) := by decide
theorem rec1_21 : ∀ n : Fin 15, tab (n.val+735)=step tab (n.val+735) := by decide
theorem rec1_22 : ∀ n : Fin 15, tab (n.val+750)=step tab (n.val+750) := by decide
theorem rec1_23 : ∀ n : Fin 15, tab (n.val+765)=step tab (n.val+765) := by decide
theorem rec1_24 : ∀ n : Fin 15, tab (n.val+780)=step tab (n.val+780) := by decide
theorem rec1_25 : ∀ n : Fin 15, tab (n.val+795)=step tab (n.val+795) := by decide
theorem rec1_26 : ∀ n : Fin 15, tab (n.val+810)=step tab (n.val+810) := by decide
theorem rec1_27 : ∀ n : Fin 15, tab (n.val+825)=step tab (n.val+825) := by decide
theorem rec1 : ∀ n : Fin 420, tab (n.val+420)=step tab (n.val+420) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec1_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+420=n.val+420 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec1_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+435=n.val+420 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec1_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+450=n.val+420 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec1_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+465=n.val+420 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec1_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+480=n.val+420 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec1_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+495=n.val+420 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec1_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+510=n.val+420 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec1_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+525=n.val+420 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec1_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+540=n.val+420 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec1_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+555=n.val+420 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec1_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+570=n.val+420 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec1_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+585=n.val+420 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec1_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+600=n.val+420 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec1_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+615=n.val+420 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec1_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+630=n.val+420 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec1_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+645=n.val+420 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec1_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+660=n.val+420 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec1_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+675=n.val+420 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec1_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+690=n.val+420 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec1_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+705=n.val+420 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec1_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+720=n.val+420 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec1_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+735=n.val+420 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec1_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+750=n.val+420 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec1_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+765=n.val+420 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec1_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+780=n.val+420 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec1_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+795=n.val+420 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec1_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+810=n.val+420 := by omega
    simpa only [he] using h
  have h := rec1_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+825=n.val+420 := by omega
  simpa only [he] using h
theorem rows1 : ∀ r : Fin 60,
  0 ≤ tab (r.val+60+2520) ∧
  0 ≤ tab (r.val+60+3360)-tab (r.val+60+2520) ∧
  0 ≤ tab (r.val+60+4200)-2*tab (r.val+60+3360)+tab (r.val+60+2520) ∧
  0 ≤ tab (r.val+60+5040)-3*tab (r.val+60+4200)+3*tab (r.val+60+3360)-tab (r.val+60+2520) := by decide
theorem pref1 : ∀ n : Fin 420, n.val+420≠8 → 0≤tab (n.val+420) := by decide

#print axioms rec1
#print axioms rows1
#print axioms pref1
end T4
