import RBSharedUnmarked
namespace RBShared
open Polynomial
open scoped BigOperators
def Low (N : Nat) (p q : Polynomial Int) : Prop := ∀ n, n ≤ N → p.coeff n = q.coeff n
theorem low_refl (N : Nat) (p : Polynomial Int) : Low N p p := fun _ _ => rfl
theorem low_mul {N : Nat} {p p' q q' : Polynomial Int}
 (hp : Low N p p') (hq : Low N q q') : Low N (p*q) (p'*q') := by
 intro n hn
 rw [Polynomial.coeff_mul, Polynomial.coeff_mul]
 apply Finset.sum_congr rfl
 rintro ⟨i,j⟩ hij
 have hs : i+j=n := Finset.mem_antidiagonal.mp hij
 rw [hp i (by omega), hq j (by omega)]
theorem low_cancel {N : Nat} (d p q : Polynomial Int) (hd : d.coeff 0 = 1)
 (h : Low N (d*p) (d*q)) : Low N p q := by
 intro n
 induction n using Nat.strong_induction_on with
 | h n ih =>
  intro hn
  have he := h n hn
  simp only [Polynomial.coeff_mul] at he
  have hm : (0,n) ∈ Finset.antidiagonal n := by simp
  rw [← Finset.add_sum_erase (Finset.antidiagonal n) (fun x => d.coeff x.1*p.coeff x.2) hm,
   ← Finset.add_sum_erase (Finset.antidiagonal n) (fun x => d.coeff x.1*q.coeff x.2) hm] at he
  simp only [hd,one_mul] at he
  have ht : (∑ x ∈ (Finset.antidiagonal n).erase (0,n), d.coeff x.1*p.coeff x.2) =
    ∑ x ∈ (Finset.antidiagonal n).erase (0,n), d.coeff x.1*q.coeff x.2 := by
   apply Finset.sum_congr rfl
   rintro ⟨i,j⟩ hij
   have hm' := Finset.mem_erase.mp hij
   have hs : i+j=n := Finset.mem_antidiagonal.mp hm'.2
   have hi : 0<i := by
    by_contra hh
    have hi0 : i=0 := by omega
    have hjn : j=n := by omega
    exact hm'.1 (by simp only [hi0,hjn])
   have hj : j<n := by omega
   rw [ih j hj (by omega)]
  rw [ht] at he
  exact add_right_cancel he
#print axioms low_cancel
end RBShared
