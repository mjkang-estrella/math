import RBSharedUniversal
import RBSharedInterval
set_option maxRecDepth 100000
namespace RBShared
open Polynomial
def NumSound (q : Polynomial Int) (k N H : Nat) (r : Nat → Int) : Prop :=
 ∀ n, n ≤ N → r n = (q*numerator k H).coeff n
def signedCheck (N d : Nat) (r s : Nat → Int) : Bool :=
 (List.range (N+1)).all fun n => decide (s n = r n - shift d r n)
theorem numerator_base (q : Polynomial Int) (k N : Nat) (r : Nat → Int)
 (hr : ∀ n, n ≤ N → r n = q.coeff n) : NumSound q k N 0 r := by
 intro n hn
 simpa only [numerator,mul_one] using hr n hn
theorem numerator_transition (q : Polynomial Int) (k N H : Nat) (r s : Nat → Int)
 (hr : NumSound q k N H r) (hc : signedCheck N (k*(H+1)) r s = true) :
 NumSound q k N (H+1) s := by
 intro n hn
 have he := (List.all_eq_true.mp hc) n (List.mem_range.mpr (by omega))
 simp only [decide_eq_true_eq] at he
 have hp : q*numerator k (H+1) = (1-X^(k*(H+1)))*(q*numerator k H) := by
  rw [numerator]
  ring
 rw [hp,sub_mul,one_mul,Polynomial.coeff_sub,shifted_coeff]
 rw [←hr n hn, ←shift_congr N (k*(H+1)) n r (q*numerator k H).coeff hr hn]
 exact he
theorem regular_row_sound (k : Nat) (hk : 0 < k) (r : Nat → Int)
 (hr : NumSound (RBPrefix.actualMarked 143 0) k 142 (142/k) r) :
 ∀ n, n ≤ 142 → r n = (RBPrefix.actualMarked k 0).coeff n := by
 have hx : 142 < k*(142/k+1) := by
  have h := (Nat.div_lt_iff_lt_mul hk).mp (show 142/k < 142/k+1 by omega)
  simpa only [Nat.mul_comm] using h
 have ht := numerator_tail k (142/k) 142 142 (Nat.div_le_self 142 k) hx
 have hm := low_mul (low_refl 142 (RBPrefix.actualMarked 143 0)) ht
 intro n hn
 exact (hr n hn).trans (((universal_product_bridge k) n hn).trans (hm n hn)).symm
#print axioms numerator_transition
#print axioms regular_row_sound
end RBShared
