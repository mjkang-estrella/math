import RBBinaryUnmarked
noncomputable section
namespace RBBinary
open Finset PowerSeries
local notation "𝔛" => (X : PowerSeries ℤ)
def b (a : ℕ) : PowerSeries ℤ := 1+𝔛^a
def native (a : ℕ) : PowerSeries ℤ := mk (fun n => (RBCount.C 2 a n : ℤ)-RBCount.C 2 (a+1) n)
def u (a : ℕ) : PowerSeries ℤ := b a * b (a+1) * lowDen

theorem binary_B (a : ℕ) : RBCount.Bf 2 a = b a := by
  simp [RBCount.Bf, sum_range_succ, b]
theorem binary_A (a : ℕ) : RBCount.Af 2 a = 𝔛^a := by
  simp [RBCount.Af, sum_range_succ]

theorem marked_clear (k a N : ℕ) (ha : a ∈ Icc 1 N) :
    RBCount.marked k a N * RBCount.Bf k a = RBCount.Af k a * RBCount.prodB k N := by
  have hp : RBCount.prodB k N = RBCount.Bf k a * ∏ h ∈ (Icc 1 N).erase a, RBCount.Bf k h := by
    exact (Finset.mul_prod_erase (Icc 1 N) (RBCount.Bf k) ha).symm
  rw [hp]
  unfold RBCount.marked
  ring

theorem marked_binary_clear (a N : ℕ) (ha : 1 ≤ a) (haN : a+1 ≤ N) :
    (RBCount.marked 2 a N-RBCount.marked 2 (a+1) N)*b a*b (a+1) =
      (𝔛^a-𝔛^(a+1))*RBCount.prodB 2 N := by
  have h1 := marked_clear 2 a N (mem_Icc.mpr ⟨ha,by omega⟩)
  have h2 := marked_clear 2 (a+1) N (mem_Icc.mpr ⟨by omega,haN⟩)
  rw [binary_A,binary_B] at h1 h2
  unfold b at h1 h2 ⊢
  linear_combination (1+𝔛^(a+1))*h1-(1+𝔛^a)*h2

theorem native_cleared (a : ℕ) (ha : 1 ≤ a) :
    native a * u a = (𝔛^a-𝔛^(a+1))*RBAbsorb.R := by
  ext n
  let N := max 7 (max n (a+1))
  have hn : n ≤ N := le_trans (le_max_left _ _) (le_max_right _ _)
  have haN : a+1 ≤ N := le_trans (le_max_right _ _) (le_max_right _ _)
  have h7 : 7 ≤ N := le_max_left _ _
  have hm : Agree N (RBCount.marked 2 a N-RBCount.marked 2 (a+1) N) (native a) := by
    intro j hj
    simpa only [native, coeff_mk] using RBCount.coeff_marked_sub (by decide : 1≤2) ha haN hj
  have hb : ∀ i, Agree N (b i) (b i) := fun _ _ _ => rfl
  have hl : Agree N lowDen lowDen := fun _ _ => rfl
  have hleft := agree_mul (agree_mul (agree_mul hm (hb a)) (hb (a+1))) hl
  have hu := agree_mul (show Agree N (𝔛^a-𝔛^(a+1)) (𝔛^a-𝔛^(a+1)) from fun _ _ => rfl)
    (unmarked_low_cleared N h7)
  have hr : Agree N (residualGeometric N) RBAbsorb.R := fun j hj => geometric_residual_cutoff j N hj
  have hr' := agree_mul (show Agree N (𝔛^a-𝔛^(a+1)) (𝔛^a-𝔛^(a+1)) from fun _ _ => rfl) hr
  calc
    coeff n (native a*u a) = coeff n (((RBCount.marked 2 a N-RBCount.marked 2 (a+1) N)*b a*b (a+1))*lowDen) := by
      simpa only [u, mul_assoc] using (hleft n hn).symm
    _ = coeff n ((𝔛^a-𝔛^(a+1))*(RBCount.prodB 2 N*lowDen)) := by
      rw [marked_binary_clear a N ha haN, mul_assoc]
    _ = coeff n ((𝔛^a-𝔛^(a+1))*residualGeometric N) := hu n hn
    _ = coeff n ((𝔛^a-𝔛^(a+1))*RBAbsorb.R) := hr' n hn

#print axioms native_cleared
end RBBinary
