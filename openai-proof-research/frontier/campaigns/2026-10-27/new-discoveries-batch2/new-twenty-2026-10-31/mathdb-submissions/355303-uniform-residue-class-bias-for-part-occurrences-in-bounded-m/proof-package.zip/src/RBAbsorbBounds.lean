import RBAbsorbFibers
import Atoms
noncomputable section
namespace RBAbsorb
open PowerSeries

theorem product_mono (L T : PowerSeries ℤ) (h : ∀ d, coeff d L ≤ coeff d T) (n : ℕ) :
    coeff n (L*R) ≤ coeff n (T*R) := by
  rw [PowerSeries.coeff_mul, PowerSeries.coeff_mul]
  apply Finset.sum_le_sum
  intro p _
  exact mul_le_mul_of_nonneg_right (h p.1) (by rw [coeff_R]; positivity)

def L1 : PowerSeries ℤ := X^1+X^4+X^8+X^11-X^2
theorem bound1 (n : ℕ) : coeff n L1 ≤ coeff n T1.rational := by
  by_cases hn : n<25
  · rw [T1.small_rational ⟨n,hn⟩]
    interval_cases n <;> norm_num [L1, PowerSeries.coeff_X_pow, PowerSeries.coeff_X, T1.small, T1.smallValues]
  · have he : coeff n L1 = 0 := by
      simp only [L1, map_add, map_sub, PowerSeries.coeff_X_pow]
      split_ifs <;> omega
    rw [he]
    exact T1.coefficient_nonnegative n (by omega)
theorem expand1 (n : ℕ) : coeff n (L1*R) = shifted n 1+shifted n 4+shifted n 8+shifted n 11-shifted n 2 := by
  simp only [L1, add_mul, sub_mul, map_add, map_sub, ← shifted_coeff]
#print axioms bound1

def L2 : PowerSeries ℤ := X^2+X^6+X^7+X^13-X^4
theorem bound2 (n : ℕ) : coeff n L2 ≤ coeff n T2.rational := by
  by_cases hn : n<25
  · rw [T2.small_rational ⟨n,hn⟩]
    interval_cases n <;> norm_num [L2, PowerSeries.coeff_X_pow, PowerSeries.coeff_X, T2.small, T2.smallValues]
  · have he : coeff n L2 = 0 := by
      simp only [L2, map_add, map_sub, PowerSeries.coeff_X_pow]
      split_ifs <;> omega
    rw [he]
    exact T2.coefficient_nonnegative n (by omega)
theorem expand2 (n : ℕ) : coeff n (L2*R) = shifted n 2+shifted n 6+shifted n 7+shifted n 13-shifted n 4 := by
  simp only [L2, add_mul, sub_mul, map_add, map_sub, ← shifted_coeff]
#print axioms bound2

def L3 : PowerSeries ℤ := X^3+X^8+X^9+X^16+X^16+X^21+X^23-X^7-X^12
theorem bound3 (n : ℕ) : coeff n L3 ≤ coeff n T3.rational := by
  by_cases hn : n<25
  · rw [T3.small_rational ⟨n,hn⟩]
    interval_cases n <;> norm_num [L3, PowerSeries.coeff_X_pow, PowerSeries.coeff_X, T3.small, T3.smallValues]
  · have he : coeff n L3 = 0 := by
      simp only [L3, map_add, map_sub, PowerSeries.coeff_X_pow]
      split_ifs <;> omega
    rw [he]
    exact T3.coefficient_nonnegative n (by omega) (by omega)
theorem expand3 (n : ℕ) : coeff n (L3*R) = shifted n 3+shifted n 8+shifted n 9+shifted n 16+shifted n 16+shifted n 21+shifted n 23-shifted n 7-shifted n 12 := by
  simp only [L3, add_mul, sub_mul, map_add, map_sub, ← shifted_coeff]
#print axioms bound3

def L4 : PowerSeries ℤ := X^4+X^7+X^10+X^17-X^8
theorem bound4 (n : ℕ) : coeff n L4 ≤ coeff n T4.rational := by
  by_cases hn : n<25
  · rw [T4.small_rational ⟨n,hn⟩]
    interval_cases n <;> norm_num [L4, PowerSeries.coeff_X_pow, PowerSeries.coeff_X, T4.small, T4.smallValues]
  · have he : coeff n L4 = 0 := by
      simp only [L4, map_add, map_sub, PowerSeries.coeff_X_pow]
      split_ifs <;> omega
    rw [he]
    exact T4.coefficient_nonnegative n (by omega)
theorem expand4 (n : ℕ) : coeff n (L4*R) = shifted n 4+shifted n 7+shifted n 10+shifted n 17-shifted n 8 := by
  simp only [L4, add_mul, sub_mul, map_add, map_sub, ← shifted_coeff]
#print axioms bound4
end RBAbsorb
