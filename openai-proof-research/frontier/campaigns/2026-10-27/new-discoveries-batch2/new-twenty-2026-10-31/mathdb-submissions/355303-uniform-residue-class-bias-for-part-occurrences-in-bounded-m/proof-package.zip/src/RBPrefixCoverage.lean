import RBPrefixMemo
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RBPrefix
open scoped BigOperators
open Polynomial
theorem exponent_bound (k e : Nat) (hk : 2 ≤ k) : e < k^e := by
 induction e with
 | zero => simp
 | succ e ih =>
   have h := Nat.mul_le_mul_left (k^e) hk
   rw [pow_succ]
   omega
theorem positivePower_iff (k x : Nat) (hk : 2 ≤ k) :
 positivePower k x = true ↔ ∃ e : Nat, 0 < e ∧ k^e = x := by
 simp only [positivePower, List.any_eq_true, List.mem_range, Bool.and_eq_true,
   decide_eq_true_eq, beq_iff_eq]
 constructor
 · rintro ⟨e, _, he, hx⟩; exact ⟨e,he,hx⟩
 · rintro ⟨e, he, hx⟩
   exact ⟨e, by have := exponent_bound k e hk; omega, he, hx⟩
theorem expanded_product (k a H : Nat) : poly k (factors H a) =
 ∏ h ∈ Finset.range H, ∑ j ∈ Finset.range k,
   Polynomial.C (weight (h+1 == a) j) * Polynomial.X^(j*(h+1)) := by
 induction H with
 | zero => simp [factors,poly]
 | succ H ih => simp only [factors,poly,Finset.prod_range_succ,ih]; exact mul_comm _ _
def fastBox (lo hi : Nat) : Bool :=
 (List.range (hi-lo)).all fun d =>
 (List.range 24).all fun a =>
 (List.range 143).all fun n =>
 if Required (lo+d) a n then decide (fastCount (lo+d) (a+1) n < fastCount (lo+d) a n) else true
theorem fastBox_sound {lo hi : Nat} (h : fastBox lo hi = true) :
 ∀ k a n, lo ≤ k → k < hi → Required k a n → Comparison k a n := by
 intro k a n hl hh r
 have b := required_bounds r
 simp only [fastBox, List.all_eq_true] at h
 have h1 := h (k-lo) (List.mem_range.mpr (by omega))
 have h2 := h1 a (List.mem_range.mpr b.1)
 have h3 := h2 n (List.mem_range.mpr b.2)
 have he : lo + (k-lo) = k := by omega
 have hd : fastCount k (a+1) n < fastCount k a n := by simpa only [he, ite_eq_left r, decide_eq_true_eq] using h3
 rw [fastCount_eq k (a+1) n (by omega), fastCount_eq k a n (by omega)] at hd
 exact hd
#print axioms positivePower_iff
#print axioms expanded_product
#print axioms fastBox_sound
end RBPrefix
