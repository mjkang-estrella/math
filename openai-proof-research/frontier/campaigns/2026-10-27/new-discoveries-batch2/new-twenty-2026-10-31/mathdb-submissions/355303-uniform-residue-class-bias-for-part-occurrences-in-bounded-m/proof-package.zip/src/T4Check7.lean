import T4Data
set_option maxRecDepth 16000
set_option maxHeartbeats 20000000
namespace T4
theorem rec7_0 : ∀ n : Fin 15, tab (n.val+2940)=step tab (n.val+2940) := by decide
theorem rec7_1 : ∀ n : Fin 15, tab (n.val+2955)=step tab (n.val+2955) := by decide
theorem rec7_2 : ∀ n : Fin 15, tab (n.val+2970)=step tab (n.val+2970) := by decide
theorem rec7_3 : ∀ n : Fin 15, tab (n.val+2985)=step tab (n.val+2985) := by decide
theorem rec7_4 : ∀ n : Fin 15, tab (n.val+3000)=step tab (n.val+3000) := by decide
theorem rec7_5 : ∀ n : Fin 15, tab (n.val+3015)=step tab (n.val+3015) := by decide
theorem rec7_6 : ∀ n : Fin 15, tab (n.val+3030)=step tab (n.val+3030) := by decide
theorem rec7_7 : ∀ n : Fin 15, tab (n.val+3045)=step tab (n.val+3045) := by decide
theorem rec7_8 : ∀ n : Fin 15, tab (n.val+3060)=step tab (n.val+3060) := by decide
theorem rec7_9 : ∀ n : Fin 15, tab (n.val+3075)=step tab (n.val+3075) := by decide
theorem rec7_10 : ∀ n : Fin 15, tab (n.val+3090)=step tab (n.val+3090) := by decide
theorem rec7_11 : ∀ n : Fin 15, tab (n.val+3105)=step tab (n.val+3105) := by decide
theorem rec7_12 : ∀ n : Fin 15, tab (n.val+3120)=step tab (n.val+3120) := by decide
theorem rec7_13 : ∀ n : Fin 15, tab (n.val+3135)=step tab (n.val+3135) := by decide
theorem rec7_14 : ∀ n : Fin 15, tab (n.val+3150)=step tab (n.val+3150) := by decide
theorem rec7_15 : ∀ n : Fin 15, tab (n.val+3165)=step tab (n.val+3165) := by decide
theorem rec7_16 : ∀ n : Fin 15, tab (n.val+3180)=step tab (n.val+3180) := by decide
theorem rec7_17 : ∀ n : Fin 15, tab (n.val+3195)=step tab (n.val+3195) := by decide
theorem rec7_18 : ∀ n : Fin 15, tab (n.val+3210)=step tab (n.val+3210) := by decide
theorem rec7_19 : ∀ n : Fin 15, tab (n.val+3225)=step tab (n.val+3225) := by decide
theorem rec7_20 : ∀ n : Fin 15, tab (n.val+3240)=step tab (n.val+3240) := by decide
theorem rec7_21 : ∀ n : Fin 15, tab (n.val+3255)=step tab (n.val+3255) := by decide
theorem rec7_22 : ∀ n : Fin 15, tab (n.val+3270)=step tab (n.val+3270) := by decide
theorem rec7_23 : ∀ n : Fin 15, tab (n.val+3285)=step tab (n.val+3285) := by decide
theorem rec7_24 : ∀ n : Fin 15, tab (n.val+3300)=step tab (n.val+3300) := by decide
theorem rec7_25 : ∀ n : Fin 15, tab (n.val+3315)=step tab (n.val+3315) := by decide
theorem rec7_26 : ∀ n : Fin 15, tab (n.val+3330)=step tab (n.val+3330) := by decide
theorem rec7_27 : ∀ n : Fin 15, tab (n.val+3345)=step tab (n.val+3345) := by decide
theorem rec7 : ∀ n : Fin 420, tab (n.val+2940)=step tab (n.val+2940) := by
  intro n
  by_cases h0 : n.val < 15
  · have h := rec7_0 ⟨n.val-0,by omega⟩
    have he : n.val-0+2940=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h1 : n.val < 30
  · have h := rec7_1 ⟨n.val-15,by omega⟩
    have he : n.val-15+2955=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h2 : n.val < 45
  · have h := rec7_2 ⟨n.val-30,by omega⟩
    have he : n.val-30+2970=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h3 : n.val < 60
  · have h := rec7_3 ⟨n.val-45,by omega⟩
    have he : n.val-45+2985=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h4 : n.val < 75
  · have h := rec7_4 ⟨n.val-60,by omega⟩
    have he : n.val-60+3000=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h5 : n.val < 90
  · have h := rec7_5 ⟨n.val-75,by omega⟩
    have he : n.val-75+3015=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h6 : n.val < 105
  · have h := rec7_6 ⟨n.val-90,by omega⟩
    have he : n.val-90+3030=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h7 : n.val < 120
  · have h := rec7_7 ⟨n.val-105,by omega⟩
    have he : n.val-105+3045=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h8 : n.val < 135
  · have h := rec7_8 ⟨n.val-120,by omega⟩
    have he : n.val-120+3060=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h9 : n.val < 150
  · have h := rec7_9 ⟨n.val-135,by omega⟩
    have he : n.val-135+3075=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h10 : n.val < 165
  · have h := rec7_10 ⟨n.val-150,by omega⟩
    have he : n.val-150+3090=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h11 : n.val < 180
  · have h := rec7_11 ⟨n.val-165,by omega⟩
    have he : n.val-165+3105=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h12 : n.val < 195
  · have h := rec7_12 ⟨n.val-180,by omega⟩
    have he : n.val-180+3120=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h13 : n.val < 210
  · have h := rec7_13 ⟨n.val-195,by omega⟩
    have he : n.val-195+3135=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h14 : n.val < 225
  · have h := rec7_14 ⟨n.val-210,by omega⟩
    have he : n.val-210+3150=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h15 : n.val < 240
  · have h := rec7_15 ⟨n.val-225,by omega⟩
    have he : n.val-225+3165=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h16 : n.val < 255
  · have h := rec7_16 ⟨n.val-240,by omega⟩
    have he : n.val-240+3180=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h17 : n.val < 270
  · have h := rec7_17 ⟨n.val-255,by omega⟩
    have he : n.val-255+3195=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h18 : n.val < 285
  · have h := rec7_18 ⟨n.val-270,by omega⟩
    have he : n.val-270+3210=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h19 : n.val < 300
  · have h := rec7_19 ⟨n.val-285,by omega⟩
    have he : n.val-285+3225=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h20 : n.val < 315
  · have h := rec7_20 ⟨n.val-300,by omega⟩
    have he : n.val-300+3240=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h21 : n.val < 330
  · have h := rec7_21 ⟨n.val-315,by omega⟩
    have he : n.val-315+3255=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h22 : n.val < 345
  · have h := rec7_22 ⟨n.val-330,by omega⟩
    have he : n.val-330+3270=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h23 : n.val < 360
  · have h := rec7_23 ⟨n.val-345,by omega⟩
    have he : n.val-345+3285=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h24 : n.val < 375
  · have h := rec7_24 ⟨n.val-360,by omega⟩
    have he : n.val-360+3300=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h25 : n.val < 390
  · have h := rec7_25 ⟨n.val-375,by omega⟩
    have he : n.val-375+3315=n.val+2940 := by omega
    simpa only [he] using h
  by_cases h26 : n.val < 405
  · have h := rec7_26 ⟨n.val-390,by omega⟩
    have he : n.val-390+3330=n.val+2940 := by omega
    simpa only [he] using h
  have h := rec7_27 ⟨n.val-405,by omega⟩
  have he : n.val-405+3345=n.val+2940 := by omega
  simpa only [he] using h
theorem rows7 : ∀ r : Fin 60,
  0 ≤ tab (r.val+420+2520) ∧
  0 ≤ tab (r.val+420+3360)-tab (r.val+420+2520) ∧
  0 ≤ tab (r.val+420+4200)-2*tab (r.val+420+3360)+tab (r.val+420+2520) ∧
  0 ≤ tab (r.val+420+5040)-3*tab (r.val+420+4200)+3*tab (r.val+420+3360)-tab (r.val+420+2520) := by decide

#print axioms rec7
#print axioms rows7
end T4
