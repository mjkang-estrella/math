# MathDB 355303 — FINAL independent replay and fidelity report (resumed)

Lane: `regular-bias-unconditional-final-independent-full-replay-opus-r1` (Claude Opus 5.5, formal test/replay sub-agent).
Resume authority: `root-intake-r60/355303-independent-replay-continuation-authorization-20261116-v1.json` (read in full).
Inputs read for the resume: that authorization, `regular-bias-replay-recovery-opus-20261116-r1/{REPORT.md,review.json}`, this lane's `TASK.txt`, both applicable `AGENTS.md` files (new-twenty, batch2), `driver/replay.sh`, `check32.sh`, `checker32.sh`, `run_lean_32g.py`, `formal_command.py`, `write_lane.py`, `verify_frozen.py`, `run.py` (head), `PINS.json`, `formal-budget.json`.

## Verdict

**The scoped full scientific replay and literal-fidelity check of the native endpoint passes. Acceptance is not decided here; credit stays 0. Root gates remain open (listed below).**

* All **332/332** canonical modules are now freshly compiled from this lane's own independently extracted sources. Each compile is immediately followed by a **separate** `leanchecker` kernel check. The build started empty in the original run (#2–#611) and was finished here (#613–#666).
* The new independent audits **`RBReplayUnconditional`** (#667/#668) and **`RBReplayAxiomMap`** (#669/#670) were compiled and separately kernel-checked.
* `RB355303.original_weak` and `RB355303.original_strict`, together with my fully expanded restatements, are closed theorems over literal Mathlib `Nat.Partition.countRestricted`. Their whole proof closure (68,573 constants) uses only {propext, Classical.choice, Quot.sound}, with no unsafe and no partial constant.
* Zero failures and zero repairs. No audit implementation change was needed, and no source was changed.

## Call accounting (original 768 allocation; no reset, no raise)

| Range | Count | Content | Result |
|---|---|---|---|
| #1 | 1 | `p-version` probe (prior session) | pass |
| #2–#611 | 610 | compile and check, positions 0–304 (prior session) | all pass (305 pairs) |
| **#612** | 1 | `c-305-RBStageFnBinary22` | **INTERRUPTED / UNKNOWN**. No receipt, output or olean. Marker preserved untouched; counts against budget. |
| #613 | 1 | `c-305r1-RBStageFnBinary22` (unique retry label) | pass |
| #614–#666 | 53 | `k-305`, then compile and check for positions 306–331 (RBStageFnBinary23..44, RBStageFnBinaryEndpoint, RBSharedClosed, RB355303Final, RB355303Audit) | all pass |
| #667–#668 | 2 | `c-A1`/`k-A1-RBReplayUnconditional` | pass |
| #669–#670 | 2 | `c-A2`/`k-A2-RBReplayAxiomMap` | pass |

* **Total markers:** 670 of 768. **Used by this resume:** 58, exactly the planned number. **Unused:** 98. Every one of #613–#670 has a receipt.
* **Labels:** only #612's retry needed a new label (`r1`). The check for position 305 used the never-used base label `k-305-RBStageFnBinary22`.
* **Resource use (new calls):** max wall 33.83 s (c-A2), max sampled group RSS 3.03 GB (c-331), total wall 888 s.
* **Caps (every receipt):** affinity [0,1], CPU 115 s, AS 32 GiB, group RSS 6 GiB, deadline 130 s, `-j1 -M3500 -DwarningAsError=true`, `LEAN_PATH` = own `build` then pinned upstream only, Lean 4.34.1 binaries hash-verified by `formal_command.py` on every call.
* **Driver:** new file `driver/resume.sh` (sha256 `d8257389…1da1`). It runs one position per foreground harness call, with the same wrappers, the same 760-marker abort threshold, and no overwrite of any existing marker, receipt or output. Its log is `driver-resume-20261116.log`. The original `driver/replay.sh` (`e70c0752…5244`) and `driver-run-10-332.log` are unchanged.
* **Process attachment:** every Lean call ran in the foreground inside an active harness call (about 3–40 s each). Nothing was left in the background.

## Gate table

| Gate | Status | Evidence |
|---|---|---|
| Custody before resume | PASS | `resume-prestart-check.json`: frozen 10,420 entries, 0 mismatches. 332 src hashes equal the canonical index; ORDER equals the index positions. No oleans for 305–331, all 305 earlier oleans present. No live Lean/driver process. 612 markers, no #612 receipt/output. |
| Fresh compile + separate kernel check, all 332 | **PASS** | `maps/FINAL-MODULE-CALL-OLEAN-MAP.json` (sha `4eec45ab…76c2`): 334 modules (332 plus 2 audits), each with exactly one passing compile followed by one passing check. 0 defects. |
| Receipt integrity, new 58 | PASS | `resume-call-audit.json` (`45be1de3…a31f`). Every receipt: exit 0, not killed, empty stderr. Source sha identical before and after and equal to the file. Every compile starts from an absent olean (`olean_sha256_before = null`). Check olean = compile olean = current build olean. |
| Final theorem fresh | **PASS** | `RBSharedClosed` (#661/#662), `RB355303Final` (#663/#664), `RB355303Audit` (#665/#666). |
| Expanded unconditional audit | **PASS** | `RBReplayAudit.{weak_literal, strict_literal, conjecture_1_4, countRestricted_spelled, weak/strict_spelled, weak/strict_modEq, weak/strict_top_dvd, domains_inhabited}`. Every theorem has only parameter-range hypotheses and is proved solely from `RB355303.original_weak/strict`. `#print axioms` gives the standard three only (`domains_inhabited`: none). `pp.all` types confirm root `Nat`, `Nat.Partition.countRestricted`, `Multiset.filter`/`card`, `Nat.instMod`, `instDecidableEqNat` and `Nat.instMax`. |
| Exhaustive axiom / unsafe / reachability map | **PASS** | Independent traversal of actual kernel type and value expressions. It does not use the precomputed axiom extension. 337 flat modules = 332 project + `RBReplayUnconditional` + 4 upstream umbrella modules (`Aesop`, `Qq`, `Plausible`, `LeanSearchClient`), each with 0 declarations; the flat-name heuristic misclassifies them, which only over-approximates. Results: roots 56,692; reachable 73,711; missing 0; DFS finished; fixed point stable in 5 passes; non-standard-axiom roots 0. REACH_AXIOMS = REACH_UNSAFE = 0. PROOF_CLOSURE (14 roots incl. original_weak/strict, nativeEndpoint, full_table): reachable 68,573 (56,228 project), axioms = standard three, unsafe 0, partial 0. |
| Author audit replay | PASS, consistent | `RB355303Audit` fresh: EXPORT_COUNT 56,661. 24,421 "depends on" lines are all subsets of the standard three; 32,242 "does not depend". 56,661 + 11 (RBReplayAudit) + 20 (RBReplayAxiomMap) = 56,692, exactly my root count. |
| Compiler-generated helpers | DISCLOSED, not proof-reachable | The only flagged project declarations are `RBPrefix.{memo,coeffRun,factors,memoCut}._unsafe_rec`. They carry flags P (partial safety) and R, not U, and are absent from PROOF_CLOSURE (PROOF_PARTIAL = 0). They are code-generation helpers for well-founded definitions, and the kernel uses the safe definitions. |
| implemented_by / extern | DISCLOSED | Reachable 37 / 129, in the proof closure 6 / 53. All are on upstream core constants. These are compiler runtime attributes and are not consulted by the kernel. None are on project declarations (no I/E flags in any DECL row). |
| Name hijack | PASS | No project declaration in the `Nat.`, `Multiset.`, `Finset.`, `inst*`, `Lean.`, `Classical.`, `Quot*` or `Decidable*` namespaces. One exception: `Nat.Partition.countRestricted.eq_1`, the auto-realized equation lemma of the Mathlib definition (a theorem, standard axioms). |
| Import resolution | PASS (with disclosure) | All 333 project imports resolve to own `build/` and exist in no upstream path. 23 distinct upstream imports. The only non-Mathlib one is `Lean.Elab.Tactic.Omega` (RBPrefixCheck, Support), which resolves via the pinned toolchain sysroot `lean-4.34.1-linux/lib/lean`. No project name exists in the upstream paths or the toolchain. No umbrella `Mathlib`/`Lean`/`Std`/`Batteries` import. `build/` holds exactly 335 oleans (332 + 2 audits + version probe). |
| Lexical scan, 334 sources | PASS | Hits for `axiom` (7), `partial` (5), `sorry` (1), `native_decide` (1), `unsafe` (2) and `opaque` (1) are all in comments or in `RBReplayAxiomMap`'s own meta strings/patterns. Kernel-level confirmation comes from the map above. |
| Reproducibility vs author (read-only hash comparison, nothing copied) | Informative | 330/330 paid-cache oleans are byte-identical to the fresh ones. `RB355303Final`/`Audit` fresh oleans equal `producer/build` (`4c262a89…d9e4`, `23fce24d…bcea`). Receipts prove the fresh writes, so this is reproducibility, not copying. |
| Literal statement fidelity | PASS | See below. |
| Frozen-after and seal | Performed after this report | `frozen-after.json` comes from standalone `verify_frozen.py after`. `PHYSICAL-SHA256-SEAL.json` comes from run.py label `final-seal`, with exactly three exclusions. |

Key fresh hashes:
* `RBSharedClosed.olean` `f7729dec…c4cc`
* `RB355303Final.olean` `4c262a89…d9e4`
* `RB355303Audit.olean` `23fce24d…bcea`
* `RBReplayUnconditional.olean` `39ba4840…ce89`
* `RBReplayAxiomMap.olean` `14cadaee…c75a`
* Sources: Final `a43297f7…71f8`, Audit `551c6e9a…c78c`, SharedClosed `cde0c67e…24bb`, Unconditional `3a48da9b…6651`, AxiomMap `3836d855…f6df197`
* Outputs: A2 `6d79466a…be4a`, 331 `914a83b4…19e1`, A1 `6de79389…f64b`

## Literal source fidelity (personal reading)

**Owned native text** (sha `d26525d3…ce4d`, arXiv:2207.04352v1, Jackson–Otgonbayar), read in r047/r048 excerpts:

> Conjecture 1.4. If t ≥ 6 and 1 ≤ r < s ≤ t, k ≥ 3, then for n ≥ 1 we have D_k(r,t;n) ≥ D_k(s,t;n). Further, for k ≥ 2 if n > max{t+3,16}, the strict inequality D_k(r,t;n) > D_k(s,t;n) holds.

The abstract defines D_k(r,t;n) as the number of parts, among all k-regular partitions of n ("all parts have multiplicity less than k"), that are congruent to r modulo t.

**Kernel-checked type** (pp.all, from c-A1):
* Weak: `∀ k t r s n : Nat, 3 ≤ k → 6 ≤ t → 1 ≤ r → r < s → s ≤ t → 1 ≤ n → Σ_{p ∈ countRestricted n k} card(filter (x % t = s % t) p.parts) ≤ Σ … (x % t = r % t)`.
* Strict: the same with `2 ≤ k`, `max (t+3) 16 < n` and `<`.

Pinned Mathlib `countRestricted n m := univ.filter (∀ i ∈ parts, parts.count i < m)`. Partitions are multisets of positive parts summing to n. Multiset filter-card counts occurrences with multiplicity. `s = t` gives residue 0 (also proved literally as `t ∣ x` in `weak/strict_top_dvd`). n is unbounded. There are no extra hypotheses. The strict clause inherits t ≥ 6, 1 ≤ r < s ≤ t from the sentence "Further…", which is the natural reading; the recovery review and earlier source reviews used the same reading.

**Premise discharge:** `RBAssemble.FinitePrefixPolynomial` is `∀ k a n, RBPrefix.Required k a n → (actualMarked k (a+1)).coeff n < (actualMarked k a).coeff n`. `RBSharedClosed.full_table` has exactly this type and is closed: `complete_block 2 144` built by `join_block`/`singleton_block` over shards 2..143, with `k < 144` from `hr.2.1` by omega. `expanded_polynomial_endpoint` spells `actualMarked` as the literal product of truncated polynomials. The axiom map confirms the premise is discharged by proof, with no axiom, opaque, oracle or typeclass premise in the closure.

## Final paper adequacy (FINAL-PAPER.md `a3a2414f…250c`; body PAPER-BODY.md `8125bb2d…f8e5`, 167 lines, read in full)

What it does well:
* The statement section matches the Lean endpoint and the native conjecture exactly, including the multiplicity convention, occurrence counting and residue t = 0.
* The weak-clause proof is given essentially in full and checks:
  * kernel identity A_aB_{a+1} − A_{a+1}B_a = (1−q)F_a, verified by hand for k = 2 (F = q^a) and k = 3;
  * chain telescoping and the coin identity;
  * the k ≥ 4 and k = 4, x = 4 collision analysis (I re-derived that 3 is the only possible collision of chains 2 and 3 with a marked neighbour of k^v);
  * a = 1 via H_k (checked: H_3 = q(1−q²)² = (1−q)²(1−q²)F_1/(1−q³)).
* The finite reduction is correct: n ≤ 142, C_k = C_143 for k > 143, exceptional cases force k ≤ 24.
* The residue telescope is correct (j = 0 term strict since r + 4 ≤ t + 3; for k = 2, j ≥ 1 terms have a ≥ 7 ≥ 5).
* It contains a byte-exact standalone extractor and the full source appendix. This replay used its own extractor and confirmed all 332 hashes.

Remaining manuscript gates (these are real content gaps, not root preference):
* **MG1 — strict support is only sketched in prose.** The five support regions are stated with a mechanism outline. These are: a ≥ 24, n ≥ a + 5; a = 1, n ≥ 17; k = 3 exceptional; non-exceptional n ≥ a + 120; exceptional n ≥ a + 24. The large-a "single allowed parts below the conductor" argument and the exceptional-conductor numerators are deferred to RBStrictTail/RBStrictLow. A referee cannot verify the strict clause from the prose alone. Correctness is established by the kernel, but the manuscript lacks a human-readable proof of these lemmas.
* **MG2 — low binary pairs (k = 2, a = 1..4) are only outlined.** T_a are stated, but the explicit lower-bound polynomials, the residual-fiber injections, the strict-surplus partitions and the finite initial-degree checks appear only as Lean (T1–T4, RBAbsorb*). The prose gives no checkable argument for n ≥ 17 positivity.
* **MG3 — one expository imprecision.** "If neither a nor a+1 is a positive k-power, chain 1 cancels 1−q" is false as written for a = 1, since 1 = k⁰ lies in chain 1. The logic is not affected, because a = 1 is treated separately immediately after. The text should read a ≥ 2.
* **MG4 — stale status text.** The paper says it is "not an independent fresh replay" and "Root must independently verify". This replay now supplies that, so the status, provenance and limits sections need updating. They also contain campaign-accounting text (e.g. "75/80") that does not belong in a mathematical manuscript.
* **MG5 — no prior-art, novelty or significance section.** Beyond citing the source conjecture and noting that its circle-method and k, t ≤ 10 checks do not prove it, the paper has none. Current-registry and literature status and the substantial-contribution argument remain separate root gates and are not established by this paper.
* **MG6 — source-binding limits are inherited.** The paper did not visually recheck the PDF or reacquire MathDB. Earlier lanes' visual binding is inherited by hash, and my fidelity check above used the owned text extraction only.

**Assessment:** the paper is adequate as the formal-proof companion and as the source and statement record. The weak clause, finite reduction, closing and residue argument are adequately written. It is **not yet adequate as a standalone human-verifiable manuscript for the strict clause** (MG1, MG2). Root should either require prose proofs for MG1/MG2 or explicitly accept that the strict-support and low-binary arguments are certified by the kernel only. MG3 and MG4 are editorial; MG5 is the prior-art and significance gate.

## Limitations (honest)

* **Trust base:** the kernel and `leanchecker` of the pinned Lean 4.34.1 (binary hashes verified), and upstream Mathlib, Batteries and other oleans in `PINS.upstream_lean_paths`. Root hashed these; this lane did not rebuild upstream or attest its olean provenance. GMP-accelerated kernel `Nat` literals are part of the standard trust base.
* **Axiom map:** it mirrors `Lean.CollectAxioms.collect`'s dependency rules (type and value; inductive → ctors; ctor and rec types). It reads imported declarations as stored in oleans, which is the same environment `leanchecker` replays. The `#print axioms` lines (author audit) use the precomputed extension, which is a metadata limitation; the independent map does not rely on it.
* **Flat-name heuristic:** it over-includes 4 empty upstream umbrella modules. This is harmless.
* **Not re-reviewed here:** current registry and prior art, significance, process history, the 50 MB numeric shard bodies (the kernel checks them), and most module bodies.

## Deviations (all preserved, UNWAIVED)

1. #612 interrupted with no receipt (prior session). Retried as `c-305r1-…`.
2. The documentary audit `resume-call-audit` failed (exit 1) on parsing the `p-version` label. Its receipt is preserved, and the corrected re-run is `resume-call-audit-r2`. This was not a Lean call.
3. Several read-only inspection commands (cat, grep, sha256sum, python -c) ran directly in the harness shell rather than through run.py. Several displays exceeded the TASK's 2,000/2,400-character slice caps: TASK, both audit sources, PAPER-BODY, the first 5,000 characters of c-331 output, and the A1 pp.all output.
4. Helper program texts (pre.py, aud.py, maps.py and a draft of resume.sh) were written in the session scratchpad outside the lane, and aud.py was edited there with sed. Their exact code is recorded in the corresponding run.py receipts. resume.sh entered the lane only through write_lane.py.
5. The driver writes its log through write_lane by rewriting the whole file each line, not by append-in-place.
6. The prior lane's earlier deviations listed in the recovery review are retained: positions 0–9 log absent, version-probe olean, and the author's f003 failure.

## Files added by this resume

* `resume-prestart-check.json`
* `driver/resume.sh`
* `driver-resume-20261116.log`
* `calls/0613…0670-*.start`, plus the c-/k- receipts and outputs for 305–331, A1 and A2
* `build/*.olean` (29 new)
* `resume-call-audit.json`
* `maps/FINAL-MODULE-CALL-OLEAN-MAP.json`
* run.py receipts/outputs: `resume-prestart`, `resume-call-audit` (failed), `resume-call-audit-r2`, `final-module-map`, `final-seal`
* `FINAL-REPLAY-AND-FIDELITY.md` (this file)
* `frozen-after.json`
* `PHYSICAL-SHA256-SEAL.json`

No acceptance, shared-ledger, git, publication, subagent, network or search action. Credit 0. A full replay failure would have been HOLD/0; none occurred.
