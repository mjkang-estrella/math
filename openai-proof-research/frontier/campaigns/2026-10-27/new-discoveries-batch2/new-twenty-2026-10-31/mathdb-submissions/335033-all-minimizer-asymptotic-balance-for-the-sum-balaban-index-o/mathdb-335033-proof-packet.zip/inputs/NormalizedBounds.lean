import ActualPrefactor
namespace SumBalaban
theorem actual_normalized_bounds {a b d : ℕ} {B δ : ℝ}
    (hb : 0<b) (_hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hql : δ*(a+b+d:ℕ)≤(a:ℝ)^2+(d:ℝ)^2) :
    let n : ℝ := (a+b+d:ℕ)
    let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
    let u : ℝ := ((a:ℝ)+d)/n
    let t : ℝ := ((a:ℝ)^3+(d:ℝ)^3)/n^2
    δ≤q ∧ q≤B ∧ 0≤u ∧ u≤1 ∧ 0≤t ∧ t≤B*u ∧ u^2≤2*B/n := by
  dsimp only
  let n : ℝ := (a+b+d:ℕ)
  let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
  let u : ℝ := ((a:ℝ)+d)/n
  let t : ℝ := ((a:ℝ)^3+(d:ℝ)^3)/n^2
  have hn0 : 0<n := by dsimp [n]; exact_mod_cast (show 0<a+b+d by omega)
  have hu0 : 0≤u := by dsimp [u]; positivity
  have hqB : q≤B := (div_le_iff₀ hn0).mpr hq
  have hu1 : u≤1 := by
    apply (div_le_one hn0).mpr
    dsimp [n]
    push_cast
    linarith [show (0:ℝ)≤b by positivity]
  have htq : t≤u*q := by
    have hid : u*q=(((a:ℝ)+d)*((a:ℝ)^2+(d:ℝ)^2))/n^2 := by dsimp [u,q]; ring
    rw [hid]
    apply (div_le_div_iff_of_pos_right (sq_pos_of_pos hn0)).mpr
    have hh : 0≤(a:ℝ)*(d:ℝ)*((a:ℝ)+d) := by positivity
    nlinarith
  have htB : t≤B*u := by
    have hh := mul_le_mul_of_nonneg_left hqB hu0
    nlinarith
  have hu2 : u^2≤2*B/n := by
    have hid : 2*B/n=(2*B*n)/n^2 := by field_simp
    rw [hid]
    dsimp [u]
    rw [div_pow]
    apply (div_le_div_iff_of_pos_right (sq_pos_of_pos hn0)).mpr
    change (a:ℝ)^2+(d:ℝ)^2≤B*n at hq
    nlinarith [sq_nonneg ((a:ℝ)-d)]
  refine ⟨(le_div_iff₀ hn0).mpr hql,hqB,hu0,hu1,?_,htB,hu2⟩
  positivity
#print axioms actual_normalized_bounds
end SumBalaban
