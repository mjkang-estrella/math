import CliqueTaylor
namespace SumBalaban
theorem prefactor_residual_identity {q u v : ℝ}
    (hq : q≠0) (hD : q-u+2*v≠0) :
    (1+(2-4*v)/(q-u+2*v))-(1+2/q+2*u/q^2) =
    (2*u^2-4*v*q^2-4*v*q-4*u*v)/(q^2*(q-u+2*v)) := by
  field_simp
  ring

theorem prefactor_uniform_bound {q u v B δ : ℝ}
    (hδ : 0<δ) (hq : δ≤q) (hB : q≤B)
    (hu : 0≤u) (hu1 : u≤1) (huδ : u≤δ/2) (hv : 0≤v)
    (hu2 : u^2≤2*B*v) :
    |(1+(2-4*v)/(q-u+2*v))-(1+2/q+2*u/q^2)| ≤
      2*(4*B^2+8*B+4)*v/δ^3 := by
  have hq0 : 0<q := lt_of_lt_of_le hδ hq
  have hB0 : 0≤B := by linarith
  have hD : 0<q-u+2*v := by linarith
  rw [prefactor_residual_identity (ne_of_gt hq0) (ne_of_gt hD), abs_div,
    abs_of_pos (mul_pos (sq_pos_of_pos hq0) hD)]
  have hnum : |2*u^2-4*v*q^2-4*v*q-4*u*v|≤(4*B^2+8*B+4)*v := by
    have hq2 : q^2≤B^2 := by nlinarith
    have hvq := mul_le_mul_of_nonneg_left hq2 hv
    have hvq' := mul_le_mul_of_nonneg_left hB hv
    have huv := mul_le_mul_of_nonneg_left hu1 hv
    apply abs_le.mpr
    constructor <;> nlinarith [sq_nonneg u, mul_nonneg hv (sq_nonneg q),
      mul_nonneg hu hv, mul_nonneg (le_of_lt hq0) hv]
  have hq2 : δ^2≤q^2 := by nlinarith
  have hden : δ^3/2≤q^2*(q-u+2*v) := by
    have hh := mul_le_mul hq2 (show δ/2≤q-u+2*v by linarith)
      (by positivity : 0≤δ/2) (sq_nonneg q)
    nlinarith
  have hc : 0≤(4*B^2+8*B+4)*v := by positivity
  apply (div_le_iff₀ (mul_pos (sq_pos_of_pos hq0) hD)).mpr
  apply hnum.trans
  have hh := mul_le_mul_of_nonneg_left hden
    (show 0≤2*(4*B^2+8*B+4)*v/δ^3 by positivity)
  have hid : 2*(4*B^2+8*B+4)*v/δ^3*(δ^3/2) =
      (4*B^2+8*B+4)*v := by field_simp
  rw [hid] at hh
  exact hh

theorem actual_prefactor_exact {a b d : ℕ} (hb : 0<b) :
    let n : ℝ := (a+b+d:ℕ)
    let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
    let u : ℝ := ((a:ℝ)+d)/n
    let v : ℝ := 1/n
    (edgeCount a b d:ℝ)/((edgeCount a b d:ℝ)-n+2) =
      1+(2-4*v)/(q-u+2*v) := by
  dsimp only
  have hn : (0:ℝ)<(a+b+d:ℕ) := by exact_mod_cast (show 0<a+b+d by omega)
  have he := real_edge_count_formula (a:=a) (d:=d) hb
  have hk := cycle_denominator_pos (a:=a) (d:=d) hb
  rw [he] at *
  have hD : (a:ℝ)^2+(d:ℝ)^2-a-d+2≠0 := by nlinarith [hk]
  have hi := mul_inv_cancel₀ hD
  ring_nf at hi
  field_simp [ne_of_gt hn, hD]
  linear_combination hi

#print axioms prefactor_residual_identity
#print axioms prefactor_uniform_bound
#print axioms actual_prefactor_exact
end SumBalaban
