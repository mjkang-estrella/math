import RadialCost
import Mathlib.Algebra.Order.Floor.Ring
namespace SumBalaban
noncomputable def optimalTrial (n : ℕ) : Triple :=
  let k := Nat.floor (c*Real.sqrt n)
  (k,n-2*k,k)
theorem optimal_trial_bounds {n : ℕ} (hn : 4≤n)
    (hlo : 4≤c^2*(n:ℝ)) (hhi : 16*c^2≤(n:ℝ)) :
    admissible n (optimalTrial n) ∧
    c/2≤((optimalTrial n).1:ℝ)/Real.sqrt n ∧
    ((optimalTrial n).1:ℝ)/Real.sqrt n≤c ∧
    |2*(((optimalTrial n).1:ℝ)/Real.sqrt n)^2-radialQ|≤4*c/Real.sqrt n := by
  let k := Nat.floor (c*Real.sqrt n)
  have hn0 : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hs := Real.sqrt_pos.mpr hn0
  have hs2 := Real.sq_sqrt (le_of_lt hn0)
  have hc := c_pos
  have hx0 : 0≤c*Real.sqrt n := by positivity
  have hx2 : (c*Real.sqrt n)^2=c^2*(n:ℝ) := by rw [mul_pow,hs2]
  have hxlo : 2≤c*Real.sqrt n := by nlinarith [sq_nonneg (c*Real.sqrt n-2)]
  have hxhi : c*Real.sqrt n≤(n:ℝ)/4 := by
    have hh := mul_le_mul_of_nonneg_right hhi (le_of_lt hn0)
    nlinarith [sq_nonneg (c*Real.sqrt n-(n:ℝ)/4)]
  have hklo : 1≤k := by
    apply Nat.le_floor
    norm_num
    linarith
  have hkhi : (k:ℝ)≤c*Real.sqrt n := Nat.floor_le hx0
  have hkerr : c*Real.sqrt n<(k:ℝ)+1 := Nat.lt_floor_add_one _
  have hkpath : 2*k+1≤n := by
    have hn4 : (4:ℝ)≤n := by exact_mod_cast hn
    have hh : (2:ℝ)*k+1≤n := by linarith
    exact_mod_cast hh
  have hadm : admissible n (optimalTrial n) := by
    change 0<k ∧ 0<n-2*k ∧ 0<k ∧ k+(n-2*k)+k=n ∧ k≤k
    omega
  let z : ℝ := (k:ℝ)/Real.sqrt n
  have hz0 : 0≤z := by positivity
  have hzhi : z≤c := (div_le_iff₀ hs).mpr hkhi
  have hzlo : c/2≤z := by
    apply (le_div_iff₀ hs).mpr
    nlinarith
  have he : c-z≤1/Real.sqrt n := by
    apply (le_div_iff₀ hs).mpr
    dsimp [z]
    field_simp
    linarith
  have hq0 : radialQ=2*c^2 := by
    unfold radialQ c
    rw [Real.sq_sqrt (le_of_lt (Real.sqrt_pos.mpr Q_pos))]
  have hqhi : 2*z^2≤radialQ := by rw [hq0]; nlinarith
  have hcost : radialQ-2*z^2≤4*c/Real.sqrt n := by
    rw [hq0]
    have hh := mul_le_mul he (show c+z≤2*c by linarith)
      (by positivity : 0≤c+z) (by positivity : 0≤1/Real.sqrt n)
    have hid : (1/Real.sqrt n)*(2*c)=2*c/Real.sqrt n := by ring
    rw [hid] at hh
    calc
      _ = 2*((c-z)*(c+z)) := by ring
      _ ≤ 2*(2*c/Real.sqrt n) := mul_le_mul_of_nonneg_left hh (by norm_num)
      _ = _ := by ring
  refine ⟨hadm,?_,?_,?_⟩
  · exact hzlo
  · exact hzhi
  · change |2*z^2-radialQ|≤_
    rw [abs_of_nonpos (by linarith)]
    linarith

theorem optimal_trial_radial_cost {n : ℕ} (hn : 4≤n)
    (hlo : 4≤c^2*(n:ℝ)) (hhi : 16*c^2≤(n:ℝ)) :
    radialF (2*(((optimalTrial n).1:ℝ)/Real.sqrt n)^2)-radialF radialQ≤
      16*c^2/(c^2*(n:ℝ)) := by
  obtain ⟨_,hl,hu,he⟩ := optimal_trial_bounds hn hlo hhi
  have hn0 : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hs := Real.sqrt_pos.mpr hn0
  have hc := c_pos
  have hh := radial_cost_bound (q:=2*(((optimalTrial n).1:ℝ)/Real.sqrt n)^2)
    (δ:=c^2/2) (L:=4*c) (e:=1/Real.sqrt n)
    (by positivity : 0<c^2/2) (by nlinarith [c_pos])
    (by positivity) (by positivity) (by simpa only [mul_one_div] using he)
  have hid : (4*c)^2*(1/Real.sqrt n)^2/(2*(c^2/2))=16*c^2/(c^2*(n:ℝ)) := by
    rw [div_pow,Real.sq_sqrt (le_of_lt hn0)]
    field_simp
    ring
  rw [hid] at hh
  exact hh
#print axioms optimal_trial_bounds
#print axioms optimal_trial_radial_cost
end SumBalaban
