import Prefactor
namespace SumBalaban
theorem actual_prefactor_first_correction {a b d : ℕ} {B δ : ℝ}
    (hb : 0<b) (_hB : 0≤B) (hδ : 0<δ)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hqlo : δ*(a+b+d:ℕ)≤(a:ℝ)^2+(d:ℝ)^2)
    (hn : 8*B≤δ^2*(a+b+d:ℕ)) :
    let n : ℝ := (a+b+d:ℕ)
    let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
    let u : ℝ := ((a:ℝ)+d)/n
    |(edgeCount a b d:ℝ)/((edgeCount a b d:ℝ)-n+2)-
      (1+2/q+2*u/q^2)|≤2*(4*B^2+8*B+4)/δ^3/n := by
  dsimp only
  let n : ℝ := (a+b+d:ℕ)
  let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
  let u : ℝ := ((a:ℝ)+d)/n
  have hn0 : 0<n := by dsimp [n]; exact_mod_cast (show 0<a+b+d by omega)
  have hS : ((a:ℝ)+d)^2≤2*B*n := by
    change (a:ℝ)^2+(d:ℝ)^2≤B*n at hq
    nlinarith [sq_nonneg ((a:ℝ)-d)]
  have hSl : (a:ℝ)+d≤δ*n/2 := by
    change 8*B≤δ^2*n at hn
    have hh := mul_le_mul_of_nonneg_right hn (le_of_lt hn0)
    have hdn : 0<δ*n := mul_pos hδ hn0
    nlinarith [sq_nonneg (((a:ℝ)+d)-δ*n/2)]
  have hq' : δ≤q := (le_div_iff₀ hn0).mpr hqlo
  have hqB : q≤B := (div_le_iff₀ hn0).mpr hq
  have hu1 : u≤1 := by
    apply (div_le_one hn0).mpr
    dsimp [n]
    push_cast
    linarith [show (0:ℝ)≤b by positivity]
  have huδ : u≤δ/2 := (div_le_iff₀ hn0).mpr (by linarith)
  have hu2 : u^2≤2*B*(1/n) := by
    dsimp [u]
    rw [div_pow]
    apply (div_le_iff₀ (sq_pos_of_pos hn0)).mpr
    field_simp
    nlinarith
  have he := prefactor_uniform_bound hδ hq' hqB (by dsimp [u]; positivity) hu1 huδ
    (by positivity : 0≤1/n) hu2
  have hid := actual_prefactor_exact (a:=a) (d:=d) hb
  change (edgeCount a b d:ℝ)/((edgeCount a b d:ℝ)-n+2)=
    1+(2-4*(1/n))/(q-u+2*(1/n)) at hid
  change |(edgeCount a b d:ℝ)/((edgeCount a b d:ℝ)-n+2)-(1+2/q+2*u/q^2)|≤_
  rw [hid]
  convert he using 1; ring
#print axioms actual_prefactor_first_correction
end SumBalaban
