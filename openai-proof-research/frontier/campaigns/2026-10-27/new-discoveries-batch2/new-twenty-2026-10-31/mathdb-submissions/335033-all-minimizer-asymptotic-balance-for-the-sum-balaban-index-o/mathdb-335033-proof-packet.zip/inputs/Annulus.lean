import Coercivity
namespace SumBalaban

theorem clique_squares_le_twice_edges {a b d : ℕ} (hb : 0<b) :
    (a:ℝ)^2+(d:ℝ)^2 ≤ 2*(edgeCount a b d : ℝ) := by
  have h := twice_edge_count (a:=a) (d:=d) hb
  have hr : (2:ℝ)*edgeCount a b d = (a:ℝ)*a+(d:ℝ)*d+a+d+2*(b-1:ℕ) := by exact_mod_cast h
  have hz : (0:ℝ)≤(b-1:ℕ) := by positivity
  nlinarith

theorem sublevel_clique_squares_upper {a b d : ℕ} {M : ℝ} (hb : 0<b)
    (hn : 2≤a+b+d) (hM : SJ a b d ≤ M) :
    (a:ℝ)^2+(d:ℝ)^2 ≤ 4*(a+b+d : ℕ)*M := by
  have hm := edgeCount_le_of_SJ_le hb hn hM
  have hq := clique_squares_le_twice_edges (a:=a) (d:=d) hb
  linarith

theorem sublevel_cycle_lower {a b d : ℕ} {M : ℝ} (hb : 0<b)
    (hn : 4≤a+b+d) (hM : SJ a b d ≤ M) :
    ((a+b+d : ℕ):ℝ) ≤ 8*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2)*M := by
  have ho := order_le_edges_add_one (a:=a) (d:=d) hb
  have hn' : (4:ℝ)≤(a+b+d : ℕ) := by exact_mod_cast hn
  have hpos : (0:ℝ)<(a+b+d : ℕ) := by linarith
  have hmpos : (0:ℝ)<(edgeCount a b d : ℝ) := by linarith
  have hk := cycle_denominator_pos (a:=a) (d:=d) hb
  have hl := SJ_scaled_lower (a:=a) (d:=d) hb
  have hprod := mul_le_mul_of_nonneg_left hM
    (show 0≤(2*(a+b+d : ℕ):ℝ)*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2) by positivity)
  have hsquare : ((a+b+d : ℕ):ℝ)^2 ≤ 4*(edgeCount a b d : ℝ)^2 := by nlinarith
  have hbound : ((a+b+d : ℕ):ℝ)*((a+b+d : ℕ):ℝ) ≤
      ((a+b+d : ℕ):ℝ)*(8*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2)*M) := by nlinarith
  exact (mul_le_mul_iff_right₀ hpos).mp (by simpa only [mul_comm] using hbound)

theorem sublevel_clique_squares_lower {a b d : ℕ} {M : ℝ} (hb : 0<b)
    (hn : 4≤a+b+d) (hlarge : 16*M≤((a+b+d : ℕ):ℝ)) (hM0 : 0≤M)
    (hM : SJ a b d ≤ M) :
    ((a+b+d : ℕ):ℝ) ≤ 8*M*((a:ℝ)^2+(d:ℝ)^2) := by
  have hl := sublevel_cycle_lower hb hn hM
  have he := real_edge_count_formula (a:=a) (d:=d) hb
  have hs : (0:ℝ)≤M*((a:ℝ)+(d:ℝ)) := mul_nonneg hM0 (by positivity)
  nlinarith

#print axioms sublevel_clique_squares_upper
#print axioms sublevel_cycle_lower
#print axioms sublevel_clique_squares_lower
end SumBalaban
