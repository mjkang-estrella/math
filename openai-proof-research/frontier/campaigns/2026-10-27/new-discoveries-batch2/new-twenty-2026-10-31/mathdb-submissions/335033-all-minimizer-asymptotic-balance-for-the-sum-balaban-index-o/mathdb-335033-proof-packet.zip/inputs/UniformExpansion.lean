import MixedProduct
namespace SumBalaban
open scoped BigOperators
noncomputable def edgeErrorK (B : ℝ) : ℝ := (B+1)*(10*B+12)+21*B+45
noncomputable def prefactorErrorK (B δ : ℝ) : ℝ := 2*(4*B^2+8*B+4)/δ^3
noncomputable def combinedErrorK (B δ : ℝ) : ℝ :=
  prefactorErrorK B δ*(B+Q+edgeErrorK B+1)+
  (1+2/δ+2/δ^2)*edgeErrorK B+2*B*(B+1)/δ^2

theorem actual_SJ_rational_expansion {a b d : ℕ} {B δ : ℝ}
    (ha : 0<a) (hb : 0<b) (hd : 0<d) (hB : 0≤B) (hδ : 0<δ)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hql : δ*(a+b+d:ℕ)≤(a:ℝ)^2+(d:ℝ)^2)
    (hn : 16*(2*B+4)≤((a+b+d:ℕ):ℝ))
    (hnδ : 8*B≤δ^2*(a+b+d:ℕ)) :
    let n : ℝ := (a+b+d:ℕ)
    let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
    let u : ℝ := ((a:ℝ)+d)/n
    let t : ℝ := ((a:ℝ)^3+(d:ℝ)^3)/n^2
    |SJ a b d-((1+2/q)*(q/2+Q)+(1+2/q)*(t-u)/2+
      (2*u/q^2)*(q/2+Q))|≤combinedErrorK B δ/n := by
  dsimp only
  let n : ℝ := (a+b+d:ℕ)
  let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
  let u : ℝ := ((a:ℝ)+d)/n
  let t : ℝ := ((a:ℝ)^3+(d:ℝ)^3)/n^2
  let P : ℝ := (edgeCount a b d:ℝ)/((edgeCount a b d:ℝ)-n+2)
  let E : ℝ := ∑ e ∈ (graph a b d).edgeFinset, edgeWeight e
  let P₀ : ℝ := 1+2/q+2*u/q^2
  let A : ℝ := q/2+Q+(t-u)/2
  let T : ℝ := (1+2/q)*(q/2+Q)+(1+2/q)*(t-u)/2+(2*u/q^2)*(q/2+Q)
  have hn0 : 0<n := by dsimp [n]; exact_mod_cast (show 0<a+b+d by omega)
  have hn1 : 1≤n := by change 1≤((a+b+d:ℕ):ℝ); nlinarith
  obtain ⟨hqlo,hqB,hu0,hu1,ht0,htu,hu2⟩ := actual_normalized_bounds hb hB hq hql
  change δ≤q at hqlo
  change q≤B at hqB
  change 0≤u at hu0
  change u≤1 at hu1
  change 0≤t at ht0
  change t≤B*u at htu
  have hq0 : 0<q := lt_of_lt_of_le hδ hqlo
  have hKE : 0≤edgeErrorK B := by unfold edgeErrorK; positivity
  have hKP : 0≤prefactorErrorK B δ := by unfold prefactorErrorK; positivity
  have hP : |P-P₀|≤prefactorErrorK B δ/n :=
    actual_prefactor_first_correction hb hB hδ hq hql hnδ
  have he := actual_edge_first_correction ha hb hd hB hq hn
  have hA : A=((a:ℝ)^2+(d:ℝ)^2)/(2*n)+Q+
      ((a:ℝ)^3+(d:ℝ)^3)/(2*n^2)-((a:ℝ)+d)/(2*n) := by dsimp [A,q,t,u]; ring
  have hE : |E-A|≤edgeErrorK B/n := by
    rw [hA]
    exact he
  have hE0 : 0≤E := by
    dsimp [E]
    apply Finset.sum_nonneg
    intro e he
    cases e using Sym2.inductionOn with
    | _ x y => rw [edgeWeight_formula]; positivity
  have htB : t≤B := by nlinarith
  have hAb : A≤B+Q := by dsimp [A]; linarith
  have hker : edgeErrorK B/n≤edgeErrorK B := by
    apply (div_le_iff₀ hn0).mpr
    nlinarith
  have hEb : |E|≤B+Q+edgeErrorK B+1 := by
    rw [abs_of_nonneg hE0]
    have hh := (abs_le.mp hE).2
    linarith
  have hi : 1/q≤1/δ := one_div_le_one_div_of_le hδ hqlo
  have hi0 : 0≤1/q := by positivity
  have hδi0 : 0≤1/δ := by positivity
  have hi2 : (1/q)^2≤(1/δ)^2 := by nlinarith only [hi,hi0,hδi0]
  have hui2 := mul_le_mul hu1 hi2 (sq_nonneg (1/q)) (by norm_num : (0:ℝ)≤1)
  have hP₀id : P₀=1+2*(1/q)+2*u*(1/q)^2 := by dsimp [P₀]; ring
  have hLb : |P₀|≤1+2/δ+2/δ^2 := by
    rw [hP₀id,abs_of_nonneg (by positivity)]
    have hid : 1+2/δ+2/δ^2=1+2*(1/δ)+2*(1/δ)^2 := by ring
    rw [hid]
    linarith only [hi,hui2]
  have hcrossid : P₀*A-T=u*(t-u)/q^2 := by dsimp [P₀,A,T]; ring
  have hcross : |P₀*A-T|≤(2*B*(B+1)/δ^2)/n := by
    rw [hcrossid]
    have hh := actual_mixed_remainder hb hB hδ hq hql
    convert hh using 1; ring
  have hh := product_remainder_bound hn0 hKP hKE hP hE hEb hLb hcross
  change |SJ a b d-T|≤combinedErrorK B δ/n
  exact hh
#print axioms actual_SJ_rational_expansion
end SumBalaban
