import SourceEndpoint
open Filter
open scoped BigOperators
namespace ReviewIndependent
theorem all_choices_expanded :
  ∀ f : ℕ → ℕ × ℕ × ℕ,
    (∀ᶠ n in atTop, (0<(f n).1 ∧ 0<(f n).2.1 ∧ 0<(f n).2.2 ∧ (f n).1+(f n).2.1+(f n).2.2=n ∧ (f n).1≤(f n).2.2) ∧
      ∀ s : ℕ × ℕ × ℕ, (0<s.1 ∧ 0<s.2.1 ∧ 0<s.2.2 ∧ s.1+s.2.1+s.2.2=n ∧ s.1≤s.2.2) →
        ((SumBalaban.edgeCount (f n).1 (f n).2.1 (f n).2.2 : ℝ) / ((SumBalaban.edgeCount (f n).1 (f n).2.1 (f n).2.2 : ℝ) - ((f n).1+(f n).2.1+(f n).2.2 : ℕ) + 2) * ∑ e ∈ (SumBalaban.graph (f n).1 (f n).2.1 (f n).2.2).edgeFinset, SumBalaban.edgeWeight e) ≤ ((SumBalaban.edgeCount s.1 s.2.1 s.2.2 : ℝ) / ((SumBalaban.edgeCount s.1 s.2.1 s.2.2 : ℝ) - (s.1+s.2.1+s.2.2 : ℕ) + 2) * ∑ e ∈ (SumBalaban.graph s.1 s.2.1 s.2.2).edgeFinset, SumBalaban.edgeWeight e)) →
    Tendsto (fun n => ((f n).1 : ℝ) / Real.sqrt n) atTop
      (nhds (Real.sqrt (Real.sqrt (Real.sqrt 2 * Real.log (1+Real.sqrt 2))))) ∧
    Tendsto (fun n => ((f n).2.2 : ℝ) / Real.sqrt n) atTop
      (nhds (Real.sqrt (Real.sqrt (Real.sqrt 2 * Real.log (1+Real.sqrt 2))))) ∧
    Tendsto (fun n => ((f n).2.1 : ℝ) / n) atTop (nhds 1) := by
  simpa only [SumBalaban.SourceTarget, SumBalaban.minimizes, SumBalaban.admissible,
    SumBalaban.objective, SumBalaban.SJ, SumBalaban.c, SumBalaban.Q] using SumBalaban.source_target
#print all_choices_expanded
#print axioms all_choices_expanded
end ReviewIndependent
#print SumBalaban.graph
#print SumBalaban.Adj
#print SumBalaban.transmission
#print SumBalaban.edgeWeight
#print SumBalaban.edgeCount
#print SumBalaban.SourceTarget
#print axioms SumBalaban.Q_pos
#print axioms SumBalaban.SJ_nonneg
#print axioms SumBalaban.SJ_scaled_lower
#print axioms SumBalaban.SJ_upper_of_path
#print axioms SumBalaban.actual_SJ_rational_expansion
#print axioms SumBalaban.actual_clique_arguments_error
#print axioms SumBalaban.actual_clique_four_corrections
#print axioms SumBalaban.actual_clique_sum_first_correction
#print axioms SumBalaban.actual_edge_first_correction
#print axioms SumBalaban.actual_edge_sum_lower
#print axioms SumBalaban.actual_edge_sum_split
#print axioms SumBalaban.actual_mixed_remainder
#print axioms SumBalaban.actual_normalized_bounds
#print axioms SumBalaban.actual_path_edge_polynomial
#print axioms SumBalaban.actual_path_first_correction
#print axioms SumBalaban.actual_path_kernel_error
#print axioms SumBalaban.actual_path_pair_error
#print axioms SumBalaban.actual_path_pair_lower
#print axioms SumBalaban.actual_path_sum_error
#print axioms SumBalaban.actual_prefactor_exact
#print axioms SumBalaban.actual_prefactor_first_correction
#print axioms SumBalaban.actual_reference_rectangle
#print axioms SumBalaban.angular_cubic
#print axioms SumBalaban.balanced_trial_bound
#print axioms SumBalaban.c_pos
#print axioms SumBalaban.clique_block
#print axioms SumBalaban.clique_squares_le_twice_edges
#print axioms SumBalaban.clique_sum
#print axioms SumBalaban.coarseTrial_admissible
#print axioms SumBalaban.coarseTrial_bound
#print axioms SumBalaban.common_uniform_expansion
#print axioms SumBalaban.comparison_algebra
#print axioms SumBalaban.connected
#print axioms SumBalaban.coordinate_dist
#print axioms SumBalaban.coordinate_step
#print axioms SumBalaban.coordinate_walk
#print axioms SumBalaban.correction_at_optimal_radius
#print axioms SumBalaban.correction_limit
#print axioms SumBalaban.cycle_denominator_pos
#print axioms SumBalaban.dart_sum_eq_twice_edge_sum
#print axioms SumBalaban.degree_as_sum
#print axioms SumBalaban.distance_le_order
#print axioms SumBalaban.edgeCount_le_of_SJ_le
#print axioms SumBalaban.edgeWeight_formula
#print axioms SumBalaban.edgeWeight_lower
#print axioms SumBalaban.edgeWeight_upper
#print axioms SumBalaban.edge_class_lt_five
#print axioms SumBalaban.edge_count_formula
#print axioms SumBalaban.every_minimizer_annulus
#print axioms SumBalaban.every_minimizer_pair_limit
#print axioms SumBalaban.every_minimizer_radial_bounds
#print axioms SumBalaban.every_minimizer_radial_limit
#print axioms SumBalaban.five_sum_identity
#print axioms SumBalaban.general_uniform_expansion
#print axioms SumBalaban.inverse_sqrt_error
#print axioms SumBalaban.inverse_sqrt_first_correction
#print axioms SumBalaban.inverse_sqrt_limit
#print axioms SumBalaban.kernel_symm
#print axioms SumBalaban.leftW_polynomial
#print axioms SumBalaban.left_attachment_argument
#print axioms SumBalaban.left_degree
#print axioms SumBalaban.left_left_dist
#print axioms SumBalaban.left_path_dist
#print axioms SumBalaban.left_right_dist
#print axioms SumBalaban.left_transmission_sum
#print axioms SumBalaban.mem_candidates
#print axioms SumBalaban.minimizer_bound
#print axioms SumBalaban.minimizer_eventual_comparison
#print axioms SumBalaban.minimizer_eventual_expansion
#print axioms SumBalaban.minimizing_cluster_balanced
#print axioms SumBalaban.minimum_attained
#print axioms SumBalaban.mixed_remainder_bound
#print axioms SumBalaban.natural_cycle_formula
#print axioms SumBalaban.normalized_product_identity
#print axioms SumBalaban.normalized_squares
#print axioms SumBalaban.optimal_cluster_forced_balanced
#print axioms SumBalaban.optimal_trial_bounds
#print axioms SumBalaban.optimal_trial_eventually
#print axioms SumBalaban.optimal_trial_radial_cost
#print axioms SumBalaban.order_le_edges_add_one
#print axioms SumBalaban.ordered_sum_eq_dart_sum
#print axioms SumBalaban.pathForward_single
#print axioms SumBalaban.path_block
#print axioms SumBalaban.path_degree_sum
#print axioms SumBalaban.path_dist
#print axioms SumBalaban.path_dist_le
#print axioms SumBalaban.path_dist_of_le
#print axioms SumBalaban.path_neighbor_count
#print axioms SumBalaban.path_reachable
#print axioms SumBalaban.path_reference_lower
#print axioms SumBalaban.path_right_dist
#print axioms SumBalaban.path_transmission_sum
#print axioms SumBalaban.polynomial_residual_bounds
#print axioms SumBalaban.preconnected
#print axioms SumBalaban.prefactor_residual_identity
#print axioms SumBalaban.prefactor_uniform_bound
#print axioms SumBalaban.product_remainder_bound
#print axioms SumBalaban.radialQ_pos
#print axioms SumBalaban.radial_cost_bound
#print axioms SumBalaban.radial_excess
#print axioms SumBalaban.radial_excess_nonneg
#print axioms SumBalaban.radial_limit
#print axioms SumBalaban.rational_correction_as_normalized
#print axioms SumBalaban.reachable_from_start
#print axioms SumBalaban.real_edge_count_formula
#print axioms SumBalaban.referenceF_continuous
#print axioms SumBalaban.referenceF_lipschitz
#print axioms SumBalaban.referenceF_one
#print axioms SumBalaban.referenceF_zero
#print axioms SumBalaban.reference_cell_error
#print axioms SumBalaban.reference_integral_value
#print axioms SumBalaban.reference_left_end_error
#print axioms SumBalaban.reference_moving_interval
#print axioms SumBalaban.reference_phi_lower
#print axioms SumBalaban.reference_primitive_derivative
#print axioms SumBalaban.reference_rectangle_error
#print axioms SumBalaban.reference_right_end_error
#print axioms SumBalaban.reference_scaled
#print axioms SumBalaban.reverse_path_sum
#print axioms SumBalaban.rightW_polynomial
#print axioms SumBalaban.right_attachment_argument
#print axioms SumBalaban.right_degree
#print axioms SumBalaban.right_right_dist
#print axioms SumBalaban.right_transmission_sum
#print axioms SumBalaban.shifted_actual_transmission
#print axioms SumBalaban.source_c_fourth
#print axioms SumBalaban.source_target
#print axioms SumBalaban.sublevel_clique_squares_lower
#print axioms SumBalaban.sublevel_clique_squares_upper
#print axioms SumBalaban.sublevel_cycle_lower
#print axioms SumBalaban.sum_path_degrees
#print axioms SumBalaban.transmission_ge_path_sq
#print axioms SumBalaban.transmission_le_order_sq
#print axioms SumBalaban.transmission_pos_of_adj
#print axioms SumBalaban.trial_eventual_expansion
#print axioms SumBalaban.trial_normalized_limit
#print axioms SumBalaban.twice_edge_count
#print axioms SumBalaban.twice_left_transmission
#print axioms SumBalaban.twice_path_distance_sum
#print axioms SumBalaban.twice_path_transmission
#print axioms SumBalaban.twice_right_transmission
#print axioms SumBalaban.twice_sum_path_orders
#print axioms SumBalaban.vertex_count
#print axioms SumBalaban.weight_as_kernel
#print axioms SumBalaban.weighted_two_error
