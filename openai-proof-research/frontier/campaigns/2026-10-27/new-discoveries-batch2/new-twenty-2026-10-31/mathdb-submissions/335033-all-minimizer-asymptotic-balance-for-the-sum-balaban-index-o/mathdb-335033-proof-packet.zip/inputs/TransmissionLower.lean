import PathSumError
namespace SumBalaban

theorem transmission_ge_path_sq {a b d : ℕ} (hb : 2≤b) (u : Vertex a b d) :
    (b:ℝ)^2/8 ≤ (transmission u : ℝ) := by
  have hb0 : 0<b := by omega
  have hb' : (2:ℝ)≤b := by exact_mod_cast hb
  rcases u with u | u
  · have h := twice_left_transmission (a:=a) (d:=d) hb0 u
    have hr : (2:ℝ)*transmission (left u : Vertex a b d) =
        2*(a-1:ℕ)+(b:ℝ)*(b+1)+2*d*(b+1) := by exact_mod_cast h
    have hm : (0:ℝ)≤(d:ℝ)*(b+1) := by positivity
    have hz : (0:ℝ)≤(a-1:ℕ) := by positivity
    nlinarith
  · rcases u with i | u
    · have h := twice_path_transmission (a:=a) (d:=d) hb0 i
      have hr : (2:ℝ)*transmission (path i : Vertex a b d) =
        (i.val:ℝ)*(i.val+1)+(b-1-i.val:ℕ)*(b-i.val:ℕ)+
        2*a*(i.val+1)+2*d*(b-i.val:ℕ) := by exact_mod_cast h
      have h1 : ((b-i.val:ℕ):ℝ)=(b:ℝ)-i.val := by rw [Nat.cast_sub (by have := i.isLt; omega)]
      have h2 : ((b-1-i.val:ℕ):ℝ)=(b:ℝ)-1-i.val := by
        rw [Nat.cast_sub (by have := i.isLt; omega),Nat.cast_sub (by omega : 1≤b)]
        norm_num
      rw [h1,h2] at hr
      have hm : (0:ℝ)≤(d:ℝ)*((b:ℝ)-i.val) := by
        have hi : (i.val:ℝ)≤b := by exact_mod_cast (show i.val≤b by have := i.isLt; omega)
        exact mul_nonneg (by positivity) (by linarith)
      have hm' : (0:ℝ)≤(a:ℝ)*((i.val:ℝ)+1) := by positivity
      nlinarith [sq_nonneg (2*(i.val:ℝ)-((b:ℝ)-1))]
    · have h := twice_right_transmission (a:=a) (d:=d) hb0 u
      have hr : (2:ℝ)*transmission (right u : Vertex a b d) =
          2*(d-1:ℕ)+(b:ℝ)*(b+1)+2*a*(b+1) := by exact_mod_cast h
      have hm : (0:ℝ)≤(a:ℝ)*(b+1) := by positivity
      have hz : (0:ℝ)≤(d-1:ℕ) := by positivity
      nlinarith

theorem edgeWeight_upper {a b d : ℕ} (hb : 2≤b) (e : Sym2 (Vertex a b d)) :
    edgeWeight e ≤ 2/(b:ℝ) := by
  induction e using Sym2.inductionOn with
  | _ u v =>
    have hu := transmission_ge_path_sq hb u
    have hv := transmission_ge_path_sq hb v
    have hb' : (0:ℝ)<b := by exact_mod_cast (show 0<b by omega)
    have hs := Real.sq_sqrt (show (0:ℝ)≤(transmission u : ℝ)+(transmission v : ℝ) by positivity)
    have hlow : (b:ℝ)/2≤Real.sqrt ((transmission u : ℝ)+(transmission v : ℝ)) := by
      nlinarith [Real.sqrt_nonneg ((transmission u : ℝ)+(transmission v : ℝ))]
    rw [edgeWeight_formula]
    have h := one_div_le_one_div_of_le (show (0:ℝ)<(b:ℝ)/2 by positivity) hlow
    convert h using 1; field_simp

#print axioms transmission_ge_path_sq
#print axioms edgeWeight_upper
end SumBalaban
