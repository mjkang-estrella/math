import Mathlib.Combinatorics.SimpleGraph.Metric
import Mathlib.Data.Fintype.Sum

namespace SumBalaban
abbrev Vertex (a b d : ℕ) := Fin a ⊕ (Fin b ⊕ Fin d)
abbrev left {a b d : ℕ} (i : Fin a) : Vertex a b d := Sum.inl i
abbrev path {a b d : ℕ} (i : Fin b) : Vertex a b d := Sum.inr (Sum.inl i)
abbrev right {a b d : ℕ} (i : Fin d) : Vertex a b d := Sum.inr (Sum.inr i)

def Adj {a b d : ℕ} : Vertex a b d → Vertex a b d → Prop
  | .inl i, .inl j => i ≠ j
  | .inl _, .inr (.inl j) => j.val = 0
  | .inr (.inl i), .inl _ => i.val = 0
  | .inr (.inl i), .inr (.inl j) => i.val + 1 = j.val ∨ j.val + 1 = i.val
  | .inr (.inl i), .inr (.inr _) => i.val + 1 = b
  | .inr (.inr _), .inr (.inl j) => j.val + 1 = b
  | .inr (.inr i), .inr (.inr j) => i ≠ j
  | _, _ => False

def graph (a b d : ℕ) : SimpleGraph (Vertex a b d) where
  Adj := Adj
  symm := by
    constructor
    intro u v h
    rcases u with i | i <;> rcases v with j | j
    · exact Ne.symm h
    · rcases j with j | j
      · exact h
      · exact False.elim h
    · rcases i with i | i
      · exact h
      · exact False.elim h
    · rcases i with i | i <;> rcases j with j | j
      · simpa only [Adj, or_comm] using h
      · exact h
      · exact h
      · exact Ne.symm h
  loopless := by
    constructor
    intro u
    rcases u with i | i
    · simp [Adj]
    · rcases i with i | i
      · simp [Adj]
      · simp [Adj]

instance (a b d : ℕ) : DecidableRel (graph a b d).Adj := by
  intro u v
  change Decidable (Adj u v)
  unfold Adj
  split <;> infer_instance

theorem path_reachable {a b d : ℕ} (hb : 0 < b) (i : ℕ) (hi : i < b) :
    (graph a b d).Reachable (path ⟨0,hb⟩) (path ⟨i,hi⟩) := by
  induction i with
  | zero => exact .refl _
  | succ i ih =>
    exact (ih (by omega)).trans (SimpleGraph.Adj.reachable (by
      change @Adj a b d (path ⟨i,by omega⟩) (path ⟨i+1,hi⟩)
      simp [Adj]))

theorem reachable_from_start {a b d : ℕ} (hb : 0 < b) (u : Vertex a b d) :
    (graph a b d).Reachable (path ⟨0,hb⟩) u := by
  rcases u with i | i
  · exact SimpleGraph.Adj.reachable (by change @Adj a b d (path ⟨0,hb⟩) (left i); rfl)
  · rcases i with i | i
    · exact path_reachable hb i.val i.isLt
    · exact (path_reachable (a:=a) (d:=d) hb (b-1) (by omega)).trans
        (SimpleGraph.Adj.reachable (by change @Adj a b d (path ⟨b-1,by omega⟩) (right i); simp [Adj]; omega))

theorem preconnected {a b d : ℕ} (hb : 0 < b) : (graph a b d).Preconnected := by
  intro u v
  exact (reachable_from_start hb u).symm.trans (reachable_from_start hb v)

#print axioms graph
#print axioms path_reachable
#print axioms preconnected
#eval Lean.versionString
end SumBalaban
