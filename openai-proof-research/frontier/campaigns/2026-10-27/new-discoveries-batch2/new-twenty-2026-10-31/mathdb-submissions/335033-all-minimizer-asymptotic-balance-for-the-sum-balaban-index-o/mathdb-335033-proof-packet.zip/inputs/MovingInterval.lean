import ReferenceRectangle
import ReferenceValue
namespace SumBalaban
@[simp] theorem referenceF_zero : referenceF 0=1 := by norm_num [referenceF]
@[simp] theorem referenceF_one : referenceF 1=1 := by norm_num [referenceF]

theorem reference_left_end_error {h : ℝ} (hh : 0≤h) (hh1 : h≤1) :
    |(∫ u in (0:ℝ)..h, referenceF u)-h|≤8*h^2 := by
  simpa using reference_cell_error (h:=0) (t:=h) (by norm_num) hh (by simpa using hh1)

theorem reference_right_end_error {r : ℝ} (hr : 0≤r) (hr1 : r≤1) :
    |(∫ u in 1-r..(1:ℝ), referenceF u)-r|≤8*r^2 := by
  have hint : IntervalIntegrable referenceF MeasureTheory.volume (1-r) 1 :=
    referenceF_continuous.intervalIntegrable _ _
  have hc : IntervalIntegrable (fun _ : ℝ => (1:ℝ)) MeasureTheory.volume (1-r) 1 :=
    intervalIntegrable_const
  have he := intervalIntegral.norm_integral_le_of_norm_le_const
    (a:=1-r) (b:=1) (f:=fun u => referenceF u-1) (C:=8*r) ?_
  · rw [intervalIntegral.integral_sub hint hc] at he
    simpa [Real.norm_eq_abs,abs_of_nonneg hr,pow_two,mul_assoc] using he
  · intro u hu
    rw [Set.uIoc_of_le (by linarith : 1-r≤1)] at hu
    rw [Real.norm_eq_abs]
    have hh := referenceF_lipschitz (by linarith [hu.1] : 0≤u) hu.2
      (by norm_num : (0:ℝ)≤1) (by norm_num : (1:ℝ)≤1)
    rw [referenceF_one, abs_of_nonpos (by linarith [hu.2] : u-1≤0)] at hh
    linarith [hu.1]

theorem reference_moving_interval {h r : ℝ} (hh : 0≤h) (hr : 0≤r)
    (hhr : h+r≤1) :
    |(∫ u in h..1-r, referenceF u)-(Q-h-r)|≤8*(h^2+r^2) := by
  have hl := reference_left_end_error hh (by linarith : h≤1)
  have hr' := reference_right_end_error hr (by linarith : r≤1)
  have h1 := intervalIntegral.integral_add_adjacent_intervals
    (referenceF_continuous.intervalIntegrable (μ:=MeasureTheory.volume) 0 h)
    (referenceF_continuous.intervalIntegrable (μ:=MeasureTheory.volume) h (1-r))
  have h2 := intervalIntegral.integral_add_adjacent_intervals
    (referenceF_continuous.intervalIntegrable (μ:=MeasureTheory.volume) 0 (1-r))
    (referenceF_continuous.intervalIntegrable (μ:=MeasureTheory.volume) (1-r) 1)
  rw [reference_integral_value] at h2
  have he : (∫ u in h..1-r, referenceF u)-(Q-h-r) =
      -((∫ u in (0:ℝ)..h, referenceF u)-h)-
      ((∫ u in 1-r..(1:ℝ), referenceF u)-r) := by linarith
  rw [he]
  have hab := abs_sub_le (-((∫ u in (0:ℝ)..h, referenceF u)-h)) 0
    ((∫ u in 1-r..(1:ℝ), referenceF u)-r)
  simp only [sub_zero, zero_sub, abs_neg] at hab
  nlinarith
#print axioms reference_moving_interval
end SumBalaban
