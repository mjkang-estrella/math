import ReferenceIntegral
namespace SumBalaban
open scoped BigOperators
theorem reference_rectangle_error (h t : ℝ) (N : ℕ)
    (hh : 0≤h) (ht : 0≤t) (hN : h+(N:ℝ)*t≤1) :
    |(∑ i ∈ Finset.range N, t*referenceF (h+(i:ℝ)*t))-
      (∫ u in h..h+(N:ℝ)*t, referenceF u)|≤8*(N:ℝ)*t^2 := by
  have hs := intervalIntegral.sum_integral_adjacent_intervals
    (a:=fun i : ℕ => h+(i:ℝ)*t) (n:=N)
    (f:=referenceF) (μ:=MeasureTheory.volume)
    (fun k _ => referenceF_continuous.intervalIntegrable _ _)
  simp only [Nat.cast_zero, zero_mul, add_zero] at hs
  have hi : ∀ i ∈ Finset.range N,
      |t*referenceF (h+(i:ℝ)*t)-
        (∫ u in h+(i:ℝ)*t..h+((i+1:ℕ):ℝ)*t, referenceF u)|≤8*t^2 := by
    intro i hi
    have hiN : ((i+1:ℕ):ℝ)≤N := by exact_mod_cast (Finset.mem_range.mp hi)
    have he := reference_cell_error (h:=h+(i:ℝ)*t) (t:=t)
      (by positivity) ht (by
        have := mul_le_mul_of_nonneg_right hiN ht
        push_cast at *
        linarith)
    rw [abs_sub_comm]
    convert he using 1; push_cast; congr 2; ring
  calc
    _ = |∑ i ∈ Finset.range N,
        (t*referenceF (h+(i:ℝ)*t)-
        (∫ u in h+(i:ℝ)*t..h+((i+1:ℕ):ℝ)*t, referenceF u))| := by
      rw [Finset.sum_sub_distrib, hs]
    _ ≤ ∑ i ∈ Finset.range N,
        |t*referenceF (h+(i:ℝ)*t)-
        (∫ u in h+(i:ℝ)*t..h+((i+1:ℕ):ℝ)*t, referenceF u)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _i ∈ Finset.range N, 8*t^2 := Finset.sum_le_sum hi
    _ = _ := by simp; ring
#print axioms reference_rectangle_error
end SumBalaban
