import FiveSums
namespace SumBalaban
open scoped BigOperators

theorem weight_as_kernel {a b d : ℕ} (u v : Vertex a b d) :
    edgeWeight s(u,v) = kernel (transmission u) (transmission v) := rfl

theorem five_sum_identity {a b d : ℕ} (hb : 0<b) :
    (∑ e ∈ (graph a b d).edgeFinset, edgeWeight e) =
      (a:ℝ)*(a-1:ℕ)/2*kernel (leftW a b d) (leftW a b d) +
      (a:ℝ)*kernel (leftW a b d) (transmission (path ⟨0,hb⟩ : Vertex a b d)) +
      pathForward a b d +
      (d:ℝ)*kernel (rightW a b d) (transmission (path ⟨b-1,by omega⟩ : Vertex a b d)) +
      (d:ℝ)*(d-1:ℕ)/2*kernel (rightW a b d) (rightW a b d) := by
  classical
  have hl (u : Fin a) : transmission (left u : Vertex a b d) = leftW a b d := left_transmission_sum hb u
  have hr (u : Fin d) : transmission (right u : Vertex a b d) = rightW a b d := right_transmission_sum hb u
  have hzero (i : Fin b) : i.val=0 ↔ i=⟨0,hb⟩ := by
    constructor
    · exact fun h => Fin.ext h
    · intro h; subst i; rfl
  have hlast (i : Fin b) : i.val+1=b ↔ i=⟨b-1,by omega⟩ := by
    constructor
    · intro h; apply Fin.ext; dsimp only; omega
    · intro h; subst i; dsimp only; omega
  have hp : (∑ i : Fin b, ∑ j : Fin b,
      if i.val+1=j.val ∨ j.val+1=i.val then
        kernel (transmission (path i : Vertex a b d)) (transmission (path j : Vertex a b d)) else 0) =
      2*pathForward a b d := by
    simpa only [weight_as_kernel] using path_block a b d
  have hpoint (i j : Fin b) :
      (if (graph a b d).Adj (path i) (path j) then edgeWeight s((path i : Vertex a b d),path j) else 0) =
      (if i.val+1=j.val ∨ j.val+1=i.val then edgeWeight s((path i : Vertex a b d),path j) else 0) := by
    by_cases h : i.val+1=j.val ∨ j.val+1=i.val
    · have ha : (graph a b d).Adj (path i) (path j) := h
      simp only [ha,h,ite_true]
    · have ha : ¬(graph a b d).Adj (path i) (path j) := h
      simp only [ha,h,ite_false]
  have ht := (ordered_sum_eq_dart_sum a b d).trans (dart_sum_eq_twice_edge_sum a b d)
  simp only [Fintype.sum_sum_type,Finset.sum_add_distrib] at ht
  simp_rw [hpoint] at ht
  simp only [graph,Adj,weight_as_kernel] at ht
  simp only [hl,hr,hzero,hlast,ite_false,Finset.sum_const_zero,add_zero,zero_add] at ht
  simp only [Finset.sum_ite_eq',Finset.mem_univ,ite_true,
    Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at ht
  rw [clique_block,clique_block] at ht
  simp only [path] at hp
  simp only [hp, ←Finset.mul_sum, Finset.sum_ite_eq', Finset.mem_univ, ite_true] at ht
  simp only [kernel_symm (transmission (path ⟨0,hb⟩ : Vertex a b d)),
    kernel_symm (transmission (path ⟨b-1,by omega⟩ : Vertex a b d))] at ht
  simp only [path,graph] at ht ⊢
  nlinarith [hp]

#print axioms five_sum_identity
end SumBalaban
