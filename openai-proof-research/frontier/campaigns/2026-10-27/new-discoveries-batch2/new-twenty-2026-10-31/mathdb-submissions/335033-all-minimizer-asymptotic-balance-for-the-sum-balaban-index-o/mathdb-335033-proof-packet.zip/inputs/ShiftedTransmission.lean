import Angular
namespace SumBalaban

theorem shifted_actual_transmission {a b d : ℕ} (hb : 0<b) (i : Fin b) :
    (transmission (path i : Vertex a b d) : ℝ) =
      ((i.val+a:ℕ):ℝ)^2 - ((a+b+d:ℕ)-1:ℝ)*((i.val+a:ℕ):ℝ) +
      ((a+b+d:ℕ):ℝ)*((a+b+d:ℕ)-1:ℝ)/2 -
      (((a:ℝ)^2+(d:ℝ)^2-a-d)/2) := by
  have h := twice_path_transmission (a:=a) (d:=d) hb i
  have hr : (2:ℝ)*transmission (path i : Vertex a b d) =
      (i.val:ℝ)*(i.val+1) + ((b-1-i.val:ℕ):ℝ)*((b-i.val:ℕ):ℝ) +
      2*a*(i.val+1) + 2*d*((b-i.val:ℕ):ℝ) := by exact_mod_cast h
  have h1 : ((b-i.val:ℕ):ℝ)=(b:ℝ)-i.val := by
    rw [Nat.cast_sub (by omega : i.val≤b)]
  have h2 : ((b-1-i.val:ℕ):ℝ)=(b:ℝ)-1-i.val := by
    rw [Nat.cast_sub (by omega : i.val≤b-1), Nat.cast_sub (by omega : 1≤b)]
    norm_num
  rw [h1,h2] at hr
  push_cast
  nlinarith
#print axioms shifted_actual_transmission
end SumBalaban
