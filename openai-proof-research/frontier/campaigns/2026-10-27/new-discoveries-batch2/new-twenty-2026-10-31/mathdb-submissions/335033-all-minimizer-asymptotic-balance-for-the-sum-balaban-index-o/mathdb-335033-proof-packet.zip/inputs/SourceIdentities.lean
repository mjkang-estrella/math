import EdgeFormula
import Mathlib.Data.Fin.Rev
namespace SumBalaban
open scoped BigOperators

theorem edge_count_formula {a b d : ℕ} (hb : 0<b) :
    edgeCount a b d = (a+b+d)-1+(a*a+d*d-a-d)/2 := by
  have h := twice_edge_count (a:=a) (d:=d) hb
  have ha := Nat.le_mul_self a
  have hd := Nat.le_mul_self d
  omega

theorem natural_cycle_formula {a b d : ℕ} (hb : 0<b) :
    edgeCount a b d + 2 - (a+b+d) = 1+(a*a+d*d-a-d)/2 := by
  rw [edge_count_formula hb]
  omega

theorem reverse_path_sum (b : ℕ) :
    (∑ i : Fin b, (b - i.val)) = (∑ i : Fin b, (i.val+1)) := by
  have h := Equiv.sum_comp (Fin.revPerm (n:=b)) (fun i : Fin b => b-i.val)
  have he (i : Fin b) : b-(Fin.revPerm i).val = i.val+1 := by
    change b-i.rev.val=i.val+1
    simp only [Fin.val_rev]
    have := i.isLt
    omega
  simpa only [he] using h.symm

theorem twice_right_transmission {a b d : ℕ} (hb : 0<b) (u : Fin d) :
    2*transmission (right u : Vertex a b d) =
      2*(d-1)+b*(b+1)+2*a*(b+1) := by
  rw [right_transmission_sum hb, reverse_path_sum]
  have hs := twice_sum_path_orders b
  nlinarith

-- Real identity has no natural subtraction ambiguity.
theorem real_edge_count_formula {a b d : ℕ} (hb : 0<b) :
    (edgeCount a b d : ℝ) = (a+b+d : ℕ)-1+
      (((a:ℝ)^2+(d:ℝ)^2-a-d)/2) := by
  have h := twice_edge_count (a:=a) (d:=d) hb
  have hr : (2:ℝ)*edgeCount a b d =
      (a:ℝ)*a+(d:ℝ)*d+a+d+2*(b-1:ℕ) := by exact_mod_cast h
  have hb' : (b:ℝ)-1 = (b-1:ℕ) := by
    rw [Nat.cast_sub (by omega : 1≤b)]
    norm_num
  push_cast
  nlinarith

#print axioms edge_count_formula
#print axioms natural_cycle_formula
#print axioms twice_right_transmission
#print axioms real_edge_count_formula
end SumBalaban
