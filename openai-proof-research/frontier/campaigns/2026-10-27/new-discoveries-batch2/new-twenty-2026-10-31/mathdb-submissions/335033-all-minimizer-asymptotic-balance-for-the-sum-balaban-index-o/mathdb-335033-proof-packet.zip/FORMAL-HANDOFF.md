# FORMAL-HANDOFF v4 — unconditional endpoint proved; independent acceptance pending

2026-11-15 UTC. MathDB 335033. GPT-6.1 Sol/high/default; implementation, no children.

SumBalaban.source_target : SourceTarget is now a theorem. For EVERY f:Nat→Triple eventually minimizing the actual graph SJ among admissible positive triples with a+b+d=n and a≤d, it proves full a/sqrt(n)→c, d/sqrt(n)→c, b/n→1. No unpaid annulus, expansion, balance or selection hypotheses. SourceEndpoint also proves full radial q→2sqrt(Q). No Conjecture9 exact finite balancing or connected-graph global minimum claim.

New production chain (all compile+separate kernel PASS): TrialLimits [formal02/03], TrialExpansion [formal06/07], MinimizerComparison [formal10/11], EventualComparison [formal13/14], MinimizingCluster [formal18/19], SourceEndpoint [formal23/24], AuditV4 [formal25/26]. AuditV4's literal expanded all_eventually_minimizing_choices endpoint and 16 transitive critical axiom reports allow only propext, Classical.choice, Quot.sound. No sorry/admit/newaxiom/unsafe/native_decide/oracle in successful production sources.

Core proof: floor trials converge to c and have a general c-dependent expansion; minimizers have inherited fixed-annulus expansion; minimality gives radial and next-order comparisons; exact nonnegative radial excess is discarded for G comparison. Any nonnegative cluster has q=q0 by the exact excess identity and G≤G(c,c), hence is balanced including exclusion of axes. Closed-square compactness upgrades this to full convergence for every choice. The path ratio follows from the exact sum identity. No radial rate or numeric Q/c bound is assumed.

Artifacts: PAPER-v1.md complete ordinary proof; SOURCE-APPENDIX-v4.md FULL literal 55-module local source closure, safe byte-length/hash markers and extraction/rebuild instructions; SOURCE-MAP-v4.json source/import/hash/cache-origin map; FORMAL-USAGE-v4.json and COMMANDS-v4.txt exact call/resource/failure map; INVESTIGATION-v4.md, SELF-v4.md and PROCESS-INVENTORY-v4.json coverage and unwaived defects. All 96 granted old source/olean artifacts matched their sealed hashes before reuse. They remain read-only. Honest reuse: 48 inherited modules, seven fresh modules; NOT a fresh-all-modules build.

Formal budget: 26/64 fresh calls, 12 failures, every failure retained; 38 unused. Historical r3 94 calls/26 failures, r2 71/23, r1 47/23 unchanged. Resource maximum sampled RSS=3,281,256,448 bytes, max child CPU=7.763628s. Exact taskset-prefixed frozen wrappers enforced AS32GiB compile/check only, RSS6GiB, CPU115, wall130, two cores, j1/M3500, warningsAsErrors, one thread. formal20 reported missing Mathlib/Topology/Instances/Prod.olean from a mistaken UNUSED import; archived revision removes it, no pin/cache fallback. All exact commands and failure outputs are preserved.

REQUIRED FUTURE INDEPENDENT ACCEPTANCE: commission a NEW task to extract and freshly compile+kernel-check ENTIRE 55-module source closure WITHOUT these project oleans (at least 110 calls plus any independent audit). Independently review source statement and substantiality to recorded scope, new105th pure-flag comparison, and full extracted replay. Inherited source/binding/substantiality/104-scope/dated373-registry qualification is not repeated here. Closed 2017 journal final/ordinary-Balaban2016 predecessor remain unread; no final identity claim. arXiv2017/internal2021 discrepancy retained. No credit, acceptance or novelty claim/actions.

All inherited and current process defects UNWAIVED; scoped mathematical admissibility is not a clean-history assertion. In particular current display/screen-method/cadence caveats are explicit in PROCESS-INVENTORY-v4.json. Zero network/search/scientific experiments/git/installs/children/accounts/messages/uploads/publication/ledger/count operations. No original origins or other lanes opened. No PDF work in this run.

Finalization: all writes precede standalone frozen-after and exhaustive physical SHA256 seal excluding exactly SHA256-MANIFEST-v4.json, seal-v4.receipt.json, seal-v4.output.txt. Consult observed frozen-after/seal receipts. No postseal commands/writes.

New production source SHA256:
src/TrialLimits.lean 4b18e2f399d0cd61e7594f682ebe86b4b64f2449821f20034ee54efa4951596a
src/TrialExpansion.lean 9f8b7f8fd65e60cf3d9ebef87bc37a0e70d9e13c6a693cc8aa9c52d3a063c82d
src/MinimizerComparison.lean e5b9576260612c968e0e35f5865b681bbdbce6a64bdda305cc5dc1e76af97778
src/EventualComparison.lean 4a2f31bc1d44dec54893beade6ee5f0cb7ecb3eecf7d74b979f6a3df35b29b75
src/MinimizingCluster.lean ad40dd4b1e590190b84952749ae7049d69e3e96586f2daa5f878f0f8d70ac6b3
src/SourceEndpoint.lean 7492d25a0675f686440df8912ec0ef0f6c69065beac1a3a3cfe14e4222986080
src/AuditV4.lean 972f3bba8bbbecd5325f17f4cdc69986409eef7df760962c4b45fafa84d8fd66
