import ReferenceIntegral
import IndexTarget
import Mathlib.Analysis.SpecialFunctions.Arsinh
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
namespace SumBalaban
theorem reference_primitive_derivative (u : ℝ) :
    HasDerivAt (fun x : ℝ => Real.sqrt 2/2*Real.arsinh (2*x-1))
      (referenceF u) u := by
  have hd := ((Real.hasDerivAt_arsinh (2*u-1)).comp u
    (((hasDerivAt_id u).const_mul 2).sub_const 1)).const_mul (Real.sqrt 2/2)
  have hs : Real.sqrt (1+(2*u-1)^2) =
      Real.sqrt 2*Real.sqrt (u^2+(1-u)^2) := by
    rw [←Real.sqrt_mul (by norm_num : (0:ℝ)≤2)]
    congr 1
    ring
  have hp : 0<Real.sqrt (u^2+(1-u)^2) :=
    Real.sqrt_pos.mpr (by linarith [reference_phi_lower u])
  have h2 : 0<Real.sqrt (2:ℝ) := Real.sqrt_pos.mpr (by norm_num)
  have he : referenceF u = Real.sqrt 2/2*((Real.sqrt (1+(2*u-1)^2))⁻¹*(2*1)) := by
    dsimp [referenceF]
    rw [hs]
    field_simp

  rw [he]
  exact hd

theorem reference_integral_value : (∫ u in (0:ℝ)..1, referenceF u)=Q := by
  have hi := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (a:=0) (b:=1)
    (fun u _ => reference_primitive_derivative u)
    (referenceF_continuous.intervalIntegrable 0 1)
  have hn : Real.arsinh (-1) = -Real.arsinh 1 := Real.arsinh_neg 1
  norm_num only [mul_one, mul_zero, sub_zero, zero_sub] at hi
  rw [hn] at hi
  rw [hi]
  simp only [Real.arsinh, one_pow, one_add_one_eq_two, Q]
  ring
#print axioms reference_primitive_derivative
#print axioms reference_integral_value
end SumBalaban
