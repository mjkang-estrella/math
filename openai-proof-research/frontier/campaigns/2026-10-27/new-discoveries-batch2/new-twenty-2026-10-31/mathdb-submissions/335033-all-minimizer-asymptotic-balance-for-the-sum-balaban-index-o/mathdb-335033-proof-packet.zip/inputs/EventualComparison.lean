import MinimizerComparison
namespace SumBalaban
open Filter

theorem minimizer_eventual_comparison {f : ℕ → Triple}
    (hf : ∀ᶠ n in atTop, minimizes n (f n)) :
    ∃ C : ℝ, ∀ᶠ n : ℕ in atTop,
      radialF ((normA (f n) n)^2+(normD (f n) n)^2) ≤
        radialF (2*(trialX n)^2)+(1/Real.sqrt (n:ℝ))*
          (correctionG (trialX n) (trialX n)-correctionG (normA (f n) n) (normD (f n) n))+C/(n:ℝ) ∧
      correctionG (normA (f n) n) (normD (f n) n) ≤
        correctionG (trialX n) (trialX n)+(16+C)/Real.sqrt (n:ℝ) := by
  obtain ⟨K,hK,hE⟩ := minimizer_eventual_expansion hf
  obtain ⟨L,hL,hT⟩ := trial_eventual_expansion
  refine ⟨K+L,?_⟩
  filter_upwards [hf,hE,hT,optimal_trial_eventually,eventually_ge_atTop 2048] with n hm he ht htrial hn
  have hr := every_minimizer_annulus hn hm
  have hnR : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hq : 0<(normA (f n) n)^2+(normD (f n) n)^2 := by
    have hh := hr.2.2.2.2.1
    change (1:ℝ)/1024≤(normA (f n) n)^2+(normD (f n) n)^2 at hh
    linarith
  have hcomp := comparison_algebra hnR hq he ht htrial.2 (hm.2 _ htrial.1)
  simpa only [add_assoc] using hcomp

#print axioms minimizer_eventual_comparison
end SumBalaban
