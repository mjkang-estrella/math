import OptimalTrialEventually
import ClusterSelection
import UniformEndpoint
import Mathlib.Topology.Algebra.Order.Field
namespace SumBalaban
open Filter
noncomputable def trialX (n : ℕ) : ℝ := ((optimalTrial n).1:ℝ)/Real.sqrt n

theorem inverse_sqrt_limit : Tendsto (fun n : ℕ => 1/Real.sqrt (n:ℝ)) atTop (nhds 0) := by
  simpa only [one_div, Function.comp_def] using tendsto_inv_atTop_zero.comp
    (Real.tendsto_sqrt_atTop.comp tendsto_natCast_atTop_atTop)

theorem trial_normalized_limit : Tendsto trialX atTop (nhds c) := by
  have hlow : ∀ᶠ n : ℕ in atTop, c-1/Real.sqrt (n:ℝ) ≤ trialX n := by
    filter_upwards [eventually_ge_atTop 1] with n hn
    have hs : 0<Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast (show 0<n by omega))
    have he := Nat.lt_floor_add_one (c*Real.sqrt (n:ℝ))
    change c-1/Real.sqrt (n:ℝ) ≤ (Nat.floor (c*Real.sqrt (n:ℝ)):ℝ)/Real.sqrt (n:ℝ)
    apply (le_div_iff₀ hs).mpr
    field_simp
    nlinarith
  have hhigh : ∀ᶠ n : ℕ in atTop, trialX n ≤ c := by
    filter_upwards [eventually_ge_atTop 1] with n hn
    have hs : 0<Real.sqrt (n:ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast (show 0<n by omega))
    change (Nat.floor (c*Real.sqrt (n:ℝ)):ℝ)/Real.sqrt (n:ℝ) ≤ c
    exact (div_le_iff₀ hs).mpr (Nat.floor_le (mul_nonneg (le_of_lt c_pos) (Real.sqrt_nonneg _)))
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le'
    (by simpa using tendsto_const_nhds.sub inverse_sqrt_limit) tendsto_const_nhds hlow hhigh
#print axioms trial_normalized_limit
end SumBalaban
