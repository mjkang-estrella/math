import UniformExpansion
namespace SumBalaban
theorem rational_correction_as_normalized {a d n : ℝ} (hn : 0<n)
    (hS : 0<a^2+d^2) :
    let q := (a^2+d^2)/n
    let u := (a+d)/n
    let t := (a^3+d^3)/n^2
    (1+2/q)*(q/2+Q)+(1+2/q)*(t-u)/2+(2*u/q^2)*(q/2+Q) =
      radialF ((a/Real.sqrt n)^2+(d/Real.sqrt n)^2)+
        (1/Real.sqrt n)*correctionG (a/Real.sqrt n) (d/Real.sqrt n) := by
  dsimp only
  unfold radialF correctionG
  dsimp only
  have hs := Real.sqrt_pos.mpr hn
  have hs2 := Real.sq_sqrt (le_of_lt hn)
  generalize hz : Real.sqrt n=z at *
  rw [←hs2]
  field_simp [ne_of_gt hs,ne_of_gt hS]
  ring

theorem common_uniform_expansion :
    ∃ K : ℝ, 0≤K ∧ ∃ N : ℕ, 1≤N ∧
    ∀ a b d : ℕ, 0<a → 0<b → 0<d → N≤a+b+d →
      (a:ℝ)^2+(d:ℝ)^2≤512*(a+b+d:ℕ) →
      ((a+b+d:ℕ):ℝ)≤1024*((a:ℝ)^2+(d:ℝ)^2) →
      let n : ℝ := (a+b+d:ℕ)
      let x : ℝ := (a:ℝ)/Real.sqrt n
      let y : ℝ := (d:ℝ)/Real.sqrt n
      |SJ a b d-radialF (x^2+y^2)-(1/Real.sqrt n)*correctionG x y|≤K/n := by
  refine ⟨combinedErrorK 512 (1/1024),?_,2^40,by norm_num,?_⟩
  · unfold combinedErrorK prefactorErrorK edgeErrorK
    have := Q_pos
    positivity
  · intro a b d ha hb hd hn hq hql
    have hn0 : (0:ℝ)<(a+b+d:ℕ) := by exact_mod_cast (show 0<a+b+d by omega)
    have hge : (2^40:ℝ)≤(a+b+d:ℕ) := by exact_mod_cast hn
    have hS : (0:ℝ)<(a:ℝ)^2+(d:ℝ)^2 := by positivity
    have he := actual_SJ_rational_expansion ha hb hd
      (by norm_num : (0:ℝ)≤512) (by norm_num : (0:ℝ)<1/1024) hq
      (by nlinarith : (1/1024:ℝ)*(a+b+d:ℕ)≤(a:ℝ)^2+(d:ℝ)^2)
      (by nlinarith : 16*(2*(512:ℝ)+4)≤(a+b+d:ℕ))
      (by nlinarith : 8*(512:ℝ)≤(1/1024:ℝ)^2*(a+b+d:ℕ))
    have hid := rational_correction_as_normalized (a:=(a:ℝ)) (d:=(d:ℝ)) hn0 hS
    dsimp only at he hid ⊢
    rw [hid] at he
    convert he using 1; congr 1; ring
#print axioms rational_correction_as_normalized
#print axioms common_uniform_expansion
end SumBalaban
