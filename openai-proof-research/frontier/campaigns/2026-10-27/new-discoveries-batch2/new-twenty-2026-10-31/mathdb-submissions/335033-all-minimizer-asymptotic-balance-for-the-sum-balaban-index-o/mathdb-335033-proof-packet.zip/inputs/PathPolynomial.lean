import SourceIdentities
namespace SumBalaban
open scoped BigOperators

theorem twice_path_distance_sum (b i : ℕ) (hi : i<b) :
    2*(∑ j : Fin b, (if i≤j.val then j.val-i else i-j.val)) =
      i*(i+1)+(b-1-i)*(b-i) := by
  induction b with
  | zero => omega
  | succ b ih =>
    rw [Fin.sum_univ_castSucc]
    simp only [Fin.val_castSucc, Fin.val_last]
    by_cases h : i<b
    · have hs := ih h
      have he : b-i=(b-1-i)+1 := by omega
      have hle : i≤b := by omega
      simp only [hle,ite_true]
      have h1 : b+1-1-i=b-i := by omega
      have h2 : b+1-i=(b-i)+1 := by omega
      rw [h1,h2,he]
      rw [he] at hs
      nlinarith
    · have he : i=b := by omega
      subst i
      have hf (j : Fin b) : ¬b≤j.val := by have := j.isLt; omega
      simp only [hf,ite_false,le_refl,ite_true,Nat.sub_self,add_zero]
      rw [reverse_path_sum]
      have hs := twice_sum_path_orders b
      simpa using hs

theorem twice_path_transmission {a b d : ℕ} (hb : 0<b) (i : Fin b) :
    2*transmission (path i : Vertex a b d) =
      i.val*(i.val+1)+(b-1-i.val)*(b-i.val)+
      2*a*(i.val+1)+2*d*(b-i.val) := by
  rw [path_transmission_sum hb]
  have hs := twice_path_distance_sum b i.val i.isLt
  nlinarith

#print axioms twice_path_distance_sum
#print axioms twice_path_transmission
end SumBalaban
