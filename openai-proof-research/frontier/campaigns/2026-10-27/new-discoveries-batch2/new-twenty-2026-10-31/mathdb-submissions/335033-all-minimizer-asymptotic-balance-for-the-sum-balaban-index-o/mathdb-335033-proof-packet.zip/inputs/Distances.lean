import Dumbbell
namespace SumBalaban

theorem connected {a b d : ℕ} (hb : 0 < b) : (graph a b d).Connected := by
  let : Nonempty (Vertex a b d) := ⟨path ⟨0,hb⟩⟩
  exact ⟨preconnected hb⟩

def coordinate {a b d : ℕ} : Vertex a b d → ℕ
  | .inl _ => 0
  | .inr (.inl i) => i.val + 1
  | .inr (.inr _) => b + 1

theorem coordinate_step {a b d : ℕ} {u v : Vertex a b d}
    (h : (graph a b d).Adj u v) : coordinate v ≤ coordinate u + 1 := by
  rcases u with i | i <;> rcases v with j | j
  · simp [coordinate]
  · rcases j with j | j
    · change j.val = 0 at h
      simp only [coordinate]
      omega
    · exact False.elim h
  · rcases i with i | i
    · simp only [coordinate]
      omega
    · exact False.elim h
  · rcases i with i | i <;> rcases j with j | j
    · change i.val+1=j.val ∨ j.val+1=i.val at h
      simp only [coordinate]
      omega
    · change i.val+1=b at h
      simp only [coordinate]
      omega
    · change j.val+1=b at h
      simp only [coordinate]
      omega
    · simp [coordinate]

theorem coordinate_walk {a b d : ℕ} {u v : Vertex a b d}
    (p : (graph a b d).Walk u v) : coordinate v ≤ coordinate u + p.length := by
  induction p with
  | nil => simp
  | @cons u v w h p ih =>
    have hs := coordinate_step h
    simp only [SimpleGraph.Walk.length_cons]
    omega

theorem coordinate_dist {a b d : ℕ} (hb : 0 < b) (u v : Vertex a b d) :
    coordinate v ≤ coordinate u + (graph a b d).dist u v := by
  obtain ⟨p,hp⟩ := (connected (a:=a) (d:=d) hb).exists_walk_length_eq_dist u v
  simpa [hp] using coordinate_walk p

theorem path_dist_le {a b d : ℕ} (hb : 0 < b) (i j : Fin b) (hij : i.val ≤ j.val) :
    (graph a b d).dist (path i) (path j) ≤ j.val-i.val := by
  obtain ⟨j,hj⟩ := j
  induction j with
  | zero =>
    have he : i = ⟨0,hj⟩ := Fin.ext (by dsimp (config := { failIfUnchanged := false }) only at *; omega)
    subst i
    simp
  | succ j ih =>
    by_cases he : i.val = j+1
    · have he' : i = ⟨j+1,hj⟩ := Fin.ext he
      subst i
      simp
    · have hj' : j < b := by dsimp (config := { failIfUnchanged := false }) only at *; omega
      have hsmall := ih hj' (by dsimp (config := { failIfUnchanged := false }) only at *; omega)
      have ha : (graph a b d).Adj (path ⟨j,hj'⟩) (path ⟨j+1,hj⟩) := by
        change @Adj a b d (path ⟨j,hj'⟩) (path ⟨j+1,hj⟩)
        simp [Adj]
      have hone := SimpleGraph.dist_eq_one_iff_adj.mpr ha
      have ht := (connected (a:=a) (d:=d) hb).dist_triangle
        (u:=path i) (v:=path ⟨j,hj'⟩) (w:=path ⟨j+1,hj⟩)
      dsimp (config := { failIfUnchanged := false }) only at *
      omega

theorem path_dist_of_le {a b d : ℕ} (hb : 0 < b) (i j : Fin b) (hij : i.val ≤ j.val) :
    (graph a b d).dist (path i) (path j) = j.val-i.val := by
  have hu := path_dist_le (a:=a) (d:=d) hb i j hij
  have hl := coordinate_dist (a:=a) (d:=d) hb (path i) (path j)
  simp only [coordinate] at hl
  omega

theorem left_path_dist {a b d : ℕ} (hb : 0 < b) (u : Fin a) (i : Fin b) :
    (graph a b d).dist (left u) (path i) = i.val+1 := by
  have ha : (graph a b d).Adj (left u) (path ⟨0,hb⟩) := by rfl
  have h1 := SimpleGraph.dist_eq_one_iff_adj.mpr ha
  have hp := path_dist_of_le (a:=a) (d:=d) hb ⟨0,hb⟩ i (by dsimp (config := { failIfUnchanged := false }) only at *; omega)
  have ht := (connected (a:=a) (d:=d) hb).dist_triangle
    (u:=left u) (v:=path ⟨0,hb⟩) (w:=path i)
  have hl := coordinate_dist (a:=a) (d:=d) hb (left u) (path i)
  simp only [coordinate] at hl
  omega

theorem path_right_dist {a b d : ℕ} (hb : 0 < b) (i : Fin b) (u : Fin d) :
    (graph a b d).dist (path i) (right u) = b-i.val := by
  have ha : (graph a b d).Adj (path ⟨b-1,by omega⟩) (right u) := by
    change @Adj a b d (path ⟨b-1,by omega⟩) (right u)
    simp only [Adj]; omega
  have h1 := SimpleGraph.dist_eq_one_iff_adj.mpr ha
  have hp := path_dist_of_le (a:=a) (d:=d) hb i ⟨b-1,by omega⟩ (by change i.val ≤ b-1; omega)
  have ht := (connected (a:=a) (d:=d) hb).dist_triangle
    (u:=path i) (v:=path ⟨b-1,by dsimp (config := { failIfUnchanged := false }) only at *; omega⟩) (w:=right u)
  have hl := coordinate_dist (a:=a) (d:=d) hb (path i) (right u)
  simp only [coordinate] at hl
  omega

theorem left_right_dist {a b d : ℕ} (hb : 0 < b) (u : Fin a) (v : Fin d) :
    (graph a b d).dist (left u) (right v) = b+1 := by
  have hp := left_path_dist (d:=d) hb u (⟨b-1,by omega⟩ : Fin b)
  have hr := path_right_dist (a:=a) hb (⟨b-1,by dsimp (config := { failIfUnchanged := false }) only at *; omega⟩ : Fin b) v
  have ht := (connected (a:=a) (d:=d) hb).dist_triangle
    (u:=left u) (v:=path ⟨b-1,by dsimp (config := { failIfUnchanged := false }) only at *; omega⟩) (w:=right v)
  have hl := coordinate_dist (a:=a) (d:=d) hb (left u) (right v)
  simp only [coordinate] at hl
  omega

theorem left_left_dist {a b d : ℕ} (u v : Fin a) :
    (graph a b d).dist (left u) (left v) = if u=v then 0 else 1 := by
  split_ifs with h
  · subst v; exact SimpleGraph.dist_self
  · apply SimpleGraph.dist_eq_one_iff_adj.mpr
    exact h

theorem right_right_dist {a b d : ℕ} (u v : Fin d) :
    (graph a b d).dist (right u) (right v) = if u=v then 0 else 1 := by
  split_ifs with h
  · subst v; exact SimpleGraph.dist_self
  · apply SimpleGraph.dist_eq_one_iff_adj.mpr
    exact h

#print axioms coordinate_dist
#print axioms path_dist_of_le
#print axioms left_path_dist
#print axioms path_right_dist
#print axioms left_right_dist
#print axioms left_left_dist
end SumBalaban
