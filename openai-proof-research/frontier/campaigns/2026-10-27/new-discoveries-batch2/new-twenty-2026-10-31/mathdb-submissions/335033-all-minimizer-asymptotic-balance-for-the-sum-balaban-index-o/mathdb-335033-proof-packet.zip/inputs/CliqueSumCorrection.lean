import CliqueTaylor
namespace SumBalaban
theorem weighted_two_error {w z t v ε k : ℝ} (hw : 0≤w) (hv : 0≤v)
    (hz : |z-k|≤ε) (ht : |t-k|≤ε) :
    |w*z+v*t-(w+v)*k|≤(w+v)*ε := by
  calc
    _ = |w*(z-k)+v*(t-k)| := by congr 1; ring
    _ ≤ |w*(z-k)|+|v*(t-k)| := abs_add_le _ _
    _ = w*|z-k|+v*|t-k| := by rw [abs_mul,abs_mul,abs_of_nonneg hw,abs_of_nonneg hv]
    _ ≤ w*ε+v*ε := add_le_add (mul_le_mul_of_nonneg_left hz hw) (mul_le_mul_of_nonneg_left ht hv)
    _ = _ := by ring
noncomputable def actualCliqueSum (a b d : ℕ) (hb : 0<b) : ℝ :=
  (a:ℝ)*(a-1:ℕ)/2*(1/Real.sqrt (2*(leftW a b d:ℝ)))+
  (a:ℝ)*(1/Real.sqrt ((leftW a b d:ℝ)+(transmission (path ⟨0,hb⟩ : Vertex a b d):ℝ)))+
  (d:ℝ)*(d-1:ℕ)/2*(1/Real.sqrt (2*(rightW a b d:ℝ)))+
  (d:ℝ)*(1/Real.sqrt ((rightW a b d:ℝ)+(transmission (path ⟨b-1,by omega⟩ : Vertex a b d):ℝ)))
theorem actual_clique_sum_first_correction {a b d : ℕ} {B : ℝ}
    (ha : 0<a) (hb : 0<b) (hd : 0<d) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hn : 16*(2*B+4)≤((a+b+d:ℕ):ℝ)) :
    let n : ℝ := (a+b+d:ℕ)
    |actualCliqueSum a b d hb-
      (((a:ℝ)^2+(d:ℝ)^2)/(2*n)+((a:ℝ)+d)/(2*n)+
       ((a:ℝ)^3+(d:ℝ)^3)/(2*n^2))|≤
      ((B+1)*(10*B+12)+B)/n := by
  dsimp only
  let n : ℝ := (a+b+d:ℕ)
  have hn0 : 0<n := by dsimp [n]; exact_mod_cast (show 0<a+b+d by omega)
  have ham : ((a-1:ℕ):ℝ)=(a:ℝ)-1 := by rw [Nat.cast_sub (by omega),Nat.cast_one]
  have hdm : ((d-1:ℕ):ℝ)=(d:ℝ)-1 := by rw [Nat.cast_sub (by omega),Nat.cast_one]
  obtain ⟨h1,h2,h3,h4⟩ := actual_clique_four_corrections ha hb hd hB hq hn
  have hL := weighted_two_error (w:=(a:ℝ)*(a-1:ℕ)/2) (v:=(a:ℝ))
    (by positivity) (by positivity) h1 h3
  have hR := weighted_two_error (w:=(d:ℝ)*(d-1:ℕ)/2) (v:=(d:ℝ))
    (by positivity) (by positivity) h2 h4
  have hW : ((a:ℝ)*(a-1:ℕ)/2+a)+((d:ℝ)*(d-1:ℕ)/2+d)≤(B+1)*n := by
    rw [ham,hdm]
    have hs : (a:ℝ)+d≤n := by dsimp [n]; push_cast; linarith [show (0:ℝ)≤b by positivity]
    change (a:ℝ)^2+(d:ℝ)^2≤B*n at hq
    nlinarith
  let P : ℝ := ((a:ℝ)*(a-1:ℕ)/2+a)*(1/n+(a:ℝ)/n^2)+
    ((d:ℝ)*(d-1:ℕ)/2+d)*(1/n+(d:ℝ)/n^2)
  have hE : |actualCliqueSum a b d hb-P|≤((B+1)*(10*B+12))/n := by
    have hh := abs_add_le
      ((a:ℝ)*(a-1:ℕ)/2*(1/Real.sqrt (2*(leftW a b d:ℝ)))+
       (a:ℝ)*(1/Real.sqrt ((leftW a b d:ℝ)+(transmission (path ⟨0,hb⟩ : Vertex a b d):ℝ)))-
       ((a:ℝ)*(a-1:ℕ)/2+a)*(1/n+(a:ℝ)/n^2))
      ((d:ℝ)*(d-1:ℕ)/2*(1/Real.sqrt (2*(rightW a b d:ℝ)))+
       (d:ℝ)*(1/Real.sqrt ((rightW a b d:ℝ)+(transmission (path ⟨b-1,by omega⟩ : Vertex a b d):ℝ)))-
       ((d:ℝ)*(d-1:ℕ)/2+d)*(1/n+(d:ℝ)/n^2))
    have hh' := hh.trans (add_le_add hL hR)
    have hr : (actualCliqueSum a b d hb-P)=
      ((a:ℝ)*(a-1:ℕ)/2*(1/Real.sqrt (2*(leftW a b d:ℝ)))+
       (a:ℝ)*(1/Real.sqrt ((leftW a b d:ℝ)+(transmission (path ⟨0,hb⟩ : Vertex a b d):ℝ)))-
       ((a:ℝ)*(a-1:ℕ)/2+a)*(1/n+(a:ℝ)/n^2))+
      ((d:ℝ)*(d-1:ℕ)/2*(1/Real.sqrt (2*(rightW a b d:ℝ)))+
       (d:ℝ)*(1/Real.sqrt ((rightW a b d:ℝ)+(transmission (path ⟨b-1,by omega⟩ : Vertex a b d):ℝ)))-
       ((d:ℝ)*(d-1:ℕ)/2+d)*(1/n+(d:ℝ)/n^2)) := by dsimp [actualCliqueSum,P]; ring
    rw [←hr] at hh'
    apply hh'.trans
    have hm := mul_le_mul_of_nonneg_right hW (show 0≤(10*B+12)/n^2 by positivity)
    have hid : (B+1)*n*((10*B+12)/n^2)=((B+1)*(10*B+12))/n := by field_simp
    rw [hid] at hm
    nlinarith
  let T : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/(2*n)+((a:ℝ)+d)/(2*n)+
    ((a:ℝ)^3+(d:ℝ)^3)/(2*n^2)
  have hPT : P-T=((a:ℝ)^2+(d:ℝ)^2)/(2*n^2) := by dsimp [P,T]; rw [ham,hdm]; ring
  have hPTb : |P-T|≤B/n := by
    rw [hPT,abs_of_nonneg (by positivity)]
    apply (div_le_iff₀ (by positivity : 0<2*n^2)).mpr
    field_simp
    nlinarith
  have hh := (abs_sub_le (actualCliqueSum a b d hb) P T).trans (add_le_add hE hPTb)
  change |actualCliqueSum a b d hb-T|≤((B+1)*(10*B+12)+B)/n
  convert hh using 1; ring
#print axioms actual_clique_sum_first_correction
end SumBalaban
