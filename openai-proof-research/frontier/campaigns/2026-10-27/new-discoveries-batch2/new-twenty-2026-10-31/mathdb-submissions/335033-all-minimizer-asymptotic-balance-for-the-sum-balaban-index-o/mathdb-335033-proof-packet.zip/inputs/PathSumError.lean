import PathKernel
namespace SumBalaban
open scoped BigOperators

theorem actual_path_sum_error {a b d : ℕ} {B : ℝ} (hb : 0<b) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2 ≤ B*(a+b+d : ℕ))
    (hn : 4*(B+5)≤((a+b+d:ℕ):ℝ)) :
    |pathForward a b d -
      ∑ i : Fin (b-1), 1/Real.sqrt (((i.val+a:ℕ):ℝ)^2 +
        (((a+b+d:ℕ):ℝ)-((i.val+a:ℕ):ℝ))^2)| ≤ 4*(B+5)/((a+b+d:ℕ):ℝ) := by
  rw [pathForward_single,←Finset.sum_sub_distrib]
  have hpos : (0:ℝ)<((a+b+d:ℕ):ℝ) := by exact_mod_cast (show 0<a+b+d by omega)
  have hcard : ((b-1:ℕ):ℝ)≤((a+b+d:ℕ):ℝ) := by exact_mod_cast (show b-1≤a+b+d by omega)
  calc
    _ ≤ ∑ i : Fin (b-1), |edgeWeight s((path (pathLo i) : Vertex a b d),path (pathHi i)) -
        1/Real.sqrt (((i.val+a:ℕ):ℝ)^2 + (((a+b+d:ℕ):ℝ)-((i.val+a:ℕ):ℝ))^2)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _i : Fin (b-1), 4*(B+5)/((a+b+d:ℕ):ℝ)^2 :=
      Finset.sum_le_sum (fun i _ => actual_path_kernel_error hb hB hq hn i)
    _ = ((b-1:ℕ):ℝ)*(4*(B+5)/((a+b+d:ℕ):ℝ)^2) := by
      simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
    _ ≤ ((a+b+d:ℕ):ℝ)*(4*(B+5)/((a+b+d:ℕ):ℝ)^2) :=
      mul_le_mul_of_nonneg_right hcard (by positivity)
    _ = _ := by field_simp

theorem reference_scaled (n t : ℝ) (hn : 0<n) :
    1/Real.sqrt (t^2+(n-t)^2) = (1/n)*(1/Real.sqrt ((t/n)^2+(1-t/n)^2)) := by
  have hp : t^2+(n-t)^2 = n^2*((t/n)^2+(1-t/n)^2) := by field_simp
  rw [hp,Real.sqrt_mul (sq_nonneg n),Real.sqrt_sq_eq_abs,abs_of_pos hn]
  field_simp

#print axioms actual_path_sum_error
#print axioms reference_scaled
end SumBalaban
