import IndexTarget
import Mathlib.Combinatorics.SimpleGraph.Acyclic
import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Tactic.Linarith
namespace SumBalaban
open scoped BigOperators

theorem twice_sum_path_orders (b : ℕ) :
    2*(∑ i : Fin b, (i.val+1)) = b*(b+1) := by
  induction b with
  | zero => simp
  | succ b ih =>
    rw [Fin.sum_univ_succ]
    have he : (∑ i : Fin b, (i.succ.val+1)) =
        (∑ i : Fin b, (i.val+1)) + b := by
      simp only [Fin.val_succ]
      simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ,
        Fintype.card_fin, smul_eq_mul, mul_one]
    rw [he]
    simp only [Fin.val_zero]
    nlinarith

theorem twice_left_transmission {a b d : ℕ} (hb : 0 < b) (u : Fin a) :
    2*transmission (left u : Vertex a b d) =
      2*(a-1) + b*(b+1) + 2*d*(b+1) := by
  rw [left_transmission_sum hb]
  have hs := twice_sum_path_orders b
  nlinarith

theorem vertex_count (a b d : ℕ) : Fintype.card (Vertex a b d) = a+b+d := by
  simp only [Vertex, Fintype.card_sum, Fintype.card_fin]
  omega

theorem cycle_denominator_pos {a b d : ℕ} (hb : 0 < b) :
    0 < (edgeCount a b d : ℝ) - (a+b+d : ℕ) + 2 := by
  classical
  have h := (connected (a:=a) (d:=d) hb).card_vert_le_card_edgeSet_add_one
  rw [Nat.card_eq_fintype_card, Nat.card_eq_fintype_card, vertex_count,
    ←SimpleGraph.edgeFinset_card] at h
  change a+b+d ≤ edgeCount a b d+1 at h
  have hc : ((a+b+d : ℕ) : ℝ) ≤ (edgeCount a b d : ℝ)+1 := by exact_mod_cast h
  linarith

theorem edgeWeight_formula {a b d : ℕ} (u v : Vertex a b d) :
    edgeWeight (s(u,v)) = 1/Real.sqrt ((transmission u : ℝ)+(transmission v : ℝ)) := rfl

-- Exact actual-edge partition, before evaluating the five cardinalities.
def edgeClass {a b d : ℕ} : Sym2 (Vertex a b d) → ℕ :=
  Sym2.lift ⟨fun u v => match u,v with
    | .inl _, .inl _ => 0
    | .inl _, .inr (.inl _) | .inr (.inl _), .inl _ => 1
    | .inr (.inl _), .inr (.inl _) => 2
    | .inr (.inr _), .inr (.inl _) | .inr (.inl _), .inr (.inr _) => 3
    | .inr (.inr _), .inr (.inr _) => 4
    | _,_ => 5,
    by
      intro u v
      rcases u with i|i <;> rcases v with j|j
      · rfl
      · rcases j <;> rfl
      · rcases i <;> rfl
      · rcases i <;> rcases j <;> rfl⟩

theorem edge_class_lt_five {a b d : ℕ} (e : Sym2 (Vertex a b d))
    (he : e ∈ (graph a b d).edgeSet) : edgeClass e < 5 := by
  induction e using Sym2.inductionOn with
  | _ u v =>
    have ha : (graph a b d).Adj u v := he
    rcases u with i|i <;> rcases v with j|j
    · norm_num [edgeClass, Sym2.lift_mk]
    · rcases j with j|j
      · norm_num [edgeClass, Sym2.lift_mk]
      · exact False.elim ha
    · rcases i with i|i
      · norm_num [edgeClass, Sym2.lift_mk]
      · exact False.elim ha
    · rcases i <;> rcases j <;> norm_num [edgeClass, Sym2.lift_mk]

#print axioms twice_left_transmission
#print axioms cycle_denominator_pos
#print axioms edge_class_lt_five
end SumBalaban
