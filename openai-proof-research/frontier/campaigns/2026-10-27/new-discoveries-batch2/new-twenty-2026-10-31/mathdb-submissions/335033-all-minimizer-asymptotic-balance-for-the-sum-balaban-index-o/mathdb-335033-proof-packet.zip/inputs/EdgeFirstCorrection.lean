import CliqueSumCorrection
import PathFirstCorrection
namespace SumBalaban
open scoped BigOperators
theorem actual_edge_sum_split {a b d : ℕ} (hb : 0<b) :
    (∑ e ∈ (graph a b d).edgeFinset, edgeWeight e)=
      actualCliqueSum a b d hb+pathForward a b d := by
  rw [five_sum_identity hb]
  unfold actualCliqueSum
  simp only [kernel,←two_mul]
  ring

theorem actual_edge_first_correction {a b d : ℕ} {B : ℝ}
    (ha : 0<a) (hb : 0<b) (hd : 0<d) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hn : 16*(2*B+4)≤((a+b+d:ℕ):ℝ)) :
    let n : ℝ := (a+b+d:ℕ)
    |(∑ e ∈ (graph a b d).edgeFinset, edgeWeight e)-
      (((a:ℝ)^2+(d:ℝ)^2)/(2*n)+Q+
       ((a:ℝ)^3+(d:ℝ)^3)/(2*n^2)-((a:ℝ)+d)/(2*n))|≤
      ((B+1)*(10*B+12)+21*B+45)/n := by
  dsimp only
  let n : ℝ := (a+b+d:ℕ)
  have hC := actual_clique_sum_first_correction ha hb hd hB hq hn
  have hP := actual_path_first_correction hb hB hq (by nlinarith)
  let TC : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/(2*n)+((a:ℝ)+d)/(2*n)+
       ((a:ℝ)^3+(d:ℝ)^3)/(2*n^2)
  let TP : ℝ := Q-((a:ℝ)+d)/n
  have hident :
      (∑ e ∈ (graph a b d).edgeFinset, edgeWeight e)-
      (((a:ℝ)^2+(d:ℝ)^2)/(2*n)+Q+
       ((a:ℝ)^3+(d:ℝ)^3)/(2*n^2)-((a:ℝ)+d)/(2*n)) =
      (actualCliqueSum a b d hb-TC)+(pathForward a b d-TP) := by
    rw [actual_edge_sum_split hb]
    dsimp [TC,TP]
    ring
  change |(∑ e ∈ (graph a b d).edgeFinset, edgeWeight e)-
      (((a:ℝ)^2+(d:ℝ)^2)/(2*n)+Q+
       ((a:ℝ)^3+(d:ℝ)^3)/(2*n^2)-((a:ℝ)+d)/(2*n))|≤_
  rw [hident]
  calc
    _ ≤ |actualCliqueSum a b d hb-TC|+|pathForward a b d-TP| := abs_add_le _ _
    _ ≤ ((B+1)*(10*B+12)+B)/n+(20*B+45)/n := add_le_add hC hP
    _ = _ := by ring
#print axioms actual_edge_sum_split
#print axioms actual_edge_first_correction
end SumBalaban
