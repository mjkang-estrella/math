import Distances
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic.Ring
namespace SumBalaban
open scoped BigOperators
noncomputable def transmission {a b d : ℕ} (u : Vertex a b d) : ℕ :=
  ∑ v : Vertex a b d, (graph a b d).dist u v

theorem clique_sum (a : ℕ) (u : Fin a) :
    (∑ v : Fin a, if u=v then (0:ℕ) else 1) = a-1 := by
  classical
  simp only [Finset.sum_ite, Finset.sum_const_zero, zero_add, Finset.sum_const,
    smul_eq_mul, mul_one]
  have he : Finset.univ.filter (fun v : Fin a => ¬u=v) = Finset.univ.erase u := by
    ext v
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_erase,
      and_true]
    exact ne_comm
  rw [he, Finset.card_erase_of_mem (Finset.mem_univ u), Finset.card_univ, Fintype.card_fin]

theorem left_transmission_sum {a b d : ℕ} (hb : 0 < b) (u : Fin a) :
    transmission (d:=d) (left u : Vertex a b d) =
      (a-1) + (∑ i : Fin b, (i.val+1)) + d*(b+1) := by
  classical
  unfold transmission
  rw [Fintype.sum_sum_type]
  rw [Fintype.sum_sum_type]
  simp only [left_left_dist, left_path_dist hb, left_right_dist hb]
  rw [clique_sum]
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul]
  omega

theorem right_transmission_sum {a b d : ℕ} (hb : 0 < b) (u : Fin d) :
    transmission (a:=a) (right u : Vertex a b d) =
      (d-1) + (∑ i : Fin b, (b-i.val)) + a*(b+1) := by
  classical
  unfold transmission
  rw [Fintype.sum_sum_type, Fintype.sum_sum_type]
  have hl : ∀ v : Fin a, (graph a b d).dist (right u) (left v) = b+1 := by
    intro v
    rw [SimpleGraph.dist_comm]
    exact left_right_dist hb v u
  have hp : ∀ i : Fin b, (graph a b d).dist (right u) (path i) = b-i.val := by
    intro i
    rw [SimpleGraph.dist_comm]
    exact path_right_dist hb i u
  simp only [hl, hp, right_right_dist, clique_sum, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, smul_eq_mul]
  omega

theorem path_dist {a b d : ℕ} (hb : 0 < b) (i j : Fin b) :
    (graph a b d).dist (path i) (path j) =
      if i.val ≤ j.val then j.val-i.val else i.val-j.val := by
  split_ifs with h
  · exact path_dist_of_le hb i j h
  · rw [SimpleGraph.dist_comm]
    exact path_dist_of_le hb j i (by omega)

theorem path_transmission_sum {a b d : ℕ} (hb : 0 < b) (i : Fin b) :
    transmission (path i : Vertex a b d) =
      a*(i.val+1) +
      (∑ j : Fin b, if i.val ≤ j.val then j.val-i.val else i.val-j.val) +
      d*(b-i.val) := by
  classical
  unfold transmission
  rw [Fintype.sum_sum_type, Fintype.sum_sum_type]
  have hl : ∀ v : Fin a, (graph a b d).dist (path i) (left v) = i.val+1 := by
    intro v
    rw [SimpleGraph.dist_comm]
    exact left_path_dist hb v i
  simp only [hl, path_dist hb, path_right_dist hb, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, smul_eq_mul]
  omega

#print axioms left_transmission_sum
#print axioms right_transmission_sum
#print axioms path_transmission_sum
end SumBalaban
