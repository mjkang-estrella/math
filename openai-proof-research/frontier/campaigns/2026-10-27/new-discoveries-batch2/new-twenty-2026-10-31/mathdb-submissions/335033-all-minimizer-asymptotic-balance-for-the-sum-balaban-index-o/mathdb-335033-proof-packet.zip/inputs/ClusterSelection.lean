import ProductCorrection
import OptimalTrialEventually
namespace SumBalaban
theorem source_c_fourth : c^4=Q := by
  have h1 := Real.sq_sqrt (le_of_lt (Real.sqrt_pos.mpr Q_pos))
  have h2 := Real.sq_sqrt (le_of_lt Q_pos)
  unfold c
  nlinarith

theorem correction_at_optimal_radius {x y : ℝ}
    (hq : x^2+y^2=2*c^2) :
    correctionG x y=(c^2+1)/(2*c^2)*(x^3+y^3) := by
  have hc := c_pos
  unfold correctionG
  dsimp only
  rw [hq,←source_c_fourth]
  field_simp
  ring

theorem optimal_cluster_forced_balanced {x y : ℝ} (hx : 0≤x) (hy : 0≤y)
    (hq : x^2+y^2=2*c^2) (hG : correctionG x y≤correctionG c c) :
    x=c ∧ y=c := by
  obtain ⟨hl,he⟩ := angular_cubic hx hy c_pos hq
  have h1 := correction_at_optimal_radius hq
  have h2 := correction_at_optimal_radius (x:=c) (y:=c) (by ring)
  rw [h1,h2] at hG
  have hp : 0<(c^2+1)/(2*c^2) := by have := c_pos; positivity
  have hu : x^3+y^3≤2*c^3 := by nlinarith only [hG,hp]
  exact he.mp (le_antisymm hu hl)
#print axioms source_c_fourth
#print axioms correction_at_optimal_radius
#print axioms optimal_cluster_forced_balanced
end SumBalaban
