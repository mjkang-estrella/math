import MinimizingCluster
import Mathlib.Topology.Sequences
namespace SumBalaban
open Filter
set_option maxHeartbeats 800000

theorem every_minimizer_pair_limit {f : ℕ → Triple}
    (hf : ∀ᶠ n in atTop, minimizes n (f n)) :
    Tendsto (fun n => (normA (f n) n,normD (f n) n)) atTop (nhds (c,c)) := by
  let z : ℕ → ℝ × ℝ := fun n => (normA (f n) n,normD (f n) n)
  have hbox : ∀ᶠ n in atTop, z n ∈ (Set.Icc (0:ℝ) 32) ×ˢ (Set.Icc (0:ℝ) 32) := by
    filter_upwards [hf,eventually_ge_atTop 2048] with n hm hn
    obtain ⟨h1,h2,h3,h4,_,_,_⟩ := every_minimizer_annulus hn hm
    exact ⟨⟨h1,h2⟩,⟨h3,h4⟩⟩
  apply Metric.tendsto_nhds.mpr
  intro ε hε
  by_contra hbad
  have hfreq : ∃ᶠ n in atTop, ε≤dist (z n) (c,c) := by
    simpa only [not_lt] using (not_eventually.mp hbad)
  let S : Set (ℝ × ℝ) := ((Set.Icc (0:ℝ) 32) ×ˢ (Set.Icc (0:ℝ) 32)) ∩
    {p | ε≤dist p (c,c)}
  have hcompact : IsCompact S :=
    (isCompact_Icc.prod isCompact_Icc).inter_right
      (isClosed_le continuous_const (continuous_id.dist continuous_const))
  have hfreqS : ∃ᶠ n in atTop, z n ∈ S := by
    exact (hfreq.and_eventually hbox).mono fun n hn => ⟨hn.2,hn.1⟩
  obtain ⟨p,hp,φ,hφ,hlim⟩ := hcompact.tendsto_subseq' hfreqS
  have hA : Tendsto (fun i => normA (f (φ i)) (φ i)) atTop (nhds p.1) :=
    (continuous_fst.tendsto p).comp hlim
  have hD : Tendsto (fun i => normD (f (φ i)) (φ i)) atTop (nhds p.2) :=
    (continuous_snd.tendsto p).comp hlim
  have hbalance := minimizing_cluster_balanced hf hφ.tendsto_atTop hA hD
  have hp0 : p=(c,c) := Prod.ext hbalance.1 hbalance.2
  have hh : ε≤dist p (c,c) := hp.2
  rw [hp0,dist_self] at hh
  linarith

theorem every_minimizer_radial_limit {f : ℕ → Triple}
    (hf : ∀ᶠ n in atTop, minimizes n (f n)) :
    Tendsto (fun n => (normA (f n) n)^2+(normD (f n) n)^2) atTop (nhds radialQ) := by
  have h := every_minimizer_pair_limit hf
  have hq0 : radialQ=c^2+c^2 := by
    unfold radialQ c
    rw [Real.sq_sqrt (le_of_lt (Real.sqrt_pos.mpr Q_pos))]
    ring
  rw [hq0]
  exact (((continuous_fst.tendsto (c,c)).comp h).pow 2).add
    (((continuous_snd.tendsto (c,c)).comp h).pow 2)

theorem source_target : SourceTarget := by
  intro f hf
  have hpair := every_minimizer_pair_limit hf
  have hA : Tendsto (fun n => normA (f n) n) atTop (nhds c) :=
    (continuous_fst.tendsto (c,c)).comp hpair
  have hD : Tendsto (fun n => normD (f n) n) atTop (nhds c) :=
    (continuous_snd.tendsto (c,c)).comp hpair
  refine ⟨hA,hD,?_⟩
  have hsmall := (hA.add hD).mul inverse_sqrt_limit
  have hlim : Tendsto (fun n => 1-(normA (f n) n+normD (f n) n)*(1/Real.sqrt (n:ℝ)))
      atTop (nhds 1) := by
    simpa only [mul_zero,sub_zero] using tendsto_const_nhds.sub hsmall
  apply hlim.congr'
  filter_upwards [hf,eventually_ge_atTop 1] with n hm hn
  have hn0 : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hs := Real.sqrt_pos.mpr hn0
  have hs2 := Real.sq_sqrt (le_of_lt hn0)
  have hsum : ((f n).1:ℝ)+((f n).2.1:ℝ)+((f n).2.2:ℝ)=(n:ℝ) := by exact_mod_cast hm.1.2.2.2.1
  dsimp only [normA,normD]
  field_simp
  nlinarith [hs2]
#print axioms every_minimizer_pair_limit
#print axioms every_minimizer_radial_limit
#print axioms source_target
end SumBalaban
