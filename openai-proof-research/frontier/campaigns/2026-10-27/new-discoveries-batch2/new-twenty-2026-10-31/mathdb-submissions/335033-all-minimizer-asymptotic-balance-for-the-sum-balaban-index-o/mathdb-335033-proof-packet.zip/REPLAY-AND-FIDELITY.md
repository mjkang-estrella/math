# Independent replay and source fidelity review v1

Target 335033. GPT-6.1 Sol / high / default. Review only; no acceptance, credit, count, ledger or publication action.

## Separate verdicts

| Gate | Verdict | Meaning |
|---|---|---|
| Primary identity | PASS for owned arXiv v1 only | Knor, Kranjc, Škrekovski, Tepeh, arXiv:1701.02716v1. The arXiv stamp is 2017-01-10; internal cover date is 2021-08-26. Neither is silently corrected. No journal-final equivalence. |
| Source statement fidelity | PASS, scoped | Conjecture 10, printed p11, and the owned raw target match the three asymptotic limits. The formal theorem proves the stronger universal eventual-choice statement. |
| Mathematical model | PASS, scoped | Actual finite simple graph, shortest-path transmissions, real SJ prefactor, all positive admissible triples, and actual edge sums. No surrogate objective or unproved graph bridge found. |
| Paper | PASS for stated three limits | Entire PAPER-v1.md personally read; retained unchanged. No extra finite-balance or global-connected-graph result credited. |
| Literal parser/binding | PASS, final v3 | 55 modules bound to independent root index, producer map, owned inputs, and extracted bytes. Strict final parser rejects all 13 negative controls. |
| Fresh compiles | PASS | All 55 production modules plus one new independent audit compiled from initially empty own src/build/cache. |
| Separate kernel checks | PASS | All 56 separately checked; actual helper and wrapper exits zero. |
| Expanded endpoint / axioms | PASS | Explicit f and competitor quantifiers, raw graph-edge objective and constant, three limits. 175 distinct declaration axiom reports, exact allowed names only. |
| Scope comparison | PASS for NEW 105th predicate | PureFlag finite nonunimodal face-vector refutation differs in objects, predicate, quantifiers and mechanism. Prior 104/373 comparisons remain inherited with their limits. |
| Process compliance | FAIL / defects UNWAIVED | See process inventory below. This is not a clean-history certification or an acceptance decision. |

## Actual source statement and model

The primary defines two DISJOINT cliques, disjoint from an actual b-vertex path; EVERY vertex of each clique joins its respective endpoint (pp5–6). It explicitly assumes a≤d. The owned raw record and Conjecture 10 concern this family, not the alternative dumbbell with two single bridges. The code uses Fin a ⊕ (Fin b ⊕ Fin d), with all corresponding adjacency cases. b=1 joins both cliques to the same path vertex without identifying clique vertices.

transmission is the finite sum of the actual SimpleGraph.dist. Distances proves coordinate lower bounds along every walk, explicit path/attachment upper bounds, and hence actual distances: path |i-j|, left-to-path i+1, path-to-right b-i, left-to-right b+1, and clique 0/1. Thus the polynomial transmission formulas are derived, not assumed. For a=d these reduce to primary Lemma 3: b²/2+ab+b/2+2a-1 in a clique, and i²/2+(b-i)²/2+ab-b/2+i+a on the path. These statements include b=1.

SJ uses m/(m-n+2) in REAL arithmetic after casts, multiplying the unordered-edge sum of 1/sqrt(w(u)+w(v)). It does not use the ordinary Balaban product. Real edge counting gives m=n-1+(a²+d²-a-d)/2; the denominator is positive. ActualFive derives both clique-interior terms, both attachment terms and the b-1 path terms through ordered sums/darts; there is no missing attachment set. Nat subtraction inside clique cardinalities is explicitly separate from the real denominator.

admissible imposes positive a,b,d, sum n, and a≤d; minimizes compares against EVERY admissible triple. Finite candidates contains precisely this set; (1,n-2,1) proves nonemptiness for n≥3 and minimum_attained gives actual attainment. Eventual quantification intentionally ignores the finite prefix n<3. The primary already uses reversal ordering, so no new family restriction is being substituted. Neither the target nor this review asserts Conjecture 9 (exact finite balance) or Conjecture 11 (global connected-graph minima).

## Proof review and hostile checks

The all-minimizer bound comes from a finite explicit coarse trial and SJ coercivity, not from selecting a balanced minimizer. It gives a²+d²≤512n and n≤1024(a²+d²), then 0≤x,y≤32 and q≥1/1024. No individual positive coordinate lower bound is imposed: bounded cliques and axis clusters remain in the domain.

The uniform expansion is an ACTUAL objective theorem. For fixed B≥0, δ>0 its K and N precede all a,b,d. Its common minimizer specialization uses B=512, δ=1/1024 and a fixed threshold. The clique inverse-root estimates, path polynomial/reference rectangle, endpoint integrals, real prefactor and mixed product are explicit statements in the inspected local source closure. They produce SJ=F(q)+G(x,y)/sqrt(n)+O(1/n) uniformly. The integral of 1/sqrt(u²+(1-u)²) is Q=sqrt(2)log(1+sqrt(2)), with the arsinh antiderivative proved in ReferenceValue. Endpoint estimates allow b=1 and cliques of order one; no interior-domain limit replaces the closed annulus.

For floor(c sqrt(n)) trials the proof establishes the normalized limit and eventual admissibility. Their expansion uses B=2c²+1 and δ=c², not an unproved numerical Q interval. Constants for trial and minimizer expansions may differ. Minimality combines these actual-objective expansions. The exact identity F(q)-F(q0)=(q-q0)²/(2q)≥0 is discarded BEFORE multiplying the next-order inequality by sqrt(n). Thus no radial convergence rate is assumed. The trial radial cost is O(1/n).

For any cofinal convergent subsequence, the common closed annulus gives nonnegative coordinates and positive q. Continuity and the first comparison force q=q0; the scaled comparison gives G(x,y)≤G(c,c). At radius 2c², the linear coefficient vanishes, and the angular cubic inequality forces x=y=c, including exclusion of axis limits. SourceEndpoint uses a compact CLOSED complement of an epsilon ball to rule out failure of full convergence, for every eventual minimizing choice. The exact sum identity gives b/n=1-(x+y)/sqrt(n)→1. No stronger asymptotic path expansion is claimed.

No mathematical/model/source gap was found in the reviewed scope. Kernel validity alone is not the reason for this fidelity verdict: the primary conventions, literal quantifiers, actual graph definitions and these bridge types/proofs were separately inspected.

## Honest personal read coverage

Mandatory instructions: TASK.txt in bounded chunks; research-root, batch2 and new-twenty AGENTS; writer/runner interfaces; formal helper interfaces; operative budgets, model/routing/authorization grants, owned-copy grant and relevant exact-work closure narratives. Documentary origin paths were not followed.

Primary: full PDF text extracted by installed pdftotext for machine indexing, NOT all personally read. Personally read primary-layout character ranges 0–5900, 12064–14064, 28600–30600, plus bounded heading/statement indexes. Material original pages 2,5,6,11,16 rendered through own writer and visually inspected, including both figures and their captions. The remainder of the PDF, including unrelated results and references, is not claimed as personally body-read. Primary PDF hash and provenance are in evidence-hashes.json. No new HTTP/search request occurred.

Raw target: entire owned inputs/mathdb-335033.raw.jsonl personally read. Paper: entire inputs/PAPER-v1.md personally read, in six bounded slices. SELF-v4 personally read; handoff portions read as recorded in handoff receipts. Historical qualifications and prior reports are inherited evidence, not fresh proof-body coverage.

All non-Audit production definition bodies and load-bearing theorem statements were personally inspected in source-statements-v2.txt (38125 characters, stm02–stm20 and proof01 overlapping final portion). This is an independently generated reading aid from owned source, with theorem bodies explicitly omitted; source bytes themselves were not reconstructed from it. Definitions include actual adjacency, SJ, objective, admissibility, minimizing, F/G, constants and target. The statement aid includes incidental instance bodies and some short proofs; that is not full body coverage.

Full or effectively complete critical proof reads: Dumbbell; Distances; SourceEndpoint; EventualComparison; TrialExpansion; MinimizerComparison; MinimizingCluster; MinimizerAnnulus; ReferenceValue. Exact partial reads: IndexTarget initial definitions and 1100–end (including finite-attainment proof); ActualFive 0–300, 650–end plus complete statement; UniformExpansion 0–3400; UniformEndpoint 1100–end plus complete statement; TrialExistence 1500–end; PathFirstCorrection 500–1300; Angular 300–950; TrialLimits 0–1200. These ranges are character offsets, not claimed line ranges. The final independent audit endpoint and graph/transmission/weight expansions were personally read from actual compiler output, auditread02–03. All other local proof bodies and remaining generated audit output received machine compile/check/axiom validation, not full personal line-by-line reading. No human audit of imported trusted mathlib proofs is claimed.

The main primary/model/paper and all load-bearing statement review preceded the large replay loop; later reads supplemented critical bridge bodies and actual generated audit output. The review does not claim that every local proof body was personally read before that loop.

## Strict extraction and fresh replay

Independent parser versions and actual failures are retained. No producer extractor, package or reproduction script was copied/executed. Root EXPECTED-SOURCES.json was treated as data. Final parser checks exact preamble bytes, anchored BEGIN header grammar, safe allowlisted unique module names, root bytes/hash, exact payload byte counts, paired same-name END markers, complete module coverage, exact separators and no trailing bytes. The actual appendix has no code fences; inserted fences are rejected. Module names cannot choose filesystem paths. Payload bytes are never reformatted.

Negative cases (in memory only): body alteration, forged hash header, forged matching body+header, missing module, duplicate module, unsafe path name, unknown module, mismatched end marker, inserted fence, changed preamble, trailing junk, lone trailing newline and wrong byte length. All 13 rejected. v1 rejected a harmless #print directive; v2 initially extracted correctly but accepted an extra final separator; v3 tightened only the independent parser. Same final v3 parsing rebinds all unchanged source copies. No production proof/definition was repaired.

Imports equal the producer map and are independently checked for dependency closure and DFS topological order. Only local allowlisted modules and specific existing Mathlib imports are allowed; no import Mathlib. Source scanning erases nested comments and string contents before checking prohibited commands/tokens and inspecting directives. Harmless comment words are not treated as proof commands.

src/build/cache were empty both at primary01 and the extraction assertion. Every production compile had NO prior own olean. No producer/intermediate scientific olean was supplied, copied or used. Cache remains empty. Implementation's 48 reused dependencies and 7 fresh modules are historical producer facts, not replay privilege. This review rebuilt all 55.

The only formal commands are the 112 exact taskset-prefixed wrapper invocations in final-formal-usage.json: for each module in topological-order.json, taskset -c 0,1 bash ./check32.sh MODULE fresh-NN-MODULE-compile, then taskset -c 0,1 bash ./checker32.sh MODULE fresh-NN-MODULE-check. Finally identical wrapper forms for IndependentAudit with independent-audit-compile and independent-audit-check. No raw Lean/lake/repl or extra replay loop.

Binary hashes and available mathlib metadata hashes matched PINS. Effective LEAN_PATH for EVERY call equals OWN build followed by the nine pinned read-only upstream paths (mathlib plus eight libraries); recorded in full in replay-verdict.json and every helper output. Standard Lean toolchain libraries remain implicit trusted upstream. This is not an independent upstream truth rebuild or full upstream olean provenance audit.

Every actual wrapper exit, helper receipt exit and inner Lean/checker exit is zero. Compile source SHA before/after matches the root index; every final artifact matches its producing receipt; checks preserve its hash. All 56 compiles were fresh; all 56 separate kernel checks passed. The independent endpoint expands the competitor predicate, actual real edge expression and constant, with no opaque expansion/annulus/trial/selection hypothesis. Its type was personally checked. Axiom reports are matched to EXACT allowed names after removing universe annotations, not allowed prefixes.

Usage: 112/128 formal calls; zero formal failures; 190.304420 total child CPU seconds; maximum single-call CPU 5.137538s, wall 5.155960s, sampled RSS 3301056512 bytes. Every helper enforces AS32GiB for compile/check only, RSS6GiB, CPU115/wall130, affinity 0,1, j1/M3500/warningsAsErrors/one Lean thread. No acquisition, search or scientific experiment runs. Full commands/stdout/stderr/resources are retained in labeled receipts, except the expressly disclosed pre-run shell failure below.

## Scope and process disposition

The new105 sanitized predicate is PureFlag's literal broad refutation for a finite pure flag complex on 540000 vertices with nonunimodal f-vector; its isolate-free graph conjecture remains unrefuted. It neither supplies nor subsumes universal actual-SJ minimizer asymptotics. Only that new predicate was freshly compared. Prior 104 scope comparisons, primary binding, bounded substantiality and dated373 qualification remain paid inherited qualifications with their recorded limitations. Closed journal-final and ordinary-Balaban predecessor bodies remain unread; no universal absence/novelty claim from missing searches is made.

UNWAIVED current defects:
1. Initial screening used target ID/version, topic fragments, author surnames/aliases and hosts, but not the complete normalized full-title/full-author set demanded by the task. Corrective complete recursive screening was saved later; it does not retroactively make earlier body reads prospectively compliant.
2. control01 displayed unmatched blocked-key prefixes and unrelated restriction snippets while reading a global rule. This violated the selective-narrative display rule; no such source was fetched.
3. paper06 attempted nonexistent inputs/SourceTarget.lean after displaying the requested paper tail. The failure, traceback and actual exit are retained; it was not silently counted as a successful read.
4. A functions-JavaScript parser authoring syntax failure executed no shell. The following attempted shell command was malformed by JavaScript replacement-string dollar expansion and failed before entering the capped runner. Tool transport clipped its error output; a complete on-disk stderr for that pre-run failure does NOT exist. This logging/display/runner defect cannot be cured by claiming a clean receipt. The independently authored parser source and cause are preserved; no proof source was changed.
5. extract02 failed on the too-restrictive harmless #print scanner; v1 and its receipt remain. v2 corrected the independent scanner, and v3 corrected trailing-separator rejection. No failed version was overwritten.
6. Commentary cadence exceeded 60 seconds during parser authoring and some verification preparation. Read/runner receipt suffixes were sometimes clipped at the outer pre-emission 2200-character bound; they remain full on disk. Earlier raw syntax-error transport did not meet this display discipline.
7. Root, implementation and earlier historical display/screen/cadence/formal failures remain unwaived as documented in the owned PROCESS-INVENTORY-v4.json; this review does not claim fresh reading of every unrelated historical scalar or erase those failures.

All mathematical source, paper and appendix bytes remain unchanged. No children, other-lane/origin body traversal, network/search, scientific experiment, git, installs, accounts, external messages, uploads, publication, acceptance or count action occurred. Process compliance FAIL remains separate from the scoped mathematical/fidelity/replay PASS. Root must adjudicate that process disposition; this file performs no acceptance administration.

All deliverable writes precede standalone frozen-after and final physical seal. The final seal excludes exactly PHYSICAL-SEAL-v1.json, seal-v1.receipt.json and seal-v1.output.txt; those are the manifest and its generating receipt/stdout. Final frozen/seal outcomes are independently visible in those artifacts, with no postseal command/write.
