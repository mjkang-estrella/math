import TrialExistence
namespace SumBalaban

theorem normalized_squares (a d n : ℕ) (hn : 0<n) :
    ((a:ℝ)/Real.sqrt n)^2+((d:ℝ)/Real.sqrt n)^2 = ((a:ℝ)^2+(d:ℝ)^2)/(n:ℝ) := by
  have hs := Real.sq_sqrt (show (0:ℝ)≤n by positivity)
  rw [div_pow,div_pow,hs]
  ring

theorem every_minimizer_annulus {n : ℕ} {t : Triple} (hn : 2048≤n)
    (ht : minimizes n t) :
    0≤(t.1:ℝ)/Real.sqrt n ∧ (t.1:ℝ)/Real.sqrt n≤32 ∧
    0≤(t.2.2:ℝ)/Real.sqrt n ∧ (t.2.2:ℝ)/Real.sqrt n≤32 ∧
    (1:ℝ)/1024 ≤ ((t.1:ℝ)/Real.sqrt n)^2+((t.2.2:ℝ)/Real.sqrt n)^2 ∧
    ((t.1:ℝ)/Real.sqrt n)^2+((t.2.2:ℝ)/Real.sqrt n)^2≤512 ∧
    (n:ℝ)-(t.2.1:ℝ)≤64*Real.sqrt n := by
  have hpos : (0:ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hspos := Real.sqrt_pos.mpr hpos
  have ⟨hup,hlo⟩ := every_minimizer_radial_bounds hn ht
  have hnorm := normalized_squares t.1 t.2.2 n (by omega)
  have hqup : ((t.1:ℝ)/Real.sqrt n)^2+((t.2.2:ℝ)/Real.sqrt n)^2≤512 := by
    rw [hnorm]
    exact (div_le_iff₀ hpos).mpr (by linarith)
  have hqlo : (1:ℝ)/1024 ≤ ((t.1:ℝ)/Real.sqrt n)^2+((t.2.2:ℝ)/Real.sqrt n)^2 := by
    rw [hnorm]
    exact (le_div_iff₀ hpos).mpr (by linarith)
  have hx : 0≤(t.1:ℝ)/Real.sqrt n := by positivity
  have hy : 0≤(t.2.2:ℝ)/Real.sqrt n := by positivity
  have hxup : (t.1:ℝ)/Real.sqrt n≤32 := by nlinarith [sq_nonneg ((t.2.2:ℝ)/Real.sqrt n)]
  have hyup : (t.2.2:ℝ)/Real.sqrt n≤32 := by nlinarith [sq_nonneg ((t.1:ℝ)/Real.sqrt n)]
  refine ⟨hx,hxup,hy,hyup,hqlo,hqup,?_⟩
  have ha := (div_le_iff₀ hspos).mp hxup
  have hd := (div_le_iff₀ hspos).mp hyup
  have htot : (t.1:ℝ)+(t.2.1:ℝ)+(t.2.2:ℝ)=n := by exact_mod_cast ht.1.2.2.2.1
  linarith

#print axioms normalized_squares
#print axioms every_minimizer_annulus
end SumBalaban
