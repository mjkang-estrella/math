import TransmissionLower
namespace SumBalaban
open scoped BigOperators

theorem SJ_nonneg (a b d : ℕ) (hb : 0<b) : 0≤SJ a b d := by
  classical
  have hw (e : Sym2 (Vertex a b d)) : 0≤edgeWeight e := by
    induction e using Sym2.inductionOn with
    | _ u v => rw [edgeWeight_formula]; positivity
  unfold SJ
  exact mul_nonneg (div_nonneg (by positivity) (le_of_lt (cycle_denominator_pos hb)))
    (Finset.sum_nonneg (fun e _ => hw e))

theorem SJ_upper_of_path {a b d : ℕ} (hb : 2≤b) :
    SJ a b d ≤ 2*(edgeCount a b d : ℝ)^2 /
      ((b:ℝ)*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2)) := by
  classical
  have hb0 : (0:ℝ)<b := by exact_mod_cast (show 0<b by omega)
  have hk := cycle_denominator_pos (a:=a) (d:=d) (show 0<b by omega)
  have hs : (∑ e ∈ (graph a b d).edgeFinset, edgeWeight e) ≤ (edgeCount a b d : ℝ)*(2/(b:ℝ)) := by
    calc
      _ ≤ ∑ _e ∈ (graph a b d).edgeFinset, (2/(b:ℝ)) :=
        Finset.sum_le_sum (fun e _ => edgeWeight_upper hb e)
      _ = _ := by simp only [Finset.sum_const,edgeCount, nsmul_eq_mul]
  have hm : (0:ℝ)≤(edgeCount a b d : ℝ)/((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2) := by positivity
  have h := mul_le_mul_of_nonneg_left hs hm
  change SJ a b d ≤ _ at h
  convert h using 1; field_simp

theorem balanced_trial_bound {k b : ℕ} (hk : 2≤k) (hb : 2≤b)
    (hsq : (k:ℝ)^2≤((k+b+k:ℕ):ℝ))
    (hsq' : ((k+b+k:ℕ):ℝ)≤4*(k:ℝ)^2)
    (hpath : ((k+b+k:ℕ):ℝ)/2≤b) : SJ k b k ≤ 128 := by
  have hkpos := cycle_denominator_pos (a:=k) (d:=k) (show 0<b by omega)
  have hpos : (0:ℝ)<(k+b+k : ℕ) := by exact_mod_cast (show 0<k+b+k by omega)
  have he := real_edge_count_formula (a:=k) (d:=k) (show 0<b by omega)
  have hk' : (2:ℝ)≤k := by exact_mod_cast hk
  have hm : (edgeCount k b k : ℝ) ≤ 2*(k+b+k : ℕ) := by nlinarith
  have hm0 : (0:ℝ)≤(edgeCount k b k : ℝ) := by positivity
  have hcycle : ((k+b+k:ℕ):ℝ)/8 ≤ (edgeCount k b k : ℝ)-(k+b+k : ℕ)+2 := by nlinarith [sq_nonneg ((k:ℝ)-1)]
  have hden : ((k+b+k:ℕ):ℝ)^2/16 ≤ (b:ℝ)*((edgeCount k b k : ℝ)-(k+b+k : ℕ)+2) := by
    have h := mul_le_mul hpath hcycle (show (0:ℝ)≤((k+b+k:ℕ):ℝ)/8 by positivity) (show (0:ℝ)≤b by positivity)
    nlinarith
  calc
    _ ≤ 2*(edgeCount k b k : ℝ)^2 / ((b:ℝ)*((edgeCount k b k : ℝ)-(k+b+k : ℕ)+2)) := SJ_upper_of_path hb
    _ ≤ (8*((k+b+k:ℕ):ℝ)^2) / ((b:ℝ)*((edgeCount k b k : ℝ)-(k+b+k : ℕ)+2)) := by
      apply div_le_div_of_nonneg_right
      · nlinarith
      · positivity
    _ ≤ (8*((k+b+k:ℕ):ℝ)^2) / (((k+b+k:ℕ):ℝ)^2/16) :=
      div_le_div_of_nonneg_left (by positivity) (by positivity) hden
    _ = 128 := by field_simp; norm_num

#print axioms SJ_upper_of_path
#print axioms balanced_trial_bound
end SumBalaban
