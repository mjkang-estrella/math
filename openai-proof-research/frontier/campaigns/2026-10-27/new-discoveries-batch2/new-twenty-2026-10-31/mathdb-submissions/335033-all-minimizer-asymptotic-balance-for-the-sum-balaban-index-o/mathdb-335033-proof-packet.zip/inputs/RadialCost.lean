import CliqueError
namespace SumBalaban
noncomputable def radialF (q : ℝ) : ℝ := q/2+1+Q+2*Q/q
noncomputable def radialQ : ℝ := 2*Real.sqrt Q

theorem radialQ_pos : 0<radialQ := mul_pos (by norm_num) (Real.sqrt_pos.mpr Q_pos)

theorem radial_excess {q : ℝ} (hq : 0<q) :
    radialF q-radialF radialQ = (q-radialQ)^2/(2*q) := by
  have hsq := Real.sq_sqrt (le_of_lt Q_pos)
  have hspos := Real.sqrt_pos.mpr Q_pos
  unfold radialF radialQ
  field_simp
  nlinarith

theorem radial_excess_nonneg {q : ℝ} (hq : 0<q) :
    0≤radialF q-radialF radialQ := by rw [radial_excess hq]; positivity

theorem radial_cost_bound {q δ L e : ℝ} (hδ : 0<δ) (hq : δ≤q)
    (_hL : 0≤L) (_he : 0≤e) (herr : |q-radialQ|≤L*e) :
    radialF q-radialF radialQ ≤ L^2*e^2/(2*δ) := by
  have hq0 : 0<q := lt_of_lt_of_le hδ hq
  have habs := abs_le.mp herr
  have hs : (q-radialQ)^2≤L^2*e^2 := by
    have hprod := mul_nonneg (show 0≤L*e-(q-radialQ) by linarith)
      (show 0≤L*e+(q-radialQ) by linarith)
    nlinarith
  rw [radial_excess hq0]
  calc
    _ ≤ (L^2*e^2)/(2*q) := div_le_div_of_nonneg_right hs (by positivity)
    _ ≤ _ := div_le_div_of_nonneg_left (by positivity) (by positivity) (by linarith)

#print axioms radial_excess
#print axioms radial_cost_bound
end SumBalaban
