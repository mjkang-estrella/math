import ShiftedTransmission
namespace SumBalaban
open scoped BigOperators

theorem distance_le_order {a b d : ℕ} (hb : 0 < b) (u v : Vertex a b d) :
    (graph a b d).dist u v ≤ a+b+d := by
  rcases u with i | i <;> rcases v with j | j
  · rw [left_left_dist]; split_ifs <;> omega
  · rcases j with j | j
    · rw [left_path_dist hb]; have := j.isLt; omega
    · rw [left_right_dist hb]; have := i.isLt; have := j.isLt; omega
  · rcases i with i | i
    · rw [SimpleGraph.dist_comm, left_path_dist hb]; have := i.isLt; omega
    · rw [SimpleGraph.dist_comm, left_right_dist hb]; have := i.isLt; have := j.isLt; omega
  · rcases i with i | i <;> rcases j with j | j
    · rw [path_dist hb]; split_ifs <;> (have := i.isLt; have := j.isLt; omega)
    · rw [path_right_dist hb]; omega
    · rw [SimpleGraph.dist_comm, path_right_dist hb]; omega
    · rw [right_right_dist]; split_ifs <;> omega

theorem transmission_le_order_sq {a b d : ℕ} (hb : 0 < b) (u : Vertex a b d) :
    transmission u ≤ (a+b+d)^2 := by
  calc
    transmission u ≤ ∑ _v : Vertex a b d, (a+b+d) :=
      Finset.sum_le_sum (fun v _ => distance_le_order hb u v)
    _ = (a+b+d)^2 := by simp [pow_two, Nat.add_assoc]

theorem transmission_pos_of_adj {a b d : ℕ} {u v : Vertex a b d}
    (h : (graph a b d).Adj u v) : 0 < transmission u := by
  have hs : (graph a b d).dist u v ≤ transmission u :=
    Finset.single_le_sum (fun x _ => Nat.zero_le ((graph a b d).dist u x)) (Finset.mem_univ v)
  rw [SimpleGraph.dist_eq_one_iff_adj.mpr h] at hs
  omega

theorem edgeWeight_lower {a b d : ℕ} (hb : 0 < b) (e : Sym2 (Vertex a b d))
    (he : e ∈ (graph a b d).edgeSet) :
    1 / (2*(a+b+d : ℕ) : ℝ) ≤ edgeWeight e := by
  induction e using Sym2.inductionOn with
  | _ u v =>
    have ha : (graph a b d).Adj u v := he
    have hu := transmission_le_order_sq hb u
    have hv := transmission_le_order_sq hb v
    have hp := transmission_pos_of_adj ha
    have hn : (0:ℝ) < (a+b+d : ℕ) := by exact_mod_cast (show 0<a+b+d by omega)
    have hpos : (0:ℝ) < (transmission u : ℝ)+(transmission v : ℝ) := by positivity
    have hs : Real.sqrt ((transmission u : ℝ)+(transmission v : ℝ)) ≤ 2*(a+b+d : ℕ) := by
      apply Real.sqrt_le_iff.mpr
      constructor
      · positivity
      · have hu' : (transmission u : ℝ) ≤ ((a+b+d : ℕ):ℝ)^2 := by exact_mod_cast hu
        have hv' : (transmission v : ℝ) ≤ ((a+b+d : ℕ):ℝ)^2 := by exact_mod_cast hv
        nlinarith [sq_nonneg (((a+b+d : ℕ):ℝ))]
    rw [edgeWeight_formula]
    exact one_div_le_one_div_of_le (Real.sqrt_pos.mpr hpos) hs

#print axioms distance_le_order
#print axioms transmission_le_order_sq
#print axioms transmission_pos_of_adj
#print axioms edgeWeight_lower
end SumBalaban
