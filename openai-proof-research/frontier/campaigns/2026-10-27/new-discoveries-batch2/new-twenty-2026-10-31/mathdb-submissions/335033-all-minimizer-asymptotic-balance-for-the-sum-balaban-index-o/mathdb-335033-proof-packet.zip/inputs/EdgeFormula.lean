import EdgeCounts
namespace SumBalaban
open scoped BigOperators

theorem path_neighbor_count {b : ℕ} (i : Fin b) :
    (∑ j : Fin b, if i.val+1=j.val ∨ j.val+1=i.val then (1:ℕ) else 0) =
      (if i.val + 1 < b then 1 else 0) + (if (0 : ℕ) < i.val then 1 else 0) := by
  classical
  have hs (j : Fin b) :
      (if i.val+1=j.val ∨ j.val+1=i.val then (1:ℕ) else 0) =
      (if i.val+1=j.val then 1 else 0) + (if j.val+1=i.val then 1 else 0) := by
    split_ifs <;> omega
  simp_rw [hs]
  rw [Finset.sum_add_distrib]
  have hnext : (∑ j : Fin b, if i.val+1=j.val then (1:ℕ) else 0) =
      if i.val + 1 < b then 1 else 0 := by
    by_cases h : i.val + 1 < b
    · have he (j : Fin b) : i.val+1=j.val ↔ j=⟨i.val+1,h⟩ := by
        constructor <;> intro he
        · exact Fin.ext he.symm
        · subst j; rfl
      simp_rw [he]
      simp only [Finset.sum_ite_eq', Finset.mem_univ, ite_true, h]
    · have he (j : Fin b) : ¬i.val+1=j.val := by have := j.isLt; omega
      simp only [he, h, ite_false, Finset.sum_const_zero]
  have hprev : (∑ j : Fin b, if j.val+1=i.val then (1:ℕ) else 0) =
      if (0 : ℕ) < i.val then 1 else 0 := by
    by_cases h : (0 : ℕ) < i.val
    · have he (j : Fin b) : j.val+1=i.val ↔ j=⟨i.val-1,by omega⟩ := by
        constructor <;> intro he
        · apply Fin.ext; dsimp only; omega
        · subst j; dsimp only; omega
      simp_rw [he]
      simp only [Finset.sum_ite_eq', Finset.mem_univ, ite_true, h]
    · have he (j : Fin b) : ¬j.val+1=i.val := by omega
      simp only [he, h, ite_false, Finset.sum_const_zero]
  rw [hnext,hprev]

theorem sum_path_degrees {a b d : ℕ} (hb : 0<b) :
    (∑ i : Fin b, (graph a b d).degree (path i)) = a+d+2*(b-1) := by
  classical
  have hzero (i : Fin b) : i.val=0 ↔ i=⟨0,hb⟩ := by
    constructor
    · exact fun h => Fin.ext h
    · intro h; subst i; rfl
  have hlast (i : Fin b) : i.val+1=b ↔ i=⟨b-1,by omega⟩ := by
    constructor
    · intro h; apply Fin.ext; dsimp only; omega
    · intro h; subst i; dsimp only; omega
  have hnext (i : Fin b) : (if i.val + 1 < b then (1:ℕ) else 0) =
      if (⟨b-1,by omega⟩ : Fin b)=i then 0 else 1 := by
    split_ifs <;> simp_all [Fin.ext_iff] <;> omega
  have hprev (i : Fin b) : (if (0 : ℕ) < i.val then (1:ℕ) else 0) =
      if (⟨0,hb⟩ : Fin b)=i then 0 else 1 := by
    split_ifs <;> simp_all [Fin.ext_iff]
  simp_rw [path_degree_sum, path_neighbor_count, hzero, hlast, hnext, hprev]
  simp only [Finset.sum_add_distrib, Finset.sum_ite_eq', Finset.mem_univ, ite_true, clique_sum]
  omega

theorem twice_edge_count {a b d : ℕ} (hb : 0<b) :
    2*edgeCount a b d = a*a+d*d+a+d+2*(b-1) := by
  classical
  have h := (graph a b d).sum_degrees_eq_twice_card_edges
  rw [Fintype.sum_sum_type, Fintype.sum_sum_type] at h
  have hl : (∑ u : Fin a, (graph a b d).degree (left u)) = a*a := by
    simp only [left_degree hb,Finset.sum_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul]
  have hr : (∑ u : Fin d, (graph a b d).degree (right u)) = d*d := by
    simp only [right_degree hb,Finset.sum_const,Finset.card_univ,Fintype.card_fin,smul_eq_mul]
  rw [hl,hr,sum_path_degrees hb] at h
  change a*a+(a+d+2*(b-1)+d*d)=2*edgeCount a b d at h
  omega

#print axioms path_neighbor_count
#print axioms sum_path_degrees
#print axioms twice_edge_count
end SumBalaban
