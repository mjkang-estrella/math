# FINAL QUALIFICATION — MathDB 335033
Contribution: SUBSTANTIAL WITHIN THE SUPPLIED BOUNDED EVIDENCE. Credit 0.
The root-routed ordinary correctness / owned-arXiv-v1 fidelity PASS is retained as an input; no new correctness review or source change is issued. This is a decisive contribution judgment, not final acceptance or worldwide novelty certification. Counts remain 65/80 NEW,104 total.

## Exact result and materiality
For every sequence of minimizing positive integer triples a+b+d=n, a<=d, for the source's all-vertex-attachment dumbbell, both a/sqrt(n) and d/sqrt(n) tend to c=Q^(1/4), Q=sqrt(2)log(1+sqrt(2)). Hence b=n-2c sqrt(n)+o(sqrt(n)). The objective is SJ=m/(m-n+2) sum_edges (w(u)+w(v))^(-1/2), with genuine graph-distance transmissions. Ordinary Balaban has a PRODUCT under the radical. The candidate proves neither exact finite balance, global optimality among all connected graphs, nor journal-final equivalence.

Theorem 7, equation (9), and Corollary 8 of the owned arXiv:1701.02716v1 prove balanced radial optimization. Lemma 3 supplies balanced transmissions, Proposition 5 the path integral, and Lemma 6 a leading equivalence. Restricting their conclusions to a=d cannot cover minimizers over all triples. Even extending only leading order leaves the entire arc x^2+y^2=2sqrt(Q) undetermined, including an axis. This is a mathematical obstruction to a literal old-theorem specialization, not an inference from an open label.

The surviving target-specific step is the uniform n^(-1/2) correction and selection on that flat arc. It requires accounting for all attachment edges, the missing integration endpoints, integer trials and possible bounded-clique limits at a precision the supplied old equivalences discard. Elementary estimates are sufficient, but the estimates accomplish the target's unresolved angular selection. Shortness and familiar calculus do not turn that new, load-bearing selection argument into a parameter instance of the balanced result.

## Strongest TECHNICAL contrary case, fully paid
Here is the complete adaptation that makes the technical objection serious. Its unequal-clique formulas and uniform correction are reconstructed candidate work, not attributed to an unread old theorem.

Write S1=a+d,S2=a^2+d^2,k=m-n+2. Edge partition gives m=n-1+(S2-S1)/2,k=1+(S2-S1)/2. Exact transmissions are
L=a-1+b(b+1)/2+d(b+1),
W_i=i(i+1)/2+(b-1-i)(b-i)/2+a(i+1)+d(b-i).
With t=i+a, W_i=t^2-(n-1)t+n(n-1)/2-(S2-S1)/2 and L-W_0=n-a-1; exchange sides for R.

A balanced rounded trial gives SJ<=M. Equation (2)'s universal transmission bound w<=n(n-1)/2 implies SJ>=m^2/(nk). Thus m<=Mn and k>=(n-1)^2/(Mn). Since S2-S1=2(k-1), and S2-S1>=S2/2-1, all minimizers have a,d<=C sqrt(n), S2/n>=delta>0 and b=n-O(sqrt(n)). This covers short-path escape and retains one bounded clique without assuming either clique has a positive scaled limit.

Put e=n^(-1/2), x=a/sqrt(n), y=d/sqrt(n), q=x^2+y^2,s=x+y,r=x^3+y^3. On 0<=x,y<=C,q>=delta, L=n^2/2-an+O_C(n). Both internal-clique and attachment inverse radicals equal 1/n+a/n^2+O_C(n^-2): normalized arguments are 1-2a/n+O_C(1/n), with uniformly bounded second derivative near 1. Multiplying by binom(a,2)+a gives a^2/(2n)+a/(2n)+a^3/(2n^2)+O_C(1/n). Both sides total q/2+e(r+s)/2+O_C(e^2). The omitted a^2/(2n^2) and edge-count times remainder are O_C(1/n), including a=1.

For a path edge, phi(u)=u^2+(1-u)^2>=1/2,u=t/n, and the exact remainder is
W_i+W_(i+1)=n^2 phi(u)+4t-2n+2-S2+S1.
The final terms are O_C(n). The inverse radical is f(u)/n+O_C(n^-2), f=phi^-1/2, totaling O_C(1/n) error. Rectangle integration error is <=||f'||/(2n); the one-cell endpoint shift costs <=||f||/n. Removed endpoint integrals equal (a+d)/n with error <=||f'||(a^2+d^2)/(2n^2). Thus path sum=Q-es+O_C(e^2). No uncontrolled endpoint or axis limit remains.

Total edge sum=q/2+Q+e(r-s)/2+O_C(e^2). Since k/n=q/2-es/2+e^2 and q>=delta, uniformly
m/k=1+2/q+2es/q^2+O_(C,delta)(e^2).
Consequently SJ=F(q)+eG(x,y)+O_(C,delta)(e^2), where
F=q/2+1+Q+2Q/q,
G=(q+2)r/(2q)+s(-1/2+2Q/q^2).
All errors have one constant and threshold for the entire annulus, including both axes as limits.

At q0=2sqrt(Q), F(q)-F(q0)=(q-q0)^2/(2q)>=0. A nearest-integer balanced trial has q=q0+O(e), radial cost O(e^2), and value F(q0)+eG(c,c)+O(e^2). First, compactness and the uniform expansion imply q_n->q0 for every minimizing sequence. Then
F(q_n)-F(q0)+e(G(x_n,y_n)-G(c,c))<=K e^2.
Discard the nonnegative radial excess and divide by e. Every subsequential limit satisfies G(x,y)<=G(c,c),q=q0. At q0 the s coefficient vanishes; strict convexity of z^(3/2) gives x^3+y^3>=2(q0/2)^(3/2), equality only x=y=c. Axis limits are strictly worse. Every subsequential limit is balanced, so all minimizers converge. No radial rate or finite experiment is assumed.

This closes the adaptation mathematically, but does NOT close an OLD-material specialization: the supplied old results lack the unequal uniform expansion and flat-minimum selection just derived. Labeling those derivations “the old theorem” would assume the disputed contribution. The genuine extra step survives, so TECHNICAL/STOP0CREDIT is not established by this packet.

## Primary comparison, with exact limits
Owned source: Knor–Kranjc–Škrekovski–Tepeh, On the minimum value of sum-Balaban index, arXiv:1701.02716v1. Cover label 10 Jan 2017 and internal August 26,2021 are both preserved; no version equivalence inferred. Conjecture 10 (printed p11) is the asymptotic target; Conjecture 9 is finite balance for n>=14.

MATCH: Knor–Škrekovski–Tepeh, Mathematical Aspects of Balaban Index, MATCH79(2018)685–716, received August25,2017. Section3.2.1, pp698–699, defines unequal dumbbells, states finite balance as Conjecture27, then explicitly restricts to balanced graphs. Theorem28 is ordinary Balaban; its sum analogue and Corollary30 remain balanced. Theorem59 is a balanced accumulation-point assertion. Corollary30's unexplained r is not repaired or used. No inspected theorem supplies the uniform all-triples correction.

CroCoDays: same three authors, Sum-Balaban index and its properties, DOI10.5592/CO/CCD.2016.03. Proceedings event2016, imprint2017. Printed pp46–48 define endpoint joins, state balanced Theorem8 and Corollary9, finite-balance Conjecture10, and balanced accumulation Theorem12. These are actual inspected pages, not a summary substituted for the original journal method.

Journal2017 and ordinary-Balaban2016 bodies remain unread and closed. Their positive linkage is bibliographic/method ancestry, not evidence of an unequal-SJ selection theorem: the ordinary objective differs and the inspected source explicitly uses only its balanced lemma. No comparison predicate requiring a hidden body has been demonstrated. Therefore their unreadness alone is not a materiality HOLD. No worldwide exclusion or final-body equivalence is certified. The previous HOLD arguments were considered and resolved at this bounded contribution level; process defects are not waived.

## Released-result and registry comparisons
104-comparison.json binds all104 stable IDs and supplied statement digests, with per-record scope dispositions, plus all14 definition/endpoint supplements. All literal title/scope fields and all supplemental result/notation fields were personally read. Closest graph endpoints were additionally inspected: new62-007 sigma_t,018 Kirchhoff,059 biharmonic,062 Q-index,next9-006 Steiner tensor; new62-053 uses “balanced” in an unrelated clique-parity sense. None supplies SJ dumbbell selection. Auxiliary undefined special-function symbols in unrelated supplements do not create plausible overlap. No protected proof, plan, code or origin was read.

Registry limitation is explicit: the owned release attests373 families/721 manuscripts but contains only five candidate-family statements; the imset provenance packet supplies12 further actual statements. All17 were personally compared in registry-comparison.json. Its imset verdict is not adopted as a Sum-Balaban clearance. Dated documented head4eaee87548250b2682affda7d05d947c05554bae, acquired2026-11-14T22:26:16.636Z; catalogue snapshot22:28:25.825Z, blob7e1ed90ac5a666f1bbecb22027387c4ad79e9d03. No live head acquired here. The remaining356 catalogue statements are not supplied. Full-registry acceptance comparison is administratively incomplete; no mathematical overlap is inferred from that lack. Minimal completion field is the dated hash-bound literal result statements, never manuscript/proof/code bodies. No registry request or permission question is made. This is not an identified comparison-changing mathematical gap and does not reverse bounded SUBSTANTIAL.

## SELF / HANDOFF and process
Hostile objection: this is merely one more Taylor term. Answer: the leading minimum is nonisolated, so one more term is exactly the load-bearing result, with uniform minimizer localization and selection necessary for the source quantifier. Conversely no claim is made that the formula alone proves worldwide novelty. A genuine old theorem supplying that complete uniform bridge would change the verdict to STOP0CREDIT; none is supplied.

No unresolved mathematical predicate is asserted; the ordinary/fidelity PASS is inherited. Registry coverage, raw MathDB exact-byte binding, process adjudication, Lean/paper/replay and final acceptance remain separately unpaid. FORMAL-FEASIBILITY.md is a planning assessment only, not authorization or an API audit.

All inherited process failures in the four complete reports remain UNWAIVED, including wrong cwd/path, oversized/multiple-runner displays, substring/host/ownership-origin displays, incomplete prospective control authentication and incomplete original search-response preservation. New defects: instructions-12 generated a too-large display candidate; the outer guard rejected it before any payload was printed, and its full output/receipt remain on disk. registry-02 failed because candidate_scopes was a list, not a dict; preserved. Initial helper-interface discovery was direct shell before using the runner. screen-01 displayed documentary ownership-origin strings; none followed. No clean process PASS is claimed. These defects do not automatically prove or disprove contribution.

ZERO network/search/scientific prototypes/Lean/git/children/installs/accounts/messages/uploads/publication or shared-ledger edits. Documentary Python/Poppler alone ran under the capped runner after interface discovery. All writes use write_lane.py; frozen inputs untouched subject to standalone after check. No credit/count mutation. Reading source PDFs and mandatory historical mentions is not new MathDB breadth.

Finish all writes, standalone frozen-after, then exhaustive physical seal with exactly manifest/generating receipt/stdout excluded. Actual final outcomes are established by those receipts; no postseal commands or writes.
