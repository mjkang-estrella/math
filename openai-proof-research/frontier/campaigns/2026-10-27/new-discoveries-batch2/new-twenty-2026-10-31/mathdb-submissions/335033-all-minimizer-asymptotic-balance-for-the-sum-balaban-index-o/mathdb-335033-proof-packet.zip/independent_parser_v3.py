"""Independent literal parser authored in this review."""
from pathlib import Path
import hashlib,json,re,subprocess,base64
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,data):
 if isinstance(data,str):data=data.encode()
 r=subprocess.run(['python3','-I','-B','write_lane.py',name,'--base64'],input=base64.b64encode(data).decode(),text=True,capture_output=True)
 assert r.returncode==0,r.stderr
rows=json.loads(Path('inputs/EXPECTED-SOURCES.json').read_text())['modules']
allow={r['module']:r for r in rows}
assert len(rows)==len(allow)==55
assert all(re.fullmatch('[A-Za-z][A-Za-z0-9_]*',n) and r['owned_copy']=='inputs/'+n+'.lean' for n,r in allow.items())
pm=json.loads(Path('inputs/SOURCE-MAP-v4.json').read_text())['modules']
producer={r['module']:r for r in pm};assert set(producer)==set(allow) and len(pm)==55
HEAD=re.compile(rb'@@SB335033_LITERAL_SOURCE_V4 BEGIN ([A-Za-z][A-Za-z0-9_]*) ([1-9][0-9]*) ([0-9a-f]{64})@@\n')
def parse(b):
 assert len(b)>=2566 and sha(b[:2566])=='9587847286cde7bbf991bec0c27e5fceebccda2b321be1ab3d82a0a0de45a15a','preamble'
 pos=2566;out={}
 while pos<len(b):
  m=HEAD.match(b,pos);assert m,'header'
  name=m[1].decode();assert name in allow and name not in out,'unsafe/unknown/duplicate'
  r=allow[name];size=int(m[2]);assert size==r['bytes'] and m[3].decode()==r['sha256'],'forged header'
  end=m.end()+size;payload=b[m.end():end];payload.decode('utf-8')
  assert len(payload)==size and sha(payload)==r['sha256'],'body'
  tail=b'\n@@SB335033_LITERAL_SOURCE_V4 END '+name.encode()+b'@@\n'
  assert b[end:end+len(tail)]==tail,'paired end'
  out[name]=payload;pos=end+len(tail)
  if pos<len(b):
   assert b[pos:pos+1]==b'\n','separator';pos+=1
   assert pos<len(b),'trailing separator'
 assert set(out)==set(allow),'missing coverage'
 return out
def lex(s):
 out=[];i=0;depth=0
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;i+=2
   elif s.startswith('-/',i):depth-=1;i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif s.startswith('/-',i):depth=1;i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);j=len(s) if j<0 else j;out.extend(' '*(j-i));i=j
  elif s[i]=='"':
   out.append(' ');i+=1
   while i<len(s):
    if s[i]=='\\':i+=2
    elif s[i]=='"':i+=1;break
    else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
def main():
 assert all(not list(Path(p).iterdir()) for p in ['src','build','cache']),'freshness'
 b=Path('inputs/SOURCE-APPENDIX-v4.md').read_bytes();out=parse(b)
 cases={};m=HEAD.match(b,2566);end=m.end()+int(m[2])
 variants={
 'body_alteration':b[:m.end()]+bytes([b[m.end()]^1])+b[m.end()+1:],
 'forged_header':b[:2566]+m[0].replace(m[3],b'0'*64)+b[m.end():],
 'trailing':b+b'junk',
 'trailing_newline':b+b'\n',
 'wrong_length':b[:2566]+m[0].replace(m[2],str(int(m[2])+1).encode())+b[m.end():],
 'missing':b[:2566]+b[end+len(b'\n@@SB335033_LITERAL_SOURCE_V4 END Dumbbell@@\n\n'):],
 'duplicate':b+b'\n'+b[2566:end]+b'\n@@SB335033_LITERAL_SOURCE_V4 END Dumbbell@@\n',
 'unsafe':b[:2566]+b[2566:].replace(b'BEGIN Dumbbell',b'BEGIN ../Dumbbell',1),
 'unknown':b[:2566]+b[2566:].replace(b'BEGIN Dumbbell',b'BEGIN Unknown',1),
 'mismatched':b[:end]+b[end:].replace(b'END Dumbbell',b'END Distances',1),
 'fence':b[:2566]+bytes([96])*3+b'lean\n'+b[2566:],
 'preamble':b'X'+b[1:]}
 changed=out['Dumbbell'].replace(b'import',b'Import',1)
 variants['forged_body_and_header']=b[:2566]+m[0].replace(m[3],sha(changed).encode())+changed+b[end:]
 for n,v in variants.items():
  try:parse(v)
  except (AssertionError,UnicodeError):cases[n]='rejected'
  else:raise AssertionError('negative accepted '+n)
 deps={};external=set();index=[]
 for n,payload in out.items():
  r=allow[n];assert Path(r['owned_copy']).read_bytes()==payload,'owned mismatch'
  pr=producer[n];assert pr['source_sha256']==sha(payload) and pr['source_bytes']==len(payload)
  s=lex(payload.decode());tokens=re.findall(r'[A-Za-z_][A-Za-z0-9_]*',s)
  assert not set(tokens)&{'sorry','admit','axiom','unsafe','native_decide','implemented_by','extern','run_tac','eval_expr'}
  for directive in re.findall(r'(?m)^#.*$',s):
   assert re.fullmatch(r'#print (?:axioms )?[A-Za-z0-9_.]+',directive) or directive=='#eval Lean.versionString',directive
  imports=[]
  for line in s.splitlines():
   if line.startswith('import '):imports.extend(line[7:].split())
  assert imports==pr['imports'],('imports',n)
  assert all(x in allow or x.startswith('Mathlib.') for x in imports)
  external.update(x for x in imports if x not in allow);deps[n]=[x for x in imports if x in allow]
  index.append({'module':n,'sha256':sha(payload),'bytes':len(payload),'imports':imports})
 order=[];active=set()
 def visit(n):
  if n in order:return
  assert n not in active,'cycle';active.add(n)
  for x in deps[n]:visit(x)
  active.remove(n);order.append(n)
 for n in out:visit(n)
 pins=json.loads(Path('PINS.json').read_text());pinresults={}
 for kind in ['lean','leanchecker']:
  p=Path(pins[kind+'_bin']);assert sha(p.read_bytes())==pins[kind+'_sha256'];pinresults[kind]=sha(p.read_bytes())
 for name,h in pins['mathlib_metadata_sha256'].items():
  q=Path(pins['mathlib_source'])/name;assert sha(q.read_bytes())==h;pinresults[name]=h
 for x in external:
  assert (Path(pins['upstream_lean_paths'][0])/Path(*x.split('.'))).with_suffix('.olean').is_file(),x
 for n,payload in out.items():write('src/'+n+'.lean',payload)
 write('independent-source-index.json',json.dumps(index,indent=2))
 write('topological-order.json',json.dumps(order))
 write('parser-verdict.json',json.dumps({'status':'PASS','initial_src_build_cache_empty':True,'negative_controls':cases,'pins':pinresults,'external_imports':sorted(external),'appendix_sha256':sha(b)},indent=2))
 print('Independent parser PASS; 55 exact owned/root/producer bindings; 11 negative controls rejected; pins verified; fresh extraction only.')
if __name__=='__main__':main()
