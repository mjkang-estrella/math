import SourceEndpoint
import AuditV3
namespace SumBalaban
-- Expanded endpoint: no selection, annulus, expansion, or convergence hypotheses.
theorem all_eventually_minimizing_choices :
    ∀ f : ℕ → Triple, (∀ᶠ n in Filter.atTop, minimizes n (f n)) →
    Filter.Tendsto (fun n => ((f n).1:ℝ)/Real.sqrt n) Filter.atTop (nhds c) ∧
    Filter.Tendsto (fun n => ((f n).2.2:ℝ)/Real.sqrt n) Filter.atTop (nhds c) ∧
    Filter.Tendsto (fun n => ((f n).2.1:ℝ)/(n:ℝ)) Filter.atTop (nhds 1) := source_target
#print SourceTarget
#print all_eventually_minimizing_choices
#print axioms all_eventually_minimizing_choices
#print axioms source_target
#print axioms every_minimizer_pair_limit
#print axioms every_minimizer_radial_limit
#print axioms minimizing_cluster_balanced
#print axioms minimizer_eventual_comparison
#print axioms minimizer_eventual_expansion
#print axioms comparison_algebra
#print axioms trial_eventual_expansion
#print axioms general_uniform_expansion
#print axioms trial_normalized_limit
#print axioms inverse_sqrt_limit
#print axioms common_uniform_expansion
#print axioms optimal_cluster_forced_balanced
#print axioms SJ
#print axioms minimum_attained
end SumBalaban
