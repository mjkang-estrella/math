import GeometryCounts
import Mathlib.Algebra.BigOperators.Ring.Finset
namespace SumBalaban
open scoped BigOperators

theorem degree_as_sum {a b d : ℕ} (u : Vertex a b d) :
    (graph a b d).degree u = ∑ v : Vertex a b d, if (graph a b d).Adj u v then 1 else 0 := by
  classical
  have hf : Finset.univ.filter ((graph a b d).Adj u) = (graph a b d).neighborFinset u := by
    ext v
    simp
  rw [←SimpleGraph.card_neighborFinset_eq_degree, ←hf]
  exact (Finset.sum_boole ((graph a b d).Adj u) Finset.univ).symm

theorem left_degree {a b d : ℕ} (hb : 0<b) (u : Fin a) :
    (graph a b d).degree (left u) = a := by
  classical
  rw [degree_as_sum, Fintype.sum_sum_type, Fintype.sum_sum_type]
  have hin (v : Fin a) : (if (graph a b d).Adj (left u) (left v) then 1 else 0 : ℕ) =
      if u=v then 0 else 1 := by
    split_ifs <;> simp_all [graph, Adj]
  have hp (j : Fin b) : (if (graph a b d).Adj (left u) (path j) then 1 else 0 : ℕ) =
      if j=⟨0,hb⟩ then 1 else 0 := by
    split_ifs <;> simp_all [graph, Adj, Fin.ext_iff]
  have hr (v : Fin d) : (if (graph a b d).Adj (left u) (right v) then 1 else 0 : ℕ) = 0 := rfl
  simp_rw [hin, hp, hr]
  rw [clique_sum]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, ite_true, Finset.sum_const_zero, add_zero]
  have ha := u.isLt
  omega

theorem right_degree {a b d : ℕ} (hb : 0<b) (u : Fin d) :
    (graph a b d).degree (right u) = d := by
  classical
  rw [degree_as_sum, Fintype.sum_sum_type, Fintype.sum_sum_type]
  have hin (v : Fin d) : (if (graph a b d).Adj (right u) (right v) then 1 else 0 : ℕ) =
      if u=v then 0 else 1 := by
    split_ifs <;> simp_all [graph, Adj]
  have hp (j : Fin b) : (if (graph a b d).Adj (right u) (path j) then 1 else 0 : ℕ) =
      if j=⟨b-1,by omega⟩ then 1 else 0 := by
    split_ifs <;> simp_all [graph, Adj, Fin.ext_iff] <;> omega
  have hl (v : Fin a) : (if (graph a b d).Adj (right u) (left v) then 1 else 0 : ℕ) = 0 := rfl
  simp_rw [hin, hp, hl]
  rw [clique_sum]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, ite_true, Finset.sum_const_zero, zero_add]
  have hd := u.isLt
  omega

theorem path_degree_sum {a b d : ℕ} (i : Fin b) :
    (graph a b d).degree (path i) =
      (if i.val=0 then a else 0) +
      (∑ j : Fin b, if i.val+1=j.val ∨ j.val+1=i.val then 1 else 0) +
      (if i.val+1=b then d else 0) := by
  classical
  rw [degree_as_sum, Fintype.sum_sum_type, Fintype.sum_sum_type]
  have hl (v : Fin a) : (if (graph a b d).Adj (path i) (left v) then 1 else 0 : ℕ) =
      if i.val=0 then 1 else 0 := by
    split_ifs <;> simp_all [graph, Adj]
  have hr (v : Fin d) : (if (graph a b d).Adj (path i) (right v) then 1 else 0 : ℕ) =
      if i.val+1=b then 1 else 0 := by
    split_ifs <;> simp_all [graph, Adj]
  have hp (j : Fin b) : (if (graph a b d).Adj (path i) (path j) then 1 else 0 : ℕ) =
      if i.val+1=j.val ∨ j.val+1=i.val then 1 else 0 := by
    split_ifs <;> simp_all [graph, Adj]
  simp_rw [hl,hr,hp]
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul]
  simp only [mul_ite,mul_one,mul_zero]
  omega
#print axioms left_degree
#print axioms right_degree
#print axioms path_degree_sum
end SumBalaban
