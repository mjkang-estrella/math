import MovingInterval
import PathSumError
namespace SumBalaban
open scoped BigOperators

theorem actual_reference_rectangle {a b d : ℕ} {B : ℝ}
    (hb : 0<b) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hn : 4*(B+5)≤((a+b+d:ℕ):ℝ)) :
    let n : ℝ := (a+b+d:ℕ)
    |pathForward a b d -
      (∫ u in (a:ℝ)/n..(a:ℝ)/n+(b-1:ℕ)/n, referenceF u)|≤
      (4*(B+5)+8)/n := by
  dsimp only
  let n : ℝ := (a+b+d:ℕ)
  have hn0 : 0<n := by dsimp [n]; exact_mod_cast (show 0<a+b+d by omega)
  have hn1 : (b-1:ℕ)≤a+b+d := by omega
  have hn1' : ((b-1:ℕ):ℝ)≤n := by dsimp [n]; exact_mod_cast hn1
  have he := actual_path_sum_error hb hB hq hn
  have hr := reference_rectangle_error ((a:ℝ)/n) (1/n) (b-1)
    (by positivity) (by positivity) (by
      rw [mul_one_div, ←add_div, div_le_one hn0]
      dsimp [n]
      have h : a+(b-1)≤a+b+d := by omega
      exact_mod_cast h)
  have hs :
      (∑ i : Fin (b-1), 1/Real.sqrt (((i.val+a:ℕ):ℝ)^2+
        (n-((i.val+a:ℕ):ℝ))^2)) =
      ∑ i ∈ Finset.range (b-1), (1/n)*referenceF ((a:ℝ)/n+(i:ℝ)*(1/n)) := by
    rw [Fin.sum_univ_eq_sum_range (fun i : ℕ => 1/Real.sqrt (((i+a:ℕ):ℝ)^2+(n-((i+a:ℕ):ℝ))^2))]
    apply Finset.sum_congr rfl
    intro i hi
    rw [reference_scaled n ((i+a:ℕ):ℝ) hn0]
    congr 1
    dsimp [referenceF]
    push_cast
    congr 3 <;> ring
  have hs' := hs
  change |pathForward a b d - _|≤4*(B+5)/n at he
  rw [hs] at he
  have hr' : |(∑ i ∈ Finset.range (b-1), (1/n)*referenceF ((a:ℝ)/n+(i:ℝ)*(1/n)))-
      (∫ u in (a:ℝ)/n..(a:ℝ)/n+(b-1:ℕ)/n, referenceF u)|≤8/n := by
    have hc : 8*((b-1:ℕ):ℝ)*(1/n)^2≤8/n := by
      apply (le_div_iff₀ hn0).mpr
      field_simp
      nlinarith
    simpa only [mul_one_div] using hr.trans hc
  have hh := abs_sub_le (pathForward a b d)
    (∑ i ∈ Finset.range (b-1), (1/n)*referenceF ((a:ℝ)/n+(i:ℝ)*(1/n)))
    (∫ u in (a:ℝ)/n..(a:ℝ)/n+(b-1:ℕ)/n, referenceF u)
  change |pathForward a b d - _|≤(4*(B+5)+8)/n
  calc
    _ ≤ _ := hh
    _ ≤ 4*(B+5)/n+8/n := add_le_add he hr'
    _ = _ := by ring
#print axioms actual_reference_rectangle
end SumBalaban
