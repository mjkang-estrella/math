import TrialLimits
import MinimizerAnnulus
namespace SumBalaban
open Filter

theorem general_uniform_expansion {B δ : ℝ} (hB : 0≤B) (hδ : 0<δ) :
    ∃ K : ℝ, 0≤K ∧ ∃ N : ℕ, 1≤N ∧
    ∀ a b d : ℕ, 0<a → 0<b → 0<d → N≤a+b+d →
      (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ) →
      δ*(a+b+d:ℕ)≤(a:ℝ)^2+(d:ℝ)^2 →
      |SJ a b d-radialF (((a:ℝ)/Real.sqrt (a+b+d:ℕ))^2+
        ((d:ℝ)/Real.sqrt (a+b+d:ℕ))^2)-
        (1/Real.sqrt (a+b+d:ℕ))*correctionG ((a:ℝ)/Real.sqrt (a+b+d:ℕ))
          ((d:ℝ)/Real.sqrt (a+b+d:ℕ))|≤K/(a+b+d:ℕ) := by
  let T : ℝ := 1+16*(2*B+4)+8*B/δ^2
  refine ⟨combinedErrorK B δ, ?_, max 1 (Nat.ceil T), le_max_left _ _, ?_⟩
  · unfold combinedErrorK prefactorErrorK edgeErrorK
    have := Q_pos
    positivity
  · intro a b d ha hb hd hn hq hql
    have hT : T≤((a+b+d:ℕ):ℝ) := le_trans (Nat.le_ceil T)
      (by exact_mod_cast (le_trans (le_max_right 1 (Nat.ceil T)) hn))
    have hn1 : 16*(2*B+4)≤((a+b+d:ℕ):ℝ) := by
      dsimp [T] at hT
      have : 0≤8*B/δ^2 := by positivity
      linarith
    have hn2 : 8*B≤δ^2*((a+b+d:ℕ):ℝ) := by
      have hbound : 8*B/δ^2≤((a+b+d:ℕ):ℝ) := by dsimp [T] at hT; nlinarith
      have := (div_le_iff₀ (sq_pos_of_pos hδ)).mp hbound
      nlinarith
    have he := actual_SJ_rational_expansion ha hb hd hB hδ hq hql hn1 hn2
    have hid := rational_correction_as_normalized
      (a:=(a:ℝ)) (d:=(d:ℝ)) (by positivity : (0:ℝ)<(a+b+d:ℕ))
      (by positivity : (0:ℝ)<(a:ℝ)^2+(d:ℝ)^2)
    dsimp only at he hid
    rw [hid] at he
    convert he using 1
    congr 1
    ring

theorem trial_eventual_expansion :
    ∃ K : ℝ, 0≤K ∧ ∀ᶠ n : ℕ in atTop,
      |objective (optimalTrial n)-radialF (2*(trialX n)^2)-
        (1/Real.sqrt (n:ℝ))*correctionG (trialX n) (trialX n)|≤K/(n:ℝ) := by
  have hc := c_pos
  have hq : Tendsto (fun n => 2*(trialX n)^2) atTop (nhds (2*c^2)) :=
    tendsto_const_nhds.mul (trial_normalized_limit.pow 2)
  obtain ⟨K,hK,N,hN,hE⟩ := general_uniform_expansion
    (B:=2*c^2+1) (δ:=c^2) (by positivity) (sq_pos_of_pos hc)
  refine ⟨K,hK,?_⟩
  have hlo : ∀ᶠ n : ℕ in atTop, c^2 < 2*(trialX n)^2 :=
    (tendsto_order.mp hq).1 _ (by nlinarith [sq_pos_of_pos hc])
  have hhi : ∀ᶠ n : ℕ in atTop, 2*(trialX n)^2 < 2*c^2+1 :=
    (tendsto_order.mp hq).2 _ (by linarith)
  filter_upwards [optimal_trial_eventually, hlo, hhi, eventually_ge_atTop N] with n ha hl hu hn
  obtain ⟨ha,hb,hd,hs,had⟩ := ha.1
  have hn0 : 0<n := by omega
  have hnR : (0:ℝ)<n := by exact_mod_cast hn0
  have hnorm := normalized_squares (optimalTrial n).1 (optimalTrial n).2.2 n hn0
  have heq : (optimalTrial n).2.2=(optimalTrial n).1 := rfl
  rw [heq] at hnorm
  have hnorm2 : 2*(trialX n)^2 = (((optimalTrial n).1:ℝ)^2+((optimalTrial n).1:ℝ)^2)/(n:ℝ) := by
    simpa only [trialX, ←two_mul] using hnorm
  have hupper : ((optimalTrial n).1:ℝ)^2+((optimalTrial n).2.2:ℝ)^2≤(2*c^2+1)*(n:ℝ) := by
    rw [heq]; rw [hnorm2] at hu; exact le_of_lt ((div_lt_iff₀ hnR).mp hu)
  have hlower : c^2*(n:ℝ)≤((optimalTrial n).1:ℝ)^2+((optimalTrial n).2.2:ℝ)^2 := by
    rw [heq]; rw [hnorm2] at hl; exact le_of_lt ((lt_div_iff₀ hnR).mp hl)
  have he := hE _ _ _ ha hb hd (by omega) (by simpa [hs] using hupper) (by simpa [hs] using hlower)
  rw [hs] at he
  simpa only [objective, heq, trialX, ←two_mul] using he
#print axioms general_uniform_expansion
#print axioms trial_eventual_expansion
end SumBalaban
