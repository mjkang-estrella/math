import PathPolynomial
namespace SumBalaban
-- Algebraic selection lemma only; this does not assert the missing uniform expansion.
theorem angular_cubic {x y c : ℝ} (hx : 0≤x) (hy : 0≤y) (hc : 0<c)
    (hq : x^2+y^2=2*c^2) :
    2*c^3 ≤ x^3+y^3 ∧ (x^3+y^3=2*c^3 ↔ x=c ∧ y=c) := by
  have hs : 0<x+y := by nlinarith [sq_nonneg (x-y)]
  have hxy : 0≤x*y := mul_nonneg hx hy
  have hb : x+y≤2*c := by nlinarith [sq_nonneg (x-y)]
  have hp : 0<(x+y)^2+2*c*(x+y)-2*c^2 := by
    have hm : 0<2*c*(x+y) := mul_pos (by linarith) hs
    nlinarith
  have hid : 2*(x^3+y^3-2*c^3) =
      (2*c-x-y)*((x+y)^2+2*c*(x+y)-2*c^2) := by
    have hm := congrArg (fun t : ℝ => (x+y)*t) hq
    nlinarith
  have hn := mul_nonneg (by linarith : 0≤2*c-x-y) (le_of_lt hp)
  constructor
  · nlinarith
  · constructor
    · intro he
      have hz : 2*c-x-y=0 := by
        have hpz : (2*c-x-y)*((x+y)^2+2*c*(x+y)-2*c^2)=0 := by nlinarith
        exact (mul_eq_zero.mp hpz).resolve_right (ne_of_gt hp)
      constructor <;> nlinarith [sq_nonneg (x-y)]
    · rintro ⟨rfl,rfl⟩
      ring
#print axioms angular_cubic
end SumBalaban
