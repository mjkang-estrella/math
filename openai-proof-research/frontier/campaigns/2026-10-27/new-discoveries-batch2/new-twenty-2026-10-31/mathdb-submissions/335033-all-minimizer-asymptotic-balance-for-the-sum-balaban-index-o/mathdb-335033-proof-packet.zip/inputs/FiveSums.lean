import EdgeSums
namespace SumBalaban
open scoped BigOperators
noncomputable def leftW (a b d : ℕ) : ℕ :=
  (a-1)+(∑ i : Fin b, (i.val+1))+d*(b+1)
noncomputable def rightW (a b d : ℕ) : ℕ :=
  (d-1)+(∑ i : Fin b, (b-i.val))+a*(b+1)
noncomputable def kernel (p q : ℕ) : ℝ := 1/Real.sqrt ((p:ℝ)+(q:ℝ))
noncomputable def pathForward (a b d : ℕ) : ℝ :=
  ∑ i : Fin b, ∑ j : Fin b,
    if i.val+1=j.val then edgeWeight s((path i : Vertex a b d),path j) else 0

theorem kernel_symm (p q : ℕ) : kernel p q = kernel q p := by
  unfold kernel; rw [add_comm]

theorem clique_block (a : ℕ) (z : ℝ) :
    (∑ u : Fin a, ∑ v : Fin a, if u≠v then z else 0) =
      (a:ℝ)*(a-1:ℕ)*z := by
  classical
  have hi (u : Fin a) :
      (∑ v : Fin a, if u≠v then z else 0) = ((a-1:ℕ):ℝ)*z := by
    have hr : (∑ v : Fin a, if u=v then (0:ℝ) else 1) = (a-1:ℕ) := by
      exact_mod_cast clique_sum a u
    calc
      _ = ∑ v : Fin a, (if u=v then (0:ℝ) else 1)*z := by
        apply Finset.sum_congr rfl
        intro v _
        by_cases h : u=v <;> simp [h]
      _ = (∑ v : Fin a, if u=v then (0:ℝ) else 1)*z := (Finset.sum_mul _ _ _).symm
      _ = _ := by rw [hr]
  simp_rw [hi]
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin, nsmul_eq_mul]
  ring

theorem path_block (a b d : ℕ) :
    (∑ i : Fin b, ∑ j : Fin b,
      if i.val+1=j.val ∨ j.val+1=i.val then edgeWeight s((path i : Vertex a b d),path j) else 0) =
      2*pathForward a b d := by
  classical
  have he (i j : Fin b) :
      (if i.val+1=j.val ∨ j.val+1=i.val then edgeWeight s((path i : Vertex a b d),path j) else 0) =
      (if i.val+1=j.val then edgeWeight s((path i : Vertex a b d),path j) else 0)+
      (if j.val+1=i.val then edgeWeight s((path i : Vertex a b d),path j) else 0) := by
    split_ifs <;> (try omega) <;> ring
  simp_rw [he,Finset.sum_add_distrib]
  have hs : (∑ i : Fin b, ∑ j : Fin b,
      if j.val+1=i.val then edgeWeight s((path i : Vertex a b d),path j) else 0) = pathForward a b d := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i _
    apply Finset.sum_congr rfl
    intro j _
    simp only [edgeWeight_formula,add_comm]
  rw [hs]
  change pathForward a b d + pathForward a b d = _
  ring

#print axioms clique_block
#print axioms path_block
end SumBalaban
