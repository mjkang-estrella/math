import Transmissions
import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.Real.Sqrt
import Mathlib.Data.Set.Finite.Lemmas
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Tactic.Positivity

namespace SumBalaban
open scoped BigOperators
noncomputable def edgeWeight {a b d : ℕ} : Sym2 (Vertex a b d) → ℝ :=
  Sym2.lift ⟨fun u v => 1 / Real.sqrt ((transmission u : ℝ) + (transmission v : ℝ)),
    by intro u v; dsimp only; rw [add_comm]⟩

noncomputable def edgeCount (a b d : ℕ) : ℕ := by
  classical
  exact (graph a b d).edgeFinset.card

noncomputable def SJ (a b d : ℕ) : ℝ := by
  classical
  exact (edgeCount a b d : ℝ) /
    ((edgeCount a b d : ℝ) - (a+b+d : ℕ) + 2) *
    ∑ e ∈ (graph a b d).edgeFinset, edgeWeight e

noncomputable def Q : ℝ := Real.sqrt 2 * Real.log (1+Real.sqrt 2)
noncomputable def c : ℝ := Real.sqrt (Real.sqrt Q)

theorem Q_pos : 0 < Q := by
  have hs : 0 < Real.sqrt (2:ℝ) := Real.sqrt_pos.2 (by norm_num)
  exact mul_pos hs (Real.log_pos (by linarith))
theorem c_pos : 0 < c := Real.sqrt_pos.2 (Real.sqrt_pos.2 Q_pos)

abbrev Triple := ℕ × ℕ × ℕ
def admissible (n : ℕ) (t : Triple) : Prop :=
  0<t.1 ∧ 0<t.2.1 ∧ 0<t.2.2 ∧ t.1+t.2.1+t.2.2=n ∧ t.1≤t.2.2
instance (n : ℕ) : DecidablePred (admissible n) := fun t => by
  unfold admissible
  infer_instance
noncomputable def objective (t : Triple) : ℝ := SJ t.1 t.2.1 t.2.2

def minimizes (n : ℕ) (t : Triple) : Prop :=
  admissible n t ∧ ∀ s, admissible n s → objective t ≤ objective s

def candidates (n : ℕ) : Finset Triple :=
  ((Finset.range (n+1)).product ((Finset.range (n+1)).product (Finset.range (n+1)))).filter
    (fun t => admissible n t)

@[simp] theorem mem_candidates (n : ℕ) (t : Triple) : t ∈ candidates n ↔ admissible n t := by
  rw [candidates, Finset.mem_filter]
  constructor
  · exact fun h => h.2
  · intro h
    have hh := h
    unfold admissible at hh
    refine ⟨Finset.mem_product.mpr ⟨?_,Finset.mem_product.mpr ⟨?_,?_⟩⟩,h⟩
    all_goals apply Finset.mem_range.mpr; omega

theorem minimum_attained (n : ℕ) (hn : 3≤n) : ∃ t, minimizes n t := by
  classical
  have h : admissible n (1,n-2,1) := by simp only [admissible]; omega
  have hs : (candidates n).Nonempty := ⟨(1,n-2,1),(mem_candidates _ _).2 h⟩
  obtain ⟨t,ht,hm⟩ := (candidates n).exists_min_image objective hs
  exact ⟨t,(mem_candidates _ _).1 ht, fun s hs => hm s ((mem_candidates _ _).2 hs)⟩

-- Exact sequential source target: a proposition, not an asserted theorem.
-- Every eventually minimizing choice over ALL positive triples modulo reversal.
def SourceTarget : Prop :=
  ∀ f : ℕ → Triple,
    (∀ᶠ n in Filter.atTop, minimizes n (f n)) →
    Filter.Tendsto (fun n => ((f n).1 : ℝ) / Real.sqrt n) Filter.atTop (nhds c) ∧
    Filter.Tendsto (fun n => ((f n).2.2 : ℝ) / Real.sqrt n) Filter.atTop (nhds c) ∧
    Filter.Tendsto (fun n => ((f n).2.1 : ℝ) / n) Filter.atTop (nhds 1)

#print axioms SJ
#print axioms Q_pos
#print axioms c_pos
#print axioms minimum_attained
end SumBalaban
