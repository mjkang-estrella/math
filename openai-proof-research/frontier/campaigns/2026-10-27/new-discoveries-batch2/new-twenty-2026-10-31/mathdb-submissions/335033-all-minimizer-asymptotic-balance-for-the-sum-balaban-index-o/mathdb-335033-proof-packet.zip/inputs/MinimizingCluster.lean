import EventualComparison
import Mathlib.Tactic.FunProp
namespace SumBalaban
open Filter

theorem correction_limit {α : Type*} {l : Filter α} {u v : α → ℝ} {x y : ℝ}
    (hu : Tendsto u l (nhds x)) (hv : Tendsto v l (nhds y)) (hq : 0<x^2+y^2) :
    Tendsto (fun i => correctionG (u i) (v i)) l (nhds (correctionG x y)) := by
  unfold correctionG
  dsimp only
  have hqq := (hu.pow 2).add (hv.pow 2)
  exact (((hqq.add_const 2).mul ((hu.pow 3).add (hv.pow 3))).div
    (tendsto_const_nhds.mul hqq) (by positivity)).add
    ((hu.add hv).mul (tendsto_const_nhds.add
      (tendsto_const_nhds.div (hqq.pow 2) (by positivity))))

theorem radial_limit {α : Type*} {l : Filter α} {q : α → ℝ} {r : ℝ}
    (hq : Tendsto q l (nhds r)) (hr : 0<r) :
    Tendsto (fun i => radialF (q i)) l (nhds (radialF r)) := by
  unfold radialF
  exact (((hq.div_const 2).add_const 1).add_const Q).add
    (tendsto_const_nhds.div hq (ne_of_gt hr))

theorem minimizing_cluster_balanced {f : ℕ → Triple}
    (hf : ∀ᶠ n in atTop, minimizes n (f n)) {φ : ℕ → ℕ}
    (hφ : Tendsto φ atTop atTop) {x y : ℝ}
    (hx : Tendsto (fun i => normA (f (φ i)) (φ i)) atTop (nhds x))
    (hy : Tendsto (fun i => normD (f (φ i)) (φ i)) atTop (nhds y)) :
    x=c ∧ y=c := by
  have ha : ∀ᶠ n : ℕ in atTop,
      0≤normA (f n) n ∧ 0≤normD (f n) n ∧
      (1:ℝ)/1024≤(normA (f n) n)^2+(normD (f n) n)^2 := by
    filter_upwards [hf,eventually_ge_atTop 2048] with n hn hN
    obtain ⟨h1,_,h2,_,h3,_,_⟩ := every_minimizer_annulus hN hn
    exact ⟨h1,h2,h3⟩
  have hseq := hφ.eventually ha
  have hx0 : 0≤x := ge_of_tendsto hx (hseq.mono fun _ h => h.1)
  have hy0 : 0≤y := ge_of_tendsto hy (hseq.mono fun _ h => h.2.1)
  have hqseq := (hx.pow 2).add (hy.pow 2)
  have hql : (1:ℝ)/1024≤x^2+y^2 := ge_of_tendsto hqseq (hseq.mono fun _ h => h.2.2)
  have hq : 0<x^2+y^2 := by linarith
  have hG := correction_limit hx hy hq
  have ht := trial_normalized_limit.comp hφ
  have hcq : 0<c^2+c^2 := by have := c_pos; positivity
  have hGt := correction_limit ht ht hcq
  have hqt : Tendsto (fun i => 2*(trialX (φ i))^2) atTop (nhds (2*c^2)) :=
    tendsto_const_nhds.mul (ht.pow 2)
  have hFt := radial_limit hqt (by have := c_pos; positivity)
  have hF := radial_limit hqseq hq
  have he := inverse_sqrt_limit.comp hφ
  have hinv : Tendsto (fun i => 1/(φ i:ℝ)) atTop (nhds 0) := by
    simpa only [one_div,Function.comp_def] using tendsto_inv_atTop_zero.comp
      (tendsto_natCast_atTop_atTop.comp hφ)
  obtain ⟨C,hcomp⟩ := minimizer_eventual_comparison hf
  have hcomp' := hφ.eventually hcomp
  have hright := hFt.add ((he.mul (hGt.sub hG)).add ((tendsto_const_nhds (x:=C)).mul hinv))
  have hright' : Tendsto (fun i => radialF (2*(trialX (φ i))^2)+
      (1/Real.sqrt (φ i:ℝ))*(correctionG (trialX (φ i)) (trialX (φ i))-
        correctionG (normA (f (φ i)) (φ i)) (normD (f (φ i)) (φ i)))+C/(φ i:ℝ))
      atTop (nhds (radialF (2*c^2))) := by
    simpa only [zero_mul,mul_zero,add_zero,div_eq_mul_inv,one_div,add_assoc,Function.comp_def,one_mul] using hright
  have hrad : radialF (x^2+y^2)≤radialF (2*c^2) :=
    le_of_tendsto_of_tendsto hF hright' (hcomp'.mono fun _ h => h.1)
  have hq0 : radialQ=2*c^2 := by unfold radialQ c; rw [Real.sq_sqrt (le_of_lt (Real.sqrt_pos.mpr Q_pos))]
  have hrad0 : radialF (x^2+y^2)-radialF radialQ≤0 := by rw [hq0]; linarith
  rw [radial_excess hq] at hrad0
  have hzero : (x^2+y^2-radialQ)^2=0 := by
    have := (div_le_iff₀ (show 0<2*(x^2+y^2) by positivity)).mp hrad0
    nlinarith [sq_nonneg (x^2+y^2-radialQ)]
  have hqr : x^2+y^2=2*c^2 := by rw [sq_eq_zero_iff] at hzero; rw [←hq0]; linarith
  have hrightG : Tendsto (fun i => correctionG (trialX (φ i)) (trialX (φ i))+
      (16+C)/Real.sqrt (φ i:ℝ)) atTop (nhds (correctionG c c)) := by
    simpa only [mul_zero,add_zero,div_eq_mul_inv,one_div,Function.comp_def,one_mul] using
      hGt.add ((tendsto_const_nhds (x:=16+C)).mul he)
  have hGl := le_of_tendsto_of_tendsto hG hrightG (hcomp'.mono fun _ h => h.2)
  exact optimal_cluster_forced_balanced hx0 hy0 hqr hGl
#print axioms correction_limit
#print axioms radial_limit
#print axioms minimizing_cluster_balanced
end SumBalaban
