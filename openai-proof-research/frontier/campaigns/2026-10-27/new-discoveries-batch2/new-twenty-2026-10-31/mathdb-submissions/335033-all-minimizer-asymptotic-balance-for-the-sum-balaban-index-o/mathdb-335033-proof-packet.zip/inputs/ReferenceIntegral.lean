import PathKernel
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic
namespace SumBalaban
noncomputable def referenceF (u : ℝ) : ℝ := 1/Real.sqrt (u^2+(1-u)^2)
theorem reference_phi_lower (u : ℝ) : (1:ℝ)/2≤u^2+(1-u)^2 := by
  nlinarith [sq_nonneg (u-1/2)]
theorem referenceF_continuous : Continuous referenceF := by
  apply Continuous.div continuous_const
    (((continuous_id.pow 2).add ((continuous_const.sub continuous_id).pow 2)).sqrt)
  intro u
  change Real.sqrt (u^2+(1-u)^2)≠0
  exact ne_of_gt (Real.sqrt_pos.mpr (by linarith [reference_phi_lower u]))
theorem referenceF_lipschitz {u v : ℝ} (hu : 0≤u) (hu1 : u≤1)
    (hv : 0≤v) (hv1 : v≤1) :
    |referenceF u-referenceF v|≤8*|u-v| := by
  have hsum : |u+v-1|≤1 := abs_le.mpr ⟨by linarith,by linarith⟩
  have he : |(u^2+(1-u)^2)-(v^2+(1-v)^2)|≤2*|u-v| := by
    rw [show (u^2+(1-u)^2)-(v^2+(1-v)^2)=2*(u-v)*(u+v-1) by ring,
      abs_mul,abs_mul,abs_of_pos (by norm_num : (0:ℝ)<2)]
    nlinarith [mul_le_mul_of_nonneg_left hsum (abs_nonneg (u-v))]
  have h := inverse_sqrt_error (A:=u^2+(1-u)^2) (T:=v^2+(1-v)^2) (n:=1) (H:=2*|u-v|) (by norm_num)
    (by positivity) (by linarith [reference_phi_lower u])
    (by linarith [reference_phi_lower v]) (by simpa using he)
  dsimp [referenceF]
  simpa only [one_pow, div_one, show (4:ℝ)*(2*|u-v|)=8*|u-v| by ring] using h

theorem reference_cell_error {h t : ℝ} (hh : 0≤h) (ht : 0≤t) (hht : h+t≤1) :
    |(∫ u in h..h+t, referenceF u)-t*referenceF h|≤8*t^2 := by
  have hint : IntervalIntegrable referenceF MeasureTheory.volume h (h+t) :=
    referenceF_continuous.intervalIntegrable h (h+t)
  have hc : IntervalIntegrable (fun _ : ℝ => referenceF h) MeasureTheory.volume h (h+t) :=
    intervalIntegrable_const
  have he := intervalIntegral.norm_integral_le_of_norm_le_const
    (a:=h) (b:=h+t) (f:=fun u => referenceF u-referenceF h) (C:=8*t) ?_
  · rw [intervalIntegral.integral_sub hint hc] at he
    simpa [Real.norm_eq_abs, abs_of_nonneg ht, pow_two, mul_comm, mul_left_comm, mul_assoc] using he
  · intro u hu
    rw [Set.uIoc_of_le (by linarith : h≤h+t)] at hu
    have huu : h≤u := le_of_lt hu.1
    have hu1 : u≤1 := le_trans hu.2 hht
    rw [Real.norm_eq_abs]
    have he := referenceF_lipschitz (by linarith : 0≤u) hu1 hh (by linarith : h≤1)
    rw [abs_of_nonneg (sub_nonneg.mpr huu)] at he
    linarith [hu.2]
#print axioms referenceF_lipschitz
#print axioms reference_cell_error
end SumBalaban
