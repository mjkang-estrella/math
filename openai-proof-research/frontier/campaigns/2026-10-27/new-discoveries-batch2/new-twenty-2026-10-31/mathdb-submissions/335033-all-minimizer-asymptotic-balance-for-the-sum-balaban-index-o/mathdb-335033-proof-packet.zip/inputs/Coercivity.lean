import GlobalBounds
namespace SumBalaban
open scoped BigOperators

theorem actual_edge_sum_lower {a b d : ℕ} (hb : 0<b) :
    (edgeCount a b d : ℝ) / (2*(a+b+d : ℕ)) ≤
      ∑ e ∈ (graph a b d).edgeFinset, edgeWeight e := by
  classical
  calc
    (edgeCount a b d : ℝ) / (2*(a+b+d : ℕ)) =
        ∑ _e ∈ (graph a b d).edgeFinset, (1 / (2*(a+b+d : ℕ)) : ℝ) := by
      simp [edgeCount, div_eq_mul_inv]
    _ ≤ _ := Finset.sum_le_sum (fun e he => edgeWeight_lower hb e (by simpa using he))

theorem order_le_edges_add_one {a b d : ℕ} (hb : 0<b) :
    ((a+b+d : ℕ):ℝ) ≤ (edgeCount a b d : ℝ)+1 := by
  have h := cycle_denominator_pos (a:=a) (d:=d) hb
  have hn : a+b+d ≤ edgeCount a b d+1 := by
    have hc := (connected (a:=a) (d:=d) hb).card_vert_le_card_edgeSet_add_one
    rw [Nat.card_eq_fintype_card, Nat.card_eq_fintype_card, vertex_count,
      ←SimpleGraph.edgeFinset_card] at hc
    exact hc
  exact_mod_cast hn

theorem SJ_scaled_lower {a b d : ℕ} (hb : 0<b) :
    (edgeCount a b d : ℝ)^2 ≤
      (2*(a+b+d : ℕ))*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2)*SJ a b d := by
  classical
  have hk := cycle_denominator_pos (a:=a) (d:=d) hb
  have hn : (0:ℝ)<(a+b+d : ℕ) := by exact_mod_cast (show 0<a+b+d by omega)
  have hm : (0:ℝ) ≤ (edgeCount a b d : ℝ) := by positivity
  have hs := actual_edge_sum_lower (a:=a) (d:=d) hb
  have ht := mul_le_mul_of_nonneg_left hs (div_nonneg hm (le_of_lt hk))
  change (edgeCount a b d : ℝ) / ((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2) *
      ((edgeCount a b d : ℝ)/(2*(a+b+d : ℕ))) ≤ SJ a b d at ht
  have he : (edgeCount a b d : ℝ) / ((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2) *
      ((edgeCount a b d : ℝ)/(2*(a+b+d : ℕ))) =
      (edgeCount a b d : ℝ)^2 / ((2*(a+b+d : ℕ))*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2)) := by
        field_simp
  rw [he] at ht
  simpa only [mul_comm (SJ a b d)] using (div_le_iff₀ (mul_pos (by positivity) hk)).mp ht

theorem edgeCount_le_of_SJ_le {a b d : ℕ} {M : ℝ} (hb : 0<b)
    (hn : 2≤a+b+d) (hM : SJ a b d ≤ M) :
    (edgeCount a b d : ℝ) ≤ 2*(a+b+d : ℕ)*M := by
  have horder := order_le_edges_add_one (a:=a) (d:=d) hb
  have hn' : (2:ℝ) ≤ (a+b+d : ℕ) := by exact_mod_cast hn
  have hm : (0:ℝ)<(edgeCount a b d : ℝ) := by linarith
  have hk := cycle_denominator_pos (a:=a) (d:=d) hb
  have hl := SJ_scaled_lower (a:=a) (d:=d) hb
  have hsj : 0≤SJ a b d := by
    by_contra hh
    have hden : (0:ℝ)<(2*(a+b+d : ℕ))*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2) := mul_pos (by linarith) hk
    have hf := mul_neg_of_pos_of_neg hden (lt_of_not_ge hh)
    linarith [sq_nonneg (edgeCount a b d : ℝ)]
  have hprod := mul_le_mul_of_nonneg_left hM
    (show 0≤(2*(a+b+d : ℕ):ℝ)*((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2) by positivity)
  have hM0 : 0≤M := le_trans hsj hM
  have hkM : ((edgeCount a b d : ℝ)-(a+b+d : ℕ)+2)*M ≤ (edgeCount a b d : ℝ)*M := by nlinarith
  have hlast := mul_le_mul_of_nonneg_left hkM (show (0:ℝ)≤2*(a+b+d : ℕ) by positivity)
  nlinarith

#print axioms actual_edge_sum_lower
#print axioms SJ_scaled_lower
#print axioms edgeCount_le_of_SJ_le
end SumBalaban
