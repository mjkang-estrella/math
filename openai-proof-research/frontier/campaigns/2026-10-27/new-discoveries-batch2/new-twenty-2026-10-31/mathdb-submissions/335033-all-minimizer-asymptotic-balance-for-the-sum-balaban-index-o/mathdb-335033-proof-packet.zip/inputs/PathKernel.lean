import PathError
namespace SumBalaban

theorem inverse_sqrt_error {A T n H : ℝ} (hn : 0<n) (hH : 0≤H)
    (hA : n^2/4≤A) (hT : n^2/4≤T) (herr : |A-T|≤H*n) :
    |1/Real.sqrt A - 1/Real.sqrt T| ≤ 4*H/n^2 := by
  have hA0 : 0<A := by nlinarith [sq_pos_of_pos hn]
  have hT0 : 0<T := by nlinarith [sq_pos_of_pos hn]
  have hu0 := Real.sqrt_pos.mpr hA0
  have hv0 := Real.sqrt_pos.mpr hT0
  have hu2 := Real.sq_sqrt (le_of_lt hA0)
  have hv2 := Real.sq_sqrt (le_of_lt hT0)
  have hu : n/2≤Real.sqrt A := by nlinarith [Real.sqrt_nonneg A]
  have hv : n/2≤Real.sqrt T := by nlinarith [Real.sqrt_nonneg T]
  have hprod : n^2/4≤Real.sqrt A*Real.sqrt T := by
    have h := mul_le_mul hu hv (by linarith : 0≤n/2) (le_of_lt hu0)
    nlinarith
  have hden : n^3/4 ≤ Real.sqrt A*Real.sqrt T*(Real.sqrt A+Real.sqrt T) := by
    have h := mul_le_mul hprod (show n≤Real.sqrt A+Real.sqrt T by linarith)
      (le_of_lt hn) (mul_nonneg (le_of_lt hu0) (le_of_lt hv0))
    nlinarith
  have hid : (1/Real.sqrt A - 1/Real.sqrt T)*
      (Real.sqrt A*Real.sqrt T*(Real.sqrt A+Real.sqrt T)) = T-A := by
    field_simp
    nlinarith
  have heq : |1/Real.sqrt A - 1/Real.sqrt T| =
      |A-T|/(Real.sqrt A*Real.sqrt T*(Real.sqrt A+Real.sqrt T)) := by
    apply (eq_div_iff (ne_of_gt (mul_pos (mul_pos hu0 hv0) (add_pos hu0 hv0)))).mpr
    have ha := congrArg abs hid
    simpa only [abs_mul, abs_of_pos (mul_pos (mul_pos hu0 hv0) (add_pos hu0 hv0)), abs_sub_comm] using ha
  rw [heq]
  calc
    _ ≤ (H*n)/(Real.sqrt A*Real.sqrt T*(Real.sqrt A+Real.sqrt T)) :=
      div_le_div_of_nonneg_right herr (by positivity)
    _ ≤ (H*n)/(n^3/4) := div_le_div_of_nonneg_left (mul_nonneg hH (le_of_lt hn)) (by positivity) hden
    _ = 4*H/n^2 := by field_simp

theorem actual_path_kernel_error {a b d : ℕ} {B : ℝ} (hb : 0<b) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2 ≤ B*(a+b+d : ℕ))
    (hn : 4*(B+5)≤((a+b+d:ℕ):ℝ)) (i : Fin (b-1)) :
    |edgeWeight s((path (pathLo i) : Vertex a b d),path (pathHi i)) -
      1/Real.sqrt (((i.val+a:ℕ):ℝ)^2 + (((a+b+d:ℕ):ℝ)-((i.val+a:ℕ):ℝ))^2)| ≤
      4*(B+5)/((a+b+d:ℕ):ℝ)^2 := by
  rw [edgeWeight_formula]
  apply inverse_sqrt_error (n:=((a+b+d:ℕ):ℝ)) (H:=B+5)
  · exact_mod_cast (show 0<a+b+d by omega)
  · linarith
  · exact actual_path_pair_lower hb hB hq hn i
  · have h := path_reference_lower (((a+b+d:ℕ):ℝ)) (((i.val+a:ℕ):ℝ))
    nlinarith [sq_nonneg (((a+b+d:ℕ):ℝ))]
  · exact actual_path_pair_error hb hB hq i

#print axioms actual_path_kernel_error
end SumBalaban
