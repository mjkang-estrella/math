import RadialCost
import EdgeFirstCorrection
import ActualPrefactor
namespace SumBalaban
noncomputable def correctionG (x y : ℝ) : ℝ :=
  let q := x^2+y^2
  (q+2)*(x^3+y^3)/(2*q)+(x+y)*(-1/2+2*Q/q^2)

theorem normalized_product_identity {x y e : ℝ} (hq : x^2+y^2≠0) :
    let q := x^2+y^2
    let s := x+y
    let r := x^3+y^3
    (1+2/q+2*e*s/q^2)*(q/2+Q+e*(r-s)/2) =
      radialF q+e*correctionG x y+e^2*s*(r-s)/q^2 := by
  dsimp only
  unfold radialF correctionG
  dsimp only
  field_simp
  ring

theorem product_remainder_bound {P E P₀ A T n KP KE KD M L : ℝ}
    (hn : 0<n) (hKP : 0≤KP) (_hKE : 0≤KE)
    (hP : |P-P₀|≤KP/n) (hE : |E-A|≤KE/n)
    (hM : |E|≤M) (hL : |P₀|≤L) (hcross : |P₀*A-T|≤KD/n) :
    |P*E-T|≤(KP*M+L*KE+KD)/n := by
  have hM0 : 0≤M := le_trans (abs_nonneg _) hM
  have hL0 : 0≤L := le_trans (abs_nonneg _) hL
  have h1 : |(P-P₀)*E|≤(KP/n)*M := by
    rw [abs_mul]
    exact mul_le_mul hP hM (abs_nonneg _) (by positivity)
  have h2 : |P₀*(E-A)|≤L*(KE/n) := by
    rw [abs_mul]
    exact mul_le_mul hL hE (abs_nonneg _) hL0
  have hid : P*E-T = ((P-P₀)*E+P₀*(E-A))+(P₀*A-T) := by ring
  rw [hid]
  calc
    _ ≤ |(P-P₀)*E+P₀*(E-A)|+|P₀*A-T| := abs_add_le _ _
    _ ≤ (|(P-P₀)*E|+|P₀*(E-A)|)+|P₀*A-T| :=
      add_le_add (abs_add_le _ _) le_rfl
    _ ≤ ((KP/n)*M+L*(KE/n))+KD/n := add_le_add (add_le_add h1 h2) hcross
    _ = _ := by ring
#print axioms normalized_product_identity
#print axioms product_remainder_bound
end SumBalaban
