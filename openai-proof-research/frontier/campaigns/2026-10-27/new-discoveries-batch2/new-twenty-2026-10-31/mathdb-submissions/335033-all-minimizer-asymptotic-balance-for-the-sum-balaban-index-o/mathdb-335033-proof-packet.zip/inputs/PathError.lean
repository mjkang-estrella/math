import PathEdges
namespace SumBalaban

theorem actual_path_pair_error {a b d : ℕ} {B : ℝ} (hb : 0<b) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2 ≤ B*(a+b+d : ℕ)) (i : Fin (b-1)) :
    |((transmission (path (pathLo i) : Vertex a b d):ℝ) +
      (transmission (path (pathHi i) : Vertex a b d):ℝ)) -
      (((i.val+a:ℕ):ℝ)^2 + (((a+b+d:ℕ):ℝ)-((i.val+a:ℕ):ℝ))^2)| ≤
      (B+5)*(a+b+d : ℕ) := by
  rw [actual_path_edge_polynomial hb]
  have hn : (1:ℝ)≤(a+b+d : ℕ) := by exact_mod_cast (show 1≤a+b+d by omega)
  have ht : ((i.val+a:ℕ):ℝ) ≤ (a+b+d : ℕ) := by
    exact_mod_cast (show i.val+a≤a+b+d by have := i.isLt; omega)
  have ht0 : (0:ℝ)≤((i.val+a:ℕ):ℝ) := by positivity
  have hs : (a:ℝ)+(d:ℝ) ≤ (a+b+d : ℕ) := by push_cast; linarith
  have hBn : (0:ℝ)≤B*(a+b+d : ℕ) := mul_nonneg hB (by positivity)
  apply abs_le.mpr
  constructor <;> nlinarith

theorem path_reference_lower (n t : ℝ) : n^2/2 ≤ t^2+(n-t)^2 := by
  nlinarith [sq_nonneg (2*t-n)]

theorem actual_path_pair_lower {a b d : ℕ} {B : ℝ} (hb : 0<b) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2 ≤ B*(a+b+d : ℕ))
    (hn : 4*(B+5)≤((a+b+d:ℕ):ℝ)) (i : Fin (b-1)) :
    ((a+b+d:ℕ):ℝ)^2/4 ≤
      ((transmission (path (pathLo i) : Vertex a b d):ℝ) +
      (transmission (path (pathHi i) : Vertex a b d):ℝ)) := by
  have he := (abs_le.mp (actual_path_pair_error hb hB hq i)).1
  have hf := path_reference_lower (((a+b+d:ℕ):ℝ)) (((i.val+a:ℕ):ℝ))
  have hm := mul_le_mul_of_nonneg_right hn (show (0:ℝ)≤((a+b+d:ℕ):ℝ) by positivity)
  nlinarith

#print axioms actual_path_pair_error
#print axioms actual_path_pair_lower
end SumBalaban
