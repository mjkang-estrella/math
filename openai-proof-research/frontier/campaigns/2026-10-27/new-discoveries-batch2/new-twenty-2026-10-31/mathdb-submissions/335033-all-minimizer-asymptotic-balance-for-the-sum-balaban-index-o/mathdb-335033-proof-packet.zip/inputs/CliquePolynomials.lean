import MinimizerAnnulus
namespace SumBalaban

theorem leftW_polynomial {a b d : ℕ} (ha : 0<a) (hb : 0<b) :
    2*(leftW a b d : ℝ) = ((a+b+d:ℕ):ℝ)^2-2*(a:ℝ)*(a+b+d:ℕ)+
      (a:ℝ)^2-(d:ℝ)^2+(a+b+d:ℕ)+a+d-2 := by
  let u : Fin a := ⟨0,ha⟩
  have h := twice_left_transmission (a:=a) (d:=d) hb u
  have hr : (2:ℝ)*transmission (left u : Vertex a b d) =
      2*(a-1:ℕ)+(b:ℝ)*(b+1)+2*d*(b+1) := by exact_mod_cast h
  rw [left_transmission_sum hb] at hr
  change 2*(leftW a b d : ℝ)=_ at hr
  have hsub : ((a-1:ℕ):ℝ)=(a:ℝ)-1 := by rw [Nat.cast_sub (by omega : 1≤a)]; norm_num
  rw [hsub] at hr
  push_cast
  nlinarith

theorem rightW_polynomial {a b d : ℕ} (hd : 0<d) (hb : 0<b) :
    2*(rightW a b d : ℝ) = ((a+b+d:ℕ):ℝ)^2-2*(d:ℝ)*(a+b+d:ℕ)+
      (d:ℝ)^2-(a:ℝ)^2+(a+b+d:ℕ)+a+d-2 := by
  let u : Fin d := ⟨0,hd⟩
  have h := twice_right_transmission (a:=a) (d:=d) hb u
  have hr : (2:ℝ)*transmission (right u : Vertex a b d) =
      2*(d-1:ℕ)+(b:ℝ)*(b+1)+2*a*(b+1) := by exact_mod_cast h
  rw [right_transmission_sum hb] at hr
  change 2*(rightW a b d : ℝ)=_ at hr
  have hsub : ((d-1:ℕ):ℝ)=(d:ℝ)-1 := by rw [Nat.cast_sub (by omega : 1≤d)]; norm_num
  rw [hsub] at hr
  push_cast
  nlinarith

theorem left_attachment_argument {a b d : ℕ} (ha : 0<a) (hb : 0<b) :
    (leftW a b d : ℝ)+(transmission (path ⟨0,hb⟩ : Vertex a b d):ℝ) =
      ((a+b+d:ℕ):ℝ)^2-2*(a:ℝ)*(a+b+d:ℕ)+(a:ℝ)^2-(d:ℝ)^2+2*a+d-1 := by
  have hl := leftW_polynomial (d:=d) ha hb
  rw [shifted_actual_transmission hb]
  push_cast at *
  nlinarith

theorem right_attachment_argument {a b d : ℕ} (hd : 0<d) (hb : 0<b) :
    (rightW a b d : ℝ)+(transmission (path ⟨b-1,by omega⟩ : Vertex a b d):ℝ) =
      ((a+b+d:ℕ):ℝ)^2-2*(d:ℝ)*(a+b+d:ℕ)+(d:ℝ)^2-(a:ℝ)^2+2*d+a-1 := by
  have hr := rightW_polynomial (a:=a) hd hb
  rw [shifted_actual_transmission hb]
  have hsub : ((b-1:ℕ):ℝ)=(b:ℝ)-1 := by rw [Nat.cast_sub (by omega : 1≤b)]; norm_num
  push_cast
  rw [hsub]
  push_cast at hr
  nlinarith

#print axioms leftW_polynomial
#print axioms rightW_polynomial
#print axioms left_attachment_argument
#print axioms right_attachment_argument
end SumBalaban
