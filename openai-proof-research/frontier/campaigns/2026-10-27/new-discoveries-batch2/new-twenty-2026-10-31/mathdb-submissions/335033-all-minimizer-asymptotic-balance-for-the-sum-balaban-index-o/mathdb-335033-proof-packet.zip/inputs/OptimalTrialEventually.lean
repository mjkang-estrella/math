import OptimalTrial
namespace SumBalaban
theorem optimal_trial_eventually :
    ∀ᶠ n : ℕ in Filter.atTop, admissible n (optimalTrial n) ∧
      radialF (2*(((optimalTrial n).1:ℝ)/Real.sqrt n)^2)-radialF radialQ≤16/(n:ℝ) := by
  let T : ℝ := 4+4/c^2+16*c^2
  refine Filter.eventually_atTop.mpr ⟨Nat.ceil T,?_⟩
  intro n hn
  have hc := c_pos
  have hcn : c≠0 := ne_of_gt hc
  have hceil : T≤(Nat.ceil T:ℝ) := Nat.le_ceil T
  have hnn : (Nat.ceil T:ℝ)≤n := by exact_mod_cast hn
  have hT : T≤(n:ℝ) := le_trans hceil hnn
  have hn4 : (4:ℝ)≤n := by dsimp [T] at hT; nlinarith [show (0:ℝ)≤4/c^2 by positivity]
  have h4 : 4≤n := by exact_mod_cast hn4
  have hn0 : (0:ℝ)<n := by linarith
  have hlo : 4≤c^2*(n:ℝ) := by
    have hbound : 4/c^2≤(n:ℝ) := by dsimp [T] at hT; nlinarith [sq_nonneg c]
    have hh := (div_le_iff₀ (sq_pos_of_pos hc)).mp hbound
    nlinarith
  have hhi : 16*c^2≤(n:ℝ) := by dsimp [T] at hT; nlinarith [show (0:ℝ)≤4/c^2 by positivity]
  refine ⟨(optimal_trial_bounds h4 hlo hhi).1,?_⟩
  have he := optimal_trial_radial_cost h4 hlo hhi
  have hid : 16*c^2/(c^2*(n:ℝ))=16/(n:ℝ) := by field_simp
  rwa [hid] at he
#print axioms optimal_trial_eventually
end SumBalaban
