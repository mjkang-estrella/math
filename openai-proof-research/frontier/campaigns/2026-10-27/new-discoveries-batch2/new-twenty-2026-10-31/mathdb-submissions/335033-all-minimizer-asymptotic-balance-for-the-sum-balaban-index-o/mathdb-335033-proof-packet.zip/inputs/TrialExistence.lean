import TrialBound
import Mathlib.Data.Nat.Sqrt
namespace SumBalaban

def coarseTrial (n : ℕ) : Triple := (n.sqrt,n-2*n.sqrt,n.sqrt)

theorem coarseTrial_admissible {n : ℕ} (hn : 64≤n) : admissible n (coarseTrial n) := by
  have hk : 8≤n.sqrt := Nat.le_sqrt.mpr hn
  have hs := Nat.sqrt_le n
  have hh : 2*n.sqrt≤n := by nlinarith
  have hb : 0<n-2*n.sqrt := Nat.sub_pos_of_lt (by nlinarith)
  simp only [admissible,coarseTrial]
  omega

theorem coarseTrial_bound {n : ℕ} (hn : 64≤n) : objective (coarseTrial n) ≤ 128 := by
  have hk : 8≤n.sqrt := Nat.le_sqrt.mpr hn
  have hs := Nat.sqrt_le n
  have hfour : 4*n.sqrt≤n := by nlinarith
  have htot : n.sqrt+(n-2*n.sqrt)+n.sqrt=n := by omega
  have hreal : (n.sqrt:ℝ)^2≤(n:ℝ) := by exact_mod_cast (Nat.sqrt_le' n)
  have hreal' : (n:ℝ)<((n.sqrt:ℝ)+1)^2 := by
    have hh : n<(n.sqrt+1)^2 := by simpa only [Nat.succ_eq_add_one] using Nat.lt_succ_sqrt' n
    exact_mod_cast hh
  have hk' : (8:ℝ)≤n.sqrt := by exact_mod_cast hk
  have hb : 2≤n-2*n.sqrt := by omega
  have hp : (n:ℝ)/2≤(n-2*n.sqrt:ℕ) := by
    have hh : ((n-2*n.sqrt:ℕ):ℝ)=(n:ℝ)-2*n.sqrt := by
      rw [Nat.cast_sub (by omega : 2*n.sqrt≤n)]
      norm_num
    rw [hh]
    have hfour' : (4:ℝ)*n.sqrt≤n := by exact_mod_cast hfour
    linarith
  unfold objective coarseTrial
  apply balanced_trial_bound (by omega : 2≤n.sqrt) hb
  · rw [htot]; exact hreal
  · rw [htot]; nlinarith
  · rw [htot]; exact hp

theorem minimizer_bound {n : ℕ} {t : Triple} (hn : 64≤n) (ht : minimizes n t) :
    objective t ≤ 128 :=
  le_trans (ht.2 (coarseTrial n) (coarseTrial_admissible hn)) (coarseTrial_bound hn)

theorem every_minimizer_radial_bounds {n : ℕ} {t : Triple} (hn : 2048≤n)
    (ht : minimizes n t) :
    (t.1:ℝ)^2+(t.2.2:ℝ)^2 ≤ 512*n ∧
    (n:ℝ) ≤ 1024*((t.1:ℝ)^2+(t.2.2:ℝ)^2) := by
  obtain ⟨ha,hb,hd,htot,had⟩ := ht.1
  have hM : SJ t.1 t.2.1 t.2.2≤128 := minimizer_bound (by omega) ht
  constructor
  · have h := sublevel_clique_squares_upper hb (by omega) hM
    rw [htot] at h
    linarith
  · have h := sublevel_clique_squares_lower hb (by omega : 4≤t.1+t.2.1+t.2.2)
      (show 16*(128:ℝ)≤((t.1+t.2.1+t.2.2:ℕ):ℝ) by rw [htot]; exact_mod_cast hn)
      (by norm_num : (0:ℝ)≤128) hM
    rw [htot] at h
    norm_num at h ⊢
    exact h

#print axioms coarseTrial_admissible
#print axioms coarseTrial_bound
#print axioms every_minimizer_radial_bounds
end SumBalaban
