import CliquePolynomials
namespace SumBalaban

theorem polynomial_residual_bounds {a d n B : ℝ} (ha : 0≤a) (hd : 0≤d)
    (hn : 1≤n) (hB : 0≤B) (hs : a+d≤n) (hq : a^2+d^2≤B*n) :
    |a^2-d^2+n+a+d-2|≤(B+3)*n ∧ |a^2-d^2+2*a+d-1|≤(B+3)*n := by
  have hBn := mul_nonneg hB (show 0≤n by linarith)
  constructor <;> apply abs_le.mpr <;> constructor <;>
    nlinarith [sq_nonneg a,sq_nonneg d]

theorem actual_clique_arguments_error {a b d : ℕ} {B : ℝ}
    (ha : 0<a) (hb : 0<b) (hd : 0<d) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ)) :
    |2*(leftW a b d : ℝ)-((a+b+d:ℕ):ℝ)^2+2*(a:ℝ)*(a+b+d:ℕ)|≤(B+3)*(a+b+d:ℕ) ∧
    |2*(rightW a b d : ℝ)-((a+b+d:ℕ):ℝ)^2+2*(d:ℝ)*(a+b+d:ℕ)|≤(B+3)*(a+b+d:ℕ) ∧
    |(leftW a b d : ℝ)+(transmission (path ⟨0,hb⟩ : Vertex a b d):ℝ)-
      ((a+b+d:ℕ):ℝ)^2+2*(a:ℝ)*(a+b+d:ℕ)|≤(B+3)*(a+b+d:ℕ) ∧
    |(rightW a b d : ℝ)+(transmission (path ⟨b-1,by omega⟩ : Vertex a b d):ℝ)-
      ((a+b+d:ℕ):ℝ)^2+2*(d:ℝ)*(a+b+d:ℕ)|≤(B+3)*(a+b+d:ℕ) := by
  have hn : (1:ℝ)≤(a+b+d:ℕ) := by exact_mod_cast (show 1≤a+b+d by omega)
  have hs : (a:ℝ)+(d:ℝ)≤(a+b+d:ℕ) := by push_cast; linarith
  have hl := polynomial_residual_bounds (by positivity : (0:ℝ)≤a) (by positivity : (0:ℝ)≤d) hn hB hs hq
  have hr := polynomial_residual_bounds (by positivity : (0:ℝ)≤d) (by positivity : (0:ℝ)≤a) hn hB
    (by linarith : (d:ℝ)+(a:ℝ)≤(a+b+d:ℕ)) (by linarith : (d:ℝ)^2+(a:ℝ)^2≤B*(a+b+d:ℕ))
  rw [leftW_polynomial ha hb,rightW_polynomial hd hb,left_attachment_argument ha hb,right_attachment_argument hd hb]
  ring_nf at hl hr ⊢
  exact ⟨hl.1,hr.1,hl.2,hr.2⟩

#print axioms actual_clique_arguments_error
end SumBalaban
