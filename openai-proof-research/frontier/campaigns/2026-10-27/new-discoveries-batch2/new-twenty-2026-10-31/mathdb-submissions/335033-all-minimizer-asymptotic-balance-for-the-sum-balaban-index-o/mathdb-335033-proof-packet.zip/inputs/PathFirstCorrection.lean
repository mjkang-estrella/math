import ActualRectangle
namespace SumBalaban
theorem actual_path_first_correction {a b d : ℕ} {B : ℝ}
    (hb : 0<b) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hn : 4*(B+5)≤((a+b+d:ℕ):ℝ)) :
    |pathForward a b d-(Q-((a:ℝ)+d)/(a+b+d:ℕ))|≤
      (20*B+45)/(a+b+d:ℕ) := by
  let n : ℝ := (a+b+d:ℕ)
  let h : ℝ := (a:ℝ)/n
  let r : ℝ := ((d:ℝ)+1)/n
  have hn0 : 0<n := by dsimp [n]; exact_mod_cast (show 0<a+b+d by omega)
  have hn1 : 1≤n := by change 1≤((a+b+d:ℕ):ℝ); nlinarith
  have hncast : n=(a:ℝ)+b+d := by dsimp [n]; push_cast; ring
  have hbm : ((b-1:ℕ):ℝ)=(b:ℝ)-1 := by rw [Nat.cast_sub (by omega),Nat.cast_one]
  have hhr : h+r≤1 := by
    dsimp [h,r]
    rw [←add_div, div_le_one hn0]
    have hb' : (1:ℝ)≤b := by exact_mod_cast hb
    linarith
  have hm := reference_moving_interval (h:=h) (r:=r) (by positivity) (by positivity) hhr
  have he := actual_reference_rectangle hb hB hq hn
  have hend : (a:ℝ)/n+((b-1:ℕ):ℝ)/n=1-r := by
    rw [hbm]
    dsimp [r]
    field_simp
    linarith
  change |pathForward a b d-(∫ u in h..(a:ℝ)/n+((b-1:ℕ):ℝ)/n, referenceF u)|≤
    (4*(B+5)+8)/n at he
  rw [hend] at he
  have hbound : 8*(h^2+r^2)≤(16*B+16)/n := by
    have hsq : (a:ℝ)^2+((d:ℝ)+1)^2≤2*B*n+2 := by
      change (a:ℝ)^2+(d:ℝ)^2≤B*n at hq
      nlinarith [sq_nonneg ((d:ℝ)-1),sq_nonneg (a:ℝ)]
    dsimp [h,r]
    apply (le_div_iff₀ hn0).mpr
    field_simp
    nlinarith
  have hdiff : (Q-h-r)-(Q-((a:ℝ)+d)/n) = -1/n := by dsimp [h,r]; ring
  have hh := abs_sub_le (pathForward a b d)
    (∫ u in h..1-r, referenceF u) (Q-h-r)
  have hp : |pathForward a b d-(Q-h-r)|≤(4*(B+5)+8)/n+(16*B+16)/n :=
    hh.trans (add_le_add he (hm.trans hbound))
  have hh' := abs_sub_le (pathForward a b d) (Q-h-r) (Q-((a:ℝ)+d)/n)
  have hneg : |(-1:ℝ)/n|=1/n := by rw [abs_div]; simp [abs_of_pos hn0]
  rw [hdiff,hneg] at hh'
  change |pathForward a b d-(Q-((a:ℝ)+d)/n)|≤(20*B+45)/n
  calc
    _ ≤ _ := hh'
    _ ≤ ((4*(B+5)+8)/n+(16*B+16)/n)+1/n := add_le_add hp le_rfl
    _ = _ := by ring
#print axioms actual_path_first_correction
end SumBalaban
