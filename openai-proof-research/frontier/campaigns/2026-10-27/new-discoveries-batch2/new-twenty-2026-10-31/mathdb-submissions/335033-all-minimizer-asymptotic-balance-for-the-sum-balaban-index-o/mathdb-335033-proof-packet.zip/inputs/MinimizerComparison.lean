import TrialExpansion
namespace SumBalaban
open Filter
noncomputable def normA (t : Triple) (n : ℕ) : ℝ := (t.1:ℝ)/Real.sqrt n
noncomputable def normD (t : Triple) (n : ℕ) : ℝ := (t.2.2:ℝ)/Real.sqrt n

theorem minimizer_eventual_expansion {f : ℕ → Triple}
    (hf : ∀ᶠ n in atTop, minimizes n (f n)) :
    ∃ K : ℝ, 0≤K ∧ ∀ᶠ n : ℕ in atTop,
      |objective (f n)-radialF ((normA (f n) n)^2+(normD (f n) n)^2)-
        (1/Real.sqrt (n:ℝ))*correctionG (normA (f n) n) (normD (f n) n)|≤K/(n:ℝ) := by
  obtain ⟨K,hK,N,hN,hE⟩ := common_uniform_expansion
  refine ⟨K,hK,?_⟩
  filter_upwards [hf, eventually_ge_atTop (max N 2048)] with n hm hn
  have ⟨ha,hb,hd,hs,had⟩ := hm.1
  have hn0 : 0<n := by omega
  obtain ⟨_,_,_,_,hl,hu,_⟩ := every_minimizer_annulus (by omega) hm
  have hnorm := normalized_squares (f n).1 (f n).2.2 n hn0
  have hnR : (0:ℝ)<n := by exact_mod_cast hn0
  rw [hnorm] at hu
  have hl' : (1:ℝ)/1024≤(((f n).1:ℝ)^2+((f n).2.2:ℝ)^2)/(n:ℝ) := by
    simpa only [normA,normD,div_pow,Real.sq_sqrt (le_of_lt hnR),←add_div] using hl
  have he := hE _ _ _ ha hb hd (by omega)
    (by rw [hs]; exact (div_le_iff₀ hnR).mp hu)
    (by rw [hs]; have := (le_div_iff₀ hnR).mp hl'; nlinarith)
  rw [hs] at he
  exact he

theorem comparison_algebra {n x y u K L S T : ℝ} (hn : 0<n)
    (hq : 0<x^2+y^2)
    (hS : |S-radialF (x^2+y^2)-(1/Real.sqrt n)*correctionG x y|≤K/n)
    (hT : |T-radialF (2*u^2)-(1/Real.sqrt n)*correctionG u u|≤L/n)
    (hcost : radialF (2*u^2)-radialF radialQ≤16/n) (hmin : S≤T) :
    radialF (x^2+y^2) ≤ radialF (2*u^2)+(1/Real.sqrt n)*(correctionG u u-correctionG x y)+(K+L)/n ∧
    correctionG x y ≤ correctionG u u+(16+K+L)/Real.sqrt n := by
  have hs := Real.sqrt_pos.mpr hn
  have hs2 := Real.sq_sqrt (le_of_lt hn)
  obtain ⟨hSl,hSu⟩ := abs_le.mp hS
  obtain ⟨hTl,hTu⟩ := abs_le.mp hT
  have hrad := radial_excess_nonneg hq
  constructor
  · have heq : (K+L)/n=K/n+L/n := by ring
    rw [heq]
    nlinarith
  · have hmul : (1/Real.sqrt n)*(correctionG x y-correctionG u u)≤(16+K+L)/n := by
      have heq : (16+K+L)/n=16/n+K/n+L/n := by ring
      rw [heq]
      nlinarith
    have he := mul_le_mul_of_nonneg_right hmul (le_of_lt hs)
    have hid1 : (1/Real.sqrt n)*(correctionG x y-correctionG u u)*Real.sqrt n = correctionG x y-correctionG u u := by field_simp
    have hid2 : (16+K+L)/n*Real.sqrt n=(16+K+L)/Real.sqrt n := by
      field_simp
      rw [hs2]
    rw [hid1,hid2] at he
    linarith
#print axioms minimizer_eventual_expansion
#print axioms comparison_algebra
end SumBalaban
