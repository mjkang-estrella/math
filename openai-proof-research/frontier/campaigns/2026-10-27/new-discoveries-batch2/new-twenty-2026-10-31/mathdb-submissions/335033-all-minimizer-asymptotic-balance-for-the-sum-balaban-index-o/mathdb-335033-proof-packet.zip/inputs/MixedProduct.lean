import ProductCorrection
import NormalizedBounds
namespace SumBalaban
theorem mixed_remainder_bound {q u t n B δ : ℝ} (hn : 0<n) (hδ : 0<δ)
    (hq : δ≤q) (hB : 0≤B) (hu : 0≤u) (ht : 0≤t)
    (htu : t≤B*u) (hu2 : u^2≤2*B/n) :
    |u*(t-u)/q^2|≤2*B*(B+1)/(δ^2*n) := by
  have hq0 : 0<q := lt_of_lt_of_le hδ hq
  have hq2 : δ^2≤q^2 := by nlinarith
  have ha : |t-u|≤(B+1)*u := by
    apply abs_le.mpr
    constructor <;> nlinarith
  have hnum : u*|t-u|≤2*B*(B+1)/n := by
    have h1 := mul_le_mul_of_nonneg_left ha hu
    have h2 := mul_le_mul_of_nonneg_left hu2 (show 0≤B+1 by linarith)
    calc
      _ ≤ u*((B+1)*u) := h1
      _ = (B+1)*u^2 := by ring
      _ ≤ (B+1)*(2*B/n) := h2
      _ = _ := by ring
  calc
    _ = (u*|t-u|)/q^2 := by
      rw [abs_div,abs_mul,abs_of_nonneg hu,abs_of_pos (sq_pos_of_pos hq0)]
    _ ≤ (2*B*(B+1)/n)/q^2 := div_le_div_of_nonneg_right hnum (sq_nonneg q)
    _ ≤ (2*B*(B+1)/n)/δ^2 :=
      div_le_div_of_nonneg_left (by positivity) (sq_pos_of_pos hδ) hq2
    _ = _ := by ring

theorem actual_mixed_remainder {a b d : ℕ} {B δ : ℝ}
    (hb : 0<b) (hB : 0≤B) (hδ : 0<δ)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hql : δ*(a+b+d:ℕ)≤(a:ℝ)^2+(d:ℝ)^2) :
    let n : ℝ := (a+b+d:ℕ)
    let q : ℝ := ((a:ℝ)^2+(d:ℝ)^2)/n
    let u : ℝ := ((a:ℝ)+d)/n
    let t : ℝ := ((a:ℝ)^3+(d:ℝ)^3)/n^2
    |u*(t-u)/q^2|≤2*B*(B+1)/(δ^2*n) := by
  obtain ⟨h1,_,h3,_,h5,h6,h7⟩ := actual_normalized_bounds hb hB hq hql
  apply mixed_remainder_bound ?_ hδ h1 hB h3 h5 h6 h7
  exact_mod_cast (show 0<a+b+d by omega)
#print axioms mixed_remainder_bound
#print axioms actual_mixed_remainder
end SumBalaban
