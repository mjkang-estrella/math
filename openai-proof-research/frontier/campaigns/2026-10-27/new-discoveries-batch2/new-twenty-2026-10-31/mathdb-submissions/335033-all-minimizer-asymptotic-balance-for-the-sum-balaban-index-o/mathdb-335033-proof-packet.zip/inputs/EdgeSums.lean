import Annulus
namespace SumBalaban
open scoped BigOperators

theorem dart_sum_eq_twice_edge_sum (a b d : ℕ) :
    (∑ z : (graph a b d).Dart, edgeWeight z.edge) =
      2 * ∑ e ∈ (graph a b d).edgeFinset, edgeWeight e := by
  classical
  have hmap : ∀ z ∈ (Finset.univ : Finset (graph a b d).Dart),
      z.edge ∈ (graph a b d).edgeFinset := by
    intro z _
    simp
  calc
    _ = ∑ e ∈ (graph a b d).edgeFinset,
        ∑ _z ∈ Finset.univ.filter (fun z : (graph a b d).Dart => z.edge=e), edgeWeight e :=
      (Finset.sum_fiberwise_of_maps_to' hmap edgeWeight).symm
    _ = ∑ e ∈ (graph a b d).edgeFinset, 2*edgeWeight e := by
      apply Finset.sum_congr rfl
      intro e he
      rw [Finset.sum_const, (graph a b d).dart_edge_fiber_card e (by simpa using he)]
      simp
    _ = _ := (Finset.mul_sum _ _ _).symm

theorem ordered_sum_eq_dart_sum (a b d : ℕ) :
    (∑ u : Vertex a b d, ∑ v : Vertex a b d,
      if (graph a b d).Adj u v then edgeWeight s(u,v) else 0) =
      ∑ z : (graph a b d).Dart, edgeWeight z.edge := by
  classical
  let f : Vertex a b d × Vertex a b d → ℝ := fun z => edgeWeight s(z.1,z.2)
  have he : (∑ z : (graph a b d).Dart, edgeWeight z.edge) =
      ∑ z ∈ (Finset.univ : Finset (Vertex a b d × Vertex a b d)).filter
        (fun z => (graph a b d).Adj z.1 z.2), f z := by
    apply Finset.sum_bij (fun z _ => z.toProd)
    · intro z _; simp
    · intro z _ z' _ h; exact SimpleGraph.Dart.ext _ _ h
    · intro z hz
      exact ⟨⟨z,(Finset.mem_filter.mp hz).2⟩,Finset.mem_univ _,rfl⟩
    · intro z _; rfl
  rw [he, Finset.sum_filter]
  exact (Fintype.sum_prod_type (fun z : Vertex a b d × Vertex a b d =>
    if (graph a b d).Adj z.1 z.2 then f z else 0)).symm

#print axioms dart_sum_eq_twice_edge_sum
#print axioms ordered_sum_eq_dart_sum
end SumBalaban
