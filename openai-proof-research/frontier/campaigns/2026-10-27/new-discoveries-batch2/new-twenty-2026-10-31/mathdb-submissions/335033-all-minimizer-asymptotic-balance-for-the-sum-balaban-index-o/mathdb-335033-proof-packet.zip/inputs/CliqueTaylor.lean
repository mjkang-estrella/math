import CliqueError
import PathKernel
namespace SumBalaban
theorem inverse_sqrt_first_correction {A a n B H : ℝ}
    (ha : 0≤a) (hn : 1≤n) (hB : 0≤B) (hH : 0≤H)
    (hlarge : 16*(B+H+1)≤n) (ha2 : a^2≤B*n)
    (herr : |A-n^2+2*a*n|≤H*n) :
    |1/Real.sqrt A - (1/n+a/n^2)| ≤ (4*H+6*B)/n^2 := by
  have hn0 : 0<n := by linarith
  have ha4 : a≤n/4 := by
    have : B*n≤n^2/16 := by nlinarith
    nlinarith [sq_nonneg (a-n/4)]
  have hnma : 0<n-a := by linarith
  have hA : n^2/4≤A := by
    have he := (abs_le.mp herr).1
    have : H*n≤n^2/16 := by nlinarith
    nlinarith
  have hT : n^2/4≤(n-a)^2 := by nlinarith [sq_nonneg (n/4)]
  have he : |A-(n-a)^2|≤(H+B)*n := by
    apply abs_le.mpr
    have hh := abs_le.mp herr
    constructor <;> nlinarith [sq_nonneg a]
  have he' := inverse_sqrt_error hn0 (by positivity : 0≤H+B) hA hT he
  rw [Real.sqrt_sq (le_of_lt hnma)] at he'
  have hid : 1/(n-a)-(1/n+a/n^2) = a^2/((n-a)*n^2) := by
    field_simp
    ring
  have hr : |1/(n-a)-(1/n+a/n^2)|≤2*B/n^2 := by
    rw [hid, abs_of_nonneg (by positivity)]
    apply (div_le_div_iff₀ (by positivity : 0<(n-a)*n^2)
      (by positivity : 0<n^2)).mpr
    have hab : a^2≤2*B*(n-a) := by nlinarith
    nlinarith [mul_nonneg (sub_nonneg.mpr hab) (sq_nonneg n)]
  calc
    _ ≤ |1/Real.sqrt A-1/(n-a)|+|1/(n-a)-(1/n+a/n^2)| :=
      abs_sub_le _ _ _
    _ ≤ 4*(H+B)/n^2+2*B/n^2 := add_le_add he' hr
    _ = _ := by ring

#print axioms inverse_sqrt_first_correction

theorem actual_clique_four_corrections {a b d : ℕ} {B : ℝ}
    (ha : 0<a) (hb : 0<b) (hd : 0<d) (hB : 0≤B)
    (hq : (a:ℝ)^2+(d:ℝ)^2≤B*(a+b+d:ℕ))
    (hn : 16*(2*B+4)≤((a+b+d:ℕ):ℝ)) :
    let n : ℝ := (a+b+d:ℕ)
    |1/Real.sqrt (2*(leftW a b d:ℝ))-(1/n+(a:ℝ)/n^2)|≤(10*B+12)/n^2 ∧
    |1/Real.sqrt (2*(rightW a b d:ℝ))-(1/n+(d:ℝ)/n^2)|≤(10*B+12)/n^2 ∧
    |1/Real.sqrt ((leftW a b d:ℝ)+(transmission (path ⟨0,hb⟩ : Vertex a b d):ℝ))-
      (1/n+(a:ℝ)/n^2)|≤(10*B+12)/n^2 ∧
    |1/Real.sqrt ((rightW a b d:ℝ)+(transmission (path ⟨b-1,by omega⟩ : Vertex a b d):ℝ))-
      (1/n+(d:ℝ)/n^2)|≤(10*B+12)/n^2 := by
  dsimp only
  obtain ⟨h1,h2,h3,h4⟩ := actual_clique_arguments_error ha hb hd hB hq
  have hn1 : (1:ℝ)≤(a+b+d:ℕ) := by exact_mod_cast (show 1≤a+b+d by omega)
  have hl : 16*(B+(B+3)+1)≤((a+b+d:ℕ):ℝ) := by linarith
  have ha2 : (a:ℝ)^2≤B*(a+b+d:ℕ) := by nlinarith [sq_nonneg (d:ℝ)]
  have hd2 : (d:ℝ)^2≤B*(a+b+d:ℕ) := by nlinarith [sq_nonneg (a:ℝ)]
  have hh : 0≤B+3 := by linarith
  have hc : 4*(B+3)+6*B=10*B+12 := by ring
  constructor
  · simpa only [hc] using inverse_sqrt_first_correction (by positivity) hn1 hB hh hl ha2 h1
  constructor
  · simpa only [hc] using inverse_sqrt_first_correction (by positivity) hn1 hB hh hl hd2 h2
  constructor
  · simpa only [hc] using inverse_sqrt_first_correction (by positivity) hn1 hB hh hl ha2 h3
  · simpa only [hc] using inverse_sqrt_first_correction (by positivity) hn1 hB hh hl hd2 h4
#print axioms actual_clique_four_corrections

end SumBalaban
