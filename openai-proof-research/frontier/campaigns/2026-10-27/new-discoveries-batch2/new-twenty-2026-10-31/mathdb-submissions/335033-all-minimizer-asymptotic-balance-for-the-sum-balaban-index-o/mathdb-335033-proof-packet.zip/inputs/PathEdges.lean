import ActualFive
namespace SumBalaban
open scoped BigOperators

def pathLo {b : ℕ} (i : Fin (b-1)) : Fin b := ⟨i.val,by have := i.isLt; omega⟩
def pathHi {b : ℕ} (i : Fin (b-1)) : Fin b := ⟨i.val+1,by have := i.isLt; omega⟩

theorem pathForward_single (a b d : ℕ) :
    pathForward a b d = ∑ i : Fin (b-1), edgeWeight s((path (pathLo i) : Vertex a b d),path (pathHi i)) := by
  classical
  let f : Fin b × Fin b → ℝ := fun z => edgeWeight s((path z.1 : Vertex a b d),path z.2)
  have he : (∑ i : Fin (b-1), edgeWeight s((path (pathLo i) : Vertex a b d),path (pathHi i))) =
      ∑ z ∈ (Finset.univ : Finset (Fin b × Fin b)).filter (fun z => z.1.val+1=z.2.val), f z := by
    apply Finset.sum_bij (fun i _ => (pathLo i,pathHi i))
    · intro i _; simp [pathLo,pathHi]
    · intro i _ j _ h
      apply Fin.ext
      exact congrArg (fun z : Fin b × Fin b => z.1.val) h
    · intro z hz
      have hh := (Finset.mem_filter.mp hz).2
      have hi : z.1.val<b-1 := by have := z.2.isLt; omega
      refine ⟨⟨z.1.val,hi⟩,Finset.mem_univ _,?_⟩
      apply Prod.ext
      · apply Fin.ext; rfl
      · apply Fin.ext; exact hh
    · intro i _; rfl
  rw [he,Finset.sum_filter]
  exact (Fintype.sum_prod_type (fun z : Fin b × Fin b =>
    if z.1.val+1=z.2.val then f z else 0)).symm

theorem actual_path_edge_polynomial {a b d : ℕ} (hb : 0<b) (i : Fin (b-1)) :
    ((transmission (path (pathLo i) : Vertex a b d):ℝ) +
      (transmission (path (pathHi i) : Vertex a b d):ℝ)) =
      2*((i.val+a:ℕ):ℝ)^2 - 2*((a+b+d:ℕ)-2:ℝ)*((i.val+a:ℕ):ℝ) +
      ((a+b+d:ℕ):ℝ)^2-2*((a+b+d:ℕ):ℝ)+2 -
      ((a:ℝ)^2+(d:ℝ)^2-a-d) := by
  rw [shifted_actual_transmission hb,shifted_actual_transmission hb]
  simp only [pathLo,pathHi]
  push_cast
  ring

#print axioms pathForward_single
#print axioms actual_path_edge_polynomial
end SumBalaban
