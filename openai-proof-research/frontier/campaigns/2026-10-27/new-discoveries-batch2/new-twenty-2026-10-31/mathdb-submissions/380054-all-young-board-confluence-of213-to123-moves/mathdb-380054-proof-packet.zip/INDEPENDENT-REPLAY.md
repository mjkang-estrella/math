# Independent replay and statement-fidelity review v1 / INVESTIGATION / HANDOFF

MathDB 380054; review role; GPT-6.1 Sol, high effort, default speed; no children. Own lane only. Review date 2026-11-13 America/Los_Angeles, 2026-11-14 UTC. Counters remain 62/80 NEW, 101 total, credit 0.

## Verdict by gate

| Gate | Result | Scope |
|---|---|---|
| Ordinary mathematical correctness | PASS | Supplied working statement and owned arXiv v1 Conjecture 1 |
| Independent source/formal statement fidelity | PASS | Definitions 1/2/5, proper shapes, Section 3.5, Section 6.3; all sizes |
| Exact source extraction | PASS | New verbatim 19-module appendix; six negative extractor tests |
| Fresh all-source rebuild | PASS | All 19 production inputs; no supplied implementation binaries |
| All-module kernel checks | PASS | 19/19, plus separate independent audit |
| Complete-endpoint transitive axioms | PASS | Exactly propext, Classical.choice, Quot.sound |
| Relevant bridge transitive axioms | PASS | Subsets of those three; 317 axiom output lines audited overall |
| Compiler/mathlib pins and import path | PASS within stated trust boundary | Binary hashes, toolchain, source metadata and revision checked; permitted upstream oleans trusted |
| Candidate paper v3 | PASS mathematics; minor packaging gap repaired | Attached exact appendix and versioned review-v4 replay update; no theorem repair |
| Resource / execution protocol | PASS observed formal caps | 40/48 formal calls; zero formal failures; sampled peak 3,521,011,712 bytes |
| Access / own-lane discipline | PASS | No network, git, other-lane bodies, children, installs, messages, accounts, uploads or publication |
| Clean documentary/display process | FAIL | Specific own and inherited deviations below remain unwaived |
| Raw MathDB binding | GAP / HOLD | Original record unread; working metadata is not raw authentication |
| EJC final fidelity | GAP / HOLD | Closed publisher body; v1 is not journal-final authentication |
| Current prior art / registry / full101 | GAP / HOLD | Not investigated or cleared; no public requests authorized in this task |
| Independent significance / acceptance / credit | GAP / HOLD | No new qualification or credit adjudication here |

A clean mathematical replay does not turn any GAP/HOLD or historical process failure into PASS. The scoped ordinary/v1 verdict is independently justified below, not inferred from inherited PASS or SUBSTANTIAL labels.

## Exact theorem and source meaning

The compiled declaration is `Young213.source_shape_complete` in `YoungSequences`. Its full printed type is preserved in formal39.output.txt (and formal33.output.txt), with no elided hypotheses:

For every natural n, every `Y : RowShape n`, every `D : Dots n`, assuming only `Y.Transversal D`:

1. Any two finite descendants E,F of D have a common finite descendant G.
2. There is no f : Nat -> Dots n whose every consecutive pair is a Y.Move (even without requiring f 0 = D).
3. There exists E reachable from D, a valid Y-transversal avoiding 213; every reachable avoiding F equals E; a maximal finite sequence to E exists; every maximal finite sequence from D ends at E.

The binders are arbitrary n, shape and literal dot relation. There is no finite-size, certificate, FullJoin, local-confluence, algorithm-choice, or avoiding-input hypothesis. `Y.Maximal D length f` means f 0 = D, every step before length is legal, and f length has no outgoing move. Values after length are irrelevant. The theorem neither falsely declares every finite prefix terminal nor permits an infinite maximal run. Its separate existence clause prevents a merely vacuous universal claim about maximal sequences.

The owned cover visibly identifies Zvezdelina Stankova, *Shape-Wilf-Ordering on Permutations of Length 3*, math/0609644v1, 22 September 2006; source identity https://arxiv.org/abs/math/0609644v1. Personally rendered and inspected complete PDF pages 1,2,3,12,24. Those pages supply Definitions 1/2/5, orientation and properness with Figure 1, Section 3.5 and exact Section 6.3 Conjecture 1. Only relevant extracted text was read; no claim to reading the whole source. The source conjecture says that starting at T in S_Y, all 213->123 sequences terminate at the same transversal in S_Y(213), naturally understood as sequences continued until no move remains. The compiled theorem proves precisely this and full confluence. It does not resolve a separately authenticated raw MathDB record or closed final journal text.

## Source model: both directions and hostile checks

`RowShape.rows : Fin n -> Nat` is antitone and bounded by n, indexed top to bottom. Zero-based bottom-left cell (c,r) means c.val < rows(Fin.rev r). Thus one-based bottom-left coordinates (c+1,r+1) correspond to top row index n-(r+1); `coordinates` proves the formula. This is a row reversal, not a transpose, horizontal reflection or reversal of value inequalities. Repeated row lengths are allowed.

The boundary of a column is its least present bottom-based row, or n for an empty column. `boundary_cell` proves in BOTH directions that a cell is present iff boundary c <= r.val; `boundary_monotone` proves the right direction of monotonicity. No division by zero or minimum of an empty set occurs. Proper source partitions satisfy rows r >= n-r.val; `proper_iff` equates this with boundary c <= c.val. The theorem deliberately proves more than proper shapes, without needing to prove that arbitrary transversals imply properness. Every source proper shape is directly a RowShape; nonsquare shapes have no transversal by equal-dot counting. Square improper shapes have none by the suffix-column counting argument. Empty shapes and n<3 have no legal triples and admit the required zero-length normalizations. No forced cell, repeated part or degenerate case is removed by preprocessing.

`Dots n` is the literal cell predicate Fin n -> Fin n -> Prop. `Transversal` requires containment and exactly one dot per column and row. Given this predicate, unique dot choice defines a bijection p : Equiv.Perm (Fin n), and `transversal_encoding` proves unique p with `graph p = D` and `Valid boundary p`. Conversely each valid permutation graph is a transversal. Equality is equality of dot predicates via extensionality, not equality modulo a statistic. The encoding's fallback identity on invalid dot relations is harmless: `encode_spec`, `move_encode`, and every application to an actual move have validity premises. Every finite reachable state is valid by `paths_valid`; every state of an alleged infinite run is the source of an actual move and hence valid.

A 213 occurrence uses i<j<k and p j < p i < p k, plus ALL nine selected row-column intersections. `Rectangle`, `DotOccurrence` and `RowShape.Occurrence` express this full condition, not just three existing dots. Monotonicity makes it equivalent to boundary k <= (p j).val. Source Figure 1's nonlanding 324 in Y(5,5,4,4,3) is correctly excluded: its rightmost column's bottom is one-based 4, exceeding the selected low height 2. The comparison is not accidentally a square-only pattern test.

The move swaps columns i,j's dot heights, fixes the witness column k, and fixes all other dots. `exchange` is swap on the DOMAIN followed by p. The dot-level relation E x r iff D (swap i j x) r gives precisely that operation. `occurrence_iff`, graph occurrence, source_step_iff/extract, source_path_iff/extract, and RowShape's occurrence/move/path equivalences prove the transfer in both directions. `valid_exchange` proves that both new dots fit; permutation bijectivity preserves one dot in each row/column. Terminality iff avoidance is proved under validity at both encoding levels. No output-validity assumption is smuggled into the endpoint's uniqueness clause: it follows for every reachable F.

## Complete proof audit

The ordinary proof in INDEPENDENT-PROOF.md was personally read in full, including all 64 certificate rows. It is treated as an argument to verify, not an authority. Its inversion-count descent is correct: swapping an inversion removes 1 + twice the number of intervening values strictly between the swapped values. The formal implementation instead uses W(p)=sum_c (n-c)*p(c). A move at i<j decreases W by (j-i)*(p(i)-p(j))>0. YoungTermination proves strict natural descent, well-foundedness and existence of an avoiding descendant; YoungGlobal also proves W(f(t))+t <= W(f(0)) for any purported infinite run, which contradicts t=W(f(0))+1. No equality or repeated-value issue arises because p is a permutation.

For local peaks, retain each FULL triple, including its witness. Equal full supports imply identical ordered triples; disjoint full supports give commuting legal moves, not merely disjoint exchanged pairs. All remaining support unions have size 4 or 5. `tripleSupport_cases` proves this exhaustive split for arbitrary n.

Increasing embeddings e of selected columns and v of selected row VALUES encode a permutation q on the entire support union. Fixed thresholds d satisfy, for EVERY selected column i and EVERY selected row rank r, boundary(e i) <= v(r).val iff d i <= r.val. `threshold_spec` proves this universal condition from a nonempty fitting set, and `threshold_monotone` proves d monotone. This remains true at every rearranged state, even if witnesses move or change. `legal_compression` is an iff. `exchange_agrees`, `lift_step` and induction `lift_path` preserve all outside columns and validity through arbitrary finite paths. `lift_join` combines equality on the support with equality outside, proving equality of the actual global permutations. `preimages_cover` proves every compressed position belongs to one of the six preimages; no hidden unselected rank is omitted.

For a ranked peak q, peakCaps caps every column by its original value and caps both witness columns by the corresponding low value. Its suffix minimum B is the greatest monotone boundary allowing q and both initial legalities. `strongest_boundary` proves d<=B for every actual compressed board d; smaller boundaries enlarge boards, so every B-path is a d-path. The inequality direction and suffix (not prefix) construction are essential and correct. Reversing the pair in the coverage branch reverses the caps consistently, with independent symmetry lemmas also available.

The full-union coverage theorems quantify over ALL bijections Fin 4 -> Fin 4 or Fin 5 -> Fin 5 and ALL increasing triple choices. Their ordinary `decide` proofs are kernel-reduced finite universal propositions; they are neither native_decide nor finite sampling across diagram sizes. They cover seven four-position and 57 five-position cases, up to swapping the ORDER of the two peaks. No unproved symmetry quotient is used. Every case has a concrete boundary equality and two explicit paths; each successive step proves both Valid and Legal and each pair of final permutations is proved equal. Joins need not themselves be terminal. Equal outputs from different witnesses are retained.

For the generated repeated material I personally read the source templates and ALL 64 p/b/caps/triple/path records. review-tables-v3.py reconstructs the ENTIRE 78,075-byte Young64 source exactly from those records and the reviewed template, including all peak lemmas, and checks every TableJoins case branch against its reviewed template and triple association. This is explicit factored source reading, not a false claim of literal redisplay of each repeated line, and not merely hashing unread files. table-records-v1.json and tablereview03/tableread04/05 retain the review evidence. The unused initial-peak lemmas were still compiled and kernel-checked with the whole module. The ordinary certificate may use a different valid join in some cases (for example case64); identical chosen paths are not required.

`full_join4/5`, `overlap_join`, `legal_join`, and `local_confluence` discharge this finite lemma for arbitrary boards and n. Well-founded induction then equates any two reachable avoiding terminals: join the first steps, take an avoiding descendant of that join, and apply the induction hypothesis at each strict successor. Empty-path cases use terminality. Taking terminal descendants proves full confluence. The shape graph bridges transfer the result back to literal transversals; path_sequence constructs a natural-indexed finite realization, proving existence of a maximal path as well as universality of its endpoint. This closes all source bridges and the working/v1 theorem, with no residual ordinary or formal premise.

## Reproducibility and pins

The candidate v3 did not embed the exact modules. REPRODUCIBILITY-APPENDIX-v1.md adds 19 uniquely named verbatim Lean fences without mathematical edits. extract-v1.py parses only permitted module filenames, rejects traversal, duplicate, unexpected, malformed and missing modules, checks exact byte count and SHA256 against frozen SOURCE-PROOF-PINS.json, and extracts through write_lane.py into initially EMPTY src. It then verifies the complete exact source set and hashes BEFORE compilation. Six negative tests (missing, duplicate, unexpected, traversal, tamper, malformed) and the positive 19-module parse passed. This is extraction from source text, not copying implementation oleans. Initial src/build/cache were empty; cache remains empty. The independent audit source was added only after all 19 production sources were extracted and verified.

Lean reports 4.34.1 inside the compiled audit. Compiler SHA256 e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550; leanchecker SHA256 ccef1bfe9bfeecea65137d94a69033c1a89f360711f50fa3178e7ba3e696fcbe. Both were checked against PINS and rechecked by every formal wrapper. mathlib source revision is d13f23b723b8a846827a245b89c10fc7d3f11612, verified from its local .git/HEAD without executing git. Its lean-toolchain says leanprover/lean4:v4.34.1. Mathlib.lean and lake-manifest.json SHA256 match PINS; pinverify01 records exact results. This attests those local metadata, not all upstream compiled provenance. Standard pinned upstream mathlib/package/Lean oleans are explicitly allowed and trusted here.

Every invocation's LEAN_PATH was verified to be own build followed by EXACTLY the eight PINS upstream paths: mathlib, batteries, aesop, Qq, proofwidgets, importGraph, LeanSearchClient, plausible. No other research module/build/cache path occurs. The imports are specific, enumerated in import-audit-v1.json; no import Mathlib. Source scans found no sorry/admit/added axiom/unsafe/native_decide in executable source. The independent complete-endpoint axiom audit confirms this transitively, not merely by text scan.

All Lean invocations exclusively used `bash ./check32.sh MODULE UNIQUE_LABEL` or `bash ./checker32.sh MODULE UNIQUE_LABEL`. Wrappers/formal_command.py/run_lean_32g.py were read first. 32 GiB address space applied solely to these formal operations; child CPU115s, wall130s, sampled group RSS6GiB, affinity [0,1], -j1 -M3500 -DwarningAsError=true, LEAN_NUM_THREADS=1 stayed unchanged. Outputs were redirected to unique formalNN.wrapper.txt and preserved separately by the wrappers as formalNN.output.txt and formalNN.receipt.json. No labels were reused. All 40 exits are zero. Total measured child CPU 83.701842s and wrapper wall 84.339200s; sampled peak 3,521,011,712 bytes. Sampling is not a continuous-memory attestation. 8 of the 48 formal allocations remain unused; old budgets were not reset.

formal-results-v1.json records all 40 operations, module, stage, exit, resource use, source/output/olean hashes, and stderr. build-output-hashes-v1.json records 20 freshly generated binaries. The complete final theorem and 33 endpoint/bridge axiom lines are in formal39.output.txt; its independent module passed checker in formal40. Across the supplied audit modules and independent audit, 317 axiom output lines were parsed and restricted to the three allowed names. The complete endpoint's set is exactly those three. No formal failures occurred.

## Paper review and packaging repair

Candidate v3 accurately states the domain, orientation, rectangle-contained pattern, termination argument, arbitrary-state compression, 64-case universal local lemma, global induction, maximal-path semantics, source limits and historical cache reuse. I found no load-bearing theorem, fidelity, or proof defect. It candidly did not claim fresh replay. Its source archive was missing, a minor packaging gap now repaired by the separate appendix and CANDIDATE-PAPER-review-v4.md. The versioned update explains the new extraction/replay without falsifying the historical seed-cache paragraph. Frozen v3 and original sources are untouched.

The paper and appendix must travel together: bare case counts, hashes or a claim that a table exists would be insufficient to expose the finite proof. Paths and thresholds are now fully reproducible source, with actual coverage and legality checked in Lean. Journal-final citation/authentication and prior-art/significance qualification remain open gates. The paper is suitable as a scoped computer-assisted v1 proof draft, not accepted or publication-ready merely because this technical review passed.

## Read inventory, process, failures, and HANDOFF

SOURCE-INVENTORY-v1.json records every supplied input's size/hash/date and actual read scope. Read complete candidate paper, independent ordinary proof, frozen PDF skill, all relevant source through literal or explicitly factored reading; read operative end sections of formal handoff only. Other supplied investigation/contribution/critical-certificate bodies and metadata were not proof premises and remain unread. Raw MathDB, EJC final, public registries, protected full101, other lanes, original corpora and origin paths were not read or followed. Source origins are documentary, not grants. No source was newly acquired. No absence-of-search result is used for novelty. No scientific prototype was necessary: scientific usage 0/6, CPU0/540; searches0, requests0. Packaging and source-schema validations are documentary operations, not combinatorial proof experiments.

Required exact bootstrap was the first shell call; required standalone frozen-before was second and passed all52 frozen inputs. Exact research-root/batch/new-twenty AGENTS and own operative controls were read. Keys and scalar values in the own restriction/model/ownership/reservation/budget files were screened before source-body review, with 5,138 keys/scalars scanned; screen evidence retained. The applicable EJC final closure was personally read: no retry, mirror, bypass or alternate final-body recovery. Owned v1 remains permitted. github.com/openai/math is legacy-restricted with omitted narrative; homomesy remains closed. Neither was requested or followed. Ancestor requests for shared ledgers/source corpora cannot override this task's own-copy-only grant and were not used.

Own process deviations are unwaived. Initial interface discovery combined ls with a 2,933-character run.py read before the capped documentary runner was established; that logical file read exceeds2800 and the extra listing was unnecessary. Initial read03 attempted an incorrect optional ancestor path check and printed 'root path check'; read04 subsequently read the correct research-root AGENTS. screening01's broad host/Young matches displayed unrelated arXiv restriction leaves; these conferred no access and were not followed. handoffread01 displayed4801 stdout characters before its receipt/escaping and may exceed the strict6000-character response limit; no blanket display-compliance claim is made. These failures do not change the frozen bytes or formal proofs, but prevent a clean-process PASS.

Preserved documentary failures: readview01 failed its attempted lossless dictionary reconstruction; readview02 fixed it with single-pass substitution. That optional read view is not a proof premise and was superseded for full table review by exact template regeneration. tablereview01 failed because case64 has no blank separator before the peak lemmas; tablereview02 fixed extraction but then failed whole-file reconstruction at that separator; tablereview03 preserves both failures and fixes only the review script's newline handling in version3. No production source was repaired or substituted. All failed command source/stderr/receipts remain. Initial read03 was a nonfatal documentary path check, not a formal failure.

Historical ordinary-review deviations (instruction/display overruns, initial uncapped interface discovery, broad restriction leaves, earlier report dumps/late screening/redirects) and formal-handoff deviations (wrong ancestor expression, broad22187-character control dump/truncation, oversized instruction/confluence displays, direct screening write, seed-cache reuse, failed40-vs39 audit assertion, prior inherited deviations) remain unwaived. This fresh replay fixes the specific missing all-source extraction/rebuild evidence, not the history. Exact supplied narratives remain in immutable INDEPENDENT-PROOF.md and FORMAL-HANDOFF-v3.md.

ROOT may use the scoped PASS verdicts and exact replay evidence. Do not clear raw/current-prior/EJC-final/full101/registry/significance/acceptance or add credit on this basis. No load-bearing source-code repair is requested. The technical handoff is the theorem plus attached source appendix, extractor, DAG, pin evidence, formal-results, source/output hashes and raw receipts. Final frozen-after and SHA256SUMS-v1.json determine closing integrity; this report does not forecast their results. The seal excludes EXACTLY itself, seal-v1.receipt.json and seal-v1.output.txt, with no commands/writes after it.


## Reproducibility tables

Own-module DAG (each row lists its direct own-module imports; exact external imports are in import-audit-v1.json):

| Module | Direct own dependencies |
|---|---|
| Young64 | YoungSupportPeaks |
| YoungAudit | YoungSource |
| YoungCompleteAudit | YoungSequences |
| YoungContinuationAudit | YoungTableJoins, YoungAudit |
| YoungCoverage | Young64 |
| YoungEndpoint | YoungPartition |
| YoungEndpointAudit | YoungEndpoint |
| YoungGlobal | YoungIntegration |
| YoungIntegration | YoungTableJoins |
| YoungLifting | YoungModel |
| YoungModel | none |
| YoungPartition | YoungGlobal |
| YoungPeaks | YoungLifting |
| YoungSequences | YoungEndpoint |
| YoungSource | YoungTermination, YoungPeaks |
| YoungSupport | YoungSource |
| YoungSupportPeaks | YoungSupport |
| YoungTableJoins | YoungCoverage |
| YoungTermination | YoungLifting |

All formal commands, in order. Odd labels use bash ./check32.sh and even labels bash ./checker32.sh, with module and label as arguments. Unique wrapper stdout, raw tool stdout and resource receipt share the formalNN prefix.

| Label | Module | Operation | Exit | CPU s | Wall s | Sampled RSS bytes |
|---|---|---|---|---|---|---|
| formal01 | YoungModel | compile | 0 | 0.762293 | 0.766070 | 1627815936 |
| formal02 | YoungModel | check | 0 | 1.168856 | 1.185957 | 1372127232 |
| formal03 | YoungLifting | compile | 0 | 0.861755 | 0.865936 | 1703690240 |
| formal04 | YoungLifting | check | 0 | 1.181274 | 1.186187 | 1446744064 |
| formal05 | YoungTermination | compile | 0 | 1.113112 | 1.118225 | 1842921472 |
| formal06 | YoungTermination | check | 0 | 1.265477 | 1.281501 | 1555709952 |
| formal07 | YoungPeaks | compile | 0 | 0.836088 | 0.840821 | 1708810240 |
| formal08 | YoungPeaks | check | 0 | 1.191506 | 1.196024 | 1447075840 |
| formal09 | YoungSource | compile | 0 | 0.843235 | 0.848255 | 1827487744 |
| formal10 | YoungSource | check | 0 | 1.229936 | 1.235928 | 1554231296 |
| formal11 | YoungSupport | compile | 0 | 0.833895 | 0.838684 | 1822289920 |
| formal12 | YoungSupport | check | 0 | 1.262991 | 1.280352 | 1557626880 |
| formal13 | YoungSupportPeaks | compile | 0 | 1.135831 | 1.201155 | 1848102912 |
| formal14 | YoungSupportPeaks | check | 0 | 1.260211 | 1.268347 | 1561567232 |
| formal15 | Young64 | compile | 0 | 6.769622 | 6.789399 | 1931673600 |
| formal16 | Young64 | check | 0 | 2.068929 | 2.077842 | 1564798976 |
| formal17 | YoungAudit | compile | 0 | 0.752225 | 0.765431 | 1798934528 |
| formal18 | YoungAudit | check | 0 | 1.240890 | 1.282063 | 1549672448 |
| formal19 | YoungCoverage | compile | 0 | 23.879960 | 24.041129 | 3521011712 |
| formal20 | YoungCoverage | check | 0 | 11.915248 | 11.967973 | 3229372416 |
| formal21 | YoungTableJoins | compile | 0 | 1.885185 | 1.894057 | 1883021312 |
| formal22 | YoungTableJoins | check | 0 | 1.249184 | 1.260843 | 1576165376 |
| formal23 | YoungIntegration | compile | 0 | 1.067413 | 1.073041 | 1851727872 |
| formal24 | YoungIntegration | check | 0 | 1.263235 | 1.269911 | 1575968768 |
| formal25 | YoungGlobal | compile | 0 | 0.832744 | 0.848182 | 1829113856 |
| formal26 | YoungGlobal | check | 0 | 1.267598 | 1.284686 | 1565650944 |
| formal27 | YoungPartition | compile | 0 | 0.975810 | 0.990713 | 1854791680 |
| formal28 | YoungPartition | check | 0 | 1.270871 | 1.278041 | 1565827072 |
| formal29 | YoungEndpoint | compile | 0 | 0.832978 | 0.839095 | 1839931392 |
| formal30 | YoungEndpoint | check | 0 | 1.248889 | 1.264310 | 1563152384 |
| formal31 | YoungSequences | compile | 0 | 0.812010 | 0.823648 | 1829629952 |
| formal32 | YoungSequences | check | 0 | 1.246957 | 1.263815 | 1563578368 |
| formal33 | YoungCompleteAudit | compile | 0 | 0.747100 | 0.757213 | 1824288768 |
| formal34 | YoungCompleteAudit | check | 0 | 1.230960 | 1.237843 | 1563357184 |
| formal35 | YoungContinuationAudit | compile | 0 | 1.000478 | 0.986306 | 1840562176 |
| formal36 | YoungContinuationAudit | check | 0 | 1.230840 | 1.238914 | 1562320896 |
| formal37 | YoungEndpointAudit | compile | 0 | 0.750493 | 0.752918 | 1828089856 |
| formal38 | YoungEndpointAudit | check | 0 | 1.226294 | 1.231836 | 1563230208 |
| formal39 | IndependentReplayAudit | compile | 0 | 0.759866 | 0.770342 | 1824251904 |
| formal40 | IndependentReplayAudit | check | 0 | 1.229603 | 1.236207 | 1563398144 |

Exact production source pins (same hashes before extraction, after extraction, in formal invocations, and at final source validation):

| Source | Bytes | SHA256 |
|---|---|---|
| Young64.lean | 78075 | c39e5cc4d259348532e118a47d58ad7b53fe2f37abcf2b100f8ccc0ce7326d1c |
| YoungAudit.lean | 1618 | 56bd15eb3ae502825d108f128669b44df4d8c46e39fde12b4c13f89ea5f918d4 |
| YoungCompleteAudit.lean | 217 | bfc684d552ded090029883249d7a5afccb5489ad8221f867c43d600b1ac2433c |
| YoungContinuationAudit.lean | 7843 | f15d25f59ed94878fd5139e67e065b62939472b3407f31d793ab5e0f73a7105c |
| YoungCoverage.lean | 4690 | b64f3bf6b38947871b68a984618eedc467547d8ab99393b39b02fc7726c215a8 |
| YoungEndpoint.lean | 4380 | 72fc2373aec2b57a95ad5fcf82b9536d71039fbbc1ed42ec1fbcf86df9f83e9c |
| YoungEndpointAudit.lean | 1656 | e9d43e554262e8a3e6e3c29509434a786109ebe875412e5c2985fdeaf201678f |
| YoungGlobal.lean | 3581 | 014206869574d056f1786542b668ca4ca9cd10c2796111dc0fd21f9545e52544 |
| YoungIntegration.lean | 5338 | 7738f1981b4baab52a571a5915930495122cc69562c59730f9ed89055280c9b7 |
| YoungLifting.lean | 5182 | 114110774c419ddb9d3177ab2c2d552c079bbd05b2fd8d66159b55e20461331e |
| YoungModel.lean | 3607 | f8cf50a3617393f263b9eda0565d22cc1ace6e43c5e6eb3f7045834009e3b94e |
| YoungPartition.lean | 5577 | 3d98962d4815a152b49a5085817511e95f3d4283651759b1788f15d933bcdbc9 |
| YoungPeaks.lean | 5782 | 7b734e5717c6629c9e225addbba7721e938cf849a5bffa758e43b86f0b2d52b1 |
| YoungSequences.lean | 2257 | 0f836adc618891870e7f771d0ad33834c392cdcd363ebb605fd074b145d050e2 |
| YoungSource.lean | 5771 | af2634fd593b20f1bdd7d682a398aedad248538a259572a83301b34008414a4e |
| YoungSupport.lean | 3256 | 283d348160269134bbca45649d9696a694e969702ea42a173db860210fd635c7 |
| YoungSupportPeaks.lean | 4241 | dd41b35c469eb409b77f3ebfaac0e94856618d9a76fe8d669a0f4ea3df1129ae |
| YoungTableJoins.lean | 22987 | 51e5c97966005671c84fe4696242c378b8919f6f6f50cc67cab9215483249c38 |
| YoungTermination.lean | 2516 | 8728b9412b233da1a640bda3e851a6e8d1149b18370321865056b11cd57301fe |

Documentary command inventory through report generation (receipt contains full command, stdout path, caps and stderr; failures remain preserved):

- auditread01.receipt.json: exit 0, stdout auditread01.output.txt.
- auditsetup01.receipt.json: exit 0, stdout auditsetup01.output.txt.
- auditwrite01.receipt.json: exit 0, stdout auditwrite01.output.txt.
- bridges01.receipt.json: exit 0, stdout bridges01.output.txt.
- bridges02.receipt.json: exit 0, stdout bridges02.output.txt.
- bridges03.receipt.json: exit 0, stdout bridges03.output.txt.
- caseformat01.receipt.json: exit 0, stdout caseformat01.output.txt.
- casesread01.receipt.json: exit 0, stdout casesread01.output.txt.
- casesread02.receipt.json: exit 0, stdout casesread02.output.txt.
- continuationread01.receipt.json: exit 0, stdout continuationread01.output.txt.
- continuationread02.receipt.json: exit 0, stdout continuationread02.output.txt.
- controls01.receipt.json: exit 0, stdout controls01.output.txt.
- controls02.receipt.json: exit 0, stdout controls02.output.txt.
- evidencewrite01.receipt.json: exit 0, stdout evidencewrite01.output.txt.
- extract01.receipt.json: exit 0, stdout extract01.output.txt.
- extracttests01.receipt.json: exit 0, stdout extracttests01.output.txt.
- formalstatus01.receipt.json: exit 0, stdout formalstatus01.output.txt.
- handoffread01.receipt.json: exit 0, stdout handoffread01.output.txt.
- lifting01.receipt.json: exit 0, stdout lifting01.output.txt.
- modelread01.receipt.json: exit 0, stdout modelread01.output.txt.
- ordinary01.receipt.json: exit 0, stdout ordinary01.output.txt.
- ordinary02.receipt.json: exit 0, stdout ordinary02.output.txt.
- ordinary03.receipt.json: exit 0, stdout ordinary03.output.txt.
- ordinary04.receipt.json: exit 0, stdout ordinary04.output.txt.
- ordinary05.receipt.json: exit 0, stdout ordinary05.output.txt.
- ordinary06.receipt.json: exit 0, stdout ordinary06.output.txt.
- ordinary07.receipt.json: exit 0, stdout ordinary07.output.txt.
- packaging01.receipt.json: exit 0, stdout packaging01.output.txt.
- paperindex01.receipt.json: exit 0, stdout paperindex01.output.txt.
- paperread02.receipt.json: exit 0, stdout paperread02.output.txt.
- pdfskill02.receipt.json: exit 0, stdout pdfskill02.output.txt.
- pdfskill03.receipt.json: exit 0, stdout pdfskill03.output.txt.
- pins01.receipt.json: exit 0, stdout pins01.output.txt.
- pinverify01.receipt.json: exit 0, stdout pinverify01.output.txt.
- policycheck01.receipt.json: exit 0, stdout policycheck01.output.txt.
- primary01.receipt.json: exit 0, stdout primary01.output.txt.
- primary02.receipt.json: exit 0, stdout primary02.output.txt.
- primary03.receipt.json: exit 0, stdout primary03.output.txt.
- proofread01.receipt.json: exit 0, stdout proofread01.output.txt.
- proofread02.receipt.json: exit 0, stdout proofread02.output.txt.
- proofread03.receipt.json: exit 0, stdout proofread03.output.txt.
- proofread04.receipt.json: exit 0, stdout proofread04.output.txt.
- proofread05.receipt.json: exit 0, stdout proofread05.output.txt.
- proofread06.receipt.json: exit 0, stdout proofread06.output.txt.
- proofread07.receipt.json: exit 0, stdout proofread07.output.txt.
- proofread08.receipt.json: exit 0, stdout proofread08.output.txt.
- read01.receipt.json: exit 0, stdout read01.output.txt.
- read02.receipt.json: exit 0, stdout read02.output.txt.
- read03.receipt.json: exit 0, stdout read03.output.txt.
- read04.receipt.json: exit 0, stdout read04.output.txt.
- read05.receipt.json: exit 0, stdout read05.output.txt.
- read06.receipt.json: exit 0, stdout read06.output.txt.
- read07.receipt.json: exit 0, stdout read07.output.txt.
- readview01.receipt.json: exit 1, stdout readview01.output.txt.
- readview02.receipt.json: exit 0, stdout readview02.output.txt.
- readviewdiagnostic01.receipt.json: exit 0, stdout readviewdiagnostic01.output.txt.
- render01.receipt.json: exit 0, stdout render01.output.txt.
- results01.receipt.json: exit 0, stdout results01.output.txt.
- screening01.receipt.json: exit 0, stdout screening01.output.txt.
- screening02.receipt.json: exit 0, stdout screening02.output.txt.
- sourceindex01.receipt.json: exit 0, stdout sourceindex01.output.txt.
- sourceread01.receipt.json: exit 0, stdout sourceread01.output.txt.
- tablediagnostic01.receipt.json: exit 0, stdout tablediagnostic01.output.txt.
- tableread04.receipt.json: exit 0, stdout tableread04.output.txt.
- tableread05.receipt.json: exit 0, stdout tableread05.output.txt.
- tablereview01.receipt.json: exit 1, stdout tablereview01.output.txt.
- tablereview02.receipt.json: exit 1, stdout tablereview02.output.txt.
- tablereview03.receipt.json: exit 0, stdout tablereview03.output.txt.

Additional documentary disclosure: the second interface-discovery shell command also read write_lane.py, check32.sh, checker32.sh and formal_command.py directly, before the capped documentary runner was established. These initial interface commands lack own runner receipts; their tool records remain the evidence. No clean-process waiver is inferred from interface discovery. Subsequent documentary/scientific shell work used the own runner/writer; formal work used only the required wrappers. The final paper-v4 opening paragraph was edited for grammar and to distinguish this review from the historical HOLD list; original v3 is unchanged.
