from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path(__file__).resolve().parent
pins=json.loads((root/'SOURCE-PROOF-PINS.json').read_text())['files']
def parse(data):
 found={}; pos=0
 for m in re.finditer(rb'^```lean module=([^\n]+)\n(.*?)^```\n',data,re.M|re.S):
  name=m[1].decode('ascii')
  if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*\.lean',name):raise ValueError('invalid path')
  if name not in pins or name in found:raise ValueError('unexpected/duplicate module')
  b=m[2]; p=pins[name]
  if len(b)!=p['bytes'] or hashlib.sha256(b).hexdigest()!=p['sha256']:raise ValueError('bytes/hash mismatch')
  found[name]=b;pos=m.end()
 if set(found)!=set(pins) or data.count(b'```lean module=')!=len(found):raise ValueError('missing/malformed module')
 if data.count(b'```')!=2*len(found):raise ValueError('unexpected fence')
 return found
if __name__=='__main__':
 data=(root/'REPRODUCIBILITY-APPENDIX-v1.md').read_bytes(); found=parse(data)
 dest=root/'src';assert not list(dest.iterdir()),'src must start empty'
 for name,b in found.items():
  subprocess.run([sys.executable,'-I','-B',str(root/'write_lane.py'),'src/'+name,'--base64'],input=__import__('base64').b64encode(b).decode(),text=True,capture_output=True,check=True)
 assert set(p.name for p in dest.iterdir())==set(pins)
 for n,p in pins.items():assert hashlib.sha256((dest/n).read_bytes()).hexdigest()==p['sha256']
 print(json.dumps({'extracted_modules':len(found),'source':'appendix v1','all_hashes_verified':True}))
