import Rigidity
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
namespace BoardV1
def corner00 (k : ℕ) : Pos (2*k+1) := (⟨0, by omega⟩, ⟨0, by omega⟩)
theorem corner00_0 (k : ℕ) : L (corner00 k) 0 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner00 k) w 0 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner00, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner00_1 (k : ℕ) : L (corner00 k) 1 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner00 k) w 1 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner00, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner00_2 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner00 k) 2 := by
  apply L_ge_one (w := (⟨0, by omega⟩, ⟨1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner00, row, col] <;> omega
theorem corner00_3 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner00 k) 3 := by
  apply L_ge_one (w := (⟨1, by omega⟩, ⟨1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner00, row, col] <;> omega
theorem corner00_4 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner00 k) 4 := by
  apply L_ge_one (w := (⟨1, by omega⟩, ⟨0, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner00, row, col] <;> omega
theorem corner00_5 (k : ℕ) : L (corner00 k) 5 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner00 k) w 5 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner00, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner00_6 (k : ℕ) : L (corner00 k) 6 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner00 k) w 6 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner00, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner00_7 (k : ℕ) : L (corner00 k) 7 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner00 k) w 7 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner00, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
def corner01 (k : ℕ) : Pos (2*k+1) := (⟨0, by omega⟩, ⟨2*k, by omega⟩)
theorem corner01_0 (k : ℕ) : L (corner01 k) 0 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner01 k) w 0 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner01, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner01_1 (k : ℕ) : L (corner01 k) 1 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner01 k) w 1 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner01, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner01_2 (k : ℕ) : L (corner01 k) 2 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner01 k) w 2 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner01, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner01_3 (k : ℕ) : L (corner01 k) 3 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner01 k) w 3 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner01, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner01_4 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner01 k) 4 := by
  apply L_ge_one (w := (⟨1, by omega⟩, ⟨2*k, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner01, row, col] <;> omega
theorem corner01_5 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner01 k) 5 := by
  apply L_ge_one (w := (⟨1, by omega⟩, ⟨2*k-1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner01, row, col] <;> omega
theorem corner01_6 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner01 k) 6 := by
  apply L_ge_one (w := (⟨0, by omega⟩, ⟨2*k-1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner01, row, col] <;> omega
theorem corner01_7 (k : ℕ) : L (corner01 k) 7 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner01 k) w 7 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner01, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
def corner10 (k : ℕ) : Pos (2*k+1) := (⟨2*k, by omega⟩, ⟨0, by omega⟩)
theorem corner10_0 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner10 k) 0 := by
  apply L_ge_one (w := (⟨2*k-1, by omega⟩, ⟨0, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner10, row, col] <;> omega
theorem corner10_1 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner10 k) 1 := by
  apply L_ge_one (w := (⟨2*k-1, by omega⟩, ⟨1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner10, row, col] <;> omega
theorem corner10_2 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner10 k) 2 := by
  apply L_ge_one (w := (⟨2*k, by omega⟩, ⟨1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner10, row, col] <;> omega
theorem corner10_3 (k : ℕ) : L (corner10 k) 3 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner10 k) w 3 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner10, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner10_4 (k : ℕ) : L (corner10 k) 4 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner10 k) w 4 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner10, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner10_5 (k : ℕ) : L (corner10 k) 5 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner10 k) w 5 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner10, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner10_6 (k : ℕ) : L (corner10 k) 6 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner10 k) w 6 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner10, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner10_7 (k : ℕ) : L (corner10 k) 7 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner10 k) w 7 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner10, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
def corner11 (k : ℕ) : Pos (2*k+1) := (⟨2*k, by omega⟩, ⟨2*k, by omega⟩)
theorem corner11_0 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner11 k) 0 := by
  apply L_ge_one (w := (⟨2*k-1, by omega⟩, ⟨2*k, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner11, row, col] <;> omega
theorem corner11_1 (k : ℕ) : L (corner11 k) 1 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner11 k) w 1 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner11, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner11_2 (k : ℕ) : L (corner11 k) 2 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner11 k) w 2 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner11, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner11_3 (k : ℕ) : L (corner11 k) 3 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner11 k) w 3 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner11, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner11_4 (k : ℕ) : L (corner11 k) 4 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner11 k) w 4 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner11, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner11_5 (k : ℕ) : L (corner11 k) 5 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (corner11 k) w 5 := by
    rintro ⟨t, ht, hr, hc⟩
    simp [corner11, row, col] at hr hc
    have h₁ := w.1.isLt
    have h₂ := w.2.isLt
    omega
  simp only [ite_eq_right hh]
theorem corner11_6 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner11 k) 6 := by
  apply L_ge_one (w := (⟨2*k, by omega⟩, ⟨2*k-1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner11, row, col] <;> omega
theorem corner11_7 (k : ℕ) (hk : 1 ≤ k) : 1 ≤ L (corner11 k) 7 := by
  apply L_ge_one (w := (⟨2*k-1, by omega⟩, ⟨2*k-1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [corner11, row, col] <;> omega
theorem profile_injective {k : ℕ} (hk : 1 ≤ k) (d e : Dir)
    (h : ∀ v : Pos (2*k+1), L v d = L v e) : d = e := by
  fin_cases d <;> fin_cases e
  · rfl
  · have hh := h (corner11 k)
    change L (corner11 k) 0 = L (corner11 k) 1 at hh
    have hd := corner11_0 k hk
    have he := corner11_1 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 0 = L (corner00 k) 2 at hh
    have hd := corner00_0 k
    have he := corner00_2 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 0 = L (corner00 k) 3 at hh
    have hd := corner00_0 k
    have he := corner00_3 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 0 = L (corner00 k) 4 at hh
    have hd := corner00_0 k
    have he := corner00_4 k hk
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 0 = L (corner01 k) 5 at hh
    have hd := corner01_0 k
    have he := corner01_5 k hk
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 0 = L (corner01 k) 6 at hh
    have hd := corner01_0 k
    have he := corner01_6 k hk
    omega
  · have hh := h (corner10 k)
    change L (corner10 k) 0 = L (corner10 k) 7 at hh
    have hd := corner10_0 k hk
    have he := corner10_7 k
    omega
  · have hh := h (corner11 k)
    change L (corner11 k) 1 = L (corner11 k) 0 at hh
    have hd := corner11_1 k
    have he := corner11_0 k hk
    omega
  · rfl
  · have hh := h (corner00 k)
    change L (corner00 k) 1 = L (corner00 k) 2 at hh
    have hd := corner00_1 k
    have he := corner00_2 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 1 = L (corner00 k) 3 at hh
    have hd := corner00_1 k
    have he := corner00_3 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 1 = L (corner00 k) 4 at hh
    have hd := corner00_1 k
    have he := corner00_4 k hk
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 1 = L (corner01 k) 5 at hh
    have hd := corner01_1 k
    have he := corner01_5 k hk
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 1 = L (corner01 k) 6 at hh
    have hd := corner01_1 k
    have he := corner01_6 k hk
    omega
  · have hh := h (corner10 k)
    change L (corner10 k) 1 = L (corner10 k) 7 at hh
    have hd := corner10_1 k hk
    have he := corner10_7 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 2 = L (corner00 k) 0 at hh
    have hd := corner00_2 k hk
    have he := corner00_0 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 2 = L (corner00 k) 1 at hh
    have hd := corner00_2 k hk
    have he := corner00_1 k
    omega
  · rfl
  · have hh := h (corner10 k)
    change L (corner10 k) 2 = L (corner10 k) 3 at hh
    have hd := corner10_2 k hk
    have he := corner10_3 k
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 2 = L (corner01 k) 4 at hh
    have hd := corner01_2 k
    have he := corner01_4 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 2 = L (corner00 k) 5 at hh
    have hd := corner00_2 k hk
    have he := corner00_5 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 2 = L (corner00 k) 6 at hh
    have hd := corner00_2 k hk
    have he := corner00_6 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 2 = L (corner00 k) 7 at hh
    have hd := corner00_2 k hk
    have he := corner00_7 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 3 = L (corner00 k) 0 at hh
    have hd := corner00_3 k hk
    have he := corner00_0 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 3 = L (corner00 k) 1 at hh
    have hd := corner00_3 k hk
    have he := corner00_1 k
    omega
  · have hh := h (corner10 k)
    change L (corner10 k) 3 = L (corner10 k) 2 at hh
    have hd := corner10_3 k
    have he := corner10_2 k hk
    omega
  · rfl
  · have hh := h (corner01 k)
    change L (corner01 k) 3 = L (corner01 k) 4 at hh
    have hd := corner01_3 k
    have he := corner01_4 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 3 = L (corner00 k) 5 at hh
    have hd := corner00_3 k hk
    have he := corner00_5 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 3 = L (corner00 k) 6 at hh
    have hd := corner00_3 k hk
    have he := corner00_6 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 3 = L (corner00 k) 7 at hh
    have hd := corner00_3 k hk
    have he := corner00_7 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 4 = L (corner00 k) 0 at hh
    have hd := corner00_4 k hk
    have he := corner00_0 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 4 = L (corner00 k) 1 at hh
    have hd := corner00_4 k hk
    have he := corner00_1 k
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 4 = L (corner01 k) 2 at hh
    have hd := corner01_4 k hk
    have he := corner01_2 k
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 4 = L (corner01 k) 3 at hh
    have hd := corner01_4 k hk
    have he := corner01_3 k
    omega
  · rfl
  · have hh := h (corner00 k)
    change L (corner00 k) 4 = L (corner00 k) 5 at hh
    have hd := corner00_4 k hk
    have he := corner00_5 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 4 = L (corner00 k) 6 at hh
    have hd := corner00_4 k hk
    have he := corner00_6 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 4 = L (corner00 k) 7 at hh
    have hd := corner00_4 k hk
    have he := corner00_7 k
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 5 = L (corner01 k) 0 at hh
    have hd := corner01_5 k hk
    have he := corner01_0 k
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 5 = L (corner01 k) 1 at hh
    have hd := corner01_5 k hk
    have he := corner01_1 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 5 = L (corner00 k) 2 at hh
    have hd := corner00_5 k
    have he := corner00_2 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 5 = L (corner00 k) 3 at hh
    have hd := corner00_5 k
    have he := corner00_3 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 5 = L (corner00 k) 4 at hh
    have hd := corner00_5 k
    have he := corner00_4 k hk
    omega
  · rfl
  · have hh := h (corner11 k)
    change L (corner11 k) 5 = L (corner11 k) 6 at hh
    have hd := corner11_5 k
    have he := corner11_6 k hk
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 5 = L (corner01 k) 7 at hh
    have hd := corner01_5 k hk
    have he := corner01_7 k
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 6 = L (corner01 k) 0 at hh
    have hd := corner01_6 k hk
    have he := corner01_0 k
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 6 = L (corner01 k) 1 at hh
    have hd := corner01_6 k hk
    have he := corner01_1 k
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 6 = L (corner00 k) 2 at hh
    have hd := corner00_6 k
    have he := corner00_2 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 6 = L (corner00 k) 3 at hh
    have hd := corner00_6 k
    have he := corner00_3 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 6 = L (corner00 k) 4 at hh
    have hd := corner00_6 k
    have he := corner00_4 k hk
    omega
  · have hh := h (corner11 k)
    change L (corner11 k) 6 = L (corner11 k) 5 at hh
    have hd := corner11_6 k hk
    have he := corner11_5 k
    omega
  · rfl
  · have hh := h (corner01 k)
    change L (corner01 k) 6 = L (corner01 k) 7 at hh
    have hd := corner01_6 k hk
    have he := corner01_7 k
    omega
  · have hh := h (corner10 k)
    change L (corner10 k) 7 = L (corner10 k) 0 at hh
    have hd := corner10_7 k
    have he := corner10_0 k hk
    omega
  · have hh := h (corner10 k)
    change L (corner10 k) 7 = L (corner10 k) 1 at hh
    have hd := corner10_7 k
    have he := corner10_1 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 7 = L (corner00 k) 2 at hh
    have hd := corner00_7 k
    have he := corner00_2 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 7 = L (corner00 k) 3 at hh
    have hd := corner00_7 k
    have he := corner00_3 k hk
    omega
  · have hh := h (corner00 k)
    change L (corner00 k) 7 = L (corner00 k) 4 at hh
    have hd := corner00_7 k
    have he := corner00_4 k hk
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 7 = L (corner01 k) 5 at hh
    have hd := corner01_7 k
    have he := corner01_5 k hk
    omega
  · have hh := h (corner01 k)
    change L (corner01 k) 7 = L (corner01 k) 6 at hh
    have hd := corner01_7 k
    have he := corner01_6 k hk
    omega
  · rfl
end BoardV1
