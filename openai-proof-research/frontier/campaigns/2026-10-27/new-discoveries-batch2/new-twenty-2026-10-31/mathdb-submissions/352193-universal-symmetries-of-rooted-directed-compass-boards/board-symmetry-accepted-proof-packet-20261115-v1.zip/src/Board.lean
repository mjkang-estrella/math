import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Algebra.Ring.Parity

/- Source: Shaviv arXiv:2110.05416v1, Definitions 2,11 and §5.1.
No gameplay stopping rule is imposed on the graph. -/
namespace BoardV1
open scoped BigOperators
abbrev Pos (n : ℕ) := Fin n × Fin n
abbrev Dir := Fin 8
abbrev Board (n : ℕ) := Pos n → Dir

def row (d : Dir) : ℤ :=
  match d.val with
  | 0 => -1 | 1 => -1 | 2 => 0 | 3 => 1
  | 4 => 1 | 5 => 1 | 6 => 0 | _ => -1

def col (d : Dir) : ℤ :=
  match d.val with
  | 0 => 0 | 1 => 1 | 2 => 1 | 3 => 1
  | 4 => 0 | 5 => -1 | 6 => -1 | _ => -1

def Ray {n : ℕ} (v w : Pos n) (d : Dir) : Prop :=
  ∃ t : ℕ, 0 < t ∧
    (w.1.val : ℤ) = v.1.val + (t : ℤ) * row d ∧
    (w.2.val : ℤ) = v.2.val + (t : ℤ) * col d

def Edge {n : ℕ} (A : Board n) (v w : Pos n) : Prop := Ray v w (A v)

def Transform {n : ℕ} (σ : Equiv.Perm (Pos n)) (τ : Equiv.Perm Dir)
    (A : Board n) : Board n := fun v => τ (A (σ v))

def start (k : ℕ) : Pos (2*k+1) := (⟨0, by omega⟩, ⟨0, by omega⟩)
def center (k : ℕ) : Pos (2*k+1) := (⟨k, by omega⟩, ⟨k, by omega⟩)

structure RootedIso {k : ℕ} (A B : Board (2*k+1)) where
  vertex : Equiv.Perm (Pos (2*k+1))
  beginning : vertex (start k) = start k
  ending : vertex (center k) = center k
  edge_iff : ∀ v w, Edge A v w ↔ Edge B (vertex v) (vertex w)

def Universal {k : ℕ} (σ : Equiv.Perm (Pos (2*k+1))) (τ : Equiv.Perm Dir) : Prop :=
  ∀ A, Nonempty (RootedIso A (Transform σ τ A))

noncomputable def L {n : ℕ} (v : Pos n) (d : Dir) : ℤ := by
  classical
  exact ∑ w : Pos n, if Ray v w d then 1 else 0
noncomputable def total {n : ℕ} (A : Board n) : ℤ := ∑ v, L v (A v)

theorem odd_size_bridge (n : ℕ) :
    (Odd n ∧ 3 ≤ n) ↔ ∃ k : ℕ, 1 ≤ k ∧ n = 2*k+1 := by
  constructor
  · rintro ⟨⟨k, hk⟩, hn⟩
    exact ⟨k, by omega, by omega⟩
  · rintro ⟨k, hk, rfl⟩
    exact ⟨⟨k, by omega⟩, by omega⟩

theorem outdegree_iso {k : ℕ} {A B : Board (2*k+1)}
    (f : RootedIso A B) (v : Pos (2*k+1)) :
    L v (A v) = L (f.vertex v) (B (f.vertex v)) := by
  classical
  unfold L
  apply Fintype.sum_equiv f.vertex
  intro w
  have h := f.edge_iff v w
  unfold Edge at h
  rw [h]

theorem total_iso {k : ℕ} {A B : Board (2*k+1)} (f : RootedIso A B) :
    total A = total B := by
  classical
  unfold total
  apply Fintype.sum_equiv f.vertex
  intro v
  exact outdegree_iso f v

theorem universal_total {k : ℕ} {σ : Equiv.Perm (Pos (2*k+1))}
    {τ : Equiv.Perm Dir} (h : Universal σ τ) (A : Board (2*k+1)) :
    total A = total (Transform σ τ A) := by
  obtain ⟨f⟩ := h A
  exact total_iso f

theorem universal_start {k : ℕ} {σ : Equiv.Perm (Pos (2*k+1))}
    {τ : Equiv.Perm Dir} (h : Universal σ τ) (A : Board (2*k+1)) :
    L (start k) (A (start k)) = L (start k) (τ (A (σ (start k)))) := by
  obtain ⟨f⟩ := h A
  simpa only [f.beginning, Transform] using outdegree_iso f (start k)
end BoardV1
