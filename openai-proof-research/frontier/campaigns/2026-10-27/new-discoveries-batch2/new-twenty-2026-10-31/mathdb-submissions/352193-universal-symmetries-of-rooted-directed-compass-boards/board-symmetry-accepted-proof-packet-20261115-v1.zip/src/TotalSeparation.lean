import Separation
import Mathlib.Algebra.Order.Ring.Int
namespace BoardV1
open scoped BigOperators
noncomputable def revRows (n : ℕ) : Equiv.Perm (Pos n) where
  toFun v := (v.1.rev, v.2)
  invFun v := (v.1.rev, v.2)
  left_inv v := by simp
  right_inv v := by simp

theorem total_NS (n : ℕ) :
    (∑ v : Pos n, L v 0) = ∑ v : Pos n, L v 4 := by
  apply Fintype.sum_equiv (revRows n)
  intro v
  simp [L_north, L_south, revRows, Fin.rev]
  have hv := v.1.isLt
  omega

theorem total_transpose (n : ℕ) (d : Dir) :
    (∑ v : Pos n, L v d) = ∑ v : Pos n, L v (transposeDir d) := by
  apply Fintype.sum_equiv (transposePos n)
  intro v
  exact L_transpose v d

def IsCard (d : Dir) : Prop := d = 0 ∨ d = 2 ∨ d = 4 ∨ d = 6

theorem total_cardinal (n : ℕ) {d : Dir} (hd : IsCard d) :
    (∑ v : Pos n, L v d) = ∑ v : Pos n, L v 0 := by
  rcases hd with rfl | rfl | rfl | rfl
  · rfl
  · have h := total_transpose n 2
    change (∑ v : Pos n, L v 2) = ∑ v : Pos n, L v 4 at h
    exact h.trans (total_NS n).symm
  · exact (total_NS n).symm
  · exact total_transpose n 6

theorem diagonal_lt {k : ℕ} (hk : 1 ≤ k) {d : Dir} (hd : ¬ IsCard d) :
    (∑ v : Pos (2*k+1), L v d) < ∑ v : Pos (2*k+1), L v 0 := by
  classical
  fin_cases d
  all_goals try { exfalso; apply hd; unfold IsCard; decide }
  · apply Finset.sum_lt_sum
    · intro v _
      exact ray_row_le v 1 0 rfl (by decide) rfl
    · refine ⟨corner11 k, Finset.mem_univ _, ?_⟩
      have h := corner11_0 k hk
      change L (corner11 k) (1 : Dir) < L (corner11 k) 0
      rw [corner11_1]
      omega
  · rw [total_NS]
    apply Finset.sum_lt_sum
    · intro v _
      exact ray_row_le v 3 4 rfl (by decide) rfl
    · refine ⟨corner01 k, Finset.mem_univ _, ?_⟩
      have h := corner01_4 k hk
      change L (corner01 k) (3 : Dir) < L (corner01 k) 4
      rw [corner01_3]
      omega
  · rw [total_NS]
    apply Finset.sum_lt_sum
    · intro v _
      exact ray_row_le v 5 4 rfl (by decide) rfl
    · refine ⟨corner00 k, Finset.mem_univ _, ?_⟩
      have h := corner00_4 k hk
      change L (corner00 k) (5 : Dir) < L (corner00 k) 4
      rw [corner00_5]
      omega
  · apply Finset.sum_lt_sum
    · intro v _
      exact ray_row_le v 7 0 rfl (by decide) rfl
    · refine ⟨corner10 k, Finset.mem_univ _, ?_⟩
      have h := corner10_0 k hk
      change L (corner10 k) (7 : Dir) < L (corner10 k) 0
      rw [corner10_7]
      omega

theorem cardinal_preserved {k : ℕ} (hk : 1 ≤ k)
    {σ : Equiv.Perm (Pos (2*k+1))} {τ : Equiv.Perm Dir}
    (h : Universal σ τ) (d : Dir) : IsCard d ↔ IsCard (τ d) := by
  have ht := universal_constant h d
  constructor
  · intro hd
    by_contra hn
    have hl := diagonal_lt hk hn
    rw [← ht, total_cardinal _ hd] at hl
    exact (lt_irrefl _ hl)
  · intro hd
    by_contra hn
    have hl := diagonal_lt hk hn
    rw [ht, total_cardinal _ hd] at hl
    exact (lt_irrefl _ hl)
end BoardV1
