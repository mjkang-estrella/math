import Normalized
namespace BoardV1
open scoped BigOperators
theorem ray_row_le {n : ℕ} (v : Pos n) (d c : Dir)
    (hr : row d = row c) (hn : row d ≠ 0) (hc : col c = 0) :
    L v d ≤ L v c := by
  classical
  rw [L_card, L_card]
  apply Int.ofNat_le.mpr
  exact Finset.card_le_card_of_injOn (s := Finset.univ.filter (fun w => Ray v w d))
    (t := Finset.univ.filter (fun w => Ray v w c)) (fun w : Pos n => (w.1, v.2))
    (by
      intro w hw
      have hw' := (Finset.mem_filter.mp hw).2
      apply Finset.mem_filter.mpr
      refine ⟨Finset.mem_univ _, ?_⟩
      obtain ⟨t, ht, hrow, _⟩ := hw'
      exact ⟨t, ht, by simpa only [hr] using hrow, by simp [hc]⟩)
    (by
      intro w hw z hz he
      obtain ⟨t, _, hwr, hwc⟩ := (Finset.mem_filter.mp hw).2
      obtain ⟨u, _, hzr, hzc⟩ := (Finset.mem_filter.mp hz).2
      have heq : w.1 = z.1 := (Prod.mk.inj he).1
      have hmul : (t : ℤ) * row d = (u : ℤ) * row d := by
        rw [heq] at hwr
        omega
      have htu : (t : ℤ) = u := mul_right_cancel₀ hn hmul
      rw [htu] at hwc
      exact Prod.ext heq (Fin.ext (by omega)))
end BoardV1
