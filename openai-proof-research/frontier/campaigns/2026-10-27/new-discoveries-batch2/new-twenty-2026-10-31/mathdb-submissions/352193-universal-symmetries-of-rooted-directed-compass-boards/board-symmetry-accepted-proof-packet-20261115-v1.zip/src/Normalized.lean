import Corners
namespace BoardV1

theorem normalized_pair {k : ℕ} (hk : 1 ≤ k)
    {σ : Equiv.Perm (Pos (2*k+1))} {τ : Equiv.Perm Dir}
    (h : Universal σ τ) (hN : τ 0 = 0) (hS : τ 4 = 4) (hW : τ 6 = 6) :
    σ = Equiv.refl _ ∧ τ = Equiv.refl _ := by
  have hs := normalized_positions h hN hS hW
  refine ⟨hs, ?_⟩
  obtain ⟨c, hc⟩ := universal_offsets h
  apply Equiv.ext
  intro d
  apply profile_injective hk (τ d) d
  intro v
  have h₀ := hc v 0
  have hd := hc v d
  rw [hs, Equiv.refl_apply, hN] at h₀
  rw [hs, Equiv.refl_apply] at hd
  omega

def RootedIso.trans {k : ℕ} {A B C : Board (2*k+1)}
    (f : RootedIso A B) (g : RootedIso B C) : RootedIso A C where
  vertex := f.vertex.trans g.vertex
  beginning := by simp only [Equiv.trans_apply, f.beginning, g.beginning]
  ending := by simp only [Equiv.trans_apply, f.ending, g.ending]
  edge_iff := fun v w => (f.edge_iff v w).trans (g.edge_iff (f.vertex v) (f.vertex w))

theorem universal_reflection_normalize {k : ℕ}
    {σ : Equiv.Perm (Pos (2*k+1))} {τ : Equiv.Perm Dir}
    (h : Universal σ τ) :
    Universal ((transposePos _).trans σ) (τ.trans transposeDir) := by
  intro A
  obtain ⟨f⟩ := h A
  exact ⟨f.trans (reflectionIso (Transform σ τ A))⟩

/- Exact intended final proposition, deliberately only a definition.
   No theorem in this closure asserts it. The missing cardinal/geometric reduction
   cannot be supplied by treating normalized_pair as an unconditional classifier. -/
def LiteralEndpoint (k : ℕ) : Prop :=
  ∀ (σ : Equiv.Perm (Pos (2*k+1))) (τ : Equiv.Perm Dir),
    Universal σ τ ↔
      (Transform σ τ = (fun A => A)) ∨
      (Transform σ τ = @Reflection (2*k+1))
end BoardV1
