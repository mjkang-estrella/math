import Cardinals
namespace BoardV1
open scoped BigOperators

theorem L_transpose {n : ℕ} (v : Pos n) (d : Dir) :
    L v d = L (transposePos n v) (transposeDir d) := by
  classical
  unfold L
  apply Fintype.sum_equiv (transposePos n)
  intro w
  rw [transpose_ray]

theorem L_west {n : ℕ} (v : Pos n) : L v 6 = v.2.val := by
  have h := L_transpose v 6
  change L v 6 = L (transposePos n v) 0 at h
  rw [L_north] at h
  exact h

theorem ray_south {n : ℕ} (v w : Pos n) :
    Ray v w 4 ↔ v.1 < w.1 ∧ w.2 = v.2 := by
  constructor
  · rintro ⟨t, ht, hr, hc⟩
    simp [row, col] at hr hc
    constructor
    · change v.1.val < w.1.val
      omega
    · exact Fin.ext (by omega)
  · rintro ⟨hr, hc⟩
    refine ⟨w.1.val - v.1.val, Nat.sub_pos_of_lt hr, ?_, ?_⟩
    · simp [row]
      have hh : v.1.val < w.1.val := hr
      omega
    · simp [col, hc]

theorem L_south {n : ℕ} (v : Pos n) : L v 4 = (n-1-v.1.val : ℕ) := by
  classical
  unfold L
  simp_rw [ray_south]
  rw [Fintype.sum_prod_type]
  have hs : (∑ x : Fin n, ∑ y : Fin n, if v.1 < x ∧ y = v.2 then (1 : ℤ) else 0) =
      ∑ x : Fin n, if v.1 < x then (1 : ℤ) else 0 := by
    apply Finset.sum_congr rfl
    intro x _
    by_cases h : v.1 < x <;> simp [h]
  rw [hs]
  have hh : (Finset.univ.filter (fun x : Fin n => v.1 < x)) = Finset.Ioi v.1 := by
    ext x
    simp
  rw [Finset.sum_boole, hh, Fin.card_Ioi]

theorem L_east {n : ℕ} (v : Pos n) : L v 2 = (n-1-v.2.val : ℕ) := by
  have h := L_transpose v 2
  change L v 2 = L (transposePos n v) 4 at h
  rw [L_south] at h
  exact h

theorem opposite_cardinal_sums {n : ℕ} (v : Pos n) :
    L v 0 + L v 4 = (n-1 : ℕ) ∧ L v 2 + L v 6 = (n-1 : ℕ) := by
  rw [L_north, L_south, L_east, L_west]
  have h₁ := v.1.isLt
  have h₂ := v.2.isLt
  constructor <;> omega

theorem normalized_positions {k : ℕ} {σ : Equiv.Perm (Pos (2*k+1))}
    {τ : Equiv.Perm Dir} (h : Universal σ τ)
    (hN : τ 0 = 0) (hS : τ 4 = 4) (hW : τ 6 = 6) :
    σ = Equiv.refl _ := by
  obtain ⟨c, hc⟩ := universal_offsets h
  apply Equiv.ext
  intro v
  have h₁ := hc v 0
  have h₂ := hc v 4
  have h₃ := hc v 6
  rw [hN] at h₁
  rw [hS] at h₂
  rw [hW] at h₃
  have p := (opposite_cardinal_sums v).1
  have q := (opposite_cardinal_sums (σ v)).1
  have hz : c v = 0 := by omega
  rw [L_north, L_north, hz] at h₁
  rw [L_west, L_west, hz] at h₃
  apply Prod.ext <;> apply Fin.ext <;> dsimp <;> omega

theorem universal_opposite_balance {k : ℕ} {σ : Equiv.Perm (Pos (2*k+1))}
    {τ : Equiv.Perm Dir} (h : Universal σ τ) (v : Pos (2*k+1)) :
    L v (τ 0) + L v (τ 4) = L v (τ 2) + L v (τ 6) := by
  obtain ⟨c, hc⟩ := universal_offsets h
  have p := opposite_cardinal_sums (σ v)
  have h₀ := hc v 0
  have h₄ := hc v 4
  have h₂ := hc v 2
  have h₆ := hc v 6
  omega
end BoardV1
