import TotalSeparation
namespace BoardV1
theorem rooted_cardinal_cases {k : ℕ} (hk : 1 ≤ k)
    {σ : Equiv.Perm (Pos (2*k+1))} {τ : Equiv.Perm Dir}
    (h : Universal σ τ) :
    (τ 0=0 ∧ τ 4=4 ∧ τ 6=6) ∨
    (τ 0=6 ∧ τ 4=2 ∧ τ 6=0) := by
  have h0 := (cardinal_preserved hk h 0).mp (by simp [IsCard])
  have h2 := (cardinal_preserved hk h 2).mp (by simp [IsCard])
  have h4 := (cardinal_preserved hk h 4).mp (by simp [IsCard])
  have h6 := (cardinal_preserved hk h 6).mp (by simp [IsCard])
  have i02 : τ 0 ≠ τ 2 := τ.injective.ne (by decide)
  have i04 : τ 0 ≠ τ 4 := τ.injective.ne (by decide)
  have i06 : τ 0 ≠ τ 6 := τ.injective.ne (by decide)
  have i24 : τ 2 ≠ τ 4 := τ.injective.ne (by decide)
  have i26 : τ 2 ≠ τ 6 := τ.injective.ne (by decide)
  have i46 : τ 4 ≠ τ 6 := τ.injective.ne (by decide)
  have s0 := universal_start h (fun _ => (0 : Dir))
  have s2 := universal_start h (fun _ => (2 : Dir))
  have s4 := universal_start h (fun _ => (4 : Dir))
  have bal := universal_opposite_balance h (corner01 k)
  rcases h0 with h0 | h0 | h0 | h0 <;>
    rcases h2 with h2 | h2 | h2 | h2 <;>
    rcases h4 with h4 | h4 | h4 | h4 <;>
    rcases h6 with h6 | h6 | h6 | h6 <;>
    simp_all [L_north, L_south, L_east, L_west, start, corner01] <;> omega
end BoardV1
