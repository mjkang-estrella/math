import Action
namespace BoardV1
theorem reflection_ne_identity (k : ℕ) :
    boardAction (transposePos (2*k+1)) transposeDir ≠
      Equiv.refl (Board (2*k+1)) := by
  intro h
  have q := congrArg (fun f : Equiv.Perm (Board (2*k+1)) =>
    f (fun _ => (0 : Dir)) (start k)) h
  change (6 : Dir) = 0 at q
  exact (by decide : (6 : Dir) ≠ 0) q

theorem all_odd_source_groups (n : ℕ) (hn : Odd n) (h3 : 3 ≤ n) :
    ∃ k : ℕ, 1 ≤ k ∧ n = 2*k+1 ∧
      SourceSym k = {Equiv.refl _, boardAction (transposePos _) transposeDir} := by
  obtain ⟨k,hk,rfl⟩ := (odd_size_bridge n).mp ⟨hn,h3⟩
  exact ⟨k,hk,rfl,source_group_endpoint hk⟩
end BoardV1
