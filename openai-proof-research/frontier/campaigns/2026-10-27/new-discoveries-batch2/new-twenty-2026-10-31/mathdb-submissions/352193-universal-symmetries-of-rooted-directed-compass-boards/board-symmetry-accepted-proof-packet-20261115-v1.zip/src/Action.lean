import Endpoint
namespace BoardV1
def boardAction {n : ℕ} (σ : Equiv.Perm (Pos n)) (τ : Equiv.Perm Dir) :
    Equiv.Perm (Board n) where
  toFun := Transform σ τ
  invFun := Transform σ.symm τ.symm
  left_inv A := by funext v; simp [Transform]
  right_inv A := by funext v; simp [Transform]

theorem action_faithful {k : ℕ}
    (σ ρ : Equiv.Perm (Pos (2*k+1))) (τ υ : Equiv.Perm Dir)
    (he : boardAction σ τ = boardAction ρ υ) : σ = ρ ∧ τ = υ := by
  have hd : ∀ (A : Board (2*k+1)) (v : Pos (2*k+1)), τ (A (σ v)) = υ (A (ρ v)) := by
    intro A v
    exact congrFun (congrArg (fun f : Equiv.Perm (Board (2*k+1)) => f A) he) v
  have ht : τ = υ := by
    apply Equiv.ext
    intro d
    exact hd (fun _ => d) (start k)
  subst υ
  refine ⟨?_,rfl⟩
  apply Equiv.ext
  intro v
  by_contra hn
  have hh := τ.injective (hd (single (σ v) 0 1) v)
  simp [single, Ne.symm hn] at hh

def SourceSym (k : ℕ) : Set (Equiv.Perm (Board (2*k+1))) :=
  { S | ∃ σ τ, S = boardAction σ τ ∧
      ∀ A, Nonempty (RootedIso A (S A)) }

theorem source_group_endpoint {k : ℕ} (hk : 1 ≤ k) :
    SourceSym k = { Equiv.refl _, boardAction (transposePos _) transposeDir } := by
  ext S
  constructor
  · rintro ⟨σ,τ,rfl,h⟩
    have hu : Universal σ τ := h
    rcases universal_pair hk hu with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
    · left; rfl
    · right; rfl
  · rintro (rfl | rfl)
    · exact ⟨Equiv.refl _, Equiv.refl _, rfl, identity_universal k⟩
    · exact ⟨transposePos _, transposeDir, rfl, reflection_universal k⟩
end BoardV1
