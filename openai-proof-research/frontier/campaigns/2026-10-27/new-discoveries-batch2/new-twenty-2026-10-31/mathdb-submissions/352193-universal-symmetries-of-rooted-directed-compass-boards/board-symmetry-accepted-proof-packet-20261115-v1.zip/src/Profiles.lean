import Board
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise
namespace BoardV1
open scoped BigOperators

def single {n : ℕ} (v : Pos n) (d e : Dir) : Board n :=
  fun x => if x = v then d else e

theorem total_single_sub {n : ℕ} (v : Pos n) (d e : Dir) :
    total (single v d e) - total (n := n) (fun _ => e) = L v d - L v e := by
  classical
  unfold total
  rw [← Finset.sum_sub_distrib]
  have hh := Finset.sum_eq_single (s := Finset.univ)
    (f := fun x => L x (single v d e x) - L x e) v
    (fun x _ hx => by simp [single, hx]) (by simp)
  simpa [single] using hh

theorem transform_single {n : ℕ} (σ : Equiv.Perm (Pos n))
    (τ : Equiv.Perm Dir) (v : Pos n) (d e : Dir) :
    Transform σ τ (single (σ v) d e) = single v (τ d) (τ e) := by
  classical
  funext x
  simp only [Transform, single, σ.injective.eq_iff]
  split_ifs <;> rfl

theorem universal_variation {k : ℕ} {σ : Equiv.Perm (Pos (2*k+1))}
    {τ : Equiv.Perm Dir} (h : Universal σ τ) (v : Pos (2*k+1)) (d e : Dir) :
    L v (τ d) - L v (τ e) = L (σ v) d - L (σ v) e := by
  have h₁ := universal_total h (single (σ v) d e)
  have h₂ := universal_total h (fun _ => e)
  rw [transform_single] at h₁
  change total (fun _ => e) = total (fun _ => τ e) at h₂
  have h₃ := total_single_sub v (τ d) (τ e)
  have h₄ := total_single_sub (σ v) d e
  omega

theorem universal_offsets {k : ℕ} {σ : Equiv.Perm (Pos (2*k+1))}
    {τ : Equiv.Perm Dir} (h : Universal σ τ) :
    ∃ c : Pos (2*k+1) → ℤ, ∀ v d, L v (τ d) = L (σ v) d + c v := by
  refine ⟨fun v => L v (τ 0) - L (σ v) 0, ?_⟩
  intro v d
  have hv := universal_variation h v d 0
  dsimp
  omega

theorem universal_constant {k : ℕ} {σ : Equiv.Perm (Pos (2*k+1))}
    {τ : Equiv.Perm Dir} (h : Universal σ τ) (d : Dir) :
    (∑ v : Pos (2*k+1), L v d) = ∑ v : Pos (2*k+1), L v (τ d) :=
  universal_total h (fun _ => d)

theorem L_nonneg {n : ℕ} (v : Pos n) (d : Dir) : 0 ≤ L v d := by
  classical
  unfold L
  exact Finset.sum_nonneg fun _ _ => by split_ifs <;> omega

theorem L_ge_one {n : ℕ} {v w : Pos n} {d : Dir} (h : Ray v w d) :
    1 ≤ L v d := by
  classical
  unfold L
  have hh := Finset.single_le_sum
    (s := (Finset.univ : Finset (Pos n)))
    (f := fun w => if Ray v w d then (1 : ℤ) else 0)
    (fun _ _ => by split_ifs <;> omega) (Finset.mem_univ w)
  simpa only [ite_eq_left h] using hh

theorem north_start_zero (k : ℕ) : L (start k) 0 = 0 := by
  classical
  unfold L
  apply Finset.sum_eq_zero
  intro w _
  have hh : ¬ Ray (start k) w 0 := by
    rintro ⟨t, ht, hr, _⟩
    simp [row, start] at hr
    omega
  simp only [ite_eq_right hh]

theorem east_start_positive {k : ℕ} (hk : 1 ≤ k) : 1 ≤ L (start k) 2 := by
  apply L_ge_one (w := (⟨0, by omega⟩, ⟨1, by omega⟩))
  refine ⟨1, by omega, ?_, ?_⟩ <;> simp [start, row, col]

theorem universal_fixes_start {k : ℕ} (hk : 1 ≤ k)
    {σ : Equiv.Perm (Pos (2*k+1))} {τ : Equiv.Perm Dir}
    (h : Universal σ τ) : σ (start k) = start k := by
  classical
  by_contra hs
  have hn := universal_start h (single (start k) 0 0)
  have he := universal_start h (single (start k) 2 0)
  simp [single, hs] at hn he
  have hz := north_start_zero k
  have hp := east_start_positive hk
  omega
end BoardV1
