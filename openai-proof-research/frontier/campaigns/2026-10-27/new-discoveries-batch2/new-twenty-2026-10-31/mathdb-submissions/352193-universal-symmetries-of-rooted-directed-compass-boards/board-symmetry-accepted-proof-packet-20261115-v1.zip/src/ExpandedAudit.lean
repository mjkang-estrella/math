import AllSizes
#print axioms BoardV1.Pos
#print axioms BoardV1.Dir
#print axioms BoardV1.Board
#print axioms BoardV1.row
#print axioms BoardV1.col
#print axioms BoardV1.Ray
#print axioms BoardV1.Edge
#print axioms BoardV1.Transform
#print axioms BoardV1.start
#print axioms BoardV1.center
#print axioms BoardV1.RootedIso
#print axioms BoardV1.Universal
#print axioms BoardV1.L
#print axioms BoardV1.total
#print axioms BoardV1.odd_size_bridge
#print axioms BoardV1.outdegree_iso
#print axioms BoardV1.total_iso
#print axioms BoardV1.universal_total
#print axioms BoardV1.universal_start
#print axioms BoardV1.single
#print axioms BoardV1.total_single_sub
#print axioms BoardV1.transform_single
#print axioms BoardV1.universal_variation
#print axioms BoardV1.universal_offsets
#print axioms BoardV1.universal_constant
#print axioms BoardV1.L_nonneg
#print axioms BoardV1.L_ge_one
#print axioms BoardV1.north_start_zero
#print axioms BoardV1.east_start_positive
#print axioms BoardV1.universal_fixes_start
#print axioms BoardV1.transposeD
#print axioms BoardV1.transposeD_involutive
#print axioms BoardV1.transposeDir
#print axioms BoardV1.transposePos
#print axioms BoardV1.row_transpose
#print axioms BoardV1.col_transpose
#print axioms BoardV1.transpose_ray
#print axioms BoardV1.Reflection
#print axioms BoardV1.reflectionIso
#print axioms BoardV1.reflection_universal
#print axioms BoardV1.identityIso
#print axioms BoardV1.identity_universal
#print axioms BoardV1.reflection_involutive
#print axioms BoardV1.ray_irreflexive
#print axioms BoardV1.L_card
#print axioms BoardV1.total_arc_card
#print axioms BoardV1.ray_north
#print axioms BoardV1.L_north
#print axioms BoardV1.L_transpose
#print axioms BoardV1.L_west
#print axioms BoardV1.ray_south
#print axioms BoardV1.L_south
#print axioms BoardV1.L_east
#print axioms BoardV1.opposite_cardinal_sums
#print axioms BoardV1.normalized_positions
#print axioms BoardV1.universal_opposite_balance
#print axioms BoardV1.corner00
#print axioms BoardV1.corner00_0
#print axioms BoardV1.corner00_1
#print axioms BoardV1.corner00_2
#print axioms BoardV1.corner00_3
#print axioms BoardV1.corner00_4
#print axioms BoardV1.corner00_5
#print axioms BoardV1.corner00_6
#print axioms BoardV1.corner00_7
#print axioms BoardV1.corner01
#print axioms BoardV1.corner01_0
#print axioms BoardV1.corner01_1
#print axioms BoardV1.corner01_2
#print axioms BoardV1.corner01_3
#print axioms BoardV1.corner01_4
#print axioms BoardV1.corner01_5
#print axioms BoardV1.corner01_6
#print axioms BoardV1.corner01_7
#print axioms BoardV1.corner10
#print axioms BoardV1.corner10_0
#print axioms BoardV1.corner10_1
#print axioms BoardV1.corner10_2
#print axioms BoardV1.corner10_3
#print axioms BoardV1.corner10_4
#print axioms BoardV1.corner10_5
#print axioms BoardV1.corner10_6
#print axioms BoardV1.corner10_7
#print axioms BoardV1.corner11
#print axioms BoardV1.corner11_0
#print axioms BoardV1.corner11_1
#print axioms BoardV1.corner11_2
#print axioms BoardV1.corner11_3
#print axioms BoardV1.corner11_4
#print axioms BoardV1.corner11_5
#print axioms BoardV1.corner11_6
#print axioms BoardV1.corner11_7
#print axioms BoardV1.profile_injective
#print axioms BoardV1.normalized_pair
#print axioms BoardV1.RootedIso.trans
#print axioms BoardV1.universal_reflection_normalize
#print axioms BoardV1.LiteralEndpoint
#print axioms BoardV1.ray_row_le
#print axioms BoardV1.revRows
#print axioms BoardV1.total_NS
#print axioms BoardV1.total_transpose
#print axioms BoardV1.IsCard
#print axioms BoardV1.total_cardinal
#print axioms BoardV1.diagonal_lt
#print axioms BoardV1.cardinal_preserved
#print axioms BoardV1.rooted_cardinal_cases
#print axioms BoardV1.universal_pair
#print axioms BoardV1.universal_iff_pair
#print axioms BoardV1.literal_endpoint
#print axioms BoardV1.all_odd_sizes
#print axioms BoardV1.source_map_set
#print axioms BoardV1.boardAction
#print axioms BoardV1.action_faithful
#print axioms BoardV1.SourceSym
#print axioms BoardV1.source_group_endpoint
#print axioms BoardV1.reflection_ne_identity
#print axioms BoardV1.all_odd_source_groups
set_option pp.all true in
#print BoardV1.Universal
set_option pp.all true in
#print BoardV1.RootedIso
set_option pp.all true in
#print BoardV1.LiteralEndpoint
set_option pp.all true in
#print BoardV1.SourceSym
set_option pp.all true in
#print BoardV1.all_odd_source_groups
set_option pp.all true in
#print BoardV1.source_group_endpoint
set_option pp.all true in
#print BoardV1.universal_pair
