import RootedCases
namespace BoardV1
theorem universal_pair {k : ℕ} (hk : 1 ≤ k)
    {σ : Equiv.Perm (Pos (2*k+1))} {τ : Equiv.Perm Dir}
    (h : Universal σ τ) :
    (σ = Equiv.refl _ ∧ τ = Equiv.refl _) ∨
    (σ = transposePos _ ∧ τ = transposeDir) := by
  rcases rooted_cardinal_cases hk h with ⟨h0,h4,h6⟩ | ⟨h0,h4,h6⟩
  · exact Or.inl (normalized_pair hk h h0 h4 h6)
  · have hn := universal_reflection_normalize h
    have p := normalized_pair hk hn
      (by change transposeDir (τ 0) = 0; rw [h0]; rfl)
      (by change transposeDir (τ 4) = 4; rw [h4]; rfl)
      (by change transposeDir (τ 6) = 6; rw [h6]; rfl)
    right
    constructor
    · apply Equiv.ext
      intro v
      have q := congrArg (fun f : Equiv.Perm (Pos (2*k+1)) => f (transposePos _ v)) p.1
      simpa [Equiv.trans_apply, transposePos] using q
    · apply Equiv.ext
      intro d
      have q := congrArg (fun f : Equiv.Perm Dir => f d) p.2
      have r := congrArg transposeD q
      change transposeD (transposeD (τ d)) = transposeD d at r
      rw [transposeD_involutive (τ d)] at r
      exact r

theorem universal_iff_pair {k : ℕ} (hk : 1 ≤ k)
    (σ : Equiv.Perm (Pos (2*k+1))) (τ : Equiv.Perm Dir) :
    Universal σ τ ↔
    (σ = Equiv.refl _ ∧ τ = Equiv.refl _) ∨
    (σ = transposePos _ ∧ τ = transposeDir) := by
  constructor
  · exact universal_pair hk
  · rintro (⟨rfl,rfl⟩ | ⟨rfl,rfl⟩)
    · exact identity_universal k
    · exact reflection_universal k

theorem literal_endpoint {k : ℕ} (hk : 1 ≤ k) : LiteralEndpoint k := by
  intro σ τ
  constructor
  · intro h
    rcases universal_pair hk h with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
    · left; rfl
    · right; rfl
  · rintro (h | h)
    · intro A
      have q := congrFun h A
      rw [q]
      exact ⟨identityIso A⟩
    · intro A
      have q := congrFun h A
      rw [q]
      exact ⟨reflectionIso A⟩

theorem all_odd_sizes (n : ℕ) (hn : Odd n) (h3 : 3 ≤ n) :
    ∃ k : ℕ, 1 ≤ k ∧ n = 2*k+1 ∧ LiteralEndpoint k := by
  obtain ⟨k,hk,rfl⟩ := (odd_size_bridge n).mp ⟨hn,h3⟩
  exact ⟨k,hk,rfl,literal_endpoint hk⟩

theorem source_map_set {k : ℕ} (hk : 1 ≤ k) :
    { S : Board (2*k+1) → Board (2*k+1) |
      ∃ σ τ, S = Transform σ τ ∧ Universal σ τ } =
    { (fun A => A), @Reflection (2*k+1) } := by
  ext S
  constructor
  · rintro ⟨σ,τ,rfl,h⟩
    exact (literal_endpoint hk σ τ).mp h
  · rintro (rfl | rfl)
    · exact ⟨Equiv.refl _, Equiv.refl _, rfl, identity_universal k⟩
    · exact ⟨transposePos _, transposeDir, rfl, reflection_universal k⟩
end BoardV1
