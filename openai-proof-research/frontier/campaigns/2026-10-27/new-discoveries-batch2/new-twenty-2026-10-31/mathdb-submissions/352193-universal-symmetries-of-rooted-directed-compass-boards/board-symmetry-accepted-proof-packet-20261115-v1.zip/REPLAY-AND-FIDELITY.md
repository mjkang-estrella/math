# REPLAY-AND-FIDELITY v1 — MathDB 352193
Independent review, 2026-11-15 UTC. Review only; credit0. Counts unchanged:68/80 NEW,107 total. No acceptance/count/ledger action.

## Separate verdicts
* Source binding: PASS for Ary Shaviv, Board games, random boards and long boards, arXiv:2110.05416v1,11 October2021, Definition2, Definition11,§5.1,Conjecture15. The exact owned retrieved normalized352193 record omits definitions/domain but asserts no conflicting stronger quantifier. Its provenance is target-only normalized retrieval, not a new live MathDB observation. Preserve v1 scope explicitly.
* Model: PASS. Fin n × Fin n contains all n² positions. Ray uses an existential positive natural step with signed integer coordinate equations. Edge has no center exception. RootedIso fixes beginning and center individually and preserves directed arcs in both directions. Universal is ∀A Nonempty(RootedIso A (Transform σ τ A)); its vertex equivalence is independent of σ and may vary with A. σ is an arbitrary position permutation; τ is an arbitrary single global Fin8 permutation.
* Literal endpoint: PASS. universal_iff_pair proves global pair alternatives; literal_endpoint proves global function equality alternatives; source_group_endpoint proves equality of sets of actual board permutations. all_odd_source_groups covers every odd n≥3 via n=2k+1,k≥1. The disjunction is outside ∀A. There is no surviving cardinal/geometric/normalization assumption.
* Paper ordinary correctness: PASS in that model, independently checked by reading its full mathematical proof and all13 production modules. The new row-injection bridge is valid uniformly, independently of the earlier polynomial separation. No unresolved scientific lemma found. The stale comment in Normalized claiming the bridge is missing is obsolete explanatory text: Endpoint actually supplies literal_endpoint and Action supplies the source-group equality. It should be editorially corrected in a future version, not silently edited here.
* Compile: PASS, all16 exact paper modules plus independent audit, fresh outputs and no parent project cache.
* Separate kernel replay: PASS for all17 freshly compiled artifacts. Complete order and receipts below.
* Axioms: PASS for actual endpoints and independent expanded theorem; only propext, Classical.choice, Quot.sound transitively. 304 emitted dependency-audit lines inspected programmatically; endpoint axiom output personally read. No mathematical assumption/oracle was inserted.
* Historical ordinary/source/prior/contribution/distinctness qualification: retained only within actual inherited coverage. Not a fresh worldwide novelty investigation; no journal-final fidelity claim. Publisher body remains unread, without bypass or invented compulsory closed-body gate.
* Process: NOT certified clean. All historic and current defects remain UNWAIVED, separately from scientific validity.

## Extraction and build provenance
extract-v2.py extracts bytes from actual PAPER-v1.md headings immediately followed by Lean fences, preserving every source newline. Paths are restricted to distinct simple module filenames. All16 sources match STRICT-REPLAY-OWNERSHIP expected hashes and are then byte-compared against APPENDIX-v1.json source strings. The sidecar was never an extraction source. extraction-map-v2.json records complete hashes, sizes and literal paper byte spans. No paper or mathematical source was changed. extract-v1.py incorrectly demanded a blank heading separator, failed with zero matches, and remains retained with full stdout/stderr receipt; v2 fixes only that extraction parser.

build and cache were empty before replay. formal_command.py constructs LEAN_PATH as this lane/build plus exactly the eight PINS upstream library paths; replay-build-map-v1.json verifies this on every call. Each compile receipt has null prior olean hash. No project source/olean was read from parent origins. Lean4.34.1 and pinned mathlib revision d13f23b723b8a846827a245b89c10fc7d3f11612 were used with hashed binaries. Diagnostics follow their actual imports: Audit→Normalized,FinalAudit→Action,ExpandedAudit→AllSizes.

| Module | Compile receipt | Separate kernel receipt | Verdict |
|---|---|---|---|
| Board | fresh01_compile.receipt.json | fresh02_check.receipt.json | PASS / PASS |
| Profiles | fresh03_compile.receipt.json | fresh04_check.receipt.json | PASS / PASS |
| Reflection | fresh05_compile.receipt.json | fresh06_check.receipt.json | PASS / PASS |
| Cardinals | fresh07_compile.receipt.json | fresh08_check.receipt.json | PASS / PASS |
| Rigidity | fresh09_compile.receipt.json | fresh10_check.receipt.json | PASS / PASS |
| Corners | fresh11_compile.receipt.json | fresh12_check.receipt.json | PASS / PASS |
| Normalized | fresh13_compile.receipt.json | fresh14_check.receipt.json | PASS / PASS |
| Separation | fresh15_compile.receipt.json | fresh16_check.receipt.json | PASS / PASS |
| TotalSeparation | fresh17_compile.receipt.json | fresh18_check.receipt.json | PASS / PASS |
| RootedCases | fresh19_compile.receipt.json | fresh20_check.receipt.json | PASS / PASS |
| Endpoint | fresh21_compile.receipt.json | fresh22_check.receipt.json | PASS / PASS |
| Action | fresh23_compile.receipt.json | fresh24_check.receipt.json | PASS / PASS |
| AllSizes | fresh25_compile.receipt.json | fresh26_check.receipt.json | PASS / PASS |
| Audit | fresh27_compile.receipt.json | fresh28_check.receipt.json | PASS / PASS |
| FinalAudit | fresh29_compile.receipt.json | fresh30_check.receipt.json | PASS / PASS |
| ExpandedAudit | fresh31_compile.receipt.json | fresh32_check.receipt.json | PASS / PASS |
| IndependentLiteral | fresh33_compile.receipt.json | fresh34_check.receipt.json | PASS / PASS |

Every listed receipt has a sibling .output.txt containing full stdout; stderr and full invocation are preserved inside the receipt. replay-build-map-v1.json records source and olean hashes before/after, exact arguments and Lean paths for all34 stages.

## Independent mathematical reconstruction / hostile SELF
For an arbitrary board A, the total E(A)=Σv L_v(A(v)) is the complete directed arc count. Every rooted graph isomorphism preserves E and beginning-root outdegree; neither argument substitutes σ for the graph isomorphism.

For a diagonal d with row component ±1, project each ray target w to (w.row,v.col), along the corresponding N/S ray. Membership follows from the same positive step. Equal projected targets imply equal row differences; cancellation by the nonzero row component gives equal steps, hence equal original columns. Thus L_v(d)≤L_v(N/S). For NE,NW,SE,SW respectively use corners11,10,01,00: the diagonal ray is empty but the comparison cardinal has ≥1 target for every k≥1. Summing gives strict inequality. Reversing rows equates N/S totals and transposing equates N/W and E/S, so every cardinal total is equal and strictly above each diagonal total. Constant boards force T(d)=T(τd), proving cardinal preservation in both directions. This is a new sufficient proof bridge, not an invocation of the earlier sum-of-squares formula.

Independently changing only input σ(v) changes only output v. Subtracting invariant arc totals in ℤ gives L_v(τd)−L_v(τe)=L_σ(v)(d)−L_σ(v)(e). Hence L_v(τd)=L_σ(v)(d)+b_v. The opposite cardinal sums both equal m, so their images balance pointwise. At start, constant N,E,S boards constrain cardinal images to preserve outward {N,W} and inward {E,S}. Injectivity plus balance at corner01 eliminate the two incompatible pairings, leaving precisely (τN,τS,τW)=(N,S,W) or (W,E,N). RootedCases performs this finite Fin8 calculation with symbolic arbitrary k, not finite board enumeration.

Reflection transposes coordinates and swaps N/W,E/S,NE/SW while fixing SE,NW, exactly the physical NW–SE diagonal involution printed on source page21. Its ray isomorphism fixes both roots. Composing reflection AFTER S gives σ′=σ∘transpose and τ′=r∘τ; Equiv.trans argument order in universal_reflection_normalize implements precisely that pullback order. In the normalized case, opposite N/S equations force 2b_v=0, hence b_v=0 in ℤ. North and west ray lengths recover both coordinates, so σ′=Id. Corner zero/positive patterns distinguish all eight direction profiles, forcing τ′=Id. Undo the involution to recover the original global pair. No assumption that τ was geometric entered before it was proved sufficient to normalize.

boardAction has the explicit inverse Transform σ⁻¹ τ⁻¹. Constant boards recover τ from any equal actions; a single board separating two input positions then recovers σ. Thus faithfulness is proved, not guessed. Reflection differs from identity already on the constant north board. SourceSym is the required set of permutations represented by arbitrary σ,τ and satisfying ∀A∃f. Identity and reflection give explicit rooted isomorphisms. The center root is retained even though necessity can use the beginning root alone. k=1 satisfies every corner positivity and strictness premise; the fresh independent audit includes the n=3 instance. No finite evidence is substituted for an all-size proof.

The personally read independent ordinary proof uses T_C=n²(n−1)/2,T_D=n(n−1)(2n−1)/6 and derives unrooted D4 before the root restriction. These are compatible with the injection/earlier-root ordering here. Its retained correctness does not substitute for checking the new bridge.

## Fresh expanded independent endpoint
src/IndependentLiteral.lean defines Arc by explicit positive-step integer equations and Expanded k S by ∃ arbitrary σ,τ, pointwise pullback action equality AND ∀A∃ an independent vertex permutation f fixing the two roots and preserving Arc in both directions. expanded_iff converts these explicit witnesses to/from actual RootedIso. literal_global_set proves {S | Expanded k S}={Id,R}; all_odd quantifies every odd n≥3 and the module additionally checks n=3. Fresh33 compile and fresh34 separate checker both PASS. Its actual printed term is Set.ext followed by equality transitivity with source_group_endpoint, and its transitive axioms are exactly the permitted three. This independently audits the semantic expansion; it is not a second independent implementation of the classification proof.

## Source and reading inventory
Source PDF pages3,14,21 were rendered and visually inspected in this lane; page1 text prefix authenticates author/title/v1/date. Page3 Definition2 imposes odd n≥3 and the eight positive-ray rules. Page14 Definition11 includes all vertices and arcs, with no removal of center outgoing arcs. Page21 defines doubly rooted directed isomorphism, the physical direction reflection, arbitrary σ and τ, and ∀A preservation before Conjecture15. Translating one-based (i,j) to zero-based (i−1,j−1) preserves ray differences and sends roots to start/center. This elementary coordinate identification was personally checked; no separate one-based Lean graph was constructed. The exact raw target was fully read and its raw-line hash is retained in TARGET-RECORD-PROVENANCE.json.

All16 literal module sources were personally read in bounded slices, as was the full paper mathematical narrative. The independent ordinary-proof section was fully read; root scoped qualification and implementation work narrative were read. Producer/contribution historical reports were only indexed, and their independent source/prior conclusions remain inherited within root-qualified coverage. Full pp.all production output is saved; only bounded type/term prefixes were personally inspected, in addition to complete source proof bodies and the full small independent final term. Kernel checking verifies full terms. review-read-inventory-v1.json gives exact owned input SHA256/byte identities and read/unread coverage. Unread: most other PDF pages, closed2023 publisher body, origin project files, protected/registry bodies and accepted107 proofs. No missing-hit/worldwide novelty assertion.

## Resources and process inventory
34/48 formal invocations,17 compiles+17 separate kernel checks,0 formal failures,0 guard kills. CPU sum 39.407479s; wall sum 40.039481s; maximum sampled process-group RSS 1864654848 bytes. Sampling is not a continuous peak-memory guarantee. All use taskset4,5,115CPU/130wall,32GiBAS,6GiB sampled groupRSS,j1,M3500,warnings-as-errors. Zero acquisitions,searches,scientific experiments. The failed extractor is documentary and counted separately, with its failed version retained. resource-accounting-v1.json contains every formal receipt's observed usage and immutable limits.

The first two shell commands were exact bootstrap then standalone frozen-before; the46-pin before check passed. All documentary writes and source/binary materialization used own write_lane.py. Frozen helpers were not edited. No children/git/installs/dependency updates/accounts/messages/uploads/publication/ledger actions or origin traversal occurred.

UNWAIVED current sequencing limitation: initial screening used target ID,arXiv ID,and target title. Author/full source title were identified by an initial paper-narrative read and only then added to recursive key/scalar screening before PDF bodies. Therefore exhaustive prospective all-alias screening for that identification read is not certified. Some applicable work narratives were personally read after early technical bodies rather than before them; this is not retrospectively cured. Many displays used a2300-character inner ceiling rather than ≤2000 with serialization allowance; serialized envelope compliance with2400 is not certified. These are current process shortcomings, not silent waivers. Full stdout/receipts remain saved; no clean-history/process PASS is claimed. The implementation narrative's prior oversized first formal output and all inherited failures remain UNWAIVED as well.

## HANDOFF
Scientific/model/source-v1/literal endpoint/fresh compile/kernel/axiom verdicts above are independent review findings. No unresolved mathematical lemma found in the reviewed model. Qualification beyond the owned v1 scope remains exactly as inherited, not expanded. ROOT retains all acceptance authority and all process objections. Counts stay68/80 NEW,107 total; credit0.

All documentary writes precede standalone frozen-after. The final exhaustive physical seal records file SHA256/size and physical directory set, rejects symlinks, and excludes exactly PHYSICAL-SEAL-v1.json,seal-final.receipt.json,seal-final.output.txt. No command or write may follow that final seal. The actual frozen-after/seal outputs are external receipts, not a prospective assertion here.
