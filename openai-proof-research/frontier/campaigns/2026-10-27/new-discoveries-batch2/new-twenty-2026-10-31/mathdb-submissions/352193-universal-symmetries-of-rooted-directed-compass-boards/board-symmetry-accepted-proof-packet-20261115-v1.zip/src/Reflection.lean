import Profiles
import Mathlib.Tactic.FinCases
namespace BoardV1

def transposeD (d : Dir) : Dir :=
  match d.val with
  | 0 => 6 | 1 => 5 | 2 => 4 | 3 => 3
  | 4 => 2 | 5 => 1 | 6 => 0 | _ => 7

theorem transposeD_involutive : Function.Involutive transposeD := by
  intro d
  fin_cases d <;> rfl

def transposeDir : Equiv.Perm Dir :=
  ⟨transposeD, transposeD, transposeD_involutive, transposeD_involutive⟩

def transposePos (n : ℕ) : Equiv.Perm (Pos n) := Equiv.prodComm _ _

theorem row_transpose (d : Dir) : row (transposeDir d) = col d := by
  fin_cases d <;> rfl

theorem col_transpose (d : Dir) : col (transposeDir d) = row d := by
  fin_cases d <;> rfl

theorem transpose_ray {n : ℕ} (v w : Pos n) (d : Dir) :
    Ray v w d ↔ Ray (transposePos n v) (transposePos n w) (transposeDir d) := by
  simp only [Ray, transposePos, Equiv.prodComm_apply, row_transpose, col_transpose]
  constructor <;> rintro ⟨t, ht, hr, hc⟩ <;> exact ⟨t, ht, hc, hr⟩

def Reflection {n : ℕ} (A : Board n) : Board n :=
  Transform (transposePos n) transposeDir A

def reflectionIso {k : ℕ} (A : Board (2*k+1)) : RootedIso A (Reflection A) where
  vertex := transposePos _
  beginning := rfl
  ending := rfl
  edge_iff := by
    intro v w
    change Ray v w (A v) ↔
      Ray (transposePos _ v) (transposePos _ w) (transposeDir (A v))
    exact transpose_ray v w (A v)

theorem reflection_universal (k : ℕ) :
    Universal (transposePos (2*k+1)) transposeDir := fun A => ⟨reflectionIso A⟩

def identityIso {k : ℕ} (A : Board (2*k+1)) : RootedIso A A where
  vertex := Equiv.refl _
  beginning := rfl
  ending := rfl
  edge_iff := fun _ _ => Iff.rfl

theorem identity_universal (k : ℕ) :
    Universal (Equiv.refl (Pos (2*k+1))) (Equiv.refl Dir) := fun A => ⟨identityIso A⟩

theorem reflection_involutive {n : ℕ} : Function.Involutive (@Reflection n) := by
  intro A
  funext v
  exact transposeD_involutive (A v)

theorem ray_irreflexive {n : ℕ} (v : Pos n) (d : Dir) : ¬ Ray v v d := by
  rintro ⟨t, ht, hr, hc⟩
  fin_cases d <;> simp [row, col] at hr hc <;> omega
end BoardV1
