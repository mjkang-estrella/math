import AllSizes
namespace IndependentReplay
open BoardV1
def Arc {n : ℕ} (A : (Fin n × Fin n) → Fin 8) (v w : Fin n × Fin n) : Prop :=
  ∃ t : ℕ, 0 < t ∧
    (w.1.val : ℤ) = v.1.val + (t : ℤ) * row (A v) ∧
    (w.2.val : ℤ) = v.2.val + (t : ℤ) * col (A v)
def Expanded (k : ℕ) (S : Equiv.Perm (Board (2*k+1))) : Prop :=
  ∃ (σ : Equiv.Perm (Fin (2*k+1) × Fin (2*k+1))) (τ : Equiv.Perm (Fin 8)),
    (∀ A v, S A v = τ (A (σ v))) ∧
    ∀ A, ∃ f : Equiv.Perm (Fin (2*k+1) × Fin (2*k+1)),
      f (start k) = start k ∧ f (center k) = center k ∧
      ∀ v w, Arc A v w ↔ Arc (S A) (f v) (f w)
theorem expanded_iff (k : ℕ) (S : Equiv.Perm (Board (2*k+1))) :
    Expanded k S ↔ S ∈ SourceSym k := by
  constructor
  · rintro ⟨σ,τ,hS,h⟩
    have he : S = boardAction σ τ := by
      apply Equiv.ext
      intro A
      funext v
      exact hS A v
    refine ⟨σ,τ,he,?_⟩
    intro A
    obtain ⟨f,hs,hc,hf⟩ := h A
    exact ⟨⟨f,hs,hc,hf⟩⟩
  · rintro ⟨σ,τ,hS,h⟩
    refine ⟨σ,τ,?_,?_⟩
    · intro A v
      rw [hS]
      rfl
    · intro A
      obtain ⟨f⟩ := h A
      exact ⟨f.vertex,f.beginning,f.ending,f.edge_iff⟩
theorem literal_global_set (k : ℕ) (hk : 1 ≤ k) :
    {S : Equiv.Perm (Board (2*k+1)) | Expanded k S} =
    {Equiv.refl _, boardAction (transposePos _) transposeDir} := by
  have he : {S : Equiv.Perm (Board (2*k+1)) | Expanded k S} = SourceSym k := by
    ext S
    exact expanded_iff k S
  exact he.trans (source_group_endpoint hk)
theorem all_odd (n : ℕ) (hn : Odd n) (h3 : 3 ≤ n) :
    ∃ k, 1 ≤ k ∧ n = 2*k+1 ∧
      {S : Equiv.Perm (Board (2*k+1)) | Expanded k S} =
      {Equiv.refl _, boardAction (transposePos _) transposeDir} := by
  obtain ⟨k,hk,he⟩ := (odd_size_bridge n).mp ⟨hn,h3⟩
  exact ⟨k,hk,he,literal_global_set k hk⟩
example : {S : Equiv.Perm (Board 3) | Expanded 1 S} =
    {Equiv.refl _, boardAction (transposePos _) transposeDir} := literal_global_set 1 (by omega)
#print axioms all_odd
#print axioms literal_global_set
#print Expanded
#print literal_global_set
end IndependentReplay
