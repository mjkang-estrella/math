import Reflection
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Order.Interval.Finset.Fin
namespace BoardV1
open scoped BigOperators
noncomputable section
local instance rayDec {n : ℕ} (v : Pos n) (d : Dir) : DecidablePred (fun w => Ray v w d) := Classical.decPred _
local instance edgeDec {n : ℕ} (A : Board n) : DecidablePred (fun p : Pos n × Pos n => Edge A p.1 p.2) := Classical.decPred _

theorem L_card {n : ℕ} (v : Pos n) (d : Dir) :
    L v d = ((Finset.univ.filter (fun w => Ray v w d)).card : ℤ) := by
  classical
  simp [L, ← Finset.sum_boole]

theorem total_arc_card {n : ℕ} (A : Board n) :
    total A = ((Finset.univ.filter (fun p : Pos n × Pos n => Edge A p.1 p.2)).card : ℤ) := by
  classical
  unfold total L
  rw [← Fintype.sum_prod_type' ]
  simp only [Edge, Finset.sum_boole]
  congr 1

theorem ray_north {n : ℕ} (v w : Pos n) :
    Ray v w 0 ↔ w.1 < v.1 ∧ w.2 = v.2 := by
  constructor
  · rintro ⟨t, ht, hr, hc⟩
    simp [row, col] at hr hc
    constructor
    · change w.1.val < v.1.val
      omega
    · exact Fin.ext (by omega)
  · rintro ⟨hr, hc⟩
    refine ⟨v.1.val - w.1.val, by exact Nat.sub_pos_of_lt hr, ?_, ?_⟩
    · simp [row]
      have hh : w.1.val < v.1.val := hr
      omega
    · simp [col, hc]

theorem L_north {n : ℕ} (v : Pos n) : L v 0 = v.1.val := by
  classical
  unfold L
  simp_rw [ray_north]
  rw [Fintype.sum_prod_type]
  have hs : (∑ x : Fin n, ∑ y : Fin n, if x < v.1 ∧ y = v.2 then (1 : ℤ) else 0) =
      ∑ x : Fin n, if x < v.1 then (1 : ℤ) else 0 := by
    apply Finset.sum_congr rfl
    intro x _
    by_cases h : x < v.1 <;> simp [h]
  rw [hs]
  have hh : (Finset.univ.filter (fun x : Fin n => x < v.1)) = Finset.Iio v.1 := by
    ext x
    simp
  rw [Finset.sum_boole, hh, Fin.card_Iio]
end
end BoardV1
