import KleinDefs
import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Tactic.FinCases

/-!
# The twelve-vertex graph and the non-extendable 3-matching

Vertices `Fin 12`, label `v = 4y + x` (`x = v % 4`, `y = v / 4`).  Adjacency: distinct vertices
lying in a common square of the producer's list of twelve faces (each square is a clique).
-/

open Set Function

namespace Klein366521

/-- The twelve square faces of the reflected `4 × 3` grid, in cyclic order. -/
def faces : List (List (Fin 12)) :=
  [[0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7],
   [4, 5, 9, 8], [5, 6, 10, 9], [6, 7, 11, 10], [7, 4, 8, 11],
   [8, 9, 3, 0], [9, 10, 2, 3], [10, 11, 1, 2], [11, 8, 0, 1]]

/-- Boolean adjacency: distinct and in a common face. -/
def adjB (u v : Fin 12) : Bool :=
  u != v && faces.any (fun f => f.contains u && f.contains v)

theorem adjB_symm : ∀ u v : Fin 12, adjB u v = true → adjB v u = true := by decide +kernel

theorem adjB_irrefl : ∀ u : Fin 12, ¬ adjB u u = true := by decide

/-- The graph `G`: union of the twelve square cliques. -/
def kleinGraph : SimpleGraph (Fin 12) where
  Adj u v := adjB u v = true
  symm := ⟨fun u v h => adjB_symm u v h⟩
  loopless := ⟨fun u h => adjB_irrefl u h⟩

instance : DecidableRel kleinGraph.Adj := fun u v =>
  inferInstanceAs (Decidable (adjB u v = true))

theorem kleinGraph_adj {u v : Fin 12} : kleinGraph.Adj u v ↔ adjB u v = true := Iff.rfl

theorem degree_eight_aux :
    ∀ v : Fin 12, (Finset.univ.filter (fun w => kleinGraph.Adj v w)).card = 8 := by
  decide +kernel

theorem kleinGraph_regular : kleinGraph.IsRegularOfDegree 8 := by
  intro v
  rw [← SimpleGraph.card_neighborFinset_eq_degree, SimpleGraph.neighborFinset_eq_filter]
  exact degree_eight_aux v

theorem kleinGraph_card_edges : kleinGraph.edgeFinset.card = 48 := by
  have h := kleinGraph.sum_degrees_eq_twice_card_edges
  have h8 : ∀ v : Fin 12, kleinGraph.degree v = 8 := kleinGraph_regular
  simp only [h8, Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul] at h
  omega

theorem reach_aux : ∀ v : Fin 12, v = 0 ∨ adjB 0 v = true ∨
    (adjB 0 1 = true ∧ adjB 1 v = true) ∨ (adjB 0 5 = true ∧ adjB 5 v = true) ∨
    (adjB 0 9 = true ∧ adjB 9 v = true) := by
  decide +kernel

theorem kleinGraph_connected : kleinGraph.Connected := by
  have h0 : ∀ v : Fin 12, kleinGraph.Reachable 0 v := by
    intro v
    rcases reach_aux v with h | h | ⟨h1, h2⟩ | ⟨h1, h2⟩ | ⟨h1, h2⟩
    · subst h; exact SimpleGraph.Reachable.refl _
    · exact SimpleGraph.Adj.reachable h
    · exact (SimpleGraph.Adj.reachable (G := kleinGraph) h1).trans (SimpleGraph.Adj.reachable h2)
    · exact (SimpleGraph.Adj.reachable (G := kleinGraph) h1).trans (SimpleGraph.Adj.reachable h2)
    · exact (SimpleGraph.Adj.reachable (G := kleinGraph) h1).trans (SimpleGraph.Adj.reachable h2)
  exact ⟨fun u v => (h0 u).symm.trans (h0 v)⟩

/-- Partner in the matching `M = {15, 39, 7 11}`; identity off the odd vertices. -/
def mate (v : Fin 12) : Fin 12 :=
  if v = 1 then 5 else if v = 5 then 1 else if v = 3 then 9 else if v = 9 then 3
  else if v = 7 then 11 else if v = 11 then 7 else v

/-- Boolean adjacency of the matching. -/
def mAdjB (u v : Fin 12) : Bool := u.val % 2 == 1 && v == mate u

theorem mAdjB_symm : ∀ u v : Fin 12, mAdjB u v = true → mAdjB v u = true := by decide

theorem mAdjB_sub : ∀ u v : Fin 12, mAdjB u v = true → adjB u v = true := by decide

theorem mAdjB_vert : ∀ u v : Fin 12, mAdjB u v = true → u.val % 2 = 1 := by decide

/-- The matching `M` as an actual subgraph of `G`. -/
def matchM : kleinGraph.Subgraph where
  verts := {v | v.val % 2 = 1}
  Adj u v := mAdjB u v = true
  adj_sub := fun {u v} h => mAdjB_sub u v h
  edge_vert := fun {u v} h => mAdjB_vert u v h
  symm := ⟨fun u v h => mAdjB_symm u v h⟩

theorem mAdjB_iff : ∀ u v : Fin 12, mAdjB u v = true ↔
    ((u = 1 ∧ v = 5) ∨ (u = 5 ∧ v = 1)) ∨ ((u = 3 ∧ v = 9) ∨ (u = 9 ∧ v = 3)) ∨
      ((u = 7 ∧ v = 11) ∨ (u = 11 ∧ v = 7)) := by
  decide +kernel

theorem matchM_isMatching : matchM.IsMatching := by
  intro v hv
  refine ⟨mate v, ?_, ?_⟩
  · show mAdjB v (mate v) = true
    have hv' : v.val % 2 = 1 := hv
    simp [mAdjB, hv']
  · intro w hw
    have hw' : mAdjB v w = true := hw
    simp only [mAdjB, Bool.and_eq_true, beq_iff_eq] at hw'
    exact hw'.2

theorem matchM_edgeSet : matchM.edgeSet = {s(1, 5), s(3, 9), s(7, 11)} := by
  ext z
  induction z using Sym2.ind with
  | h u v =>
    rw [SimpleGraph.Subgraph.mem_edgeSet]
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff, Sym2.eq_iff]
    exact mAdjB_iff u v

theorem matchM_card : matchM.edgeSet.ncard = 3 := by
  rw [matchM_edgeSet, Set.ncard_eq_three]
  refine ⟨s(1, 5), s(3, 9), s(7, 11), ?_, ?_, ?_, rfl⟩ <;>
    (rw [ne_eq, Sym2.eq_iff]; decide)

/-- The even vertices adjacent to an element of `{0,4,8}` lie in `{0,4,8}`. -/
theorem even_nbr_aux : ∀ v w : Fin 12, (v = 0 ∨ v = 4 ∨ v = 8) → adjB v w = true →
    w.val % 2 = 0 → (w = 0 ∨ w = 4 ∨ w = 8) := by
  decide +kernel

theorem mate_odd : ∀ v : Fin 12, v.val % 2 = 1 → (mate v).val % 2 = 1 := by decide

/-- No perfect matching of `G` contains `M`. -/
theorem matchM_not_extendable :
    ¬ ∃ P : kleinGraph.Subgraph, P.IsPerfectMatching ∧ matchM.edgeSet ⊆ P.edgeSet := by
  rintro ⟨P, hP, hMP⟩
  rw [SimpleGraph.Subgraph.isPerfectMatching_iff] at hP
  have hM : ∀ v : Fin 12, v.val % 2 = 1 → P.Adj v (mate v) := by
    intro v hv
    have h1 : s(v, mate v) ∈ matchM.edgeSet := by
      rw [SimpleGraph.Subgraph.mem_edgeSet]
      show mAdjB v (mate v) = true
      simp [mAdjB, hv]
    exact (SimpleGraph.Subgraph.mem_edgeSet).mp (hMP h1)
  have uniq : ∀ v w w' : Fin 12, P.Adj v w → P.Adj v w' → w = w' :=
    fun v w w' h h' => (hP v).unique h h'
  -- the partner of a vertex of `{0,4,8}` is in `{0,4,8}`
  have inA : ∀ v w : Fin 12, (v = 0 ∨ v = 4 ∨ v = 8) → P.Adj v w → (w = 0 ∨ w = 4 ∨ w = 8) := by
    intro v w hv hvw
    have hG : adjB v w = true := P.adj_sub hvw
    rcases Nat.mod_two_eq_zero_or_one w.val with hw | hw
    · exact even_nbr_aux v w hv hG hw
    · exfalso
      have h1 : P.Adj w (mate w) := hM w hw
      have h2 : v = mate w := uniq w v (mate w) (P.adj_symm hvw) h1
      have h3 : (mate w).val % 2 = 1 := mate_odd w hw
      rw [← h2] at h3
      rcases hv with rfl | rfl | rfl <;> simp at h3
  have noself : ∀ v : Fin 12, ¬ P.Adj v v := fun v h => adjB_irrefl v (P.adj_sub h)
  obtain ⟨a, ha, -⟩ := hP 0
  obtain ⟨b, hb, -⟩ := hP 4
  obtain ⟨c, hc, -⟩ := hP 8
  rcases inA 0 a (Or.inl rfl) ha with rfl | rfl | rfl
  · exact noself 0 ha
  · obtain rfl : b = 0 := uniq 4 b 0 hb (P.adj_symm ha)
    rcases inA 8 c (Or.inr (Or.inr rfl)) hc with rfl | rfl | rfl
    · exact absurd (uniq 0 4 8 ha (P.adj_symm hc)) (by decide)
    · exact absurd (uniq 4 0 8 hb (P.adj_symm hc)) (by decide)
    · exact noself 8 hc
  · obtain rfl : c = 0 := uniq 8 c 0 hc (P.adj_symm ha)
    rcases inA 4 b (Or.inr (Or.inl rfl)) hb with rfl | rfl | rfl
    · exact absurd (uniq 0 8 4 ha (P.adj_symm hb)) (by decide)
    · exact noself 4 hb
    · exact absurd (uniq 8 0 4 hc (P.adj_symm hb)) (by decide)

/-- `G` is not 3-extendable, although it has `12 ≥ 8` vertices. -/
theorem kleinGraph_not_three_extendable :
    8 ≤ Fintype.card (Fin 12) ∧ ¬ IsMExtendable kleinGraph 3 := by
  refine ⟨by simp, ?_⟩
  rintro ⟨-, h⟩
  exact matchM_not_extendable (h matchM matchM_isMatching matchM_card)

end Klein366521
