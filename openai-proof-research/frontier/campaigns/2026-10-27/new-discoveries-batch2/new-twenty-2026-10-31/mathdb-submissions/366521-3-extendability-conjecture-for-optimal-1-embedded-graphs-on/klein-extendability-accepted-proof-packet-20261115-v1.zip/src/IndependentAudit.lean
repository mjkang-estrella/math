import KleinFinal

open Set Function Topology
namespace IndependentReplay
open Klein366521

abbrev Square := (Icc (0 : ℝ) 1 ×ˢ Icc (0 : ℝ) 1 : Set (ℝ × ℝ))
instance : CompactSpace Square :=
  isCompact_iff_compactSpace.mp (isCompact_Icc.prod isCompact_Icc)
noncomputable def faceMap (p : Square) : KleinBottle := cellF p.1

theorem faceMap_continuous : Continuous faceMap :=
  continuous_cellF.comp continuous_subtype_val

theorem faceMap_surjective : Surjective faceMap := by
  intro z
  induction z using Quotient.inductionOn with
  | h r =>
    obtain ⟨⟨hx0, hx4⟩, ⟨hy0, hy3⟩⟩ := mem_rect_iff.mp r.2
    refine ⟨⟨(r.1.1 / 4, r.1.2 / 3), ?_⟩, ?_⟩
    · exact ⟨⟨by positivity, by linarith⟩, ⟨by positivity, by linarith⟩⟩
    · change toK (4 * (r.1.1 / 4), 3 * (r.1.2 / 3)) = _
      have he : (4 * (r.1.1 / 4), 3 * (r.1.2 / 3)) = r.1 := by
        apply Prod.ext <;> dsimp <;> ring
      rw [he]
      exact toK_val r

-- Actual closure topology, not an extra field assumed of the cell record.
theorem faceMap_quotient : IsQuotientMap faceMap :=
  faceMap_continuous.isClosedMap.isQuotientMap faceMap_continuous faceMap_surjective

theorem weak_topology (s : Set KleinBottle) :
    IsClosed s ↔ IsClosed (faceMap ⁻¹' s) :=
  (isQuotientMap_iff_isClosed.mp faceMap_quotient).2 s

theorem closed_face : IsClosed (cellF '' (Icc (0 : ℝ) 1 ×ˢ Icc (0 : ℝ) 1)) :=
  ((isCompact_Icc.prod isCompact_Icc).image continuous_cellF).isClosed

theorem closed_edges (k : Fin 2) : IsClosed (c1fun k '' Icc (0 : ℝ) 1) := by
  rcases fin2_cases k with rfl | rfl
  · rw [c1fun_zero]; exact (isCompact_Icc.image continuous_cellA).isClosed
  · rw [c1fun_one]; exact (isCompact_Icc.image continuous_cellB).isClosed

theorem actual_edge_embeddings (e : kleinGraph.edgeSet) :
    IsEmbedding (kleinDrawing.arc e) :=
  ((kleinDrawing.arc e).continuous.isClosedEmbedding (kleinDrawing_good.arc_injective e)).isEmbedding

-- Each source hypothesis is exposed; this does not invoke the author's bundled endpoint.
theorem expanded_source_counterexample :
    T2Space KleinBottle ∧ CompactSpace KleinBottle ∧
    (∀ a b : rect, Quotient.mk kleinSetoid a = Quotient.mk kleinSetoid b ↔
      Relation.EqvGen sidePair a b) ∧
    IsOpenEmbedding interiorChart ∧ IsOpenEmbedding seamA ∧ IsOpenEmbedding seamB ∧
    kleinCells.n0 = 1 ∧ kleinCells.n1 = 2 ∧ kleinCells.n2 = 1 ∧ kleinCells.euler = 0 ∧
    kleinGraph.Connected ∧ kleinGraph.IsRegularOfDegree 8 ∧
    Fintype.card (Fin 12) = 12 ∧ kleinGraph.edgeFinset.card = 48 ∧
    IsGoodOneDrawing kleinDrawing ∧
    ((kleinGraph.edgeFinset.card : ℤ) = 4 * (Fintype.card (Fin 12) : ℤ) - 4 * kleinCells.euler) ∧
    matchM.IsMatching ∧ matchM.edgeSet.ncard = 3 ∧
    (¬ ∃ P : kleinGraph.Subgraph, P.IsPerfectMatching ∧ matchM.edgeSet ⊆ P.edgeSet) ∧
    ¬ Conjecture25 KleinBottle kleinCells := by
  refine ⟨kleinBottle_t2, kleinBottle_compact, mk_eq_iff_eqvGen,
    isOpenEmbedding_interiorChart, isOpenEmbedding_seamA, isOpenEmbedding_seamB,
    rfl, rfl, rfl, kleinCells_euler, kleinGraph_connected, kleinGraph_regular,
    rfl, kleinGraph_card_edges, kleinDrawing_good, ?_, matchM_isMatching,
    matchM_card, matchM_not_extendable, ?_⟩
  · rw [kleinGraph_card_edges, kleinCells_euler]; norm_num
  · intro h
    have he := h (Fin 12) kleinGraph kleinGraph_connected kleinGraph_regular
      ⟨kleinDrawing, kleinDrawing_good⟩ (by rw [kleinGraph_card_edges, kleinCells_euler]; norm_num)
    exact matchM_not_extendable (he.2 matchM matchM_isMatching matchM_card)

end IndependentReplay
#print axioms Klein366521.nf_eq_bottom
#print axioms Klein366521.nf_eq_left
#print axioms Klein366521.nf_classify
#print axioms Klein366521.nf_idem
#print axioms Klein366521.toK_nf
#print axioms Klein366521.toK_corner40
#print axioms Klein366521.toK_corner03
#print axioms Klein366521.stripA
#print axioms Klein366521.mem_stripA_mk
#print axioms Klein366521.isOpen_stripA
#print axioms Klein366521.seamA
#print axioms Klein366521.seamA_of_nonneg
#print axioms Klein366521.seamA_of_neg
#print axioms Klein366521.seamA_agree
#print axioms Klein366521.continuous_seamA
#print axioms Klein366521.seamA_injective
#print axioms Klein366521.isOpenMap_seamA
#print axioms Klein366521.isOpenEmbedding_seamA
#print axioms Klein366521.stripB
#print axioms Klein366521.mem_stripB_mk
#print axioms Klein366521.isOpen_stripB
#print axioms Klein366521.seamB
#print axioms Klein366521.seamB_of_nonneg
#print axioms Klein366521.seamB_of_neg
#print axioms Klein366521.seamB_agree
#print axioms Klein366521.continuous_seamB
#print axioms Klein366521.seamB_injective
#print axioms Klein366521.isOpenMap_seamB
#print axioms Klein366521.isOpenEmbedding_seamB
#print axioms Klein366521.cellA
#print axioms Klein366521.cellB
#print axioms Klein366521.cellF
#print axioms Klein366521.c1fun
#print axioms Klein366521.c1fun_zero
#print axioms Klein366521.c1fun_one
#print axioms Klein366521.fin2_cases
#print axioms Klein366521.fin1_eq
#print axioms Klein366521.continuous_cellA
#print axioms Klein366521.continuous_cellB
#print axioms Klein366521.continuous_cellF
#print axioms Klein366521.ιA
#print axioms Klein366521.rA
#print axioms Klein366521.isEmbedding_ιA
#print axioms Klein366521.ιB
#print axioms Klein366521.rB
#print axioms Klein366521.isEmbedding_ιB
#print axioms Klein366521.ιF
#print axioms Klein366521.rF
#print axioms Klein366521.isEmbedding_ιF
#print axioms Klein366521.embA
#print axioms Klein366521.embB
#print axioms Klein366521.embF
#print axioms Klein366521.bdA0
#print axioms Klein366521.bdA1
#print axioms Klein366521.bdB0
#print axioms Klein366521.bdB1
#print axioms Klein366521.cellF_bd
#print axioms Klein366521.shapeIdx
#print axioms Klein366521.cellMem
#print axioms Klein366521.cell_rep
#print axioms Klein366521.cell_unique
#print axioms Klein366521.cell_exists
#print axioms Klein366521.kleinCells
#print axioms Klein366521.kleinCells_euler
#print axioms Klein366521.openUnit
#print axioms Klein366521.Drawing
#print axioms Klein366521.TransverseAt
#print axioms Klein366521.CellStructure2
#print axioms Klein366521.IsMExtendable
#print axioms Klein366521.Conjecture25
#print axioms Klein366521.vx
#print axioms Klein366521.vy
#print axioms Klein366521.pt
#print axioms Klein366521.vx_le
#print axioms Klein366521.vy_le
#print axioms Klein366521.lattice_mem
#print axioms Klein366521.pt_mem
#print axioms Klein366521.nf_pt
#print axioms Klein366521.pt_injective
#print axioms Klein366521.labN
#print axioms Klein366521.lab
#print axioms Klein366521.toK_lattice
#print axioms Klein366521.EIx
#print axioms Klein366521.segPt
#print axioms Klein366521.startN
#print axioms Klein366521.endN
#print axioms Klein366521.src
#print axioms Klein366521.dst
#print axioms Klein366521.bounds_aux
#print axioms Klein366521.src_ne_dst
#print axioms Klein366521.adj_src_dst
#print axioms Klein366521.adj_has_ix
#print axioms Klein366521.cross_disjoint
#print axioms Klein366521.segPt_zero
#print axioms Klein366521.segPt_one
#print axioms Klein366521.continuous_segPt
#print axioms Klein366521.segArc
#print axioms Klein366521.segArc_apply
#print axioms Klein366521.segArc_zero
#print axioms Klein366521.segArc_one
#print axioms Klein366521.not_nat_frac
#print axioms Klein366521.nat_eq_of_close
#print axioms Klein366521.nat_eq_of_twice
#print axioms Klein366521.fin4_le
#print axioms Klein366521.fin3_le
#print axioms Klein366521.segPt_open
#print axioms Klein366521.segPt_not_lattice
#print axioms Klein366521.IsCrossPair
#print axioms Klein366521.seg_meet
#print axioms Klein366521.unit_cases
#print axioms Klein366521.segArc_at_zero
#print axioms Klein366521.segArc_at_one
#print axioms Klein366521.toK_open_eq
#print axioms Klein366521.arc_meet
#print axioms Klein366521.arc_ne_pt
#print axioms Klein366521.segArc_injective
#print axioms Klein366521.toSym2
#print axioms Klein366521.exists_ix
#print axioms Klein366521.idx
#print axioms Klein366521.idx_spec
#print axioms Klein366521.idx_inj
#print axioms Klein366521.mem_edge_iff
#print axioms Klein366521.kleinDrawing
#print axioms Klein366521.crossPair_no_common
#print axioms Klein366521.crossPair_unique
#print axioms Klein366521.dp_affine
#print axioms Klein366521.dm_affine
#print axioms Klein366521.transverse_core
#print axioms Klein366521.transverse_of_crossPair
#print axioms Klein366521.kleinDrawing_good
#print axioms Klein366521.conjecture25_false
#print axioms Klein366521.conjecture25_false_of_euler_zero
#print axioms Klein366521.klein_counterexample
#print axioms Klein366521.kleinBottle_gluing
#print axioms Klein366521.diagonals_cross
#print axioms Klein366521.faces
#print axioms Klein366521.adjB
#print axioms Klein366521.adjB_symm
#print axioms Klein366521.adjB_irrefl
#print axioms Klein366521.kleinGraph
#print axioms Klein366521.kleinGraph_adj
#print axioms Klein366521.degree_eight_aux
#print axioms Klein366521.kleinGraph_regular
#print axioms Klein366521.kleinGraph_card_edges
#print axioms Klein366521.reach_aux
#print axioms Klein366521.kleinGraph_connected
#print axioms Klein366521.mate
#print axioms Klein366521.mAdjB
#print axioms Klein366521.mAdjB_symm
#print axioms Klein366521.mAdjB_sub
#print axioms Klein366521.mAdjB_vert
#print axioms Klein366521.matchM
#print axioms Klein366521.mAdjB_iff
#print axioms Klein366521.matchM_isMatching
#print axioms Klein366521.matchM_edgeSet
#print axioms Klein366521.matchM_card
#print axioms Klein366521.even_nbr_aux
#print axioms Klein366521.mate_odd
#print axioms Klein366521.matchM_not_extendable
#print axioms Klein366521.kleinGraph_not_three_extendable
#print axioms Klein366521.rect
#print axioms Klein366521.openRect
#print axioms Klein366521.mem_rect_iff
#print axioms Klein366521.mem_rect_mk
#print axioms Klein366521.mem_openRect_iff
#print axioms Klein366521.mem_openRect_mk
#print axioms Klein366521.isOpen_openRect
#print axioms Klein366521.openRect_subset_rect
#print axioms Klein366521.nf
#print axioms Klein366521.nf_corner_mk
#print axioms Klein366521.nf_self_mk
#print axioms Klein366521.nf_right_mk
#print axioms Klein366521.nf_top_mk
#print axioms Klein366521.nf_trichotomy
#print axioms Klein366521.nf_mem
#print axioms Klein366521.nf_of_openRect
#print axioms Klein366521.eq_of_nf_eq_openRect
#print axioms Klein366521.kleinSetoid
#print axioms Klein366521.KleinBottle
#print axioms Klein366521.mk_eq_iff
#print axioms Klein366521.sidePair
#print axioms Klein366521.nf_left_right
#print axioms Klein366521.nf_bottom_top
#print axioms Klein366521.sidePair_nf
#print axioms Klein366521.toNF
#print axioms Klein366521.eqvGen_toNF
#print axioms Klein366521.mk_eq_iff_eqvGen
#print axioms Klein366521.clampPt
#print axioms Klein366521.continuous_clampPt
#print axioms Klein366521.clampPt_of_mem
#print axioms Klein366521.toK
#print axioms Klein366521.continuous_toK
#print axioms Klein366521.toK_val
#print axioms Klein366521.toK_eq_iff
#print axioms Klein366521.toK_surjective
#print axioms Klein366521.isOpen_iff_mk
#print axioms Klein366521.interiorChart
#print axioms Klein366521.isOpenEmbedding_interiorChart
#print axioms Klein366521.interiorChart_apply
#print axioms Klein366521.Fp
#print axioms Klein366521.Fpoly
#print axioms Klein366521.continuous_Fpoly
#print axioms Klein366521.Fp_eq
#print axioms Klein366521.Fp_eq_of
#print axioms Klein366521.Fpoly_nf
#print axioms Klein366521.IsNF
#print axioms Klein366521.nf_isNF
#print axioms Klein366521.cancel_aux
#print axioms Klein366521.Fp_inj
#print axioms Klein366521.nf_eq_of_Fpoly
#print axioms Klein366521.Fpoly_respect
#print axioms Klein366521.Fk
#print axioms Klein366521.continuous_Fk
#print axioms Klein366521.Fk_injective
#print axioms Klein366521.kleinBottle_compact
#print axioms IndependentReplay.Square
#print axioms IndependentReplay.faceMap
#print axioms IndependentReplay.faceMap_continuous
#print axioms IndependentReplay.faceMap_surjective
#print axioms IndependentReplay.faceMap_quotient
#print axioms IndependentReplay.weak_topology
#print axioms IndependentReplay.closed_face
#print axioms IndependentReplay.closed_edges
#print axioms IndependentReplay.actual_edge_embeddings
#print axioms IndependentReplay.expanded_source_counterexample

#eval Lean.versionString
