import Mathlib.Topology.UnitInterval
import Mathlib.Topology.ContinuousMap.Defs
import Mathlib.Topology.Maps.Basic
import Mathlib.Combinatorics.SimpleGraph.Matching
import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected
import Mathlib.Data.Set.Card

/-!
# Source predicates for MathDB 366521 (arXiv:2501.02726v2, Conjecture 25)

Generic definitions, independent of the witness.  Source (pp. 1-2): graphs are finite,
simple and connected; a graph is 1-embedded on a closed surface when it is drawn with a
good drawing ((i) vertices at distinct points, (ii) adjacent edges do not cross, (iii) no
three edges cross at one point, (iv) nonadjacent edges do not touch tangentially) such that
every edge crosses another edge at most once.  Optimal: `|E| = 4|V| - 4 χ`.
`m`-extendable: at least `2m+2` vertices and every `m`-edge matching extends to a perfect
matching.
-/

open Set Function Topology

namespace Klein366521

/-- Interior parameters `(0,1)` of the unit interval. -/
def openUnit : Set unitInterval := {t | 0 < (t : ℝ) ∧ (t : ℝ) < 1}

/-- A drawing of a simple graph in a space: a point for every vertex and a continuous curve
for every edge, running from one endpoint to the other. -/
structure Drawing {V : Type} (G : SimpleGraph V) (X : Type) [TopologicalSpace X] where
  pt : V → X
  arc : G.edgeSet → C(unitInterval, X)
  ends : ∀ e : G.edgeSet, ∃ u v : V, (e : Sym2 V) = s(u, v) ∧ arc e 0 = pt u ∧ arc e 1 = pt v

variable {V : Type} {G : SimpleGraph V} {X : Type} [TopologicalSpace X]

/-- The interior points of a drawn edge. -/
def Drawing.inner (D : Drawing G X) (e : G.edgeSet) : Set X := D.arc e '' openUnit

/-- Transverse crossing of `γ` at `s₀` with `δ` at `t₀`: in a genuine local chart (an open
embedding `ψ` of an open planar set `U` into the surface) both curves are straight lines
through a common point with linearly independent directions near the parameters. -/
def TransverseAt (γ δ : C(unitInterval, X)) (s₀ t₀ : unitInterval) : Prop :=
  ∃ (U : Set (ℝ × ℝ)) (ψ : U → X), IsOpen U ∧ IsOpenEmbedding ψ ∧
    ∃ (c v w : ℝ × ℝ) (ε : ℝ), 0 < ε ∧ v.1 * w.2 - v.2 * w.1 ≠ 0 ∧
      (∀ s : unitInterval, |(s : ℝ) - (s₀ : ℝ)| < ε →
        ∃ h : c + ((s : ℝ) - (s₀ : ℝ)) • v ∈ U, γ s = ψ ⟨_, h⟩) ∧
      (∀ t : unitInterval, |(t : ℝ) - (t₀ : ℝ)| < ε →
        ∃ h : c + ((t : ℝ) - (t₀ : ℝ)) • w ∈ U, δ t = ψ ⟨_, h⟩)

/-- A good drawing in which every edge crosses other edges at most once (a 1-embedding). -/
structure IsGoodOneDrawing (D : Drawing G X) : Prop where
  pt_injective : Injective D.pt
  arc_injective : ∀ e, Injective (D.arc e)
  inner_avoids_vertices : ∀ e, ∀ t ∈ openUnit, ∀ w, D.arc e t ≠ D.pt w
  adjacent_inner_disjoint : ∀ e f : G.edgeSet, e ≠ f →
    (∃ w, w ∈ (e : Sym2 V) ∧ w ∈ (f : Sym2 V)) → Disjoint (D.inner e) (D.inner f)
  no_triple_crossing : ∀ e f g : G.edgeSet, e ≠ f → f ≠ g → e ≠ g →
    D.inner e ∩ D.inner f ∩ D.inner g = ∅
  crossings_transverse : ∀ e f : G.edgeSet, e ≠ f → ∀ s ∈ openUnit, ∀ t ∈ openUnit,
    D.arc e s = D.arc f t → TransverseAt (D.arc e) (D.arc f) s t
  at_most_one_crossing : ∀ e : G.edgeSet,
    {x | x ∈ D.inner e ∧ ∃ f : G.edgeSet, f ≠ e ∧ x ∈ D.inner f}.Subsingleton

/-- A finite cell structure of dimension at most two with cubical characteristic maps
(a finite CW structure): characteristic maps on `[0,1]` and `[0,1]²` are continuous and
embed the open cubes; boundaries go to lower cells; the open cells partition the space. -/
structure CellStructure2 (X : Type) [TopologicalSpace X] where
  n0 : ℕ
  n1 : ℕ
  n2 : ℕ
  c0 : Fin n0 → X
  c1 : Fin n1 → ℝ → X
  c2 : Fin n2 → ℝ × ℝ → X
  c1_cont : ∀ k, ContinuousOn (c1 k) (Icc 0 1)
  c2_cont : ∀ k, ContinuousOn (c2 k) (Icc (0 : ℝ) 1 ×ˢ Icc (0 : ℝ) 1)
  c1_emb : ∀ k, IsEmbedding ((Ioo (0 : ℝ) 1).domRestrict (c1 k))
  c2_emb : ∀ k, IsEmbedding ((Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1).domRestrict (c2 k))
  c1_bd : ∀ k, c1 k 0 ∈ range c0 ∧ c1 k 1 ∈ range c0
  c2_bd : ∀ k, ∀ p ∈ (Icc (0 : ℝ) 1 ×ˢ Icc (0 : ℝ) 1) \ (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1),
    c2 k p ∈ range c0 ∪ ⋃ j, c1 j '' Ioo 0 1
  partition : ∀ x : X, ∃! i : Fin n0 ⊕ (Fin n1 ⊕ Fin n2),
    Sum.elim (fun k => x = c0 k)
      (Sum.elim (fun k => x ∈ c1 k '' Ioo 0 1)
        (fun k => x ∈ c2 k '' (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1))) i

/-- Euler characteristic computed from the cell structure. -/
def CellStructure2.euler (C : CellStructure2 X) : ℤ := (C.n0 : ℤ) - C.n1 + C.n2

/-- `m`-extendability (source p. 2) with Mathlib's matching predicates. -/
def IsMExtendable {W : Type} [Fintype W] (H : SimpleGraph W) (m : ℕ) : Prop :=
  2 * m + 2 ≤ Fintype.card W ∧
    ∀ M : H.Subgraph, M.IsMatching → M.edgeSet.ncard = m →
      ∃ P : H.Subgraph, P.IsPerfectMatching ∧ M.edgeSet ⊆ P.edgeSet

/-- Conjecture 25 on a surface `K` whose Euler characteristic is computed by `C`. -/
def Conjecture25 (K : Type) [TopologicalSpace K] (C : CellStructure2 K) : Prop :=
  ∀ (W : Type) [Fintype W] [DecidableEq W] (H : SimpleGraph W) [DecidableRel H.Adj],
    H.Connected → H.IsRegularOfDegree 8 →
    (∃ D : Drawing H K, IsGoodOneDrawing D) →
    ((H.edgeFinset.card : ℤ) = 4 * (Fintype.card W : ℤ) - 4 * C.euler) →
    IsMExtendable H 3

end Klein366521
