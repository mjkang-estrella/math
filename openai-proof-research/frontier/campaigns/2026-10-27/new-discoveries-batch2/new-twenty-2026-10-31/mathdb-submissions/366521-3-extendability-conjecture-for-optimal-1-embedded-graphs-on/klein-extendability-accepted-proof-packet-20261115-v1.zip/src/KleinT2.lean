import KleinCells

/-!
# The Klein bottle is Hausdorff and compact

Polynomial invariants `Fp` respect the identifications and separate the classes, giving a
continuous injection of the Klein bottle into `ℝ⁵`.
-/

open Set Function Topology

namespace Klein366521

noncomputable def Fp (x y : ℝ) : ℝ × ℝ × ℝ × ℝ × ℝ :=
  (x * (4 - x), y * (3 - y), x * (4 - x) * (x - 2) * (3 - 2 * y),
   y * (3 - y) * (2 * y - 3), x * (4 - x) * (x - 2) * (y * (3 - y)))

noncomputable def Fpoly (p : ℝ × ℝ) : ℝ × ℝ × ℝ × ℝ × ℝ := Fp p.1 p.2

theorem continuous_Fpoly : Continuous Fpoly := by
  unfold Fpoly Fp
  fun_prop

theorem Fp_eq {x y x' y' : ℝ} (h : Fp x y = Fp x' y') :
    x * (4 - x) = x' * (4 - x') ∧ y * (3 - y) = y' * (3 - y') ∧
    x * (4 - x) * (x - 2) * (3 - 2 * y) = x' * (4 - x') * (x' - 2) * (3 - 2 * y') ∧
    y * (3 - y) * (2 * y - 3) = y' * (3 - y') * (2 * y' - 3) ∧
    x * (4 - x) * (x - 2) * (y * (3 - y)) = x' * (4 - x') * (x' - 2) * (y' * (3 - y')) := by
  unfold Fp at h
  simp only [Prod.mk.injEq] at h
  exact h

theorem Fp_eq_of {x y x' y' : ℝ} (h1 : x * (4 - x) = x' * (4 - x'))
    (h2 : y * (3 - y) = y' * (3 - y'))
    (h3 : x * (4 - x) * (x - 2) * (3 - 2 * y) = x' * (4 - x') * (x' - 2) * (3 - 2 * y'))
    (h4 : y * (3 - y) * (2 * y - 3) = y' * (3 - y') * (2 * y' - 3))
    (h5 : x * (4 - x) * (x - 2) * (y * (3 - y)) = x' * (4 - x') * (x' - 2) * (y' * (3 - y'))) :
    Fp x y = Fp x' y' :=
  Prod.ext h1 (Prod.ext h2 (Prod.ext h3 (Prod.ext h4 h5)))

theorem Fpoly_nf {q : ℝ × ℝ} (hq : q ∈ rect) : Fpoly (nf q) = Fpoly q := by
  obtain ⟨a, b⟩ := q
  dsimp only [nf]
  split_ifs with h1 h2 h3
  · obtain ⟨ha | ha, hb | hb⟩ := h1 <;> subst ha <;> subst hb <;>
      exact Fp_eq_of (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  · subst h2
    show Fp 0 b = Fp 4 b
    exact Fp_eq_of (by ring) (by ring) (by ring) (by ring) (by ring)
  · subst h3
    show Fp (4 - a) 0 = Fp a 3
    exact Fp_eq_of (by ring) (by ring) (by ring) (by ring) (by ring)
  · rfl

/-- Coordinates of normal forms. -/
def IsNF (x y : ℝ) : Prop :=
  (x = 0 ∧ y = 0) ∨ (x = 0 ∧ 0 < y ∧ y < 3) ∨ (y = 0 ∧ 0 < x ∧ x < 4) ∨
    ((0 < x ∧ x < 4) ∧ (0 < y ∧ y < 3))

theorem nf_isNF {q : ℝ × ℝ} (hq : q ∈ rect) : IsNF (nf q).1 (nf q).2 := by
  rcases nf_classify hq with e | ⟨y, hy0, hy3, e⟩ | ⟨x, hx0, hx4, e⟩ | ⟨hi, e⟩
  · rw [e]; exact Or.inl ⟨rfl, rfl⟩
  · rw [e]; exact Or.inr (Or.inl ⟨rfl, hy0, hy3⟩)
  · rw [e]; exact Or.inr (Or.inr (Or.inl ⟨rfl, hx0, hx4⟩))
  · rw [e]; exact Or.inr (Or.inr (Or.inr (mem_openRect_iff.mp hi)))

theorem cancel_aux {A B u v : ℝ} (hA : 0 < A) (hAB : A = B) (h : A * u = B * v) : u = v := by
  rw [← hAB] at h
  exact mul_left_cancel₀ hA.ne' h

theorem Fp_inj {x y x' y' : ℝ} (hP : IsNF x y) (hQ : IsNF x' y') (h : Fp x y = Fp x' y') :
    (x, y) = (x', y') := by
  obtain ⟨h1, h2, h3, h4, h5⟩ := Fp_eq h
  rcases hP with ⟨rfl, rfl⟩ | ⟨rfl, hy0, hy3⟩ | ⟨rfl, hx0, hx4⟩ | ⟨⟨hx0, hx4⟩, ⟨hy0, hy3⟩⟩ <;>
    rcases hQ with ⟨rfl, rfl⟩ | ⟨rfl, hy0', hy3'⟩ | ⟨rfl, hx0', hx4'⟩ |
      ⟨⟨hx0', hx4'⟩, ⟨hy0', hy3'⟩⟩
  -- (0,0) _
  · rfl
  · exfalso; linarith [mul_pos hy0' (sub_pos.mpr hy3')]
  · exfalso; linarith [mul_pos hx0' (sub_pos.mpr hx4')]
  · exfalso; linarith [mul_pos hx0' (sub_pos.mpr hx4')]
  -- (0,y) _
  · exfalso; linarith [mul_pos hy0 (sub_pos.mpr hy3)]
  · have e := cancel_aux (mul_pos hy0 (sub_pos.mpr hy3)) h2 h4
    rw [show y = y' by linarith]
  · exfalso; linarith [mul_pos hx0' (sub_pos.mpr hx4')]
  · exfalso; linarith [mul_pos hx0' (sub_pos.mpr hx4')]
  -- (x,0) _
  · exfalso; linarith [mul_pos hx0 (sub_pos.mpr hx4)]
  · exfalso; linarith [mul_pos hx0 (sub_pos.mpr hx4)]
  · have h3' : x * (4 - x) * (x - 2) = x' * (4 - x') * (x' - 2) := by linarith
    have e := cancel_aux (mul_pos hx0 (sub_pos.mpr hx4)) h1 h3'
    rw [show x = x' by linarith]
  · exfalso; linarith [mul_pos hy0' (sub_pos.mpr hy3')]
  -- interior _
  · exfalso; linarith [mul_pos hx0 (sub_pos.mpr hx4)]
  · exfalso; linarith [mul_pos hx0 (sub_pos.mpr hx4)]
  · exfalso; linarith [mul_pos hy0 (sub_pos.mpr hy3)]
  · have h5' : x * (4 - x) * (y * (3 - y)) * (x - 2) =
        x' * (4 - x') * (y' * (3 - y')) * (x' - 2) := by linarith
    have ex := cancel_aux (mul_pos (mul_pos hx0 (sub_pos.mpr hx4)) (mul_pos hy0 (sub_pos.mpr hy3)))
      (by rw [h1, h2]) h5'
    have ey := cancel_aux (mul_pos hy0 (sub_pos.mpr hy3)) h2 h4
    rw [show x = x' by linarith, show y = y' by linarith]

theorem nf_eq_of_Fpoly {p q : ℝ × ℝ} (hp : p ∈ rect) (hq : q ∈ rect) (h : Fpoly p = Fpoly q) :
    nf p = nf q := by
  rw [← Fpoly_nf hp, ← Fpoly_nf hq] at h
  exact Fp_inj (nf_isNF hp) (nf_isNF hq) h

theorem Fpoly_respect (a b : rect) (h : nf a.1 = nf b.1) : Fpoly a.1 = Fpoly b.1 := by
  rw [← Fpoly_nf a.2, h, Fpoly_nf b.2]

/-- The induced continuous map `K → ℝ⁵`. -/
noncomputable def Fk : KleinBottle → ℝ × ℝ × ℝ × ℝ × ℝ :=
  Quotient.lift (fun r : rect => Fpoly r.1) Fpoly_respect

theorem continuous_Fk : Continuous Fk :=
  Continuous.quotient_lift (continuous_Fpoly.comp continuous_subtype_val) Fpoly_respect

theorem Fk_injective : Injective Fk := by
  intro x y
  induction x using Quotient.inductionOn with
  | h a =>
    induction y using Quotient.inductionOn with
    | h b =>
      intro h
      apply Quotient.sound
      exact nf_eq_of_Fpoly a.2 b.2 h

/-- **The Klein bottle is Hausdorff.** -/
instance kleinBottle_t2 : T2Space KleinBottle :=
  T2Space.of_injective_continuous Fk_injective continuous_Fk

instance : CompactSpace rect :=
  isCompact_iff_compactSpace.mp (isCompact_Icc.prod isCompact_Icc)

/-- **The Klein bottle is compact.** -/
theorem kleinBottle_compact : CompactSpace KleinBottle := inferInstance

end Klein366521
