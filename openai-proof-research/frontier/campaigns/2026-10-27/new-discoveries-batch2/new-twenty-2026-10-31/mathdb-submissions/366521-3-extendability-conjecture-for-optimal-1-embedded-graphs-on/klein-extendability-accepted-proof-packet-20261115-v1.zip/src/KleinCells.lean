import KleinDrawing

/-!
# The canonical cell structure of the Klein bottle (`χ = 0`)

One 0-cell (the corner class), two 1-cells (the bottom/top seam `a` and the left/right seam
`b`) and one 2-cell (the open rectangle), with cubical characteristic maps.  The 1-cells are
shown to be embedded using explicit open embeddings of strips across each seam.
-/

open Set Function Topology

namespace Klein366521

/-! ## Normal-form classification -/

theorem nf_eq_bottom {r : ℝ × ℝ} {x : ℝ} (hx0 : 0 < x) (_hx4 : x < 4) (h : nf r = (x, 0)) :
    r = (x, 0) ∨ r = (4 - x, 3) := by
  obtain ⟨a, b⟩ := r
  dsimp only [nf] at h
  split_ifs at h with h1 h2 h3
  · obtain ⟨e, -⟩ := Prod.mk.inj h
    exfalso; linarith
  · obtain ⟨e, -⟩ := Prod.mk.inj h
    exfalso; linarith
  · obtain ⟨e, -⟩ := Prod.mk.inj h
    right
    rw [Prod.mk.injEq]
    exact ⟨by linarith, h3⟩
  · exact Or.inl h

theorem nf_eq_left {r : ℝ × ℝ} {y : ℝ} (hy0 : 0 < y) (_hy3 : y < 3) (h : nf r = (0, y)) :
    r = (0, y) ∨ r = (4, y) := by
  obtain ⟨a, b⟩ := r
  dsimp only [nf] at h
  split_ifs at h with h1 h2 h3
  · obtain ⟨-, e⟩ := Prod.mk.inj h
    exfalso; linarith
  · obtain ⟨-, e⟩ := Prod.mk.inj h
    right
    rw [Prod.mk.injEq]
    exact ⟨h2, e⟩
  · obtain ⟨-, e⟩ := Prod.mk.inj h
    exfalso; linarith
  · exact Or.inl h

/-- Classification of the normal forms of points of the rectangle. -/
theorem nf_classify {q : ℝ × ℝ} (hq : q ∈ rect) :
    nf q = (0, 0) ∨ (∃ y, 0 < y ∧ y < 3 ∧ nf q = (0, y)) ∨
      (∃ x, 0 < x ∧ x < 4 ∧ nf q = (x, 0)) ∨ (q ∈ openRect ∧ nf q = q) := by
  obtain ⟨a, b⟩ := q
  obtain ⟨⟨ha0, ha4⟩, ⟨hb0, hb3⟩⟩ := mem_rect_mk.mp hq
  by_cases hc : (a = 0 ∨ a = 4) ∧ (b = 0 ∨ b = 3)
  · exact Or.inl (nf_corner_mk hc)
  by_cases h4 : a = 4
  · have hb0' : b ≠ 0 := fun e => hc ⟨Or.inr h4, Or.inl e⟩
    have hb3' : b ≠ 3 := fun e => hc ⟨Or.inr h4, Or.inr e⟩
    exact Or.inr (Or.inl ⟨b, lt_of_le_of_ne hb0 (Ne.symm hb0'), lt_of_le_of_ne hb3 hb3',
      nf_right_mk hc h4⟩)
  by_cases h3 : b = 3
  · have ha0' : a ≠ 0 := fun e => hc ⟨Or.inl e, Or.inr h3⟩
    have ha1 : 0 < a := lt_of_le_of_ne ha0 (Ne.symm ha0')
    have ha2 : a < 4 := lt_of_le_of_ne ha4 h4
    exact Or.inr (Or.inr (Or.inl ⟨4 - a, by linarith, by linarith, nf_top_mk hc h4 h3⟩))
  have hs := nf_self_mk hc h4 h3
  by_cases hA : a = 0
  · have hb0' : b ≠ 0 := fun e => hc ⟨Or.inl hA, Or.inl e⟩
    refine Or.inr (Or.inl ⟨b, lt_of_le_of_ne hb0 (Ne.symm hb0'), lt_of_le_of_ne hb3 h3, ?_⟩)
    rw [hs, hA]
  by_cases hB : b = 0
  · refine Or.inr (Or.inr (Or.inl ⟨a, lt_of_le_of_ne ha0 (Ne.symm hA), lt_of_le_of_ne ha4 h4, ?_⟩))
    rw [hs, hB]
  · exact Or.inr (Or.inr (Or.inr ⟨mem_openRect_mk.mpr ⟨⟨lt_of_le_of_ne ha0 (Ne.symm hA),
      lt_of_le_of_ne ha4 h4⟩, ⟨lt_of_le_of_ne hb0 (Ne.symm hB), lt_of_le_of_ne hb3 h3⟩⟩, hs⟩))

theorem nf_idem {q : ℝ × ℝ} (hq : q ∈ rect) : nf (nf q) = nf q := by
  rcases nf_classify hq with h | ⟨y, hy0, hy3, h⟩ | ⟨x, hx0, hx4, h⟩ | ⟨hi, h⟩
  · rw [h]; exact nf_corner_mk ⟨Or.inl rfl, Or.inl rfl⟩
  · rw [h]
    exact nf_self_mk (fun hc => hc.2.elim (fun e => by linarith) (fun e => by linarith))
      (by norm_num) (fun e => by linarith)
  · rw [h]
    exact nf_self_mk (fun hc => hc.1.elim (fun e => by linarith) (fun e => by linarith))
      (fun e => by linarith) (by norm_num)
  · rw [h]; exact nf_of_openRect hi

theorem toK_nf {q : ℝ × ℝ} (hq : q ∈ rect) : toK (nf q) = toK q :=
  (toK_eq_iff (nf_mem hq) hq).mpr (nf_idem hq)

theorem toK_corner40 : toK (4, 0) = toK (0, 0) := by
  rw [toK_eq_iff (mem_rect_mk.mpr ⟨⟨by norm_num, le_refl 4⟩, ⟨le_refl 0, by norm_num⟩⟩)
    (mem_rect_mk.mpr ⟨⟨le_refl 0, by norm_num⟩, ⟨le_refl 0, by norm_num⟩⟩),
    nf_corner_mk (x := 4) (y := 0) ⟨Or.inr rfl, Or.inl rfl⟩,
    nf_corner_mk (x := 0) (y := 0) ⟨Or.inl rfl, Or.inl rfl⟩]

theorem toK_corner03 : toK (0, 3) = toK (0, 0) := by
  rw [toK_eq_iff (mem_rect_mk.mpr ⟨⟨le_refl 0, by norm_num⟩, ⟨by norm_num, le_refl 3⟩⟩)
    (mem_rect_mk.mpr ⟨⟨le_refl 0, by norm_num⟩, ⟨le_refl 0, by norm_num⟩⟩),
    nf_corner_mk (x := 0) (y := 3) ⟨Or.inl rfl, Or.inr rfl⟩,
    nf_corner_mk (x := 0) (y := 0) ⟨Or.inl rfl, Or.inl rfl⟩]

/-! ## Strip across the bottom/top seam -/

def stripA : Set (ℝ × ℝ) := Ioo (0 : ℝ) 4 ×ˢ Ioo (-1 : ℝ) 1

theorem mem_stripA_mk {x y : ℝ} : (x, y) ∈ stripA ↔ (0 < x ∧ x < 4) ∧ (-1 < y ∧ y < 1) :=
  Iff.rfl

theorem isOpen_stripA : IsOpen stripA := isOpen_Ioo.prod isOpen_Ioo

/-- Chart across the bottom/top seam: below the seam use the reflected top strip. -/
noncomputable def seamA (p : stripA) : KleinBottle :=
  if (0 : ℝ) ≤ p.1.2 then toK p.1 else toK (4 - p.1.1, 3 + p.1.2)

theorem seamA_of_nonneg (p : stripA) (h : (0 : ℝ) ≤ p.1.2) : seamA p = toK p.1 :=
  ite_eq_left h

theorem seamA_of_neg (p : stripA) (h : ¬ (0 : ℝ) ≤ p.1.2) :
    seamA p = toK (4 - p.1.1, 3 + p.1.2) :=
  ite_eq_right h

theorem seamA_agree {x : ℝ} (hx0 : 0 < x) (hx4 : x < 4) : toK (x, 0) = toK (4 - x, 3) := by
  rw [toK_eq_iff (mem_rect_mk.mpr ⟨⟨hx0.le, hx4.le⟩, ⟨le_refl 0, by norm_num⟩⟩)
    (mem_rect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by norm_num, le_refl 3⟩⟩)]
  exact nf_bottom_top x

theorem continuous_seamA : Continuous seamA := by
  have hc1 : Continuous fun p : stripA => toK p.1 := continuous_toK.comp continuous_subtype_val
  have hc2 : Continuous fun p : stripA => toK (4 - p.1.1, 3 + p.1.2) :=
    continuous_toK.comp (by fun_prop)
  show Continuous fun p : stripA =>
    if (0 : ℝ) ≤ p.1.2 then toK p.1 else toK (4 - p.1.1, 3 + p.1.2)
  refine continuous_if_le (f := fun _ : stripA => (0 : ℝ)) (g := fun p : stripA => p.1.2)
    continuous_const (continuous_snd.comp continuous_subtype_val)
    hc1.continuousOn hc2.continuousOn ?_
  rintro ⟨⟨x, y⟩, hxy⟩ hp
  obtain ⟨⟨hx0, hx4⟩, -⟩ := mem_stripA_mk.mp hxy
  obtain rfl : y = 0 := hp.symm
  show toK (x, 0) = toK (4 - x, 3 + 0)
  rw [add_zero]
  exact seamA_agree hx0 hx4

theorem seamA_injective : Injective seamA := by
  rintro ⟨⟨x, y⟩, hp⟩ ⟨⟨x', y'⟩, hq⟩ h
  obtain ⟨⟨hx0, hx4⟩, ⟨hy0, hy1⟩⟩ := mem_stripA_mk.mp hp
  obtain ⟨⟨hx0', hx4'⟩, ⟨hy0', hy1'⟩⟩ := mem_stripA_mk.mp hq
  apply Subtype.ext
  show (x, y) = (x', y')
  by_cases hy : (0 : ℝ) ≤ y <;> by_cases hy' : (0 : ℝ) ≤ y'
  · rw [seamA_of_nonneg ⟨(x, y), hp⟩ hy, seamA_of_nonneg ⟨(x', y'), hq⟩ hy'] at h
    have m1 : (x, y) ∈ rect := mem_rect_mk.mpr ⟨⟨hx0.le, hx4.le⟩, ⟨hy, by linarith⟩⟩
    have m2 : (x', y') ∈ rect := mem_rect_mk.mpr ⟨⟨hx0'.le, hx4'.le⟩, ⟨hy', by linarith⟩⟩
    have hn := (toK_eq_iff m1 m2).mp h
    rwa [nf_self_mk (x := x) (y := y)
        (fun hc => hc.1.elim (fun e => by linarith) (fun e => by linarith))
        (fun e => by linarith) (fun e => by linarith),
      nf_self_mk (x := x') (y := y')
        (fun hc => hc.1.elim (fun e => by linarith) (fun e => by linarith))
        (fun e => by linarith) (fun e => by linarith)] at hn
  · rw [seamA_of_nonneg ⟨(x, y), hp⟩ hy, seamA_of_neg ⟨(x', y'), hq⟩ hy'] at h
    have m1 : (x, y) ∈ rect := mem_rect_mk.mpr ⟨⟨hx0.le, hx4.le⟩, ⟨hy, by linarith⟩⟩
    have m2 : (4 - x', 3 + y') ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
    have e := eq_of_nf_eq_openRect m2 ((toK_eq_iff m1 (openRect_subset_rect m2)).mp h)
    obtain ⟨-, e2⟩ := Prod.mk.inj e
    exfalso; linarith
  · rw [seamA_of_neg ⟨(x, y), hp⟩ hy, seamA_of_nonneg ⟨(x', y'), hq⟩ hy'] at h
    have m1 : (4 - x, 3 + y) ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
    have m2 : (x', y') ∈ rect := mem_rect_mk.mpr ⟨⟨hx0'.le, hx4'.le⟩, ⟨hy', by linarith⟩⟩
    have e := eq_of_nf_eq_openRect m1 ((toK_eq_iff m2 (openRect_subset_rect m1)).mp h.symm)
    obtain ⟨-, e2⟩ := Prod.mk.inj e
    exfalso; linarith
  · rw [seamA_of_neg ⟨(x, y), hp⟩ hy, seamA_of_neg ⟨(x', y'), hq⟩ hy'] at h
    have m1 : (4 - x, 3 + y) ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
    have m2 : (4 - x', 3 + y') ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
    have e := eq_of_nf_eq_openRect m2
      ((toK_eq_iff (openRect_subset_rect m1) (openRect_subset_rect m2)).mp h)
    obtain ⟨e1, e2⟩ := Prod.mk.inj e
    rw [Prod.mk.injEq]
    constructor <;> linarith

theorem isOpenMap_seamA : IsOpenMap seamA := by
  intro V hV
  obtain ⟨O, hO, rfl⟩ := isOpen_induced_iff.mp hV
  have hW : IsOpen (stripA ∩ O) := isOpen_stripA.inter hO
  have hpre : (Quotient.mk kleinSetoid) ⁻¹' (seamA '' (Subtype.val ⁻¹' O)) =
      Subtype.val ⁻¹' ({p : ℝ × ℝ | p.2 < 1} ∩ (stripA ∩ O)) ∪
      Subtype.val ⁻¹' ({p : ℝ × ℝ | 2 < p.2} ∩
        (fun p : ℝ × ℝ => (4 - p.1, p.2 - 3)) ⁻¹' (stripA ∩ O)) := by
    ext ⟨⟨a, b⟩, hr⟩
    obtain ⟨⟨ha0, ha4⟩, ⟨hb0, hb3⟩⟩ := mem_rect_mk.mp hr
    simp only [mem_preimage, mem_image, mem_union, mem_inter_iff, mem_ofPred_eq]
    constructor
    · rintro ⟨⟨⟨x, y⟩, hp⟩, hpO, hpr⟩
      obtain ⟨⟨hx0, hx4⟩, ⟨hy0, hy1⟩⟩ := mem_stripA_mk.mp hp
      rw [← toK_val] at hpr
      by_cases hy : (0 : ℝ) ≤ y
      · rw [seamA_of_nonneg ⟨(x, y), hp⟩ hy] at hpr
        have m1 : (x, y) ∈ rect := mem_rect_mk.mpr ⟨⟨hx0.le, hx4.le⟩, ⟨hy, by linarith⟩⟩
        have hn := (toK_eq_iff m1 hr).mp hpr
        rcases hy.eq_or_lt with hy' | hy'
        · subst hy'
          rw [nf_self_mk (x := x) (y := 0)
            (fun hc => hc.1.elim (fun e => by linarith) (fun e => by linarith))
            (fun e => by linarith) (by norm_num)] at hn
          rcases nf_eq_bottom hx0 hx4 hn.symm with e | e
          · obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
            exact Or.inl ⟨by norm_num, hp, hpO⟩
          · obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
            refine Or.inr ⟨by norm_num, ?_⟩
            rw [sub_sub_cancel, sub_self]
            exact ⟨hp, hpO⟩
        · have mi : (x, y) ∈ openRect :=
            mem_openRect_mk.mpr ⟨⟨hx0, hx4⟩, ⟨hy', by linarith⟩⟩
          have e := eq_of_nf_eq_openRect mi hn.symm
          obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
          exact Or.inl ⟨hy1, hp, hpO⟩
      · rw [seamA_of_neg ⟨(x, y), hp⟩ hy] at hpr
        have mi : (4 - x, 3 + y) ∈ openRect :=
          mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
        have e := eq_of_nf_eq_openRect mi ((toK_eq_iff (openRect_subset_rect mi) hr).mp hpr).symm
        obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
        refine Or.inr ⟨by linarith, ?_⟩
        rw [sub_sub_cancel, add_sub_cancel_left]
        exact ⟨hp, hpO⟩
    · rintro (⟨-, hmA, hmO⟩ | ⟨hb2, hmA, hmO⟩)
      · refine ⟨⟨(a, b), hmA⟩, hmO, ?_⟩
        rw [seamA_of_nonneg ⟨(a, b), hmA⟩ hb0]
        exact toK_val ⟨(a, b), hr⟩
      · refine ⟨⟨(4 - a, b - 3), hmA⟩, hmO, ?_⟩
        obtain ⟨⟨hx0, hx4⟩, -⟩ := mem_stripA_mk.mp hmA
        rw [← toK_val]
        by_cases hb : (0 : ℝ) ≤ b - 3
        · rw [seamA_of_nonneg ⟨(4 - a, b - 3), hmA⟩ hb]
          have hb3' : b = 3 := by linarith
          subst hb3'
          show toK (4 - a, 3 - 3) = toK (a, 3)
          rw [sub_self, seamA_agree hx0 hx4, sub_sub_cancel]
        · rw [seamA_of_neg ⟨(4 - a, b - 3), hmA⟩ hb]
          show toK (4 - (4 - a), 3 + (b - 3)) = toK (a, b)
          congr 1
          rw [Prod.mk.injEq]
          constructor <;> ring
  rw [isOpen_iff_mk, hpre]
  refine IsOpen.union ?_ ?_
  · exact ((isOpen_lt continuous_snd continuous_const).inter hW).preimage continuous_subtype_val
  · exact ((isOpen_lt continuous_const continuous_snd).inter
      (hW.preimage (by fun_prop))).preimage continuous_subtype_val

theorem isOpenEmbedding_seamA : IsOpenEmbedding seamA :=
  IsOpenEmbedding.of_continuous_injective_isOpenMap continuous_seamA seamA_injective
    isOpenMap_seamA

/-! ## Strip across the left/right seam -/

def stripB : Set (ℝ × ℝ) := Ioo (-1 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 3

theorem mem_stripB_mk {x y : ℝ} : (x, y) ∈ stripB ↔ (-1 < x ∧ x < 1) ∧ (0 < y ∧ y < 3) :=
  Iff.rfl

theorem isOpen_stripB : IsOpen stripB := isOpen_Ioo.prod isOpen_Ioo

/-- Chart across the left/right seam: left of the seam use the translated right strip. -/
noncomputable def seamB (p : stripB) : KleinBottle :=
  if (0 : ℝ) ≤ p.1.1 then toK p.1 else toK (4 + p.1.1, p.1.2)

theorem seamB_of_nonneg (p : stripB) (h : (0 : ℝ) ≤ p.1.1) : seamB p = toK p.1 :=
  ite_eq_left h

theorem seamB_of_neg (p : stripB) (h : ¬ (0 : ℝ) ≤ p.1.1) :
    seamB p = toK (4 + p.1.1, p.1.2) :=
  ite_eq_right h

theorem seamB_agree {y : ℝ} (hy0 : 0 < y) (hy3 : y < 3) : toK (0, y) = toK (4, y) := by
  rw [toK_eq_iff (mem_rect_mk.mpr ⟨⟨le_refl 0, by norm_num⟩, ⟨hy0.le, hy3.le⟩⟩)
    (mem_rect_mk.mpr ⟨⟨by norm_num, le_refl 4⟩, ⟨hy0.le, hy3.le⟩⟩)]
  exact nf_left_right y

theorem continuous_seamB : Continuous seamB := by
  have hc1 : Continuous fun p : stripB => toK p.1 := continuous_toK.comp continuous_subtype_val
  have hc2 : Continuous fun p : stripB => toK (4 + p.1.1, p.1.2) :=
    continuous_toK.comp (by fun_prop)
  show Continuous fun p : stripB =>
    if (0 : ℝ) ≤ p.1.1 then toK p.1 else toK (4 + p.1.1, p.1.2)
  refine continuous_if_le (f := fun _ : stripB => (0 : ℝ)) (g := fun p : stripB => p.1.1)
    continuous_const (continuous_fst.comp continuous_subtype_val)
    hc1.continuousOn hc2.continuousOn ?_
  rintro ⟨⟨x, y⟩, hxy⟩ hp
  obtain ⟨-, ⟨hy0, hy3⟩⟩ := mem_stripB_mk.mp hxy
  obtain rfl : x = 0 := hp.symm
  show toK (0, y) = toK (4 + 0, y)
  rw [add_zero]
  exact seamB_agree hy0 hy3

theorem seamB_injective : Injective seamB := by
  rintro ⟨⟨x, y⟩, hp⟩ ⟨⟨x', y'⟩, hq⟩ h
  obtain ⟨⟨hx0, hx1⟩, ⟨hy0, hy3⟩⟩ := mem_stripB_mk.mp hp
  obtain ⟨⟨hx0', hx1'⟩, ⟨hy0', hy3'⟩⟩ := mem_stripB_mk.mp hq
  apply Subtype.ext
  show (x, y) = (x', y')
  by_cases hx : (0 : ℝ) ≤ x <;> by_cases hx' : (0 : ℝ) ≤ x'
  · rw [seamB_of_nonneg ⟨(x, y), hp⟩ hx, seamB_of_nonneg ⟨(x', y'), hq⟩ hx'] at h
    have m1 : (x, y) ∈ rect := mem_rect_mk.mpr ⟨⟨hx, by linarith⟩, ⟨hy0.le, hy3.le⟩⟩
    have m2 : (x', y') ∈ rect := mem_rect_mk.mpr ⟨⟨hx', by linarith⟩, ⟨hy0'.le, hy3'.le⟩⟩
    have hn := (toK_eq_iff m1 m2).mp h
    rwa [nf_self_mk (x := x) (y := y)
        (fun hc => hc.2.elim (fun e => by linarith) (fun e => by linarith))
        (fun e => by linarith) (fun e => by linarith),
      nf_self_mk (x := x') (y := y')
        (fun hc => hc.2.elim (fun e => by linarith) (fun e => by linarith))
        (fun e => by linarith) (fun e => by linarith)] at hn
  · rw [seamB_of_nonneg ⟨(x, y), hp⟩ hx, seamB_of_neg ⟨(x', y'), hq⟩ hx'] at h
    have m1 : (x, y) ∈ rect := mem_rect_mk.mpr ⟨⟨hx, by linarith⟩, ⟨hy0.le, hy3.le⟩⟩
    have m2 : (4 + x', y') ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨hy0', hy3'⟩⟩
    have e := eq_of_nf_eq_openRect m2 ((toK_eq_iff m1 (openRect_subset_rect m2)).mp h)
    obtain ⟨e1, -⟩ := Prod.mk.inj e
    exfalso; linarith
  · rw [seamB_of_neg ⟨(x, y), hp⟩ hx, seamB_of_nonneg ⟨(x', y'), hq⟩ hx'] at h
    have m1 : (4 + x, y) ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨hy0, hy3⟩⟩
    have m2 : (x', y') ∈ rect := mem_rect_mk.mpr ⟨⟨hx', by linarith⟩, ⟨hy0'.le, hy3'.le⟩⟩
    have e := eq_of_nf_eq_openRect m1 ((toK_eq_iff m2 (openRect_subset_rect m1)).mp h.symm)
    obtain ⟨e1, -⟩ := Prod.mk.inj e
    exfalso; linarith
  · rw [seamB_of_neg ⟨(x, y), hp⟩ hx, seamB_of_neg ⟨(x', y'), hq⟩ hx'] at h
    have m1 : (4 + x, y) ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨hy0, hy3⟩⟩
    have m2 : (4 + x', y') ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨hy0', hy3'⟩⟩
    have e := eq_of_nf_eq_openRect m2
      ((toK_eq_iff (openRect_subset_rect m1) (openRect_subset_rect m2)).mp h)
    obtain ⟨e1, e2⟩ := Prod.mk.inj e
    rw [Prod.mk.injEq]
    constructor <;> linarith

theorem isOpenMap_seamB : IsOpenMap seamB := by
  intro V hV
  obtain ⟨O, hO, rfl⟩ := isOpen_induced_iff.mp hV
  have hW : IsOpen (stripB ∩ O) := isOpen_stripB.inter hO
  have hpre : (Quotient.mk kleinSetoid) ⁻¹' (seamB '' (Subtype.val ⁻¹' O)) =
      Subtype.val ⁻¹' ({p : ℝ × ℝ | p.1 < 1} ∩ (stripB ∩ O)) ∪
      Subtype.val ⁻¹' ({p : ℝ × ℝ | 3 < p.1} ∩
        (fun p : ℝ × ℝ => (p.1 - 4, p.2)) ⁻¹' (stripB ∩ O)) := by
    ext ⟨⟨a, b⟩, hr⟩
    obtain ⟨⟨ha0, ha4⟩, ⟨hb0, hb3⟩⟩ := mem_rect_mk.mp hr
    simp only [mem_preimage, mem_image, mem_union, mem_inter_iff, mem_ofPred_eq]
    constructor
    · rintro ⟨⟨⟨x, y⟩, hp⟩, hpO, hpr⟩
      obtain ⟨⟨hx0, hx1⟩, ⟨hy0, hy3⟩⟩ := mem_stripB_mk.mp hp
      rw [← toK_val] at hpr
      by_cases hx : (0 : ℝ) ≤ x
      · rw [seamB_of_nonneg ⟨(x, y), hp⟩ hx] at hpr
        have m1 : (x, y) ∈ rect := mem_rect_mk.mpr ⟨⟨hx, by linarith⟩, ⟨hy0.le, hy3.le⟩⟩
        have hn := (toK_eq_iff m1 hr).mp hpr
        rcases hx.eq_or_lt with hx' | hx'
        · subst hx'
          rw [nf_self_mk (x := 0) (y := y)
            (fun hc => hc.2.elim (fun e => by linarith) (fun e => by linarith))
            (by norm_num) (fun e => by linarith)] at hn
          rcases nf_eq_left hy0 hy3 hn.symm with e | e
          · obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
            exact Or.inl ⟨by norm_num, hp, hpO⟩
          · obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
            refine Or.inr ⟨by norm_num, ?_⟩
            rw [sub_self]
            exact ⟨hp, hpO⟩
        · have mi : (x, y) ∈ openRect :=
            mem_openRect_mk.mpr ⟨⟨hx', by linarith⟩, ⟨hy0, hy3⟩⟩
          have e := eq_of_nf_eq_openRect mi hn.symm
          obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
          exact Or.inl ⟨hx1, hp, hpO⟩
      · rw [seamB_of_neg ⟨(x, y), hp⟩ hx] at hpr
        have mi : (4 + x, y) ∈ openRect :=
          mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨hy0, hy3⟩⟩
        have e := eq_of_nf_eq_openRect mi ((toK_eq_iff (openRect_subset_rect mi) hr).mp hpr).symm
        obtain ⟨rfl, rfl⟩ := Prod.mk.inj e
        refine Or.inr ⟨by linarith, ?_⟩
        rw [add_sub_cancel_left]
        exact ⟨hp, hpO⟩
    · rintro (⟨-, hmB, hmO⟩ | ⟨ha3, hmB, hmO⟩)
      · refine ⟨⟨(a, b), hmB⟩, hmO, ?_⟩
        rw [seamB_of_nonneg ⟨(a, b), hmB⟩ ha0]
        exact toK_val ⟨(a, b), hr⟩
      · refine ⟨⟨(a - 4, b), hmB⟩, hmO, ?_⟩
        obtain ⟨-, ⟨hy0, hy3⟩⟩ := mem_stripB_mk.mp hmB
        rw [← toK_val]
        by_cases ha : (0 : ℝ) ≤ a - 4
        · rw [seamB_of_nonneg ⟨(a - 4, b), hmB⟩ ha]
          have ha4' : a = 4 := by linarith
          subst ha4'
          show toK (4 - 4, b) = toK (4, b)
          rw [sub_self]
          exact seamB_agree hy0 hy3
        · rw [seamB_of_neg ⟨(a - 4, b), hmB⟩ ha]
          show toK (4 + (a - 4), b) = toK (a, b)
          congr 1
          rw [Prod.mk.injEq]
          constructor <;> ring
  rw [isOpen_iff_mk, hpre]
  refine IsOpen.union ?_ ?_
  · exact ((isOpen_lt continuous_fst continuous_const).inter hW).preimage continuous_subtype_val
  · exact ((isOpen_lt continuous_const continuous_fst).inter
      (hW.preimage (by fun_prop))).preimage continuous_subtype_val

theorem isOpenEmbedding_seamB : IsOpenEmbedding seamB :=
  IsOpenEmbedding.of_continuous_injective_isOpenMap continuous_seamB seamB_injective
    isOpenMap_seamB


/-! ## Characteristic maps of the canonical cell structure -/

noncomputable def cellA (s : ℝ) : KleinBottle := toK (4 * s, 0)
noncomputable def cellB (s : ℝ) : KleinBottle := toK (0, 3 * s)
noncomputable def cellF (p : ℝ × ℝ) : KleinBottle := toK (4 * p.1, 3 * p.2)

noncomputable def c1fun (k : Fin 2) : ℝ → KleinBottle := if k = 0 then cellA else cellB

theorem c1fun_zero : c1fun 0 = cellA := ite_eq_left rfl
theorem c1fun_one : c1fun 1 = cellB := ite_eq_right (by decide)

theorem fin2_cases : ∀ k : Fin 2, k = 0 ∨ k = 1 := by decide
theorem fin1_eq : ∀ k : Fin 1, k = 0 := by decide

theorem continuous_cellA : Continuous cellA := by
  unfold cellA; exact continuous_toK.comp (by fun_prop)
theorem continuous_cellB : Continuous cellB := by
  unfold cellB; exact continuous_toK.comp (by fun_prop)
theorem continuous_cellF : Continuous cellF := by
  unfold cellF; exact continuous_toK.comp (by fun_prop)

/-- Open 1-cell `a` sits in the seam chart `seamA`. -/
noncomputable def ιA (s : Ioo (0 : ℝ) 1) : stripA :=
  ⟨(4 * s.1, 0), mem_stripA_mk.mpr ⟨⟨by linarith [s.2.1], by linarith [s.2.2]⟩,
    ⟨by norm_num, by norm_num⟩⟩⟩

noncomputable def rA (p : stripA) : Ioo (0 : ℝ) 1 :=
  ⟨p.1.1 / 4, div_pos p.2.1.1 (by norm_num), (div_lt_one (by norm_num)).mpr p.2.1.2⟩

theorem isEmbedding_ιA : IsEmbedding ιA := by
  refine IsEmbedding.of_leftInverse (f := rA) (g := ιA) ?_ ?_ ?_
  · intro s
    apply Subtype.ext
    show 4 * s.1 / 4 = s.1
    ring
  · apply continuous_induced_rng.mpr
    show Continuous fun p : stripA => p.1.1 / 4
    fun_prop
  · apply continuous_induced_rng.mpr
    show Continuous fun s : Ioo (0 : ℝ) 1 => (4 * s.1, (0 : ℝ))
    fun_prop

noncomputable def ιB (s : Ioo (0 : ℝ) 1) : stripB :=
  ⟨(0, 3 * s.1), mem_stripB_mk.mpr ⟨⟨by norm_num, by norm_num⟩,
    ⟨by linarith [s.2.1], by linarith [s.2.2]⟩⟩⟩

noncomputable def rB (p : stripB) : Ioo (0 : ℝ) 1 :=
  ⟨p.1.2 / 3, div_pos p.2.2.1 (by norm_num), (div_lt_one (by norm_num)).mpr p.2.2.2⟩

theorem isEmbedding_ιB : IsEmbedding ιB := by
  refine IsEmbedding.of_leftInverse (f := rB) (g := ιB) ?_ ?_ ?_
  · intro s
    apply Subtype.ext
    show 3 * s.1 / 3 = s.1
    ring
  · apply continuous_induced_rng.mpr
    show Continuous fun p : stripB => p.1.2 / 3
    fun_prop
  · apply continuous_induced_rng.mpr
    show Continuous fun s : Ioo (0 : ℝ) 1 => ((0 : ℝ), 3 * s.1)
    fun_prop

noncomputable def ιF (p : (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1 : Set (ℝ × ℝ))) : openRect :=
  ⟨(4 * p.1.1, 3 * p.1.2), mem_openRect_mk.mpr ⟨⟨by linarith [p.2.1.1], by linarith [p.2.1.2]⟩,
    ⟨by linarith [p.2.2.1], by linarith [p.2.2.2]⟩⟩⟩

noncomputable def rF (q : openRect) : (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1 : Set (ℝ × ℝ)) :=
  ⟨(q.1.1 / 4, q.1.2 / 3),
    ⟨⟨div_pos q.2.1.1 (by norm_num), (div_lt_one (by norm_num)).mpr q.2.1.2⟩,
     ⟨div_pos q.2.2.1 (by norm_num), (div_lt_one (by norm_num)).mpr q.2.2.2⟩⟩⟩

theorem isEmbedding_ιF : IsEmbedding ιF := by
  refine IsEmbedding.of_leftInverse (f := rF) (g := ιF) ?_ ?_ ?_
  · intro p
    apply Subtype.ext
    show (4 * p.1.1 / 4, 3 * p.1.2 / 3) = p.1
    rw [Prod.mk.injEq]
    constructor <;> ring
  · apply continuous_induced_rng.mpr
    show Continuous fun q : openRect => (q.1.1 / 4, q.1.2 / 3)
    fun_prop
  · apply continuous_induced_rng.mpr
    show Continuous fun p : (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1 : Set (ℝ × ℝ)) =>
      (4 * p.1.1, 3 * p.1.2)
    fun_prop

theorem embA : IsEmbedding ((Ioo (0 : ℝ) 1).domRestrict (c1fun 0)) := by
  have key : (Ioo (0 : ℝ) 1).domRestrict (c1fun 0) = seamA ∘ ιA := by
    funext s
    rw [c1fun_zero]
    exact ((seamA_of_nonneg (ιA s) (le_refl 0)).trans rfl).symm
  rw [key]
  exact isOpenEmbedding_seamA.isEmbedding.comp isEmbedding_ιA

theorem embB : IsEmbedding ((Ioo (0 : ℝ) 1).domRestrict (c1fun 1)) := by
  have key : (Ioo (0 : ℝ) 1).domRestrict (c1fun 1) = seamB ∘ ιB := by
    funext s
    rw [c1fun_one]
    exact ((seamB_of_nonneg (ιB s) (le_refl 0)).trans rfl).symm
  rw [key]
  exact isOpenEmbedding_seamB.isEmbedding.comp isEmbedding_ιB

theorem embF : IsEmbedding ((Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1).domRestrict cellF) := by
  have key : (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1).domRestrict cellF = interiorChart ∘ ιF := rfl
  rw [key]
  exact isOpenEmbedding_interiorChart.isEmbedding.comp isEmbedding_ιF

theorem bdA0 : cellA 0 = toK (0, 0) := by unfold cellA; rw [mul_zero]
theorem bdA1 : cellA 1 = toK (0, 0) := by unfold cellA; rw [mul_one]; exact toK_corner40
theorem bdB0 : cellB 0 = toK (0, 0) := by unfold cellB; rw [mul_zero]
theorem bdB1 : cellB 1 = toK (0, 0) := by unfold cellB; rw [mul_one]; exact toK_corner03

theorem cellF_bd (p : ℝ × ℝ)
    (hp : p ∈ (Icc (0 : ℝ) 1 ×ˢ Icc (0 : ℝ) 1) \ (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1)) :
    cellF p ∈ range (fun _ : Fin 1 => toK (0, 0)) ∪ ⋃ j, c1fun j '' Ioo 0 1 := by
  obtain ⟨⟨⟨h1, h2⟩, ⟨h3, h4⟩⟩, hn⟩ := hp
  have hq : (4 * p.1, 3 * p.2) ∈ rect :=
    mem_rect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
  have e0 : cellF p = toK (nf (4 * p.1, 3 * p.2)) := (toK_nf hq).symm
  rcases nf_classify hq with h | ⟨y, hy0, hy3, h⟩ | ⟨x, hx0, hx4, h⟩ | ⟨hi, -⟩
  · left
    exact ⟨0, by rw [e0, h]⟩
  · right
    refine mem_iUnion.mpr ⟨1, y / 3, ⟨div_pos hy0 (by norm_num), by linarith⟩, ?_⟩
    rw [c1fun_one, e0, h]
    unfold cellB
    congr 1
    rw [Prod.mk.injEq]
    exact ⟨rfl, by ring⟩
  · right
    refine mem_iUnion.mpr ⟨0, x / 4, ⟨div_pos hx0 (by norm_num), by linarith⟩, ?_⟩
    rw [c1fun_zero, e0, h]
    unfold cellA
    congr 1
    rw [Prod.mk.injEq]
    exact ⟨by ring, rfl⟩
  · exfalso
    apply hn
    obtain ⟨⟨a1, a2⟩, ⟨a3, a4⟩⟩ := mem_openRect_mk.mp hi
    exact ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩

/-! ## Partition into open cells -/

noncomputable def shapeIdx (q : ℝ × ℝ) : Fin 1 ⊕ (Fin 2 ⊕ Fin 1) :=
  if q.1 = 0 ∧ q.2 = 0 then Sum.inl 0
  else if q.2 = 0 then Sum.inr (Sum.inl 0)
  else if q.1 = 0 then Sum.inr (Sum.inl 1)
  else Sum.inr (Sum.inr 0)

def cellMem (x : KleinBottle) : Fin 1 ⊕ (Fin 2 ⊕ Fin 1) → Prop :=
  Sum.elim (fun _ => x = toK (0, 0))
    (Sum.elim (fun k => x ∈ c1fun k '' Ioo 0 1)
      (fun _ => x ∈ cellF '' (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1)))

theorem cell_rep {x : KleinBottle} {i : Fin 1 ⊕ (Fin 2 ⊕ Fin 1)} (h : cellMem x i) :
    ∃ q : ℝ × ℝ, q ∈ rect ∧ x = toK q ∧ nf q = q ∧ shapeIdx q = i := by
  rcases i with k | k | k
  · have hx : x = toK (0, 0) := h
    refine ⟨(0, 0), mem_rect_mk.mpr ⟨⟨le_refl 0, by norm_num⟩, ⟨le_refl 0, by norm_num⟩⟩, hx,
      nf_corner_mk ⟨Or.inl rfl, Or.inl rfl⟩, ?_⟩
    rw [fin1_eq k]
    dsimp only [shapeIdx]
    exact ite_eq_left ⟨rfl, rfl⟩
  · have hx : x ∈ c1fun k '' Ioo 0 1 := h
    rcases fin2_cases k with rfl | rfl
    · rw [c1fun_zero] at hx
      obtain ⟨s, ⟨hs0, hs1⟩, rfl⟩ := hx
      refine ⟨(4 * s, 0), mem_rect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨le_refl 0, by norm_num⟩⟩,
        rfl, nf_self_mk (fun hc => hc.1.elim (fun e => by linarith) (fun e => by linarith))
          (fun e => by linarith) (by norm_num), ?_⟩
      dsimp only [shapeIdx]
      rw [ite_eq_right (fun hc => by linarith [hc.1]), ite_eq_left rfl]
    · rw [c1fun_one] at hx
      obtain ⟨s, ⟨hs0, hs1⟩, rfl⟩ := hx
      refine ⟨(0, 3 * s), mem_rect_mk.mpr ⟨⟨le_refl 0, by norm_num⟩, ⟨by linarith, by linarith⟩⟩,
        rfl, nf_self_mk (fun hc => hc.2.elim (fun e => by linarith) (fun e => by linarith))
          (by norm_num) (fun e => by linarith), ?_⟩
      dsimp only [shapeIdx]
      rw [ite_eq_right (fun hc => by linarith [hc.2]), ite_eq_right (fun hc => by linarith),
        ite_eq_left rfl]
  · have hx : x ∈ cellF '' (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1) := h
    obtain ⟨p, ⟨⟨a0, a1⟩, ⟨b0, b1⟩⟩, rfl⟩ := hx
    have hi : (4 * p.1, 3 * p.2) ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
    refine ⟨(4 * p.1, 3 * p.2), openRect_subset_rect hi, rfl, nf_of_openRect hi, ?_⟩
    dsimp only [shapeIdx]
    rw [ite_eq_right (fun hc => by linarith [hc.1]), ite_eq_right (fun hc => by linarith),
      ite_eq_right (fun hc => by linarith), fin1_eq k]

theorem cell_unique {x : KleinBottle} {i i' : Fin 1 ⊕ (Fin 2 ⊕ Fin 1)} (h : cellMem x i)
    (h' : cellMem x i') : i' = i := by
  obtain ⟨q, hq, hx, hnq, hi⟩ := cell_rep h
  obtain ⟨q', hq', hx', hnq', hi'⟩ := cell_rep h'
  have e : nf q' = nf q := (toK_eq_iff hq' hq).mp (hx'.symm.trans hx)
  rw [hnq, hnq'] at e
  rw [← hi, ← hi', e]

theorem cell_exists (x : KleinBottle) : ∃ i, cellMem x i := by
  induction x using Quotient.inductionOn with
  | h r =>
    have hq := r.2
    rw [← toK_val r]
    rcases nf_classify hq with h | ⟨y, hy0, hy3, h⟩ | ⟨x, hx0, hx4, h⟩ | ⟨hi, -⟩
    · refine ⟨Sum.inl 0, ?_⟩
      show toK r.1 = toK (0, 0)
      rw [← toK_nf hq, h]
    · refine ⟨Sum.inr (Sum.inl 1), ?_⟩
      show toK r.1 ∈ c1fun 1 '' Ioo 0 1
      refine ⟨y / 3, ⟨div_pos hy0 (by norm_num), by linarith⟩, ?_⟩
      rw [c1fun_one, ← toK_nf hq, h]
      unfold cellB
      congr 1
      rw [Prod.mk.injEq]
      exact ⟨rfl, by ring⟩
    · refine ⟨Sum.inr (Sum.inl 0), ?_⟩
      show toK r.1 ∈ c1fun 0 '' Ioo 0 1
      refine ⟨x / 4, ⟨div_pos hx0 (by norm_num), by linarith⟩, ?_⟩
      rw [c1fun_zero, ← toK_nf hq, h]
      unfold cellA
      congr 1
      rw [Prod.mk.injEq]
      exact ⟨by ring, rfl⟩
    · refine ⟨Sum.inr (Sum.inr 0), ?_⟩
      show toK r.1 ∈ cellF '' (Ioo (0 : ℝ) 1 ×ˢ Ioo (0 : ℝ) 1)
      obtain ⟨⟨a0, a1⟩, ⟨b0, b1⟩⟩ := mem_openRect_iff.mp hi
      refine ⟨(r.1.1 / 4, r.1.2 / 3), ⟨⟨by positivity, by linarith⟩, ⟨by positivity, by linarith⟩⟩, ?_⟩
      unfold cellF
      congr 1
      show (4 * (r.1.1 / 4), 3 * (r.1.2 / 3)) = (r.1.1, r.1.2)
      rw [Prod.mk.injEq]
      constructor <;> ring

/-- **The canonical cell structure of the Klein bottle**: one vertex, two edges, one face. -/
noncomputable def kleinCells : CellStructure2 KleinBottle where
  n0 := 1
  n1 := 2
  n2 := 1
  c0 := fun _ => toK (0, 0)
  c1 := c1fun
  c2 := fun _ => cellF
  c1_cont k := by
    rcases fin2_cases k with rfl | rfl
    · rw [c1fun_zero]; exact continuous_cellA.continuousOn
    · rw [c1fun_one]; exact continuous_cellB.continuousOn
  c2_cont _ := continuous_cellF.continuousOn
  c1_emb k := by
    rcases fin2_cases k with rfl | rfl
    · exact embA
    · exact embB
  c2_emb _ := embF
  c1_bd k := by
    rcases fin2_cases k with rfl | rfl
    · rw [c1fun_zero]; exact ⟨⟨0, bdA0.symm⟩, ⟨0, bdA1.symm⟩⟩
    · rw [c1fun_one]; exact ⟨⟨0, bdB0.symm⟩, ⟨0, bdB1.symm⟩⟩
  c2_bd _ p hp := cellF_bd p hp
  partition x := by
    obtain ⟨i, hi⟩ := cell_exists x
    exact ⟨i, hi, fun i' hi' => cell_unique hi hi'⟩

theorem kleinCells_euler : kleinCells.euler = 0 := by
  show ((1 : ℕ) : ℤ) - ((2 : ℕ) : ℤ) + ((1 : ℕ) : ℤ) = 0
  norm_num

end Klein366521
