import KleinSurface
import KleinGraph
import Mathlib.Tactic.IntervalCases

/-!
# The drawing of `G` on the Klein bottle

Vertices at the lattice points `(x,y)`, `0 ≤ x ≤ 3`, `0 ≤ y ≤ 2`.  The 48 edges are the
affine unit sides and unit diagonals of the twelve squares `[i,i+1] × [j,j+1]` of the
rectangle, each drawn once.  Open edge points have trivial normal form, so all
coincidences in the quotient are planar coincidences.
-/

open Set Function Topology

namespace Klein366521

/-! ## Vertices -/

def vx (v : Fin 12) : ℕ := v.val % 4
def vy (v : Fin 12) : ℕ := v.val / 4

/-- Position of a vertex. -/
noncomputable def pt (v : Fin 12) : KleinBottle := toK ((vx v : ℝ), (vy v : ℝ))

theorem vx_le (v : Fin 12) : vx v ≤ 3 := by unfold vx; omega
theorem vy_le (v : Fin 12) : vy v ≤ 2 := by have := v.isLt; unfold vy; omega

theorem lattice_mem {a b : ℕ} (ha : a ≤ 4) (hb : b ≤ 3) : ((a : ℝ), (b : ℝ)) ∈ rect :=
  mem_rect_mk.mpr ⟨⟨Nat.cast_nonneg _, by exact_mod_cast ha⟩, ⟨Nat.cast_nonneg _, by exact_mod_cast hb⟩⟩

theorem pt_mem (v : Fin 12) : ((vx v : ℝ), (vy v : ℝ)) ∈ rect :=
  lattice_mem (by have := vx_le v; omega) (by have := vy_le v; omega)

theorem nf_pt (v : Fin 12) : nf ((vx v : ℝ), (vy v : ℝ)) = ((vx v : ℝ), (vy v : ℝ)) := by
  fin_cases v <;> norm_num [vx, vy, nf]

theorem pt_injective : Injective pt := by
  intro u v h
  have h' := (toK_eq_iff (pt_mem u) (pt_mem v)).mp h
  rw [nf_pt, nf_pt] at h'
  obtain ⟨h1, h2⟩ := Prod.mk.inj h'
  have e1 : vx u = vx v := by exact_mod_cast h1
  have e2 : vy u = vy v := by exact_mod_cast h2
  unfold vx at e1
  unfold vy at e2
  apply Fin.ext
  have hu := Nat.div_add_mod u.val 4
  have hv := Nat.div_add_mod v.val 4
  omega

/-! ## Lattice labels -/

def labN (a b : ℕ) : ℕ := if b = 3 then (4 - a) % 4 else a % 4 + 4 * b

/-- The vertex at the lattice point `(a,b)` of the rectangle (`a ≤ 4`, `b ≤ 3`). -/
def lab (a b : ℕ) : Fin 12 := ⟨labN a b % 12, Nat.mod_lt _ (by norm_num)⟩

theorem toK_lattice (a b : ℕ) (ha : a ≤ 4) (hb : b ≤ 3) :
    toK ((a : ℝ), (b : ℝ)) = pt (lab a b) := by
  unfold pt
  rw [toK_eq_iff (lattice_mem ha hb) (pt_mem _)]
  interval_cases a <;> interval_cases b <;> norm_num [lab, labN, vx, vy, nf]

/-! ## Edges -/

inductive Kind
  | H
  | V
  | Dp
  | Dm
  deriving DecidableEq

instance : Fintype Kind where
  elems := {Kind.H, Kind.V, Kind.Dp, Kind.Dm}
  complete := fun x => by cases x <;> decide

/-- Edge index: square `(i,j)` and kind. -/
abbrev EIx := Fin 4 × Fin 3 × Kind

/-- Affine parametrisation of the representative segment. -/
noncomputable def segPt : EIx → ℝ → ℝ × ℝ
  | (i, j, .H), t => (((i : ℕ) : ℝ) + t, ((j : ℕ) : ℝ))
  | (i, j, .V), t => (((i : ℕ) : ℝ), ((j : ℕ) : ℝ) + t)
  | (i, j, .Dp), t => (((i : ℕ) : ℝ) + t, ((j : ℕ) : ℝ) + t)
  | (i, j, .Dm), t => (((i : ℕ) : ℝ) + 1 - t, ((j : ℕ) : ℝ) + t)

def startN : EIx → ℕ × ℕ
  | (i, j, .H) => ((i : ℕ), (j : ℕ))
  | (i, j, .V) => ((i : ℕ), (j : ℕ))
  | (i, j, .Dp) => ((i : ℕ), (j : ℕ))
  | (i, j, .Dm) => ((i : ℕ) + 1, (j : ℕ))

def endN : EIx → ℕ × ℕ
  | (i, j, .H) => ((i : ℕ) + 1, (j : ℕ))
  | (i, j, .V) => ((i : ℕ), (j : ℕ) + 1)
  | (i, j, .Dp) => ((i : ℕ) + 1, (j : ℕ) + 1)
  | (i, j, .Dm) => ((i : ℕ), (j : ℕ) + 1)

def src (k : EIx) : Fin 12 := lab (startN k).1 (startN k).2
def dst (k : EIx) : Fin 12 := lab (endN k).1 (endN k).2

theorem bounds_aux : ∀ k : EIx, (startN k).1 ≤ 4 ∧ (startN k).2 ≤ 3 ∧
    (endN k).1 ≤ 4 ∧ (endN k).2 ≤ 3 := by decide

theorem src_ne_dst : ∀ k : EIx, src k ≠ dst k := by decide +kernel

theorem adj_src_dst : ∀ k : EIx, adjB (src k) (dst k) = true := by decide +kernel

theorem adj_has_ix : ∀ u v : Fin 12, adjB u v = true → ∃ i : Fin 4, ∃ j : Fin 3, ∃ κ : Kind,
    (src (i, j, κ) = u ∧ dst (i, j, κ) = v) ∨ (src (i, j, κ) = v ∧ dst (i, j, κ) = u) := by
  decide +kernel

theorem cross_disjoint : ∀ (i : Fin 4) (j : Fin 3) (w : Fin 12),
    (w = src (i, j, .Dp) ∨ w = dst (i, j, .Dp)) →
    (w = src (i, j, .Dm) ∨ w = dst (i, j, .Dm)) → False := by
  decide +kernel

theorem segPt_zero (k : EIx) : segPt k 0 = (((startN k).1 : ℝ), ((startN k).2 : ℝ)) := by
  rcases k with ⟨i, j, κ⟩
  cases κ <;> simp [segPt, startN]

theorem segPt_one (k : EIx) : segPt k 1 = (((endN k).1 : ℝ), ((endN k).2 : ℝ)) := by
  rcases k with ⟨i, j, κ⟩
  cases κ <;> simp [segPt, endN]

theorem continuous_segPt (k : EIx) : Continuous (segPt k) := by
  rcases k with ⟨i, j, κ⟩
  cases κ
  · show Continuous fun t : ℝ => (((i : ℕ) : ℝ) + t, ((j : ℕ) : ℝ))
    fun_prop
  · show Continuous fun t : ℝ => (((i : ℕ) : ℝ), ((j : ℕ) : ℝ) + t)
    fun_prop
  · show Continuous fun t : ℝ => (((i : ℕ) : ℝ) + t, ((j : ℕ) : ℝ) + t)
    fun_prop
  · show Continuous fun t : ℝ => (((i : ℕ) : ℝ) + 1 - t, ((j : ℕ) : ℝ) + t)
    fun_prop

/-- The edge arc of index `k`. -/
noncomputable def segArc (k : EIx) : C(unitInterval, KleinBottle) :=
  ⟨fun t => toK (segPt k t), continuous_toK.comp ((continuous_segPt k).comp continuous_subtype_val)⟩

theorem segArc_apply (k : EIx) (t : unitInterval) : segArc k t = toK (segPt k t) := rfl

theorem segArc_zero (k : EIx) : segArc k 0 = pt (src k) := by
  show toK (segPt k 0) = pt (src k)
  rw [segPt_zero]
  exact toK_lattice _ _ (bounds_aux k).1 (bounds_aux k).2.1

theorem segArc_one (k : EIx) : segArc k 1 = pt (dst k) := by
  show toK (segPt k 1) = pt (dst k)
  rw [segPt_one]
  exact toK_lattice _ _ (bounds_aux k).2.2.1 (bounds_aux k).2.2.2

/-! ## Planar facts about open segment points -/

theorem not_nat_frac {a b : ℕ} {t : ℝ} (ht0 : 0 < t) (ht1 : t < 1) (h : (a : ℝ) = b + t) :
    False := by
  rcases lt_trichotomy a b with hab | rfl | hab
  · have : (a : ℝ) + 1 ≤ b := by exact_mod_cast (show a + 1 ≤ b by omega)
    linarith
  · linarith
  · have : (b : ℝ) + 1 ≤ a := by exact_mod_cast (show b + 1 ≤ a by omega)
    linarith

theorem nat_eq_of_close {a b : ℕ} {s t : ℝ} (hs0 : 0 < s) (hs1 : s < 1) (ht0 : 0 < t)
    (ht1 : t < 1) (h : (a : ℝ) + s = b + t) : a = b := by
  rcases lt_trichotomy a b with hab | hab | hab
  · have : (a : ℝ) + 1 ≤ b := by exact_mod_cast (show a + 1 ≤ b by omega)
    linarith
  · exact hab
  · have : (b : ℝ) + 1 ≤ a := by exact_mod_cast (show b + 1 ≤ a by omega)
    linarith

theorem nat_eq_of_twice {a b : ℕ} {s : ℝ} (hs0 : 0 < s) (hs1 : s < 1)
    (h : (a : ℝ) + 2 * s = b + 1) : a = b := by
  rcases lt_trichotomy a b with hab | hab | hab
  · have : (a : ℝ) + 1 ≤ b := by exact_mod_cast (show a + 1 ≤ b by omega)
    linarith
  · exact hab
  · have : (b : ℝ) + 1 ≤ a := by exact_mod_cast (show b + 1 ≤ a by omega)
    linarith

theorem fin4_le (i : Fin 4) : ((i : ℕ) : ℝ) ≤ 3 := by
  exact_mod_cast (show (i : ℕ) ≤ 3 by have := i.isLt; omega)

theorem fin3_le (j : Fin 3) : ((j : ℕ) : ℝ) ≤ 2 := by
  exact_mod_cast (show (j : ℕ) ≤ 2 by have := j.isLt; omega)

/-- Open segment points lie in the rectangle and are their own normal form. -/
theorem segPt_open {k : EIx} {s : ℝ} (hs0 : 0 < s) (hs1 : s < 1) :
    segPt k s ∈ rect ∧ nf (segPt k s) = segPt k s := by
  rcases k with ⟨i, j, κ⟩
  have hi := fin4_le i
  have hj := fin3_le j
  have hi0 : (0 : ℝ) ≤ ((i : ℕ) : ℝ) := Nat.cast_nonneg _
  have hj0 : (0 : ℝ) ≤ ((j : ℕ) : ℝ) := Nat.cast_nonneg _
  cases κ
  · show (((i : ℕ) : ℝ) + s, ((j : ℕ) : ℝ)) ∈ rect ∧
      nf (((i : ℕ) : ℝ) + s, ((j : ℕ) : ℝ)) = (((i : ℕ) : ℝ) + s, ((j : ℕ) : ℝ))
    refine ⟨mem_rect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨hj0, by linarith⟩⟩, ?_⟩
    exact nf_self_mk (fun hc => hc.1.elim (fun e => by linarith) (fun e => by linarith))
      (fun e => by linarith) (fun e => by linarith)
  · show (((i : ℕ) : ℝ), ((j : ℕ) : ℝ) + s) ∈ rect ∧
      nf (((i : ℕ) : ℝ), ((j : ℕ) : ℝ) + s) = (((i : ℕ) : ℝ), ((j : ℕ) : ℝ) + s)
    refine ⟨mem_rect_mk.mpr ⟨⟨hi0, by linarith⟩, ⟨by linarith, by linarith⟩⟩, ?_⟩
    exact nf_self_mk (fun hc => hc.2.elim (fun e => by linarith) (fun e => by linarith))
      (fun e => by linarith) (fun e => by linarith)
  · have hm : (((i : ℕ) : ℝ) + s, ((j : ℕ) : ℝ) + s) ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
    exact ⟨openRect_subset_rect hm, nf_of_openRect hm⟩
  · have hm : (((i : ℕ) : ℝ) + 1 - s, ((j : ℕ) : ℝ) + s) ∈ openRect :=
      mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩
    exact ⟨openRect_subset_rect hm, nf_of_openRect hm⟩

/-- Open segment points are not lattice points. -/
theorem segPt_not_lattice {k : EIx} {s : ℝ} (hs0 : 0 < s) (hs1 : s < 1) (a b : ℕ) :
    segPt k s ≠ ((a : ℝ), (b : ℝ)) := by
  rcases k with ⟨i, j, κ⟩
  intro h
  cases κ <;> simp only [segPt, Prod.mk.injEq] at h <;> obtain ⟨h1, h2⟩ := h
  · exact not_nat_frac hs0 hs1 h1.symm
  · exact not_nat_frac hs0 hs1 h2.symm
  · exact not_nat_frac hs0 hs1 h1.symm
  · exact not_nat_frac (a := (i : ℕ) + 1) (b := a) hs0 hs1 (by push_cast; linarith)

/-- Two diagonals of the same square, in either order. -/
def IsCrossPair (k l : EIx) : Prop :=
  k.1 = l.1 ∧ k.2.1 = l.2.1 ∧
    ((k.2.2 = .Dp ∧ l.2.2 = .Dm) ∨ (k.2.2 = .Dm ∧ l.2.2 = .Dp))

/-- **Planar intersection classification** of open representative segments. -/
theorem seg_meet {k l : EIx} {s t : ℝ} (hs0 : 0 < s) (hs1 : s < 1) (ht0 : 0 < t) (ht1 : t < 1)
    (h : segPt k s = segPt l t) :
    (k = l ∧ s = t) ∨ (IsCrossPair k l ∧ s = 1 / 2 ∧ t = 1 / 2) := by
  rcases k with ⟨i, j, κ⟩
  rcases l with ⟨i', j', κ'⟩
  cases κ <;> cases κ' <;> simp only [segPt, Prod.mk.injEq] at h <;> obtain ⟨h1, h2⟩ := h
  -- H H
  · have hi := nat_eq_of_close hs0 hs1 ht0 ht1 h1
    have hj : (j : ℕ) = j' := by exact_mod_cast h2
    have hi' : ((i : ℕ) : ℝ) = ((i' : ℕ) : ℝ) := by rw [hi]
    exact Or.inl ⟨Prod.ext (Fin.ext hi) (Prod.ext (Fin.ext hj) rfl), by linarith⟩
  · exact (not_nat_frac ht0 ht1 h2).elim
  · exact (not_nat_frac ht0 ht1 h2).elim
  · exact (not_nat_frac ht0 ht1 h2).elim
  -- V _
  · exact (not_nat_frac ht0 ht1 h1).elim
  · have hj := nat_eq_of_close hs0 hs1 ht0 ht1 h2
    have hi : (i : ℕ) = i' := by exact_mod_cast h1
    have hj' : ((j : ℕ) : ℝ) = ((j' : ℕ) : ℝ) := by rw [hj]
    exact Or.inl ⟨Prod.ext (Fin.ext hi) (Prod.ext (Fin.ext hj) rfl), by linarith⟩
  · exact (not_nat_frac ht0 ht1 h1).elim
  · exact (not_nat_frac (a := (i' : ℕ) + 1) (b := i) ht0 ht1 (by push_cast; linarith)).elim
  -- Dp _
  · exact (not_nat_frac hs0 hs1 h2.symm).elim
  · exact (not_nat_frac hs0 hs1 h1.symm).elim
  · have hi := nat_eq_of_close hs0 hs1 ht0 ht1 h1
    have hj := nat_eq_of_close hs0 hs1 ht0 ht1 h2
    have hi' : ((i : ℕ) : ℝ) = ((i' : ℕ) : ℝ) := by rw [hi]
    exact Or.inl ⟨Prod.ext (Fin.ext hi) (Prod.ext (Fin.ext hj) rfl), by linarith⟩
  · have hj := nat_eq_of_close hs0 hs1 ht0 ht1 h2
    have hj' : ((j : ℕ) : ℝ) = ((j' : ℕ) : ℝ) := by rw [hj]
    have hst : s = t := by linarith
    have hi := nat_eq_of_twice hs0 hs1 (show ((i : ℕ) : ℝ) + 2 * s = ((i' : ℕ) : ℝ) + 1 by linarith)
    have hi' : ((i : ℕ) : ℝ) = ((i' : ℕ) : ℝ) := by rw [hi]
    refine Or.inr ⟨⟨Fin.ext hi, Fin.ext hj, Or.inl ⟨rfl, rfl⟩⟩, by linarith, by linarith⟩
  -- Dm _
  · exact (not_nat_frac hs0 hs1 h2.symm).elim
  · exact (not_nat_frac (a := (i : ℕ) + 1) (b := i') hs0 hs1 (by push_cast; linarith)).elim
  · have hj := nat_eq_of_close hs0 hs1 ht0 ht1 h2
    have hj' : ((j : ℕ) : ℝ) = ((j' : ℕ) : ℝ) := by rw [hj]
    have hst : s = t := by linarith
    have hi := nat_eq_of_twice hs0 hs1 (show ((i' : ℕ) : ℝ) + 2 * s = ((i : ℕ) : ℝ) + 1 by linarith)
    have hi' : ((i : ℕ) : ℝ) = ((i' : ℕ) : ℝ) := by rw [hi]
    refine Or.inr ⟨⟨Fin.ext hi.symm, Fin.ext hj, Or.inr ⟨rfl, rfl⟩⟩, by linarith, by linarith⟩
  · have hj := nat_eq_of_close hs0 hs1 ht0 ht1 h2
    have hj' : ((j : ℕ) : ℝ) = ((j' : ℕ) : ℝ) := by rw [hj]
    have hst : s = t := by linarith
    have hi : (i : ℕ) = i' := by exact_mod_cast (show ((i : ℕ) : ℝ) = ((i' : ℕ) : ℝ) by linarith)
    exact Or.inl ⟨Prod.ext (Fin.ext hi) (Prod.ext (Fin.ext hj) rfl), hst⟩


/-! ## Arcs in the quotient -/

theorem unit_cases (s : unitInterval) : (s : ℝ) = 0 ∨ (s : ℝ) = 1 ∨ s ∈ openUnit := by
  rcases s.2.1.eq_or_lt with h | h
  · exact Or.inl h.symm
  · rcases s.2.2.eq_or_lt with h' | h'
    · exact Or.inr (Or.inl h')
    · exact Or.inr (Or.inr ⟨h, h'⟩)

theorem segArc_at_zero (k : EIx) {t : unitInterval} (ht : (t : ℝ) = 0) :
    segArc k t = pt (src k) := by
  have : t = 0 := Subtype.ext ht
  rw [this]
  exact segArc_zero k

theorem segArc_at_one (k : EIx) {t : unitInterval} (ht : (t : ℝ) = 1) :
    segArc k t = pt (dst k) := by
  have : t = 1 := Subtype.ext ht
  rw [this]
  exact segArc_one k

theorem toK_open_eq {k l : EIx} {s t : unitInterval} (hs : s ∈ openUnit) (ht : t ∈ openUnit)
    (h : segArc k s = segArc l t) : segPt k s = segPt l t := by
  have h1 := segPt_open (k := k) hs.1 hs.2
  have h2 := segPt_open (k := l) ht.1 ht.2
  have h' := (toK_eq_iff h1.1 h2.1).mp h
  rwa [h1.2, h2.2] at h'

/-- Intersection classification in the Klein bottle. -/
theorem arc_meet {k l : EIx} {s t : unitInterval} (hs : s ∈ openUnit) (ht : t ∈ openUnit)
    (h : segArc k s = segArc l t) :
    (k = l ∧ (s : ℝ) = t) ∨ (IsCrossPair k l ∧ (s : ℝ) = 1 / 2 ∧ (t : ℝ) = 1 / 2) :=
  seg_meet hs.1 hs.2 ht.1 ht.2 (toK_open_eq hs ht h)

/-- Edge interiors avoid all vertices. -/
theorem arc_ne_pt {k : EIx} {s : unitInterval} (hs : s ∈ openUnit) (w : Fin 12) :
    segArc k s ≠ pt w := by
  intro h
  have h1 := segPt_open (k := k) hs.1 hs.2
  have h' := (toK_eq_iff h1.1 (pt_mem w)).mp h
  rw [h1.2, nf_pt] at h'
  exact segPt_not_lattice hs.1 hs.2 (vx w) (vy w) h'

theorem segArc_injective (k : EIx) : Injective (segArc k) := by
  intro s t h
  rcases unit_cases s with hs | hs | hs <;> rcases unit_cases t with ht | ht | ht
  · exact Subtype.ext (hs.trans ht.symm)
  · rw [segArc_at_zero k hs, segArc_at_one k ht] at h
    exact absurd (pt_injective h) (src_ne_dst k)
  · rw [segArc_at_zero k hs] at h
    exact absurd h.symm (arc_ne_pt ht _)
  · rw [segArc_at_one k hs, segArc_at_zero k ht] at h
    exact absurd (pt_injective h).symm (src_ne_dst k)
  · exact Subtype.ext (hs.trans ht.symm)
  · rw [segArc_at_one k hs] at h
    exact absurd h.symm (arc_ne_pt ht _)
  · rw [segArc_at_zero k ht] at h
    exact absurd h (arc_ne_pt hs _)
  · rw [segArc_at_one k ht] at h
    exact absurd h (arc_ne_pt hs _)
  · rcases arc_meet hs ht h with ⟨_, e⟩ | ⟨⟨_, _, hc⟩, _, _⟩
    · exact Subtype.ext e
    · rcases hc with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> rw [h1] at h2 <;> exact absurd h2 (by decide)

/-! ## Edge indices versus graph edges -/

abbrev toSym2 (k : EIx) : Sym2 (Fin 12) := s(src k, dst k)

theorem exists_ix : ∀ z : Sym2 (Fin 12), z ∈ kleinGraph.edgeSet → ∃ k : EIx, toSym2 k = z := by
  refine Sym2.ind (fun u v => ?_)
  intro h
  rw [SimpleGraph.mem_edgeSet] at h
  obtain ⟨i, j, κ, hk⟩ := adj_has_ix u v h
  refine ⟨(i, j, κ), ?_⟩
  rcases hk with ⟨h1, h2⟩ | ⟨h1, h2⟩
  · rw [toSym2, h1, h2]
  · rw [toSym2, h1, h2, Sym2.eq_swap]

/-- The edge index of a graph edge. -/
noncomputable def idx (e : kleinGraph.edgeSet) : EIx := Classical.choose (exists_ix e.1 e.2)

theorem idx_spec (e : kleinGraph.edgeSet) : toSym2 (idx e) = e.1 :=
  Classical.choose_spec (exists_ix e.1 e.2)

theorem idx_inj {e f : kleinGraph.edgeSet} (h : idx e = idx f) : e = f :=
  Subtype.ext (by rw [← idx_spec e, ← idx_spec f, h])

theorem mem_edge_iff (e : kleinGraph.edgeSet) (w : Fin 12) :
    w ∈ (e : Sym2 (Fin 12)) ↔ w = src (idx e) ∨ w = dst (idx e) := by
  rw [← idx_spec e]
  exact Sym2.mem_iff

/-- **The drawing of `G` on the Klein bottle.** -/
noncomputable def kleinDrawing : Drawing kleinGraph KleinBottle where
  pt := pt
  arc e := segArc (idx e)
  ends e := ⟨src (idx e), dst (idx e), (idx_spec e).symm, segArc_zero _, segArc_one _⟩

/-! ## Crossing pairs -/

theorem crossPair_no_common {k l : EIx} (hkl : IsCrossPair k l) (w : Fin 12)
    (hk : w = src k ∨ w = dst k) (hl : w = src l ∨ w = dst l) : False := by
  rcases k with ⟨i, j, κ⟩
  rcases l with ⟨i', j', κ'⟩
  obtain ⟨h1, h2, h3⟩ := hkl
  obtain rfl : i = i' := h1
  obtain rfl : j = j' := h2
  have h3' : (κ = Kind.Dp ∧ κ' = Kind.Dm) ∨ (κ = Kind.Dm ∧ κ' = Kind.Dp) := h3
  rcases h3' with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
  · exact cross_disjoint i j w hk hl
  · exact cross_disjoint i j w hl hk

theorem crossPair_unique {k l m : EIx} (h1 : IsCrossPair k l) (h2 : IsCrossPair k m) :
    l = m := by
  obtain ⟨a1, b1, c1⟩ := h1
  obtain ⟨a2, b2, c2⟩ := h2
  have hκ : l.2.2 = m.2.2 := by
    rcases c1 with ⟨e1, f1⟩ | ⟨e1, f1⟩ <;> rcases c2 with ⟨e2, f2⟩ | ⟨e2, f2⟩
    · rw [f1, f2]
    · rw [e1] at e2; exact absurd e2 (by decide)
    · rw [e1] at e2; exact absurd e2 (by decide)
    · rw [f1, f2]
  exact Prod.ext (a1.symm.trans a2) (Prod.ext (b1.symm.trans b2) hκ)

theorem dp_affine (i : Fin 4) (j : Fin 3) : ∀ r : ℝ, 0 < r → r < 1 →
    segPt (i, j, .Dp) r =
      (((i : ℕ) : ℝ) + 1 / 2, ((j : ℕ) : ℝ) + 1 / 2) + (r - 1 / 2) • ((1 : ℝ), (1 : ℝ)) ∧
    segPt (i, j, .Dp) r ∈ openRect := by
  intro r hr0 hr1
  have hi := fin4_le i
  have hj := fin3_le j
  have hi0 : (0 : ℝ) ≤ ((i : ℕ) : ℝ) := Nat.cast_nonneg _
  have hj0 : (0 : ℝ) ≤ ((j : ℕ) : ℝ) := Nat.cast_nonneg _
  refine ⟨?_, ?_⟩
  · show (((i : ℕ) : ℝ) + r, ((j : ℕ) : ℝ) + r) = _
    simp only [Prod.mk_add_mk, Prod.smul_mk, smul_eq_mul]
    congr 1 <;> ring
  · exact mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩

theorem dm_affine (i : Fin 4) (j : Fin 3) : ∀ r : ℝ, 0 < r → r < 1 →
    segPt (i, j, .Dm) r =
      (((i : ℕ) : ℝ) + 1 / 2, ((j : ℕ) : ℝ) + 1 / 2) + (r - 1 / 2) • ((-1 : ℝ), (1 : ℝ)) ∧
    segPt (i, j, .Dm) r ∈ openRect := by
  intro r hr0 hr1
  have hi := fin4_le i
  have hj := fin3_le j
  have hi0 : (0 : ℝ) ≤ ((i : ℕ) : ℝ) := Nat.cast_nonneg _
  have hj0 : (0 : ℝ) ≤ ((j : ℕ) : ℝ) := Nat.cast_nonneg _
  refine ⟨?_, ?_⟩
  · show (((i : ℕ) : ℝ) + 1 - r, ((j : ℕ) : ℝ) + r) = _
    simp only [Prod.mk_add_mk, Prod.smul_mk, smul_eq_mul]
    congr 1 <;> ring
  · exact mem_openRect_mk.mpr ⟨⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩

/-- Transversality in the interior chart. -/
theorem transverse_core {k l : EIx} (c v w : ℝ × ℝ) {s t : unitInterval}
    (hs : (s : ℝ) = 1 / 2) (ht : (t : ℝ) = 1 / 2) (hdet : v.1 * w.2 - v.2 * w.1 ≠ 0)
    (hk : ∀ r : ℝ, 0 < r → r < 1 → segPt k r = c + (r - 1 / 2) • v ∧ segPt k r ∈ openRect)
    (hl : ∀ r : ℝ, 0 < r → r < 1 → segPt l r = c + (r - 1 / 2) • w ∧ segPt l r ∈ openRect) :
    TransverseAt (segArc k) (segArc l) s t := by
  refine ⟨openRect, interiorChart, isOpen_openRect, isOpenEmbedding_interiorChart, c, v, w,
    1 / 2, by norm_num, hdet, ?_, ?_⟩
  · intro s' hs'
    rw [hs] at hs' ⊢
    obtain ⟨h1, h2⟩ := abs_lt.mp hs'
    obtain ⟨e, hm⟩ := hk s' (by linarith) (by linarith)
    rw [← e]
    exact ⟨hm, rfl⟩
  · intro t' ht'
    rw [ht] at ht' ⊢
    obtain ⟨h1, h2⟩ := abs_lt.mp ht'
    obtain ⟨e, hm⟩ := hl t' (by linarith) (by linarith)
    rw [← e]
    exact ⟨hm, rfl⟩

theorem transverse_of_crossPair {k l : EIx} (hkl : IsCrossPair k l) {s t : unitInterval}
    (hs : (s : ℝ) = 1 / 2) (ht : (t : ℝ) = 1 / 2) :
    TransverseAt (segArc k) (segArc l) s t := by
  rcases k with ⟨i, j, κ⟩
  rcases l with ⟨i', j', κ'⟩
  obtain ⟨h1, h2, h3⟩ := hkl
  obtain rfl : i = i' := h1
  obtain rfl : j = j' := h2
  have h3' : (κ = Kind.Dp ∧ κ' = Kind.Dm) ∨ (κ = Kind.Dm ∧ κ' = Kind.Dp) := h3
  rcases h3' with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
  · exact transverse_core _ (1, 1) (-1, 1) hs ht (by norm_num) (dp_affine i j) (dm_affine i j)
  · exact transverse_core _ (-1, 1) (1, 1) hs ht (by norm_num) (dm_affine i j) (dp_affine i j)

/-! ## The drawing is a good 1-embedding -/

theorem kleinDrawing_good : IsGoodOneDrawing kleinDrawing where
  pt_injective := pt_injective
  arc_injective e := segArc_injective (idx e)
  inner_avoids_vertices _ _ ht w := arc_ne_pt ht w
  adjacent_inner_disjoint e f hef hw := by
    obtain ⟨w, hwe, hwf⟩ := hw
    rw [Set.disjoint_left]
    rintro x ⟨s, hs, rfl⟩ ⟨t, ht, hts⟩
    rcases arc_meet (k := idx e) (l := idx f) hs ht hts.symm with ⟨he, -⟩ | ⟨hc, -, -⟩
    · exact hef (idx_inj he)
    · exact crossPair_no_common hc w ((mem_edge_iff e w).mp hwe) ((mem_edge_iff f w).mp hwf)
  no_triple_crossing e f g hef hfg heg := by
    apply Set.subset_empty_iff.mp
    rintro x ⟨⟨⟨s, hs, rfl⟩, ⟨t, ht, hts⟩⟩, ⟨r, hr, hrs⟩⟩
    exfalso
    rcases arc_meet (k := idx e) (l := idx f) hs ht hts.symm with ⟨he, -⟩ | ⟨hc1, -, -⟩
    · exact hef (idx_inj he)
    rcases arc_meet (k := idx e) (l := idx g) hs hr hrs.symm with ⟨he, -⟩ | ⟨hc2, -, -⟩
    · exact heg (idx_inj he)
    exact hfg (idx_inj (crossPair_unique hc1 hc2))
  crossings_transverse e f hef s hs t ht h := by
    rcases arc_meet (k := idx e) (l := idx f) hs ht h with ⟨he, -⟩ | ⟨hc, h1, h2⟩
    · exact absurd (idx_inj he) hef
    · exact transverse_of_crossPair hc h1 h2
  at_most_one_crossing e := by
    rintro x ⟨⟨s, hs, rfl⟩, f, hfe, t, ht, hts⟩ y ⟨⟨s', hs', rfl⟩, g, hge, t', ht', hts'⟩
    have e1 : (s : ℝ) = 1 / 2 := by
      rcases arc_meet (k := idx f) (l := idx e) ht hs hts with ⟨he, -⟩ | ⟨-, -, h2⟩
      · exact absurd (idx_inj he) hfe
      · exact h2
    have e2 : (s' : ℝ) = 1 / 2 := by
      rcases arc_meet (k := idx g) (l := idx e) ht' hs' hts' with ⟨he, -⟩ | ⟨-, -, h2⟩
      · exact absurd (idx_inj he) hge
      · exact h2
    have hss : s = s' := Subtype.ext (e1.trans e2.symm)
    rw [hss]

end Klein366521
