import UMWQuotientV3IntegratedV3
namespace MathDB339675
open Polynomial Finset
noncomputable def quadraticMap (d : ℕ) : ℝ[X] := X*(C (d:ℝ)-X)
theorem quadraticMap_degree_le (d : ℕ) : (quadraticMap d).natDegree ≤ 2 := by
  have h1 := natDegree_sub_le (C (d:ℝ)) (X:ℝ[X])
  have h2 := natDegree_mul_le (p := (X:ℝ[X])) (q := C (d:ℝ)-X)
  simp only [natDegree_C, natDegree_X] at h1 h2
  unfold quadraticMap
  omega
theorem sourceP_eq_pairedB (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    sourceP m d = (pairedB m d).comp (quadraticMap d) := by
  have hb := pairedB_degree_le m d
  have hq := quadraticMap_degree_le d
  have hc : ((pairedB m d).comp (quadraticMap d)).natDegree ≤ (m-1)*2 := by
    exact (natDegree_comp_le).trans (Nat.mul_le_mul hb hq)
  apply eq_of_natDegree_lt_card_of_eval_eq _ _ (pairedNode_injective m d hd)
  · rintro ⟨j,b⟩
    have hj : j.val ≤ m := by omega
    have he := sourceP_paired_evaluations m d j hm hd hj
    have hv := pairedB_eval m d j j.isLt
    cases b
    · change (sourceP m d).eval (-(j:ℝ)) = _
      rw [he.1, eval_comp]
      have hmap : (quadraticMap d).eval (pairedNode d (j,false)) = -lattice d j := by
        simp [quadraticMap, pairedNode, lattice]
      rw [hmap, hv]
    · change (sourceP m d).eval ((d:ℝ)+j) = _
      rw [he.2, eval_comp]
      have hmap : (quadraticMap d).eval (pairedNode d (j,true)) = -lattice d j := by
        simp [quadraticMap, pairedNode, lattice]
        ring
      rw [hmap, hv]
  · have hp := (sourceP_exact_degree m d hm).1
    simp only [Fintype.card_prod, Fintype.card_fin, Fintype.card_bool]
    omega
#print axioms sourceP_eq_pairedB
end MathDB339675
