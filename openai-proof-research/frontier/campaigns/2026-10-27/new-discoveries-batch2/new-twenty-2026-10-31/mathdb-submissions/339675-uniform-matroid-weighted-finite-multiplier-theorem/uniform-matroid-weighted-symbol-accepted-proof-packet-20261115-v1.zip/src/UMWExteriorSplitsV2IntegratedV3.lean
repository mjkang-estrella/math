import UMWSourceRootsV4IntegratedV3
import Mathlib.Analysis.SpecialFunctions.Sqrt
namespace MathDB339675
open Polynomial Finset
theorem quadraticMap_sub_splits (d : ℕ) (c : ℝ) (hc : c < 0) :
    (quadraticMap d - C c).Splits := by
  let z := Real.sqrt ((d:ℝ)^2-4*c)
  let a := ((d:ℝ)-z)/2
  let b := ((d:ℝ)+z)/2
  have hz : z^2 = (d:ℝ)^2-4*c := Real.sq_sqrt (by nlinarith [sq_nonneg (d:ℝ)])
  have hab : a+b = d := by dsimp [a,b]; ring
  have hmul : a*b = c := by dsimp [a,b]; nlinarith [hz]
  have hsumP : C a+C b = (C (d:ℝ):ℝ[X]) := by rw [← C_add, hab]
  have hprodP : C a*C b = (C c:ℝ[X]) := by rw [← C_mul, hmul]
  have he : quadraticMap d - C c = C (-1:ℝ)*(X-C a)*(X-C b) := by
    unfold quadraticMap
    simp only [C_neg, C_1]
    linear_combination -X * hsumP + hprodP
  rw [he]
  exact ((Splits.X_sub_C a).C_mul (-1)).mul (Splits.X_sub_C b)
theorem sourceP_splits_exterior (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    (sourceP m d).Splits ∧
      ∀ x : ℝ, (sourceP m d).eval x = 0 → x < 0 ∨ (d:ℝ) < x := by
  constructor
  · have hb := pairedB_negative_roots m d hm hd
    rw [sourceP_eq_pairedB m d hm hd]
    rw [hb.1.eq_prod_roots, mul_comp, C_comp, multiset_prod_comp]
    apply (Splits.C _).mul
    apply Splits.multisetProd
    intro f hf
    obtain ⟨g,hg,rfl⟩ := Multiset.mem_map.mp hf
    obtain ⟨c,hc,rfl⟩ := Multiset.mem_map.mp hg
    rw [sub_comp, X_comp, C_comp]
    apply quadraticMap_sub_splits d c
    exact hb.2 c ((mem_roots (pairedB_nonzero m d hm)).mp hc)
  · exact fun x hx => sourceP_real_roots_exterior m d hm hd x hx
#print axioms sourceP_splits_exterior
end MathDB339675
