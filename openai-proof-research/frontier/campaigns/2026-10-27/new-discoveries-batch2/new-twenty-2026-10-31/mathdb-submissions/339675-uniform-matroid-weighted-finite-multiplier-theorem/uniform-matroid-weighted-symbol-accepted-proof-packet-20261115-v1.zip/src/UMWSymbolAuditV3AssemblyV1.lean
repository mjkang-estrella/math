import UMWSymbolNegativeV2AssemblyV1
namespace MathDB339675
open Polynomial
theorem literal_symbol_certificate (m d : ℕ) (hm : 0<m) (hd : 0<d) :
    (symbol m d).natDegree=d ∧ (symbol m d).coeff 0=1 ∧
    (symbol m d).Splits ∧ ∀ x : ℝ, (symbol m d).eval x=0 → x<0 :=
  ⟨symbol_degree m d hm hd, symbol_constant m d hm, symbol_splits_negative m d hm hd⟩
#print axioms literal_symbol_certificate
#print axioms symbol_splits_negative
#print axioms theta_exterior_preserves
#print axioms theta_factor_leading
#print axioms theta_factor_constant
#print axioms thetaAction_exterior_preserves
#print axioms source_theta_seed_eq_symbol
#print axioms thetaLinear
#print axioms thetaAction_mul
#print axioms thetaAction_monomial
#print axioms theta_log_im_pos
end MathDB339675
