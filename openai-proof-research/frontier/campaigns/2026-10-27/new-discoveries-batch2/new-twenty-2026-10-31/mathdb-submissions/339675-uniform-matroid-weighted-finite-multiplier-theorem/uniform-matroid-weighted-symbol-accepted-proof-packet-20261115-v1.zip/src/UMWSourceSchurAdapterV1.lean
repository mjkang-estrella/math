import UMWSourceBridgeIntegratedV1
import UMWSchurEndpointV3
namespace MathDB339675
open Polynomial
theorem source_symbol_schur_adapter (m d : ℕ) (_hm : 0 < m) (hd : 0 < d)
    (hdeg : (symbol m d).natDegree = d) (hs : (symbol m d).Splits)
    (hr : ∀ r : ℝ, (symbol m d).eval r = 0 → r < 0) : IsDSequence m d := by
  intro f hfd hfs
  simpa only [composition_symbol_eq_diagonal] using
    finite_schur_splits d hd f (symbol m d) hdeg hs hr hfd hfs
#print axioms source_symbol_schur_adapter
#print axioms finite_schur_splits
#print axioms composition_symbol_eq_diagonal
end MathDB339675
