import UMWThresholdV1IntegratedV2
import Mathlib.Algebra.Group.ForwardDiff
namespace MathDB339675
open Finset
open scoped fwdDiff

/-- The exact finite-difference identity needed for lattice evaluations,
with the standard forward-difference sign convention. -/
theorem alternating_choose_sum (A q : ℕ) (hq : q ≤ A) :
    ∑ h ∈ range (q+1), (-1 : ℝ)^(q-h) * (q.choose h : ℝ) *
      ((A+h).choose A : ℝ) = (A.choose (A-q) : ℝ) := by
  have h := fwdDiff_iter_eq_sum_shift (1 : ℕ) (fun x : ℕ => (x.choose A : ℝ)) q A
  have he : (fwdDiff (1 : ℕ))^[q] (fun x : ℕ => (x.choose A : ℝ)) A =
      (A.choose (A-q) : ℝ) := by
    have hh := fwdDiff_iter_choose (R := ℝ) (A-q) q
    rw [Nat.add_sub_of_le hq] at hh
    exact congrFun hh A
  rw [he] at h
  simpa [zsmul_eq_mul, mul_assoc] using h.symm

#print axioms alternating_choose_sum
end MathDB339675
