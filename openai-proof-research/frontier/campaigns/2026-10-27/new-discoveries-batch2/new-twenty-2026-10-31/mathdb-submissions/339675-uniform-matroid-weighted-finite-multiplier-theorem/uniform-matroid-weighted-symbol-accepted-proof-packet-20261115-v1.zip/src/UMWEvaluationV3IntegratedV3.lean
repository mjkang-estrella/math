import UMWFallingV2IntegratedV3
namespace MathDB339675
open Finset

noncomputable def negativeSummand (m d j h : ℕ) : ℝ :=
  (((j : ℝ)+1)/((h : ℝ)+1) - (j : ℝ)/m) *
    (-1 : ℝ)^h * (j.choose h : ℝ) * ((d+j+h).choose h : ℝ)

theorem b_negative_sum (m d j : ℕ) (hm : 0 < m) :
    b m d (-(j : ℝ)) = ∑ h ∈ range m, negativeSummand m d j h := by
  unfold b
  apply sum_congr rfl
  intro h _
  have hm' : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hh : (h : ℝ)+1 ≠ 0 := by positivity
  have hf : -(j : ℝ)-1+(h : ℝ) = (h : ℝ)-(j : ℝ)-1 := by ring
  have hg : (d : ℝ) - -(j : ℝ) + (h : ℝ) = ((d+j+h : ℕ) : ℝ) := by push_cast; ring
  rw [hf, hg, fallingChoose_negative_grid, fallingChoose_nat]
  unfold negativeSummand
  field_simp
  ring

theorem negativeSummand_vanish (m d j h : ℕ) (hh : j < h) :
    negativeSummand m d j h = 0 := by
  simp [negativeSummand, Nat.choose_eq_zero_of_lt hh]

theorem negativeSummand_last (m d : ℕ) (hm : 0 < m) : negativeSummand m d m m = 0 := by
  have hm' : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hh : (m : ℝ)+1 ≠ 0 := by positivity
  simp [negativeSummand, hm', hh]

theorem b_negative_trimmed (m d j : ℕ) (hm : 0 < m) (hj : j ≤ m) :
    b m d (-(j : ℝ)) = ∑ h ∈ range (j+1), negativeSummand m d j h := by
  rw [b_negative_sum m d j hm]
  rcases lt_or_eq_of_le hj with hj | rfl
  · symm
    apply sum_subset (range_mono (by omega : j+1 ≤ m))
    intro h _ hh
    exact negativeSummand_vanish m d j h (by simp only [mem_range, not_lt] at hh; omega)
  · rw [sum_range_succ, negativeSummand_last j d hm, add_zero]

#print axioms b_negative_trimmed
end MathDB339675
