import UMWThetaActionV2AssemblyV1
namespace MathDB339675
open Polynomial
noncomputable def thetaLinear : ℝ[X] →ₗ[ℝ] ℝ[X] where
  toFun := theta
  map_add' f g := by simp [theta, mul_add]
  map_smul' a f := by simp [theta]
theorem thetaAction_C (a : ℝ) (f : ℝ[X]) : thetaAction (C a) f = C a * f := by
  ext i
  simp [coeff_thetaAction]
theorem thetaAction_add (p q f : ℝ[X]) :
    thetaAction (p+q) f = thetaAction p f + thetaAction q f := by
  ext i
  simp [coeff_thetaAction, add_mul]
theorem thetaAction_monomial (p : ℝ[X]) (i : ℕ) (c : ℝ) :
    thetaAction p (monomial i c) = monomial i (p.eval (i:ℝ)*c) := by
  ext j
  by_cases h : i=j
  · subst j; simp [coeff_thetaAction]
  · simp [coeff_thetaAction, coeff_monomial, h]
theorem source_theta_seed_eq_symbol (m d : ℕ) :
    thetaAction (sourceP m d) ((1+X)^d) = symbol m d := by
  ext i
  rw [coeff_thetaAction, coeff_one_add_X_pow, eval_sourceP, coeff_symbol]
  by_cases hi : i ≤ d
  · simp [hi, mul_comm]
  · simp [hi, Nat.choose_eq_zero_of_lt (by omega : d < i)]
end MathDB339675
