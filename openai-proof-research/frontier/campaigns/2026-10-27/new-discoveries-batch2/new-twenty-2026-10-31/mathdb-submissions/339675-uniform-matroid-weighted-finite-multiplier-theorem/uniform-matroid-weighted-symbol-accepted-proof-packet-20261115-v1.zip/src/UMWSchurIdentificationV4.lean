import UMWSchurPartialSlopeV3
namespace MathDB339675
open Polynomial
open scoped BigOperators
theorem schurPolarizationSlope_equal (d : ℕ) (p : ℂ[X])
    (z : Fin d → ℂ) (j k : Fin d) (hjk : z j = z k) :
    schurPolarizationSlope d p z j = schurPolarizationSlope d p z k := by
  classical
  by_cases hne : j = k
  · subst k; rfl
  have hu : (fun l => (Function.update z j (z j+1)) ((Equiv.swap j k) l)) =
      Function.update z k (z j+1) := by
    funext l
    by_cases h1 : l = j
    · subst l
      simp [hne, Ne.symm hne, hjk]
    · by_cases h2 : l = k
      · subst l; simp
      · simp [Equiv.swap_apply_of_ne_of_ne h1 h2, h1, h2]
  have hh := schurPolarization_perm d p (Function.update z j (z j+1)) (Equiv.swap j k)
  rw [hu, schurPolarization_update, schurPolarization_update, ← hjk] at hh
  linear_combination -hh

theorem partialSlope_equal (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) (j k : Fin d) (hj : j ∉ T) (hk : k ∉ T) :
    partialSlope d p T a j = partialSlope d p T a k := by
  apply Polynomial.funext
  intro z
  rw [partialSlope_eval, partialSlope_eval]
  apply schurPolarizationSlope_equal
  simp [hj, hk]

theorem partialPoly_derivative (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) (j : Fin d) (hj : j ∉ T) :
    (partialPoly d p T a).derivative =
      C ((d-T.card : ℕ) : ℂ) * partialSlope d p T a j := by
  classical
  rw [partialPoly_derivative_sum]
  have hh : ∀ k ∈ (Finset.univ : Finset (Fin d)) \ T,
      partialSlope d p T a k = partialSlope d p T a j := by
    intro k hk
    exact partialSlope_equal d p T a k j (Finset.mem_sdiff.mp hk).2 hj
  rw [Finset.sum_congr rfl hh, Finset.sum_const]
  simp [Finset.card_sdiff_of_subset (Finset.subset_univ T), nsmul_eq_mul]

theorem partialPoly_insert_polarStep (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) (j : Fin d) (hj : j ∉ T) :
    partialPoly d p (insert j T) a =
      polarStep (partialPoly d p T a) (d-T.card) (a j) := by
  classical
  have ht : T.card < d := by
    have h := Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr
      ⟨Finset.subset_univ T, by intro he; exact hj (he ▸ Finset.mem_univ j)⟩)
    simpa using h
  have hn : ((d-T.card : ℕ) : ℂ) ≠ 0 := by exact_mod_cast (show d-T.card ≠ 0 by omega)
  rw [partialPoly_insert d p T a j hj, polarStep,
    partialPoly_derivative d p T a j hj]
  simp only [← mul_assoc]
  congr 1
  calc
    (C (a j)-X) * partialSlope d p T a j =
        (C ((d-T.card : ℕ) : ℂ)⁻¹ * C ((d-T.card : ℕ) : ℂ)) *
          (C (a j)-X) * partialSlope d p T a j := by rw [← C_mul, inv_mul_cancel₀ hn, C_1, one_mul]
    _ = _ := by ring
end MathDB339675
