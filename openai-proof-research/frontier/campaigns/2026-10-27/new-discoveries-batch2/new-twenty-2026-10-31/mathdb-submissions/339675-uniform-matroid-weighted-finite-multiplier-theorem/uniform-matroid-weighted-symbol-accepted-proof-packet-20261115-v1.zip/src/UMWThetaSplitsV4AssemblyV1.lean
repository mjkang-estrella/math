import UMWThetaStabilityV3AssemblyV1
namespace MathDB339675
open Polynomial
theorem theta_complex_no_upper {p : ℂ[X]} (hp : p ≠ 0) (hs : p.Splits)
    (hd : p.natDegree ≠ 0) (hr : ∀ w ∈ p.roots, w.im=0 ∧ w.re<0)
    (r : ℝ) {z : ℂ} (hz : 0 < z.im) :
    (X*p.derivative-C (r:ℂ)*p).eval z ≠ 0 := by
  have he := schur_eval_ne_zero_upper hp (fun w hw => le_of_eq (hr w hw).1) hz
  have hi := theta_log_im_pos hp hs hd hr hz
  intro h
  simp only [eval_sub, eval_mul, eval_X, eval_C] at h
  have hh : z * (p.derivative.eval z / p.eval z) = (r:ℂ) := by
    rw [← mul_div_assoc]
    apply (div_eq_iff he).2
    linear_combination h
  rw [hh, Complex.ofReal_im] at hi
  linarith
theorem theta_real_splits (p : ℝ[X]) (hp : p ≠ 0) (hs : p.Splits)
    (hd : p.natDegree ≠ 0) (hn : ∀ x : ℝ, p.eval x=0 → x<0) (r : ℝ) :
    (X*p.derivative-C r*p).Splits := by
  apply schur_real_splits_of_upperStable
  intro z hz
  have hr : ∀ w ∈ (p.map (algebraMap ℝ ℂ)).roots, w.im=0 ∧ w.re<0 := by
    intro w hw
    have he := (mem_roots (map_ne_zero hp)).mp hw
    obtain ⟨a, ha⟩ := hs.mem_range_of_isRoot hp he
    rw [← ha] at he ⊢
    constructor
    · simp
    · change a < 0
      apply hn a
      have hh : (algebraMap ℝ ℂ) (p.eval a) = 0 := by
        simpa only [IsRoot, eval_map, eval₂_at_apply] using he
      exact (map_eq_zero_iff (algebraMap ℝ ℂ) (algebraMap ℝ ℂ).injective).mp hh
  have hh := theta_complex_no_upper (map_ne_zero hp) (IsAlgClosed.splits _) (by simpa using hd) hr r hz
  simpa [derivative_map] using hh
end MathDB339675
