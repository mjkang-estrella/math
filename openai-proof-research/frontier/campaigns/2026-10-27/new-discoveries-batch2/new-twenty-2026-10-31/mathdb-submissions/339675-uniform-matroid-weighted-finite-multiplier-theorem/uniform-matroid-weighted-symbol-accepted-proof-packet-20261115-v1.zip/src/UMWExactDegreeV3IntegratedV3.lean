import UMWSourceDegreeV2IntegratedV3
namespace MathDB339675
open Polynomial Finset
theorem source_last_degree (n d : ℕ) :
    (sourceSummand (n+1) d n).natDegree = 2*n ∧
    (sourceSummand (n+1) d n).leadingCoeff =
      (-1:ℝ)^n / ((n.factorial:ℝ)*((n+1).factorial:ℝ)) := by
  have hs := source_factors d n
  have hfac : (n.factorial:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero n)
  have hneg : (-1:ℝ)^n ≠ 0 := pow_ne_zero _ (by norm_num)
  have hA : fallingPoly (X-C 1+C (n:ℝ)) n ≠ 0 := by
    intro hz
    have hh := hs.2.1
    rw [hz, leadingCoeff_zero] at hh
    exact (one_div_ne_zero hfac) hh.symm
  have hB : fallingPoly (C (d:ℝ)-X+C (n:ℝ)) n ≠ 0 := by
    intro hz
    have hh := hs.2.2.2
    rw [hz, leadingCoeff_zero] at hh
    exact (div_ne_zero hneg hfac) hh.symm
  have hn : (n:ℝ)+1 ≠ 0 := by positivity
  rw [sourceSummand_last]
  constructor
  · rw [natDegree_mul (mul_ne_zero (C_ne_zero.mpr (one_div_ne_zero hn)) hA) hB,
      natDegree_C_mul (one_div_ne_zero hn), hs.1, hs.2.2.1]
    omega
  · rw [leadingCoeff_mul, leadingCoeff_mul, leadingCoeff_C, hs.2.1, hs.2.2.2,
      Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one]
    field_simp
theorem sourceP_one (d : ℕ) : sourceP 1 d = 1 := by
  simp [sourceP, fallingPoly]
theorem sourceP_exact_degree (m d : ℕ) (hm : 0 < m) :
    (sourceP m d).natDegree = 2*m-2 ∧
    (sourceP m d).leadingCoeff =
      (-1:ℝ)^(m-1) / (((m-1).factorial:ℝ)*(m.factorial:ℝ)) := by
  obtain ⟨n, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : m ≠ 0)
  by_cases hn : n = 0
  · subst n
    simp [sourceP_one]
  · let L := ∑ h ∈ range n, sourceSummand (n+1) d h
    have hL : L.natDegree ≤ 2*n-1 := by
      apply natDegree_sum_le_of_forall_le
      intro h hh
      have hb := sourceSummand_degree_le (n+1) d h
      have hh' := mem_range.mp hh
      omega
    have ht := source_last_degree n d
    have hlt : L.natDegree < (sourceSummand (n+1) d n).natDegree := by
      rw [ht.1]
      omega
    have he : sourceP (n+1) d = L + sourceSummand (n+1) d n := by
      change (∑ h ∈ range (n+1), sourceSummand (n+1) d h) = _
      rw [sum_range_succ]
    have hd : (sourceP (n+1) d).natDegree = 2*n := by
      rw [he, natDegree_add_eq_right_of_natDegree_lt hlt, ht.1]
    constructor
    · rw [hd]; omega
    · rw [leadingCoeff, hd, he, coeff_add, coeff_eq_zero_of_natDegree_lt (by omega : L.natDegree < 2*n),
        zero_add, ← ht.1, ← leadingCoeff, ht.2]
      simp
#print axioms sourceP_exact_degree
end MathDB339675
