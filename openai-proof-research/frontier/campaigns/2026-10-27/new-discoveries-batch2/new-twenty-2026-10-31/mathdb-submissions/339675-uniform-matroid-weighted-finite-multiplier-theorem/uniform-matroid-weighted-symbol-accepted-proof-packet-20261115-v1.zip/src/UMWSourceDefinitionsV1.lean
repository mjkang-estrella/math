import UMWSchurCompositionDefinitionV2
import Mathlib.Algebra.Polynomial.Splits

open scoped BigOperators
open Polynomial Finset
namespace MathDB339675
noncomputable def fallingChoose (x : ℝ) (h : ℕ) : ℝ :=
  (∏ k ∈ range h, (x - (k : ℝ))) / (h.factorial : ℝ)
noncomputable def b (m d : ℕ) (x : ℝ) : ℝ :=
  ∑ h ∈ range m, (((m : ℝ) + x * ((h : ℝ) - (m : ℝ) + 1)) /
    (((h : ℝ) + 1) * (m : ℝ))) *
    fallingChoose (x - 1 + (h : ℝ)) h * fallingChoose ((d : ℝ) - x + (h : ℝ)) h
noncomputable def symbol (m d : ℕ) : ℝ[X] :=
  ∑ i ∈ range (d+1), monomial i ((d.choose i : ℝ) * b m d (i : ℝ))
noncomputable def diagonal (m d : ℕ) (f : ℝ[X]) : ℝ[X] :=
  ∑ i ∈ range (d+1), monomial i (b m d (i : ℝ) * f.coeff i)
def IsDSequence (m d : ℕ) : Prop :=
  ∀ f : ℝ[X], f.natDegree ≤ d → (f = 0 ∨ f.Splits) →
    (diagonal m d f = 0 ∨ (diagonal m d f).Splits)
theorem coeff_diagonal (m d : ℕ) (f : ℝ[X]) (i : ℕ) :
    (diagonal m d f).coeff i = if i ≤ d then b m d (i : ℝ) * f.coeff i else 0 := by
  classical
  simp [diagonal, coeff_monomial]

theorem coeff_symbol (m d i : ℕ) :
    (symbol m d).coeff i = if i ≤ d then (d.choose i : ℝ) * b m d (i : ℝ) else 0 := by
  classical
  simp [symbol, coeff_monomial]


theorem source_b_definition_fidelity (m d : ℕ) (x : ℝ) :
 b m d x = ∑ h ∈ range m, (((m : ℝ) + x * ((h : ℝ) - (m : ℝ) + 1)) / (((h : ℝ) + 1) * (m : ℝ))) * fallingChoose (x - 1 + (h : ℝ)) h * fallingChoose ((d : ℝ) - x + (h : ℝ)) h := rfl
end MathDB339675
