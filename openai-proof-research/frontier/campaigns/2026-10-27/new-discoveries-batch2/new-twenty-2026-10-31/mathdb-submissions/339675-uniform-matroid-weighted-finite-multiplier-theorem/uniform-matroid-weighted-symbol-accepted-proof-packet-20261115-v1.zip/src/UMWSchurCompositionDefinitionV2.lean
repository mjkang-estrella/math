import Mathlib.Algebra.Polynomial.Monomial
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Data.Real.Basic
namespace MathDB339675
open Polynomial Finset
/-- Standalone extraction of the frozen definition. Integration must use ONE
definition provider; do not import UMWSourceBridgeV2 alongside this module. -/
noncomputable def weightedComposition (d : ℕ) (f g : ℝ[X]) : ℝ[X] :=
  ∑ i ∈ range (d+1), monomial i (f.coeff i * g.coeff i / (d.choose i : ℝ))
end MathDB339675
