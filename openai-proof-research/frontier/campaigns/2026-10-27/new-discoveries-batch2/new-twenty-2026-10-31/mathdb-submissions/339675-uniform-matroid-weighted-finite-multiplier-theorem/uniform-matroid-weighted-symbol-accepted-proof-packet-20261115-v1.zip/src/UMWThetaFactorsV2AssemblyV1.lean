import UMWThetaPreservesV2AssemblyV1
import UMWThetaSymbolV3AssemblyV1
namespace MathDB339675
open Polynomial
def NegativeDegree (d : ℕ) (p : ℝ[X]) : Prop :=
  p.natDegree=d ∧ p.Splits ∧ ∀ x : ℝ, p.eval x=0 → x<0
theorem negativeDegree_ne_zero {d : ℕ} (hd : 0<d) {p : ℝ[X]}
    (h : NegativeDegree d p) : p ≠ 0 := by
  intro he
  have := h.1
  simp [he] at this
  omega
theorem thetaAction_factor_preserves {d : ℕ} (hd : 0<d) {p : ℝ[X]}
    (h : NegativeDegree d p) (r : ℝ) (hr : r<0 ∨ (d:ℝ)<r) :
    NegativeDegree d (thetaAction (X-C r) p) := by
  rw [thetaAction_sub_C]
  have hh := theta_exterior_preserves p (negativeDegree_ne_zero hd h) h.2.1
    (by rw [h.1]; omega) h.2.2 r (by simpa only [h.1] using hr)
  exact ⟨hh.1.trans h.1, hh.2⟩
theorem thetaAction_factors_preserves {d : ℕ} (hd : 0<d) (s : Multiset ℝ)
    (hr : ∀ r ∈ s, r<0 ∨ (d:ℝ)<r) {p : ℝ[X]} (h : NegativeDegree d p) :
    NegativeDegree d (thetaAction (s.map (fun r => X-C r)).prod p) := by
  induction s using Multiset.induction_on with
  | empty => simpa only [Multiset.map_zero, Multiset.prod_zero, thetaAction_one] using h
  | cons r s ih =>
    simp only [Multiset.map_cons, Multiset.prod_cons, thetaAction_mul]
    exact thetaAction_factor_preserves hd
      (ih (fun a ha => hr a (by simp [ha]))) r (hr r (by simp))
end MathDB339675
