import UMWNodesV3IntegratedV2
namespace MathDB339675
open Polynomial Finset

theorem lattice_pos (d j : ℕ) (hj : 0 < j) : 0 < lattice d j := by
  simpa using lattice_strictMono d hj

theorem no_node_in_gap (d j k : ℕ) :
    -lattice d k ∉ Set.Ioo (-lattice d (j+1)) (-lattice d j) := by
  intro h
  by_cases hk : k ≤ j
  · have := (lattice_strictMono d).monotone hk
    linarith [h.2]
  · have := (lattice_strictMono d).monotone (show j+1 ≤ k by omega)
    linarith [h.1]

/-- Select one root in each specified disjoint quadratic-lattice gap.
The resulting roots are negative and avoid every lattice node. -/
theorem gap_root_set (p : ℝ[X]) (d : ℕ) (s : Finset ℕ)
    (he : ∀ j ∈ s, ∃ x ∈ Set.Ioo (-lattice d (j+1)) (-lattice d j), p.eval x = 0) :
    ∃ Z : Finset ℝ, Z.card = s.card ∧
      (∀ x ∈ Z, p.eval x = 0 ∧ x < 0) ∧
      (∀ k, -lattice d k ∉ Z) := by
  classical
  choose r hr using fun j : s => he j j.property
  let Z : Finset ℝ := s.attach.image r
  have hinj : Function.Injective r := by
    intro j k heq
    apply Subtype.ext
    by_contra hn
    rcases lt_or_gt_of_ne hn with hjk | hkj
    · have ha := (lattice_strictMono d).monotone (show j.val+1 ≤ k.val by omega)
      have hj := (hr j).1.1
      have hk := (hr k).1.2
      rw [heq] at hj
      linarith
    · have ha := (lattice_strictMono d).monotone (show k.val+1 ≤ j.val by omega)
      have hj := (hr j).1.2
      have hk := (hr k).1.1
      rw [heq] at hj
      linarith
  refine ⟨Z, ?_, ?_, ?_⟩
  · simp only [Z, card_image_of_injective _ hinj, card_attach]
  · intro x hx
    obtain ⟨j, _, rfl⟩ := mem_image.mp hx
    have hn : 0 ≤ lattice d j := by
      simpa using (lattice_strictMono d).monotone (Nat.zero_le j.val)
    exact ⟨(hr j).2, lt_of_lt_of_le (hr j).1.2 (neg_nonpos.mpr hn)⟩
  · intro k hk
    obtain ⟨j, _, hj⟩ := mem_image.mp hk
    have hgap := (hr j).1
    rw [hj] at hgap
    exact no_node_in_gap d j k hgap

/-- A full set of distinct negative roots exhausts the degree, hence also
proves splitting and excludes all other roots. -/
theorem certify_roots (p : ℝ[X]) (hp : p ≠ 0) (Z : Finset ℝ)
    (hc : Z.card = p.natDegree) (hz : ∀ x ∈ Z, p.eval x = 0 ∧ x < 0) :
    p.Splits ∧ ∀ x : ℝ, p.eval x = 0 → x < 0 := by
  classical
  have hs : Z ⊆ p.roots.toFinset := by
    intro x hx
    exact Multiset.mem_toFinset.mpr ((mem_roots hp).mpr (hz x hx).1)
  have h1 := Finset.card_le_card hs
  have h2 := p.roots.toFinset_card_le
  have h3 := p.card_roots'
  have he : Z = p.roots.toFinset := Finset.eq_of_subset_of_card_le hs (by omega)
  refine ⟨splits_iff_card_roots.mpr (by omega), ?_⟩
  intro x hx
  have hm : x ∈ Z := by
    rw [he]
    exact Multiset.mem_toFinset.mpr ((mem_roots hp).mpr hx)
  exact (hz x hm).2

theorem strict_threshold_certificate (p : ℝ[X]) (m d l : ℕ)
    (hm : 0 < m) (hd : 0 < d) (hl : l < m)
    (ht : lattice d l < (m : ℝ)*d ∧ (m : ℝ)*d < lattice d (l+1))
    (he : ∀ k, k ≤ m → p.eval (-lattice d k) = nodeValue m d k)
    (hp : p ≠ 0) (hdeg : p.natDegree = m-1) :
    p.Splits ∧ ∀ x : ℝ, p.eval x = 0 → x < 0 := by
  classical
  let s := (range m).erase l
  have hgap : ∀ j ∈ s, ∃ x ∈ Set.Ioo (-lattice d (j+1)) (-lattice d j), p.eval x = 0 := by
    intro j hj
    have hjm : j < m := mem_range.mp (mem_erase.mp hj).2
    have hjl : j ≠ l := (mem_erase.mp hj).1
    apply lattice_interval_root p m d j hm hd he hjm
    rcases lt_or_gt_of_ne hjl with h | h
    · left
      exact lt_of_le_of_lt ((lattice_strictMono d).monotone (by omega : j+1 ≤ l)) ht.1
    · right
      exact lt_of_lt_of_le ht.2 ((lattice_strictMono d).monotone (by omega : l+1 ≤ j))
  obtain ⟨Z,hc,hz,_⟩ := gap_root_set p d s hgap
  apply certify_roots p hp Z _ hz
  rw [hc, hdeg]
  simpa [s] using card_erase_of_mem (mem_range.mpr hl)

#print axioms strict_threshold_certificate
#print axioms gap_root_set
end MathDB339675
