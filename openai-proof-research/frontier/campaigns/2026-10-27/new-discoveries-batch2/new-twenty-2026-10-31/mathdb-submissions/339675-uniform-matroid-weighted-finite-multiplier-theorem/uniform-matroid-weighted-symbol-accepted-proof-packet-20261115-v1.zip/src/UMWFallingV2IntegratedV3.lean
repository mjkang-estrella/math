import UMWSumsV2IntegratedV3
import Mathlib.Data.Nat.Factorial.BigOperators
import Mathlib.Algebra.BigOperators.Intervals
namespace MathDB339675
open Finset

theorem fallingChoose_nat (n h : ℕ) : fallingChoose (n : ℝ) h = (n.choose h : ℝ) := by
  unfold fallingChoose
  by_cases hh : h ≤ n
  · have he : ∏ k ∈ range h, ((n : ℝ) - k) = (n.descFactorial h : ℝ) := by
      rw [Nat.descFactorial_eq_prod_range, Nat.cast_prod]
      apply prod_congr rfl
      intro k hk
      rw [Nat.cast_sub (by have := mem_range.mp hk; omega)]
    rw [he, Nat.descFactorial_eq_factorial_mul_choose, Nat.cast_mul]
    exact mul_div_cancel_left₀ _ (Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero h))
  · have hn : n < h := by omega
    have he : ∏ k ∈ range h, ((n : ℝ) - k) = 0 := by
      exact prod_eq_zero (mem_range.mpr hn) (sub_self (n : ℝ))
    rw [he, zero_div, Nat.choose_eq_zero_of_lt hn, Nat.cast_zero]

theorem fallingChoose_reflect (x : ℝ) (h : ℕ) :
    fallingChoose ((h : ℝ)-x-1) h = (-1 : ℝ)^h * fallingChoose x h := by
  unfold fallingChoose
  have he : ∏ k ∈ range h, ((h : ℝ)-x-1-k) =
      (-1 : ℝ)^h * ∏ k ∈ range h, (x-k) := by
    calc
      _ = ∏ k ∈ range h, (-1 : ℝ) * (x - (h-1-k : ℕ)) := by
        apply prod_congr rfl
        intro k hk
        have hk' := mem_range.mp hk
        rw [Nat.cast_sub (by omega : k ≤ h-1), Nat.cast_sub (by omega : 1 ≤ h)]
        push_cast
        ring
      _ = _ := by rw [prod_mul_distrib, prod_const, card_range, prod_range_reflect (fun k => x - (k : ℝ)) h]
  rw [he, mul_div_assoc]

theorem fallingChoose_negative_grid (j h : ℕ) :
    fallingChoose ((h : ℝ)-(j : ℝ)-1) h = (-1 : ℝ)^h * (j.choose h : ℝ) := by
  rw [fallingChoose_reflect, fallingChoose_nat]

#print axioms fallingChoose_nat
#print axioms fallingChoose_negative_grid
end MathDB339675
