import UMWNegativeClosedV3IntegratedV3
namespace MathDB339675

theorem b_negative_node (m d j : ℕ) (hm : 0 < m) (hd : 0 < d) (hj : j ≤ m) :
    b m d (-(j : ℝ)) = nodeValue m d j := by
  have hA : d+j-1+1 = d+j := by omega
  have hc1 : (d+j).choose (d+j-1-j) = (d+j).choose (j+1) := by
    rw [show d+j-1-j = (d+j)-(j+1) by omega]
    exact Nat.choose_symm (by omega)
  have hc2 : (d+j).choose (d+j-j) = (d+j).choose j := by
    exact Nat.choose_symm (by omega)
  have h1 := Nat.add_one_mul_choose_eq (d+j-1) j
  rw [hA] at h1
  have h2 := Nat.choose_mul_succ_eq (d+j-1) j
  rw [hA, show d+j-j = d by omega] at h2
  have h1' : ((j : ℝ)+1) * ((d+j).choose (j+1) : ℝ) =
      ((d : ℝ)+j) * ((d+j-1).choose j : ℝ) := by
    norm_cast
    nlinarith only [h1]
  have h2' : ((d+j).choose j : ℝ) * (d : ℝ) =
      ((d : ℝ)+j) * ((d+j-1).choose j : ℝ) := by
    norm_cast
    nlinarith only [h2]
  have hd' : (d : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hA' : (d : ℝ)+(j : ℝ) ≠ 0 := by positivity
  have he1 : ((j : ℝ)+1) * ((d+j).choose (j+1) : ℝ) / ((d : ℝ)+j) =
      ((d+j-1).choose j : ℝ) := by
    apply (div_eq_iff hA').mpr
    nlinarith only [h1']
  have he2 : ((d+j).choose j : ℝ) =
      (((d : ℝ)+j) * ((d+j-1).choose j : ℝ)) / d := by
    exact (eq_div_iff hd').mpr h2'
  rw [b_negative_closed m d j hm hd hj, hc1, hc2]
  rw [he1, he2]
  unfold nodeValue lattice
  ring

#print axioms b_negative_node
end MathDB339675
