import UMWGridV1IntegratedV3
import Mathlib.Algebra.Polynomial.BigOperators
namespace MathDB339675
open Polynomial Finset
theorem affine_factor (a c k : ℝ) (ha : a ≠ 0) :
    C a * X + C c - C k = C a * (X + C ((c-k)/a)) := by
  rw [mul_add, ← C_mul]
  have he : a * ((c-k)/a) = c-k := by field_simp
  rw [he, C_sub]
  ring
theorem fallingPoly_affine_degree (a c : ℝ) (ha : a ≠ 0) (h : ℕ) :
    (fallingPoly (C a * X + C c) h).natDegree = h ∧
    (fallingPoly (C a * X + C c) h).leadingCoeff = a^h / (h.factorial:ℝ) := by
  have hf : ∀ k : ℕ, (C a * X + C c - C (k:ℝ)).natDegree = 1 ∧
      (C a * X + C c - C (k:ℝ)).leadingCoeff = a := by
    intro k
    rw [affine_factor a c k ha]
    constructor
    · rw [natDegree_C_mul ha, natDegree_X_add_C]
    · rw [leadingCoeff_mul, leadingCoeff_C, leadingCoeff_X_add_C, mul_one]
  have hz : ∀ k : ℕ, C a * X + C c - C (k:ℝ) ≠ 0 := by
    intro k hk
    have hh := (hf k).2
    rw [hk, leadingCoeff_zero] at hh
    exact ha hh.symm
  have hp : (∏ k ∈ range h, (C a * X + C c - C (k:ℝ))) ≠ 0 :=
    prod_ne_zero_iff.mpr (fun k _ => hz k)
  have hd : (∏ k ∈ range h, (C a * X + C c - C (k:ℝ))).natDegree = h := by
    rw [natDegree_prod _ _ (fun k _ => hz k)]
    simp only [(hf _).1, sum_const, card_range, smul_eq_mul, mul_one]
  have hl : (∏ k ∈ range h, (C a * X + C c - C (k:ℝ))).leadingCoeff = a^h := by
    rw [leadingCoeff_prod]
    simp only [(hf _).2, prod_const, card_range]
  have hfact : (h.factorial:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero h)
  constructor
  · unfold fallingPoly
    rw [natDegree_C_mul (one_div_ne_zero hfact), hd]
  · unfold fallingPoly
    rw [leadingCoeff_mul, leadingCoeff_C, hl]
    ring
#print axioms fallingPoly_affine_degree
end MathDB339675
