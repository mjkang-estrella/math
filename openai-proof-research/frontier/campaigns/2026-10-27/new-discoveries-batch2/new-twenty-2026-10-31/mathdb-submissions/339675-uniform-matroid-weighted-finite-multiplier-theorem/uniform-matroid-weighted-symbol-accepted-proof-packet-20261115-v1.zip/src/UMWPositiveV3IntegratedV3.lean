import UMWEncodingV3IntegratedV3
import UMWSourceBridgeIntegratedV1
namespace MathDB339675
open Finset
noncomputable def positiveSummand (m d q h : ℕ) : ℝ :=
  (-(d+q : ℝ)/((h:ℝ)+1) + (d+q+1:ℝ)/m) *
  (-1:ℝ)^h * (q.choose h : ℝ) * ((d+q+h).choose (d+q) : ℝ)

theorem b_positive_sum (m d q : ℕ) (hm : 0 < m) :
    b m d (d+q+1 : ℝ) = ∑ h ∈ range m, positiveSummand m d q h := by
  unfold b
  apply sum_congr rfl
  intro h _
  have hm' : (m:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hh : (h:ℝ)+1 ≠ 0 := by positivity
  have hf : (d+q+1:ℝ)-1+h = ((d+q+h:ℕ):ℝ) := by push_cast; ring
  have hg : (d:ℝ)-(d+q+1)+h = (h:ℝ)-(q:ℝ)-1 := by ring
  rw [hf, hg, fallingChoose_nat, fallingChoose_negative_grid]
  have hc : (d+q+h).choose h = (d+q+h).choose (d+q) := by
    simpa using (Nat.choose_symm (by omega : h ≤ d+q+h)).symm
  rw [hc]
  unfold positiveSummand
  field_simp
  ring

theorem b_positive_trimmed (m d q : ℕ) (hm : 0 < m) (hq : q < m) :
    b m d (d+q+1 : ℝ) = ∑ h ∈ range (q+1), positiveSummand m d q h := by
  rw [b_positive_sum m d q hm]
  symm
  apply sum_subset (range_mono (by omega : q+1 ≤ m))
  intro h _ hh
  have hqh : q < h := by simp only [mem_range, not_lt] at hh; omega
  simp [positiveSummand, Nat.choose_eq_zero_of_lt hqh]

theorem b_positive_closed (m d q : ℕ) (hm : 0 < m) (hd : 0 < d) (hq : q < m) :
    b m d (d+q+1 : ℝ) =
      (-1:ℝ)^q * (-((d+q).choose (d-1):ℝ) +
        (d+q+1:ℝ)/m * ((d+q).choose d:ℝ)) := by
  rw [b_positive_trimmed m d q hm hq]
  have hs := signed_choose_sum (d+q) (d+q) q (by omega)
  have ht := signed_divided_choose_sum (d+q) q (by omega)
  have he : (∑ h ∈ range (q+1), positiveSummand m d q h) =
      -(d+q:ℝ) * (∑ h ∈ range (q+1), (-1:ℝ)^h * (q.choose h:ℝ) *
          (((d+q+h).choose (d+q):ℝ) / ((h:ℝ)+1))) +
      (d+q+1:ℝ)/m * (∑ h ∈ range (q+1), (-1:ℝ)^h * (q.choose h:ℝ) *
          ((d+q+h).choose (d+q):ℝ)) := by
    rw [mul_sum, mul_sum, ← sum_add_distrib]
    apply sum_congr rfl
    intro h _
    unfold positiveSummand
    ring
  rw [he, hs, ht]
  have hdq : (d+q:ℝ) ≠ 0 := by positivity
  rw [show d+q-1-q = d-1 by omega, show d+q-q = d by omega]
  push_cast
  field_simp
#print axioms b_positive_closed
end MathDB339675
