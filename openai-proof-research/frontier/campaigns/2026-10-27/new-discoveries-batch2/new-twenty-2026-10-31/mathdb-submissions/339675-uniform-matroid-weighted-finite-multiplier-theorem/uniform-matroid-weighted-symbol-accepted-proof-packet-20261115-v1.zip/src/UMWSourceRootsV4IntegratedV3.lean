import UMWPairedCompositionV3IntegratedV3
namespace MathDB339675
open Polynomial Finset
theorem pairedB_nonzero (m d : ℕ) (hm : 0 < m) : pairedB m d ≠ 0 := by
  intro hz
  have he := pairedB_eval m d 0 hm
  simp [hz, nodeValue] at he
theorem pairedB_exact_degree (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    (pairedB m d).natDegree = m-1 := by
  have he := sourceP_eq_pairedB m d hm hd
  have hp := (sourceP_exact_degree m d hm).1
  have hq := quadraticMap_degree_le d
  have hb := pairedB_degree_le m d
  have hc := natDegree_comp_le (p := pairedB m d) (q := quadraticMap d)
  have hm2 := Nat.mul_le_mul_left (pairedB m d).natDegree hq
  rw [← he, hp] at hc
  omega
theorem pairedB_extra_eval (m d j : ℕ) (hm : 0 < m) (hd : 0 < d) (hj : j ≤ m) :
    (pairedB m d).eval (-lattice d j) = nodeValue m d j := by
  have he := (sourceP_paired_evaluations m d j hm hd hj).1
  rw [sourceP_eq_pairedB m d hm hd, eval_comp] at he
  have hmap : (quadraticMap d).eval (-(j:ℝ)) = -lattice d j := by
    simp [quadraticMap, lattice]
  rwa [hmap] at he
theorem pairedB_negative_roots (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    (pairedB m d).Splits ∧ ∀ x : ℝ, (pairedB m d).eval x = 0 → x < 0 := by
  exact quadratic_lattice_certificate _ m d hm hd (fun j hj => pairedB_extra_eval m d j hm hd hj)
    (pairedB_nonzero m d hm) (pairedB_exact_degree m d hm hd)
theorem sourceP_real_roots_exterior (m d : ℕ) (hm : 0 < m) (hd : 0 < d) (x : ℝ)
    (hx : (sourceP m d).eval x = 0) : x < 0 ∨ (d:ℝ) < x := by
  rw [sourceP_eq_pairedB m d hm hd, eval_comp] at hx
  have hneg := (pairedB_negative_roots m d hm hd).2 _ hx
  simp only [quadraticMap, eval_mul, eval_X, eval_sub, eval_C] at hneg
  by_contra hn
  push Not at hn
  have hp := mul_nonneg hn.1 (sub_nonneg.mpr hn.2)
  linarith
#print axioms pairedB_negative_roots
#print axioms sourceP_real_roots_exterior
end MathDB339675
