import UMWSchurPolarV2
namespace MathDB339675
open Polynomial
theorem schur_polarStep_degree (p : ℂ[X]) {n : ℕ} (hn : 0 < n)
    (hd : p.natDegree ≤ n) (w : ℂ) :
    (polarStep p n w).natDegree ≤ n-1 := by
  apply natDegree_le_iff_coeff_eq_zero.mpr
  intro k hk
  have hkn : n ≤ k := by omega
  have hk0 : 0 < k := by omega
  obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (ne_of_gt hk0)
  have hz : p.coeff (j+1+1) = 0 :=
    coeff_eq_zero_of_natDegree_lt (by omega)
  have hc : (polarStep p n w).coeff (j+1) =
      p.coeff (j+1) + (n : ℂ)⁻¹ *
        (w * (p.coeff (j+1+1) * (j+1+1 : ℕ)) -
          p.coeff (j+1) * (j+1 : ℕ)) := by
    simp [polarStep, mul_assoc, sub_mul, mul_sub, coeff_derivative]
  rw [hc, hz]
  by_cases h : n = j+1
  · have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast (ne_of_gt hn)
    rw [← h]
    field_simp
    ring
  · have hh : p.coeff (j+1) = 0 := coeff_eq_zero_of_natDegree_lt (by omega)
    simp [hh]
#print axioms schur_polarStep_degree
end MathDB339675

