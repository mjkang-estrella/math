import UMWSymbolAuditV3AssemblyV1
import UMWSourceSchurAdapterV1
namespace MathDB339675
open Polynomial Finset
open scoped BigOperators
def SourceTarget : Prop := ∀ m d : ℕ, 0 < m → 0 < d → IsDSequence m d
theorem source_target : SourceTarget := by
  intro m d hm hd
  have h := literal_symbol_certificate m d hm hd
  exact source_symbol_schur_adapter m d hm hd h.1 h.2.2.1 h.2.2.2
theorem source_target_expanded :
    ∀ m d : ℕ, 0 < m → 0 < d →
    ∀ f : ℝ[X], f.natDegree ≤ d → (f = 0 ∨ f.Splits) →
    ((∑ i ∈ range (d+1), monomial i (b m d (i : ℝ) * f.coeff i)) = 0 ∨
     (∑ i ∈ range (d+1), monomial i (b m d (i : ℝ) * f.coeff i)).Splits) :=
  source_target
theorem source_target_literal :
    ∀ m d : ℕ, 0 < m → 0 < d →
    ∀ f : ℝ[X], f.natDegree ≤ d → (f = 0 ∨ f.Splits) →
    (let out : ℝ[X] := ∑ i ∈ range (d+1), monomial i
      ((∑ h ∈ range m, (((m : ℝ) + (i : ℝ) * ((h : ℝ) - (m : ℝ) + 1)) /
        (((h : ℝ) + 1) * (m : ℝ))) *
        ((∏ k ∈ range h, ((i : ℝ) - 1 + (h : ℝ) - (k : ℝ))) / (h.factorial : ℝ)) *
        ((∏ k ∈ range h, ((d : ℝ) - (i : ℝ) + (h : ℝ) - (k : ℝ))) / (h.factorial : ℝ))) *
       f.coeff i)
     out = 0 ∨ out.Splits) :=
  source_target
#print source_target
#print source_target_expanded
#print source_target_literal
#print axioms source_target
#print axioms source_target_literal
#print axioms literal_symbol_certificate
#print axioms finite_schur_splits
#print axioms composition_symbol_eq_diagonal
end MathDB339675
