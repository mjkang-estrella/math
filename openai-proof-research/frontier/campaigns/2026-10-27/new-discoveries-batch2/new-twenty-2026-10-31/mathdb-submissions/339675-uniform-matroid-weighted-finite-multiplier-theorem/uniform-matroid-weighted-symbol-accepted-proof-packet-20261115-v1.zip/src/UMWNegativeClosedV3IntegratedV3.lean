import UMWEvaluationV3IntegratedV3
namespace MathDB339675
open Finset

theorem b_negative_closed (m d j : ℕ) (hm : 0 < m) (hd : 0 < d) (hj : j ≤ m) :
    b m d (-(j : ℝ)) = (-1 : ℝ)^j *
      (((j : ℝ)+1) * ((d+j).choose (d+j-1-j) : ℝ) / (d+j : ℝ) -
       (j : ℝ)/m * ((d+j).choose (d+j-j) : ℝ)) := by
  have hc (h : ℕ) : (d+j+h).choose h = (d+j+h).choose (d+j) := by
    simpa using (Nat.choose_symm (by omega : h ≤ d+j+h)).symm
  calc
    _ = ((j : ℝ)+1) * (∑ h ∈ range (j+1), (-1 : ℝ)^h * (j.choose h : ℝ) *
         (((d+j+h).choose (d+j) : ℝ) / ((h : ℝ)+1))) -
        ((j : ℝ)/m) * (∑ h ∈ range (j+1), (-1 : ℝ)^h * (j.choose h : ℝ) *
         ((d+j+h).choose (d+j) : ℝ)) := by
      rw [b_negative_trimmed m d j hm hj, mul_sum, mul_sum, ← sum_sub_distrib]
      apply sum_congr rfl
      intro h _
      unfold negativeSummand
      rw [hc]
      ring
    _ = _ := by
      rw [signed_divided_choose_sum (d+j) j (by omega), signed_choose_sum (d+j) (d+j) j (by omega)]
      push_cast
      ring

#print axioms b_negative_closed
end MathDB339675
