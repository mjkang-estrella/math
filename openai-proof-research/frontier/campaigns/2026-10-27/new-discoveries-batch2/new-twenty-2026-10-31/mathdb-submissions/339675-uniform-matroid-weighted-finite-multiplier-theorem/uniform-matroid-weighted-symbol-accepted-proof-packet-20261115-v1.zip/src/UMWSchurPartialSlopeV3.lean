import UMWSchurPartialV4
namespace MathDB339675
open Polynomial
open scoped BigOperators
noncomputable def partialSlope (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) (j : Fin d) : ℂ[X] :=
  ∑ i ∈ Finset.range (d+1), C (p.coeff i / (d.choose i : ℂ)) *
    ∑ S ∈ (Finset.univ : Finset (Fin d)).powersetCard i,
      if j ∈ S then partialProduct T a (S.erase j) else 0

theorem partialSlope_eval (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) (j : Fin d) (z : ℂ) :
    (partialSlope d p T a j).eval z =
      schurPolarizationSlope d p (fun k => if k ∈ T then a k else z) j := by
  classical
  simp only [partialSlope, schurPolarizationSlope, schurElementarySlope,
    eval_finsetSum, eval_mul, eval_C]
  apply Finset.sum_congr rfl
  intro i hi
  have hh : ∀ S : Finset (Fin d),
    (if j ∈ S then partialProduct T a (S.erase j) else 0).eval z =
      if j ∈ S then ∏ k ∈ S \ {j}, (if k ∈ T then a k else z) else 0 := by
    intro S
    split_ifs <;> simp [partialProduct, partialFactor, Finset.sdiff_singleton_eq_erase, eval_prod, apply_ite (eval z)]
  simp_rw [hh]
  ring

theorem partialPoly_insert (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) (j : Fin d) (hj : j ∉ T) :
    partialPoly d p (insert j T) a =
      partialPoly d p T a + (C (a j)-X) * partialSlope d p T a j := by
  classical
  apply Polynomial.funext
  intro z
  simp only [eval_add, eval_mul, eval_sub, eval_C, eval_X, partialPoly_eval,
    partialSlope_eval]
  have he : (fun k => if k ∈ insert j T then a k else z) =
      Function.update (fun k => if k ∈ T then a k else z) j (a j) := by
    funext k
    by_cases h : k = j
    · subst k; simp
    · simp [h]
  rw [he, schurPolarization_update]
  simp [hj]

theorem partialProduct_derivative {d : ℕ} (T S : Finset (Fin d))
    (a : Fin d → ℂ) :
    (partialProduct T a S).derivative =
      ∑ j ∈ (Finset.univ \ T), if j ∈ S then partialProduct T a (S.erase j) else 0 := by
  classical
  rw [partialProduct, derivative_prod_finset]
  calc
    _ = ∑ j ∈ S, if j ∈ T then 0 else partialProduct T a (S.erase j) := by
      apply Finset.sum_congr rfl
      intro j hj
      by_cases ht : j ∈ T <;> simp [partialFactor, ht, partialProduct]
    _ = ∑ j ∈ (Finset.univ : Finset (Fin d)),
        if j ∈ S then (if j ∈ T then 0 else partialProduct T a (S.erase j)) else 0 := by
      simp only [Finset.sum_ite_mem, Finset.univ_inter]
    _ = ∑ j ∈ (Finset.univ : Finset (Fin d)),
        if j ∉ T then (if j ∈ S then partialProduct T a (S.erase j) else 0) else 0 := by
      apply Finset.sum_congr rfl
      intro j hj
      by_cases hs : j ∈ S <;> by_cases ht : j ∈ T <;> simp [hs, ht]
    _ = _ := by
      rw [← Finset.sum_filter]
      congr 1
      ext x
      simp

theorem partialPoly_derivative_sum (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) :
    (partialPoly d p T a).derivative =
      ∑ j ∈ (Finset.univ \ T), partialSlope d p T a j := by
  classical
  unfold partialPoly partialSlope
  simp only [derivative_sum, derivative_mul, derivative_C, zero_mul, zero_add,
    partialProduct_derivative, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  rw [Finset.sum_comm]
end MathDB339675
