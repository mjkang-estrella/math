import UMWSchurNegativeFactorsV3
namespace MathDB339675
open Polynomial
open scoped BigOperators
theorem schur_negative_factor_fin (d : ℕ) (g : ℝ[X])
    (hd : g.natDegree = d) (hg : g.Splits)
    (hr : ∀ r : ℝ, g.eval r = 0 → r < 0) :
    ∃ s : Fin d → ℝ, (∀ j, 0 < s j) ∧
      g = C (g.eval 0) * ∏ j, ((1 : ℝ[X])+C ((s j)⁻¹)*X) := by
  obtain ⟨ls, hlen, hpos, heq⟩ := schur_negative_factor_list d g hd hg hr
  clear hd
  subst d
  refine ⟨ls.get, fun j => hpos _ (List.get_mem ls j), ?_⟩
  have hh : (∏ j : Fin ls.length, ((1 : ℝ[X])+C ((ls.get j)⁻¹)*X)) =
      (ls.map (fun t => (1 : ℝ[X])+C (t⁻¹)*X)).prod := by
    rw [← List.prod_ofFn]
    change (List.ofFn ((fun t : ℝ => (1 : ℝ[X])+C (t⁻¹)*X) ∘ ls.get)).prod = _
    rw [← List.map_ofFn, List.ofFn_get]
  rw [hh]
  exact heq
#print axioms schur_negative_factor_fin
end MathDB339675
