import UMWSourceDefinitionsV1
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
namespace MathDB339675
open Polynomial Finset
theorem coeff_weightedComposition (d i : ℕ) (f g : ℝ[X]) :
    (weightedComposition d f g).coeff i =
    if i ≤ d then f.coeff i * g.coeff i / (d.choose i : ℝ) else 0 := by
  classical
  simp [weightedComposition, coeff_monomial]

theorem composition_symbol_eq_diagonal (m d : ℕ) (f : ℝ[X]) :
    weightedComposition d f (symbol m d) = diagonal m d f := by
  ext i
  rw [coeff_weightedComposition, coeff_diagonal]
  by_cases hi : i ≤ d
  · rw [ite_eq_left_iff.mpr (fun h => False.elim (h hi)), coeff_symbol]
    simp only [hi, ite_true]
    have hc : (d.choose i : ℝ) ≠ 0 := ne_of_gt (by exact_mod_cast Nat.choose_pos hi)
    field_simp
  · simp [hi]

#print axioms composition_symbol_eq_diagonal
end MathDB339675
