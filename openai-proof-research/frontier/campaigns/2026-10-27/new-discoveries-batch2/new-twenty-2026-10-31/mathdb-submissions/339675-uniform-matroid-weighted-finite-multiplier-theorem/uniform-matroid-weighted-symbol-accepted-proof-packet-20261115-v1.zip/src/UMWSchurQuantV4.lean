import UMWSchurQuantV2
namespace MathDB339675
open Polynomial
theorem schur_recip_quant {z w : ℂ} (hz : 0 < z.im) (hw : w.im ≤ 0) :
    z.im * Complex.normSq (1 / (z-w)) ≤ -(1/(z-w)).im := by
  have hn : 0 < Complex.normSq (z-w) := by
    apply Complex.normSq_pos.mpr
    intro he
    have hi : (z-w).im = 0 := by rw [he]; rfl
    simp only [Complex.sub_im] at hi
    linarith
  rw [one_div, Complex.normSq_inv, Complex.inv_im]
  simp only [Complex.sub_im]
  rw [← div_eq_mul_inv]
  apply (div_le_iff₀ hn).2
  have hh : -( -(z.im-w.im) / Complex.normSq (z-w)) * Complex.normSq (z-w) =
      z.im-w.im := by field_simp
  rw [hh]
  linarith

theorem schur_sum_recip_quant (s : Multiset ℂ) {z : ℂ}
    (hz : 0 < z.im) (hs : ∀ w ∈ s, w.im ≤ 0) :
    z.im * (s.map (fun w => Complex.normSq (1/(z-w)))).sum ≤
      -((s.map (fun w => 1/(z-w))).sum).im := by
  induction s using Multiset.induction_on with
  | empty => simp
  | cons w s ih =>
    have hw := schur_recip_quant hz (hs w (by simp))
    have ht := ih (fun v hv => hs v (by simp [hv]))
    simp only [Multiset.map_cons, Multiset.sum_cons, Complex.add_im]
    nlinarith

theorem schur_logDerivative_quant {p : ℂ[X]} (hp : SchurUpperStable p)
    {n : ℕ} (_hn : 0 < n) (hd : p.natDegree ≤ n)
    {z : ℂ} (hz : 0 < z.im) :
    z.im * Complex.normSq (p.derivative.eval z / p.eval z) ≤
      (n : ℝ) * -(p.derivative.eval z / p.eval z).im := by
  have hp0 := schur_upperStable_ne_zero hp
  have hs := IsAlgClosed.splits p
  have hr : ∀ w ∈ p.roots, w.im ≤ 0 := by
    intro w hw
    by_contra h
    exact hp w (lt_of_not_ge h) ((mem_roots hp0).mp hw)
  rw [hs.eval_derivative_div_eval_of_ne_zero (hp z hz)]
  have hq := schur_sum_recip_quant p.roots hz hr
  have hc := schur_normSq_sum_le (p.roots.map (fun w => 1/(z-w)))
  simp only [Multiset.card_map, Multiset.map_map, Function.comp_def] at hc
  have hcard : p.roots.card = p.natDegree := hs.natDegree_eq_card_roots.symm
  have hneg : 0 ≤ -((p.roots.map (fun w => 1/(z-w))).sum).im :=
    neg_nonneg.mpr (schur_sum_recip_im_nonpos p.roots hz hr)
  have hn' : (p.roots.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast (hcard ▸ hd)
  have hc0 : (0 : ℝ) ≤ p.roots.card := Nat.cast_nonneg _
  have ha := mul_le_mul_of_nonneg_left hc (le_of_lt hz)
  have hb := mul_le_mul_of_nonneg_left hq hc0
  have hh := mul_le_mul_of_nonneg_right hn' hneg
  nlinarith
theorem schur_logDerivative_ne_zero {p : ℂ[X]} (hp : SchurUpperStable p)
    (hd : p.natDegree ≠ 0) {z : ℂ} (hz : 0 < z.im) :
    p.derivative.eval z / p.eval z ≠ 0 := by
  have hi := schur_logDerivative_im_neg (schur_upperStable_ne_zero hp)
    (IsAlgClosed.splits p) hd (by
      intro w hw
      by_contra h
      exact hp w (lt_of_not_ge h) ((mem_roots (schur_upperStable_ne_zero hp)).mp hw)) hz
  intro h
  simp [h] at hi
#print axioms schur_logDerivative_quant
#print axioms schur_logDerivative_ne_zero
end MathDB339675

