import UMWSchurDegreeV2
import Mathlib.Data.Finset.Powerset
import Mathlib.Algebra.Polynomial.Eval.Degree
namespace MathDB339675
open Polynomial
open scoped BigOperators
noncomputable def schurElementary (d i : ℕ) (z : Fin d → ℂ) : ℂ :=
  ∑ s ∈ (Finset.univ : Finset (Fin d)).powersetCard i, ∏ j ∈ s, z j
noncomputable def schurPolarization (d : ℕ) (p : ℂ[X]) (z : Fin d → ℂ) : ℂ :=
  ∑ i ∈ Finset.range (d+1), p.coeff i * schurElementary d i z / (d.choose i : ℂ)
theorem schurElementary_diagonal (d i : ℕ) (z : ℂ) :
    schurElementary d i (fun _ => z) = (d.choose i : ℂ) * z^i := by
  unfold schurElementary
  have hh : ∀ s ∈ (Finset.univ : Finset (Fin d)).powersetCard i,
      (∏ _j ∈ s, z) = z^i := by
    intro s hs
    rw [Finset.prod_const, (Finset.mem_powersetCard.mp hs).2]
  simp_rw [Finset.sum_congr rfl hh]
  simp [Finset.card_powersetCard, nsmul_eq_mul]
theorem schurPolarization_diagonal (d : ℕ) (p : ℂ[X])
    (hd : p.natDegree ≤ d) (z : ℂ) :
    schurPolarization d p (fun _ => z) = p.eval z := by
  unfold schurPolarization
  rw [p.eval_eq_sum_range' (n := d+1) (by omega) z]
  apply Finset.sum_congr rfl
  intro i hi
  have hc : (d.choose i : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (Nat.choose_pos (by
      have := Finset.mem_range.mp hi
      omega)))
  rw [schurElementary_diagonal]
  field_simp
noncomputable def schurSpecialize : ℂ[X] → ℕ → List ℂ → ℂ[X]
  | p, _, [] => p
  | p, n, w :: ws => schurSpecialize (polarStep p n w) (n-1) ws

theorem schurSpecialize_stable (ws : List ℂ) (p : ℂ[X]) (n : ℕ)
    (hp : SchurUpperStable p) (hd : p.natDegree ≤ n)
    (hlen : ws.length ≤ n) (hw : ∀ w ∈ ws, 0 < w.im) :
    SchurUpperStable (schurSpecialize p n ws) ∧
      (schurSpecialize p n ws).natDegree ≤ n-ws.length := by
  induction ws generalizing p n with
  | nil => simpa [schurSpecialize] using And.intro hp hd
  | cons w ws ih =>
    have hn : 0 < n := by simp only [List.length_cons] at hlen; omega
    have hwp : 0 < w.im := hw w (by simp)
    have ht := ih (polarStep p n w) (n-1)
      (schur_polarStep_stable hp hn hd hwp)
      (schur_polarStep_degree p hn hd w)
      (by simp only [List.length_cons] at hlen; omega)
      (fun v hv => hw v (by simp [hv]))
    simpa [schurSpecialize, List.length_cons, Nat.sub_sub, Nat.add_comm] using ht
#print axioms schurElementary_diagonal
#print axioms schurPolarization_diagonal
#print axioms schurSpecialize_stable
end MathDB339675

