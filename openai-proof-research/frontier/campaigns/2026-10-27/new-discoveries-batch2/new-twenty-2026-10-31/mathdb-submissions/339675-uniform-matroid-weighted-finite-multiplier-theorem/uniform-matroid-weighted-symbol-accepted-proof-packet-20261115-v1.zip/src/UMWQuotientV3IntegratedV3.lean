import UMWExactDegreeV3IntegratedV3
import Mathlib.LinearAlgebra.Lagrange
namespace MathDB339675
open Polynomial Finset
noncomputable def pairedB (m d : ℕ) : ℝ[X] :=
  Lagrange.interpolate (range m) (fun j => -lattice d j) (nodeValue m d)
theorem lattice_nodes_injective (d : ℕ) : Function.Injective (fun j => -lattice d j) := by
  intro i j h
  exact (lattice_strictMono d).injective (neg_injective h)
theorem pairedB_eval (m d j : ℕ) (hj : j < m) :
    (pairedB m d).eval (-lattice d j) = nodeValue m d j := by
  exact Lagrange.eval_interpolate_at_node _ (lattice_nodes_injective d).injOn (mem_range.mpr hj)
theorem pairedB_degree_le (m d : ℕ) :
    (pairedB m d).natDegree ≤ m-1 := by
  apply natDegree_le_of_degree_le
  simpa [pairedB] using
    Lagrange.degree_interpolate_le (s := range m) (nodeValue m d) (lattice_nodes_injective d).injOn
noncomputable def pairedNode (d : ℕ) (i : Fin m × Bool) : ℝ :=
  if i.2 then (d:ℝ)+i.1 else -(i.1:ℝ)
theorem pairedNode_injective (m d : ℕ) (hd : 0 < d) :
    Function.Injective (pairedNode (m := m) d) := by
  rintro ⟨i,bi⟩ ⟨j,bj⟩ h
  have hd' : (0:ℝ) < d := Nat.cast_pos.mpr hd
  have hi : (0:ℝ) ≤ i := Nat.cast_nonneg i.val
  have hj : (0:ℝ) ≤ j := Nat.cast_nonneg j.val
  cases bi <;> cases bj
  · have he : (i:ℝ) = j := by simpa [pairedNode] using h
    have hij : i = j := Fin.ext (by exact_mod_cast he)
    subst j; rfl
  · simp [pairedNode] at h
    linarith
  · simp [pairedNode] at h
    linarith
  · have he : (i:ℝ) = j := by simpa [pairedNode] using h
    have hij : i = j := Fin.ext (by exact_mod_cast he)
    subst j; rfl
#print axioms pairedB_eval
end MathDB339675
