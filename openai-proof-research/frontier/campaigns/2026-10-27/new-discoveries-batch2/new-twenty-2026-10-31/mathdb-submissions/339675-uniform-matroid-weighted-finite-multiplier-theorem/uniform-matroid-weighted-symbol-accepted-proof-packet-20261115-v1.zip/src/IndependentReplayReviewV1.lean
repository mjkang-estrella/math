import UMWFinalSourceAssemblyV1
namespace MathDB339675
open Polynomial Finset
open scoped BigOperators
theorem independent_expanded_source_endpoint :
    ∀ m d : ℕ, 0 < m → 0 < d →
    ∀ f : ℝ[X], f.natDegree ≤ d → (f = 0 ∨ f.Splits) →
    (let out : ℝ[X] := ∑ i ∈ range (d+1), monomial i
      ((∑ h ∈ range m, (((m : ℝ) + (i : ℝ) * ((h : ℝ) - (m : ℝ) + 1)) /
        (((h : ℝ) + 1) * (m : ℝ))) *
        ((∏ k ∈ range h, ((i : ℝ) - 1 + (h : ℝ) - (k : ℝ))) / (h.factorial : ℝ)) *
        ((∏ k ∈ range h, ((d : ℝ) - (i : ℝ) + (h : ℝ) - (k : ℝ))) / (h.factorial : ℝ))) *
       f.coeff i)
     out = 0 ∨ out.Splits) := source_target_literal

theorem independent_alias_expansion : SourceTarget = (∀ m d : ℕ, 0 < m → 0 < d → ∀ f : ℝ[X], f.natDegree ≤ d → (f = 0 ∨ f.Splits) → (diagonal m d f = 0 ∨ (diagonal m d f).Splits)) := rfl

#print independent_expanded_source_endpoint
#print independent_alias_expansion
#print fallingChoose
#print b
#print symbol
#print diagonal
#print IsDSequence
#print SourceTarget
#print weightedComposition
#print axioms independent_expanded_source_endpoint
#print axioms source_target
#print axioms source_target_literal
#print axioms literal_symbol_certificate
#print axioms finite_schur_splits
#print axioms composition_symbol_eq_diagonal
end MathDB339675
