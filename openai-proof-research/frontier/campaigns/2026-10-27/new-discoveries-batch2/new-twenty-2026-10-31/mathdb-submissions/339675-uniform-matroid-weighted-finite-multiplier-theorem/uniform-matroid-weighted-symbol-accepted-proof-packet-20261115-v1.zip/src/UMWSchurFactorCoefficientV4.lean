import UMWSchurCoefficientAlgebraV1
namespace MathDB339675
open Polynomial
open scoped BigOperators
theorem schur_factor_coeff (d i : ℕ) (g : ℝ[X]) (s : Fin d → ℝ)
    (heq : g = C (g.eval 0) * ∏ j, ((1 : ℝ[X])+C ((s j)⁻¹)*X)) :
    ((g.coeff i : ℝ) : ℂ) =
      ((g.eval 0 : ℝ) : ℂ) * schurElementary d i (fun j => ((s j : ℂ)⁻¹)) := by
  have hm : g.map (algebraMap ℝ ℂ) =
      C ((g.eval 0 : ℝ) : ℂ) * ∏ j, ((1 : ℂ[X])+C ((s j : ℂ)⁻¹)*X) := by
    conv_lhs => rw [heq]
    simp only [Polynomial.map_mul, Polynomial.map_C, Polynomial.map_prod,
      Polynomial.map_add, Polynomial.map_one, Polynomial.map_X, Complex.coe_algebraMap,
      Complex.ofReal_inv]
  have hc := congrArg (fun q : ℂ[X] => q.coeff i) hm
  simpa only [coeff_map, coeff_C_mul, schur_product_coeff, Complex.coe_algebraMap] using hc

end MathDB339675
