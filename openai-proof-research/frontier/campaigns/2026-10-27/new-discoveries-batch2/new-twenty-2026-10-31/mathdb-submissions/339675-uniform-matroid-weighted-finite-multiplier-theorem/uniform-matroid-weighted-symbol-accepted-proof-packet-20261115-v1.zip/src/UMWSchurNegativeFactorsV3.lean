import UMWSchurFullPolarizationV2
import Mathlib.Algebra.BigOperators.Fin
namespace MathDB339675
open Polynomial
open scoped BigOperators
theorem schur_normalized_linear (r : ℝ) (hr : r ≠ 0) :
    C (-r) * (1 + C ((-r)⁻¹) * X) = X-C r := by
  have hn : -r ≠ 0 := neg_ne_zero.mpr hr
  calc
    _ = C (-r) + C ((-r)*(-r)⁻¹) * X := by rw [C_mul]; ring
    _ = _ := by rw [mul_inv_cancel₀ hn]; simp; ring

theorem schur_normalized_root_product (s : Multiset ℝ)
    (hs : ∀ r ∈ s, r ≠ 0) :
    C ((s.map (fun r => -r)).prod) *
      (s.map (fun r => (1 : ℝ[X]) + C ((-r)⁻¹)*X)).prod =
      (s.map (fun r => X-C r)).prod := by
  induction s using Multiset.induction_on with
  | empty => simp
  | @cons r s ih =>
    have hr := hs r (by simp)
    have ht : ∀ t ∈ s, t ≠ 0 := fun t ht => hs t (by simp [ht])
    simp only [Multiset.map_cons, Multiset.prod_cons, C_mul]
    calc
      _ = (C (-r) * (1+C ((-r)⁻¹)*X)) *
          (C ((s.map (fun t => -t)).prod) *
            (s.map (fun t => (1 : ℝ[X])+C ((-t)⁻¹)*X)).prod) := by ring
      _ = _ := by rw [schur_normalized_linear r hr, ih ht]

theorem schur_negative_root_factorization (g : ℝ[X]) (hg : g.Splits)
    (hr : ∀ r : ℝ, g.eval r = 0 → r < 0) :
    g = C (g.eval 0) *
      (g.roots.map (fun r => (1 : ℝ[X]) + C ((-r)⁻¹)*X)).prod := by
  have hroots : ∀ r ∈ g.roots, r ≠ 0 := by
    intro r hm
    exact ne_of_lt (hr r ((isRoot_of_mem_roots hm)))
  have he : g.eval 0 = g.leadingCoeff * (g.roots.map (fun r => -r)).prod := by
    simpa using hg.eval_eq_prod_roots 0
  rw [he, C_mul, mul_assoc, schur_normalized_root_product g.roots hroots]
  exact hg.eq_prod_roots

theorem schur_negative_factor_list (d : ℕ) (g : ℝ[X])
    (hd : g.natDegree = d) (hg : g.Splits)
    (hr : ∀ r : ℝ, g.eval r = 0 → r < 0) :
    ∃ s : List ℝ, s.length = d ∧ (∀ t ∈ s, 0 < t) ∧
      g = C (g.eval 0) * (s.map (fun t => (1 : ℝ[X]) + C (t⁻¹)*X)).prod := by
  let s := g.roots.toList.map (fun r => -r)
  refine ⟨s, ?_, ?_, ?_⟩
  · simp only [s, List.length_map, Multiset.length_toList]
    rw [← hg.natDegree_eq_card_roots, hd]
  · intro t ht
    obtain ⟨r, hm, rfl⟩ := List.mem_map.mp ht
    have hm' : r ∈ g.roots := by simpa using hm
    exact neg_pos.mpr (hr r ((isRoot_of_mem_roots hm')))
  · simpa [s, List.map_map, Function.comp_def, ← Multiset.prod_coe, ← Multiset.map_coe] using
      schur_negative_root_factorization g hg hr
end MathDB339675
