import Mathlib.Topology.Algebra.Polynomial
import Mathlib.Algebra.Polynomial.Splits
import Mathlib.Analysis.Polynomial.Basic
import Mathlib.Topology.Order.IntermediateValue
import UMWSourceDefinitionsV1
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp

open scoped BigOperators
open Polynomial Finset
namespace MathDB339675
noncomputable def lattice (d j : ℕ) : ℝ := (j : ℝ) * ((d : ℝ) + j)
noncomputable def nodeValue (m d j : ℕ) : ℝ :=
  (-1 : ℝ)^j * (Nat.choose (d+j-1) j : ℝ) * (1 - lattice d j / ((m : ℝ)*d))
@[simp] theorem fallingChoose_zero (x : ℝ) : fallingChoose x 0 = 1 := by
  simp [fallingChoose]
@[simp] theorem b_one (d : ℕ) (x : ℝ) : b 1 d x = 1 := by
  simp [b]
@[simp] theorem diagonal_zero (m d : ℕ) : diagonal m d 0 = 0 := by
  simp [diagonal]
theorem lattice_step (d j : ℕ) : lattice d (j+1) - lattice d j = (d : ℝ)+2*j+1 := by
  simp only [lattice, Nat.cast_add, Nat.cast_one]; ring
theorem lattice_strictMono (d : ℕ) : StrictMono (lattice d) := by
  apply strictMono_nat_of_lt_succ
  intro j
  have hd : (0 : ℝ) ≤ d := Nat.cast_nonneg d
  have hj : (0 : ℝ) ≤ j := Nat.cast_nonneg j
  have := lattice_step d j
  linarith
@[simp] theorem lattice_zero (d : ℕ) : lattice d 0 = 0 := by simp [lattice]
theorem threshold_bounds (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    0 < (m : ℝ)*d ∧ (m : ℝ)*d < lattice d m := by
  have hm' : (0 : ℝ) < m := Nat.cast_pos.mpr hm
  have hd' : (0 : ℝ) < d := Nat.cast_pos.mpr hd
  constructor
  · positivity
  · dsimp [lattice]; nlinarith [sq_pos_of_pos hm']
theorem nodeValue_eq_zero (m d j : ℕ) (h : lattice d j = (m : ℝ)*d)
    (hm : 0 < m) (hd : 0 < d) : nodeValue m d j = 0 := by
  have hn : (m : ℝ)*(d : ℝ) ≠ 0 := ne_of_gt (threshold_bounds m d hm hd).1
  simp [nodeValue, h, hn]

theorem interval_root (p : ℝ[X]) {a c : ℝ} (hac : a < c)
    (hs : p.eval a * p.eval c < 0) :
    ∃ x ∈ Set.Ioo a c, p.eval x = 0 := by
  have hc := p.continuous.continuousOn (s := Set.Icc a c)
  rcases mul_neg_iff.mp hs with h | h
  · rcases intermediate_value_Ioo' hac.le hc ⟨h.2, h.1⟩ with ⟨x,hx,he⟩
    exact ⟨x,hx,he⟩
  · rcases intermediate_value_Ioo hac.le hc ⟨h.1, h.2⟩ with ⟨x,hx,he⟩
    exact ⟨x,hx,he⟩

#print axioms interval_root
#print axioms threshold_bounds
#print axioms b_one
end MathDB339675
