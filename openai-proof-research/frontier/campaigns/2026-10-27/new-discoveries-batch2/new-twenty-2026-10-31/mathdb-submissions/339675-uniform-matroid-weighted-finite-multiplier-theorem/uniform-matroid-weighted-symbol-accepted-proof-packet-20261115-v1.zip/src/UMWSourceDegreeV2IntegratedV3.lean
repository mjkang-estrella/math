import UMWDegreeV1IntegratedV3
namespace MathDB339675
open Polynomial Finset
noncomputable def sourceSummand (m d h : ℕ) : ℝ[X] :=
  C (1 / (((h:ℝ)+1)*m)) * (C (m:ℝ) + X*C ((h:ℝ)-m+1)) *
  fallingPoly (X-C 1+C (h:ℝ)) h * fallingPoly (C (d:ℝ)-X+C (h:ℝ)) h
theorem source_factors (d h : ℕ) :
    (fallingPoly (X-C 1+C (h:ℝ)) h).natDegree = h ∧
    (fallingPoly (X-C 1+C (h:ℝ)) h).leadingCoeff = 1/(h.factorial:ℝ) ∧
    (fallingPoly (C (d:ℝ)-X+C (h:ℝ)) h).natDegree = h ∧
    (fallingPoly (C (d:ℝ)-X+C (h:ℝ)) h).leadingCoeff = (-1:ℝ)^h/(h.factorial:ℝ) := by
  have he : X-C 1+C (h:ℝ) = C (1:ℝ)*X+C ((h:ℝ)-1) := by
    simp only [C_1, one_mul, C_sub]; ring
  have hf : C (d:ℝ)-X+C (h:ℝ) = C (-1:ℝ)*X+C ((d:ℝ)+h) := by
    simp only [C_neg, C_1, C_add]; ring
  rw [he, hf]
  have h1 := fallingPoly_affine_degree 1 ((h:ℝ)-1) (by norm_num) h
  have h2 := fallingPoly_affine_degree (-1) ((d:ℝ)+h) (by norm_num) h
  have hh := And.intro h1.1 (And.intro h1.2 (And.intro h2.1 h2.2))
  simpa only [one_pow] using hh
theorem sourceSummand_degree_le (m d h : ℕ) :
    (sourceSummand m d h).natDegree ≤ 2*h+1 := by
  have hs := source_factors d h
  unfold sourceSummand
  have hpre : (C (1 / (((h:ℝ)+1)*m)) * (C (m:ℝ) + X*C ((h:ℝ)-m+1))).natDegree ≤ 1 := by
    apply le_trans (natDegree_mul_le)
    have hp := natDegree_add_le (C (m:ℝ)) (X*C ((h:ℝ)-m+1))
    have hq := natDegree_mul_le (p := (X:ℝ[X])) (q := C ((h:ℝ)-m+1))
    simp only [natDegree_C, natDegree_X] at hp hq ⊢
    omega
  have hleft := natDegree_mul_le (p := C (1 / (((h:ℝ)+1)*m)) *
      (C (m:ℝ) + X*C ((h:ℝ)-m+1))) (q := fallingPoly (X-C 1+C (h:ℝ)) h)
  have hwhole := natDegree_mul_le (p := C (1 / (((h:ℝ)+1)*m)) *
      (C (m:ℝ) + X*C ((h:ℝ)-m+1)) * fallingPoly (X-C 1+C (h:ℝ)) h)
      (q := fallingPoly (C (d:ℝ)-X+C (h:ℝ)) h)
  rw [hs.1] at hleft
  rw [hs.2.2.1] at hwhole
  omega
theorem sourceSummand_last (n d : ℕ) :
    sourceSummand (n+1) d n =
      C (1/((n:ℝ)+1)) * fallingPoly (X-C 1+C (n:ℝ)) n *
      fallingPoly (C (d:ℝ)-X+C (n:ℝ)) n := by
  unfold sourceSummand
  have hn : (n:ℝ)+1 ≠ 0 := by positivity
  push_cast
  rw [show (n:ℝ)-((n:ℝ)+1)+1 = 0 by ring, C_0, mul_zero, add_zero, ← C_mul]
  have he : 1/(((n:ℝ)+1)*((n:ℝ)+1))*((n:ℝ)+1) = 1/((n:ℝ)+1) := by field_simp
  rw [he]
#print axioms sourceSummand_degree_le
end MathDB339675
