import Mathlib.Algebra.BigOperators.Field
import UMWDifferenceV1IntegratedV2
namespace MathDB339675
open Finset
open scoped fwdDiff

theorem forward_choose_sum (A r q : ℕ) (hq : q ≤ r) :
    ∑ h ∈ range (q+1), (-1 : ℝ)^(q-h) * (q.choose h : ℝ) *
      ((A+h).choose r : ℝ) = (A.choose (r-q) : ℝ) := by
  have h := fwdDiff_iter_eq_sum_shift (1 : ℕ) (fun x : ℕ => (x.choose r : ℝ)) q A
  have he : (fwdDiff (1 : ℕ))^[q] (fun x : ℕ => (x.choose r : ℝ)) A =
      (A.choose (r-q) : ℝ) := by
    have hh := fwdDiff_iter_choose (R := ℝ) (r-q) q
    rw [Nat.add_sub_of_le hq] at hh
    exact congrFun hh A
  rw [he] at h
  simpa [zsmul_eq_mul, mul_assoc] using h.symm

theorem sign_cancel (q h : ℕ) (hh : h ≤ q) :
    (-1 : ℝ)^q * (-1 : ℝ)^(q-h) = (-1 : ℝ)^h := by
  have hs : (-1 : ℝ)^(q-h)*(-1 : ℝ)^(q-h) = 1 := by rw [← mul_pow]; simp
  calc
    _ = ((-1 : ℝ)^h * (-1 : ℝ)^(q-h)) * (-1 : ℝ)^(q-h) := by
      congr 1
      rw [← pow_add, Nat.add_sub_of_le hh]
    _ = _ := by rw [mul_assoc, hs, mul_one]

theorem signed_choose_sum (A r q : ℕ) (hq : q ≤ r) :
    ∑ h ∈ range (q+1), (-1 : ℝ)^h * (q.choose h : ℝ) *
      ((A+h).choose r : ℝ) = (-1 : ℝ)^q * (A.choose (r-q) : ℝ) := by
  rw [← forward_choose_sum A r q hq, mul_sum]
  apply sum_congr rfl
  intro h hh
  rw [← mul_assoc, ← mul_assoc, sign_cancel q h (by simpa using mem_range.mp hh)]

theorem binomial_div_succ (A h : ℕ) (hA : 0 < A) :
    ((A+h).choose A : ℝ) / ((h : ℝ)+1) =
    ((A+h).choose (A-1) : ℝ) / (A : ℝ) := by
  have hn := Nat.choose_succ_right_eq (A+h) (A-1)
  have h1 : A-1+1 = A := by omega
  have h2 : A+h-(A-1) = h+1 := by omega
  rw [h1,h2] at hn
  have hr : ((A+h).choose A : ℝ) * (A : ℝ) =
      ((A+h).choose (A-1) : ℝ) * ((h : ℝ)+1) := by exact_mod_cast hn
  have ha : (A : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hh : (h : ℝ)+1 ≠ 0 := by positivity
  apply (div_eq_div_iff hh ha).mpr
  exact hr

theorem signed_divided_choose_sum (A q : ℕ) (hq : q < A) :
    ∑ h ∈ range (q+1), (-1 : ℝ)^h * (q.choose h : ℝ) *
      (((A+h).choose A : ℝ) / ((h : ℝ)+1)) =
    (-1 : ℝ)^q * (A.choose (A-1-q) : ℝ) / (A : ℝ) := by
  simp_rw [binomial_div_succ A _ (by omega : 0 < A), ← mul_div_assoc]
  rw [← sum_div, signed_choose_sum A (A-1) q (by omega)]

#print axioms signed_choose_sum
#print axioms signed_divided_choose_sum
end MathDB339675
