import UMWThetaFactorsV2AssemblyV1
namespace MathDB339675
open Polynomial
theorem negativeDegree_C_mul {d : ℕ} {p : ℝ[X]} (h : NegativeDegree d p)
    {a : ℝ} (ha : a ≠ 0) : NegativeDegree d (C a*p) := by
  refine ⟨?_, (Splits.C a).mul h.2.1, ?_⟩
  · rw [natDegree_C_mul ha]; exact h.1
  · intro x hx
    apply h.2.2 x
    simp only [eval_mul, eval_C] at hx
    exact (mul_eq_zero.mp hx).resolve_left ha
theorem thetaAction_exterior_preserves {d : ℕ} (hd : 0<d) (q : ℝ[X])
    (hq : q ≠ 0) (hs : q.Splits)
    (hr : ∀ r : ℝ, q.eval r=0 → r<0 ∨ (d:ℝ)<r)
    {p : ℝ[X]} (h : NegativeDegree d p) :
    NegativeDegree d (thetaAction q p) := by
  have hh := thetaAction_factors_preserves hd q.roots
    (fun r h => hr r ((mem_roots hq).mp h)) h
  rw [hs.eq_prod_roots, thetaAction_mul, thetaAction_C]
  exact negativeDegree_C_mul hh (leadingCoeff_ne_zero.mpr hq)
theorem negativeDegree_seed (d : ℕ) : NegativeDegree d ((1+X)^d) := by
  refine ⟨?_, ?_, ?_⟩
  · rw [add_comm (1:ℝ[X]) X, natDegree_pow, ← C_1, natDegree_X_add_C]
    simp
  · simpa only [C_1, add_comm] using (Splits.X_add_C (1:ℝ)).pow d
  · intro x hx
    simp only [eval_pow, eval_add, eval_one, eval_X] at hx
    have hh : 1+x=0 := by
      by_contra hh
      exact (pow_ne_zero d hh) hx
    linarith
theorem symbol_splits_negative (m d : ℕ) (hm : 0<m) (hd : 0<d) :
    (symbol m d).Splits ∧ ∀ x : ℝ, (symbol m d).eval x=0 → x<0 := by
  have hs := sourceP_splits_exterior m d hm hd
  have hq : sourceP m d ≠ 0 := by
    intro he
    have hh := eval_sourceP m d 0
    rw [he, eval_zero, b_zero m d hm] at hh
    norm_num at hh
  have hh := thetaAction_exterior_preserves hd (sourceP m d) hq hs.1 hs.2
    (negativeDegree_seed d)
  rw [source_theta_seed_eq_symbol] at hh
  exact hh.2
end MathDB339675
