import UMWBaseV1IntegratedV2
namespace MathDB339675
open Polynomial Finset

theorem fallingChoose_pred (h : ℕ) (hh : 0 < h) :
    fallingChoose ((h : ℝ) - 1) h = 0 := by
  unfold fallingChoose
  have hz : ∏ k ∈ range h, ((h : ℝ) - 1 - k) = 0 := by
    apply Finset.prod_eq_zero ((show h-1 ∈ range h from Finset.mem_range.mpr (Nat.sub_lt hh (by omega))))
    have : ((h - 1 : ℕ) : ℝ) = (h : ℝ) - 1 := by rw [Nat.cast_sub (by omega)]; simp
    rw [this]; ring
  rw [hz, zero_div]

theorem b_zero (m d : ℕ) (hm : 0 < m) : b m d 0 = 1 := by
  unfold b
  rw [Finset.sum_eq_single 0]
  · have h : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
    simp [h]
  · intro h _ hn
    have hh : 0 < h := Nat.pos_of_ne_zero hn
    have hz : fallingChoose (-1 + (h : ℝ)) h = 0 := by
      rw [show -1 + (h : ℝ) = (h : ℝ) - 1 by ring]
      exact fallingChoose_pred h hh
    simp [hz]
  · simp [hm]

theorem choose_node_pos (d j : ℕ) (hd : 0 < d) :
    0 < (Nat.choose (d+j-1) j : ℝ) := by
  exact_mod_cast Nat.choose_pos (by omega : j ≤ d+j-1)

theorem nodeValue_mul (m d j : ℕ) :
    nodeValue m d j * nodeValue m d (j+1) =
    - ((Nat.choose (d+j-1) j : ℝ) * (Nat.choose (d+(j+1)-1) (j+1) : ℝ) *
       (1 - lattice d j / ((m : ℝ)*d)) *
       (1 - lattice d (j+1) / ((m : ℝ)*d))) := by
  unfold nodeValue
  rw [pow_succ]
  have h : (-1 : ℝ)^j * (-1 : ℝ)^j = 1 := by
    rw [← mul_pow]; simp
  calc
    _ = -(((-1 : ℝ)^j * (-1 : ℝ)^j) *
      (Nat.choose (d+j-1) j : ℝ) * (Nat.choose (d+(j+1)-1) (j+1) : ℝ) *
      (1 - lattice d j / ((m : ℝ)*d)) *
      (1 - lattice d (j+1) / ((m : ℝ)*d))) := by ring
    _ = _ := by rw [h]; ring

theorem nodeValue_adjacent_neg (m d j : ℕ) (hm : 0 < m) (hd : 0 < d)
    (h : lattice d (j+1) < (m : ℝ)*d ∨ (m : ℝ)*d < lattice d j) :
    nodeValue m d j * nodeValue m d (j+1) < 0 := by
  rw [nodeValue_mul]
  have ht := (threshold_bounds m d hm hd).1
  have hj := lattice_strictMono d (Nat.lt_succ_self j)
  have hc := mul_pos (choose_node_pos d j hd) (choose_node_pos d (j+1) hd)
  apply neg_neg_of_pos
  rcases h with h | h
  · have h1 : 0 < 1 - lattice d j / ((m : ℝ)*d) := by
      have := (div_lt_one ht).mpr (lt_trans hj h); linarith
    have h2 : 0 < 1 - lattice d (j+1) / ((m : ℝ)*d) := by
      have := (div_lt_one ht).mpr h; linarith
    exact mul_pos (mul_pos hc h1) h2
  · have h1 : 1 - lattice d j / ((m : ℝ)*d) < 0 := by
      have := (one_lt_div ht).mpr h; linarith
    have h2 : 1 - lattice d (j+1) / ((m : ℝ)*d) < 0 := by
      have := (one_lt_div ht).mpr (lt_trans h hj); linarith
    exact mul_pos_of_neg_of_neg (mul_neg_of_pos_of_neg hc h1) h2

theorem lattice_interval_root (p : ℝ[X]) (m d j : ℕ) (hm : 0 < m) (hd : 0 < d)
    (he : ∀ k, k ≤ m → p.eval (-lattice d k) = nodeValue m d k)
    (hj : j < m)
    (ht : lattice d (j+1) < (m : ℝ)*d ∨ (m : ℝ)*d < lattice d j) :
    ∃ x ∈ Set.Ioo (-lattice d (j+1)) (-lattice d j), p.eval x = 0 := by
  apply interval_root p (neg_lt_neg (lattice_strictMono d (Nat.lt_succ_self j)))
  rw [he (j+1) (by omega), he j (by omega), mul_comm]
  exact nodeValue_adjacent_neg m d j hm hd ht

#print axioms b_zero
#print axioms nodeValue_adjacent_neg
#print axioms lattice_interval_root
end MathDB339675
