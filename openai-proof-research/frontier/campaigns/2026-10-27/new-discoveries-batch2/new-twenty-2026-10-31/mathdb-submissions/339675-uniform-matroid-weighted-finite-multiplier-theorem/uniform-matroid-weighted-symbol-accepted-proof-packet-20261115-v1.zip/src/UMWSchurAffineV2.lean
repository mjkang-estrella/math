import UMWSchurPolarizationV2
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise
namespace MathDB339675
open Polynomial
open scoped BigOperators
noncomputable def schurElementarySlope (d i : ℕ) (z : Fin d → ℂ) (j : Fin d) : ℂ :=
  ∑ s ∈ (Finset.univ : Finset (Fin d)).powersetCard i,
    if j ∈ s then ∏ k ∈ s \ {j}, z k else 0

theorem schurElementary_update (d i : ℕ) (z : Fin d → ℂ) (j : Fin d) (w : ℂ) :
    schurElementary d i (Function.update z j w) =
      schurElementary d i z + (w-z j) * schurElementarySlope d i z j := by
  classical
  unfold schurElementary schurElementarySlope
  rw [Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro s _hs
  by_cases hj : j ∈ s
  · simp only [hj, ite_true]
    rw [Finset.prod_update_of_mem hj]
    have hh : (∏ k ∈ s, z k) = z j * ∏ k ∈ s \ {j}, z k := by
      simpa using (Finset.prod_update_of_mem hj z (z j))
    rw [hh]
    ring
  · simp only [hj, ite_false]
    rw [Finset.prod_update_of_notMem hj]
    ring

noncomputable def schurPolarizationSlope (d : ℕ) (p : ℂ[X])
    (z : Fin d → ℂ) (j : Fin d) : ℂ :=
  ∑ i ∈ Finset.range (d+1),
    p.coeff i * schurElementarySlope d i z j / (d.choose i : ℂ)

theorem schurPolarization_update (d : ℕ) (p : ℂ[X])
    (z : Fin d → ℂ) (j : Fin d) (w : ℂ) :
    schurPolarization d p (Function.update z j w) =
      schurPolarization d p z + (w-z j) * schurPolarizationSlope d p z j := by
  classical
  unfold schurPolarization schurPolarizationSlope
  rw [Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _hi
  rw [schurElementary_update]
  ring

theorem schurSpecialize_all (ws : List ℂ) (p : ℂ[X])
    (hp : SchurUpperStable p) (hd : p.natDegree ≤ ws.length)
    (hw : ∀ w ∈ ws, 0 < w.im) :
    ∀ z : ℂ, (schurSpecialize p ws.length ws).eval z ≠ 0 := by
  have ht := schurSpecialize_stable ws p ws.length hp hd (le_refl _) hw
  have hd0 : (schurSpecialize p ws.length ws).natDegree = 0 := by omega
  rw [eq_C_of_natDegree_eq_zero hd0]
  intro z
  have hh := ht.1 Complex.I (by simp)
  rw [eq_C_of_natDegree_eq_zero hd0] at hh
  simpa only [eval_C] using hh
#print axioms schurElementary_update
#print axioms schurPolarization_update
#print axioms schurSpecialize_all
end MathDB339675

