import UMWSchurCompositionBridgeV7
import UMWSchurFiniteFactorsV2
namespace MathDB339675
open Polynomial
open scoped BigOperators
theorem finite_schur_splits (d : ℕ) (_hdpos : 0 < d) (f g : ℝ[X])
    (hgd : g.natDegree = d) (hgs : g.Splits)
    (hgr : ∀ r : ℝ, g.eval r = 0 → r < 0)
    (hfd : f.natDegree ≤ d) (hfs : f = 0 ∨ f.Splits) :
    weightedComposition d f g = 0 ∨ (weightedComposition d f g).Splits := by
  by_cases hf : f = 0
  · left
    simp [hf, weightedComposition]
  · right
    apply schur_real_splits_of_upperStable
    obtain ⟨s, hs, heq⟩ := schur_negative_factor_fin d g hgd hgs hgr
    have hg0 : g.eval 0 ≠ 0 := by
      intro h
      have := hgr 0 h
      linarith
    have hgc : ((g.eval 0 : ℝ) : ℂ) ≠ 0 := by exact_mod_cast hg0
    intro z hz
    rw [weightedComposition_eval_polarization d f g s heq z]
    apply mul_ne_zero hgc
    apply schurPolarization_real_nonzero d f hf (hfs.resolve_left hf) hfd
    intro j
    rw [div_eq_mul_inv, ← Complex.ofReal_inv]
    simpa only [Complex.mul_im, Complex.ofReal_re, Complex.ofReal_im,
      mul_zero, zero_add, add_zero] using
      mul_pos hz (inv_pos.mpr (hs j))
#print axioms finite_schur_splits
end MathDB339675
