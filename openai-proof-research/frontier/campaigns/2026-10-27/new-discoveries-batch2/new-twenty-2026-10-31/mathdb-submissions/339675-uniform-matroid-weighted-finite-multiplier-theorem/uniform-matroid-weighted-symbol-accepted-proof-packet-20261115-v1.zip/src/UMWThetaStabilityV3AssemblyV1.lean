import UMWSchurClosureV6
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
namespace MathDB339675
open Polynomial
theorem theta_fraction_im_pos {z w : ℂ} (hz : 0 < z.im)
    (hw : w.im = 0) (hn : w.re < 0) : (z / (z-w)).im > 0 := by
  have he : z-w ≠ 0 := by
    intro he
    have hi := congrArg Complex.im he
    simp only [Complex.sub_im, Complex.zero_im, hw, sub_zero] at hi
    linarith
  have hid : z / (z-w) = 1 + w * (1 / (z-w)) := by
    field_simp
    ring
  rw [hid]
  simp only [Complex.add_im, Complex.one_im, Complex.mul_im, hw, zero_mul,
    add_zero, zero_add]
  exact mul_pos_of_neg_of_neg hn (schur_recip_im_neg hz (le_of_eq hw))
theorem theta_sum_im_pos (s : Multiset ℂ) (hne : s ≠ 0) {z : ℂ}
    (hz : 0 < z.im) (hs : ∀ w ∈ s, w.im=0 ∧ w.re<0) :
    (z * (s.map (fun w => 1/(z-w))).sum).im > 0 := by
  have hnon : ∀ t : Multiset ℂ, (∀ w ∈ t, w.im=0 ∧ w.re<0) →
      0 ≤ (z * (t.map (fun w => 1/(z-w))).sum).im := by
    intro t
    induction t using Multiset.induction_on with
    | empty => simp
    | cons w t ih =>
      intro ht
      simp only [Multiset.map_cons, Multiset.sum_cons, mul_add, Complex.add_im]
      have h := ht w (by simp)
      have hp := theta_fraction_im_pos hz h.1 h.2
      have hi := ih (fun v hv => ht v (by simp [hv]))
      simp only [div_eq_mul_inv, one_mul] at hp hi ⊢
      linarith
  induction s using Multiset.induction_on with
  | empty => exact (hne rfl).elim
  | cons w s _ =>
    simp only [Multiset.map_cons, Multiset.sum_cons, mul_add, Complex.add_im]
    have h := hs w (by simp)
    have hp := theta_fraction_im_pos hz h.1 h.2
    have hi := hnon s (fun v hv => hs v (by simp [hv]))
    simp only [div_eq_mul_inv, one_mul] at hp hi ⊢
    linarith
theorem theta_log_im_pos {p : ℂ[X]} (hp : p ≠ 0) (hs : p.Splits)
    (hd : p.natDegree ≠ 0) (hr : ∀ w ∈ p.roots, w.im=0 ∧ w.re<0)
    {z : ℂ} (hz : 0 < z.im) :
    (z * (p.derivative.eval z / p.eval z)).im > 0 := by
  rw [hs.eval_derivative_div_eval_of_ne_zero
    (schur_eval_ne_zero_upper hp (fun w hw => le_of_eq (hr w hw).1) hz)]
  exact theta_sum_im_pos p.roots (hs.roots_ne_zero hd) hz hr
end MathDB339675
