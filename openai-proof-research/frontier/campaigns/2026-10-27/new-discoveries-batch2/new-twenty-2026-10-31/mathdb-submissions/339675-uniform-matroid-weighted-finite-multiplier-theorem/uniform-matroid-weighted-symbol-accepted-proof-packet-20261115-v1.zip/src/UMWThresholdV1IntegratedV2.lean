import UMWRootCountV2IntegratedV2
namespace MathDB339675
open Polynomial Finset

theorem equality_threshold_certificate (p : ℝ[X]) (m d l : ℕ)
    (hm : 0 < m) (hd : 0 < d) (hl : 0 < l ∧ l < m)
    (ht : lattice d l = (m : ℝ)*d)
    (he : ∀ k, k ≤ m → p.eval (-lattice d k) = nodeValue m d k)
    (hp : p ≠ 0) (hdeg : p.natDegree = m-1) :
    p.Splits ∧ ∀ x : ℝ, p.eval x = 0 → x < 0 := by
  classical
  let s := ((range m).erase l).erase (l-1)
  have hgap : ∀ j ∈ s, ∃ x ∈ Set.Ioo (-lattice d (j+1)) (-lattice d j), p.eval x = 0 := by
    intro j hj
    have hj1 := mem_erase.mp hj
    have hj2 := mem_erase.mp hj1.2
    have hjm : j < m := mem_range.mp hj2.2
    apply lattice_interval_root p m d j hm hd he hjm
    by_cases h : j < l
    · left
      rw [← ht]
      exact lattice_strictMono d (by omega : j+1 < l)
    · right
      rw [← ht]
      exact lattice_strictMono d (by omega : l < j)
  obtain ⟨Z,hc,hz,hn⟩ := gap_root_set p d s hgap
  have hnode : p.eval (-lattice d l) = 0 := by
    rw [he l (by omega)]
    exact nodeValue_eq_zero m d l ht hm hd
  have hlm : l-1 ∈ (range m).erase l := by
    simp only [mem_erase, mem_range]
    omega
  have hcard : s.card = m-2 := by
    dsimp [s]
    rw [card_erase_of_mem hlm, card_erase_of_mem (mem_range.mpr hl.2), card_range]
    omega
  apply certify_roots p hp (insert (-lattice d l) Z)
  · rw [card_insert_of_notMem (hn l), hc, hcard, hdeg]
    omega
  · intro x hx
    rcases mem_insert.mp hx with rfl | hx
    · exact ⟨hnode, neg_neg_of_pos (lattice_pos d l hl.1)⟩
    · exact hz x hx

/-- Finite threshold location, without a non-equality assumption. -/
theorem locate_threshold (d m : ℕ) (T : ℝ) (h0 : 0 ≤ T) (hm : T < lattice d m) :
    ∃ l < m, lattice d l ≤ T ∧ T < lattice d (l+1) := by
  induction m with
  | zero => simp only [lattice_zero] at hm; linarith
  | succ m ih =>
    by_cases h : T < lattice d m
    · obtain ⟨l,hl,ha,hb⟩ := ih h
      exact ⟨l,by omega,ha,hb⟩
    · exact ⟨m, Nat.lt_succ_self m, le_of_not_gt h, hm⟩

/-- Complete quadratic-lattice root-count theorem. Evaluations and degree
are explicit mathematical hypotheses, still to be proved for the source B. -/
theorem quadratic_lattice_certificate (p : ℝ[X]) (m d : ℕ)
    (hm : 0 < m) (hd : 0 < d)
    (he : ∀ k, k ≤ m → p.eval (-lattice d k) = nodeValue m d k)
    (hp : p ≠ 0) (hdeg : p.natDegree = m-1) :
    p.Splits ∧ ∀ x : ℝ, p.eval x = 0 → x < 0 := by
  obtain ⟨ht0,htm⟩ := threshold_bounds m d hm hd
  obtain ⟨l,hl,ha,hb⟩ := locate_threshold d m ((m : ℝ)*d) ht0.le htm
  rcases lt_or_eq_of_le ha with ha | ha
  · exact strict_threshold_certificate p m d l hm hd hl ⟨ha,hb⟩ he hp hdeg
  · have hl0 : 0 < l := by
      by_contra h
      have : l = 0 := by omega
      rw [this, lattice_zero] at ha
      linarith
    exact equality_threshold_certificate p m d l hm hd ⟨hl0,hl⟩ ha he hp hdeg

#print axioms equality_threshold_certificate
#print axioms quadratic_lattice_certificate
end MathDB339675
