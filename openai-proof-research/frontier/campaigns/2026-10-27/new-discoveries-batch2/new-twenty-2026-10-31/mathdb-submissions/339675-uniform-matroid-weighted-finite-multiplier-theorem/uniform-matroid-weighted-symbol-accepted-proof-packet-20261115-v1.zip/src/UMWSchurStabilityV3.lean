import Mathlib.Algebra.Polynomial.Splits
import Mathlib.Basic.Complex.BigOperators
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
namespace MathDB339675
open Polynomial
theorem schur_recip_im_neg {z w : ℂ} (hz : 0 < z.im) (hw : w.im ≤ 0) :
    (1 / (z-w)).im < 0 := by
  rw [one_div, Complex.inv_im]
  have hi : 0 < (z-w).im := by simp only [Complex.sub_im]; linarith
  have hn : z-w ≠ 0 := by intro h; rw [h] at hi; simp at hi
  exact div_neg_of_neg_of_pos (neg_neg_of_pos hi) (Complex.normSq_pos.mpr hn)

theorem schur_sum_recip_im_nonpos (s : Multiset ℂ) {z : ℂ}
    (hz : 0 < z.im) (hs : ∀ w ∈ s, w.im ≤ 0) :
    ((s.map (fun w => 1 / (z-w))).sum).im ≤ 0 := by
  induction s using Multiset.induction_on with
  | empty => simp
  | cons w s ih =>
    simp only [Multiset.map_cons, Multiset.sum_cons, Complex.add_im]
    have hw := schur_recip_im_neg hz (hs w (by simp))
    have ht := ih (fun v hv => hs v (by simp [hv]))
    linarith

theorem schur_sum_recip_im_neg (s : Multiset ℂ) (hne : s ≠ 0) {z : ℂ}
    (hz : 0 < z.im) (hs : ∀ w ∈ s, w.im ≤ 0) :
    ((s.map (fun w => 1 / (z-w))).sum).im < 0 := by
  induction s using Multiset.induction_on with
  | empty => exact (hne rfl).elim
  | cons w s _ =>
    simp only [Multiset.map_cons, Multiset.sum_cons, Complex.add_im]
    have hw := schur_recip_im_neg hz (hs w (by simp))
    have ht := schur_sum_recip_im_nonpos s hz (fun v hv => hs v (by simp [hv]))
    linarith

/-- A split polynomial whose roots are in the closed lower half plane
cannot vanish in the open upper half plane. Multiplicities are unrestricted. -/
theorem schur_eval_ne_zero_upper {p : ℂ[X]} (hp : p ≠ 0)
    (hr : ∀ w ∈ p.roots, w.im ≤ 0) {z : ℂ} (hz : 0 < z.im) :
    p.eval z ≠ 0 := by
  intro he
  have hm : z ∈ p.roots := (mem_roots hp).mpr he
  linarith [hr z hm]

/-- Strict imaginary-part certificate for the logarithmic derivative. -/
theorem schur_logDerivative_im_neg {p : ℂ[X]} (hp : p ≠ 0)
    (hs : p.Splits) (hd : p.natDegree ≠ 0)
    (hr : ∀ w ∈ p.roots, w.im ≤ 0) {z : ℂ} (hz : 0 < z.im) :
    (p.derivative.eval z / p.eval z).im < 0 := by
  rw [hs.eval_derivative_div_eval_of_ne_zero (schur_eval_ne_zero_upper hp hr hz)]
  exact schur_sum_recip_im_neg p.roots (hs.roots_ne_zero hd) hz hr

/-- Real constant plus differentiation preserves upper-half-plane
nonvanishing for nonconstant split polynomials. No simple-root or
same-sign-real-root assumption occurs. -/
theorem schur_differential_no_upper_zero {p : ℂ[X]} (hp : p ≠ 0)
    (hs : p.Splits) (hd : p.natDegree ≠ 0)
    (hr : ∀ w ∈ p.roots, w.im ≤ 0) (a : ℝ) {z : ℂ} (hz : 0 < z.im) :
    (p.derivative + C (a : ℂ) * p).eval z ≠ 0 := by
  have he := schur_eval_ne_zero_upper hp hr hz
  have hi := schur_logDerivative_im_neg hp hs hd hr hz
  intro hq
  have h : p.derivative.eval z = -(a : ℂ) * p.eval z := by
    have hh : p.derivative.eval z + (a : ℂ) * p.eval z = 0 := by
      simpa only [eval_add, eval_mul, eval_C] using hq
    linear_combination hh
  rw [h, mul_div_cancel_right₀ _ he] at hi
  simp at hi

#print axioms schur_differential_no_upper_zero
end MathDB339675
