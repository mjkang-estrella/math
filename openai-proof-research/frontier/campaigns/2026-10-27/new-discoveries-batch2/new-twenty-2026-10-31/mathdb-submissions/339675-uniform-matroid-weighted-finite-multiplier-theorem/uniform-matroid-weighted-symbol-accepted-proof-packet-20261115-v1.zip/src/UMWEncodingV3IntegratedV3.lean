import UMWNegativeNodeV3IntegratedV3
namespace MathDB339675
open Polynomial Finset

noncomputable def fallingPoly (u : ℝ[X]) (h : ℕ) : ℝ[X] :=
  C (1 / (h.factorial : ℝ)) * ∏ k ∈ range h, (u - C (k : ℝ))
noncomputable def sourceP (m d : ℕ) : ℝ[X] :=
  ∑ h ∈ range m, C (1 / (((h : ℝ)+1)*m)) *
    (C (m : ℝ) + X * C ((h : ℝ)-(m : ℝ)+1)) *
    fallingPoly (X-C 1+C (h : ℝ)) h * fallingPoly (C (d : ℝ)-X+C (h : ℝ)) h

theorem eval_fallingPoly (u : ℝ[X]) (h : ℕ) (x : ℝ) :
    (fallingPoly u h).eval x = fallingChoose (u.eval x) h := by
  have he : (∏ k ∈ range h, (u - C (k : ℝ))).eval x =
      ∏ k ∈ range h, (u.eval x - k) := by
    induction h with
    | zero => simp
    | succ h ih => simp only [prod_range_succ, eval_mul, eval_sub, eval_C, ih]
  simp only [fallingPoly, eval_mul, eval_C, he, fallingChoose]
  ring

theorem eval_sourceP (m d : ℕ) (x : ℝ) : (sourceP m d).eval x = b m d x := by
  simp only [sourceP, b, eval_finsetSum]
  apply sum_congr rfl
  intro h _
  simp only [eval_mul, eval_add, eval_sub, eval_C, eval_X, eval_fallingPoly]
  simp only [div_eq_mul_inv, one_mul]
  ring

theorem diagonal_C (m d : ℕ) (hm : 0 < m) (c : ℝ) : diagonal m d (C c) = C c := by
  ext i
  rw [coeff_diagonal]
  cases i with
  | zero => simp [b_zero m d hm]
  | succ i => simp

theorem diagonal_one_parameter (d : ℕ) (f : ℝ[X]) (hf : f.natDegree ≤ d) :
    diagonal 1 d f = f := by
  ext i
  rw [coeff_diagonal]
  by_cases hi : i ≤ d
  · simp [hi]
  · simp [hi, coeff_eq_zero_of_natDegree_lt (by omega : f.natDegree < i)]

theorem one_parameter_d_sequence (d : ℕ) : IsDSequence 1 d := by
  intro f hf hr
  rw [diagonal_one_parameter d f hf]
  exact hr

#print axioms eval_sourceP
#print axioms coeff_symbol
#print axioms diagonal_C
#print axioms one_parameter_d_sequence
end MathDB339675
