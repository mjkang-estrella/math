import UMWSchurStabilityV3
import Mathlib.Analysis.Complex.Polynomial.Basic
namespace MathDB339675
open Polynomial
def SchurUpperStable (p : ℂ[X]) : Prop :=
  ∀ z : ℂ, 0 < z.im → p.eval z ≠ 0

theorem schur_upperStable_ne_zero {p : ℂ[X]} (h : SchurUpperStable p) : p ≠ 0 := by
  intro hp
  have := h Complex.I (by simp)
  simp [hp] at this

/-- Differentiation plus any real scalar preserves upper stability, allowing
the identically zero output. This includes constant and repeated-root inputs. -/
theorem schur_upperStable_differential {p : ℂ[X]} (h : SchurUpperStable p) (a : ℝ) :
    p.derivative + C (a : ℂ) * p = 0 ∨
    SchurUpperStable (p.derivative + C (a : ℂ) * p) := by
  by_cases hq : p.derivative + C (a : ℂ) * p = 0
  · exact Or.inl hq
  right
  have hp := schur_upperStable_ne_zero h
  by_cases hd : p.natDegree = 0
  · have hc := eq_C_of_natDegree_eq_zero hd
    rw [hc] at hq ⊢
    simpa only [derivative_C, zero_add, C_mul] using
      (show SchurUpperStable (C ((a : ℂ) * p.coeff 0)) from by
        intro z _
        simpa using (show (a : ℂ) * p.coeff 0 ≠ 0 from by
          intro he; apply hq
          simp only [derivative_C, zero_add, ← C_mul, he, map_zero]))
  · intro z hz
    apply schur_differential_no_upper_zero hp (IsAlgClosed.splits p) hd _ a hz
    intro w hw
    by_contra hn
    have hw' : p.eval w = 0 := (mem_roots hp).mp hw
    exact h w (lt_of_not_ge hn) hw'

theorem schur_real_map_upperStable {p : ℝ[X]} (hp : p ≠ 0) (hs : p.Splits) :
    SchurUpperStable (p.map (algebraMap ℝ ℂ)) := by
  intro z hz
  apply schur_eval_ne_zero_upper (map_ne_zero hp) _ hz
  intro w hw
  obtain ⟨r, hr⟩ := hs.mem_range_of_isRoot hp ((mem_roots (map_ne_zero hp)).mp hw)
  rw [← hr]
  simp

theorem schur_real_splits_of_upperStable {p : ℝ[X]}
    (hs : SchurUpperStable (p.map (algebraMap ℝ ℂ))) : p.Splits := by
  apply Splits.of_splits_map_of_injective (i := (algebraMap ℝ ℂ)) Complex.ofReal_injective (IsAlgClosed.splits _)
  intro z hz
  have hp : p.map (algebraMap ℝ ℂ) ≠ 0 := schur_upperStable_ne_zero hs
  have he : (p.map (algebraMap ℝ ℂ)).eval z = 0 := (mem_roots hp).mp hz
  have him : z.im = 0 := by
    rcases lt_trichotomy z.im 0 with hn | heq | hp
    · have hc : (p.map (algebraMap ℝ ℂ)).eval (star z) = 0 := by
        have he' : aeval z p = 0 := by
          simpa only [aeval_def, ← eval_map] using he
        have hc' : aeval (star z) p = 0 := by
          simpa [he'] using (aeval_conj p z)
        simpa only [aeval_def, ← eval_map] using hc'
      exact (hs (star z) (by simpa using neg_pos.mpr hn) hc).elim
    · exact heq
    · exact (hs z hp he).elim
  exact ⟨z.re, by apply Complex.ext <;> simp [him]⟩

/-- Unconditional real-rooted closure under a real first-order constant
coefficient differential operator. All root signs and multiplicities allowed. -/
theorem schur_real_differential_splits (p : ℝ[X]) (hs : p.Splits) (a : ℝ) :
    (p.derivative + C a * p).Splits := by
  by_cases hp : p = 0
  · simp [hp]
  have hu := schur_upperStable_differential (schur_real_map_upperStable hp hs) a
  have hm : (p.derivative + C a * p).map (algebraMap ℝ ℂ) =
      (p.map (algebraMap ℝ ℂ)).derivative +
      C (a : ℂ) * (p.map (algebraMap ℝ ℂ)) := by simp
  rcases hu with hz | hz
  · have hzero : p.derivative + C a * p = 0 := by
      apply (Polynomial.map_injective (algebraMap ℝ ℂ) Complex.ofReal_injective)
      simpa only [Polynomial.map_zero] using hm.trans hz
    simp [hzero]
  · apply schur_real_splits_of_upperStable
    rwa [hm]

#print axioms schur_upperStable_differential
#print axioms schur_real_differential_splits
end MathDB339675
