import UMWSchurFullPolarizationV2
namespace MathDB339675
open Polynomial
open scoped BigOperators
theorem schur_product_coeff (d i : ℕ) (a : Fin d → ℂ) :
    (∏ j, ((1 : ℂ[X])+C (a j)*X)).coeff i = schurElementary d i a := by
  classical
  rw [Finset.prod_one_add]
  have hp : ∀ S : Finset (Fin d), (∏ j ∈ S, C (a j)*X) =
      C (∏ j ∈ S, a j) * X^S.card := by
    intro S
    rw [Finset.prod_mul_distrib]
    simp
  simp_rw [hp]
  rw [finsetSum_coeff]
  simp only [coeff_C_mul_X_pow]
  unfold schurElementary
  rw [Finset.powersetCard_eq_filter, Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro S hS
  split_ifs <;> simp_all

theorem schurElementary_scale (d i : ℕ) (a : Fin d → ℂ) (z : ℂ) :
    schurElementary d i (fun j => z*a j) = z^i * schurElementary d i a := by
  classical
  unfold schurElementary
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro S hS
  rw [Finset.prod_mul_distrib, Finset.prod_const,
    (Finset.mem_powersetCard.mp hS).2]

end MathDB339675
