import UMWThetaNegativeV1AssemblyV1
namespace MathDB339675
open Polynomial
theorem coeff_theta_factor (p : ℝ[X]) (r : ℝ) (i : ℕ) :
    (X*p.derivative-C r*p).coeff i = ((i:ℝ)-r)*p.coeff i := by
  cases i with
  | zero => simp
  | succ i => simp [coeff_derivative]; ring
theorem theta_factor_degree_le (p : ℝ[X]) (r : ℝ) :
    (X*p.derivative-C r*p).natDegree ≤ p.natDegree := by
  apply natDegree_le_iff_coeff_eq_zero.mpr
  intro i hi
  rw [coeff_theta_factor, coeff_eq_zero_of_natDegree_lt hi, mul_zero]
theorem theta_factor_degree (p : ℝ[X]) (hp : p ≠ 0) (r : ℝ)
    (hr : r ≠ (p.natDegree:ℝ)) :
    (X*p.derivative-C r*p).natDegree=p.natDegree := by
  apply natDegree_eq_of_le_of_coeff_ne_zero (theta_factor_degree_le p r)
  rw [coeff_theta_factor]
  exact mul_ne_zero (sub_ne_zero.mpr (Ne.symm hr)) (by simpa only [coeff_natDegree] using (leadingCoeff_ne_zero.mpr hp))
theorem theta_factor_leading (p : ℝ[X]) (hp : p ≠ 0) (r : ℝ)
    (hr : r ≠ (p.natDegree:ℝ)) :
    (X*p.derivative-C r*p).leadingCoeff = ((p.natDegree:ℝ)-r)*p.leadingCoeff := by
  rw [leadingCoeff, theta_factor_degree p hp r hr, coeff_theta_factor, coeff_natDegree]
theorem theta_factor_constant (p : ℝ[X]) (r : ℝ) :
    (X*p.derivative-C r*p).coeff 0 = -r*p.coeff 0 := by
  simp
theorem theta_exterior_preserves (p : ℝ[X]) (hp : p ≠ 0) (hs : p.Splits)
    (hd : p.natDegree ≠ 0) (hn : ∀ a : ℝ, p.eval a=0 → a<0) (r : ℝ)
    (hr : r<0 ∨ (p.natDegree:ℝ)<r) :
    (X*p.derivative-C r*p).natDegree=p.natDegree ∧
    (X*p.derivative-C r*p).Splits ∧
    ∀ x : ℝ, (X*p.derivative-C r*p).eval x=0 → x<0 := by
  have he : r ≠ (p.natDegree:ℝ) := by
    rcases hr with hr|hr
    · have := Nat.cast_nonneg (α:=ℝ) p.natDegree; linarith
    · linarith
  exact ⟨theta_factor_degree p hp r he, theta_real_splits p hp hs hd hn r,
    theta_exterior_roots_negative p hp hs hn r hr⟩
end MathDB339675
