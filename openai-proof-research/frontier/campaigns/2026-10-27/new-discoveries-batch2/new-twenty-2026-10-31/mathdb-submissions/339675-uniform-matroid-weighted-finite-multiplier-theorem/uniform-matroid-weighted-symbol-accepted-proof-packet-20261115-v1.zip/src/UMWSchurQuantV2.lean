import UMWSchurClosureV6
import Mathlib.Algebra.Order.Chebyshev
import Mathlib.Tactic.FieldSimp
namespace MathDB339675
open Polynomial
theorem schur_normSq_sum_le (s : Multiset ℂ) :
    Complex.normSq s.sum ≤ (s.card : ℝ) * (s.map Complex.normSq).sum := by
  have hre : s.sum.re = (s.map Complex.re).sum := by
    induction s using Multiset.induction_on with
    | empty => simp
    | cons a s ih => simp [ih]
  have him : s.sum.im = (s.map Complex.im).sum := by
    clear hre
    induction s using Multiset.induction_on with
    | empty => simp
    | cons a s ih => simp [ih]
  have hns : (s.map Complex.normSq).sum =
      (s.map (fun z => z.re ^ 2)).sum + (s.map (fun z => z.im ^ 2)).sum := by
    clear hre him
    induction s using Multiset.induction_on with
    | empty => simp
    | cons a s ih => simp [ih, Complex.normSq_apply, pow_two]; ring
  have hr := Multiset.sq_sum_le_card_mul_sum_sq (s.map Complex.re)
  have hi := Multiset.sq_sum_le_card_mul_sum_sq (s.map Complex.im)
  simp only [Multiset.card_map, Multiset.map_map, Function.comp_def] at hr hi
  rw [Complex.normSq_apply, hre, him, hns]
  nlinarith
#print axioms schur_normSq_sum_le
end MathDB339675

