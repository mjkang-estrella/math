import UMWSchurQuantV4
namespace MathDB339675
open Polynomial
noncomputable def polarStep (p : ℂ[X]) (n : ℕ) (w : ℂ) : ℂ[X] :=
  p + C ((n : ℂ)⁻¹) * (C w - X) * p.derivative

theorem schur_polarStep_stable {p : ℂ[X]} (hp : SchurUpperStable p)
    {n : ℕ} (hn : 0 < n) (hd : p.natDegree ≤ n)
    {w : ℂ} (hw : 0 < w.im) : SchurUpperStable (polarStep p n w) := by
  intro z hz he
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast (ne_of_gt hn)
  have hez := hp z hz
  by_cases hd0 : p.natDegree = 0
  · have hder := derivative_of_natDegree_zero hd0
    exact hez (by simpa [polarStep, hder] using he)
  let S : ℂ := p.derivative.eval z / p.eval z
  have hs : S ≠ 0 := schur_logDerivative_ne_zero hp hd0 hz
  have hq := schur_logDerivative_quant hp hn hd hz
  have hzero : p.eval z + (n : ℂ)⁻¹ * (w-z) * p.derivative.eval z = 0 := by
    simpa [polarStep] using he
  have hwz : w = z - (n : ℂ) / S := by
    have hder : p.derivative.eval z ≠ 0 := (div_ne_zero_iff.mp hs).1
    field_simp [hnC] at hzero
    dsimp [S]
    field_simp [hez, hder]
    linear_combination hzero
  have hnorm := Complex.normSq_pos.mpr hs
  have him : w.im = z.im + (n : ℝ) * S.im / Complex.normSq S := by
    rw [hwz, Complex.sub_im, div_eq_mul_inv, Complex.mul_im, Complex.inv_im]
    simp
    ring
  have hle : w.im ≤ 0 := by
    rw [him]
    have hh : (n : ℝ) * S.im / Complex.normSq S ≤ -z.im := by
      apply (div_le_iff₀ hnorm).mpr
      dsimp [S] at *
      nlinarith
    linarith
  linarith
#print axioms schur_polarStep_stable
end MathDB339675

