import UMWSchurSymmetryV1
import Mathlib.Algebra.Polynomial.BigOperators
namespace MathDB339675
open Polynomial
open scoped BigOperators
noncomputable def partialFactor {d : ℕ} (T : Finset (Fin d))
    (a : Fin d → ℂ) (j : Fin d) : ℂ[X] :=
  if j ∈ T then C (a j) else X
noncomputable def partialProduct {d : ℕ} (T : Finset (Fin d))
    (a : Fin d → ℂ) (S : Finset (Fin d)) : ℂ[X] :=
  ∏ j ∈ S, partialFactor T a j
noncomputable def partialPoly (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) : ℂ[X] :=
  ∑ i ∈ Finset.range (d+1), C (p.coeff i / (d.choose i : ℂ)) *
    ∑ S ∈ (Finset.univ : Finset (Fin d)).powersetCard i, partialProduct T a S

theorem partialPoly_eval (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) (z : ℂ) :
    (partialPoly d p T a).eval z =
      schurPolarization d p (fun j => if j ∈ T then a j else z) := by
  classical
  simp only [partialPoly, schurPolarization, schurElementary,
    eval_finsetSum, eval_mul, eval_C, partialProduct, eval_prod]
  apply Finset.sum_congr rfl
  intro i hi
  simp only [partialFactor, apply_ite (eval z), eval_C, eval_X]
  ring

theorem partialPoly_empty (d : ℕ) (p : ℂ[X]) (hd : p.natDegree ≤ d)
    (a : Fin d → ℂ) : partialPoly d p ∅ a = p := by
  apply Polynomial.funext
  intro z
  rw [partialPoly_eval]
  simpa using schurPolarization_diagonal d p hd z

theorem partialPoly_full (d : ℕ) (p : ℂ[X]) (a : Fin d → ℂ) :
    partialPoly d p Finset.univ a = C (schurPolarization d p a) := by
  apply Polynomial.funext
  intro z
  rw [partialPoly_eval]
  simp

theorem partialProduct_degree {d : ℕ} (T S : Finset (Fin d)) (a : Fin d → ℂ) :
    (partialProduct T a S).natDegree ≤ (S \ T).card := by
  classical
  induction S using Finset.induction_on with
  | empty => simp [partialProduct]
  | @insert j S hj ih =>
    rw [partialProduct, Finset.prod_insert hj]
    change (partialFactor T a j * partialProduct T a S).natDegree ≤ _
    have hm := natDegree_mul_le (p := partialFactor T a j) (q := partialProduct T a S)
    by_cases ht : j ∈ T
    · simp only [partialFactor, ite_eq_left ht, natDegree_C, zero_add] at hm
      simpa [partialFactor, ht, Finset.insert_sdiff_of_mem _ ht] using hm.trans ih
    · have hn : j ∉ S \ T := by simp [hj]
      rw [Finset.insert_sdiff_of_notMem _ ht, Finset.card_insert_of_notMem hn]
      simp only [partialFactor, ite_eq_right ht, natDegree_X] at hm
      simpa [partialFactor, ht, Nat.add_comm] using hm.trans (Nat.add_le_add_left ih 1)

theorem partialPoly_degree (d : ℕ) (p : ℂ[X]) (T : Finset (Fin d))
    (a : Fin d → ℂ) : (partialPoly d p T a).natDegree ≤ d-T.card := by
  classical
  apply natDegree_sum_le_of_forall_le
  intro i hi
  apply natDegree_mul_le.trans
  simp only [natDegree_C, zero_add]
  apply natDegree_sum_le_of_forall_le
  intro S hS
  apply (partialProduct_degree T S a).trans
  have hh : S \ T ⊆ (Finset.univ : Finset (Fin d)) \ T :=
    Finset.sdiff_subset_sdiff (Finset.subset_univ S) (Finset.Subset.refl T)
  simpa [Finset.card_sdiff_of_subset (Finset.subset_univ T)] using Finset.card_le_card hh
end MathDB339675
