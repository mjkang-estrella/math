import UMWThetaSplitsV4AssemblyV1
namespace MathDB339675
open Polynomial
theorem theta_real_log_bounds (p : ℝ[X]) (hp : p ≠ 0) (hs : p.Splits)
    (hn : ∀ a : ℝ, p.eval a=0 → a<0) {x : ℝ} (hx : 0 ≤ x) :
    0 ≤ x * (p.derivative.eval x / p.eval x) ∧
    x * (p.derivative.eval x / p.eval x) ≤ (p.natDegree:ℝ) := by
  have he : p.eval x ≠ 0 := by intro he; linarith [hn x he]
  rw [hs.eval_derivative_div_eval_of_ne_zero he]
  have hb : ∀ s : Multiset ℝ, (∀ a ∈ s, a<0) →
      0 ≤ x*(s.map (fun a => 1/(x-a))).sum ∧
      x*(s.map (fun a => 1/(x-a))).sum ≤ (s.card:ℝ) := by
    intro s
    induction s using Multiset.induction_on with
    | empty => simp
    | cons a s ih =>
      intro h
      have ha := h a (by simp)
      have ht := ih (fun b hb => h b (by simp [hb]))
      have hd : 0 < x-a := by linarith
      have hlo : 0 ≤ x/(x-a) := div_nonneg hx hd.le
      have hhi : x/(x-a) ≤ 1 := (div_le_one hd).2 (by linarith)
      simp only [Multiset.map_cons, Multiset.sum_cons, mul_add,
        Multiset.card_cons, Nat.cast_add, Nat.cast_one]
      rw [div_eq_mul_inv] at hlo hhi
      simp only [one_div]
      simp only [one_div] at ht
      constructor <;> linarith
  have h := hb p.roots (fun a ha => hn a ((mem_roots hp).mp ha))
  simpa only [hs.natDegree_eq_card_roots] using h
theorem theta_exterior_roots_negative (p : ℝ[X]) (hp : p ≠ 0) (hs : p.Splits)
    (hn : ∀ a : ℝ, p.eval a=0 → a<0) (r : ℝ)
    (hr : r<0 ∨ (p.natDegree:ℝ)<r) :
    ∀ x : ℝ, (X*p.derivative-C r*p).eval x=0 → x<0 := by
  intro x he
  by_contra h
  have hx : 0 ≤ x := le_of_not_gt h
  have hpne : p.eval x ≠ 0 := by intro he; linarith [hn x he]
  have hb := theta_real_log_bounds p hp hs hn hx
  have hh : x*(p.derivative.eval x/p.eval x)=r := by
    rw [← mul_div_assoc]
    apply (div_eq_iff hpne).2
    simpa only [eval_sub, eval_mul, eval_X, eval_C, sub_eq_zero] using he
  rw [hh] at hb
  rcases hr with hr|hr <;> linarith
end MathDB339675
