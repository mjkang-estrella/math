import UMWPositiveNodeV2IntegratedV3
import UMWEndpointV2IntegratedV3
namespace MathDB339675
open Polynomial Finset
theorem b_positive_node (m d j : ℕ) (hm : 0 < m) (hd : 0 < d) (hj : j ≤ m) :
    b m d ((d:ℝ)+j) = nodeValue m d j := by
  cases j with
  | zero => simpa [nodeValue] using b_right_endpoint m d hm hd
  | succ q =>
    simpa only [Nat.cast_add, Nat.cast_one, Nat.cast_succ, add_assoc] using
      b_positive_node_succ m d q hm hd (by omega)
theorem sourceP_paired_evaluations (m d j : ℕ) (hm : 0 < m) (hd : 0 < d) (hj : j ≤ m) :
    (sourceP m d).eval (-(j:ℝ)) = nodeValue m d j ∧
    (sourceP m d).eval ((d:ℝ)+j) = nodeValue m d j := by
  simp only [eval_sourceP]
  exact ⟨b_negative_node m d j hm hd hj, b_positive_node m d j hm hd hj⟩
theorem symbol_constant (m d : ℕ) (hm : 0 < m) : (symbol m d).coeff 0 = 1 := by
  simp [coeff_symbol, b_zero m d hm]
theorem symbol_top (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    (symbol m d).coeff d = 1 := by
  simp [coeff_symbol, b_right_endpoint m d hm hd]
theorem symbol_degree (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    (symbol m d).natDegree = d := by
  apply le_antisymm
  · apply natDegree_le_iff_coeff_eq_zero.mpr
    intro n hn
    simp [coeff_symbol, show ¬n ≤ d by omega]
  · exact le_natDegree_of_ne_zero (by rw [symbol_top m d hm hd]; norm_num)
#print axioms sourceP_paired_evaluations
#print axioms symbol_degree
end MathDB339675
