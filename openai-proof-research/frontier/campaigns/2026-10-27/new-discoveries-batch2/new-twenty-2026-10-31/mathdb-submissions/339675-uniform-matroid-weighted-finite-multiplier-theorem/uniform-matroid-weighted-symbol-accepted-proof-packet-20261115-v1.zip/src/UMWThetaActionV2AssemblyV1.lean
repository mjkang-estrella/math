import UMWExteriorSplitsV2IntegratedV3
import Mathlib.Algebra.Polynomial.Derivative
namespace MathDB339675
open Polynomial Finset
noncomputable def theta (f : ℝ[X]) : ℝ[X] := X * f.derivative
noncomputable def thetaAction (p f : ℝ[X]) : ℝ[X] :=
  ∑ i ∈ range (f.natDegree+1), monomial i (p.eval (i:ℝ) * f.coeff i)
theorem coeff_thetaAction (p f : ℝ[X]) (i : ℕ) :
    (thetaAction p f).coeff i = p.eval (i:ℝ) * f.coeff i := by
  classical
  by_cases hi : i ≤ f.natDegree
  · simp [thetaAction, coeff_monomial, hi]
  · have hc := coeff_eq_zero_of_natDegree_lt (p := f) (by omega : f.natDegree < i)
    simp [thetaAction, coeff_monomial, hi, hc]
theorem coeff_theta (f : ℝ[X]) (i : ℕ) :
    (theta f).coeff i = (i:ℝ) * f.coeff i := by
  cases i with
  | zero => simp [theta]
  | succ i => simp [theta, coeff_derivative, mul_comm]
theorem thetaAction_X (f : ℝ[X]) : thetaAction X f = theta f := by
  ext i
  simp [coeff_thetaAction, coeff_theta]
theorem thetaAction_one (f : ℝ[X]) : thetaAction 1 f = f := by
  ext i
  simp [coeff_thetaAction]
theorem thetaAction_mul (p q f : ℝ[X]) :
    thetaAction (p*q) f = thetaAction p (thetaAction q f) := by
  ext i
  simp only [coeff_thetaAction, eval_mul]
  ring
theorem thetaAction_sub_C (r : ℝ) (f : ℝ[X]) :
    thetaAction (X-C r) f = theta f - C r * f := by
  ext i
  simp [coeff_thetaAction, coeff_theta, sub_mul]
end MathDB339675
