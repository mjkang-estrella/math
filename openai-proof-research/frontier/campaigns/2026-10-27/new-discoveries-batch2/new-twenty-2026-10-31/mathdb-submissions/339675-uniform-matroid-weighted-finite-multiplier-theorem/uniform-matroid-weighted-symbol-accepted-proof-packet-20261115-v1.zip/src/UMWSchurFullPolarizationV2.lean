import UMWSchurIdentificationV4
namespace MathDB339675
open Polynomial
theorem partialPoly_stable (d : ℕ) (p : ℂ[X])
    (hp : SchurUpperStable p) (hd : p.natDegree ≤ d)
    (T : Finset (Fin d)) (a : Fin d → ℂ)
    (ha : ∀ j ∈ T, 0 < (a j).im) :
    SchurUpperStable (partialPoly d p T a) := by
  classical
  induction T using Finset.induction_on with
  | empty => simpa [partialPoly_empty d p hd a] using hp
  | @insert j T hj ih =>
    rw [partialPoly_insert_polarStep d p T a j hj]
    have ht : T.card < d := by
      have h := Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr
        ⟨Finset.subset_univ T, by intro he; exact hj (he ▸ Finset.mem_univ j)⟩)
      simpa using h
    exact schur_polarStep_stable
      (ih (fun k hk => ha k (Finset.mem_insert_of_mem hk)))
      (by omega) (partialPoly_degree d p T a) (ha j (Finset.mem_insert_self j T))

theorem schurPolarization_nonzero (d : ℕ) (p : ℂ[X])
    (hp : SchurUpperStable p) (hd : p.natDegree ≤ d)
    (a : Fin d → ℂ) (ha : ∀ j, 0 < (a j).im) :
    schurPolarization d p a ≠ 0 := by
  have h := partialPoly_stable d p hp hd Finset.univ a (fun j _ => ha j)
  have hh := h Complex.I (by simp)
  rw [partialPoly_full] at hh
  simpa only [eval_C] using hh

theorem schurPolarization_real_nonzero (d : ℕ) (f : ℝ[X])
    (hf : f ≠ 0) (hs : f.Splits) (hd : f.natDegree ≤ d)
    (a : Fin d → ℂ) (ha : ∀ j, 0 < (a j).im) :
    schurPolarization d (f.map (algebraMap ℝ ℂ)) a ≠ 0 := by
  apply schurPolarization_nonzero d _ (schur_real_map_upperStable hf hs)
  · simpa using hd
  · exact ha
#print axioms partialPoly_stable
#print axioms schurPolarization_nonzero
#print axioms schurPolarization_real_nonzero
end MathDB339675
