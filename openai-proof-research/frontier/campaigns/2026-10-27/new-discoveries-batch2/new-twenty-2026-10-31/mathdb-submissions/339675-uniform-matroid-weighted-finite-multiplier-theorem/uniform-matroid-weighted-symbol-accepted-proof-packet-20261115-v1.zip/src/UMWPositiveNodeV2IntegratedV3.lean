import UMWPositiveV3IntegratedV3
namespace MathDB339675
theorem b_positive_node_succ (m d q : ℕ) (hm : 0 < m) (hd : 0 < d) (hq : q < m) :
    b m d (d+q+1 : ℝ) = nodeValue m d (q+1) := by
  have hc1 : (d+q).choose (d-1) = (d+q).choose (q+1) := by
    rw [show d-1 = d+q-(q+1) by omega]
    exact Nat.choose_symm (by omega)
  have hc2 : (d+q).choose d = (d+q).choose q := by
    simpa using (Nat.choose_symm (by omega : q ≤ d+q))
  have hn := Nat.choose_succ_right_eq (d+q) q
  have hr : ((d+q).choose (q+1):ℝ) * ((q:ℝ)+1) =
      ((d+q).choose q:ℝ) * (d:ℝ) := by
    have he : d+q-q = d := by omega
    rw [he] at hn
    exact_mod_cast hn
  have hd' : (d:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hm' : (m:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  rw [b_positive_closed m d q hm hd hq, hc1, hc2]
  unfold nodeValue lattice
  rw [show d+(q+1)-1 = d+q by omega]
  push_cast
  rw [pow_succ]
  field_simp
  nlinarith [hr]
#print axioms b_positive_node_succ
end MathDB339675
