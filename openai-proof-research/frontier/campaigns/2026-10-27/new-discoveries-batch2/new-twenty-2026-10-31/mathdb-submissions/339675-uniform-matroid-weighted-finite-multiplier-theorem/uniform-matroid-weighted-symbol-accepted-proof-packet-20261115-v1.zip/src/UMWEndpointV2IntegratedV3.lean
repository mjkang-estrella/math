import UMWPositiveV3IntegratedV3
namespace MathDB339675
open Finset
theorem b_right_endpoint (m d : ℕ) (hm : 0 < m) (hd : 0 < d) :
    b m d (d:ℝ) = 1 := by
  let F : ℕ → ℝ := fun h => ((h:ℝ)-m)/m * ((d+h-1).choose h:ℝ)
  have hm' : (m:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have he : b m d (d:ℝ) = ∑ h ∈ range m, (F (h+1)-F h) := by
    unfold b
    apply sum_congr rfl
    intro h _
    have hf : (d:ℝ)-1+h = ((d+h-1:ℕ):ℝ) := by
      rw [Nat.cast_sub (by omega : 1 ≤ d+h)]
      push_cast
      ring
    rw [hf, fallingChoose_nat]
    have hz : (d:ℝ)-(d:ℝ)+h = (h:ℝ) := by ring
    rw [hz, fallingChoose_nat]
    simp only [Nat.choose_self, Nat.cast_one, mul_one]
    have hn := Nat.add_one_mul_choose_eq (d+h-1) h
    rw [show d+h-1+1 = d+h by omega] at hn
    have hr : ((h:ℝ)+1) * ((d+h).choose (h+1):ℝ) =
        ((d:ℝ)+h) * ((d+h-1).choose h:ℝ) := by
      have hr0 : ((d:ℝ)+h) * ((d+h-1).choose h:ℝ) =
          ((d+h).choose (h+1):ℝ) * ((h:ℝ)+1) := by exact_mod_cast hn
      nlinarith only [hr0]
    have hh : (h:ℝ)+1 ≠ 0 := by positivity
    dsimp [F]
    push_cast
    field_simp
    nlinarith [hr]
  have ht (n : ℕ) : (∑ h ∈ range n, (F (h+1)-F h)) = F n-F 0 := by
    induction n with
    | zero => simp
    | succ n ih => rw [sum_range_succ, ih]; ring
  rw [he, ht]
  simp [F, hm']
#print axioms b_right_endpoint
end MathDB339675
