import UMWSchurAffineV2
namespace MathDB339675
open scoped BigOperators
theorem schurElementary_perm (d i : ℕ) (z : Fin d → ℂ) (σ : Equiv.Perm (Fin d)) :
    schurElementary d i (fun j => z (σ j)) = schurElementary d i z := by
  classical
  unfold schurElementary
  apply Finset.sum_bij (fun s _ => s.map σ.toEmbedding)
  · intro s hs
    simp only [Finset.mem_powersetCard] at hs ⊢
    exact ⟨Finset.subset_univ _, by simpa using hs.2⟩
  · intro s hs t ht he
    exact Finset.map_injective σ.toEmbedding he
  · intro t ht
    refine ⟨t.map σ.symm.toEmbedding, ?_, ?_⟩
    · simp only [Finset.mem_powersetCard] at ht ⊢
      exact ⟨Finset.subset_univ _, by simpa using ht.2⟩
    · ext x
      simp
  · intro s _hs
    simp
theorem schurPolarization_perm (d : ℕ) (p : Polynomial ℂ)
    (z : Fin d → ℂ) (σ : Equiv.Perm (Fin d)) :
    schurPolarization d p (fun j => z (σ j)) = schurPolarization d p z := by
  unfold schurPolarization
  simp_rw [schurElementary_perm]
#print axioms schurElementary_perm
#print axioms schurPolarization_perm
end MathDB339675

