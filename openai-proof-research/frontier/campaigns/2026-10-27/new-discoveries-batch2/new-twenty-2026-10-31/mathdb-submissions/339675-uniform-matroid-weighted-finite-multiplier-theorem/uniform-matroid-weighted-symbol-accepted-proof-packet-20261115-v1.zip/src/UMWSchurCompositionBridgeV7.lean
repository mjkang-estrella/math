import UMWSchurFactorCoefficientV4
import UMWSchurCompositionDefinitionV2
namespace MathDB339675
open Polynomial
open scoped BigOperators
theorem weightedComposition_eval_polarization (d : ℕ) (f g : ℝ[X])
    (s : Fin d → ℝ)
    (heq : g = C (g.eval 0) * ∏ j, ((1 : ℝ[X])+C ((s j)⁻¹)*X))
    (z : ℂ) :
    ((weightedComposition d f g).map (algebraMap ℝ ℂ)).eval z =
      ((g.eval 0 : ℝ) : ℂ) *
        schurPolarization d (f.map (algebraMap ℝ ℂ)) (fun j => z/(s j : ℂ)) := by
  classical
  simp only [weightedComposition, Polynomial.map_sum, map_monomial, eval_finsetSum,
    eval_monomial, Complex.coe_algebraMap, schurPolarization, Finset.mul_sum, coeff_map]
  apply Finset.sum_congr rfl
  intro i hi
  push_cast
  rw [schur_factor_coeff d i g s heq]
  simp only [div_eq_mul_inv, schurElementary_scale]
  ring
end MathDB339675
