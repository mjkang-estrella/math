import WitnessSearch
import Mathlib.Data.Fintype.Prod

namespace Torus377269
abbrev Triple := Fin 2 × Fin 2 × Fin 3

def coordinates (u : V) : Triple := (u 0, u 1, u 2)
def fromTriple (t : Triple) : V := fun j =>
  ⟨(![t.1.val, t.2.1.val, t.2.2.val]) j, by
    fin_cases j
    · exact t.1.isLt
    · exact t.2.1.isLt
    · exact t.2.2.isLt⟩

def coordinateEquiv : V ≃ Triple where
  toFun := coordinates
  invFun := fromTriple
  left_inv := by intro u; funext j; fin_cases j <;> rfl
  right_inv := by rintro ⟨a, b, c⟩; rfl

theorem from_coordinates (u : V) : fromTriple (coordinates u) = u := coordinateEquiv.left_inv u
theorem coordinates_from (t : Triple) : coordinates (fromTriple t) = t := coordinateEquiv.right_inv t

def TripleArc (a b : Triple) : Prop :=
  ((b.1.val = (a.1.val + 1) % 2) ∧ b.2 = a.2) ∨
  (b.1 = a.1 ∧ b.2.1.val = (a.2.1.val + 1) % 2 ∧ b.2.2 = a.2.2) ∨
  (b.1 = a.1 ∧ b.2.1 = a.2.1 ∧ b.2.2.val = (a.2.2.val + 1) % 3)

theorem adjacency_both_directions : ∀ u v : V,
    Arc u v ↔ TripleArc (coordinates u) (coordinates v) := by unfold Arc TripleArc; decide

theorem source_cardinality : Fintype.card V = 12 := by decide
theorem triple_cardinality : Fintype.card Triple = 12 := by decide
theorem start_transport : coordinates start = (0, 0, 0) := rfl
theorem finish_transport : coordinates finish = (0, 0, 1) := rfl

-- Exact transport of a spanning simple directed sequence, in both directions.
def TripleHamiltonian (u v : Triple) : Prop :=
  ∃ n, ∃ f : Fin (n + 1) → Triple,
    f 0 = u ∧ f (Fin.last n) = v ∧
    (∀ i : Fin n, TripleArc (f i.castSucc) (f i.succ)) ∧
    Function.Injective f ∧ Function.Surjective f

theorem path_transport (u v : V) :
    Hamiltonian u v ↔ TripleHamiltonian (coordinates u) (coordinates v) := by
  constructor
  · rintro ⟨n, f, h0, hl, ha, hi, hs⟩
    refine ⟨n, coordinates ∘ f, congrArg coordinates h0, congrArg coordinates hl, ?_,
      coordinateEquiv.injective.comp hi, coordinateEquiv.surjective.comp hs⟩
    intro i
    exact (adjacency_both_directions _ _).mp (ha i)
  · rintro ⟨n, f, h0, hl, ha, hi, hs⟩
    refine ⟨n, fromTriple ∘ f, ?_, ?_, ?_, coordinateEquiv.symm.injective.comp hi,
      coordinateEquiv.symm.surjective.comp hs⟩
    · simpa only [Function.comp_apply, from_coordinates] using congrArg fromTriple h0
    · simpa only [Function.comp_apply, from_coordinates] using congrArg fromTriple hl
    · intro i
      apply (adjacency_both_directions _ _).mpr
      simpa only [Function.comp_apply, coordinates_from] using ha i

#print axioms adjacency_both_directions
#print axioms path_transport
end Torus377269
