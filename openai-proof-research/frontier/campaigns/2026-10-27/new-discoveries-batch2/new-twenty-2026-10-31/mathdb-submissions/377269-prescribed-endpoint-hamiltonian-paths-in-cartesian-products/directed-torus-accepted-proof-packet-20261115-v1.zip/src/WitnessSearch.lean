import SourceSemantics
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Finset.Erase

namespace Torus377269
abbrev V := Vertex lengths

def step (u : V) (i : Fin 3) : V := fun j =>
  if j = i then ⟨((u j).val + 1) % lengths j, Nat.mod_lt _ (by have := valid_lengths j; omega)⟩ else u j

theorem arc_step (u v : V) : Arc u v ↔ ∃ i, step u i = v := by
  constructor
  · rintro ⟨i, hi, hj⟩
    refine ⟨i, ?_⟩
    funext j
    by_cases h : j = i
    · subst j
      apply Fin.ext
      simpa [step] using hi.symm
    · simpa [step, h] using (hj j h).symm
  · rintro ⟨i, rfl⟩
    exact ⟨i, by simp [step], by intro j hj; simp [step, hj]⟩

-- Bounded subset recurrence: the remaining set loses the next vertex at each arc.
def search : ℕ → V → V → Finset V → Prop
  | 0, u, v, s => u = v ∧ s = ∅
  | n + 1, u, v, s => ∃ i : Fin 3,
      step u i ∈ s ∧ search n (step u i) v (s.erase (step u i))

instance searchDecidable (n : ℕ) (u v : V) (s : Finset V) : Decidable (search n u v s) := by
  induction n generalizing u s with
  | zero => unfold search; infer_instance
  | succ n ih => unfold search; exact Fintype.decidableExistsFintype

-- Completeness for genuine nonrepeating directed vertex sequences.
theorem sequence_search (n : ℕ) (f : Fin (n + 1) → V)
    (hf : Function.Injective f)
    (ha : ∀ i : Fin n, Arc (f i.castSucc) (f i.succ))
    (s : Finset V)
    (hs : ∀ w, w ∈ s ↔ ∃ i : Fin n, f i.succ = w) :
    search n (f 0) (f (Fin.last n)) s := by
  induction n generalizing s with
  | zero =>
    refine ⟨rfl, ?_⟩
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro w hw
    obtain ⟨i, _⟩ := (hs w).mp hw
    exact Fin.elim0 i
  | succ n ih =>
    obtain ⟨i, hi⟩ := (arc_step _ _).mp (ha 0)
    refine ⟨i, ?_, ?_⟩
    · apply (hs _).mpr
      exact ⟨0, hi.symm⟩
    · let g : Fin (n + 1) → V := fun j => f j.succ
      have hg : Function.Injective g := hf.comp (Fin.succ_injective _)
      have hga : ∀ j : Fin n, Arc (g j.castSucc) (g j.succ) := fun j => ha j.succ
      have hgs : ∀ w, w ∈ s.erase (step (f 0) i) ↔ ∃ j : Fin n, g j.succ = w := by
        intro w
        rw [Finset.mem_erase, hs]
        constructor
        · rintro ⟨hw, j, hj⟩
          refine Fin.cases ?_ (fun a => ?_) j hj
          · intro h0
            exact (hw (h0.symm.trans hi.symm)).elim
          · intro ha'
            exact ⟨a, ha'⟩
        · rintro ⟨j, hj⟩
          refine ⟨?_, j.succ, hj⟩
          intro he
          have heq := hf (hj.trans (he.trans hi))
          have hv := congrArg Fin.val heq
          simp at hv
      have out := ih g hg hga (s.erase (step (f 0) i)) hgs
      change search n (f 1) (f (Fin.last (n + 1))) (s.erase (step (f 0) i)) at out
      change step (f 0) i = f 1 at hi
      simpa only [hi] using out

theorem hamiltonian_search (h : Hamiltonian start finish) :
    search 11 start finish (Finset.univ.erase start) := by
  obtain ⟨n, f, hu, hv, ha, hf, hcover⟩ := h
  have hc : Fintype.card V = 12 := by decide
  have hn : n = 11 := by
    have he := Fintype.card_congr (Equiv.ofBijective f ⟨hf, hcover⟩)
    rw [Fintype.card_fin, hc] at he
    omega
  subst n
  have hs : ∀ w, w ∈ Finset.univ.erase start ↔ ∃ i : Fin 11, f i.succ = w := by
    intro w
    simp only [Finset.mem_erase, Finset.mem_univ, and_true]
    constructor
    · intro hw
      obtain ⟨j, hj⟩ := hcover w
      refine Fin.cases ?_ (fun i => ?_) j hj
      · intro h0
        exact (hw (h0.symm.trans hu)).elim
      · intro hi
        exact ⟨i, hi⟩
    · rintro ⟨i, hi⟩ he
      have hh := hf (hi.trans (he.trans hu.symm))
      have := congrArg Fin.val hh
      simp at this
  have out := sequence_search 11 f hf ha _ hs
  simpa only [hu, hv] using out

-- Soundness: a positive recurrence state reconstructs an actual simple sequence.
theorem search_sequence (n : ℕ) (u v : V) (s : Finset V)
    (hu : u ∉ s) (h : search n u v s) :
    ∃ f : Fin (n + 1) → V,
      f 0 = u ∧ f (Fin.last n) = v ∧
      (∀ i : Fin n, Arc (f i.castSucc) (f i.succ)) ∧
      Function.Injective f ∧
      ∀ w, w ∈ s ↔ ∃ i : Fin n, f i.succ = w := by
  induction n generalizing u s with
  | zero =>
    obtain ⟨rfl, rfl⟩ := h
    refine ⟨fun _ => u, rfl, rfl, fun i => Fin.elim0 i, ?_, ?_⟩
    · intro a b _; apply Fin.ext; omega
    · intro w
      simp only [Finset.notMem_empty, false_iff, not_exists]
      intro i; exact Fin.elim0 i
  | succ n ih =>
    obtain ⟨i, hi, hr⟩ := h
    let a := step u i
    obtain ⟨g, hg0, hgl, hga, hgi, hgs⟩ :=
      ih a (s.erase a) (Finset.notMem_erase a s) hr
    have gm : ∀ j, g j ∈ s := by
      intro j
      refine Fin.cases ?_ (fun b => ?_) j
      · simpa only [hg0] using hi
      · exact Finset.mem_of_mem_erase ((hgs _).mpr ⟨b, rfl⟩)
    refine ⟨Fin.cases u g, rfl, ?_, ?_, ?_, ?_⟩
    · rw [show Fin.last (n + 1) = (Fin.last n).succ from rfl]
      exact hgl
    · intro j
      refine Fin.cases ?_ (fun b => ?_) j
      · change Arc u (g 0)
        rw [hg0]
        exact (arc_step u a).mpr ⟨i, rfl⟩
      · exact hga b
    · intro x y hxy
      refine Fin.cases ?_ (fun b => ?_) x hxy
      · intro hxy
        refine Fin.cases (fun _ => rfl) (fun c hc => ?_) y hxy
        change u = g c at hc
        exact (hu (hc.symm ▸ gm c)).elim
      · intro hxy
        refine Fin.cases (fun hc => ?_) (fun c hc => ?_) y hxy
        · change g b = u at hc
          exact (hu (hc ▸ gm b)).elim
        · exact congrArg Fin.succ (hgi hc)
    · intro w
      change w ∈ s ↔ ∃ j : Fin (n + 1), g j = w
      constructor
      · intro hw
        by_cases he : w = a
        · exact ⟨0, hg0.trans he.symm⟩
        · obtain ⟨j, hj⟩ := (hgs w).mp (Finset.mem_erase.mpr ⟨he, hw⟩)
          exact ⟨j.succ, hj⟩
      · rintro ⟨j, rfl⟩
        exact gm j

theorem recurrence_iff_hamiltonian :
    search 11 start finish (Finset.univ.erase start) ↔ Hamiltonian start finish := by
  constructor
  · intro h
    obtain ⟨f, h0, hl, ha, hi, hs⟩ :=
      search_sequence 11 start finish _ (Finset.notMem_erase _ _) h
    refine ⟨11, f, h0, hl, ha, hi, ?_⟩
    intro w
    by_cases he : w = start
    · exact ⟨0, h0.trans he.symm⟩
    · obtain ⟨j, hj⟩ := (hs w).mp (Finset.mem_erase.mpr ⟨he, Finset.mem_univ _⟩)
      exact ⟨j.succ, hj⟩
  · exact hamiltonian_search

set_option maxRecDepth 1000000 in
set_option maxHeartbeats 10000000 in
theorem negative_search : ¬ search 11 start finish (Finset.univ.erase start) := by
  decide

 theorem no_hamiltonian : ¬ Hamiltonian start finish := fun h => negative_search (hamiltonian_search h)
 theorem refutation : ¬ Universal := reduce_universal no_hamiltonian
 theorem distinct_refutation : ¬ DistinctUniversal := reduce_distinct no_hamiltonian
#print axioms no_hamiltonian
#print axioms refutation
#print axioms distinct_refutation

end Torus377269
