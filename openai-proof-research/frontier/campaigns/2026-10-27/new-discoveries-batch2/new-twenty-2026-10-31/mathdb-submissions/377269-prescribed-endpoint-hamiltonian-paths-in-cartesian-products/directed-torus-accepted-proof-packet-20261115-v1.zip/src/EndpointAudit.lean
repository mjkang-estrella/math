import ProductBridge

namespace Torus377269
-- No certificate, graph, distance or nonexistence hypothesis is a premise.
theorem expanded_unconditional :
    ¬ (∀ (k : ℕ), 3 ≤ k → ∀ (m : Fin k → ℕ), (∀ i, 2 ≤ m i) →
      ∀ (u v : (i : Fin k) → Fin (m i)),
      (∃ n, ∃ f : Fin (n + 1) → ((i : Fin k) → Fin (m i)),
        f 0 = u ∧ f (Fin.last n) = v ∧
        (∀ t : Fin n, ∃ i : Fin k,
          (f t.succ i).val = ((f t.castSucc i).val + 1) % m i ∧
          ∀ j, j ≠ i → f t.succ j = f t.castSucc j) ∧
        Function.Injective f ∧ Function.Surjective f) ↔
        (((List.ofFn m).foldr Nat.gcd 0 : ℕ) : ℤ) ∣ ((distance u v : ℤ) + 1)) :=
  refutation

theorem expanded_distinct_unconditional :
    ¬ (∀ (k : ℕ), 3 ≤ k → ∀ (m : Fin k → ℕ), (∀ i, 2 ≤ m i) →
      ∀ (u v : (i : Fin k) → Fin (m i)), u ≠ v →
      ((∃ n, ∃ f : Fin (n + 1) → ((i : Fin k) → Fin (m i)),
        f 0 = u ∧ f (Fin.last n) = v ∧
        (∀ t : Fin n, ∃ i : Fin k,
          (f t.succ i).val = ((f t.castSucc i).val + 1) % m i ∧
          ∀ j, j ≠ i → f t.succ j = f t.castSucc j) ∧
        Function.Injective f ∧ Function.Surjective f) ↔
        (((List.ofFn m).foldr Nat.gcd 0 : ℕ) : ℤ) ∣ ((distance u v : ℤ) + 1))) :=
  distinct_refutation

#print expanded_unconditional
#print expanded_distinct_unconditional
#print distance
#print distance_minimum
#print Walk
#print Arc
#print factorGCD
#print search
#print search_sequence
#print sequence_search
#print recurrence_iff_hamiltonian
#print coordinateEquiv
#print TripleArc
#print adjacency_both_directions
#print path_transport
#eval Lean.versionString
#print axioms expanded_unconditional
#print axioms expanded_distinct_unconditional
#print axioms recurrence_iff_hamiltonian
#print axioms search_sequence
#print axioms sequence_search
#print axioms coordinateEquiv
#print axioms adjacency_both_directions
#print axioms path_transport
#print axioms witness_distance
end Torus377269
