# FORMAL HANDOFF v1 — MathDB377269

Closed source-level refutation and distinct-endpoint refutation. Complete standalone ordinary proof and literal dependency-ordered Lean source are in PAPER-v1.md. The witness is the actual directed product of lengths(2,2,3), start000 and finish001. Both are different; shortest distance1 and gcd1 hold, but no Hamiltonian path exists. No endpoint premise is assumed.

Production: SourceSemantics -> WitnessSearch -> ProductBridge -> EndpointAudit. The full actual sequence definition has consecutive directed product arcs, specified endpoints, injection and surjection. The subset recurrence loses the next actual vertex and has proved sequence completeness and soundness; recurrence_iff_hamiltonian is an exact equivalence at the initial full-set state. negative_search is ordinary kernel reduction with decide, not native evaluation, a 12! sweep or an external data oracle. Product coordinate equivalence, both adjacency directions, cardinality and path/endpoint transport are proved. The distance definition is actual least walk length, and its witness minimum is proved with an explicit arc and exclusion of zero-length walks.

## Expanded unconditional endpoint/distance audit

The following is actual final compiler output. It expands the universal graph/path hypotheses and prints the least-walk definition. Walk itself is printed immediately afterward in the full audit; it is the existential finite vertex sequence with actual arcs, as fully listed in the paper. No graph/representation/distance/certificate proposition is a premise.

```text
theorem Torus377269.expanded_unconditional : ¬∀ (k : ℕ),
    3 ≤ k →
      ∀ (m : Fin k → ℕ),
        (∀ (i : Fin k), 2 ≤ m i) →
          ∀ (u v : (i : Fin k) → Fin (m i)),
            (∃ n f,
                f 0 = u ∧
                  f (Fin.last n) = v ∧
                    (∀ (t : Fin n),
                        ∃ i,
                          ↑(f t.succ i) = (↑(f t.castSucc i) + 1) % m i ∧
                            ∀ (j : Fin k), j ≠ i → f t.succ j = f t.castSucc j) ∧
                      Function.Injective f ∧ Function.Surjective f) ↔
              ↑(List.foldr Nat.gcd 0 (List.ofFn m)) ∣ ↑(distance u v) + 1 :=
refutation
theorem Torus377269.expanded_distinct_unconditional : ¬∀ (k : ℕ),
    3 ≤ k →
      ∀ (m : Fin k → ℕ),
        (∀ (i : Fin k), 2 ≤ m i) →
          ∀ (u v : (i : Fin k) → Fin (m i)),
            u ≠ v →
              ((∃ n f,
                  f 0 = u ∧
                    f (Fin.last n) = v ∧
                      (∀ (t : Fin n),
                          ∃ i,
                            ↑(f t.succ i) = (↑(f t.castSucc i) + 1) % m i ∧
                              ∀ (j : Fin k), j ≠ i → f t.succ j = f t.castSucc j) ∧
                        Function.Injective f ∧ Function.Surjective f) ↔
                ↑(List.foldr Nat.gcd 0 (List.ofFn m)) ∣ ↑(distance u v) + 1) :=
distinct_refutation
def Torus377269.distance : {k : ℕ} → {m : Fin k → ℕ} → Vertex m → Vertex m → ℕ :=
fun {k} {m} u v => if h : ∃ n, Walk u v n then Nat.find h else 0
```

## Transitive axiom audit

```text
'Torus377269.expanded_unconditional' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.expanded_distinct_unconditional' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.recurrence_iff_hamiltonian' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.search_sequence' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.sequence_search' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.coordinateEquiv' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.adjacency_both_directions' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.path_transport' depends on axioms: [propext, Classical.choice, Quot.sound]
'Torus377269.witness_distance' depends on axioms: [propext, Classical.choice, Quot.sound]```

## Verification and accounting

SELF extracted replay PASS: formal20/21 SourceSemantics, formal22/23 WitnessSearch, formal24/25 ProductBridge, formal26/27 EndpointAudit, in each pair compile then separate leanchecker. The extractor checked all four appendix byte hashes and byte equality before rebuilding; final re-extraction verifies unchanged source bytes. Each tool's complete stdout/stderr/command/caps is retained in its receipt/output pair. Runtime version4.34.1 was queried through the counted formal wrapper. All operations use frozen32G wrappers on CPUs4,5. There were27/72 total formal invocations, including9 failures. Zero scientific generation/validation runs, zero GET/search, no children, installs, git, account/message/publication actions, other-lane or ledger/count edits. resource-accounting-v1.json has actual aggregate formal CPU/wall/RSS. Documentary runner/writer and finalization overhead are separate from that formal sum. Immutable limits are unchanged.

## Source, reading and qualification limits

Read full TASK/override, applicable AGENTS, own run/write interfaces and operative control fields; machine-screened large restriction/ownership JSON keys/scalars. Read exact owned MathDB statement, restored primary title/authors, primary directed.txt first10000 characters and rendered/inspected PDF p2-3; read the independent ordinary proof and inherited process section. Entire remaining independent dossier, producer INVESTIGATION, auxiliary acceptance statements and remainder of primary manuscript are not claimed personally read. Origins and other project evidence were not followed. Source-v1/raw-live/ordinary PASS and bounded SUBSTANTIAL adoption are supplied evidentiary inputs, not axioms or fresh implementation verdicts. No journal-final equivalence, worldwide novelty, clean process, acceptance or credit is claimed. Current count71/80NEW110total is unchanged; older count strings in frozen inputs remain historical.

## UNWAIVED defects

Current: oversized interface payload; direct initial helper-interface read; oversized/truncated campaign/ownership display; unrelated early restriction diagnostics before corrected target-specific screening; excessive formal01 display; functions-side JavaScript syntax failure before command execution; final-document receipt-label KeyError (formal1 versus formal01), corrected with failed runner receipt retained; guessed standard import/interface before direct pinned-source reading, with missing Omega import failure and later correction. The first final-preseal documentary audit failed because it counted an extractor regex literal as an additional appendix marker; the corrected audit anchors markers at line starts. This failure is preserved and UNWAIVED. All failed compiler drafts and generated failed-draft sorryAx diagnostic output are retained and segregated from production audits. The formal07 successful helper-only source was reconstructed from its preserved formal08 prefix, rather than snapshotted before the next change; its reconstructed bytes were compared to and exactly match the original formal07 receipt digest. This preservation limitation is not waived.

Inherited reviewer: oversized/truncated TASK, failed taskset literal spelling, overlarge diagnostics, late control normalization, serialization failure, uninstrumented redirect hops and diagnostic wall-bound enforcement weakness. Producer: oversized TASK, bootstrap/order and direct-interface deviations, control dump/truncation/timing and redirect accounting. Complete inherited reports stay frozen. A correct proof does not waive process defects.

## Finalization and remaining independent gates

Frozen-before matched48/48 inputs. After all document writes, run standalone frozen-after and then the exhaustive physical seal. Seal excludes exactly physical-seal-v1.sha256, physical-seal.receipt.json and physical-seal.output.txt. NO command/write may follow the seal. Those final receipts carry actual frozen-after and seal outcomes; no prospective success is asserted here.

Required afterward: a fresh independent reviewer must extract the paper, compare exact source/version/types, rebuild every module, separately kernel-check each, inspect expanded unconditional endpoints/providers/axioms and adjudicate the unwaived process defects and all acceptance/novelty/significance gates. This implementation does not accept itself. There is no remaining mathematical endpoint interface or Lean placeholder in production.
