import EndpointAudit
namespace Independent377269
open Torus377269
theorem literal_refutation :
  ¬ (∀ (k : ℕ), 3 ≤ k → ∀ (m : Fin k → ℕ), (∀ i, 2 ≤ m i) →
    ∀ (u v : (i : Fin k) → Fin (m i)), ((∃ n, ∃ f : Fin (n + 1) → ((i : Fin k) → Fin (m i)),
        f 0 = u ∧ f (Fin.last n) = v ∧
        (∀ t : Fin n, ∃ i : Fin k,
          (f t.succ i).val = ((f t.castSucc i).val + 1) % m i ∧
          ∀ j, j ≠ i → f t.succ j = f t.castSucc j) ∧
        Function.Injective f ∧ Function.Surjective f) ↔ (∃ d : ℕ, (∃ g : Fin (d + 1) → ((i : Fin k) → Fin (m i)),
          g 0 = u ∧ g (Fin.last d) = v ∧
          ∀ t : Fin d, ∃ i : Fin k,
            (g t.succ i).val = ((g t.castSucc i).val + 1) % m i ∧
            ∀ j, j ≠ i → g t.succ j = g t.castSucc j) ∧
        (∀ r : ℕ, (∃ g : Fin (r + 1) → ((i : Fin k) → Fin (m i)),
          g 0 = u ∧ g (Fin.last r) = v ∧
          ∀ t : Fin r, ∃ i : Fin k,
            (g t.succ i).val = ((g t.castSucc i).val + 1) % m i ∧
            ∀ j, j ≠ i → g t.succ j = g t.castSucc j) → d ≤ r) ∧
        (((List.ofFn m).foldr Nat.gcd 0 : ℕ) : ℤ) ∣ ((d : ℤ) + 1)))) := by
  intro h
  apply no_hamiltonian
  apply (h 3 (by decide) lengths valid_lengths start finish).mpr
  refine ⟨1, one_walk, ?_, ?_⟩
  · intro r hr
    have hm := (distance_minimum (u := start) (v := finish) ⟨1, one_walk⟩).2 r hr
    simpa only [witness_distance] using hm
  · change (factorGCD lengths : ℤ) ∣ (1 + 1)
    rw [witness_gcd]
    exact ⟨2, rfl⟩
theorem literal_distinct_refutation :
  ¬ (∀ (k : ℕ), 3 ≤ k → ∀ (m : Fin k → ℕ), (∀ i, 2 ≤ m i) →
    ∀ (u v : (i : Fin k) → Fin (m i)), u ≠ v → ((∃ n, ∃ f : Fin (n + 1) → ((i : Fin k) → Fin (m i)),
        f 0 = u ∧ f (Fin.last n) = v ∧
        (∀ t : Fin n, ∃ i : Fin k,
          (f t.succ i).val = ((f t.castSucc i).val + 1) % m i ∧
          ∀ j, j ≠ i → f t.succ j = f t.castSucc j) ∧
        Function.Injective f ∧ Function.Surjective f) ↔ (∃ d : ℕ, (∃ g : Fin (d + 1) → ((i : Fin k) → Fin (m i)),
          g 0 = u ∧ g (Fin.last d) = v ∧
          ∀ t : Fin d, ∃ i : Fin k,
            (g t.succ i).val = ((g t.castSucc i).val + 1) % m i ∧
            ∀ j, j ≠ i → g t.succ j = g t.castSucc j) ∧
        (∀ r : ℕ, (∃ g : Fin (r + 1) → ((i : Fin k) → Fin (m i)),
          g 0 = u ∧ g (Fin.last r) = v ∧
          ∀ t : Fin r, ∃ i : Fin k,
            (g t.succ i).val = ((g t.castSucc i).val + 1) % m i ∧
            ∀ j, j ≠ i → g t.succ j = g t.castSucc j) → d ≤ r) ∧
        (((List.ofFn m).foldr Nat.gcd 0 : ℕ) : ℤ) ∣ ((d : ℤ) + 1)))) := by
  intro h
  apply no_hamiltonian
  apply (h 3 (by decide) lengths valid_lengths start finish distinct).mpr
  refine ⟨1, one_walk, ?_, ?_⟩
  · intro r hr
    have hm := (distance_minimum (u := start) (v := finish) ⟨1, one_walk⟩).2 r hr
    simpa only [witness_distance] using hm
  · change (factorGCD lengths : ℤ) ∣ (1 + 1)
    rw [witness_gcd]
    exact ⟨2, rfl⟩

#print literal_refutation
#print literal_distinct_refutation
#print axioms literal_refutation
#print axioms literal_distinct_refutation
#print axioms Torus377269.refutation
#print axioms Torus377269.distinct_refutation
#print axioms Torus377269.expanded_unconditional
#print axioms Torus377269.expanded_distinct_unconditional
#print axioms Torus377269.no_hamiltonian
#print axioms Torus377269.negative_search
#print axioms Torus377269.distinct
end Independent377269
