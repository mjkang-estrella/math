import Mathlib.Data.Nat.Find
import Mathlib.Data.Fintype.Card
import Mathlib.Data.Fin.VecNotation
import Mathlib.Tactic.FinCases
import Lean.Elab.Tactic.Omega

namespace Torus377269

abbrev Vertex {k : ℕ} (m : Fin k → ℕ) := (i : Fin k) → Fin (m i)

def Arc {k : ℕ} {m : Fin k → ℕ} (u v : Vertex m) : Prop :=
  ∃ i, (v i).val = ((u i).val + 1) % m i ∧ ∀ j, j ≠ i → v j = u j

-- A walk is an actual consecutive sequence of vertices with n directed arcs.
def Walk {k : ℕ} {m : Fin k → ℕ} (u v : Vertex m) (n : ℕ) : Prop :=
  ∃ f : Fin (n + 1) → Vertex m,
    f 0 = u ∧ f (Fin.last n) = v ∧
    ∀ i : Fin n, Arc (f i.castSucc) (f i.succ)

-- Injectivity is nonrepetition; surjectivity is coverage of every product vertex.
def Hamiltonian {k : ℕ} {m : Fin k → ℕ} (u v : Vertex m) : Prop :=
  ∃ n, ∃ f : Fin (n + 1) → Vertex m,
    f 0 = u ∧ f (Fin.last n) = v ∧
    (∀ i : Fin n, Arc (f i.castSucc) (f i.succ)) ∧
    Function.Injective f ∧ Function.Surjective f

noncomputable def distance {k : ℕ} {m : Fin k → ℕ} (u v : Vertex m) : ℕ := by
  classical
  exact if h : ∃ n, Walk u v n then @Nat.find (fun n => Walk u v n) (Classical.decPred _) h else 0

theorem distance_minimum {k : ℕ} {m : Fin k → ℕ} {u v : Vertex m}
    (h : ∃ n, Walk u v n) :
    Walk u v (distance u v) ∧ ∀ n, Walk u v n → distance u v ≤ n := by
  classical
  simp only [distance, dite_eq_left h]
  exact ⟨Nat.find_spec h, fun _ hn => Nat.find_min' h hn⟩

def lengths : Fin 3 → ℕ := ![2, 2, 3]
def start : Vertex lengths := fun i => ⟨0, by fin_cases i <;> decide⟩
def finish : Vertex lengths := fun i => ⟨if i = 2 then 1 else 0, by fin_cases i <;> decide⟩

theorem valid_lengths : ∀ i, 2 ≤ lengths i := by decide

theorem distinct : start ≠ finish := by
  intro h
  have hh := congrArg (fun f : Vertex lengths => (f 2).val) h
  change 0 = 1 at hh
  omega

theorem direct_arc : Arc start finish := by
  refine ⟨2, rfl, ?_⟩
  intro j hj
  fin_cases j <;> simp_all [start, finish, lengths]

theorem one_walk : Walk start finish 1 := by
  refine ⟨![start, finish], rfl, rfl, ?_⟩
  intro i
  fin_cases i
  exact direct_arc

theorem zero_walk_iff {k : ℕ} {m : Fin k → ℕ} (u v : Vertex m) :
    Walk u v 0 ↔ u = v := by
  constructor
  · rintro ⟨f, hu, hv, _⟩
    exact hu.symm.trans hv
  · intro h
    subst v
    exact ⟨fun _ => u, rfl, rfl, fun i => Fin.elim0 i⟩

theorem witness_distance : distance start finish = 1 := by
  have h := distance_minimum (u := start) (v := finish) ⟨1, one_walk⟩
  have hle := h.2 1 one_walk
  have hne : distance start finish ≠ 0 := by
    intro hz
    have h0 : Walk start finish 0 := hz ▸ h.1
    exact distinct ((zero_walk_iff _ _).mp h0)
  omega

-- gcd of all factor lengths, without any witness-specific assigned modulus.
def factorGCD {k : ℕ} (m : Fin k → ℕ) : ℕ :=
  (List.ofFn m).foldr Nat.gcd 0

def Congruence {k : ℕ} {m : Fin k → ℕ} (u v : Vertex m) : Prop :=
  (factorGCD m : ℤ) ∣ ((distance u v : ℤ) + 1)

theorem witness_gcd : factorGCD lengths = 1 := by decide

theorem witness_congruence : Congruence start finish := by
  simp [Congruence, witness_gcd]

def Universal : Prop :=
  ∀ (k : ℕ), 3 ≤ k → ∀ (m : Fin k → ℕ), (∀ i, 2 ≤ m i) →
    ∀ (u v : Vertex m), Hamiltonian u v ↔ Congruence u v

def DistinctUniversal : Prop :=
  ∀ (k : ℕ), 3 ≤ k → ∀ (m : Fin k → ℕ), (∀ i, 2 ≤ m i) →
    ∀ (u v : Vertex m), u ≠ v → (Hamiltonian u v ↔ Congruence u v)

-- These are conditional reductions, not the requested unconditional refutations.
theorem reduce_universal (h : ¬ Hamiltonian start finish) : ¬ Universal := by
  intro hu
  exact h ((hu 3 (by decide) lengths valid_lengths start finish).mpr witness_congruence)

theorem reduce_distinct (h : ¬ Hamiltonian start finish) : ¬ DistinctUniversal := by
  intro hu
  exact h ((hu 3 (by decide) lengths valid_lengths start finish distinct).mpr witness_congruence)

#print axioms witness_distance
#print axioms witness_congruence
#print axioms reduce_universal
#print axioms reduce_distinct
end Torus377269
