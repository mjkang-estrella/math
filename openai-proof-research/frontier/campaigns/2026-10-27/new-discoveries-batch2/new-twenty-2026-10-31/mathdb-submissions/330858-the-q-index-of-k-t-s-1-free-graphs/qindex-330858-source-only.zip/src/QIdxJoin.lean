import QIdxSpectral
import QIdxQuadratic

/-! # The join lemma (bound and equality) on internal data. -/

open SimpleGraph Matrix Finset

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- Internal form of "`K` is a clique of universal vertices and the rest has degree at most `s`". -/
structure JoinForm (G : SimpleGraph V) [DecidableRel G.Adj] (K : Finset V) (t s : ℕ) : Prop where
  card_K : K.card = t - 1
  adj_K : ∀ w ∈ K, ∀ v, v ≠ w → G.Adj w v
  deg_H : ∀ v, v ∉ K → ((G.neighborFinset v) \ K).card ≤ s

variable {K : Finset V} {t s : ℕ}

theorem JoinForm.nbr_eq_erase (hJ : JoinForm G K t s) {w : V} (hw : w ∈ K) :
    G.neighborFinset w = univ.erase w := by
  ext v
  simp only [SimpleGraph.mem_neighborFinset, Finset.mem_erase, Finset.mem_univ, and_true]
  exact ⟨fun h => h.ne', fun h => hJ.adj_K w hw v h⟩

theorem JoinForm.K_subset_nbr (hJ : JoinForm G K t s) {v : V} (hv : v ∉ K) :
    K ⊆ G.neighborFinset v := by
  intro w hw
  rw [SimpleGraph.mem_neighborFinset]
  have hne : v ≠ w := fun h => hv (h ▸ hw)
  exact (hJ.adj_K w hw v hne).symm

theorem JoinForm.deg_K (hJ : JoinForm G K t s) {w : V} (hw : w ∈ K) :
    (G.degree w : ℝ) = (Fintype.card V : ℝ) - 1 := by
  have h1 : G.degree w = Fintype.card V - 1 := by
    rw [← G.card_neighborFinset_eq_degree, hJ.nbr_eq_erase hw,
      Finset.card_erase_of_mem (Finset.mem_univ w), Finset.card_univ]
  have hpos : 1 ≤ Fintype.card V := Fintype.card_pos_iff.mpr ⟨w⟩
  rw [h1, Nat.cast_sub hpos, Nat.cast_one]

theorem JoinForm.deg_compl (hJ : JoinForm G K t s) (ht : 2 ≤ t) {v : V} (hv : v ∉ K) :
    (G.degree v : ℝ) = ((((G.neighborFinset v) \ K).card : ℕ) : ℝ) + (t : ℝ) - 1 := by
  have h1 : ((G.neighborFinset v) \ K).card + K.card = G.degree v := by
    rw [← G.card_neighborFinset_eq_degree]
    exact Finset.card_sdiff_add_card_eq_card (hJ.K_subset_nbr hv)
  rw [hJ.card_K] at h1
  have h2 : (((G.neighborFinset v) \ K).card : ℝ) + ((t - 1 : ℕ) : ℝ) = (G.degree v : ℝ) := by
    exact_mod_cast h1
  rw [Nat.cast_sub (by omega : 1 ≤ t), Nat.cast_one] at h2
  linarith

theorem JoinForm.sum_compl (hJ : JoinForm G K t s) {v : V} (hv : v ∉ K) (x : V → ℝ) :
    ∑ w ∈ G.neighborFinset v, x w = ∑ w ∈ (G.neighborFinset v) \ K, x w + ∑ w ∈ K, x w :=
  (Finset.sum_sdiff (hJ.K_subset_nbr hv)).symm

theorem JoinForm.card_compl_eq (hJ : JoinForm G K t s) (ht : 2 ≤ t) (hn : t ≤ Fintype.card V) :
    ((Kᶜ : Finset V).card : ℝ) = qm (Fintype.card V) t := by
  have h1 : (Kᶜ : Finset V).card = Fintype.card V - (t - 1) := by
    rw [Finset.card_compl, hJ.card_K]
  have h2 : t - 1 ≤ Fintype.card V := by omega
  rw [h1, Nat.cast_sub h2, Nat.cast_sub (by omega : 1 ≤ t), Nat.cast_one]
  unfold qm; ring

set_option maxHeartbeats 1000000 in
/-- The join lemma: the eigenvalue of a nonnegative eigenvector is at most the printed bound,
with equality forcing `s`-regularity outside `K`. -/
theorem join_main (hJ : JoinForm G K t s) (ht : 2 ≤ t) (hn : t ≤ Fintype.card V)
    {x : V → ℝ} {q : ℝ} (hx : ∀ v, 0 ≤ x v) (hx0 : x ≠ 0)
    (heig : ∀ v, q * x v = G.degree v * x v + ∑ w ∈ G.neighborFinset v, x w) :
    q ≤ printedBound (Fintype.card V) s t ∧
      (q = printedBound (Fintype.card V) s t →
        ∀ v, v ∉ K → ((G.neighborFinset v) \ K).card = s) := by
  obtain ⟨hquad, hA, hB⟩ := printed_facts (s := s) ht hn
  have hmEq := hJ.card_compl_eq ht hn
  have htR : (2 : ℝ) ≤ t := by exact_mod_cast ht
  have hnR : (t : ℝ) ≤ (Fintype.card V : ℝ) := by exact_mod_cast hn
  have hmpos : 0 < qm (Fintype.card V) t := by unfold qm; linarith
  have ht1 : 0 < (t : ℝ) - 1 := by linarith
  have hKne : K.Nonempty := by
    rw [← Finset.card_pos, hJ.card_K]; omega
  have hKcne : (Kᶜ : Finset V).Nonempty := by
    rw [← Finset.card_pos]
    have : 0 < ((Kᶜ : Finset V).card : ℝ) := by rw [hmEq]; exact hmpos
    exact_mod_cast this
  obtain ⟨w0, hw0, hmaxK⟩ := Finset.exists_max_image K x hKne
  obtain ⟨u0, hu0, hmaxC⟩ := Finset.exists_max_image (Kᶜ : Finset V) x hKcne
  have hu0' : u0 ∉ K := Finset.mem_compl.mp hu0
  obtain ⟨a, ha⟩ : ∃ a, a = x w0 := ⟨_, rfl⟩
  obtain ⟨b, hb⟩ : ∃ b, b = x u0 := ⟨_, rfl⟩
  have ha0 : 0 ≤ a := ha ▸ hx w0
  have hb0 : 0 ≤ b := hb ▸ hx u0
  have hKa : ∀ w ∈ K, x w ≤ a := fun w hw => ha ▸ hmaxK w hw
  have hCb : ∀ v, v ∉ K → x v ≤ b := fun v hv => hb ▸ hmaxC v (Finset.mem_compl.mpr hv)
  have hcardK : (K.card : ℝ) = (t : ℝ) - 1 := by
    rw [hJ.card_K, Nat.cast_sub (by omega : 1 ≤ t), Nat.cast_one]
  have hSK : ∑ w ∈ K, x w ≤ ((t : ℝ) - 1) * a := by
    calc ∑ w ∈ K, x w ≤ ∑ _w ∈ K, a := Finset.sum_le_sum hKa
      _ = ((t : ℝ) - 1) * a := by rw [Finset.sum_const, nsmul_eq_mul, hcardK]
  have hSC : ∑ w ∈ (Kᶜ : Finset V), x w ≤ qm (Fintype.card V) t * b := by
    calc ∑ w ∈ (Kᶜ : Finset V), x w ≤ ∑ _w ∈ (Kᶜ : Finset V), b :=
          Finset.sum_le_sum (fun v hv => hCb v (Finset.mem_compl.mp hv))
      _ = qm (Fintype.card V) t * b := by rw [Finset.sum_const, nsmul_eq_mul, hmEq]
  have hsplit : ∑ w, x w = ∑ w ∈ K, x w + ∑ w ∈ (Kᶜ : Finset V), x w :=
    (Finset.sum_add_sum_compl K x).symm
  -- inequality at w0
  have hIA : (q - qA (Fintype.card V) t) * a ≤ qm (Fintype.card V) t * b := by
    have he := heig w0
    rw [← ha, hJ.deg_K hw0, hJ.nbr_eq_erase hw0, Finset.sum_erase_eq_sub (Finset.mem_univ w0),
      hsplit, ← ha] at he
    have hexp : (q - qA (Fintype.card V) t) * a =
        q * a - ((Fintype.card V : ℝ) + t - 3) * a := by unfold qA; ring
    rw [hexp]
    linarith
  -- inequality at u0
  obtain ⟨dH, hdH⟩ : ∃ dH, dH = (((G.neighborFinset u0) \ K).card : ℝ) := ⟨_, rfl⟩
  have hdHle : dH ≤ (s : ℝ) := by rw [hdH]; exact_mod_cast hJ.deg_H u0 hu0'
  have hdH0 : 0 ≤ dH := by rw [hdH]; positivity
  have hIBall : q * b ≤ ((2 * dH + t - 1)) * b + ((t : ℝ) - 1) * a := by
    have he := heig u0
    have hSH : ∑ w ∈ (G.neighborFinset u0) \ K, x w ≤ dH * b := by
      calc ∑ w ∈ (G.neighborFinset u0) \ K, x w ≤ ∑ _w ∈ (G.neighborFinset u0) \ K, b :=
            Finset.sum_le_sum (fun v hv => hCb v (Finset.mem_sdiff.mp hv).2)
        _ = dH * b := by rw [Finset.sum_const, nsmul_eq_mul, hdH]
    rw [← hb, hJ.deg_compl ht hu0', hJ.sum_compl hu0', ← hdH] at he
    nlinarith
  have hIB : (q - qB s t) * b ≤ ((t : ℝ) - 1) * a := by
    have hexp : (q - qB s t) * b = q * b - (2 * (s : ℝ) + t - 1) * b := by unfold qB; ring
    rw [hexp]
    have hsb : dH * b ≤ (s : ℝ) * b := mul_le_mul_of_nonneg_right hdHle hb0
    nlinarith
  by_cases hgt : qA (Fintype.card V) t < q ∧ qB s t < q
  · obtain ⟨hqA, hqB⟩ := hgt
    have hqAp : 0 < q - qA (Fintype.card V) t := by linarith
    have hqBp : 0 < q - qB s t := by linarith
    have hb_pos : 0 < b := by
      by_contra hcon
      have hb00 : b = 0 := le_antisymm (not_lt.mp hcon) hb0
      have h1 : (q - qA (Fintype.card V) t) * a ≤ 0 := by rw [hb00, mul_zero] at hIA; exact hIA
      have ha00 : a = 0 := by
        by_contra hane
        have : 0 < a := lt_of_le_of_ne ha0 (Ne.symm hane)
        have := mul_pos hqAp this
        linarith
      apply hx0
      funext v
      have hv0 : x v = 0 := by
        by_cases hv : v ∈ K
        · exact le_antisymm (by have := hKa v hv; linarith) (hx v)
        · exact le_antisymm (by have := hCb v hv; linarith) (hx v)
      simpa using hv0
    have ha_pos : 0 < a := by
      by_contra hcon
      have ha00 : a = 0 := le_antisymm (not_lt.mp hcon) ha0
      have h1 : (q - qB s t) * b ≤ 0 := by rw [ha00, mul_zero] at hIB; exact hIB
      have := mul_pos hqBp hb_pos
      linarith
    -- product inequality
    have hprod : (q - qA (Fintype.card V) t) * (q - qB s t) ≤ qm (Fintype.card V) t * ((t : ℝ) - 1) := by
      have h1 : (q - qA (Fintype.card V) t) * (q - qB s t) * a ≤ qm (Fintype.card V) t * ((q - qB s t) * b) := by
        calc (q - qA (Fintype.card V) t) * (q - qB s t) * a
            = (q - qB s t) * ((q - qA (Fintype.card V) t) * a) := by ring
          _ ≤ (q - qB s t) * (qm (Fintype.card V) t * b) :=
              mul_le_mul_of_nonneg_left hIA hqBp.le
          _ = qm (Fintype.card V) t * ((q - qB s t) * b) := by ring
      have h2 : qm (Fintype.card V) t * ((q - qB s t) * b) ≤ qm (Fintype.card V) t * (((t : ℝ) - 1) * a) :=
        mul_le_mul_of_nonneg_left hIB hmpos.le
      have h3 : (q - qA (Fintype.card V) t) * (q - qB s t) * a ≤ qm (Fintype.card V) t * ((t : ℝ) - 1) * a := by
        calc _ ≤ _ := h1.trans h2
          _ = qm (Fintype.card V) t * ((t : ℝ) - 1) * a := by ring
      exact le_of_mul_le_mul_right h3 ha_pos
    refine ⟨root_le hquad hA hB hprod, ?_⟩
    intro hqeq
    have hqProd : (q - qA (Fintype.card V) t) * (q - qB s t) = qm (Fintype.card V) t * ((t : ℝ) - 1) := by
      rw [hqeq]; exact hquad
    -- tightness of the first inequality
    have eq1 : (q - qA (Fintype.card V) t) * a = qm (Fintype.card V) t * b := by
      refine le_antisymm hIA ?_
      by_contra hcon
      have hlt : (q - qA (Fintype.card V) t) * a < qm (Fintype.card V) t * b := not_le.mp hcon
      have h1 : (q - qB s t) * ((q - qA (Fintype.card V) t) * a) < (q - qB s t) * (qm (Fintype.card V) t * b) :=
        mul_lt_mul_of_pos_left hlt hqBp
      have h2 : qm (Fintype.card V) t * ((q - qB s t) * b) ≤ qm (Fintype.card V) t * (((t : ℝ) - 1) * a) :=
        mul_le_mul_of_nonneg_left hIB hmpos.le
      have h3 : (q - qA (Fintype.card V) t) * (q - qB s t) * a = qm (Fintype.card V) t * ((t : ℝ) - 1) * a := by
        rw [hqProd]
      nlinarith
    have eq2 : (q - qB s t) * b = ((t : ℝ) - 1) * a := by
      refine le_antisymm hIB ?_
      by_contra hcon
      have hlt : (q - qB s t) * b < ((t : ℝ) - 1) * a := not_le.mp hcon
      have h1 : qm (Fintype.card V) t * ((q - qB s t) * b) < qm (Fintype.card V) t * (((t : ℝ) - 1) * a) :=
        mul_lt_mul_of_pos_left hlt hmpos
      have h3 : (q - qA (Fintype.card V) t) * (q - qB s t) * a = qm (Fintype.card V) t * ((t : ℝ) - 1) * a := by
        rw [hqProd]
      nlinarith
    -- sum over complement is tight, so `x = b` on the complement
    have hSCge : qm (Fintype.card V) t * b ≤ ∑ w ∈ (Kᶜ : Finset V), x w := by
      have he := heig w0
      rw [← ha, hJ.deg_K hw0, hJ.nbr_eq_erase hw0, Finset.sum_erase_eq_sub (Finset.mem_univ w0),
        hsplit, ← ha] at he
      have hexp : (q - qA (Fintype.card V) t) * a =
          q * a - ((Fintype.card V : ℝ) + t - 3) * a := by unfold qA; ring
      nlinarith
    have hxC : ∀ v ∈ (Kᶜ : Finset V), x v = b := by
      have hSumZero : ∑ v ∈ (Kᶜ : Finset V), (b - x v) = 0 := by
        rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul, hmEq]
        linarith
      have hterms : ∀ v ∈ (Kᶜ : Finset V), 0 ≤ b - x v := fun v hv => by
        have := hCb v (Finset.mem_compl.mp hv); linarith
      intro v hv
      have := (Finset.sum_eq_zero_iff_of_nonneg hterms).mp hSumZero v hv
      linarith
    intro v hv
    have hvK : v ∈ (Kᶜ : Finset V) := Finset.mem_compl.mpr hv
    have hxv := hxC v hvK
    have he := heig v
    have hSH : ∑ w ∈ (G.neighborFinset v) \ K, x w = (((G.neighborFinset v) \ K).card : ℝ) * b := by
      calc ∑ w ∈ (G.neighborFinset v) \ K, x w = ∑ _w ∈ (G.neighborFinset v) \ K, b :=
            Finset.sum_congr rfl (fun w hw =>
              hxC w (Finset.mem_compl.mpr (Finset.mem_sdiff.mp hw).2))
        _ = (((G.neighborFinset v) \ K).card : ℝ) * b := by
            rw [Finset.sum_const, nsmul_eq_mul]
    obtain ⟨dv, hdv⟩ : ∃ dv, dv = (((G.neighborFinset v) \ K).card : ℝ) := ⟨_, rfl⟩
    rw [hxv, hJ.deg_compl ht hv, hJ.sum_compl hv, hSH, ← hdv] at he
    have hle : dv * b ≤ (s : ℝ) * b := by
      refine mul_le_mul_of_nonneg_right ?_ hb0
      rw [hdv]; exact_mod_cast hJ.deg_H v hv
    have heq2 : q * b = (2 * (s : ℝ) + t - 1) * b + ((t : ℝ) - 1) * a := by
      have h' : (q - qB s t) * b = q * b - (2 * (s : ℝ) + t - 1) * b := by unfold qB; ring
      linarith
    have hge : (s : ℝ) * b ≤ dv * b := by nlinarith
    have hsdv : (s : ℝ) ≤ dv := le_of_mul_le_mul_right hge hb_pos
    have hsdv2 : dv ≤ (s : ℝ) := by rw [hdv]; exact_mod_cast hJ.deg_H v hv
    rw [hdv] at hsdv
    have hfinal : (s : ℝ) ≤ (((G.neighborFinset v) \ K).card : ℝ) := hsdv
    have hfinal2 : s ≤ ((G.neighborFinset v) \ K).card := by exact_mod_cast hfinal
    exact le_antisymm (hJ.deg_H v hv) hfinal2
  · have hlt : q < printedBound (Fintype.card V) s t := by
      rw [not_and_or, not_lt, not_lt] at hgt
      rcases hgt with h | h <;> linarith
    exact ⟨hlt.le, fun h => absurd h hlt.ne⟩

/-- The converse: exact `s`-regularity outside `K` gives `qIndex G = printedBound`. -/
theorem join_regular_top (hJ : JoinForm G K t s) (ht : 2 ≤ t) (hn : t ≤ Fintype.card V)
    (hreg : ∀ v, v ∉ K → ((G.neighborFinset v) \ K).card = s) :
    qIndex G = printedBound (Fintype.card V) s t := by
  obtain ⟨hquad, hA, -⟩ := printed_facts (s := s) ht hn
  have hmEq := hJ.card_compl_eq ht hn
  have htR : (2 : ℝ) ≤ t := by exact_mod_cast ht
  have hnR : (t : ℝ) ≤ (Fintype.card V : ℝ) := by exact_mod_cast hn
  have hmpos : 0 < qm (Fintype.card V) t := by unfold qm; linarith
  have hKne : K.Nonempty := by rw [← Finset.card_pos, hJ.card_K]; omega
  have : Nonempty V := hKne.elim (fun w _ => ⟨w⟩)
  obtain ⟨Q, hQ⟩ : ∃ Q, Q = printedBound (Fintype.card V) s t := ⟨_, rfl⟩
  rw [← hQ] at hquad hA ⊢
  obtain ⟨m, hm⟩ : ∃ m, m = qm (Fintype.card V) t := ⟨_, rfl⟩
  rw [← hm] at hquad hmEq hmpos
  obtain ⟨b, hb⟩ : ∃ b, b = Q - qA (Fintype.card V) t := ⟨_, rfl⟩
  have hbpos : 0 < b := by rw [hb]; linarith
  have hcardK : (K.card : ℝ) = (t : ℝ) - 1 := by
    rw [hJ.card_K, Nat.cast_sub (by omega : 1 ≤ t), Nat.cast_one]
  let x : V → ℝ := fun v => if v ∈ K then m else b
  have hxK : ∀ v, v ∈ K → x v = m := fun v hv => ite_eq_left hv
  have hxC : ∀ v, v ∉ K → x v = b := fun v hv => ite_eq_right hv
  have hxpos : ∀ v, 0 < x v := by
    intro v
    by_cases hv : v ∈ K
    · rw [hxK v hv]; exact hmpos
    · rw [hxC v hv]; exact hbpos
  have hSumK : ∑ w ∈ K, x w = ((t : ℝ) - 1) * m := by
    rw [Finset.sum_congr rfl (fun w hw => hxK w hw), Finset.sum_const, nsmul_eq_mul, hcardK]
  have hSumC : ∑ w ∈ (Kᶜ : Finset V), x w = m * b := by
    rw [Finset.sum_congr rfl (fun w hw => hxC w (Finset.mem_compl.mp hw)), Finset.sum_const,
      nsmul_eq_mul, hmEq]
  have hsplit : ∑ w, x w = ∑ w ∈ K, x w + ∑ w ∈ (Kᶜ : Finset V), x w :=
    (Finset.sum_add_sum_compl K x).symm
  have hbA : b = Q - ((Fintype.card V : ℝ) + t - 3) := by rw [hb]; unfold qA; ring
  have hEig : signlessLaplacian G *ᵥ x = Q • x := by
    funext v
    rw [Q_mulVec_apply]
    by_cases hv : v ∈ K
    · have hxv := hxK v hv
      simp only [Pi.smul_apply, smul_eq_mul, hxv]
      rw [hJ.deg_K hv, hJ.nbr_eq_erase hv, Finset.sum_erase_eq_sub (Finset.mem_univ v), hsplit,
        hSumK, hSumC, hxv]
      nlinarith
    · have hxv := hxC v hv
      simp only [Pi.smul_apply, smul_eq_mul, hxv]
      have hSH : ∑ w ∈ (G.neighborFinset v) \ K, x w = (s : ℝ) * b := by
        rw [Finset.sum_congr rfl (fun w hw => hxC w (Finset.mem_sdiff.mp hw).2), Finset.sum_const,
          nsmul_eq_mul, hreg v hv]
      rw [hJ.deg_compl ht hv, hJ.sum_compl hv, hSH, hSumK, hreg v hv]
      have hprod : (Q - qB s t) * b = ((t : ℝ) - 1) * m := by
        rw [hb]
        have hc : (Q - qB s t) * (Q - qA (Fintype.card V) t) = (Q - qA (Fintype.card V) t) * (Q - qB s t) := by ring
        rw [hc, hquad]
        ring
      have hexp : (Q - qB s t) * b = Q * b - (2 * (s : ℝ) + t - 1) * b := by unfold qB; ring
      nlinarith
  exact (eq_qIndex_of_pos_eigenvector G hxpos hEig).symm

end QIdx
