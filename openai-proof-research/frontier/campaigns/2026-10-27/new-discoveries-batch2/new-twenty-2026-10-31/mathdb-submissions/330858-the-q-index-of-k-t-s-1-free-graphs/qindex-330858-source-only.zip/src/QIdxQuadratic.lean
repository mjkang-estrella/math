import QIdxStatement
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity

/-! # The quadratic behind the printed bound. -/

namespace QIdx

/-- `A0 = n + t - 3`. -/
noncomputable def qA (n t : ℕ) : ℝ := (n : ℝ) + t - 3
/-- `B0 = 2s + t - 1`. -/
noncomputable def qB (s t : ℕ) : ℝ := 2 * (s : ℝ) + t - 1
/-- `m = n - t + 1`. -/
noncomputable def qm (n t : ℕ) : ℝ := (n : ℝ) - t + 1

theorem printed_facts {n s t : ℕ} (ht : 2 ≤ t) (hn : t ≤ n) :
    (printedBound n s t - qA n t) * (printedBound n s t - qB s t) = qm n t * ((t : ℝ) - 1) ∧
      qA n t < printedBound n s t ∧ qB s t < printedBound n s t := by
  have htR : (2 : ℝ) ≤ t := by exact_mod_cast ht
  have hnR : (t : ℝ) ≤ n := by exact_mod_cast hn
  have hm : 0 < qm n t := by unfold qm; linarith
  have ht1 : 0 < (t : ℝ) - 1 := by linarith
  set R : ℝ := ((n : ℝ) - 2 + 2 * s) ^ 2 - 8 * s * ((n : ℝ) - 2)
      + 4 * ((t : ℝ) - 1) * ((n : ℝ) - t + 1) with hR
  have hRform : R = (qA n t - qB s t) ^ 2 + 4 * (qm n t * ((t : ℝ) - 1)) := by
    rw [hR]; unfold qA qB qm; ring
  have hpos : 0 < qm n t * ((t : ℝ) - 1) := mul_pos hm ht1
  have hRnn : 0 ≤ R := by rw [hRform]; positivity
  have hsq : Real.sqrt R ^ 2 = R := Real.sq_sqrt hRnn
  have hRgt : (qA n t - qB s t) ^ 2 < R := by rw [hRform]; linarith
  have hlt : |qA n t - qB s t| < Real.sqrt R := by
    apply Real.lt_sqrt_of_sq_lt
    rw [sq_abs]; exact hRgt
  have habs1 := le_abs_self (qA n t - qB s t)
  have habs2 := neg_abs_le (qA n t - qB s t)
  have hQ : printedBound n s t = (qA n t + qB s t) / 2 + Real.sqrt R / 2 := by
    unfold printedBound qA qB; rw [← hR]; ring
  rw [hQ]
  refine ⟨?_, by linarith, by linarith⟩
  have : ((qA n t + qB s t) / 2 + Real.sqrt R / 2 - qA n t) *
      ((qA n t + qB s t) / 2 + Real.sqrt R / 2 - qB s t)
      = (Real.sqrt R ^ 2 - (qA n t - qB s t) ^ 2) / 4 := by ring
  rw [this, hsq, hRform]; ring

theorem root_le {A B C Q y : ℝ} (hQ : (Q - A) * (Q - B) = C) (hA : A < Q) (hB : B < Q)
    (hf : (y - A) * (y - B) ≤ C) : y ≤ Q := by
  by_contra hcon
  have hlt : Q < y := not_le.mp hcon
  have h1 : Q - A < y - A := by linarith
  have h2 : Q - B < y - B := by linarith
  have h3 : 0 < Q - A := by linarith
  have h4 : 0 < y - B := by linarith
  have h5 : (Q - A) * (Q - B) < (y - A) * (y - B) := by
    calc (Q - A) * (Q - B) < (Q - A) * (y - B) := mul_lt_mul_of_pos_left h2 h3
      _ < (y - A) * (y - B) := mul_lt_mul_of_pos_right h1 h4
  linarith

/-- Lemma 0: the threshold `n + 2t - 4` lies strictly below the printed bound (`s ≥ t - 1`). -/
theorem gap_lt {n s t : ℕ} (ht : 2 ≤ t) (hn : t ≤ n) (hs : t - 1 ≤ s) :
    (n : ℝ) + 2 * t - 4 < printedBound n s t := by
  have htR : (2 : ℝ) ≤ t := by exact_mod_cast ht
  have hsR : (t : ℝ) - 1 ≤ s := by
    have h : t ≤ s + 1 := by omega
    have h2 : (t : ℝ) ≤ (s : ℝ) + 1 := by exact_mod_cast h
    linarith
  obtain ⟨h0, hA, hB⟩ := printed_facts (s := s) ht hn
  by_contra hcon
  have hy : printedBound n s t ≤ (n : ℝ) + 2 * t - 4 := not_lt.mp hcon
  set y : ℝ := (n : ℝ) + 2 * t - 4 with hydef
  have hyA : printedBound n s t - qA n t ≤ y - qA n t := by linarith
  have hyB : printedBound n s t - qB s t ≤ y - qB s t := by linarith
  have h3 : 0 < printedBound n s t - qA n t := by linarith
  have h4 : 0 < y - qB s t := by linarith
  have hge : (printedBound n s t - qA n t) * (printedBound n s t - qB s t) ≤ (y - qA n t) * (y - qB s t) :=
    mul_le_mul hyA hyB (by linarith) (by linarith)
  have hval : (y - qA n t) * (y - qB s t) - qm n t * ((t : ℝ) - 1)
      = 2 * ((t : ℝ) - 1) * ((t : ℝ) - 2 - s) := by
    rw [hydef]; unfold qA qB qm; ring
  have hneg : 2 * ((t : ℝ) - 1) * ((t : ℝ) - 2 - s) < 0 := by
    apply mul_neg_of_pos_of_neg <;> linarith
  linarith

end QIdx
