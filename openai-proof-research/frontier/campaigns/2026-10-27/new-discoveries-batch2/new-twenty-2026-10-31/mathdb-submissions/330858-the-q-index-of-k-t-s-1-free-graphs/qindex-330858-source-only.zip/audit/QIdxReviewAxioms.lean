import QIdxEndpoint

#print axioms QIdx.qindex_kts_endpoint
#print axioms QIdx.qIndex_isGreatest
#print axioms QIdx.main_general
#check @QIdx.qindex_kts_endpoint
#print QIdx.Statement
#print QIdx.printedBound
#print QIdx.qIndex
#print QIdx.signlessLaplacian
