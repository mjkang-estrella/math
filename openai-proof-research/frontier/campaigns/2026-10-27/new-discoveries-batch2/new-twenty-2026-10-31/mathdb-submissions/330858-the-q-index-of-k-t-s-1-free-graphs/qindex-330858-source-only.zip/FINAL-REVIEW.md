# MathDB 330858: independent final formal review

Reviewer: Claude Opus 5.5, high effort, done personally. No subagents, no other model. Credit 0; campaign 61 of 80 unchanged. Root alone adjudicates.

## Recommendation: TECHNICAL_PASS_ROOT_ADJUDICATION_PENDING

I tried to break the claim and could not. `QIdx.qindex_kts_endpoint : QIdx.Statement` is kernel-checked from a fresh extraction, uses only the three permitted axioms, and `QIdx.Statement` is the claimed result on its natural reading. No defect affects validity or fidelity.

This is a technical pass only. Two matters stay open for root: prior art (three closed or unread works, bounded search) and significance (modest; see Gate G).

| Gate | Result |
|---|---|
| A fresh replay | PASS: 9 of 9 compile, 9 of 9 kernel check, from empty build |
| B source audit | PASS: every module read, no forbidden construct, no conclusion-bearing hypothesis |
| C axioms | PASS: closure of 35,041 constants, axioms exactly propext, Classical.choice, Quot.sound |
| D statement fidelity | PASS: see the scope analysis below |
| E controls | PASS: all requested controls proved, two negative controls rejected |
| F prior art | NO_MATCH_FOUND_BOUNDED_INCOMPLETE |
| G science | MODEST: not a routine adaptation of the source's t=2 structural proof; join step is routine; exclusion defensible but not compelled |

## Gate A: fresh extracted replay

The zip was extracted into the empty `src/` with absolute paths, parent references, backslashes and symlinks rejected (none present). All 9 files match `packet/SOURCE-HASHES.json`. All 9 modules in `packet/BUILD-ORDER.json` compiled from an empty `build/` and passed `leanchecker`, under labels `fresh_compile_MODULE` and `fresh_check_MODULE`, all exit 0. Lean reports version 4.34.1. Timestamps in the receipts show the runs were sequential. Record: `results/FRESH-REPLAY.json`.

## Gate B: source audit

I read all 9 sources in full. A token scan for sorry, admit, axiom, unsafe, partial, opaque, implemented_by, extern, native_decide, ofReduceBool, macro, syntax, elab, notation, infix, prefix, postfix, run_cmd, instance, attribute, local, scoped, private, protected, csimp, reducible and decide found only `set_option maxHeartbeats 1000000 in` (QIdxJoin line 64, QIdxBootstrap line 64). There are no instance declarations and no redefinition of a mathlib name; everything is in namespace `QIdx`. A Unicode inventory shows standard Lean mathematical symbols only, with no look-alike identifiers. All imports are mathlib modules or packet modules.

| Module | Lines | Role |
|---|---|---|
| QIdxStatement | 80 | Definitions, `Statement`, Hermitian lemma, `qIndex_isGreatest` |
| QIdxCounting | 137 | Freeness to the t-set common-neighbour bound; double count; hub count |
| QIdxQuadratic | 83 | Printed bound is the larger root; n+2t-4 lies strictly below it when s >= t-1 |
| QIdxSpectral | 131 | Nonnegative top eigenvector via absolute values and PSD; positive-eigenvector test |
| QIdxEstimates | 259 | Eigenvector estimates outside hubs and heavy vertices; at most t-1 heavy vertices |
| QIdxJoin | 302 | Join lemma, bound and equality on internal data; converse |
| QIdxBootstrap | 244 | Integer-gap bootstrap forcing t-1 universal vertices; explicit `thresholdN` |
| QIdxBridge | 181 | Internal `JoinForm` to and from the literal `graphJoin`, both directions |
| QIdxEndpoint | 56 | `main_general` and `qindex_kts_endpoint` |

No theorem carries its conclusion as a hypothesis. The endpoint takes only `s`, `t`, `2 <= t`, `t-1 <= s`, then discharges everything. `main_general` assumes only `ht`, `hs`, the threshold and freeness. The structures `EigData` and `JoinForm` are Prop bundles that are constructed by `exists_eigData` and `joinForm_of_universal` / `joinForm_of_iso`, not assumed. I also followed the mathematics while reading and it holds: common-neighbour bound, hub count, sum over non-heavy vertices at most S + eta, integer gap, universal vertices, join lemma.

## Gate C: axioms and closure

`#print axioms` for `QIdx.qindex_kts_endpoint`, `QIdx.qIndex_isGreatest` and `QIdx.main_general`: exactly [propext, Classical.choice, Quot.sound] (`axioms_compile_1`).

Environment walk from the two required roots (`audit_compile_2`): 35,041 constants; axiom 3, definition 7,750, theorem 25,337, opaque 30, quot 4, inductive 805, constructor 903, recursor 209; missing 0; project constants 117. Axioms: propext, Quot.sound, Classical.choice. Unsafe 0. Partial 0. The 30 opaque constants are `irreducible_def` wrappers of mathlib (Real, Polynomial and similar), `Lean.opaqueId` and `String.Internal.append`. `implemented_by` appears on 6 core constants (Lean.Name.num, Lean.Name.str, Lean.Name.anonymous, Nat.repr, List.attachWith, Array.foldlM), and `extern` on 58 core arithmetic and array operations; these affect compiled code only, not kernel reasoning.

The first attempt, which used `import Lean`, hit the `-M3500` guard in the interpreter (`audit_compile_1`, exit 250, retained). The walk fit once that import was removed.

## Gate D: statement fidelity

Compared line by line with `inputs/literal330858.json`, the raw record, and the text layer of arXiv 1507.00625v1 Conjecture 4. I elaborated and printed `Statement`, `printedBound`, `qIndex` and `signlessLaplacian` in Lean (`axioms_compile_1`).

| Point | Finding |
|---|---|
| Hypotheses | `2 <= t`, `t-1 <= s`. With t >= 2 the truncated subtraction is exact, and s >= t-1 >= 1 as in the source |
| Quantifiers | `forall s t, ... exists N, forall n, N <= n -> forall G`. N depends only on s and t; the proof uses `thresholdN s t` |
| Graphs | Every `SimpleGraph (Fin n)` with every `DecidableRel`; order n up to relabelling |
| Q | `adjMatrix R + degMatrix R`, real; mathlib definitions read |
| qIndex | `sSup` of the real spectrum. `qIndex_isGreatest` proves it is the greatest element for nonempty V. Junk occurs only at n=0, and thresholdN >= t+1 >= 3 |
| Free | mathlib: `H.Free G := not (H contained in G)`, where a copy is an injective homomorphism, so non-induced and in the right orientation. `QIdxCtrl.free_iff` proves it equals "no injective map with all cross pairs adjacent" |
| K_{t,s+1} vs K_{s+1,t} | Immaterial; proved in `QIdxCtrl.free_swap` |
| printedBound | Real arithmetic throughout; the printed form confirms casts on n, s, t and real 1/2. It equals the larger root of the quotient matrix [[n+t-3, n-t+1],[t-1, 2s+t-1]]. At t=2 it reduces by hand to the source's own (n+2s)/2 + (1/2)sqrt((n-2s)^2+8s) |
| graphJoin | Disjoint union plus all cross edges; standard |
| H | `SimpleGraph (Fin (n-t+1))`, `IsRegularOfDegree s` means every vertex has degree exactly s. `n-t+1` is exact for n >= t, and N > t |
| K_{t-1} | `top` on `Fin (t-1)` |

### Scope of the equality clause

Source: "If G is a K_{t,s+1}-free graph of order n, then q(G) <= .... Equality holds if and only if G is a join of K_{t-1} and an s-regular graph of order n-t+1." Lean places the equivalence inside the freeness hypothesis. Three other readings exist, and I tested each.

1. **Unrestricted: for every graph G of order n, q(G) = bound iff G is such a join. FALSE.** Witness at s=t=2, for every n = 4k with k >= 2. Take |A|=|B|=2k, a 3-regular graph on A, a perfect matching on B, and a (2k-2)-regular bipartite graph between A and B. This partition is equitable with quotient [[6+m, m],[m, 2+m]], m=2k-2, trace n+4 and determinant 4(n-1). Those are exactly the coefficients of the quadratic whose larger root is printedBound(n,2,2); the quotient's Perron vector lifts to a positive eigenvector, so q(G) equals the bound. No vertex has degree n-1, so G is not a join with K_1. Proved in Lean at n=8 (`QIdxCtrl.unrestricted_equality_false_at_8`: q = 6+2 sqrt 2 = printedBound 8 2 2, not a join, not K_{2,3}-free). The general family is a hand argument, checked numerically for n = 8, 12, ..., 40 (`scope_family_numerics`). Since it recurs for infinitely many n, no threshold N rescues this reading.
2. **"Every such join is K_{t,s+1}-free and extremal". FALSE.** K_1 join C_4 is the wheel; it has the join form with H 2-regular and contains K_{2,3} (`W5_join`, `W5_not_free`). For large n use K_1 join (C_4 union C_{n-5}). Under this reading the source's own proved Theorem 5, with the identical sentence, would be false at s=2, so the authors cannot have meant it.
3. **The reverse half alone without freeness: join implies equality. TRUE**, and the source attributes the t=2 case to its reference [5]. It is not asserted by the sentence, which is governed by the freeness hypothesis, and it is not in `Statement`. The packet's lemmas already give it: `hreverse` in `main_general` does not use freeness, and I extracted it as `QIdxCtrl.reverse_unconditional`, kernel-checked.

Conclusion: the Lean scope is the natural reading and the only one of the first two kinds that is true. The Lean theorem does not miss the literal target. The MathDB wording has the same structure as the source.

"The join" (MathDB) versus "a join" (source) changes nothing. H is existentially quantified in both, the join is determined up to isomorphism by its parts, and neither phrase claims more.

Non-vacuity: free graphs exist at every n, and the equality class is non-empty for suitable parameters (for example friendship graphs at t=2, s=1, n odd; `bowtie_clause_instance` is the n=5 case, below the threshold). Non-emptiness is not asserted by the statement. thresholdN(1,2) = 3,401,221, far larger than the source's t=2 threshold, which "sufficiently large" permits.

## Gate E: semantic controls

`src/QIdxReviewControls.lean`, compiled (`controls_compile_2`) and kernel-checked (`controls_check_1`), proved from the packet's own definitions, each with only the permitted axioms (`free_swap` uses a subset).

| Requested | Result |
|---|---|
| (1) triangle | `triangle_q`: qIndex = 4; `triangle_pb`: printedBound 3 1 2 = 4; `triangle_attains` |
| (2) join form | `triangle_join`, through `graphJoin`, with H on Fin (3-2+1) |
| (3) K_4 not C_4-free | `K4_not_C4_free`; `K4_no_induced_C4` shows an induced reading would make this false |
| (4) free graph accepted | `bowtie_free` on K_1 join 2K_2, by exhaustive check |
| (5) formula pinned | `variant_sign` (+8s), `variant_const` (-1 for -2), `variant_order` (n-t for n-t+1), `variant_trunc` (natural truncation of n-t+1) all differ from printedBound; `pb_is_fam` is by rfl |
| (6) non-regular q | `P3_q`: path on 3 vertices has q = 3 |
| Further | `reviewer_form`: endpoint transported to my explicit no-injective-map hypothesis; `free_iff`; `free_swap`; `bowtie_q` and `bowtie_pb` give (7+sqrt 17)/2; `bowtie_join`; `W5_equality`; the scope witnesses above |
| Negative | A false claim q(triangle)=5 (`neg_false_1`) and a `sorry` (`neg_sorry_1`) were both rejected, exit 1 |

## Gate F: live prior art

Two native searches, standard mode, one string each (the tool takes one string), so 2 of 4 strings used. Both precharged; both complete responses saved next (`search-response-1.txt`, `search-response-2.txt`). `inherited-denials.json` read in full first. No fetches.

No record seen states that Conjecture 4 is proved for general t, or for t=3. This rests on titles and the tool's summaries only; I opened no paper in this gate.

Seen as titles or summaries only: 1507.00625 (source); 2609.21367 (t-color-critical, different family); 1612.03514 (Kong-Wang upper bound, not exact); 1908.04221 (minor-free); 2606.30272 and 2606.28121 (clique families); 1308.1653; 2108.03895; 1401.4363; 2601.17726; core.ac.uk/works/17012392; and an SBMAC proceedings item (proceedings.sbmac.org.br 2186/2203). The last has no title in the response and is Brazilian, as is the closed thesis; I do not know its content, and root may wish to treat it as an unread lead.

Unresolved holds, closed and unread: the UFRGS thesis "Indices de grafos livres de K_{s,t}"; the LAA 496 final version; the Yu-Wang-Guo paper body. RAIRO 10.1051/ro/2023109 is also closed. There is no citation index and I cannot list works citing 1507.00625. This is a bounded search, not a novelty clearance. If the UFRGS thesis proves the conjecture, this is not new.

## Gate G: science

I read both qualification files and the source's whole t=2 proof.

**Is it a routine adaptation of the t=2 proof? In part.** The join lemma is Proposition 6 with K_1 replaced by K_{t-1}, routine. The structural step is not an adaptation of Theorem 8. Theorem 8 splits on maximum degree, uses the Merris bound and a codegree count specific to pairs, and then a separate eigenvector estimate; that route does not generalize, as Kong-Wang's n^(1-1/t) error suggests. The packet uses one uniform eigenvector-concentration argument and an integer gap. At t=2 it gives a different proof of the source's "Delta < n-1 implies q < n", at a far worse threshold.

**Is it a routine adaptation of the K_{s,t} spectral-radius literature? In kind, yes; as a complete bridge, no.** Heavy vertices, entries near 1 and rounding to full degree are a known template in adjacency work, per the qualification; I did not read those papers myself. Nothing I read carries it to the Q-index, where the diagonal term changes the accounting and the scale is n.

Strongest case for: a deliberate printed conjecture open for every t >= 3, settled exactly with the equality characterization; the authors wrote that their methods seem inadequate and that completely new techniques are needed; s >= t-1 is explained exactly by the gap lemma; no complete reduction exists.

Strongest case against: about a page of counting, concentration and rounding, with no new invariant; the whole formalization is 1,473 lines and compiles in well under a minute, against a planned 2,700-3,200. The authors also said Problem C would be resolved within a few years. The only property of K_{t,s+1} used is the common-neighbour bound.

What is new, as far as I can tell: the threshold n+2t-4 with the integer-gap bootstrap, applied to the Q-index. My view: modest. A routine exclusion is not justified, because no complete bridge exists. A significance exclusion would be defensible but is not compelled. I weigh this independently of the earlier rating and land close to it.

## Defects

| ID | Severity | Description |
|---|---|---|
| D1 | cosmetic | `QIdxStatement.lean` docstring cites `FIDELITY.md`, which is not in the source-only packet |
| D2 | low | The packet contains no semantic controls beyond `qIndex_isGreatest`, though the author plan listed some; this review supplies them |
| D3 | informational | `set_option maxHeartbeats 1000000` at QIdxJoin line 64 and QIdxBootstrap line 64; no effect on statements |
| D4 | informational | `Statement` puts the true unconditional reverse direction under freeness; the source does too, and the stronger form is proved in my control |

Defects affecting validity or fidelity: none.

## What I did not check

- Upstream mathlib and Lean oleans are trusted. I verified the hashes of `Mathlib.lean` and `lake-manifest.json` against PINS and Lean's version string, not the mathlib revision itself (no git allowed) and not every olean.
- `leanchecker` replays each module against trusted imports; the audit walk is a structural enumeration.
- Conjecture 4 was compared against the PDF's text layer; I did not view the page image. The t=2 reduction of the formula supports the reading.
- I did not read `inputs/author-candidate.md`, `inputs/lean-results.json`, the accepted and prior scope files, or the PDFs of 2606.30272, 2609.21367, 1410.2142. I did not read 1612.03514 or 1908.04221. No family comparison was done; it was not asked of this gate.
- The general witness family in reading 1 is a hand argument with numerics to n=40; only n=8 is in Lean.
- Independence is limited. I read the packet's proof, both qualification reports and root's summaries in the denials file before reaching my view, so this is verification, not independent invention. Same model family as the qualifiers and the formal author.

## Process disclosures

- Compile and check of QIdxCounting and QIdxQuadratic sent console output to `/dev/null`; full output and true exits are in their receipts. Several chained Lean commands printed exit codes with a trailing `echo`, so the shell's own exit was that of `echo`; receipts hold true exits.
- Non-zero runs retained: `audit_compile_1` (250, memory guard), `controls_compile_1` (1, errors in my own file: deprecated names, a linter, missing decidability), `neg_false_1` and `neg_sorry_1` (1, intended).
- Two displays exceeded the harness limit and were persisted outside the lane (`gateF_denials_0` about 33 KB, `gateF_denials_structure` about 76 KB). I saw only previews and did not open them. The denials were then read completely.
- The denials were displayed as compact JSON (indentation removed, content complete) in chunks of at most 14,500 characters, 26 calls, offsets 0 to 374,396. Each display also carries a runner receipt, so a whole display is slightly over 15,000 characters.
- That file contains root's summaries of the earlier 330858 qualifications and of other candidates; reading it was required.
- Authored files and search saves went through `write_lane.py` without runner receipts. Some read-only runner calls were issued in the same message as other calls.
