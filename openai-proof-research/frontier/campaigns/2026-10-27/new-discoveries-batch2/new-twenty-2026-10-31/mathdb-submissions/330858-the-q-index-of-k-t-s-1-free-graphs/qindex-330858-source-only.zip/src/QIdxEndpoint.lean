import QIdxBridge

/-! # The endpoint: the literal statement of MathDB 330858, no added premise. -/

open SimpleGraph Finset

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V]

theorem main_general (G : SimpleGraph V) [DecidableRel G.Adj] {s t : ℕ} (ht : 2 ≤ t) (hs : t - 1 ≤ s)
    (hn : thresholdN s t ≤ Fintype.card V)
    (hfree : (completeBipartiteGraph (Fin t) (Fin (s + 1))).Free G) :
    qIndex G ≤ printedBound (Fintype.card V) s t ∧
      (qIndex G = printedBound (Fintype.card V) s t ↔
        ∃ (H : SimpleGraph (Fin (Fintype.card V - t + 1))) (_ : DecidableRel H.Adj),
          H.IsRegularOfDegree s ∧
            Nonempty (G ≃g graphJoin (⊤ : SimpleGraph (Fin (t - 1))) H)) := by
  have hcn : ∀ T : Finset V, T.card = t → (commonNbrs G T).card ≤ s :=
    fun T hT => common_nbrs_le_of_free hfree T hT
  have htn : t ≤ Fintype.card V := by
    unfold thresholdN at hn; omega
  have : Nonempty V := by
    apply Fintype.card_pos_iff.mp
    omega
  obtain ⟨x, hx, hx0, hQ⟩ := exists_nonneg_top_eigenvector G
  have heig := eigen_apply G hQ
  have hreverse : (∃ (H : SimpleGraph (Fin (Fintype.card V - t + 1))) (_ : DecidableRel H.Adj),
      H.IsRegularOfDegree s ∧ Nonempty (G ≃g graphJoin (⊤ : SimpleGraph (Fin (t - 1))) H)) →
      qIndex G = printedBound (Fintype.card V) s t := by
    rintro ⟨H, inst, hreg, ⟨φ⟩⟩
    obtain ⟨K, hJ, hexact⟩ := joinForm_of_iso rfl hreg φ
    exact join_regular_top hJ ht htn hexact
  by_cases hqlarge : (Fintype.card V : ℝ) + 2 * t - 4 ≤ qIndex G
  · have htR : (2 : ℝ) ≤ t := by exact_mod_cast ht
    have hqn : (Fintype.card V : ℝ) ≤ qIndex G := by linarith
    obtain ⟨y, hd, u, hu⟩ := exists_eigData hx hx0 heig hqn
    obtain ⟨K, hK, hKdeg⟩ := universal_of_large_q ht hcn hn hd hu hqlarge
    have hJ : JoinForm G K t s := joinForm_of_universal ht hcn hK hKdeg
    obtain ⟨hbound, heqImp⟩ := join_main hJ ht htn hx hx0 heig
    exact ⟨hbound, ⟨fun heq => iso_of_joinForm ht hJ htn (heqImp heq), hreverse⟩⟩
  · have hlt : qIndex G < printedBound (Fintype.card V) s t :=
      (lt_of_not_ge hqlarge).trans (gap_lt ht htn hs)
    exact ⟨hlt.le, ⟨fun h => absurd h hlt.ne, fun h => absurd (hreverse h) hlt.ne⟩⟩

/-- The literal theorem of MathDB 330858, proved with no added premise. -/
theorem qindex_kts_endpoint : Statement := by
  intro s t ht hs
  refine ⟨thresholdN s t, ?_⟩
  intro n hn G _ hfree
  have hcard : Fintype.card (Fin n) = n := Fintype.card_fin n
  have hmain := main_general G ht hs (by rw [hcard]; exact hn) hfree
  rw [hcard] at hmain
  exact hmain

end QIdx
