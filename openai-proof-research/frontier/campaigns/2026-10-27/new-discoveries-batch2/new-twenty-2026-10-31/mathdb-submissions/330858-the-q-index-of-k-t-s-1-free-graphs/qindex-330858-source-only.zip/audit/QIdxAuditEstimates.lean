import QIdxEstimates

#print axioms QIdx.sum_nbr_le
#print axioms QIdx.low_outside_hubs
#print axioms QIdx.low_outside_P
#print axioms QIdx.sum_nbr_double
#print axioms QIdx.sum_outside_P
#print axioms QIdx.card_heavy_le
