import QIdxEndpoint
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

/-! Reviewer semantic controls for MathDB 330858, proved from the packet's own definitions. -/

open SimpleGraph Matrix Finset QIdx

namespace QIdxCtrl

/-! ## Infrastructure -/

def ofBool {n : ℕ} (f : Fin n → Fin n → Bool) (hs : ∀ a b, f a b = f b a)
    (hl : ∀ a, f a a = false) : SimpleGraph (Fin n) where
  Adj a b := f a b = true
  symm := ⟨fun a b h => by rw [hs]; exact h⟩
  loopless := ⟨fun a h => by simp [hl] at h⟩

instance ofBoolDec {n : ℕ} (f : Fin n → Fin n → Bool) (hs : ∀ a b, f a b = f b a)
    (hl : ∀ a, f a a = false) : DecidableRel (ofBool f hs hl).Adj :=
  fun a b => inferInstanceAs (Decidable (f a b = true))

instance joinDec {A B : Type*} (G₁ : SimpleGraph A) (G₂ : SimpleGraph B)
    [DecidableRel G₁.Adj] [DecidableRel G₂.Adj] : DecidableRel (graphJoin G₁ G₂).Adj :=
  fun x y =>
    match x, y with
    | .inl a, .inl a' => inferInstanceAs (Decidable (G₁.Adj a a'))
    | .inr b, .inr b' => inferInstanceAs (Decidable (G₂.Adj b b'))
    | .inl _, .inr _ => isTrue trivial
    | .inr _, .inl _ => isTrue trivial

theorem sum_nbr_cells {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V)
    [DecidableRel G.Adj] (c : V → Bool) (a b : ℝ) (v : V) :
    ∑ w ∈ G.neighborFinset v, (if c w = true then a else b) =
      (((G.neighborFinset v).filter (fun w => c w = true)).card : ℝ) * a +
      (((G.neighborFinset v).filter (fun w => ¬ c w = true)).card : ℝ) * b := by
  rw [Finset.sum_ite, Finset.sum_const, Finset.sum_const, nsmul_eq_mul, nsmul_eq_mul]

theorem qIndex_of_cells {n : ℕ} (hn : 0 < n) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj]
    (c : Fin n → Bool) (a b q : ℝ) (ha : 0 < a) (hb : 0 < b)
    (h : ∀ v, q * (if c v = true then a else b) =
      (G.degree v : ℝ) * (if c v = true then a else b) +
      (((G.neighborFinset v).filter (fun w => c w = true)).card : ℝ) * a +
      (((G.neighborFinset v).filter (fun w => ¬ c w = true)).card : ℝ) * b) :
    qIndex G = q := by
  have : Nonempty (Fin n) := ⟨⟨0, hn⟩⟩
  have hpos : ∀ v, 0 < (if c v = true then a else b) := fun v => by
    split_ifs
    · exact ha
    · exact hb
  have hE : signlessLaplacian G *ᵥ (fun w => if c w = true then a else b) =
      q • (fun w => if c w = true then a else b) := by
    funext v
    rw [Q_mulVec_apply, sum_nbr_cells]
    simp only [Pi.smul_apply, smul_eq_mul]
    linarith [h v]
  exact (eq_qIndex_of_pos_eigenvector G hpos hE).symm

theorem pb_eq {n s t : ℕ} {R : ℝ}
    (h : ((n : ℝ) - 2 + 2 * s) ^ 2 - 8 * s * ((n : ℝ) - 2)
      + 4 * ((t : ℝ) - 1) * ((n : ℝ) - t + 1) = R) :
    printedBound n s t = (n : ℝ) / 2 + s + t - 2 + (1 / 2) * Real.sqrt R := by
  unfold printedBound
  rw [h]

theorem not_free_of {n a b : ℕ} (G : SimpleGraph (Fin n)) (f : Fin a ⊕ Fin b → Fin n)
    (hinj : Function.Injective f) (hadj : ∀ i j, G.Adj (f (Sum.inl i)) (f (Sum.inr j))) :
    ¬ (completeBipartiteGraph (Fin a) (Fin b)).Free G := by
  intro h
  refine h ⟨⟨⟨f, ?_⟩, hinj⟩⟩
  rintro (i | j) (i' | j') h'
  · simp [completeBipartiteGraph] at h'
  · exact hadj i j'
  · exact (hadj i' j).symm
  · simp [completeBipartiteGraph] at h'

/-- Reviewer's own explicit reading of `Free`: no injective map with all cross pairs adjacent. -/
theorem free_iff {n a b : ℕ} (G : SimpleGraph (Fin n)) :
    (completeBipartiteGraph (Fin a) (Fin b)).Free G ↔
      ¬ ∃ f : Fin a ⊕ Fin b → Fin n, Function.Injective f ∧
        ∀ i j, G.Adj (f (Sum.inl i)) (f (Sum.inr j)) := by
  constructor
  · rintro h ⟨f, hinj, hadj⟩
    exact not_free_of G f hinj hadj h
  · intro h hc
    obtain ⟨c⟩ := hc
    refine h ⟨c.toHom, c.injective', fun i j => c.toHom.map_adj ?_⟩
    simp [completeBipartiteGraph]

/-- The endpoint transported to the reviewer's explicit freeness hypothesis. -/
theorem reviewer_form : ∀ s t : ℕ, 2 ≤ t → t - 1 ≤ s →
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n → ∀ (G : SimpleGraph (Fin n)) [DecidableRel G.Adj],
      (¬ ∃ f : Fin t ⊕ Fin (s + 1) → Fin n, Function.Injective f ∧
        ∀ i j, G.Adj (f (Sum.inl i)) (f (Sum.inr j))) →
      qIndex G ≤ printedBound n s t ∧
      (qIndex G = printedBound n s t ↔
        ∃ (H : SimpleGraph (Fin (n - t + 1))) (_ : DecidableRel H.Adj),
          H.IsRegularOfDegree s ∧
            Nonempty (G ≃g graphJoin (⊤ : SimpleGraph (Fin (t - 1))) H)) := by
  intro s t h1 h2
  obtain ⟨N, hN⟩ := qindex_kts_endpoint s t h1 h2
  exact ⟨N, fun n hn G _ h => hN n hn G ((free_iff G).2 h)⟩

/-- Reversal of the two sides of the forbidden graph is immaterial. -/
theorem free_swap {V : Type*} (G : SimpleGraph V) (a b : ℕ) :
    (completeBipartiteGraph (Fin a) (Fin b)).Free G ↔
      (completeBipartiteGraph (Fin b) (Fin a)).Free G := by
  let e : completeBipartiteGraph (Fin a) (Fin b) ≃g completeBipartiteGraph (Fin b) (Fin a) :=
    ⟨Equiv.sumComm _ _, by rintro (x | x) (y | y) <;> simp [completeBipartiteGraph]⟩
  exact free_congr e Iso.refl

/-- The reverse half of the equality clause needs no freeness hypothesis. -/
theorem reverse_unconditional {n s t : ℕ} (ht : 2 ≤ t) (hn : t ≤ n) (G : SimpleGraph (Fin n))
    [DecidableRel G.Adj]
    (h : ∃ (H : SimpleGraph (Fin (n - t + 1))) (_ : DecidableRel H.Adj),
      H.IsRegularOfDegree s ∧ Nonempty (G ≃g graphJoin (⊤ : SimpleGraph (Fin (t - 1))) H)) :
    qIndex G = printedBound n s t := by
  obtain ⟨H, inst, hreg, ⟨φ⟩⟩ := h
  obtain ⟨K, hJ, hexact⟩ := joinForm_of_iso rfl hreg φ
  have hcard : t ≤ Fintype.card (Fin n) := by simpa using hn
  have := join_regular_top hJ ht hcard hexact
  simpa using this

/-! ## Control 1: triangle, and the printed bound at (3,1,2) -/

theorem row3 : ∀ v : Fin 3, (⊤ : SimpleGraph (Fin 3)).degree v = 2 ∧
    (((⊤ : SimpleGraph (Fin 3)).neighborFinset v).filter (fun w => (fun _ => true : Fin 3 → Bool) w = true)).card = 2 ∧
    (((⊤ : SimpleGraph (Fin 3)).neighborFinset v).filter (fun w => ¬ (fun _ => true : Fin 3 → Bool) w = true)).card = 0 := by
  decide +kernel

theorem triangle_q : qIndex (⊤ : SimpleGraph (Fin 3)) = 4 := by
  apply qIndex_of_cells (by norm_num) ⊤ (fun _ => true) 1 1 4 (by norm_num) (by norm_num)
  intro v
  obtain ⟨hd, hA, hB⟩ := row3 v
  rw [hd, hA, hB]
  norm_num

theorem triangle_pb : printedBound 3 1 2 = 4 := by
  rw [pb_eq (n := 3) (s := 1) (t := 2) (R := 9) (by norm_num),
    show (9 : ℝ) = 3 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  norm_num

theorem triangle_attains : qIndex (⊤ : SimpleGraph (Fin 3)) = printedBound 3 1 2 := by
  rw [triangle_q, triangle_pb]

/-! ## Control 2: the triangle has the join form of the equality clause -/

def e3 : Fin 3 → Fin 1 ⊕ Fin 2 := ![Sum.inl 0, Sum.inr 0, Sum.inr 1]
theorem e3_bij : Function.Bijective e3 := by decide +kernel

theorem triangle_join : ∃ (H : SimpleGraph (Fin (3 - 2 + 1))) (_ : DecidableRel H.Adj),
    H.IsRegularOfDegree 1 ∧
      Nonempty ((⊤ : SimpleGraph (Fin 3)) ≃g graphJoin (⊤ : SimpleGraph (Fin (2 - 1))) H) := by
  have key : ∀ a b : Fin 3,
      (graphJoin (⊤ : SimpleGraph (Fin 1)) (⊤ : SimpleGraph (Fin 2))).Adj (e3 a) (e3 b) ↔
        (⊤ : SimpleGraph (Fin 3)).Adj a b := by decide +kernel
  refine ⟨(⊤ : SimpleGraph (Fin 2)), inferInstance, ?_, ?_⟩
  · intro v; revert v; decide +kernel
  · exact ⟨⟨Equiv.ofBijective e3 e3_bij, @fun a b => key a b⟩⟩

/-! ## Control 3: `Free` is non-induced containment -/

theorem K4_not_C4_free : ¬ (completeBipartiteGraph (Fin 2) (Fin (1 + 1))).Free (⊤ : SimpleGraph (Fin 4)) :=
  not_free_of _ (Sum.elim ![0, 1] ![2, 3]) (by decide +kernel) (by decide +kernel)

/-- `K_4` has no *induced* `K_{2,2}`, so an induced reading of `Free` would make the previous
control false. -/
theorem K4_no_induced_C4 : IsEmpty (completeBipartiteGraph (Fin 2) (Fin (1 + 1)) ↪g (⊤ : SimpleGraph (Fin 4))) := by
  refine ⟨fun φ => ?_⟩
  have hinj : φ (Sum.inl 0) ≠ φ (Sum.inl 1) := fun h => by
    have := φ.injective h
    simp at this
  have h1 := (φ.map_adj_iff (v := Sum.inl 0) (w := Sum.inl 1)).mp ((SimpleGraph.top_adj _ _).2 hinj)
  simp [completeBipartiteGraph] at h1

/-! ## Control 4 and full instance: the bowtie `K_1 ∨ 2K_2` -/

def fb (a b : Fin 5) : Bool :=
  decide (a ≠ b) && (a.val == 0 || b.val == 0 || (a.val - 1) / 2 == (b.val - 1) / 2)

def bowtie : SimpleGraph (Fin 5) := ofBool fb (by decide +kernel) (by decide +kernel)
instance : DecidableRel bowtie.Adj := ofBoolDec fb _ _

theorem bowtie_free : (completeBipartiteGraph (Fin 2) (Fin (1 + 1))).Free bowtie := by
  have key : ∀ a b c d : Fin 5, a ≠ b → c ≠ d → bowtie.Adj a c → bowtie.Adj a d →
      bowtie.Adj b c → bowtie.Adj b d → False := by decide +kernel
  rintro ⟨c⟩
  have hadj : ∀ i j, bowtie.Adj (c.toHom (Sum.inl i)) (c.toHom (Sum.inr j)) := fun i j =>
    c.toHom.map_adj (by simp [completeBipartiteGraph])
  refine key (c.toHom (Sum.inl 0)) (c.toHom (Sum.inl 1)) (c.toHom (Sum.inr 0)) (c.toHom (Sum.inr 1))
    (fun h => ?_) (fun h => ?_) (hadj 0 0) (hadj 0 1) (hadj 1 0) (hadj 1 1)
  · have := c.injective' h
    simp at this
  · have := c.injective' h
    simp at this

def cb (v : Fin 5) : Bool := v.val == 0

theorem rowb : ∀ v : Fin 5,
    (cb v = true ∧ bowtie.degree v = 4 ∧
      ((bowtie.neighborFinset v).filter (fun w => cb w = true)).card = 0 ∧
      ((bowtie.neighborFinset v).filter (fun w => ¬ cb w = true)).card = 4) ∨
    (¬ cb v = true ∧ bowtie.degree v = 2 ∧
      ((bowtie.neighborFinset v).filter (fun w => cb w = true)).card = 1 ∧
      ((bowtie.neighborFinset v).filter (fun w => ¬ cb w = true)).card = 1) := by
  decide +kernel

theorem bowtie_q : qIndex bowtie = (7 + Real.sqrt 17) / 2 := by
  have r : Real.sqrt 17 ^ 2 = 17 := Real.sq_sqrt (by norm_num)
  have rp : 0 ≤ Real.sqrt 17 := Real.sqrt_nonneg _
  apply qIndex_of_cells (by norm_num) bowtie cb ((1 + Real.sqrt 17) / 2) 1 _ (by linarith) (by norm_num)
  intro v
  rcases rowb v with ⟨hc, hd, hA, hB⟩ | ⟨hc, hd, hA, hB⟩
  · rw [ite_eq_left hc, hd, hA, hB]
    push_cast
    linear_combination (1 / 4) * r
  · rw [ite_eq_right hc, hd, hA, hB]
    push_cast
    ring

theorem bowtie_pb : printedBound 5 1 2 = (7 + Real.sqrt 17) / 2 := by
  rw [pb_eq (n := 5) (s := 1) (t := 2) (R := 17) (by norm_num)]
  push_cast
  ring

def h2K2f (a b : Fin 4) : Bool := decide (a ≠ b) && (a.val / 2 == b.val / 2)
def h2K2 : SimpleGraph (Fin 4) := ofBool h2K2f (by decide +kernel) (by decide +kernel)
instance : DecidableRel h2K2.Adj := ofBoolDec h2K2f _ _

def e5 : Fin 5 → Fin 1 ⊕ Fin 4 := ![Sum.inl 0, Sum.inr 0, Sum.inr 1, Sum.inr 2, Sum.inr 3]
theorem e5_bij : Function.Bijective e5 := by decide +kernel

theorem bowtie_join : ∃ (H : SimpleGraph (Fin (5 - 2 + 1))) (_ : DecidableRel H.Adj),
    H.IsRegularOfDegree 1 ∧
      Nonempty (bowtie ≃g graphJoin (⊤ : SimpleGraph (Fin (2 - 1))) H) := by
  have key : ∀ a b : Fin 5,
      (graphJoin (⊤ : SimpleGraph (Fin 1)) h2K2).Adj (e5 a) (e5 b) ↔ bowtie.Adj a b := by
    decide +kernel
  refine ⟨h2K2, inferInstance, ?_, ?_⟩
  · intro v; revert v; decide +kernel
  · exact ⟨⟨Equiv.ofBijective e5 e5_bij, @fun a b => key a b⟩⟩

theorem bowtie_clause_instance :
    (completeBipartiteGraph (Fin 2) (Fin (1 + 1))).Free bowtie ∧
      qIndex bowtie = printedBound 5 1 2 := ⟨bowtie_free, by rw [bowtie_q, bowtie_pb]⟩

/-! ## Control 5: the printed formula is pinned -/

noncomputable def pbFam (a b c : ℝ) (n s t : ℕ) : ℝ :=
  (n : ℝ) / 2 + s + t - a +
    (1 / 2) * Real.sqrt (((n : ℝ) - 2 + 2 * s) ^ 2 - b * s * ((n : ℝ) - 2)
      + 4 * ((t : ℝ) - 1) * ((n : ℝ) - t + c))

theorem pb_is_fam (n s t : ℕ) : printedBound n s t = pbFam 2 8 1 n s t := rfl

theorem fam_eq {a b c : ℝ} {n s t : ℕ} {R : ℝ}
    (h : ((n : ℝ) - 2 + 2 * s) ^ 2 - b * s * ((n : ℝ) - 2)
      + 4 * ((t : ℝ) - 1) * ((n : ℝ) - t + c) = R) :
    pbFam a b c n s t = (n : ℝ) / 2 + s + t - a + (1 / 2) * Real.sqrt R := by
  unfold pbFam
  rw [h]

theorem variant_sign : printedBound 3 1 2 ≠ pbFam 2 (-8) 1 3 1 2 := by
  rw [triangle_pb, fam_eq (a := 2) (b := -8) (c := 1) (n := 3) (s := 1) (t := 2) (R := 25) (by norm_num),
    show (25 : ℝ) = 5 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  norm_num

theorem variant_const : printedBound 3 1 2 ≠ pbFam 1 8 1 3 1 2 := by
  rw [triangle_pb, fam_eq (a := 1) (b := 8) (c := 1) (n := 3) (s := 1) (t := 2) (R := 9) (by norm_num),
    show (9 : ℝ) = 3 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]
  norm_num

theorem variant_order : printedBound 3 1 2 ≠ pbFam 2 8 0 3 1 2 := by
  rw [triangle_pb, fam_eq (a := 2) (b := 8) (c := 0) (n := 3) (s := 1) (t := 2) (R := 5) (by norm_num)]
  intro h
  have r : Real.sqrt 5 ^ 2 = 5 := Real.sq_sqrt (by norm_num)
  have h3 : Real.sqrt 5 = 3 := by push_cast at h; linarith
  rw [h3] at r
  norm_num at r

/-- Natural-number truncation of `n - t + 1` would change the value, so the real cast matters. -/
noncomputable def pbTrunc (n s t : ℕ) : ℝ :=
  (n : ℝ) / 2 + s + t - 2 +
    (1 / 2) * Real.sqrt (((n : ℝ) - 2 + 2 * s) ^ 2 - 8 * s * ((n : ℝ) - 2)
      + 4 * ((t : ℝ) - 1) * ((n - t + 1 : ℕ) : ℝ))

theorem variant_trunc : printedBound 1 1 3 ≠ pbTrunc 1 1 3 := by
  have h1 : printedBound 1 1 3 = 3 := by
    rw [pb_eq (n := 1) (s := 1) (t := 3) (R := 1) (by norm_num), Real.sqrt_one]
    norm_num
  have h2 : pbTrunc 1 1 3 = (1 : ℝ) / 2 + 1 + 3 - 2 + (1 / 2) * Real.sqrt 17 := by
    unfold pbTrunc
    norm_num
  rw [h1, h2]
  intro h
  have r : Real.sqrt 17 ^ 2 = 17 := Real.sq_sqrt (by norm_num)
  have h3 : Real.sqrt 17 = 1 := by linarith
  rw [h3] at r
  norm_num at r

/-! ## Control 6: a non-regular graph, the path on three vertices -/

def fp (a b : Fin 3) : Bool := (a.val == 1 && b.val != 1) || (b.val == 1 && a.val != 1)
def P3 : SimpleGraph (Fin 3) := ofBool fp (by decide +kernel) (by decide +kernel)
instance : DecidableRel P3.Adj := ofBoolDec fp _ _
def cp (v : Fin 3) : Bool := v.val == 1

theorem rowp : ∀ v : Fin 3,
    (cp v = true ∧ P3.degree v = 2 ∧
      ((P3.neighborFinset v).filter (fun w => cp w = true)).card = 0 ∧
      ((P3.neighborFinset v).filter (fun w => ¬ cp w = true)).card = 2) ∨
    (¬ cp v = true ∧ P3.degree v = 1 ∧
      ((P3.neighborFinset v).filter (fun w => cp w = true)).card = 1 ∧
      ((P3.neighborFinset v).filter (fun w => ¬ cp w = true)).card = 0) := by
  decide +kernel

theorem P3_q : qIndex P3 = 3 := by
  apply qIndex_of_cells (by norm_num) P3 cp 2 1 3 (by norm_num) (by norm_num)
  intro v
  rcases rowp v with ⟨hc, hd, hA, hB⟩ | ⟨hc, hd, hA, hB⟩
  · rw [ite_eq_left hc, hd, hA, hB]
    norm_num
  · rw [ite_eq_right hc, hd, hA, hB]
    norm_num

/-! ## Scope of the equality clause: witnesses against stronger readings -/

/-- Wheel `K_1 ∨ C_4`: of the join form with `H` 2-regular, but not `K_{2,3}`-free. -/
def fw (a b : Fin 5) : Bool :=
  decide (a ≠ b) && (a.val == 0 || b.val == 0 || (a.val + b.val) % 2 == 1)

def W5 : SimpleGraph (Fin 5) := ofBool fw (by decide +kernel) (by decide +kernel)
instance : DecidableRel W5.Adj := ofBoolDec fw _ _

def fc4 (a b : Fin 4) : Bool := (a.val + b.val) % 2 == 1
def C4 : SimpleGraph (Fin 4) := ofBool fc4 (by decide +kernel) (by decide +kernel)
instance : DecidableRel C4.Adj := ofBoolDec fc4 _ _

theorem W5_join : ∃ (H : SimpleGraph (Fin (5 - 2 + 1))) (_ : DecidableRel H.Adj),
    H.IsRegularOfDegree 2 ∧
      Nonempty (W5 ≃g graphJoin (⊤ : SimpleGraph (Fin (2 - 1))) H) := by
  have key : ∀ a b : Fin 5,
      (graphJoin (⊤ : SimpleGraph (Fin 1)) C4).Adj (e5 a) (e5 b) ↔ W5.Adj a b := by
    decide +kernel
  refine ⟨C4, inferInstance, ?_, ?_⟩
  · intro v; revert v; decide +kernel
  · exact ⟨⟨Equiv.ofBijective e5 e5_bij, @fun a b => key a b⟩⟩

theorem W5_not_free : ¬ (completeBipartiteGraph (Fin 2) (Fin (2 + 1))).Free W5 :=
  not_free_of _ (Sum.elim ![1, 3] ![0, 2, 4]) (by decide +kernel) (by decide +kernel)

theorem W5_equality : qIndex W5 = printedBound 5 2 2 :=
  reverse_unconditional (s := 2) (by norm_num) (by norm_num) W5 W5_join

/-- `n = 8`, `s = t = 2`: attains the printed value but is not a join and is not free. -/
def f8 (a b : Fin 8) : Bool :=
  let x := a.val
  let y := b.val
  decide (a ≠ b) &&
    ((x < 4 && y < 4) || (4 ≤ x && 4 ≤ y && x / 2 == y / 2) ||
      (x < 4 && 4 ≤ y && (y == 4 + x || y == 4 + (x + 1) % 4)) ||
      (y < 4 && 4 ≤ x && (x == 4 + y || x == 4 + (y + 1) % 4)))

def G8 : SimpleGraph (Fin 8) := ofBool f8 (by decide +kernel) (by decide +kernel)
instance : DecidableRel G8.Adj := ofBoolDec f8 _ _
def c8 (v : Fin 8) : Bool := decide (v.val < 4)

theorem row8 : ∀ v : Fin 8,
    (c8 v = true ∧ G8.degree v = 5 ∧
      ((G8.neighborFinset v).filter (fun w => c8 w = true)).card = 3 ∧
      ((G8.neighborFinset v).filter (fun w => ¬ c8 w = true)).card = 2) ∨
    (¬ c8 v = true ∧ G8.degree v = 3 ∧
      ((G8.neighborFinset v).filter (fun w => c8 w = true)).card = 2 ∧
      ((G8.neighborFinset v).filter (fun w => ¬ c8 w = true)).card = 1) := by
  decide +kernel

theorem G8_q : qIndex G8 = 6 + 2 * Real.sqrt 2 := by
  have r : Real.sqrt 2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have rp : 1 < Real.sqrt 2 := by
    apply Real.lt_sqrt_of_sq_lt
    norm_num
  apply qIndex_of_cells (by norm_num) G8 c8 2 (2 * Real.sqrt 2 - 2) _ (by norm_num) (by linarith)
  intro v
  rcases row8 v with ⟨hc, hd, hA, hB⟩ | ⟨hc, hd, hA, hB⟩
  · rw [ite_eq_left hc, hd, hA, hB]
    push_cast
    ring
  · rw [ite_eq_right hc, hd, hA, hB]
    push_cast
    linear_combination 4 * r

theorem G8_pb : printedBound 8 2 2 = 6 + 2 * Real.sqrt 2 := by
  have h32 : Real.sqrt 32 = 4 * Real.sqrt 2 := by
    rw [show (32 : ℝ) = 4 ^ 2 * 2 by norm_num, Real.sqrt_mul (by norm_num), Real.sqrt_sq (by norm_num)]
  rw [pb_eq (n := 8) (s := 2) (t := 2) (R := 32) (by norm_num), h32]
  push_cast
  ring

theorem G8_not_join : ¬ ∃ (H : SimpleGraph (Fin (8 - 2 + 1))) (_ : DecidableRel H.Adj),
    H.IsRegularOfDegree 2 ∧
      Nonempty (G8 ≃g graphJoin (⊤ : SimpleGraph (Fin (2 - 1))) H) := by
  rintro ⟨H, _, -, ⟨φ⟩⟩
  have key : ∀ w : Fin 8, ∃ v, v ≠ w ∧ ¬ G8.Adj w v := by decide +kernel
  let z : Fin (2 - 1) := ⟨0, by norm_num⟩
  have hw : φ (φ.symm (Sum.inl z)) = Sum.inl z := RelIso.apply_symm_apply φ _
  obtain ⟨v, hv, hna⟩ := key (φ.symm (Sum.inl z))
  apply hna
  rw [← φ.map_adj_iff, hw]
  rcases hφ : φ v with i | j
  · exfalso
    apply hv
    apply φ.injective
    rw [hφ, hw]
    exact congrArg Sum.inl (Fin.ext (by simp [z]))
  · trivial

theorem G8_not_free : ¬ (completeBipartiteGraph (Fin 2) (Fin (2 + 1))).Free G8 :=
  not_free_of _ (Sum.elim ![0, 1] ![2, 3, 5]) (by decide +kernel) (by decide +kernel)

/-- The unrestricted "equality iff join" is false at `(n,s,t) = (8,2,2)`. -/
theorem unrestricted_equality_false_at_8 :
    qIndex G8 = printedBound 8 2 2 ∧
      (¬ ∃ (H : SimpleGraph (Fin (8 - 2 + 1))) (_ : DecidableRel H.Adj),
        H.IsRegularOfDegree 2 ∧
          Nonempty (G8 ≃g graphJoin (⊤ : SimpleGraph (Fin (2 - 1))) H)) ∧
      ¬ (completeBipartiteGraph (Fin 2) (Fin (2 + 1))).Free G8 :=
  ⟨by rw [G8_q, G8_pb], G8_not_join, G8_not_free⟩

end QIdxCtrl

#print axioms QIdxCtrl.reviewer_form
#print axioms QIdxCtrl.triangle_attains
#print axioms QIdxCtrl.triangle_join
#print axioms QIdxCtrl.K4_not_C4_free
#print axioms QIdxCtrl.K4_no_induced_C4
#print axioms QIdxCtrl.bowtie_clause_instance
#print axioms QIdxCtrl.bowtie_join
#print axioms QIdxCtrl.variant_sign
#print axioms QIdxCtrl.variant_const
#print axioms QIdxCtrl.variant_order
#print axioms QIdxCtrl.variant_trunc
#print axioms QIdxCtrl.P3_q
#print axioms QIdxCtrl.W5_join
#print axioms QIdxCtrl.W5_not_free
#print axioms QIdxCtrl.W5_equality
#print axioms QIdxCtrl.unrestricted_equality_false_at_8
#print axioms QIdxCtrl.free_swap
