import QIdxReviewControls

open QIdx QIdxCtrl

/-- Deliberately incomplete. This module must be rejected under warningAsError. -/
theorem neg_sorry_triangle : qIndex (⊤ : SimpleGraph (Fin 3)) = 4 := by
  sorry
