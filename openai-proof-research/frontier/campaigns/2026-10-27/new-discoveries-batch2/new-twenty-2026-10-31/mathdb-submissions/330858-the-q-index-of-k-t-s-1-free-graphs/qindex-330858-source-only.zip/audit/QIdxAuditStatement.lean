import QIdxStatement

#print axioms QIdx.signlessLaplacian_isHermitian
#print axioms QIdx.qIndex_isGreatest
#print axioms QIdx.Statement
