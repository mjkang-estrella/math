import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Combinatorics.SimpleGraph.AdjMatrix
import Mathlib.Combinatorics.SimpleGraph.Copy
import Mathlib.Combinatorics.SimpleGraph.LapMatrix
import Mathlib.Algebra.Algebra.Spectrum.Basic
import Mathlib.Analysis.Real.Sqrt

/-!
# MathDB 330858: the literal statement

The Q-index extremal theorem for `K_{t,s+1}`-free graphs (de Freitas, Nikiforov, Patuzzi,
arXiv:1507.00625, Conjecture 4).  See `FIDELITY.md` for each modelling decision.
-/

open SimpleGraph Matrix

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- The signless Laplacian `Q(G) = A + D` as a real matrix. -/
noncomputable def signlessLaplacian (G : SimpleGraph V) [DecidableRel G.Adj] : Matrix V V ℝ :=
  G.adjMatrix ℝ + G.degMatrix ℝ

theorem signlessLaplacian_isHermitian (G : SimpleGraph V) [DecidableRel G.Adj] :
    (signlessLaplacian G).IsHermitian := by
  rw [Matrix.IsHermitian, Matrix.conjTranspose_eq_transpose_of_trivial]
  exact G.isSymm_adjMatrix.add (G.isSymm_degMatrix ℝ)

/-- The Q-index: the largest element of the real spectrum of `Q(G)`. -/
noncomputable def qIndex (G : SimpleGraph V) [DecidableRel G.Adj] : ℝ :=
  sSup (spectrum ℝ (signlessLaplacian G))

/-- `qIndex G` really is the largest eigenvalue (a control on the definition). -/
theorem qIndex_isGreatest [Nonempty V] (G : SimpleGraph V) [DecidableRel G.Adj] :
    IsGreatest (spectrum ℝ (signlessLaplacian G)) (qIndex G) := by
  have hrange := (signlessLaplacian_isHermitian G).spectrum_real_eq_range_eigenvalues
  have hfin : (spectrum ℝ (signlessLaplacian G)).Finite := by
    rw [hrange]; exact Set.finite_range _
  have hne : (spectrum ℝ (signlessLaplacian G)).Nonempty := by
    rw [hrange]; exact Set.range_nonempty _
  exact ⟨hne.csSup_mem hfin, fun _ hx => le_csSup hfin.bddAbove hx⟩

/-- The join `G₁ ∨ G₂`: disjoint union of `G₁` and `G₂` with all cross edges added. -/
def graphJoin {A B : Type*} (G₁ : SimpleGraph A) (G₂ : SimpleGraph B) : SimpleGraph (A ⊕ B) where
  Adj x y :=
    match x, y with
    | Sum.inl a, Sum.inl a' => G₁.Adj a a'
    | Sum.inr b, Sum.inr b' => G₂.Adj b b'
    | Sum.inl _, Sum.inr _ => True
    | Sum.inr _, Sum.inl _ => True
  symm := ⟨by
    rintro (a | b) (a' | b') h
    · exact (show G₁.Adj a a' from h).symm
    · trivial
    · trivial
    · exact (show G₂.Adj b b' from h).symm⟩
  loopless := ⟨by
    rintro (a | b) h
    · exact G₁.loopless.irrefl a h
    · exact G₂.loopless.irrefl b h⟩

/-- The printed right-hand side of Conjecture 4, with real subtraction throughout. -/
noncomputable def printedBound (n s t : ℕ) : ℝ :=
  (n : ℝ) / 2 + s + t - 2 +
    (1 / 2) * Real.sqrt (((n : ℝ) - 2 + 2 * s) ^ 2 - 8 * s * ((n : ℝ) - 2)
      + 4 * ((t : ℝ) - 1) * ((n : ℝ) - t + 1))

/-- The literal statement of MathDB 330858. -/
def Statement : Prop :=
  ∀ s t : ℕ, 2 ≤ t → t - 1 ≤ s →
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n → ∀ (G : SimpleGraph (Fin n)) [DecidableRel G.Adj],
      (completeBipartiteGraph (Fin t) (Fin (s + 1))).Free G →
        qIndex G ≤ printedBound n s t ∧
        (qIndex G = printedBound n s t ↔
          ∃ (H : SimpleGraph (Fin (n - t + 1))) (_ : DecidableRel H.Adj),
            H.IsRegularOfDegree s ∧
              Nonempty (G ≃g graphJoin (⊤ : SimpleGraph (Fin (t - 1))) H))

end QIdx
