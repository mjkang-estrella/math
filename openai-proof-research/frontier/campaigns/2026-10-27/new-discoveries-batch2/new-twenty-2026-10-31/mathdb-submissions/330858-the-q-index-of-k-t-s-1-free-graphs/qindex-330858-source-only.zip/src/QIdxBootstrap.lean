import QIdxEstimates

/-! # The structural step: `t - 1` universal vertices via the integer-gap bootstrap. -/

open SimpleGraph Finset

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

omit [DecidableEq V] in
/-- Normalize a nonzero nonnegative eigenvector to maximum `1`. -/
theorem exists_eigData {x : V → ℝ} {q : ℝ} (hx : ∀ v, 0 ≤ x v) (hx0 : x ≠ 0)
    (heig : ∀ v, q * x v = G.degree v * x v + ∑ w ∈ G.neighborFinset v, x w)
    (hq : (Fintype.card V : ℝ) ≤ q) :
    ∃ y : V → ℝ, EigData G y q ∧ ∃ u, y u = 1 := by
  have hex : ∃ v, x v ≠ 0 := by
    by_contra hcon
    push Not at hcon
    exact hx0 (funext hcon)
  obtain ⟨v, hv⟩ := hex
  obtain ⟨u, -, hu⟩ := Finset.exists_max_image (univ : Finset V) x ⟨v, Finset.mem_univ v⟩
  have hMpos : 0 < x u := lt_of_lt_of_le (lt_of_le_of_ne (hx v) (Ne.symm hv)) (hu v (Finset.mem_univ v))
  refine ⟨fun v => x v / x u, ⟨fun v => div_nonneg (hx v) hMpos.le, fun v => ?_, fun v => ?_, hq⟩,
    u, div_self hMpos.ne'⟩
  · exact (div_le_one hMpos).mpr (hu v (Finset.mem_univ v))
  · have := heig v
    calc q * (x v / x u) = (q * x v) / x u := by ring
      _ = (G.degree v * x v + ∑ w ∈ G.neighborFinset v, x w) / x u := by rw [this]
      _ = G.degree v * (x v / x u) + ∑ w ∈ G.neighborFinset v, x w / x u := by
          rw [add_div, Finset.sum_div]; ring

theorem big_ineq {t n S η C l : ℝ} (hSle : S ≤ t - 1)
    (hn : 0 < n) (ht : (2 : ℝ) ≤ t) (hη : η * (2 * t) = 1) (hηle : η ≤ 1 / 4)
    (hn3 : 6 * t * C * l ≤ n) (hCl : 0 ≤ C * l) :
    16 * t ^ 2 * n * S + 2 * (16 * t ^ 2) * C * l ≤ ((16 * t ^ 2) - 2) * n * (S + η) := by
  have hsnd : ((16 * t ^ 2) - 2) * η = 8 * t - 2 * η := by
    linear_combination (8 * t) * hη
  have h1 : ((16 * t ^ 2) - 2) * n * η = n * (8 * t - 2 * η) := by
    calc ((16 * t ^ 2) - 2) * n * η = n * (((16 * t ^ 2) - 2) * η) := by ring
      _ = n * (8 * t - 2 * η) := by rw [hsnd]
  have htpos : 0 < t := by linarith
  have h3 : 6 * t * (6 * t * C * l) ≤ 6 * t * n :=
    mul_le_mul_of_nonneg_left hn3 (by positivity)
  have h4 : 0 ≤ t ^ 2 * (C * l) := by positivity
  have h5 : n * S ≤ n * (t - 1) := mul_le_mul_of_nonneg_left hSle hn.le
  have h6 : 0 ≤ n * (2 - 2 * η) := mul_nonneg hn.le (by linarith)
  have hexp : ((16 * t ^ 2) - 2) * n * (S + η) =
      ((16 * t ^ 2) - 2) * n * S + ((16 * t ^ 2) - 2) * n * η := by ring
  rw [hexp, h1]
  have h32 : 32 * (t ^ 2 * (C * l)) ≤ 6 * t * n := by
    have : 36 * (t ^ 2 * (C * l)) ≤ 6 * t * n := by
      calc 36 * (t ^ 2 * (C * l)) = 6 * t * (6 * t * C * l) := by ring
        _ ≤ 6 * t * n := h3
    linarith
  linarith [h5, h6, h32]

theorem final_contra {t X S η : ℝ} (hprod : (2 * t - 1) * (1 - η / 2) ≤ X)
    (hb : X ≤ 2 * S + η) (hSle : S ≤ t - 1) (hη : η * (2 * t) = 1) (hηle : η ≤ 1 / 4) : False := by
  have hexp : (2 * t - 1) * (1 - η / 2) = 2 * t - 1 - t * η + η / 2 := by ring
  rw [hexp] at hprod
  linarith

set_option maxHeartbeats 1000000 in
theorem universal_core {t s D0 l0 C0 : ℕ} (ht : 2 ≤ t) (hD0 : D0 = 16 * t ^ 2)
    (hl0 : l0 = t * D0) (hC0 : C0 = 3 * l0 * (2 * t))
    (hcn : ∀ T : Finset V, T.card = t → (commonNbrs G T).card ≤ s)
    (hn1 : l0 * (s * l0.choose t) < Fintype.card V)
    (hn2 : 2 * s < Fintype.card V)
    (hn3 : 6 * t * C0 * l0 ≤ Fintype.card V)
    (hn4 : C0 < Fintype.card V)
    {x : V → ℝ} {q : ℝ} (hd : EigData G x q) {u : V} (hu : x u = 1)
    (hq : (Fintype.card V : ℝ) + 2 * t - 4 ≤ q) :
    ∃ K : Finset V, K.card = t - 1 ∧ ∀ w ∈ K, G.degree w = Fintype.card V - 1 := by
  have ht1 : 1 ≤ t := by omega
  have htR : (2 : ℝ) ≤ t := by exact_mod_cast ht
  have hD4 : 4 ≤ D0 := by
    subst hD0
    have : 1 ≤ t ^ 2 := Nat.one_le_pow _ _ (by omega)
    omega
  have hD0R : (D0 : ℝ) = 16 * (t : ℝ) ^ 2 := by rw [hD0]; push_cast; ring
  -- hub and heavy sets
  obtain ⟨L, hL⟩ : ∃ L : Finset V, L = univ.filter (fun v => Fintype.card V ≤ D0 * G.degree v) :=
    ⟨_, rfl⟩
  obtain ⟨P, hP⟩ : ∃ P : Finset V,
      P = univ.filter (fun v => 2 * t * (Fintype.card V - G.degree v) ≤ Fintype.card V) :=
    ⟨_, rfl⟩
  have hLcard : L.card < t * D0 := by
    rw [hL]
    refine card_hubs_lt ht1 (by omega) hcn ?_
    rw [← hl0]; exact hn1
  have hLcard' : (L.card : ℝ) ≤ (l0 : ℝ) := by
    have : L.card ≤ l0 := by rw [hl0]; omega
    exact_mod_cast this
  have hPcard : P.card ≤ t - 1 := by rw [hP]; exact card_heavy_le ht1 hcn hn2
  have h4 : ∀ v, v ∉ L → 4 * (G.degree v : ℝ) ≤ (Fintype.card V : ℝ) := by
    intro v hv
    have hvL : ¬ (Fintype.card V ≤ D0 * G.degree v) := by
      intro h; exact hv (hL ▸ Finset.mem_filter.mpr ⟨Finset.mem_univ v, h⟩)
    have hle : 4 * G.degree v ≤ Fintype.card V := by
      have h1 : 4 * G.degree v ≤ D0 * G.degree v := Nat.mul_le_mul_right _ hD4
      omega
    exact_mod_cast hle
  have hL' : ∀ v, v ∉ L → (D0 : ℝ) * (G.degree v : ℝ) ≤ (Fintype.card V : ℝ) := by
    intro v hv
    have hvL : ¬ (Fintype.card V ≤ D0 * G.degree v) := by
      intro h; exact hv (hL ▸ Finset.mem_filter.mpr ⟨Finset.mem_univ v, h⟩)
    have hle : D0 * G.degree v ≤ Fintype.card V := by omega
    exact_mod_cast hle
  have hdeg : ∀ v, G.degree v ≤ Fintype.card V := fun v => (G.degree_lt_card_verts v).le
  have hPreal : ∀ v, v ∉ P → (2 * (t : ℝ)) * (G.degree v : ℝ) + (Fintype.card V : ℝ)
      ≤ (2 * (t : ℝ)) * (Fintype.card V : ℝ) := by
    intro v hv
    have hvP : ¬ (2 * t * (Fintype.card V - G.degree v) ≤ Fintype.card V) := by
      intro h; exact hv (hP ▸ Finset.mem_filter.mpr ⟨Finset.mem_univ v, h⟩)
    have h1 : Fintype.card V < 2 * t * (Fintype.card V - G.degree v) := not_le.mp hvP
    have h2 : (Fintype.card V : ℝ) < ((2 * t * (Fintype.card V - G.degree v) : ℕ) : ℝ) := by
      exact_mod_cast h1
    push_cast [Nat.cast_sub (hdeg v)] at h2
    linarith
  have hE : (1 : ℝ) ≤ 2 * (t : ℝ) := by linarith
  have hl0R : (0 : ℝ) ≤ (l0 : ℝ) := Nat.cast_nonneg _
  have hlP : ∀ v, v ∉ P → (Fintype.card V : ℝ) * x v ≤ 3 * (l0 : ℝ) * (2 * (t : ℝ)) :=
    fun v hv => low_outside_P hd L P hl0R hE hLcard' h4 hPreal hv
  have hC0R : (C0 : ℝ) = 3 * (l0 : ℝ) * (2 * (t : ℝ)) := by rw [hC0]; push_cast; ring
  have hCn : ∀ v, v ∉ P → (Fintype.card V : ℝ) * x v ≤ (C0 : ℝ) := by
    intro v hv; rw [hC0R]; exact hlP v hv
  have hn4R : (C0 : ℝ) < (Fintype.card V : ℝ) := by exact_mod_cast hn4
  have huP : u ∈ P := by
    by_contra hcon
    have := hCn u hcon
    rw [hu, mul_one] at this
    linarith
  have hnpos : (0 : ℝ) < (Fintype.card V : ℝ) := by
    have : 0 < Fintype.card V := Fintype.card_pos_iff.mpr ⟨u⟩
    exact_mod_cast this
  set S : ℝ := ∑ v ∈ P, x v with hS
  set σ : ℝ := ∑ v ∈ Pᶜ, x v with hσ
  have hScard : S ≤ (P.card : ℝ) := by
    calc S = ∑ v ∈ P, x v := hS
      _ ≤ ∑ _v ∈ P, (1 : ℝ) := Finset.sum_le_sum (fun v _ => hd.le_one v)
      _ = (P.card : ℝ) := by simp
  have hPcardR : (P.card : ℝ) ≤ (t : ℝ) - 1 := by
    have h1 : P.card + 1 ≤ t := by omega
    have h2 : (P.card : ℝ) + 1 ≤ t := by exact_mod_cast h1
    linarith
  have hSle : S ≤ (t : ℝ) - 1 := hScard.trans hPcardR
  have hsq : (1 : ℝ) ≤ (t : ℝ) ^ 2 := one_le_pow₀ (by linarith)
  have hD1 : (1 : ℝ) ≤ (D0 : ℝ) := by rw [hD0R]; linarith
  have hC0nn : (0 : ℝ) ≤ (C0 : ℝ) := Nat.cast_nonneg _
  have hsum := sum_outside_P hd L P (l := (l0 : ℝ)) (D := (D0 : ℝ)) (C := (C0 : ℝ))
    hD1 hC0nn hLcard' hL' hCn
  -- the eta bound
  let η : ℝ := 1 / (2 * (t : ℝ))
  have htpos : (0 : ℝ) < t := by linarith
  have hη : η * (2 * (t : ℝ)) = 1 := by
    show 1 / (2 * (t : ℝ)) * (2 * (t : ℝ)) = 1
    field_simp
  have hηpos : 0 < η := by positivity
  have hηle : η ≤ 1 / 4 := by
    have := mul_nonneg (sub_nonneg.2 htR) hηpos.le
    linarith
  have hn3R : 6 * (t : ℝ) * (C0 : ℝ) * (l0 : ℝ) ≤ (Fintype.card V : ℝ) := by exact_mod_cast hn3
  have hbig : (D0 : ℝ) * (Fintype.card V : ℝ) * S + 2 * (D0 : ℝ) * (C0 : ℝ) * (l0 : ℝ)
      ≤ ((D0 : ℝ) - 2) * (Fintype.card V : ℝ) * (S + η) := by
    rw [hD0R]
    exact big_ineq hSle hnpos htR hη hηle hn3R (by positivity)
  have hApos : 0 < ((D0 : ℝ) - 2) * (Fintype.card V : ℝ) := by
    have : (2 : ℝ) < (D0 : ℝ) := by rw [hD0R]; linarith
    exact mul_pos (by linarith) hnpos
  have hσle : σ ≤ S + η := le_of_mul_le_mul_left (hsum.trans hbig) hApos
  -- bound for heavy vertices
  have hheavy : ∀ w ∈ P, (q - G.degree w + 1) * x w ≤ 2 * S + η := by
    intro w hw
    have he := hd.eig w
    have hNsub : G.neighborFinset w ⊆ univ.erase w := by
      intro v hv
      rw [SimpleGraph.mem_neighborFinset] at hv
      exact Finset.mem_erase.mpr ⟨hv.ne', Finset.mem_univ v⟩
    have hsumN : ∑ v ∈ G.neighborFinset w, x v ≤ ∑ v ∈ univ.erase w, x v :=
      Finset.sum_le_sum_of_subset_of_nonneg hNsub (fun v _ _ => hd.nonneg v)
    have hE2 : ∑ v ∈ univ.erase w, x v = S + σ - x w := by
      rw [Finset.sum_erase_eq_sub (Finset.mem_univ w), hS, hσ, Finset.sum_add_sum_compl]
    have hexp : (q - G.degree w + 1) * x w = q * x w - G.degree w * x w + x w := by ring
    rw [hexp]
    linarith
  -- the eigen-gap at u
  have hdu : (G.degree u : ℝ) ≤ (Fintype.card V : ℝ) - 1 := by
    have h1 : G.degree u + 1 ≤ Fintype.card V := G.degree_lt_card_verts u
    have h2 : (G.degree u : ℝ) + 1 ≤ (Fintype.card V : ℝ) := by exact_mod_cast h1
    linarith
  have hgap : 2 * (t : ℝ) - 2 ≤ 2 * S + η := by
    have := hheavy u huP
    rw [hu, mul_one] at this
    linarith
  -- P has exactly t - 1 elements
  have hPeq : P.card = t - 1 := by
    have h1 : (t : ℝ) < (P.card : ℝ) + 2 := by linarith
    have h2 : t < P.card + 2 := by exact_mod_cast h1
    omega
  have hPeqR : (P.card : ℝ) = (t : ℝ) - 1 := by rw [hPeq, Nat.cast_sub ht1, Nat.cast_one]
  -- every heavy vertex is nearly maximal
  have hxw : ∀ w ∈ P, 1 - η / 2 ≤ x w := by
    intro w hw
    have hsplit : x w + ∑ v ∈ P.erase w, x v = S := by
      rw [hS, Finset.add_sum_erase _ _ hw]
    have herase : ∑ v ∈ P.erase w, x v ≤ (t : ℝ) - 2 := by
      calc ∑ v ∈ P.erase w, x v ≤ ∑ _v ∈ P.erase w, (1 : ℝ) :=
            Finset.sum_le_sum (fun v _ => hd.le_one v)
        _ = ((P.erase w).card : ℝ) := by simp
        _ = (P.card : ℝ) - 1 := by
            rw [Finset.card_erase_of_mem hw, Nat.cast_sub (Finset.card_pos.mpr ⟨w, hw⟩), Nat.cast_one]
        _ = (t : ℝ) - 2 := by rw [hPeqR]; ring
    linarith
  refine ⟨P, hPeq, ?_⟩
  intro w hw
  by_contra hne
  have hlt := G.degree_lt_card_verts w
  have hd2 : G.degree w + 2 ≤ Fintype.card V := by omega
  have hd2R : (G.degree w : ℝ) + 2 ≤ (Fintype.card V : ℝ) := by exact_mod_cast hd2
  have hb := hheavy w hw
  have hxwl := hxw w hw
  have hcoeff : 2 * (t : ℝ) - 1 ≤ q - G.degree w + 1 := by linarith
  have hprod : (2 * (t : ℝ) - 1) * (1 - η / 2) ≤ (q - G.degree w + 1) * x w :=
    mul_le_mul hcoeff hxwl (by linarith) (by linarith)
  exact final_contra hprod hb hSle hη hηle

/-- The size hypothesis in closed form. -/
def thresholdN (s t : ℕ) : ℕ :=
  (t * (16 * t ^ 2)) * (s * (t * (16 * t ^ 2)).choose t) + 2 * s
    + 6 * t * (3 * (t * (16 * t ^ 2)) * (2 * t)) * (t * (16 * t ^ 2))
    + 3 * (t * (16 * t ^ 2)) * (2 * t) + t + 1

theorem universal_of_large_q {t s : ℕ} (ht : 2 ≤ t)
    (hcn : ∀ T : Finset V, T.card = t → (commonNbrs G T).card ≤ s)
    (hn : thresholdN s t ≤ Fintype.card V)
    {x : V → ℝ} {q : ℝ} (hd : EigData G x q) {u : V} (hu : x u = 1)
    (hq : (Fintype.card V : ℝ) + 2 * t - 4 ≤ q) :
    ∃ K : Finset V, K.card = t - 1 ∧ ∀ w ∈ K, G.degree w = Fintype.card V - 1 := by
  unfold thresholdN at hn
  refine universal_core (D0 := 16 * t ^ 2) (l0 := t * (16 * t ^ 2))
    (C0 := 3 * (t * (16 * t ^ 2)) * (2 * t)) ht rfl rfl rfl hcn ?_ ?_ ?_ ?_ hd hu hq <;> omega

end QIdx
