# FIDELITY.md: MathDB 330858 statement modelling

Source checked: inputs/literal330858.json and inputs/sources/1507.00625.txt, Conjecture 4 (text layer):
"Let s >= t-1 >= 1, and let n be sufficiently large. If G is a K_{t,s+1}-free graph of order n, then q(G) <= n/2 + s + t - 2 + (1/2) sqrt((n-2+2s)^2 - 8s(n-2) + 4(t-1)(n-t+1)). Equality holds if and only if G is a join of K_{t-1} and an s-regular graph of order n-t+1."
The MathDB literal has the same hypotheses, bound and equality clause (it writes "the join").

Lean: `QIdx.Statement` in src/QIdxStatement.lean. Modelling decisions:

1. Scalars and quantifiers. `s t : ℕ`, `2 ≤ t`, `t - 1 ≤ s` (t >= 2 makes ℕ subtraction exact), which is s >= t-1 >= 1. "n sufficiently large" is `∃ N, ∀ n ≥ N`, with N allowed to depend on s and t only (the existential sits after `∀ s t`, before `∀ n`).
2. G. `G : SimpleGraph (Fin n)`, a simple graph of order n on the canonical vertex set, with `[DecidableRel G.Adj]` universally quantified so every instance is covered. Every graph of order n is isomorphic to one on Fin n, and Q-spectrum, freeness and join form are isomorphism-invariant.
3. Q(G). `signlessLaplacian G := G.adjMatrix ℝ + G.degMatrix ℝ` over ℝ: mathlib's adjacency and degree matrices, literally A + D.
4. q(G). `qIndex G := sSup (spectrum ℝ (signlessLaplacian G))`, the largest element of the actual real spectrum of Q, not a Rayleigh-quotient surrogate. `qIndex_isGreatest` proves that for nonempty V it is a member of the spectrum and an upper bound of it, so it is the true largest eigenvalue. The source defines q(G) as the maximal eigenvalue of Q(G).
5. K_{t,s+1}-free. mathlib's `(completeBipartiteGraph (Fin t) (Fin (s + 1))).Free G`, which is `¬ H ⊑ G`, with `⊑` being existence of a `Copy`, an injective graph homomorphism. This is ordinary non-induced subgraph containment. No induced condition appears.
6. Bound. `printedBound n s t` uses the printed square-root form literally with real arithmetic: `(n : ℝ) / 2 + s + t - 2 + (1 / 2) * Real.sqrt (((n : ℝ) - 2 + 2 * s) ^ 2 - 8 * s * ((n : ℝ) - 2) + 4 * ((t : ℝ) - 1) * ((n : ℝ) - t + 1))`. No simplification and no truncated subtraction.
7. Join. mathlib has no graph join, so `graphJoin G₁ G₂` on `A ⊕ B` is defined by hand: within A adjacency of G₁, within B adjacency of G₂, across parts always adjacent (the standard G₁ ∨ G₂). K_{t-1} is `⊤ : SimpleGraph (Fin (t - 1))`. "G is a join of K_{t-1} and an s-regular graph of order n-t+1" is: there is `H : SimpleGraph (Fin (n - t + 1))` with `H.IsRegularOfDegree s` and `Nonempty (G ≃g graphJoin ⊤ H)`. A `DecidableRel H.Adj` is existentially supplied only so that mathlib's `IsRegularOfDegree` typechecks; regularity does not depend on it. `n - t + 1` in ℕ is the true order because N will exceed t.
8. Equality clause. It is read inside the freeness hypothesis: in the source the sentence follows "If G is a K_{t,s+1}-free graph of order n, then ...". Theorem 5, the source's own t = 2 case, has the same shape: "If G is ... containing no K_{2,s+1}, then ... Equality holds if and only if ...". In `Statement` the conjunction `bound ∧ (equality ↔ join)` is the conclusion of `Free → ...`. A join of K_{t-1} and an s-regular graph need not be free, and the literal is not read as asserting that all such joins are free; the reverse implication is required only for free G.

Scope note: the proof is carried out for an arbitrary finite vertex type V in `main_general`, with the literal theorem `qindex_kts_endpoint : Statement` obtained for `Fin n` by `Fintype.card_fin`.

Proof route: reviewer-PROOF.md (delta split, no Kovari-Sos-Turan edge count), with the hub count by pigeonhole style double counting (author step (2)). It changes no definition.

Nothing here is an acceptance claim. Credit 0, root-only.
