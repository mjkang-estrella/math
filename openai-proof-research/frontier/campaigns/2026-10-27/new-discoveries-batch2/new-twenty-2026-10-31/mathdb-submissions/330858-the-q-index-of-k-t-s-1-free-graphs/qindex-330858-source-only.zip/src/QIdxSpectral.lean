import QIdxStatement
import Mathlib.Analysis.Matrix.Order

/-! # The spectral bridge: a nonnegative top eigenvector and the positive-eigenvector test. -/

open SimpleGraph Matrix Finset

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem Q_mulVec_apply (x : V → ℝ) (v : V) :
    (signlessLaplacian G *ᵥ x) v = G.degree v * x v + ∑ w ∈ G.neighborFinset v, x w := by
  simp only [signlessLaplacian, add_mulVec, Pi.add_apply, adjMatrix_mulVec_apply,
    degMatrix_mulVec_apply]
  ring

theorem exists_top_eigenvector [Nonempty V] :
    ∃ y : V → ℝ, y ≠ 0 ∧ signlessLaplacian G *ᵥ y = qIndex G • y := by
  have hA := signlessLaplacian_isHermitian G
  have hmem := (qIndex_isGreatest G).1
  rw [hA.spectrum_real_eq_range_eigenvalues] at hmem
  obtain ⟨i, hi⟩ := hmem
  refine ⟨⇑(hA.eigenvectorBasis i), ?_, ?_⟩
  · intro h
    exact hA.eigenvectorBasis.orthonormal.ne_zero i (by ext v; simpa using congrFun h v)
  · rw [← hi]; exact hA.mulVec_eigenvectorBasis i

theorem top_sub_posSemidef [Nonempty V] :
    (algebraMap ℝ (Matrix V V ℝ) (qIndex G) - signlessLaplacian G).PosSemidef := by
  have hA := signlessLaplacian_isHermitian G
  have hB : (algebraMap ℝ (Matrix V V ℝ) (qIndex G) - signlessLaplacian G).IsHermitian := by
    refine IsHermitian.sub ?_ hA
    rw [Matrix.algebraMap_eq_diagonal]
    exact isHermitian_diagonal _
  rw [hB.posSemidef_iff_eigenvalues_nonneg]
  intro i
  have h : hB.eigenvalues i ∈
      spectrum ℝ (algebraMap ℝ (Matrix V V ℝ) (qIndex G) - signlessLaplacian G) := by
    rw [hB.spectrum_real_eq_range_eigenvalues]; exact ⟨i, rfl⟩
  rw [← spectrum.singleton_sub_eq] at h
  obtain ⟨r, hr, μ, hμ, e⟩ := Set.mem_sub.1 h
  have hle := (qIndex_isGreatest G).2 hμ
  rw [Set.mem_singleton_iff] at hr
  subst hr
  simp only [Pi.zero_apply]
  linarith

/-- A nonnegative eigenvector for the top eigenvalue (no Perron–Frobenius needed). -/
theorem exists_nonneg_top_eigenvector [Nonempty V] :
    ∃ x : V → ℝ, (∀ v, 0 ≤ x v) ∧ x ≠ 0 ∧ signlessLaplacian G *ᵥ x = qIndex G • x := by
  obtain ⟨y, hy0, hy⟩ := exists_top_eigenvector G
  have hP := top_sub_posSemidef G
  set q := qIndex G with hq
  set B := algebraMap ℝ (Matrix V V ℝ) q - signlessLaplacian G with hB
  let z : V → ℝ := fun v => |y v|
  have hBz : B *ᵥ z = q • z - signlessLaplacian G *ᵥ z := by
    rw [hB, sub_mulVec, Algebra.algebraMap_eq_smul_one, smul_mulVec, one_mulVec]
  have heig : ∀ v, q * y v = G.degree v * y v + ∑ w ∈ G.neighborFinset v, y w := by
    intro v
    have := congrFun hy v
    rw [Q_mulVec_apply] at this
    simpa [Pi.smul_apply, smul_eq_mul] using this.symm
  have hterm : ∀ v, z v * (q * z v - (G.degree v * z v + ∑ w ∈ G.neighborFinset v, z w)) ≤ 0 := by
    intro v
    have hsq : z v * z v = y v * y v := abs_mul_abs_self (y v)
    have hsum : |∑ w ∈ G.neighborFinset v, y w| ≤ ∑ w ∈ G.neighborFinset v, z w :=
      Finset.abs_sum_le_sum_abs _ _
    have hprod : y v * ∑ w ∈ G.neighborFinset v, y w
        ≤ z v * ∑ w ∈ G.neighborFinset v, z w := by
      calc y v * ∑ w ∈ G.neighborFinset v, y w
          ≤ |y v * ∑ w ∈ G.neighborFinset v, y w| := le_abs_self _
        _ = z v * |∑ w ∈ G.neighborFinset v, y w| := abs_mul _ _
        _ ≤ z v * ∑ w ∈ G.neighborFinset v, z w :=
            mul_le_mul_of_nonneg_left hsum (abs_nonneg _)
    have hk := heig v
    have hyy : y v * (q * y v) = y v * (G.degree v * y v) + y v * ∑ w ∈ G.neighborFinset v, y w := by
      rw [hk]; ring
    have e1 : z v * (q * z v) = q * (y v * y v) := by rw [← hsq]; ring
    have e2 : z v * (G.degree v * z v) = G.degree v * (y v * y v) := by rw [← hsq]; ring
    have e3 : y v * (q * y v) = q * (y v * y v) := by ring
    have e4 : y v * (G.degree v * y v) = G.degree v * (y v * y v) := by ring
    nlinarith
  have hnonpos : star z ⬝ᵥ (B *ᵥ z) ≤ 0 := by
    rw [hBz, star_trivial, dotProduct]
    refine Finset.sum_nonpos (fun v _ => ?_)
    have := hterm v
    simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, Q_mulVec_apply]
    exact this
  have hzero : star z ⬝ᵥ (B *ᵥ z) = 0 := le_antisymm hnonpos (hP.dotProduct_mulVec_nonneg z)
  have hBz0 : B *ᵥ z = 0 := hP.dotProduct_mulVec_zero_iff.mp hzero
  refine ⟨z, fun v => abs_nonneg _, ?_, ?_⟩
  · intro hz
    apply hy0
    ext v
    have := congrFun hz v
    simpa [z] using this
  · rw [hBz] at hBz0
    exact (sub_eq_zero.mp hBz0).symm

/-- The eigenequation in graph form. -/
theorem eigen_apply {x : V → ℝ} {q : ℝ} (h : signlessLaplacian G *ᵥ x = q • x) (v : V) :
    q * x v = G.degree v * x v + ∑ w ∈ G.neighborFinset v, x w := by
  have := congrFun h v
  rw [Q_mulVec_apply] at this
  simpa [Pi.smul_apply, smul_eq_mul] using this.symm

/-- A positive eigenvector can only belong to the top eigenvalue. -/
theorem eq_qIndex_of_pos_eigenvector [Nonempty V] {x : V → ℝ} {μ : ℝ} (hx : ∀ v, 0 < x v)
    (h : signlessLaplacian G *ᵥ x = μ • x) : μ = qIndex G := by
  obtain ⟨z, hz, hz0, hzq⟩ := exists_nonneg_top_eigenvector G
  have hsymm : (signlessLaplacian G)ᵀ = signlessLaplacian G := by
    have := signlessLaplacian_isHermitian G
    rw [Matrix.IsHermitian, Matrix.conjTranspose_eq_transpose_of_trivial] at this
    exact this
  have hcomm : z ⬝ᵥ (signlessLaplacian G *ᵥ x) = (signlessLaplacian G *ᵥ z) ⬝ᵥ x := by
    rw [Matrix.dotProduct_mulVec, ← Matrix.mulVec_transpose, hsymm]
  rw [h, hzq, dotProduct_smul, smul_dotProduct, smul_eq_mul, smul_eq_mul] at hcomm
  have hpos : 0 < z ⬝ᵥ x := by
    have hex : ∃ v, z v ≠ 0 := by
      by_contra hcon
      push Not at hcon
      exact hz0 (funext hcon)
    obtain ⟨v, hv⟩ := hex
    have hvpos : 0 < z v := lt_of_le_of_ne (hz v) (Ne.symm hv)
    rw [dotProduct]
    exact Finset.sum_pos' (fun i _ => mul_nonneg (hz i) (hx i).le)
      ⟨v, Finset.mem_univ v, mul_pos hvpos (hx v)⟩
  exact mul_right_cancel₀ hpos.ne' hcomm

end QIdx
