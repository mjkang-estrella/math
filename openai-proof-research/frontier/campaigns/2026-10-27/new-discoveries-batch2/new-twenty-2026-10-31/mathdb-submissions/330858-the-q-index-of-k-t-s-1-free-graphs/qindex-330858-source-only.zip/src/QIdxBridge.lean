import QIdxJoin
import QIdxBootstrap

/-! # Bridges between `JoinForm` and the literal join with `K_{t-1}`. -/

open SimpleGraph Finset

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

theorem joinForm_of_universal {t s : ℕ} (ht : 2 ≤ t)
    (hcn : ∀ T : Finset V, T.card = t → (commonNbrs G T).card ≤ s)
    {K : Finset V} (hK : K.card = t - 1)
    (hdeg : ∀ w ∈ K, G.degree w = Fintype.card V - 1) : JoinForm G K t s := by
  have hadj : ∀ w ∈ K, ∀ v, v ≠ w → G.Adj w v := by
    intro w hw v hv
    have hsub : G.neighborFinset w ⊆ univ.erase w := by
      intro u hu
      rw [SimpleGraph.mem_neighborFinset] at hu
      exact Finset.mem_erase.mpr ⟨hu.ne', Finset.mem_univ u⟩
    have hcard : (univ.erase w).card ≤ (G.neighborFinset w).card := by
      rw [Finset.card_erase_of_mem (Finset.mem_univ w), Finset.card_univ,
        G.card_neighborFinset_eq_degree, hdeg w hw]
    have heq := Finset.eq_of_subset_of_card_le hsub hcard
    have hmem : v ∈ G.neighborFinset w := heq ▸ Finset.mem_erase.mpr ⟨hv, Finset.mem_univ v⟩
    exact (SimpleGraph.mem_neighborFinset _ _ _).mp hmem
  refine ⟨hK, hadj, ?_⟩
  intro v hv
  have hT : (insert v K).card = t := by
    rw [Finset.card_insert_of_notMem hv, hK]; omega
  refine le_trans (Finset.card_le_card ?_) (hcn _ hT)
  intro w' hw'
  rw [Finset.mem_sdiff, SimpleGraph.mem_neighborFinset] at hw'
  obtain ⟨hadjv, hw'K⟩ := hw'
  simp only [commonNbrs, Finset.mem_filter, Finset.mem_univ, true_and]
  intro w hw
  rw [Finset.mem_insert] at hw
  rcases hw with rfl | hw
  · exact hadjv
  · exact hadj w hw w' (fun h => hw'K (h ▸ hw))

/-- From a literal join to internal data. -/
theorem joinForm_of_iso {a : ℕ} {W : Type*} [Fintype W] [DecidableEq W]
    {H : SimpleGraph W} [DecidableRel H.Adj] {s t : ℕ} (ha : a = t - 1)
    (hreg : H.IsRegularOfDegree s)
    (φ : G ≃g graphJoin (⊤ : SimpleGraph (Fin a)) H) :
    ∃ K : Finset V, JoinForm G K t s ∧ ∀ v, v ∉ K → ((G.neighborFinset v) \ K).card = s := by
  let inlE : Fin a ↪ V :=
    ⟨fun i => φ.symm (Sum.inl i), fun i j h => Sum.inl.inj (φ.symm.injective h)⟩
  let inrE : W ↪ V :=
    ⟨fun j => φ.symm (Sum.inr j), fun i j h => Sum.inr.inj (φ.symm.injective h)⟩
  let K : Finset V := (univ : Finset (Fin a)).map inlE
  have hKcard : K.card = t - 1 := by simp [K, ha]
  have hmemK : ∀ v, v ∈ K ↔ ∃ i, φ v = Sum.inl i := by
    intro v
    constructor
    · intro hv
      obtain ⟨i, -, rfl⟩ := Finset.mem_map.mp hv
      exact ⟨i, RelIso.apply_symm_apply φ _⟩
    · rintro ⟨i, hi⟩
      refine Finset.mem_map.mpr ⟨i, Finset.mem_univ i, ?_⟩
      show φ.symm (Sum.inl i) = v
      rw [← hi]
      exact RelIso.symm_apply_apply φ v
  have hnotK : ∀ v, v ∉ K → ∃ j, φ v = Sum.inr j := by
    intro v hv
    rcases hφ : φ v with i | j
    · exact absurd ((hmemK v).mpr ⟨i, hφ⟩) hv
    · exact ⟨j, rfl⟩
  have hadjK : ∀ w ∈ K, ∀ v, v ≠ w → G.Adj w v := by
    intro w hw v hv
    obtain ⟨i, hi⟩ := (hmemK w).mp hw
    rw [← φ.map_adj_iff, hi]
    rcases hφ : φ v with i' | j
    · show (⊤ : SimpleGraph (Fin a)).Adj i i'
      rw [SimpleGraph.top_adj]
      intro h
      apply hv
      apply φ.injective
      rw [hφ, hi, h]
    · trivial
  have hexact : ∀ v, v ∉ K → ((G.neighborFinset v) \ K).card = s := by
    intro v hv
    obtain ⟨j, hj⟩ := hnotK v hv
    have heq : (G.neighborFinset v) \ K = (H.neighborFinset j).map inrE := by
      ext w
      constructor
      · intro h
        obtain ⟨hadj, hwK⟩ := Finset.mem_sdiff.mp h
        rw [SimpleGraph.mem_neighborFinset] at hadj
        obtain ⟨j', hj'⟩ := hnotK w hwK
        refine Finset.mem_map.mpr ⟨j', ?_, ?_⟩
        · rw [SimpleGraph.mem_neighborFinset]
          have hA := φ.map_adj_iff.mpr hadj
          rw [hj, hj'] at hA
          exact hA
        · show φ.symm (Sum.inr j') = w
          rw [← hj']
          exact RelIso.symm_apply_apply φ w
      · intro h
        obtain ⟨j', hj'1, rfl⟩ := Finset.mem_map.mp h
        rw [SimpleGraph.mem_neighborFinset] at hj'1
        refine Finset.mem_sdiff.mpr ⟨?_, ?_⟩
        · rw [SimpleGraph.mem_neighborFinset]
          show G.Adj v (φ.symm (Sum.inr j'))
          rw [← φ.map_adj_iff, hj, RelIso.apply_symm_apply]
          exact hj'1
        · intro hmem
          obtain ⟨i, hi⟩ := (hmemK _).mp hmem
          have hconv : φ (φ.symm (Sum.inr j')) = Sum.inl i := hi
          rw [RelIso.apply_symm_apply] at hconv
          cases hconv
    rw [heq, Finset.card_map, H.card_neighborFinset_eq_degree]
    exact hreg j
  refine ⟨K, ⟨hKcard, hadjK, fun v hv => (hexact v hv).le⟩, hexact⟩

/-- From internal data to the literal join. -/
theorem iso_of_joinForm {t s : ℕ} (ht : 2 ≤ t) {K : Finset V} (hJ : JoinForm G K t s)
    (hn : t ≤ Fintype.card V) (hreg : ∀ v, v ∉ K → ((G.neighborFinset v) \ K).card = s) :
    ∃ (H : SimpleGraph (Fin (Fintype.card V - t + 1))) (_ : DecidableRel H.Adj),
      H.IsRegularOfDegree s ∧ Nonempty (G ≃g graphJoin (⊤ : SimpleGraph (Fin (t - 1))) H) := by
  classical
  have hcardK : K.card = t - 1 := hJ.card_K
  have hcardC : Fintype.card {v // v ∉ K} = Fintype.card V - t + 1 := by
    rw [Fintype.card_subtype_compl, Fintype.card_coe, hcardK]
    omega
  let e₁ : K ≃ Fin (t - 1) := K.equivFinOfCardEq hcardK
  let e₂ : {v // v ∉ K} ≃ Fin (Fintype.card V - t + 1) := Fintype.equivFinOfCardEq hcardC
  let f : Fin (Fintype.card V - t + 1) → V := fun j => (e₂.symm j : V)
  have hfinj : Function.Injective f := fun i j h => e₂.symm.injective (Subtype.ext h)
  have hfK : ∀ j, f j ∉ K := fun j => (e₂.symm j).2
  let H : SimpleGraph (Fin (Fintype.card V - t + 1)) := G.comap f
  let g : Fin (t - 1) → V := fun i => (e₁.symm i : V)
  have hginj : Function.Injective g := fun i j h => e₁.symm.injective (Subtype.ext h)
  have hgK : ∀ i, g i ∈ K := fun i => (e₁.symm i).2
  let hdec : DecidableRel H.Adj := Classical.decRel _
  refine ⟨H, hdec, ?_, ?_⟩
  · intro j
    rw [← H.card_neighborFinset_eq_degree, ← hreg (f j) (hfK j)]
    have heq : (G.neighborFinset (f j)) \ K = (H.neighborFinset j).map ⟨f, hfinj⟩ := by
      ext w
      simp only [Finset.mem_sdiff, SimpleGraph.mem_neighborFinset, Finset.mem_map,
        Function.Embedding.coeFn_mk]
      constructor
      · rintro ⟨hadj, hwK⟩
        refine ⟨e₂ ⟨w, hwK⟩, ?_, ?_⟩
        · show G.Adj (f j) (f (e₂ ⟨w, hwK⟩))
          simp only [f, Equiv.symm_apply_apply]
          exact hadj
        · simp [f]
      · rintro ⟨j', hj', rfl⟩
        exact ⟨hj', hfK j'⟩
    rw [heq, Finset.card_map]
  · let ψ : Fin (t - 1) ⊕ Fin (Fintype.card V - t + 1) ≃ V :=
      (Equiv.sumCongr e₁.symm e₂.symm).trans (Equiv.sumCompl (fun v => v ∈ K))
    have hψl : ∀ i, ψ (Sum.inl i) = g i := fun i => rfl
    have hψr : ∀ j, ψ (Sum.inr j) = f j := fun j => rfl
    refine ⟨(RelIso.mk ψ ?_ : graphJoin (⊤ : SimpleGraph (Fin (t - 1))) H ≃g G).symm⟩
    rintro (i | j) (i' | j')
    · rw [hψl, hψl]
      show G.Adj (g i) (g i') ↔ (⊤ : SimpleGraph (Fin (t - 1))).Adj i i'
      rw [SimpleGraph.top_adj]
      constructor
      · intro h heq
        apply h.ne
        rw [heq]
      · intro h
        exact hJ.adj_K _ (hgK i) _ (fun heq => h (hginj heq.symm))
    · rw [hψl, hψr]
      show G.Adj (g i) (f j') ↔ True
      simp only [iff_true]
      exact hJ.adj_K _ (hgK i) _ (fun heq => hfK j' (by rw [heq]; exact hgK i))
    · rw [hψr, hψl]
      show G.Adj (f j) (g i') ↔ True
      simp only [iff_true]
      exact (hJ.adj_K _ (hgK i') _ (fun heq => hfK j (by rw [heq]; exact hgK i'))).symm
    · rw [hψr, hψr]
      rfl

end QIdx
