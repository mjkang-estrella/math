import QIdxEndpoint

open Lean Meta Elab Command

def reviewWalk (roots : Array Name) : CoreM Unit := do
  let env ← getEnv
  let mut seen : NameSet := {}
  let mut todo : Array Name := roots
  let mut nAxiom := 0
  let mut nDefn := 0
  let mut nThm := 0
  let mut nOpaque := 0
  let mut nQuot := 0
  let mut nInduct := 0
  let mut nCtor := 0
  let mut nRec := 0
  let mut axioms : Array Name := #[]
  let mut unsafes : Array Name := #[]
  let mut partials : Array Name := #[]
  let mut opaques : Array Name := #[]
  let mut implBy : Array Name := #[]
  let mut externs : Array Name := #[]
  let mut missing : Array Name := #[]
  let mut project : Array Name := #[]
  while !todo.isEmpty do
    let n := todo.back!
    todo := todo.pop
    if seen.contains n then continue
    seen := seen.insert n
    match env.find? n with
    | none => missing := missing.push n
    | some ci =>
      if ci.isUnsafe then unsafes := unsafes.push n
      if ci.isPartial then partials := partials.push n
      if (Lean.Compiler.getImplementedBy? env n).isSome then implBy := implBy.push n
      if isExtern env n then externs := externs.push n
      if (`QIdx).isPrefixOf n then project := project.push n
      let mut deps : Array Name := ci.type.getUsedConstants
      match ci with
      | .axiomInfo _ =>
        nAxiom := nAxiom + 1
        axioms := axioms.push n
      | .defnInfo v =>
        nDefn := nDefn + 1
        deps := deps ++ v.value.getUsedConstants
      | .thmInfo v =>
        nThm := nThm + 1
        deps := deps ++ v.value.getUsedConstants
      | .opaqueInfo v =>
        nOpaque := nOpaque + 1
        opaques := opaques.push n
        deps := deps ++ v.value.getUsedConstants
      | .quotInfo _ => nQuot := nQuot + 1
      | .inductInfo v =>
        nInduct := nInduct + 1
        deps := deps ++ v.ctors.toArray ++ v.all.toArray
      | .ctorInfo v =>
        nCtor := nCtor + 1
        deps := deps.push v.induct
      | .recInfo v =>
        nRec := nRec + 1
        deps := deps ++ v.all.toArray
      for d in deps do
        if !seen.contains d then todo := todo.push d
  IO.println s!"LEAN_VERSION {Lean.versionString}"
  IO.println s!"CLOSURE_TOTAL {seen.size}"
  IO.println s!"COUNTS axiom={nAxiom} defn={nDefn} thm={nThm} opaque={nOpaque} quot={nQuot} induct={nInduct} ctor={nCtor} rec={nRec}"
  IO.println s!"AXIOMS {axioms}"
  IO.println s!"UNSAFE {unsafes.size} {unsafes.toList.take 50}"
  IO.println s!"PARTIAL {partials.size} {partials.toList.take 50}"
  IO.println s!"OPAQUE {opaques.size} {opaques.toList.take 60}"
  IO.println s!"IMPLEMENTED_BY {implBy.size} {implBy.toList.take 60}"
  IO.println s!"EXTERN {externs.size} {externs.toList.take 60}"
  IO.println s!"MISSING {missing.size} {missing.toList.take 20}"
  IO.println s!"PROJECT_CONSTANTS {project.size}"

#eval reviewWalk #[``QIdx.qindex_kts_endpoint, ``QIdx.qIndex_isGreatest]
