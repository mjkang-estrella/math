import QIdxCounting
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Algebra.BigOperators.Ring.Finset

/-! # Eigenvector estimates for the structural step. -/

open SimpleGraph Finset

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj]

/-- A normalized nonnegative eigenvector of `Q`, with eigenvalue at least the order. -/
structure EigData (G : SimpleGraph V) [DecidableRel G.Adj] (x : V → ℝ) (q : ℝ) : Prop where
  nonneg : ∀ v, 0 ≤ x v
  le_one : ∀ v, x v ≤ 1
  eig : ∀ v, q * x v = G.degree v * x v + ∑ w ∈ G.neighborFinset v, x w
  large : (Fintype.card V : ℝ) ≤ q

theorem sum_nbr_le {x : V → ℝ} (h1 : ∀ v, x v ≤ 1) (L : Finset V) (v : V) {y : ℝ}
    (hy : 0 ≤ y) (hxy : ∀ w, w ∉ L → x w ≤ y) :
    ∑ w ∈ G.neighborFinset v, x w ≤ G.degree v * y + L.card := by
  have hterm : ∀ w ∈ G.neighborFinset v, x w ≤ y + (if w ∈ L then (1 : ℝ) else 0) := by
    intro w _
    split_ifs with hw
    · have := h1 w
      linarith
    · have := hxy w hw
      linarith
  calc ∑ w ∈ G.neighborFinset v, x w
      ≤ ∑ w ∈ G.neighborFinset v, (y + (if w ∈ L then (1 : ℝ) else 0)) :=
        Finset.sum_le_sum hterm
    _ = G.degree v * y + ((G.neighborFinset v).filter (· ∈ L)).card := by
        rw [Finset.sum_add_distrib, Finset.sum_const, G.card_neighborFinset_eq_degree,
          Finset.sum_boole, nsmul_eq_mul]
    _ ≤ G.degree v * y + L.card := by
        have : (((G.neighborFinset v).filter (· ∈ L)).card : ℝ) ≤ L.card := by
          exact_mod_cast Finset.card_le_card (fun w hw => (Finset.mem_filter.mp hw).2)
        linarith

variable {x : V → ℝ} {q : ℝ}

theorem low_outside_hubs (hd : EigData G x q) (L : Finset V) {l : ℝ}
    (hLcard : (L.card : ℝ) ≤ l)
    (h4 : ∀ v, v ∉ L → 4 * (G.degree v : ℝ) ≤ (Fintype.card V : ℝ))
    {v : V} (hv : v ∉ L) : (Fintype.card V : ℝ) * x v ≤ 2 * l := by
  set n : ℝ := (Fintype.card V : ℝ) with hn
  have hnn : 0 ≤ n := Nat.cast_nonneg _
  obtain ⟨v0, hv0mem, hv0⟩ := Finset.exists_max_image (Lᶜ : Finset V) x
    ⟨v, Finset.mem_compl.mpr hv⟩
  have hv0' : v0 ∉ L := Finset.mem_compl.mp hv0mem
  have hxy : ∀ w, w ∉ L → x w ≤ x v0 := fun w hw => hv0 w (Finset.mem_compl.mpr hw)
  have hy := hd.nonneg v0
  have hs := sum_nbr_le (G := G) hd.le_one L v0 hy hxy
  have he := hd.eig v0
  have hd4 := h4 v0 hv0'
  have hq := hd.large
  have h1 : n * x v0 ≤ q * x v0 := mul_le_mul_of_nonneg_right hq hy
  have h2 : (G.degree v0 : ℝ) * x v0 ≤ (n / 4) * x v0 :=
    mul_le_mul_of_nonneg_right (by linarith) hy
  have h3 : n * x v ≤ n * x v0 := mul_le_mul_of_nonneg_left (hxy v hv) hnn
  nlinarith

theorem low_outside_P (hd : EigData G x q) (L P : Finset V) {l E : ℝ}
    (hl : 0 ≤ l) (hE : 1 ≤ E)
    (hLcard : (L.card : ℝ) ≤ l)
    (h4 : ∀ v, v ∉ L → 4 * (G.degree v : ℝ) ≤ (Fintype.card V : ℝ))
    (hP : ∀ v, v ∉ P → E * (G.degree v : ℝ) + (Fintype.card V : ℝ) ≤ E * (Fintype.card V : ℝ))
    {v : V} (hv : v ∉ P) : (Fintype.card V : ℝ) * x v ≤ 3 * l * E := by
  set n : ℝ := (Fintype.card V : ℝ) with hn
  have hnn : 0 ≤ n := Nat.cast_nonneg _
  have hnpos : 0 < n := by
    have : 0 < Fintype.card V := Fintype.card_pos_iff.mpr ⟨v⟩
    rw [hn]; exact_mod_cast this
  by_cases hvL : v ∈ L
  · have hxy : ∀ w, w ∉ L → x w ≤ 2 * l / n := by
      intro w hw
      rw [le_div_iff₀ hnpos, mul_comm]
      exact low_outside_hubs hd L hLcard h4 hw
    have hs := sum_nbr_le (G := G) hd.le_one L v (by positivity) hxy
    have hdv : (G.degree v : ℝ) ≤ n := by
      have : G.degree v < Fintype.card V := G.degree_lt_card_verts v
      rw [hn]; exact_mod_cast this.le
    have hmul : (G.degree v : ℝ) * (2 * l / n) ≤ 2 * l := by
      calc (G.degree v : ℝ) * (2 * l / n) ≤ n * (2 * l / n) :=
            mul_le_mul_of_nonneg_right hdv (by positivity)
        _ = 2 * l := by field_simp
    have he := hd.eig v
    have hq := hd.large
    have hx := hd.nonneg v
    have h1 : (q - G.degree v) * x v ≤ 3 * l := by
      have : (q - G.degree v) * x v = ∑ w ∈ G.neighborFinset v, x w := by
        rw [sub_mul]; linarith
      rw [this]; linarith
    have hPv := hP v hv
    have h2 : n * x v ≤ E * ((q - G.degree v) * x v) := by
      have hk : n ≤ E * (q - G.degree v) := by nlinarith
      calc n * x v ≤ (E * (q - G.degree v)) * x v := mul_le_mul_of_nonneg_right hk hx
        _ = E * ((q - G.degree v) * x v) := by ring
    have h3 : E * ((q - G.degree v) * x v) ≤ E * (3 * l) :=
      mul_le_mul_of_nonneg_left h1 (by linarith)
    linarith
  · have h := low_outside_hubs hd L hLcard h4 hvL
    have : 2 * l ≤ 3 * l * E := by nlinarith
    linarith

omit [DecidableEq V] in
theorem sum_nbr_double (A : Finset V) (x : V → ℝ) :
    ∑ v ∈ A, ∑ w ∈ G.neighborFinset v, x w =
      ∑ w, x w * (A.filter (fun v => G.Adj v w)).card := by
  calc ∑ v ∈ A, ∑ w ∈ G.neighborFinset v, x w
      = ∑ v ∈ A, ∑ w, if G.Adj v w then x w else 0 := by
        refine Finset.sum_congr rfl (fun v _ => ?_)
        rw [G.neighborFinset_eq_filter, Finset.sum_filter]
    _ = ∑ w, ∑ v ∈ A, if G.Adj v w then x w else 0 := Finset.sum_comm
    _ = ∑ w, x w * (A.filter (fun v => G.Adj v w)).card := by
        refine Finset.sum_congr rfl (fun w _ => ?_)
        rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, mul_comm]

theorem sum_outside_P (hd : EigData G x q) (L P : Finset V) {l D C : ℝ}
    (hD : 1 ≤ D) (hCpos : 0 ≤ C)
    (hLcard : (L.card : ℝ) ≤ l)
    (hL : ∀ v, v ∉ L → D * (G.degree v : ℝ) ≤ (Fintype.card V : ℝ))
    (hC : ∀ v, v ∉ P → (Fintype.card V : ℝ) * x v ≤ C) :
    (D - 2) * (Fintype.card V : ℝ) * (∑ v ∈ Pᶜ, x v) ≤
      D * (Fintype.card V : ℝ) * (∑ v ∈ P, x v) + 2 * D * C * l := by
  set n : ℝ := (Fintype.card V : ℝ) with hn
  have hnn : 0 ≤ n := Nat.cast_nonneg _
  have hdeg : ∀ v, (G.degree v : ℝ) ≤ n := fun v => by
    have : G.degree v < Fintype.card V := G.degree_lt_card_verts v
    rw [hn]; exact_mod_cast this.le
  have h1 : ∑ v ∈ Pᶜ, (q - G.degree v) * x v = ∑ v ∈ Pᶜ, ∑ w ∈ G.neighborFinset v, x w := by
    refine Finset.sum_congr rfl (fun v _ => ?_)
    have := hd.eig v
    rw [sub_mul]; linarith
  have h2 : ∑ v ∈ Pᶜ, ∑ w ∈ G.neighborFinset v, x w ≤
      n * ∑ v ∈ P, x v + ∑ v ∈ Pᶜ, (G.degree v : ℝ) * x v := by
    rw [sum_nbr_double, ← Finset.sum_add_sum_compl P
      (fun w => x w * ((Pᶜ.filter (fun v => G.Adj v w)).card : ℝ))]
    refine add_le_add ?_ ?_
    · rw [Finset.mul_sum]
      refine Finset.sum_le_sum (fun w _ => ?_)
      have hc : (((Pᶜ.filter (fun v => G.Adj v w)).card : ℕ) : ℝ) ≤ n := by
        have : (Pᶜ.filter (fun v => G.Adj v w)).card ≤ Fintype.card V :=
          (Finset.card_le_univ _)
        rw [hn]; exact_mod_cast this
      calc x w * ((Pᶜ.filter (fun v => G.Adj v w)).card : ℝ) ≤ x w * n :=
            mul_le_mul_of_nonneg_left hc (hd.nonneg w)
        _ = n * x w := mul_comm _ _
    · refine Finset.sum_le_sum (fun w _ => ?_)
      have hc : (((Pᶜ.filter (fun v => G.Adj v w)).card : ℕ) : ℝ) ≤ G.degree w := by
        have : (Pᶜ.filter (fun v => G.Adj v w)).card ≤ G.degree w := by
          rw [← G.card_neighborFinset_eq_degree]
          refine Finset.card_le_card (fun v hv => ?_)
          rw [SimpleGraph.mem_neighborFinset]
          exact (Finset.mem_filter.mp hv).2.symm
        exact_mod_cast this
      calc x w * ((Pᶜ.filter (fun v => G.Adj v w)).card : ℝ) ≤ x w * G.degree w :=
            mul_le_mul_of_nonneg_left hc (hd.nonneg w)
        _ = (G.degree w : ℝ) * x w := mul_comm _ _
  have hterm : ∀ v ∈ Pᶜ, (D - 2) * n * x v - (if v ∈ L then 2 * D * C else 0)
      ≤ D * ((q - G.degree v) * x v - (G.degree v : ℝ) * x v) := by
    intro v hv
    have hvP : v ∉ P := Finset.mem_compl.mp hv
    have hx := hd.nonneg v
    have hqn := hd.large
    have hdv := hdeg v
    split_ifs with hvL
    · have hCn := hC v hvP
      have hnx : 0 ≤ n * x v := mul_nonneg hnn hx
      have h4 : 0 ≤ (q - 2 * G.degree v + n) * x v :=
        mul_nonneg (by linarith) hx
      have hgoal : (q - G.degree v) * x v - (G.degree v : ℝ) * x v
          = (q - 2 * G.degree v) * x v := by ring
      rw [hgoal]
      have h5 : -(n * x v) ≤ (q - 2 * G.degree v) * x v := by nlinarith
      have h6 : D * (-(n * x v)) ≤ D * ((q - 2 * G.degree v) * x v) :=
        mul_le_mul_of_nonneg_left h5 (by linarith)
      have h7 : (2 * D - 2) * (n * x v) ≤ 2 * D * C := by
        have : (2 * D - 2) * (n * x v) ≤ (2 * D) * (n * x v) := by nlinarith
        have : (2 * D) * (n * x v) ≤ 2 * D * C := mul_le_mul_of_nonneg_left hCn (by linarith)
        linarith
      nlinarith
    · have hLv := hL v hvL
      simp only [sub_zero]
      have hgoal : (q - G.degree v) * x v - (G.degree v : ℝ) * x v
          = (q - 2 * G.degree v) * x v := by ring
      rw [hgoal]
      have h8 : (D - 2) * n ≤ D * (q - 2 * G.degree v) := by nlinarith
      calc (D - 2) * n * x v ≤ (D * (q - 2 * G.degree v)) * x v :=
            mul_le_mul_of_nonneg_right h8 hx
        _ = D * ((q - 2 * G.degree v) * x v) := by ring
  have hsum := Finset.sum_le_sum hterm
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum, ← Finset.mul_sum, Finset.sum_sub_distrib] at hsum
  have hite : ∑ v ∈ Pᶜ, (if v ∈ L then 2 * D * C else 0) ≤ 2 * D * C * l := by
    rw [Finset.sum_ite, Finset.sum_const, Finset.sum_const_zero, add_zero, nsmul_eq_mul]
    have hc : (((Pᶜ.filter (· ∈ L)).card : ℕ) : ℝ) ≤ l := by
      have : (Pᶜ.filter (· ∈ L)).card ≤ L.card :=
        Finset.card_le_card (fun v hv => (Finset.mem_filter.mp hv).2)
      have hcast : (((Pᶜ.filter (· ∈ L)).card : ℕ) : ℝ) ≤ (L.card : ℝ) := by exact_mod_cast this
      linarith
    have hnonneg : 0 ≤ 2 * D * C := by positivity
    nlinarith [mul_le_mul_of_nonneg_right hc hnonneg]
  have hdiff : ∑ v ∈ Pᶜ, (q - G.degree v) * x v - ∑ v ∈ Pᶜ, (G.degree v : ℝ) * x v
      ≤ n * ∑ v ∈ P, x v := by
    linarith
  have hDmul := mul_le_mul_of_nonneg_left hdiff (by linarith : (0 : ℝ) ≤ D)
  have hfinal : (D - 2) * n * ∑ v ∈ Pᶜ, x v - 2 * D * C * l ≤ D * (n * ∑ v ∈ P, x v) := by
    calc (D - 2) * n * ∑ v ∈ Pᶜ, x v - 2 * D * C * l
        ≤ (D - 2) * n * ∑ v ∈ Pᶜ, x v - ∑ v ∈ Pᶜ, (if v ∈ L then 2 * D * C else 0) := by linarith
      _ ≤ D * (∑ v ∈ Pᶜ, (q - G.degree v) * x v - ∑ v ∈ Pᶜ, (G.degree v : ℝ) * x v) := hsum
      _ ≤ D * (n * ∑ v ∈ P, x v) := hDmul
  linarith

/-- The heavy-degree set has at most `t - 1` members. -/
theorem card_heavy_le {t s : ℕ} (ht : 1 ≤ t)
    (hcn : ∀ T : Finset V, T.card = t → (commonNbrs G T).card ≤ s)
    (hn : 2 * s < Fintype.card V) :
    (univ.filter (fun v => 2 * t * (Fintype.card V - G.degree v) ≤ Fintype.card V)).card
      ≤ t - 1 := by
  by_contra hcon
  have hle : t ≤ (univ.filter (fun v => 2 * t * (Fintype.card V - G.degree v) ≤ Fintype.card V)).card := by
    omega
  obtain ⟨T, hsub, hT⟩ := Finset.exists_subset_card_eq hle
  have hcover : (univ : Finset V) ⊆ commonNbrs G T ∪ T.biUnion (fun w => (G.neighborFinset w)ᶜ) := by
    intro v _
    by_cases hv : v ∈ commonNbrs G T
    · exact Finset.mem_union_left _ hv
    · refine Finset.mem_union_right _ ?_
      simp only [commonNbrs, Finset.mem_filter, Finset.mem_univ, true_and, not_forall] at hv
      obtain ⟨w, hw, hna⟩ := hv
      exact Finset.mem_biUnion.mpr ⟨w, hw, Finset.mem_compl.mpr (by simpa using hna)⟩
  have hcard1 : Fintype.card V ≤ (commonNbrs G T).card + ∑ w ∈ T, (Fintype.card V - G.degree w) := by
    calc Fintype.card V = (univ : Finset V).card := Finset.card_univ.symm
      _ ≤ (commonNbrs G T ∪ T.biUnion (fun w => (G.neighborFinset w)ᶜ)).card := Finset.card_le_card hcover
      _ ≤ (commonNbrs G T).card + (T.biUnion (fun w => (G.neighborFinset w)ᶜ)).card := Finset.card_union_le _ _
      _ ≤ (commonNbrs G T).card + ∑ w ∈ T, ((G.neighborFinset w)ᶜ).card := by
          exact Nat.add_le_add_left Finset.card_biUnion_le _
      _ = (commonNbrs G T).card + ∑ w ∈ T, (Fintype.card V - G.degree w) := by
          congr 1
          refine Finset.sum_congr rfl (fun w _ => ?_)
          rw [Finset.card_compl, G.card_neighborFinset_eq_degree]
  have hsum2 : t * (2 * ∑ w ∈ T, (Fintype.card V - G.degree w)) ≤ t * Fintype.card V := by
    calc t * (2 * ∑ w ∈ T, (Fintype.card V - G.degree w))
        = ∑ w ∈ T, 2 * t * (Fintype.card V - G.degree w) := by
          rw [Finset.mul_sum, Finset.mul_sum]
          refine Finset.sum_congr rfl (fun w _ => ?_)
          ring
      _ ≤ ∑ _w ∈ T, Fintype.card V := by
          refine Finset.sum_le_sum (fun w hw => ?_)
          exact (Finset.mem_filter.mp (hsub hw)).2
      _ = t * Fintype.card V := by simp [hT]
  have hle2 := Nat.le_of_mul_le_mul_left hsum2 (by omega : 0 < t)
  have hcs := hcn T hT
  omega

end QIdx
