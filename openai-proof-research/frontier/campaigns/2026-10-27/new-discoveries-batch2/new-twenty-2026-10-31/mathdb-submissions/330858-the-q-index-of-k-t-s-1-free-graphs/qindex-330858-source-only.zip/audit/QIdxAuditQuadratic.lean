import QIdxQuadratic

#print axioms QIdx.printed_facts
#print axioms QIdx.root_le
#print axioms QIdx.gap_lt
