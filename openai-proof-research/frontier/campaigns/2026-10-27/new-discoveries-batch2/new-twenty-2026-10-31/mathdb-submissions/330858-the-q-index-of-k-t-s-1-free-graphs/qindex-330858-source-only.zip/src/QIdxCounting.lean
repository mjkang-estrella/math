import QIdxStatement
import Mathlib.Combinatorics.Enumerative.DoubleCounting
import Mathlib.Data.Finset.Powerset
import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Data.Nat.Choose.Basic

/-! # Freeness gives the common-neighbour bound; the hub count. -/

open SimpleGraph Finset

namespace QIdx

variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Common neighbours of a finite vertex set. -/
def commonNbrs (T : Finset V) : Finset V := univ.filter (fun v => ∀ w ∈ T, G.Adj w v)

variable {G}

theorem common_nbrs_le_of_free {t s : ℕ}
    (hfree : (completeBipartiteGraph (Fin t) (Fin (s + 1))).Free G)
    (T : Finset V) (hT : T.card = t) : (commonNbrs G T).card ≤ s := by
  by_contra hcon
  have hle : s + 1 ≤ (commonNbrs G T).card := by omega
  obtain ⟨C, hCsub, hCcard⟩ := Finset.exists_subset_card_eq hle
  let e₁ : Fin t ≃ T := (T.equivFinOfCardEq hT).symm
  let e₂ : Fin (s + 1) ≃ C := (C.equivFinOfCardEq hCcard).symm
  let f : Fin t ⊕ Fin (s + 1) → V := Sum.elim (fun i => (e₁ i : V)) (fun j => (e₂ j : V))
  have hadj : ∀ i j, G.Adj (f (Sum.inl i)) (f (Sum.inr j)) := by
    intro i j
    have hmem : ((e₂ j : V)) ∈ commonNbrs G T := hCsub (e₂ j).2
    simp only [commonNbrs, Finset.mem_filter, Finset.mem_univ, true_and] at hmem
    exact hmem _ (e₁ i).2
  have hf : ∀ {a b}, (completeBipartiteGraph (Fin t) (Fin (s + 1))).Adj a b → G.Adj (f a) (f b) := by
    rintro (i | j) (i' | j') h
    · simp [completeBipartiteGraph] at h
    · exact hadj i j'
    · exact (hadj i' j).symm
    · simp [completeBipartiteGraph] at h
  have hinj : Function.Injective f := by
    rintro (i | j) (i' | j') h
    · simp only [f, Sum.elim_inl] at h
      exact congrArg Sum.inl (e₁.injective (Subtype.ext h))
    · exact absurd (h ▸ hadj i j') (G.loopless.irrefl _)
    · exact absurd (h ▸ hadj i' j) (G.loopless.irrefl _)
    · simp only [f, Sum.elim_inr] at h
      exact congrArg Sum.inr (e₂.injective (Subtype.ext h))
  exact hfree ⟨⟨⟨f, hf⟩, hinj⟩⟩

/-- The double count: sum of degrees over a `k`-set `L0` is at most `(t-1)n + k·s·C(k,t)`. -/
theorem sum_degree_le {t s k : ℕ} (ht : 1 ≤ t)
    (hcn : ∀ T : Finset V, T.card = t → (commonNbrs G T).card ≤ s)
    (L0 : Finset V) (hk : L0.card = k) :
    ∑ w ∈ L0, G.degree w ≤ (t - 1) * Fintype.card V + k * (s * k.choose t) := by
  classical
  let nb : V → Finset V := fun v => L0.filter (fun w => G.Adj w v)
  have hdc : ∑ w ∈ L0, G.degree w = ∑ v, (nb v).card := by
    have := Finset.sum_card_bipartiteAbove_eq_sum_card_bipartiteBelow (s := L0) (t := (univ : Finset V))
      (fun w v => G.Adj w v)
    simp only [Finset.bipartiteAbove, Finset.bipartiteBelow] at this
    rw [← this]
    refine Finset.sum_congr rfl (fun w _ => ?_)
    rw [← G.card_neighborFinset_eq_degree, G.neighborFinset_eq_filter]
  let W : Finset V := univ.filter (fun v => t ≤ (nb v).card)
  have hWbound : W.card ≤ s * k.choose t := by
    let P := L0.powersetCard t
    let r : V → Finset V → Prop := fun v T => ∀ w ∈ T, G.Adj w v
    have hsum : ∑ v ∈ W, (P.bipartiteAbove r v).card = ∑ T ∈ P, (W.bipartiteBelow r T).card :=
      Finset.sum_card_bipartiteAbove_eq_sum_card_bipartiteBelow r
    have hone : ∀ v ∈ W, 1 ≤ (P.bipartiteAbove r v).card := by
      intro v hv
      simp only [W, Finset.mem_filter, Finset.mem_univ, true_and] at hv
      obtain ⟨T, hTsub, hTcard⟩ := Finset.exists_subset_card_eq hv
      refine Finset.card_pos.mpr ⟨T, ?_⟩
      simp only [Finset.bipartiteAbove, Finset.mem_filter]
      refine ⟨Finset.mem_powersetCard.mpr ⟨hTsub.trans (Finset.filter_subset _ _), hTcard⟩, ?_⟩
      intro w hw
      exact (Finset.mem_filter.mp (hTsub hw)).2
    have hle1 : W.card ≤ ∑ v ∈ W, (P.bipartiteAbove r v).card := by
      calc W.card = ∑ _v ∈ W, 1 := by simp
        _ ≤ _ := Finset.sum_le_sum hone
    have hle2 : ∑ T ∈ P, (W.bipartiteBelow r T).card ≤ ∑ _T ∈ P, s := by
      refine Finset.sum_le_sum (fun T hT => ?_)
      have hTc : T.card = t := (Finset.mem_powersetCard.mp hT).2
      refine le_trans (Finset.card_le_card ?_) (hcn T hTc)
      intro v hv
      simp only [Finset.bipartiteBelow, Finset.mem_filter] at hv
      simp only [commonNbrs, Finset.mem_filter, Finset.mem_univ, true_and]
      exact hv.2
    have hPcard : P.card = k.choose t := by
      simp [P, Finset.card_powersetCard, hk]
    calc W.card ≤ ∑ T ∈ P, (W.bipartiteBelow r T).card := hle1.trans_eq hsum
      _ ≤ ∑ _T ∈ P, s := hle2
      _ = s * k.choose t := by simp [hPcard, Nat.mul_comm]
  have hpt : ∀ v, (nb v).card ≤ (t - 1) + (if v ∈ W then k else 0) := by
    intro v
    have hk' : (nb v).card ≤ k := hk ▸ Finset.card_filter_le _ _
    split_ifs with hv
    · omega
    · have : ¬ t ≤ (nb v).card := by simpa [W] using hv
      omega
  calc ∑ w ∈ L0, G.degree w = ∑ v, (nb v).card := hdc
    _ ≤ ∑ v, ((t - 1) + (if v ∈ W then k else 0)) := Finset.sum_le_sum (fun v _ => hpt v)
    _ = (t - 1) * Fintype.card V + W.card * k := by
        rw [Finset.sum_add_distrib, Finset.sum_const, Finset.sum_ite_mem,
          Finset.card_univ, Finset.univ_inter, Finset.sum_const, smul_eq_mul, smul_eq_mul]
        ring
    _ ≤ (t - 1) * Fintype.card V + k * (s * k.choose t) := by
        have := Nat.mul_le_mul_left k hWbound
        nlinarith

/-- Fewer than `t * D` vertices have degree at least `n / D`. -/
theorem card_hubs_lt {t s D : ℕ} (ht : 1 ≤ t) (hD : 0 < D)
    (hcn : ∀ T : Finset V, T.card = t → (commonNbrs G T).card ≤ s)
    (hn : (t * D) * (s * (t * D).choose t) < Fintype.card V) :
    (univ.filter (fun v => Fintype.card V ≤ D * G.degree v)).card < t * D := by
  by_contra hcon
  have hle : t * D ≤ (univ.filter (fun v => Fintype.card V ≤ D * G.degree v)).card := by omega
  obtain ⟨L0, hsub, hL0⟩ := Finset.exists_subset_card_eq hle
  have hsumle := sum_degree_le (k := t * D) ht hcn L0 hL0
  have hlow : t * D * Fintype.card V ≤ D * ∑ w ∈ L0, G.degree w := by
    calc t * D * Fintype.card V = ∑ _w ∈ L0, Fintype.card V := by simp [hL0]
      _ ≤ ∑ w ∈ L0, D * G.degree w := by
          refine Finset.sum_le_sum (fun w hw => ?_)
          exact (Finset.mem_filter.mp (hsub hw)).2
      _ = D * ∑ w ∈ L0, G.degree w := by rw [Finset.mul_sum]
  have hle2 : t * Fintype.card V ≤ ∑ w ∈ L0, G.degree w := by
    have : D * (t * Fintype.card V) ≤ D * ∑ w ∈ L0, G.degree w := by nlinarith
    exact Nat.le_of_mul_le_mul_left this hD
  have hkey : t * Fintype.card V ≤ (t - 1) * Fintype.card V + (t * D) * (s * (t * D).choose t) :=
    hle2.trans hsumle
  obtain ⟨u, rfl⟩ : ∃ u, t = u + 1 := ⟨t - 1, by omega⟩
  simp only [Nat.add_sub_cancel] at hkey
  have h1 : (u + 1) * Fintype.card V = u * Fintype.card V + Fintype.card V := by ring
  omega

end QIdx
