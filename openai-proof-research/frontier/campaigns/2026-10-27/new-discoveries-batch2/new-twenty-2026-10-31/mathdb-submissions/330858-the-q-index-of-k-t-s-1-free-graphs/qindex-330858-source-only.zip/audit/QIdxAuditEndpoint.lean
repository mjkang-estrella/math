import QIdxEndpoint

#print axioms QIdx.main_general
#print axioms QIdx.qindex_kts_endpoint
