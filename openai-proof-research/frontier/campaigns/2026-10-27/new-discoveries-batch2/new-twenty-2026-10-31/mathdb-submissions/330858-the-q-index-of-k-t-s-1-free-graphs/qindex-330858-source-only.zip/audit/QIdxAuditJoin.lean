import QIdxJoin

#print axioms QIdx.join_main
#print axioms QIdx.join_regular_top
#print axioms QIdx.JoinForm.nbr_eq_erase
#print axioms QIdx.JoinForm.K_subset_nbr
#print axioms QIdx.JoinForm.deg_K
#print axioms QIdx.JoinForm.deg_compl
#print axioms QIdx.JoinForm.sum_compl
#print axioms QIdx.JoinForm.card_compl_eq
