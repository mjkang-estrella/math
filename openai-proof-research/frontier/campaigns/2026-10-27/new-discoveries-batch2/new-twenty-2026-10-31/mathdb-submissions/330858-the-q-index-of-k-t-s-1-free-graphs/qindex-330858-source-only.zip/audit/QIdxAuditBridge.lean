import QIdxBridge

#print axioms QIdx.joinForm_of_universal
#print axioms QIdx.joinForm_of_iso
#print axioms QIdx.iso_of_joinForm
