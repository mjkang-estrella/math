import QIdxCounting

#print axioms QIdx.common_nbrs_le_of_free
#print axioms QIdx.sum_degree_le
#print axioms QIdx.card_hubs_lt
