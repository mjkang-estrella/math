import QIdxSpectral

#print axioms QIdx.Q_mulVec_apply
#print axioms QIdx.exists_top_eigenvector
#print axioms QIdx.top_sub_posSemidef
#print axioms QIdx.exists_nonneg_top_eigenvector
#print axioms QIdx.eigen_apply
#print axioms QIdx.eq_qIndex_of_pos_eigenvector
