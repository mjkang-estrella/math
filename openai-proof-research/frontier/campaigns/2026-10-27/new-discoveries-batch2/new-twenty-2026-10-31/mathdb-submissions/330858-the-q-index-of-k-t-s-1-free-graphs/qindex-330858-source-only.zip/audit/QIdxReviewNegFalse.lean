import QIdxReviewControls

open QIdx QIdxCtrl

/-- Deliberately false: the triangle has Q-index 4, not 5. This module must fail. -/
theorem neg_false_triangle : qIndex (⊤ : SimpleGraph (Fin 3)) = 5 := by
  rw [triangle_q]
  norm_num
