import QIdxBootstrap

#print axioms QIdx.exists_eigData
#print axioms QIdx.big_ineq
#print axioms QIdx.final_contra
#print axioms QIdx.universal_core
#print axioms QIdx.universal_of_large_q
