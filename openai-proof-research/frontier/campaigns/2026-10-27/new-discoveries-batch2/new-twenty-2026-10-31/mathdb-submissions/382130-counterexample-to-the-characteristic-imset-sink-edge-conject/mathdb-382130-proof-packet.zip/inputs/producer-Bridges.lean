import Finite
namespace ImsetSink
def parents {n} (h : Arrow n) (v : Fin n) : Finset (Fin n) :=
  Finset.univ.filter (fun u => h u v = true)
theorem parent_formula {n} (h : Arrow n) (s : Finset (Fin n)) :
    code h s = if ∃ v ∈ s, s ⊆ parents h v ∪ {v} then 1 else 0 := by
  unfold code
  congr 1
  apply propext
  constructor
  · rintro ⟨v,hv,hh⟩
    refine ⟨v,hv,?_⟩
    intro u hu
    by_cases he : u = v
    · simp [he]
    · simp [parents, hh u hu he]
  · rintro ⟨v,hv,hh⟩
    refine ⟨v,hv,?_⟩
    intro u hu he
    have hm := hh hu
    simpa [parents,he] using hm

def Acyclic {n} (h : Arrow n) : Prop := ∀ v, ¬ Relation.TransGen (fun u v => h u v = true) v v
theorem DAG.acyclic {n} (h : DAG n) : Acyclic h.arrow := by
  intro v ht
  have hr : ∀ {u v}, Relation.TransGen (fun u v => h.arrow u v = true) u v → h.rank u < h.rank v := by
    intro u v hp
    induction hp with
    | single he => exact h.forward _ _ he
    | tail hp he ih => exact lt_trans ih (h.forward _ _ he)
  exact (lt_irrefl _ (hr ht))

def R : Finset (Finset (Fin 5)) :=
 {{0,1},{0,2},{0,3},{0,4},{1,3},{1,4},{2,3},{2,4},
 {0,1,2},{0,1,3},{0,1,4},{0,2,3},{0,2,4},{1,2,4},{0,1,2,3},{0,1,2,4}}
def F : Finset (Finset (Fin 5)) := {{0,3,4},{0,1,3,4},{0,2,3,4},{0,1,2,3,4}}
def Q : Finset (Finset (Fin 5)) := {{1,2,3}}
def Z : Finset (Finset (Fin 5)) := {{1,2},{3,4},{1,3,4},{2,3,4},{1,2,3,4}}
theorem full_partition :
    (R ∪ F ∪ Q ∪ Z).card = 26 ∧
    (∀ s : Finset (Fin 5), 2 ≤ s.card ↔ s ∈ R ∪ F ∪ Q ∪ Z) ∧
    Disjoint R F ∧ Disjoint R Q ∧ Disjoint R Z ∧ Disjoint F Q ∧ Disjoint F Z ∧ Disjoint Q Z := by decide
set_option maxRecDepth 10000 in
theorem full_table : ∀ s : Finset (Fin 5), 2 ≤ s.card →
    code C s = (if s ∈ R ∪ F then 1 else 0) ∧
    code D s = (if s ∈ R ∪ Q then 1 else 0) ∧
    code A s = (if s ∈ R then 1 else 0) ∧
    code B s = (if s ∈ R ∪ F ∪ Q then 1 else 0) := by decide
#print axioms ImsetSink.parent_formula
#print axioms ImsetSink.DAG.acyclic
#print axioms ImsetSink.full_table
end ImsetSink
