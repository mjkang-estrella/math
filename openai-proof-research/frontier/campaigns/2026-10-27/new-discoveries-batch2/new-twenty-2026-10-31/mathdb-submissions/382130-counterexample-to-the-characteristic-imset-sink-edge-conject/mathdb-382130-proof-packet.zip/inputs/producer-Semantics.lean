import Finite
namespace ImsetSink
/-- A simple undirected path with k interior vertices; k<n suffices for every simple path. -/
def AdjacentPath {n} (h : Arrow n) {k : Fin n} (p : Fin (k.val+2) → Fin n) : Prop :=
  ∀ t : Fin (k.val+1), skeleton h (p ⟨t.val,by omega⟩) (p ⟨t.val+1,by omega⟩) = true

def Collider {n} (h : Arrow n) {k : Fin n} (p : Fin (k.val+2) → Fin n) (t : Fin k.val) : Prop :=
  h (p ⟨t.val,by omega⟩) (p ⟨t.val+1,by omega⟩) = true ∧
  h (p ⟨t.val+2,by omega⟩) (p ⟨t.val+1,by omega⟩) = true
instance {n} (h : Arrow n) {k : Fin n} (p : Fin (k.val+2) → Fin n) (t : Fin k.val) : Decidable (Collider h p t) := inferInstanceAs (Decidable (_ ∧ _))
instance {n} (h : Arrow n) {k : Fin n} (p : Fin (k.val+2) → Fin n) : Decidable (AdjacentPath h p) := inferInstanceAs (Decidable (∀ _t : Fin (k.val+1), _))

def Reach {n} (h : Arrow n) := Relation.ReflTransGen (fun u v => h u v = true)
def Active {n} (h : Arrow n) {k : Fin n} (p : Fin (k.val+2) → Fin n) (z : Finset (Fin n)) : Prop :=
  ∀ t : Fin k.val, if Collider h p t then ∃ v ∈ z, Reach h (p ⟨t.val+1,by omega⟩) v else p ⟨t.val+1,by omega⟩ ∉ z

def Connected {n} (h : Arrow n) (x y : Fin n) (z : Finset (Fin n)) : Prop :=
  ∃ k : Fin n, ∃ p : Fin (k.val+2) → Fin n,
    Function.Injective p ∧ p 0 = x ∧ p ⟨k.val+1,by omega⟩ = y ∧ AdjacentPath h p ∧ Active h p z

def DSeparated {n} (h : Arrow n) (x y z : Finset (Fin n)) : Prop :=
  ∀ a ∈ x, ∀ b ∈ y, ¬ Connected h a b z

def MarkovEquivalent {n} (h j : Arrow n) : Prop :=
  ∀ x y z : Finset (Fin n), Disjoint x y → Disjoint x z → Disjoint y z →
    (DSeparated h x y z ↔ DSeparated j x y z)

theorem active_empty {n} (h : Arrow n) {k : Fin n} (p : Fin (k.val+2) → Fin n) :
    Active h p ∅ ↔ ∀ t, ¬ Collider h p t := by
  simp [Active]

theorem D_noin1 : ∀ u, D u 1 = false := by decide
theorem D_noin2 : ∀ u, D u 2 = false := by decide

theorem D_collider : ∀ k : Fin 5, ∀ p : Fin (k.val+2) → Fin 5,
    Function.Injective p → p 0 = 1 → p ⟨k.val+1,by omega⟩ = 2 → AdjacentPath D p →
    ∃ t, Collider D p t := by
  intro k p _ hx hy hp
  by_contra hn
  have hnc : ∀ t, ¬ Collider D p t := by simpa only [not_exists] using hn
  have forward : ∀ t : ℕ, (ht : t ≤ k.val) →
      D (p ⟨t,by omega⟩) (p ⟨t+1,by omega⟩) = true := by
    intro t
    induction t with
    | zero =>
      intro ht
      have he := hp ⟨0,by omega⟩
      change (D (p 0) (p ⟨1,by omega⟩) || D (p ⟨1,by omega⟩) (p 0)) = true at he
      rw [hx,D_noin1] at he
      simpa [hx] using he
    | succ t ih =>
      intro ht
      have prev := ih (by omega)
      have nc := hnc ⟨t,by omega⟩
      have he := hp ⟨t+1,by omega⟩
      change (D (p ⟨t+1,by omega⟩) (p ⟨t+2,by omega⟩) || D (p ⟨t+2,by omega⟩) (p ⟨t+1,by omega⟩)) = true at he
      cases hv : D (p ⟨t+1,by omega⟩) (p ⟨t+2,by omega⟩) with
      | false =>
        simp only [hv, Bool.false_or] at he
        exact False.elim (nc ⟨prev,he⟩)
      | true => rfl
  have he := forward k.val (le_refl _)
  rw [hy,D_noin2] at he
  contradiction

theorem D_disconnected : ¬ Connected D 1 2 ∅ := by
  rintro ⟨k,p,hi,hx,hy,hp,ha⟩
  obtain ⟨t,ht⟩ := D_collider k p hi hx hy hp
  exact (active_empty D p).mp ha t ht

theorem C_connected : Connected C 1 2 ∅ := by
  refine ⟨1, ![1,3,2], ?_, ?_, ?_, ?_, ?_⟩
  · decide
  · rfl
  · rfl
  · decide
  · rw [active_empty]; decide

theorem singleton_separation {n} (h : Arrow n) (x y : Fin n) (z : Finset (Fin n)) :
    DSeparated h {x} {y} z ↔ ¬ Connected h x y z := by simp [DSeparated]
theorem witness_not_ME : ¬ MarkovEquivalent C D := by
  intro h
  have he := h {1} {2} ∅ (by decide) (by simp) (by simp)
  rw [singleton_separation, singleton_separation] at he
  exact he.mpr D_disconnected C_connected
#print axioms ImsetSink.D_collider
#print axioms ImsetSink.witness_not_ME
end ImsetSink
