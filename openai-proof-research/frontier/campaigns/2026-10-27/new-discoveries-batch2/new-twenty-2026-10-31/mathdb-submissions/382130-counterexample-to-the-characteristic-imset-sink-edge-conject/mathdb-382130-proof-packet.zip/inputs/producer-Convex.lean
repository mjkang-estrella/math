import Finite
import Mathlib.LinearAlgebra.AffineSpace.FiniteDimensional
namespace ImsetSink
/-- A convex subset with the defining face property for strict convex combinations. -/
def Face {E : Type*} [AddCommGroup E] [Module ℝ E] (P F : Set E) : Prop :=
  Convex ℝ F ∧ F ⊆ P ∧ ∀ a ∈ P, ∀ b ∈ P, ∀ t : ℝ,
    0 < t → t < 1 → (1-t) • a + t • b ∈ F → a ∈ F ∧ b ∈ F
/-- An edge is a face of affine dimension one. -/
def Edge {E : Type*} [AddCommGroup E] [Module ℝ E] (P F : Set E) : Prop :=
  Face P F ∧ Module.finrank ℝ (vectorSpan ℝ F) = 1

theorem four_point_nonface {E : Type*} [AddCommGroup E] [Module ℝ E]
    {P : Set E} {c d a b : E} (ha : a ∈ P) (hb : b ∈ P)
    (h : a + b = c + d) (hout : a ∉ segment ℝ c d) :
    ¬ Face P (segment ℝ c d) := by
  intro hf
  have hm : (1-(1/2:ℝ)) • a + (1/2:ℝ) • b ∈ segment ℝ c d := by
    have he : (1-(1/2:ℝ)) • a + (1/2:ℝ) • b = (1/2:ℝ) • c + (1/2:ℝ) • d := by
      norm_num
      rw [← smul_add, h, smul_add]
    rw [he]
    exact ⟨1/2,1/2,by norm_num,by norm_num,by norm_num,rfl⟩
  exact hout (hf.2.2 a ha b hb (1/2) (by norm_num) (by norm_num) hm).1

theorem member_C : imset C ∈ CIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨dagC,rfl,rfl⟩
theorem member_D : imset D ∈ CIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨dagD,same_skeleton.1.symm,rfl⟩
theorem member_A : imset A ∈ CIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨dagA,same_skeleton.2.1.symm,rfl⟩
theorem member_B : imset B ∈ CIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨dagB,same_skeleton.2.2.symm,rfl⟩
theorem witness_nonface : ¬ Face (CIM (skeleton C)) (segment ℝ (imset C) (imset D)) :=
  four_point_nonface member_A member_B imset_balance.symm A_outside
theorem witness_nonedge : ¬ Edge (CIM (skeleton C)) (segment ℝ (imset C) (imset D)) :=
  fun h => witness_nonface h.1
#print axioms ImsetSink.four_point_nonface
#print axioms ImsetSink.witness_nonedge
end ImsetSink
