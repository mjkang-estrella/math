import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Data.Fintype.Powerset
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Analysis.Convex.Hull
import Mathlib.Analysis.Convex.Segment

namespace ImsetSink
abbrev Arrow (n : ℕ) := Fin n → Fin n → Bool
structure DAG (n : ℕ) where
  arrow : Arrow n
  rank : Fin n → ℕ
  forward : ∀ u v, arrow u v = true → rank u < rank v

def skeleton {n} (h : Arrow n) (u v : Fin n) : Bool := h u v || h v u
def sink {n} (h : Arrow n) (i u v : Fin n) : Bool :=
  if v = i then skeleton h u v else if u = i then false else h u v

def coord (n : ℕ) := {s : Finset (Fin n) // 2 ≤ s.card}
def code {n} (h : Arrow n) (s : Finset (Fin n)) : ℕ :=
  if ∃ v ∈ s, ∀ u ∈ s, u ≠ v → h u v = true then 1 else 0
noncomputable def imset {n} (h : Arrow n) : coord n → ℝ := fun s => (code h s.val : ℝ)
noncomputable def CIM {n} (g : Arrow n) : Set (coord n → ℝ) :=
  convexHull ℝ {x | ∃ h : DAG n, skeleton h.arrow = g ∧ imset h.arrow = x}

def fromEdges (es : List (Fin 5 × Fin 5)) : Arrow 5 := fun u v => decide ((u,v) ∈ es)
def C : Arrow 5 := fromEdges [(1,0),(1,3),(1,4),(2,0),(2,4),(3,0),(3,2),(4,0)]
def D : Arrow 5 := fromEdges [(0,3),(1,0),(1,3),(1,4),(2,0),(2,3),(2,4),(4,0)]
def A : Arrow 5 := fromEdges [(0,4),(1,0),(1,4),(2,0),(2,4),(3,0),(3,1),(3,2)]
def B : Arrow 5 := fromEdges [(1,0),(1,3),(1,4),(2,0),(2,3),(2,4),(3,0),(4,0)]
def rankC : Fin 5 → ℕ := ![4,0,2,1,3]
def rankD : Fin 5 → ℕ := ![3,0,1,4,2]
def rankA : Fin 5 → ℕ := ![3,1,2,0,4]
def rankB : Fin 5 → ℕ := ![4,0,1,2,3]
def dagC : DAG 5 := ⟨C,rankC,by decide⟩
def dagD : DAG 5 := ⟨D,rankD,by decide⟩
def dagA : DAG 5 := ⟨A,rankA,by decide⟩
def dagB : DAG 5 := ⟨B,rankB,by decide⟩
theorem same_skeleton : skeleton C = skeleton D ∧ skeleton C = skeleton A ∧ skeleton C = skeleton B := by decide
theorem sink_C : sink C 3 = D := by decide

/-- Source labels are 1,...,5, transported by k ↦ k-1. -/
abbrev Label := {k : ℕ // 1 ≤ k ∧ k ≤ 5}
def labelToFin (k : Label) : Fin 5 := ⟨k.val - 1, by have hk := k.property; omega⟩
def finToLabel (k : Fin 5) : Label := ⟨k.val+1, by omega⟩
theorem labels_left (k : Label) : finToLabel (labelToFin k) = k := by
  apply Subtype.ext; have hk := k.property; dsimp [finToLabel,labelToFin]; omega
theorem labels_right (k : Fin 5) : labelToFin (finToLabel k) = k := by
  apply Fin.ext; simp [labelToFin,finToLabel]

/-- All subsets, including every zero coordinate, are checked by kernel reduction. -/
theorem code_balance : ∀ s : Finset (Fin 5), code C s + code D s = code A s + code B s := by decide

theorem imset_balance : imset C + imset D = imset A + imset B := by
  funext s
  have h := code_balance s.val
  change (code C s.val : ℝ) + code D s.val = (code A s.val : ℝ) + code B s.val
  exact_mod_cast h

noncomputable def q : coord 5 := ⟨{1,2,3}, by decide⟩
noncomputable def f : coord 5 := ⟨{0,3,4}, by decide⟩
theorem values_q : imset C q = 0 ∧ imset D q = 1 ∧ imset A q = 0 := by norm_num [imset,q,code,C,D,A,fromEdges]
theorem values_f : imset C f = 1 ∧ imset D f = 0 ∧ imset A f = 0 := by norm_num [imset,f,code,C,D,A,fromEdges]

theorem A_outside : imset A ∉ segment ℝ (imset C) (imset D) := by
  rintro ⟨a,b,ha,hb,hab,he⟩
  have hq := congrFun he q
  have hf := congrFun he f
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul] at hq hf
  rw [values_q.1, values_q.2.1, values_q.2.2] at hq
  rw [values_f.1, values_f.2.1, values_f.2.2] at hf
  norm_num at hq hf
  linarith

#print axioms ImsetSink.imset_balance
#print axioms ImsetSink.A_outside
end ImsetSink
