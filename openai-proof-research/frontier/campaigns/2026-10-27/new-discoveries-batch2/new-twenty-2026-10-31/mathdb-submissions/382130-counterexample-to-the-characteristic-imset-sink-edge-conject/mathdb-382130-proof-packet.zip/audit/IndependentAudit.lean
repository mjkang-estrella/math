import CertificateAudit
open ImsetSink
example : ¬ (∀ n : ℕ, ∀ g : Arrow n, Simple g →
  ∀ h : Arrow n, Acyclic h → skeleton h = g → ∀ i : Fin n,
  ¬ MarkovEquivalent h (sink h i) →
  Edge (SourceCIM g) (segment ℝ (imset h) (imset (sink h i)))) :=
  source_negation
example : Acyclic C ∧ Acyclic D ∧ skeleton C = skeleton D ∧ sink C 3 = D ∧
  ¬ MarkovEquivalent C D ∧
  ¬ Edge (SourceCIM (skeleton C)) (segment ℝ (imset C) (imset D)) :=
  explicit_five_counterexample
#print ImsetSink.UniversalSinkEdge
#print ImsetSink.SourceCIM
#print ImsetSink.MarkovEquivalent
#print ImsetSink.Connected
#print ImsetSink.Active
#print ImsetSink.Face
#print ImsetSink.Edge
#check ImsetSink.source_negation
#check ImsetSink.explicit_five_counterexample
#print axioms ImsetSink.source_negation
#print axioms ImsetSink.explicit_five_counterexample
#print axioms ImsetSink.source_nonface
#print axioms ImsetSink.four_point_nonface
#print axioms ImsetSink.witness_not_ME
#print axioms ImsetSink.D_collider
#print axioms ImsetSink.C_connected
#print axioms ImsetSink.full_partition
#print axioms ImsetSink.full_table
#print axioms ImsetSink.parent_formula
#print axioms ImsetSink.all_parents
#print axioms ImsetSink.all_orders
#print axioms ImsetSink.source_C_labels
#print axioms ImsetSink.source_D_labels
#print axioms ImsetSink.source_A_labels
#print axioms ImsetSink.source_B_labels
