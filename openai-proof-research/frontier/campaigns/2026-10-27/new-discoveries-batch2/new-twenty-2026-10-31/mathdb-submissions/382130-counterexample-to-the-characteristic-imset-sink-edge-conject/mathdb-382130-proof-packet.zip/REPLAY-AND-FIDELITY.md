# REPLAY-AND-FIDELITY v1
Review of MathDB 382130; 2026-11-15 UTC (2026-11-14 local).
Reviewer: GPT-6.1 Sol, high effort; no children. Sole writable lane is this directory.

## Separate verdicts
- Source statement and definition fidelity: PASS for the owned arXiv:2302.03647v2, not a journal-final attestation.
- Paper fidelity: PASS; retain inputs/PAPER-v1.md unchanged.
- Literal appendix extraction: PASS; retain inputs/LEAN-SOURCE-APPENDIX-v1.md unchanged.
- Six fresh production compiles: PASS. Six separate production kernel checks: PASS.
- Dependency, exact target type and allowed-axiom audit: PASS; independent audit additionally compiled and kernel checked.
- Process compliance: NOT an unqualified PASS. Display and screening defects below remain UNWAIVED.
No theorem, definition or proof bytes were changed. No mathematical gap was found in the reviewed endpoint. These judgments do not authorize credit or change any ledger/count. Ordinary binding, contribution, distinctness and current-registry assessments were supplied as separate PASS gates; they were not repeated here. Latest task context is 64/80 new, 103 total; older 62/80 and 101 text remains history.

## Investigation: precise target and primary evidence
The personally read owned target record is inputs/mathdb-382130.raw.jsonl, an explicitly supplied single-target statement projection with empty solutions, not a new raw corpus read. Provenance is inputs/target-record-provenance.json: hash-authenticated normalized retrieval, not live canonical verification.
Primary: Petter Restadh, Diameters of the Characteristic Imset Polytopes, https://arxiv.org/pdf/2302.03647v2, visibly dated 6 March 2023. Owned inputs/imset-v2.pdf was extracted with installed pdftotext and pages 1,2,3,11 rendered with installed pdftoppm under run.py and personally inspected. Page 1 defines the parent-set imset and the hull of all DAGs with skeleton G. Pages 2–3 give the intended conditional-independence/Markov equivalence meaning. Page 11 defines the sink operation, states Lemma 2.18, and states Conjecture 1 without tree, essential, chordal or similar restrictions. Its surrounding linear-diameter motivation is not the proposition being refuted.
The publisher-final route stays CLOSED; no request, retry, alternate final-body acquisition or final-version equivalence claim occurred. The other owned PDF was not used. No network or literature/scope/registry review was performed.

## Adversarial definition and quantifier audit
UniversalSinkEdge quantifies every natural n, every simple Boolean skeleton g, every Boolean arrow relation h with Acyclic h and skeleton h = g, and every i : Fin n. The conclusion uses real segment and Edge in SourceCIM g. The endpoint source_negation is its negation, instantiated at n=5, g=skeleton C, h=C, i=3. It is not merely the negation of a fixed-n conjecture. Degenerate n=0 or 1 cause no difficulty for this universal statement or its counterexample.
Acyclic prohibits every nonempty directed closed walk via Relation.TransGen. Thus self-loops and opposite arrows are excluded; skeleton equality then gives exactly an orientation of each skeleton edge. SourceCIM is the real convexHull of ALL such arrow relations, with no rank requirement. Rank-certified CIM is intermediate only. source_nonface supplies actual A and B to SourceCIM using DAG.acyclic. No converse rank-existence theorem or rank-hull equality is smuggled into the final endpoint.
coord n is every finite subset of Fin n of cardinality at least two. code uses existence of a vertex receiving an arrow from every other member. parent_formula proves equivalence to the actual source parent-set inclusion; source_imset_formula casts it into real coordinates. full_partition and full_table check all 26 coordinates, including zeros, rather than just pairs and triples.
skeleton is arrow-or-reverse; sink changes every incoming-to-i coordinate to skeleton, every outgoing-from-i coordinate to false, and preserves nonincident arrows. For acyclic h its diagonal is false. The exact identity sink C 3 = D and acyclicity of D are supplied, so the particular refutation needs no unproved general sink-preservation lemma.

## Genuine d-separation, not imset inequality
Connected quantifies injective adjacent undirected paths with k interior vertices. k : Fin n allows every simple path between distinct endpoints: such a path has at most n vertices, hence at most n-2 interior vertices. The extra possible upper values yield no injective paths and exclude nothing valid. At n=0/1 the disjoint-set comparison has no distinct endpoint pair. Zero-interior (one-edge) paths are included.
AdjacentPath checks every consecutive skeleton edge. Collider checks both adjacent arrows pointing into the interior vertex. Active requires each collider to have a directed descendant in z, using reflexive-transitive reachability (the collider itself therefore activates when conditioned), and requires each noncollider outside z. All interior vertices are checked; endpoints are outside z because MarkovEquivalent quantifies pairwise disjoint x,y,z. There is no collider-conditioning reversal or ancestor/descendant reversal.
DSeparated requires lack of connection for every endpoint pair in the two sets. MarkovEquivalent compares this for ALL disjoint finite vertex sets, not a selected coordinate predicate. singleton_separation proves the singleton-to-set reduction.
C_connected is the concrete open path 1→3→2 in zero-based indices (source 2→4→3). In D, vertices 1 and 2 have no incoming arrows. D_collider proves that a path starting at 1 and having no collider must orient every successive edge forward: a first forward-to-backward turn would be a collider. It cannot end at source 2. Thus every D path between the two sources has a collider; with empty conditioning no collider activates. D_disconnected and witness_not_ME finish the actual d-separation difference. This does not assume an ME/imset characterization, a finite enumeration of paths, or an external theorem as an axiom. This is the standard graph d-separation meaning of DAG conditional independences, not a formalization of arbitrary probability spaces. Source Theorems 1.2/1.4 are context rather than proof axioms.

## Four DAGs and ordinary proof
The full six local source modules were personally read, including every local definition on the endpoint dependency paths.
In source labels, the common skeleton is {12,13,14,15,24,25,34,35}. Parents in vertex order:
C=(2345,empty,4,2,23), order (2,4,3,5,1);
D=(235,empty,empty,123,23), order (2,3,5,1,4);
A=(234,4,4,empty,123), order (4,2,3,1,5);
B=(2345,empty,empty,23,23), order (2,3,4,5,1).
I checked the displayed arrow lists against these parents and orders. Every arrow points forward. The sink operation at source label 4 reverses 4→1 and 4→3 and retains 2→4; it changes no other edge. labels_left/right and all four source-label arrow theorems bind source k to Fin index k-1; source 4 is Lean 3.
The source-label coordinate families are
R={12,13,14,15,24,25,34,35,123,124,125,134,135,235,1234,1235},
F={145,1245,1345,12345}, Q={234}, Z={23,45,245,345,2345}.
Their sizes are 16,4,1,5 and they partition the 26 coordinates. The supports are R∪F,R∪Q,R,R∪F∪Q respectively. Therefore c_C+c_D=c_A+c_B. If a*c_C+b*c_D=c_A with a,b nonnegative and a+b=1, coordinate 234 forces b=0 and coordinate 145 forces a=0: contradiction. Thus c_A is outside [c_C,c_D].
Face is a convex subset of P with the strict convex-combination endpoint property, the genuine real-face definition. Edge additionally requires real finrank of vectorSpan F equal to one. vectorSpan is the span of affine differences; the ambient coordinate space is finite dimensional. In fact the obstruction proves nonface, so no dimension convention is carrying the negative result.
four_point_nonface applies coefficient 1/2 to A,B in the real hull; their midpoint equals that of C,D in the segment. The face property would force A into the segment. This contradicts A_outside and proves source_nonface, hence source_nonedge. This argument works in any real module for any P containing A,B; it does not assume exposed faces or substitute an LP test.
Consequently the exact sink pair is not ME and is not an edge in the full source hull, refuting Conjecture 1. No n=5 minimality, uniqueness, general diameter-bound refutation or stronger novelty conclusion is claimed. The paper's full proof and source/endpoint map agree with these declarations.

## Strict independent extraction
extract_independent.py was written here from scratch, not copied from the producer or executed from acquired source. It parses the appendix as untrusted bytes with the exact preamble, anchored safe allowlisted module names, lowercase 64-digit hashes, literal lean fences, matching END names, exact order, six-module coverage and no trailing malformed content. It rejects duplicate/unknown/unsafe names and embedded/missing fences. It checks UTF-8 and the source hash before returning literal module bytes. main independently binds every module to inputs/producer-NAME.lean byte-for-byte and to inputs/source-artifact-hashes-v1.json; byte equality also establishes exact byte length.
Only parsed appendix bytes were written into initially empty src through write_lane.py --base64. Producer src, build, cache and oleans were never used. Initial own src/build/cache were verified empty. All production sources stayed unchanged through their compiles/checks.
Nine in-memory negative controls reject missing module, duplicate modules, unsafe filename, extra filename, incorrect declared hash, body-byte alteration, trailing fence, wrong END name, and missing terminal fence. A tenth control recomputes a forged body's header hash: syntax parsing can accept it, but the independent producer-byte and artifact-hash binding rejects it. Production was not modified by controls.
Procedure: with empty src/build/cache, run extract_independent.py through the documented run.py runner, then the standalone check wrappers in the order below. The exact implementation, invocation receipts, independent-extraction-v1.json and extraction-controls-additional-v1.json are preserved. No paper/appendix packaging repair was needed.

## Dependency and axiom closure
Local graph:
Finite → Convex, Bridges, Semantics;
(Convex,Bridges,Semantics) → SourceNegation → CertificateAudit → IndependentAudit.
Finite's imports are specific Mathlib modules; Convex adds the specific affine finite-dimensional module. No import Mathlib umbrella, producer olean, other-project scientific olean, raw Lean/lake/repl or tactic bypass was used.
SourceNegation.source_negation depends on the actual universal definition, source_nonedge/source_nonface, four_point_nonface, imset_balance, A_outside, actual generator membership and acyclicity, sink_C and witness_not_ME. Bridges supplies the parent formula, relational acyclicity and full support table. CertificateAudit closes all four source memberships, parent lists, orders and source formula.
IndependentAudit checks expanded universal and concrete counterexample types by elaborating separate examples, prints the seven critical definitions and exact endpoint declarations, and independently prints sixteen critical transitive axiom closures. It compiles and passes leanchecker. All observed closures use only propext, Classical.choice, Quot.sound (all_orders only propext; DAG.acyclic none). All production and independent sources were screened for forbidden sorry/admit/axiom/unsafe/native_decide tokens; none occurred. Historical failed producer diagnostics mentioning sorryAx are not production proof dependencies.
Pinned binary SHA256s for lean and leanchecker both match PINS. mathlib Mathlib.lean and lake-manifest.json hashes match; lean-toolchain is leanprover/lean4:v4.34.1; read-only standard mathlib git revision metadata resolves to d13f23b723b8a846827a245b89c10fc7d3f11612. No git command was run. The actual binary hashes bind the executables; no separate version invocation was needed. Accepted pinned upstream oleans remain trusted, not independently rebuilt or individually origin-attested.

## Resource and command record
14 of 32 compile/check/query/version calls used: six production compiles, six production checks, one independent audit compile and one independent audit check; zero failures. No version/query call outside these. Every formal operation was a standalone bash ./check32.sh MODULE UNIQUE_LABEL or bash ./checker32.sh MODULE UNIQUE_LABEL. Full exact argv, source/olean before/after hashes, LEAN_PATH and resource receipts are in replayNN*.receipt.json/output.txt and formal-usage-independent-v1.json.
Formal envelope: AS32 GiB only via frozen formal wrappers; sampled real process-group RSS6 GiB guard, CPU115 seconds, wall deadline130 seconds, affinity cores 0,1, -j1 -M3500 -DwarningAsError=true, LEAN_NUM_THREADS=1. Ordinary documentary runner: AS6 GiB, sampled group RSS6 GiB, same child CPU/deadline/affinity. Runtime wrapper samples are evidence of the implemented guard, not a cgroup attestation.
Formal reaped child CPU sum 20.29155 seconds; maximum sampled group RSS 2,401,665,024 bytes; maximum individual wall 2.216 seconds. Immutable limits and actual usage remain separate. No scientific prototype, new mathematical experiment, network, search, children, installation, acquired author code, account, external message, upload, publication, shared ledger or count action.

## SELF: hostile objections and unwaived process failures
I challenged rank-hull substitution, all-coordinate coverage, wrong sink direction, index 3 versus label 4, imset inequality renamed ME, bounded paths missing valid witnesses, collider activation reversal, finite evidence substituted for universal proof, and exposed-face/dimension shortcuts. The displayed source and extracted declarations close these objections as explained above. No repaired mathematical model or proof is being passed off as unchanged.
Known inherited failures are retained in inputs/PROCESS-INVENTORY-v1.md and FORMAL-HANDOFF-v1.md: wrong-cwd read; display and unrelated restriction disclosure; incomplete prospective title/alias screening; six formal failures including an RSS kill; failed-elaboration diagnostics; and older inherited direct-write/fitz/display issues. Their receipts/full failed versions were not all supplied and are not newly certified or waived. Producer 18/48 usage is history, distinct from this lane's 14/32.
New deviations:
1. read12 printed 4,033 payload characters, above 2,400; primary05 printed 2,727, also above 2,400. The first formal Finite compilation was displayed with a stage payload above 2,400. Responses remained below 6,000; this does not waive the narrower cap. Later formal output was saved intact and displayed in bounded selected slices.
2. screening01 included unrelated arxiv host matches in display, contrary to the instruction to retain them silently. Exact-work filtering was corrected in screening02; no corresponding work body or request was made. Full diagnostics remain on disk and are not acceptance evidence.
3. The first exact-work pass preceded production source reading, but the full primary title/proper author alias pass screening03 occurred after paper01/paper02 disclosed the primary identification. This is conservatively recorded as an incomplete prospective-screening order defect for those earlier paper body reads, not cured retroactively. It preceded actual primary PDF extraction/body review. No closed route was accessed.
No automatic waiver or process-compliance acceptance is asserted.

## Read/unread inventory and HANDOFF
Personally read: TASK in full; operative research-root and two exact batch AGENTS in full; run.py/write_lane.py and both formal wrappers, formal_command.py/run_lean_32g.py, PINS/formal-budget and bootstrap/frozen interfaces; relevant authorization and ownership grants and matched work narratives; all six production modules, appendix preamble/markers and equivalent full literal bodies; full PAPER, SELF, FORMAL-HANDOFF, FORMAL-INTERFACE-PLAN, PROCESS-INVENTORY; target record/provenance; primary material listed above; independent audit output definitions/types/axioms and selected compile/check outputs.
Machine-only examination: all recursive control keys/scalars for identity screening, complete owned input hashes and formal receipts, all artifact hash equality, forbidden-token screening. This is not personal reading of unrelated restrictions or all metadata prose.
UNREAD/unused: primary PDF pages outside 1,2,3,11 except the recorded bounded text excerpts; imset-edges.pdf; full SOURCE-INVENTORY metadata (only initial slice read), independent-proof.md, legacy extracted producer audit/usage/integrity/extraction evidence bodies, ordinary parent-pass reports and supplied registry/contribution records; unrelated restrictions and origins. These are not claimed reviewed. Entire prior-history artifacts absent from this lane were not accessed or reconstructed.
Input hashes/byte sizes are exhaustively indexed in owned-input-index-v1.json. Extracted module index below binds the exact replay bytes. Reading/execution receipts preserve the exact viewed slices and commands. Source v2 URL/date above is inherited acquisition provenance, not a new retrieval. The review date is stated separately.
Retain producer paper/appendix unchanged. No actual source/math gap is outstanding in this reviewed statement. Root should use these separate semantic/replay verdicts alongside its already separate gates and the explicitly unwaived process record; this review does not make an acceptance/credit decision.
All documentary writes use write_lane.py, except the explicitly authorized frozen/bootstrap helpers' own fixed receipts. Finalization is standalone frozen-after followed by one exhaustive physical SHA256 manifest, excluding exactly that manifest and its generating receipt/stdout. Their actual receipts determine finalization success; this pre-seal report does not pretend to contain a later seal outcome. No commands or writes follow the seal.

## Exact extracted byte index

| Module | Bytes | SHA256 |
|---|---:|---|
| Finite | 3719 | 1d52b90315beb3be30f7ac3e7e9c12c084758be199a765a84370e10361ce33a4 |
| Convex | 2010 | 15f27955b00de3f681a05b05fa92c6c9b705db03327acf5a97067f1751886b0f |
| Bridges | 2095 | 0ca78f25eeddc9d19fcf45de35f5db29fc831f5319b89b83e8805a6c98448d03 |
| Semantics | 3996 | 11df907fddb744c00ec24e77d2b6e680d2893a7d1278330141b6a9213c3276af |
| SourceNegation | 2705 | 702e47e3299643bb57e2617c9b56165222a20384b5b2ec875d7e13168451045e |
| CertificateAudit | 2189 | 84a18ee27dda815eea6c08c426acf5ce415c63c690ba3b1f838d7e62bd3bff38 |

## Actual standalone formal commands

```sh
bash ./check32.sh Finite replay01-finite-compile
bash ./checker32.sh Finite replay02-finite-check
bash ./check32.sh Convex replay03-convex-compile
bash ./checker32.sh Convex replay04-convex-check
bash ./check32.sh Bridges replay05-bridges-compile
bash ./checker32.sh Bridges replay06-bridges-check
bash ./check32.sh Semantics replay07-semantics-compile
bash ./checker32.sh Semantics replay08-semantics-check
bash ./check32.sh SourceNegation replay09-source-compile
bash ./checker32.sh SourceNegation replay10-source-check
bash ./check32.sh CertificateAudit replay11-certificate-compile
bash ./checker32.sh CertificateAudit replay12-certificate-check
bash ./check32.sh IndependentAudit replay13-independent-compile
bash ./checker32.sh IndependentAudit replay14-independent-check
```

## Final documentary validation and failure record

final-validation exited 1 because the reviewer wrongly stripped the terminal LF when testing the target raw_line_sha256. validation-diagnosis established that the hash binds the exact complete file including LF. final-validation-corrected passes this exact-byte binding, verifies all six extracted sources remain unchanged, and verifies all six freshly built oleans equal the producer artifact hashes. No theorem/definition/proof/appendix repair occurred. The failed documentary command and its full receipt remain unwaived. This is not a formal call; the formal usage remains 14/32, zero formal failures. Cache remains empty. final-validation-v1.json records these results.
