import Convex
import Bridges
import Semantics
namespace ImsetSink
/-- Real convex hull of every acyclic orientation, with no rank certificate restriction. -/
noncomputable def SourceCIM {n} (g : Arrow n) : Set (coord n → ℝ) :=
  convexHull ℝ {x | ∃ h : Arrow n, Acyclic h ∧ skeleton h = g ∧ imset h = x}
def Simple {n} (g : Arrow n) : Prop :=
  (∀ u, g u u = false) ∧ (∀ u v, g u v = g v u)
/-- Literal arbitrary-n source predicate. -/
def UniversalSinkEdge : Prop := ∀ n : ℕ, ∀ g : Arrow n, Simple g →
  ∀ h : Arrow n, Acyclic h → skeleton h = g → ∀ i : Fin n,
  ¬ MarkovEquivalent h (sink h i) →
  Edge (SourceCIM g) (segment ℝ (imset h) (imset (sink h i)))

theorem source_nonface : ¬ Face (SourceCIM (skeleton C)) (segment ℝ (imset C) (imset D)) := by
  apply four_point_nonface (a := imset A) (b := imset B)
  · exact subset_convexHull ℝ _ ⟨A,dagA.acyclic,same_skeleton.2.1.symm,rfl⟩
  · exact subset_convexHull ℝ _ ⟨B,dagB.acyclic,same_skeleton.2.2.symm,rfl⟩
  · exact imset_balance.symm
  · exact A_outside

theorem source_nonedge : ¬ Edge (SourceCIM (skeleton C)) (segment ℝ (imset C) (imset D)) :=
  fun h => source_nonface h.1

theorem source_negation : ¬ UniversalSinkEdge := by
  intro h
  have hh := h 5 (skeleton C) (by unfold Simple; decide) C dagC.acyclic rfl 3
  rw [sink_C] at hh
  exact source_nonedge (hh witness_not_ME)

theorem explicit_five_counterexample :
  Acyclic C ∧ Acyclic D ∧ skeleton C = skeleton D ∧ sink C 3 = D ∧
  ¬ MarkovEquivalent C D ∧
  ¬ Edge (SourceCIM (skeleton C)) (segment ℝ (imset C) (imset D)) :=
  ⟨dagC.acyclic,dagD.acyclic,same_skeleton.1,sink_C,witness_not_ME,source_nonedge⟩

/-- Numeric source labels transported to zero-based Fin 5. -/
theorem source_C_labels : ∀ u v : Fin 5, C u v = decide
    (((finToLabel u).val,(finToLabel v).val) ∈
    ([(2,1),(2,4),(2,5),(3,1),(3,5),(4,1),(4,3),(5,1)] : List (ℕ × ℕ))) := by decide
theorem source_D_labels : ∀ u v : Fin 5, D u v = decide
    (((finToLabel u).val,(finToLabel v).val) ∈
    ([(1,4),(2,1),(2,4),(2,5),(3,1),(3,4),(3,5),(5,1)] : List (ℕ × ℕ))) := by decide
theorem source_A_labels : ∀ u v : Fin 5, A u v = decide
    (((finToLabel u).val,(finToLabel v).val) ∈
    ([(1,5),(2,1),(2,5),(3,1),(3,5),(4,1),(4,2),(4,3)] : List (ℕ × ℕ))) := by decide
theorem source_B_labels : ∀ u v : Fin 5, B u v = decide
    (((finToLabel u).val,(finToLabel v).val) ∈
    ([(2,1),(2,4),(2,5),(3,1),(3,4),(3,5),(4,1),(5,1)] : List (ℕ × ℕ))) := by decide
#print axioms ImsetSink.source_negation
#print axioms ImsetSink.explicit_five_counterexample
#print axioms ImsetSink.source_C_labels
end ImsetSink
