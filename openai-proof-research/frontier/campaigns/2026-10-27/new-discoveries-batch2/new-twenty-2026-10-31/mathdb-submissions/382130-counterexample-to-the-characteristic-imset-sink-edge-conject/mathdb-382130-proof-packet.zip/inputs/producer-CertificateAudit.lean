import SourceNegation
namespace ImsetSink
theorem source_member_C : imset C ∈ SourceCIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨C,dagC.acyclic,rfl,rfl⟩
theorem source_member_D : imset D ∈ SourceCIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨D,dagD.acyclic,same_skeleton.1.symm,rfl⟩
theorem source_member_A : imset A ∈ SourceCIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨A,dagA.acyclic,same_skeleton.2.1.symm,rfl⟩
theorem source_member_B : imset B ∈ SourceCIM (skeleton C) :=
  subset_convexHull ℝ _ ⟨B,dagB.acyclic,same_skeleton.2.2.symm,rfl⟩
theorem all_parents : ∀ v : Fin 5,
    parents C v = ![{1,2,3,4},∅,{3},{1},{1,2}] v ∧
    parents D v = ![{1,2,4},∅,∅,{0,1,2},{1,2}] v ∧
    parents A v = ![{1,2,3},{3},{3},∅,{0,1,2}] v ∧
    parents B v = ![{1,2,3,4},∅,∅,{1,2},{1,2}] v := by decide
theorem all_orders : ∀ p : Fin 5,
    rankC (![1,3,2,4,0] p) = p.val ∧ rankD (![1,2,4,0,3] p) = p.val ∧
    rankA (![3,1,2,0,4] p) = p.val ∧ rankB (![1,2,3,4,0] p) = p.val := by decide
theorem source_imset_formula {n} (h : Arrow n) (s : coord n) :
    imset h s = ((if ∃ v ∈ s.val, s.val ⊆ parents h v ∪ {v} then 1 else 0 : ℕ) : ℝ) := by
  exact congrArg (fun k : ℕ => (k : ℝ)) (parent_formula h s.val)
#print axioms ImsetSink.source_negation
#print axioms ImsetSink.explicit_five_counterexample
#print axioms ImsetSink.source_nonface
#print axioms ImsetSink.source_member_C
#print axioms ImsetSink.source_member_D
#print axioms ImsetSink.source_member_A
#print axioms ImsetSink.source_member_B
#print axioms ImsetSink.source_imset_formula
#print axioms ImsetSink.all_parents
#print axioms ImsetSink.all_orders
#print axioms ImsetSink.sink_C
#print axioms ImsetSink.same_skeleton
#print axioms ImsetSink.full_partition
#print axioms ImsetSink.full_table
#print axioms ImsetSink.active_empty
#print axioms ImsetSink.singleton_separation
#print axioms ImsetSink.witness_not_ME
#print axioms ImsetSink.labels_left
#print axioms ImsetSink.labels_right
#print axioms ImsetSink.source_C_labels
#print axioms ImsetSink.source_D_labels
#print axioms ImsetSink.source_A_labels
#print axioms ImsetSink.source_B_labels
end ImsetSink
