import re,json,hashlib,subprocess,sys
from pathlib import Path
ORDER=['Finite','Convex','Bridges','Semantics','SourceNegation','CertificateAudit']
HEADER=b'# Literal Lean source appendix v1\n\nPinned Lean 4.34.1. Modules appear in build order. No generated or omitted proof text.\n\n'
def parse(data):
 if not data.startswith(HEADER):raise ValueError('preamble')
 rest=data[len(HEADER):]; out={}
 while rest:
  match=re.match(rb'<!-- BEGIN SOURCE ([A-Za-z][A-Za-z0-9_]*).lean sha256=([0-9a-f]{64}) -->\n```lean\n',rest)
  if not match:raise ValueError('malformed header/trailing bytes')
  name=match[1].decode()
  if name not in ORDER or name in out:raise ValueError('unknown/duplicate name')
  tail=b'```\n<!-- END SOURCE '+name.encode()+b'.lean -->\n'
  start=match.end(); end=rest.find(tail,start)
  if end<0:raise ValueError('missing closing fence')
  body=rest[start:end]
  if not body.endswith(b'\n') or b'```' in body:raise ValueError('unsafe fence')
  if hashlib.sha256(body).hexdigest()!=match[2].decode():raise ValueError('hash mismatch')
  body.decode('utf-8',errors='strict');out[name]=body
  rest=rest[end+len(tail):]
  if rest.startswith(b'\n'):rest=rest[1:]
 if list(out)!=ORDER:raise ValueError('missing/order/extra modules')
 return out
def write(name,data):
 r=subprocess.run([sys.executable,'-I','-B','write_lane.py',name,'--base64'],input=__import__('base64').b64encode(data).decode(),text=True,capture_output=True);assert r.returncode==0,r.stderr
def main():
 data=Path('inputs/LEAN-SOURCE-APPENDIX-v1.md').read_bytes()
 bodies=parse(data)
 idx=json.loads(Path('inputs/source-artifact-hashes-v1.json').read_text())
 assert [x['module'] for x in idx]==ORDER
 for x in idx:
  b=bodies[x['module']]
  assert hashlib.sha256(b).hexdigest()==x['source_sha256']
  assert b==Path('inputs/producer-'+x['module']+'.lean').read_bytes()
 controls={
 'missing':data[:data.index(b'<!-- BEGIN SOURCE CertificateAudit')],
 'duplicate':data+data[len(HEADER):],
 'unsafe_name':data.replace(b'Finite.lean',b'../Finite.lean',1),
 'extra_name':data.replace(b'Finite.lean',b'Extra.lean',1),
 'bad_hash':data.replace(b'sha256=1',b'sha256=0',1),
 'body_byte':data.replace(b'namespace ImsetSink',b'namespace ImsetSunk',1),
 'trailing_fence':data+b'```\n',
 'end_name':data.replace(b'END SOURCE Finite',b'END SOURCE Convex',1),
 'missing_fence':data[:-5],
 }
 results={}
 for label,bad in controls.items():
  try:parse(bad)
  except (ValueError,UnicodeError) as e:results[label]=str(e)
  else:raise AssertionError('accepted '+label)
 assert all(not list(Path(s).glob('*')) for s in ['src','build','cache'])
 for name,b in bodies.items():write('src/'+name+'.lean',b)
 record={'appendix_sha256':hashlib.sha256(data).hexdigest(),'controls':results,'sources':[{'module':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in bodies.items()]}
 write('independent-extraction-v1.json',json.dumps(record,indent=2).encode())
 print('PASS strict extraction; six byte-identical modules; nine negative controls rejected.')
if __name__=='__main__':main()
