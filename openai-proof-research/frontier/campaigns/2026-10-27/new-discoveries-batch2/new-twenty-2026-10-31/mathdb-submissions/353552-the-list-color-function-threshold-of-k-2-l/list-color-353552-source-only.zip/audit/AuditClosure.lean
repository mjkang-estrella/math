import ListColLowerExact
import Lean

/-! Gate C (reviewer-authored): walk the transitive constant closure of the main theorems
through the environment API, reporting kinds, axioms, unsafe/partial/implemented_by/extern. -/

open Lean Meta Elab Command

namespace AuditClosure

def deps (c : ConstantInfo) : Array Name := Id.run do
  let mut out : Array Name := c.type.getUsedConstants
  match c with
  | .defnInfo v => out := out ++ v.value.getUsedConstants
  | .thmInfo v => out := out ++ v.value.getUsedConstants
  | .opaqueInfo v => out := out ++ v.value.getUsedConstants
  | .inductInfo v => out := out ++ v.ctors.toArray ++ v.all.toArray
  | .ctorInfo v => out := out.push v.induct
  | .recInfo v =>
      out := out ++ v.all.toArray
      for r in v.rules do
        out := out.push r.ctor
        out := out ++ r.rhs.getUsedConstants
  | _ => pure ()
  return out

def kindOf : ConstantInfo → String
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "def"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quot"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "ctor"
  | .recInfo _ => "recursor"

def roots : List Name :=
  [``ListCol.tau_isTheta, ``ListCol.tau_completeBipartite_isTheta, ``ListCol.countL_ge,
   ``ListCol.tau_le_kB, ``ListCol.tau_set_nonempty, ``ListCol.tau_lower, ``ListCol.tau_gt_source]

def bump (m : Std.HashMap String Nat) (k : String) : Std.HashMap String Nat :=
  m.insert k (m.getD k 0 + 1)

def run : CoreM Unit := do
  let env ← getEnv
  let mut seen : Std.HashSet Name := {}
  let mut stack : Array Name := roots.toArray
  let mut missing : Array Name := #[]
  let mut kinds : Std.HashMap String Nat := {}
  let mut axioms : Array Name := #[]
  let mut unsafes : Array Name := #[]
  let mut partials : Array Name := #[]
  let mut opaques : Array Name := #[]
  let mut implBy : Array Name := #[]
  let mut externs : Array Name := #[]
  let mut listcol : Nat := 0
  let mut sorryUse : Array Name := #[]
  let mut hiddenThm : Nat := 0
  while !stack.isEmpty do
    let n := stack.back!
    stack := stack.pop
    if seen.contains n then continue
    seen := seen.insert n
    match env.find? n with
    | none => missing := missing.push n
    | some c =>
      kinds := bump kinds (kindOf c)
      if (`ListCol).isPrefixOf n then listcol := listcol + 1
      if c.isUnsafe then unsafes := unsafes.push n
      if c.isPartial then partials := partials.push n
      match c with
      | .axiomInfo _ => axioms := axioms.push n
      | .opaqueInfo _ => opaques := opaques.push n
      | _ => pure ()
      if (Compiler.getImplementedBy? env n).isSome then implBy := implBy.push n
      if isExtern env n then externs := externs.push n
      if c.type.hasSorry then sorryUse := sorryUse.push n
      if let .thmInfo v := c then
        if v.value.isConstOf ``lcProof then hiddenThm := hiddenThm + 1
      for d in deps c do
        if !seen.contains d then stack := stack.push d
  logInfo m!"CLOSURE total={seen.size} listcol={listcol} missing={missing.size} {missing.toList.take 20}"
  logInfo m!"KINDS {kinds.toList}"
  logInfo m!"AXIOMS {axioms.toList}"
  logInfo m!"UNSAFE count={unsafes.size} {unsafes.toList.take 40}"
  logInfo m!"PARTIAL count={partials.size} {partials.toList.take 40}"
  logInfo m!"OPAQUE count={opaques.size} {opaques.toList.take 60}"
  logInfo m!"IMPLEMENTED_BY count={implBy.size} {implBy.toList.take 40}"
  logInfo m!"EXTERN count={externs.size} {externs.toList.take 40}"
  logInfo m!"TYPE_HAS_SORRY count={sorryUse.size} {sorryUse.toList.take 20}"
  logInfo m!"THM_VALUE_lcProof count={hiddenThm}"

end AuditClosure

#eval AuditClosure.run
