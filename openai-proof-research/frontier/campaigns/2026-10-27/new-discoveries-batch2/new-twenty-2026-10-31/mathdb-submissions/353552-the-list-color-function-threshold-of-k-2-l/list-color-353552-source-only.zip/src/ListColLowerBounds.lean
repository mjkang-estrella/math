import ListColLowerCount
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# Weight bounds for the balanced assignment, and the crude numerical estimates
-/

open scoped Classical
open Finset

namespace ListCol

variable {c l : ℕ}

lemma bad_low (c : ℕ) {l : ℕ} (j : Fin l) {a : ℕ} (ha : a < c) : a ∈ badS c j :=
  (mem_badS c j a).2 (Or.inr (Or.inr ha))

lemma mem_spec_A (c : ℕ) {l : ℕ} (j : Fin l) {α : ℕ} (hα : α < 2) :
    c + α ∈ badS c j ↔ j.val % 2 = α := by
  rw [mem_badS]
  omega

lemma mem_spec_B (c : ℕ) {l : ℕ} (j : Fin l) {β : ℕ} (hβ : β < 2) :
    c + 2 + β ∈ badS c j ↔ j.val / 2 % 2 = β := by
  rw [mem_badS]
  omega

lemma jointMiss_left_low {a : ℕ} (ha : a < c) (b : ℕ) :
    jointMiss (badS c : Fin l → Finset ℕ) a b = 0 := by
  unfold jointMiss
  rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
  intro j _ h
  exact h.1 (bad_low c j ha)

lemma jointMiss_right_low (a : ℕ) {b : ℕ} (hb : b < c) :
    jointMiss (badS c : Fin l → Finset ℕ) a b = 0 := by
  unfold jointMiss
  rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
  intro j _ h
  exact h.2 (bad_low c j hb)

section weights

variable {t : ℝ}

lemma s_le_one (ht : 3 ≤ t) : 1 - 1 / t ≤ 1 := by
  have := aPos ht
  linarith

lemma one_le_q (ht : 3 ≤ t) : 1 ≤ 1 + 1 / t := by
  have := aPos ht
  linarith

/-- Two low colours: the weight is exactly `y`. -/
lemma W_low_low (ht : 3 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {a b : ℕ} (ha : a < c) (hb : b < c)
    (hab : a ≠ b) : W t (badS c : Fin l → Finset ℕ) a b = (1 - 1 / t) ^ l := by
  rw [W_off_eq ht (fun j => card_badS c j) hmt hab, jointMiss_left_low ha b]
  have h : jointIn (badS c : Fin l → Finset ℕ) a b = l := by
    unfold jointIn
    rw [Finset.filter_true_of_mem (fun j _ => ⟨bad_low c j ha, bad_low c j hb⟩), Finset.card_univ,
      Fintype.card_fin]
  rw [h, pow_zero, mul_one]

/-- A low colour paired with a special colour of `B`. -/
lemma W_low_specB (ht : 3 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {a : ℕ} (ha : a < c) {β : ℕ}
    (hβ : β < 2) :
    W t (badS c : Fin l → Finset ℕ) a (c + 2 + β) ≤ (1 - 1 / t) ^ (2 * (l / 4)) := by
  have hab : a ≠ c + 2 + β := by omega
  rw [W_off_eq ht (fun j => card_badS c j) hmt hab, jointMiss_left_low ha _, pow_zero, mul_one]
  apply pow_le_pow_of_le_one (sPos ht).le (s_le_one ht)
  unfold jointIn
  apply two_res_le (r1 := 2 * β) (r2 := 2 * β + 1) _ (by omega) (by omega) (by omega)
  intro j hj
  exact ⟨bad_low c j ha, (mem_spec_B c j hβ).2 (by omega)⟩

/-- A special colour of `A` paired with a low colour. -/
lemma W_specA_low (ht : 3 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {α : ℕ} (hα : α < 2) {b : ℕ}
    (hb : b < c) :
    W t (badS c : Fin l → Finset ℕ) (c + α) b ≤ (1 - 1 / t) ^ (2 * (l / 4)) := by
  have hab : c + α ≠ b := by omega
  rw [W_off_eq ht (fun j => card_badS c j) hmt hab, jointMiss_right_low _ hb, pow_zero, mul_one]
  apply pow_le_pow_of_le_one (sPos ht).le (s_le_one ht)
  unfold jointIn
  apply two_res_le (r1 := α) (r2 := α + 2) _ (by omega) (by omega) (by omega)
  intro j hj
  exact ⟨(mem_spec_A c j hα).2 (by omega), bad_low c j hb⟩

/-- Two special colours. -/
lemma W_spec_spec (ht : 3 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {α β : ℕ} (hα : α < 2)
    (hβ : β < 2) :
    W t (badS c : Fin l → Finset ℕ) (c + α) (c + 2 + β)
      ≤ (1 - 1 / t) ^ (l / 4) * (1 + 1 / t) ^ (l / 4 + 1) := by
  have hab : c + α ≠ c + 2 + β := by omega
  rw [W_off_eq ht (fun j => card_badS c j) hmt hab]
  have hin : l / 4 ≤ jointIn (badS c : Fin l → Finset ℕ) (c + α) (c + 2 + β) := by
    refine (resC_ge l (α + 2 * β) (by omega)).trans ?_
    unfold resC jointIn
    apply Finset.card_le_card
    intro j hj
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj ⊢
    exact ⟨(mem_spec_A c j hα).2 (by omega), (mem_spec_B c j hβ).2 (by omega)⟩
  have hmiss : jointMiss (badS c : Fin l → Finset ℕ) (c + α) (c + 2 + β) ≤ l / 4 + 1 := by
    refine le_trans ?_ (resC_le l (1 - α + 2 * (1 - β)) (by omega))
    unfold resC jointMiss
    apply Finset.card_le_card
    intro j hj
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj ⊢
    have h1 := hj.1
    have h2 := hj.2
    rw [mem_spec_A c j hα] at h1
    rw [mem_spec_B c j hβ] at h2
    omega
  have hs := sPos ht
  have hq := qPos ht
  exact mul_le_mul (pow_le_pow_of_le_one hs.le (s_le_one ht) hin)
    (pow_le_pow_right₀ (one_le_q ht) hmiss) (pow_nonneg hq.le _) (pow_nonneg hs.le _)

/-- The crude numerical estimate for the balanced assignment. -/
lemma bad_numeric (ht : 3 ≤ t) {T : ℕ} (hT : 4 * t ^ 2 ≤ T) {x : ℝ} (hx0 : 0 ≤ x) (hxt : x ≤ t) :
    4 * x * (1 - 1 / t) ^ (2 * T) + 4 * ((1 - 1 / t) ^ T * (1 + 1 / t) ^ (T + 1))
      ≤ 1 / 2 + 16 / 15 := by
  have htpos : 0 < t := by linarith
  have ha0 := aPos ht
  have ha1 := aLe ht
  have hs := sPos ht
  have hq := qPos ht
  have ht1 : t * (1 / t) = 1 := by field_simp
  -- first summand
  have hsle : 1 - 1 / t ≤ Real.exp (-(1 / t)) := Real.one_sub_le_exp_neg _
  have hE1 : (1 - 1 / t) ^ (2 * T) ≤ Real.exp (-(1 / t)) ^ (2 * T) :=
    pow_le_pow_left₀ hs.le hsle _
  obtain ⟨X, hX⟩ : ∃ X : ℝ, X = ((2 * T : ℕ) : ℝ) * (1 / t) := ⟨_, rfl⟩
  have hEeq : Real.exp (-(1 / t)) ^ (2 * T) = Real.exp (-X) := by
    rw [hX, ← Real.exp_nat_mul]
    congr 1
    ring
  rw [hEeq] at hE1
  have hE0 : 0 < Real.exp (-X) := Real.exp_pos _
  have hX8 : 8 * t ≤ X := by
    rw [hX]
    push_cast
    have h1 : 8 * t ^ 2 ≤ 2 * (T : ℝ) := by linarith
    have h2 : 8 * t ^ 2 * (1 / t) ≤ 2 * (T : ℝ) * (1 / t) :=
      mul_le_mul_of_nonneg_right h1 ha0.le
    have h3 : 8 * t ^ 2 * (1 / t) = 8 * t := by
      field_simp
    linarith
  have hcancel : Real.exp (-X) * Real.exp X = 1 := by
    rw [← Real.exp_add]
    simp
  have hexp8 : 8 * t ≤ Real.exp X := by linarith [Real.add_one_le_exp X]
  have hE8 : Real.exp (-X) * (8 * t) ≤ 1 := by
    calc Real.exp (-X) * (8 * t) ≤ Real.exp (-X) * Real.exp X :=
          mul_le_mul_of_nonneg_left hexp8 hE0.le
      _ = 1 := hcancel
  have hpart1 : 4 * x * (1 - 1 / t) ^ (2 * T) ≤ 1 / 2 := by
    have h1 : 4 * x * (1 - 1 / t) ^ (2 * T) ≤ 4 * x * Real.exp (-X) :=
      mul_le_mul_of_nonneg_left hE1 (by linarith)
    have h2 : 4 * x * Real.exp (-X) ≤ 4 * t * Real.exp (-X) :=
      mul_le_mul_of_nonneg_right (by linarith) hE0.le
    have h3 : 4 * t * Real.exp (-X) = Real.exp (-X) * (8 * t) / 2 := by ring
    linarith
  -- second summand
  have hkap : (1 - 1 / t) ^ T * (1 + 1 / t) ^ (T + 1)
      = ((1 - 1 / t) * (1 + 1 / t)) ^ T * (1 + 1 / t) := by
    rw [pow_succ, mul_pow]
    ring
  obtain ⟨a, ha⟩ : ∃ a : ℝ, a = 1 / t := ⟨_, rfl⟩
  have hkap2 : (1 - 1 / t) * (1 + 1 / t) = 1 - a ^ 2 := by
    rw [ha]
    ring
  have hk0 : 0 ≤ 1 - a ^ 2 := by
    rw [← hkap2]
    positivity
  have hkle : 1 - a ^ 2 ≤ Real.exp (-(a ^ 2)) := Real.one_sub_le_exp_neg _
  have hk1 : (1 - a ^ 2) ^ T ≤ Real.exp (-(a ^ 2)) ^ T := pow_le_pow_left₀ hk0 hkle _
  obtain ⟨Y, hY⟩ : ∃ Y : ℝ, Y = (T : ℝ) * a ^ 2 := ⟨_, rfl⟩
  have hkeq : Real.exp (-(a ^ 2)) ^ T = Real.exp (-Y) := by
    rw [hY, ← Real.exp_nat_mul]
    congr 1
    ring
  rw [hkeq] at hk1
  have hY4 : 4 ≤ Y := by
    rw [hY, ha]
    have h1 : 4 * t ^ 2 * (1 / t) ^ 2 ≤ (T : ℝ) * (1 / t) ^ 2 :=
      mul_le_mul_of_nonneg_right hT (by positivity)
    have h2 : 4 * t ^ 2 * (1 / t) ^ 2 = 4 := by
      field_simp
    linarith
  have hexp4 : Real.exp (-Y) ≤ 1 / 5 := by
    have h5 : (5 : ℝ) ≤ Real.exp Y := by linarith [Real.add_one_le_exp Y]
    have hc : Real.exp (-Y) * Real.exp Y = 1 := by
      rw [← Real.exp_add]
      simp
    have hp : 0 < Real.exp (-Y) := Real.exp_pos _
    have h : Real.exp (-Y) * 5 ≤ 1 := by
      calc Real.exp (-Y) * 5 ≤ Real.exp (-Y) * Real.exp Y := mul_le_mul_of_nonneg_left h5 hp.le
        _ = 1 := hc
    linarith
  have hq43 : 1 + 1 / t ≤ 4 / 3 := by linarith
  have hkpow0 : 0 ≤ (1 - a ^ 2) ^ T := pow_nonneg hk0 _
  have hpart2 : (1 - 1 / t) ^ T * (1 + 1 / t) ^ (T + 1) ≤ 1 / 5 * (4 / 3) := by
    rw [hkap, hkap2]
    exact mul_le_mul (hk1.trans hexp4) hq43 hq.le (by norm_num)
  linarith

end weights

end ListCol
