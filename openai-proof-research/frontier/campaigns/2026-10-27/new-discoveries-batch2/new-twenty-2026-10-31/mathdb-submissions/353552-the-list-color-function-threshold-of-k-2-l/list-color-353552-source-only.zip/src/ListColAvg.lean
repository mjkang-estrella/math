import Mathlib.Analysis.Complex.Exponential
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The per-list inequality and the exponential AM-GM step
-/

open Finset

namespace ListCol

/-- Pointwise bound for one list, with `x = α/k`, `y = β/k`, `z = min 1 (δ/k)`. -/
lemma perList {L M x y z : ℝ} (hM : 0 ≤ M) (hML : M ≤ L)
    (hx0 : 0 ≤ x) (hx1 : x ≤ 1) (hy0 : 0 ≤ y) (hy1 : y ≤ 1) (hz0 : 0 ≤ z)
    (h : 1 ≤ x + y + z) :
    -z * L - (1 - z) * (L - M) / 4 ≤ x * y * M - (1 - x) * (1 - y) * L := by
  have hw0 : 0 ≤ x + y := by linarith
  have hw2 : x + y ≤ 2 := by linarith
  have hww : 0 ≤ (x + y) - (1 - z) := by linarith
  have hkey : 0 ≤ 4 * (x + y) - (x + y) ^ 2 - 3 * (1 - z) := by
    by_cases h1 : x + y ≤ 1
    · have := mul_nonneg hw0 (sub_nonneg.mpr h1)
      nlinarith only [this, hww]
    · have h2 : 1 < x + y := not_le.mp h1
      have := mul_nonneg (sub_nonneg.mpr h2.le) (by linarith : 0 ≤ 3 - (x + y))
      nlinarith only [this, hz0, h2]
  have hN : 0 ≤ L - M := sub_nonneg.mpr hML
  have e : x * y * M - (1 - x) * (1 - y) * L - (-z * L - (1 - z) * (L - M) / 4)
      = (L - M) * (4 * (x + y) - (x + y) ^ 2 - 3 * (1 - z)) / 4
        + ((x + y) - (1 - z)) * M + (L - M) * (x - y) ^ 2 / 4 := by
    ring
  have h1 : 0 ≤ (L - M) * (4 * (x + y) - (x + y) ^ 2 - 3 * (1 - z)) / 4 :=
    div_nonneg (mul_nonneg hN hkey) (by norm_num)
  have h2 : 0 ≤ ((x + y) - (1 - z)) * M := mul_nonneg hww hM
  have h3 : 0 ≤ (L - M) * (x - y) ^ 2 / 4 :=
    div_nonneg (mul_nonneg hN (sq_nonneg _)) (by norm_num)
  linarith

/-- AM-GM in exponential form, proved from the tangent line of `exp`. -/
lemma exp_avg {ι : Type*} (I : Finset ι) (hI : I.Nonempty) (f : ι → ℝ) :
    (I.card : ℝ) * Real.exp ((∑ i ∈ I, f i) / (I.card : ℝ)) ≤ ∑ i ∈ I, Real.exp (f i) := by
  have hc : (0 : ℝ) < I.card := by exact_mod_cast Finset.card_pos.mpr hI
  obtain ⟨c, hcdef⟩ : ∃ c : ℝ, c = (∑ i ∈ I, f i) / (I.card : ℝ) := ⟨_, rfl⟩
  rw [← hcdef]
  have hstep : ∀ i ∈ I, Real.exp c * (1 + (f i - c)) ≤ Real.exp (f i) := by
    intro i _
    have h1 : 1 + (f i - c) ≤ Real.exp (f i - c) := by linarith [Real.add_one_le_exp (f i - c)]
    have h2 : Real.exp c * (1 + (f i - c)) ≤ Real.exp c * Real.exp (f i - c) :=
      mul_le_mul_of_nonneg_left h1 (Real.exp_pos c).le
    have h3 : Real.exp c * Real.exp (f i - c) = Real.exp (f i) := by
      rw [← Real.exp_add]
      congr 1
      ring
    rw [h3] at h2
    exact h2
  have hsum : (∑ i ∈ I, Real.exp c * (1 + (f i - c))) = (I.card : ℝ) * Real.exp c := by
    have e1 : ∀ i ∈ I, Real.exp c * (1 + (f i - c))
        = Real.exp c * (1 - c) + Real.exp c * f i := by
      intro i _
      ring
    rw [Finset.sum_congr rfl e1, Finset.sum_add_distrib, Finset.sum_const, nsmul_eq_mul,
      ← Finset.mul_sum]
    have e2 : ∑ i ∈ I, f i = (I.card : ℝ) * c := by
      rw [hcdef]
      field_simp
    rw [e2]
    ring
  rw [← hsum]
  exact Finset.sum_le_sum hstep

/-- The double sum of a difference of products. -/
lemma double_sum_prod (A' B' : Finset ℕ) (F G F' G' : ℕ → ℝ) (M L : ℝ) :
    (∑ a ∈ A', ∑ b ∈ B', (F a * G b * M - F' a * G' b * L))
      = (∑ a ∈ A', F a) * (∑ b ∈ B', G b) * M
        - (∑ a ∈ A', F' a) * (∑ b ∈ B', G' b) * L := by
  rw [Finset.sum_mul_sum, Finset.sum_mul_sum, Finset.sum_mul, Finset.sum_mul,
    ← Finset.sum_sub_distrib]
  refine Finset.sum_congr rfl (fun a _ => ?_)
  rw [Finset.sum_mul, Finset.sum_mul, ← Finset.sum_sub_distrib]

end ListCol
