import ListColMain
import Mathlib.Data.Nat.Cast.Order.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.IntervalCases
import Mathlib.Tactic.NormNum

/-!
# The fully shared case (`p = 0`): equality with `P(K_{2,l}, m)`

If the colour lists of the two vertices of the small side coincide (`A = B`) then the
lists of the large side are forced to be all of `A`, and the number of proper list
colourings is *exactly* `P(K_{2,l}, m) = m (m-1)^l + m (m-1) (m-2)^l`.
-/

open scoped Classical
open Finset

namespace ListCol

theorem count_K_eq_p0 (m l : Nat) (hm : 4 ≤ m) (A B : Finset Nat) (S : Fin l → Finset Nat)
    (hA : A.card = m) (hB : B.card = m) (hS : ∀ j, (S j).card = m)
    (hsub : ∀ j, S j ⊆ A ∪ B) (hU : (A ∪ B).card = m) :
    ((∑ a ∈ A, ∑ b ∈ B, ∏ j : Fin l, (((S j).erase a).erase b).card : Nat) : Real)
      = (m:Real) * ((m:Real) - 1) ^ l
        + (m:Real) * ((m:Real) - 1) * ((m:Real) - 2) ^ l := by
  have hU1 : A ∪ B = A :=
    (Finset.eq_of_subset_of_card_le Finset.subset_union_left (by rw [hU, hA])).symm
  have hBA : B = A :=
    Finset.eq_of_subset_of_card_le (by rw [← hU1]; exact Finset.subset_union_right)
      (by rw [hA, hB])
  have hSA : ∀ j : Fin l, S j = A := by
    intro j
    exact Finset.eq_of_subset_of_card_le (by rw [← hU1]; exact hsub j) (by rw [hA, hS j])
  have hmem : ∀ j : Fin l, ∀ x ∈ A, x ∈ S j := by
    intro j x hx
    rw [hSA j]
    exact hx
  have hcast1 : ((m - 1 : Nat) : Real) = (m:Real) - 1 := by
    rw [Nat.cast_sub (by omega : 1 ≤ m)]
    norm_num
  have hcast2 : ((m - 2 : Nat) : Real) = (m:Real) - 2 := by
    rw [Nat.cast_sub (by omega : 2 ≤ m)]
    norm_num
  have hterm : ∀ a ∈ A, ∀ b ∈ A,
      ((∏ j : Fin l, (((S j).erase a).erase b).card : Nat) : Real)
        = if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l := by
    intro a ha b hb
    by_cases hab : a = b
    · have hfac : ∀ j : Fin l, (((S j).erase a).erase b).card = m - 1 := by
        intro j
        subst hab
        have he : ((S j).erase a).erase a = (S j).erase a :=
          (Finset.erase_eq_self).mpr (Finset.notMem_erase a (S j))
        rw [he, Finset.card_erase_of_mem (hmem j a ha), hS j]
      have hif : (if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l)
          = ((m:Real) - 1) ^ l := by simp [hab]
      rw [hif, Nat.cast_prod]
      have hterm1 : ∀ j : Fin l, ((((S j).erase a).erase b).card : Real) = (m:Real) - 1 := by
        intro j
        rw [hfac j, hcast1]
      rw [Finset.prod_congr rfl (fun j _ => hterm1 j), Finset.prod_const, Finset.card_univ,
        Fintype.card_fin]
    · have hfac : ∀ j : Fin l, (((S j).erase a).erase b).card = m - 2 := by
        intro j
        have h := card_erase_erase_add (S j) a b hab
        rw [hS j] at h
        have hua : u (S j) a = 0 := by simp [u, hmem j a ha]
        have hub : u (S j) b = 0 := by simp [u, hmem j b hb]
        rw [hua, hub] at h
        omega
      have hif : (if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l)
          = ((m:Real) - 2) ^ l := by simp [hab]
      rw [hif, Nat.cast_prod]
      have hterm2 : ∀ j : Fin l, ((((S j).erase a).erase b).card : Real) = (m:Real) - 2 := by
        intro j
        rw [hfac j, hcast2]
      rw [Finset.prod_congr rfl (fun j _ => hterm2 j), Finset.prod_const, Finset.card_univ,
        Fintype.card_fin]
  have hcast : ((∑ a ∈ A, ∑ b ∈ B, ∏ j : Fin l, (((S j).erase a).erase b).card : Nat) : Real)
      = ∑ a ∈ A, ∑ b ∈ B, ((∏ j : Fin l, (((S j).erase a).erase b).card : Nat) : Real) := by
    rw [Nat.cast_sum]
    refine Finset.sum_congr rfl (fun a _ => ?_)
    rw [Nat.cast_sum]
  rw [hcast, hBA]
  have hstep : (∑ a ∈ A, ∑ b ∈ A,
      ((∏ j : Fin l, (((S j).erase a).erase b).card : Nat) : Real))
      = ∑ a ∈ A, ∑ b ∈ A, (if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l) :=
    Finset.sum_congr rfl (fun a ha => Finset.sum_congr rfl (fun b hb => hterm a ha b hb))
  rw [hstep]
  have hinner : ∀ a ∈ A,
      (∑ b ∈ A, (if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l))
        = (m:Real) * ((m:Real) - 2) ^ l
            + (((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l) := by
    intro a ha
    have hcongr : ∀ b, (if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l)
        = ((m:Real) - 2) ^ l
            + (if a = b then ((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l else 0) := by
      intro b
      by_cases h : a = b
      · simp [h]
      · simp [h]
    calc (∑ b ∈ A, (if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l))
        = ∑ b ∈ A, (((m:Real) - 2) ^ l
            + (if a = b then ((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l else 0)) :=
          Finset.sum_congr rfl (fun b _ => hcongr b)
      _ = (∑ b ∈ A, ((m:Real) - 2) ^ l)
            + ∑ b ∈ A, (if a = b then ((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l else 0) :=
          Finset.sum_add_distrib
      _ = (m:Real) * ((m:Real) - 2) ^ l
            + (((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l) := by
          have hsingle : (∑ b ∈ A,
              (if a = b then ((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l else 0))
              = ((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l := by
            have h := Finset.sum_eq_single (s := A)
              (f := fun b => if a = b then ((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l else 0) a
              (fun b _ hba => by simp [show ¬ (a = b) from fun hh => hba hh.symm])
              (fun ha' => absurd ha ha')
            rw [h]
            simp
          rw [hsingle, Finset.sum_const, hA, nsmul_eq_mul]
  calc (∑ a ∈ A, ∑ b ∈ A, (if a = b then ((m:Real) - 1) ^ l else ((m:Real) - 2) ^ l))
      = ∑ a ∈ A, ((m:Real) * ((m:Real) - 2) ^ l
          + (((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l)) :=
        Finset.sum_congr rfl (fun a ha => hinner a ha)
    _ = (m:Real) * ((m:Real) * ((m:Real) - 2) ^ l
          + (((m:Real) - 1) ^ l - ((m:Real) - 2) ^ l)) := by
        rw [Finset.sum_const, hA, nsmul_eq_mul]
    _ = (m:Real) * ((m:Real) - 1) ^ l
          + (m:Real) * ((m:Real) - 1) * ((m:Real) - 2) ^ l := by ring

end ListCol
