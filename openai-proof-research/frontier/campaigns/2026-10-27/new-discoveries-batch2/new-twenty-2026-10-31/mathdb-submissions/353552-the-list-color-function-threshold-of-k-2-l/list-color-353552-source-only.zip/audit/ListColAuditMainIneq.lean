import ListColMainIneq

#print axioms ListCol.main_real
#print axioms ListCol.poly_real
#print axioms ListCol.count_real
#print axioms ListCol.countL_ge
#print axioms ListCol.chromaticPolynomial_le_countL
#print axioms ListCol.listColorFunction_eq
