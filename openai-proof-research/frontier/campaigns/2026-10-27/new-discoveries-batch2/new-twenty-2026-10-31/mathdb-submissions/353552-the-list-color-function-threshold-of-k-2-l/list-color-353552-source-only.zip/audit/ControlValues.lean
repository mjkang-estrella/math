import ListColEndpoint
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Sum
import Mathlib.Data.Fin.VecNotation
import Mathlib.Tactic.FinCases

/-! Gate E (reviewer-authored): concrete semantic controls. Hand values:
`P(K_{2,2},2)=2`, `P(K_{2,2},3)=18`, `P(K_{2,3},3)=30`, `P(K_{2,4},2)=2`. -/

namespace ReviewerControls
open ListCol

section Brute

/-- An adjacency for `K_{2,l}` written independently of mathlib and of the packet. -/
def adj' {l : ℕ} : Fin 2 ⊕ Fin l → Fin 2 ⊕ Fin l → Bool
  | Sum.inl _, Sum.inr _ => true
  | Sum.inr _, Sum.inl _ => true
  | _, _ => false

abbrev bruteP (l m : ℕ) (f : Fin 2 ⊕ Fin l → Fin m) : Prop :=
  ∀ u v, adj' u v = true → f u ≠ f v

/-- Brute-force count of proper colourings of `K_{2,l}` with colours `Fin m`. -/
def brute (l m : ℕ) : ℕ := (Finset.univ.filter (bruteP l m)).card

theorem brute_2_2 : brute 2 2 = 2 := by decide +kernel
theorem brute_2_3 : brute 2 3 = 18 := by decide +kernel
theorem brute_3_3 : brute 3 3 = 30 := by decide +kernel
theorem brute_4_2 : brute 4 2 = 2 := by decide +kernel

end Brute

theorem K_adj_iff (l : ℕ) (u v : Fin 2 ⊕ Fin l) : (K l).Adj u v ↔ adj' u v = true := by
  rcases u with i | j <;> rcases v with i' | j' <;> simp [adj', K, completeBipartiteGraph]

open scoped Classical

noncomputable def bruteEquiv (l m : ℕ) :
    ListColorings (K l) (fun _ => Finset.range m) ≃ {f : Fin 2 ⊕ Fin l → Fin m // bruteP l m f} where
  toFun f := ⟨fun v => ⟨(f.1 v).val, Finset.mem_range.mp (f.1 v).2⟩, fun u v huv heq =>
    f.2 u v ((K_adj_iff l u v).mpr huv) (congrArg Fin.val heq)⟩
  invFun f := ⟨fun v => ⟨(f.1 v).val, Finset.mem_range.mpr (f.1 v).isLt⟩,
    fun u v huv heq => f.2 u v ((K_adj_iff l u v).mp huv) (Fin.ext heq)⟩
  left_inv f := by
    apply Subtype.ext
    funext v
    apply Subtype.ext
    rfl
  right_inv f := by
    apply Subtype.ext
    funext v
    apply Fin.ext
    rfl

theorem cp_eq_brute (l m : ℕ) : chromaticPolynomial (K l) m = brute l m := by
  unfold chromaticPolynomial countL brute
  rw [← Fintype.card_subtype]
  exact Fintype.card_congr (bruteEquiv l m)

/-- Each value is obtained both from the brute count and from the packet's closed form. -/
theorem cp_K2_2 : chromaticPolynomial (K 2) 2 = 2 := by rw [cp_eq_brute, brute_2_2]
theorem cp_K2_3 : chromaticPolynomial (K 2) 3 = 18 := by rw [cp_eq_brute, brute_2_3]
theorem cp_K3_3 : chromaticPolynomial (K 3) 3 = 30 := by rw [cp_eq_brute, brute_3_3]
theorem cp_K4_2 : chromaticPolynomial (K 4) 2 = 2 := by rw [cp_eq_brute, brute_4_2]

theorem closed_form_agrees :
    2 * (2 - 1) ^ 2 + 2 * (2 - 1) * (2 - 2) ^ 2 = 2 ∧
    3 * (3 - 1) ^ 2 + 3 * (3 - 1) * (3 - 2) ^ 2 = 18 ∧
    3 * (3 - 1) ^ 3 + 3 * (3 - 1) * (3 - 2) ^ 3 = 30 ∧
    2 * (2 - 1) ^ 4 + 2 * (2 - 1) * (2 - 2) ^ 4 = 2 := by
  norm_num

/-! ### An explicit 2-assignment of `K_{2,4}` with no proper list colouring -/

def S4 : Fin 4 → Finset ℕ := ![{0, 2}, {0, 3}, {1, 2}, {1, 3}]

def badK4 : Fin 2 ⊕ Fin 4 → Finset ℕ := Sum.elim ![{0, 1}, {2, 3}] S4

theorem badK4_card : ∀ v, (badK4 v).card = 2 := by
  intro v
  rcases v with i | j
  · fin_cases i <;> rfl
  · fin_cases j <;> rfl

theorem badK4_empty : IsEmpty (ListColorings (K 4) badK4) := by
  refine ⟨fun f => ?_⟩
  obtain ⟨g, hg⟩ := f
  have key : ∀ j : Fin 4, (g (Sum.inr j)).val ≠ (g (Sum.inl 0)).val ∧
      (g (Sum.inr j)).val ≠ (g (Sum.inl 1)).val := fun j =>
    ⟨hg _ _ (K_adj_inr_inl 4 0 j), hg _ _ (K_adj_inr_inl 4 1 j)⟩
  have ha : (g (Sum.inl 0)).val = 0 ∨ (g (Sum.inl 0)).val = 1 := by
    have h := (g (Sum.inl 0)).2
    simpa [badK4] using h
  have hb : (g (Sum.inl 1)).val = 2 ∨ (g (Sum.inl 1)).val = 3 := by
    have h := (g (Sum.inl 1)).2
    simpa [badK4] using h
  have hS : ∀ j : Fin 4, (g (Sum.inr j)).val ∈ S4 j := fun j => by
    have h := (g (Sum.inr j)).2
    simpa [badK4] using h
  rcases ha with ha | ha <;> rcases hb with hb | hb
  · have h := hS 0
    have k := key 0
    rw [ha, hb] at k
    simp [S4] at h
    omega
  · have h := hS 1
    have k := key 1
    rw [ha, hb] at k
    simp [S4] at h
    omega
  · have h := hS 2
    have k := key 2
    rw [ha, hb] at k
    simp [S4] at h
    omega
  · have h := hS 3
    have k := key 3
    rw [ha, hb] at k
    simp [S4] at h
    omega

theorem countL_badK4 : countL (K 4) badK4 = 0 := by
  unfold countL
  exact Fintype.card_eq_zero_iff.mpr badK4_empty

/-- The minimum over assignments is `0` although the constant assignment gives `2`:
this fails if `listColorFunction` is not a minimum over all `m`-assignments. -/
theorem listColor_K4_2 : listColorFunction (K 4) 2 = 0 := by
  have h := listColorFunction_le_countL (K 4) badK4 badK4_card
  rw [countL_badK4] at h
  exact Nat.le_zero.mp h

theorem tau_K4_ge3 : 3 ≤ tau (K 4) :=
  lt_tau_of_lt (by rw [listColor_K4_2, cp_K4_2]; norm_num)

/-! ### Controls for the shape of `τ` -/

theorem cp_K4_0 : chromaticPolynomial (K 4) 0 = 0 := by
  rw [chromaticPolynomial_K]
  norm_num

theorem eq_at_0 : listColorFunction (K 4) 0 = chromaticPolynomial (K 4) 0 := by
  have h := listColorFunction_le_chromaticPolynomial (K 4) 0
  rw [cp_K4_0] at h ⊢
  exact Nat.le_zero.mp h

/-- The first equality holds at `m = 0` but fails at the larger `m = 2`. -/
noncomputable def tauAtKNoChi : ℕ :=
  sInf {k : ℕ | listColorFunction (K 4) k = chromaticPolynomial (K 4) k}

noncomputable def tauEveryNoChi : ℕ :=
  sInf {k : ℕ | ∀ m : ℕ, k ≤ m → listColorFunction (K 4) m = chromaticPolynomial (K 4) m}

theorem tauAtKNoChi_eq : tauAtKNoChi = 0 :=
  Nat.le_zero.mp (Nat.sInf_le eq_at_0)

/-- With the every-larger-`m` clause the value is forced above `2`; with equality only at `k`
it is `0`. -/
theorem tauEveryNoChi_ge : 3 ≤ tauEveryNoChi := by
  have hne : ({k : ℕ | ∀ m : ℕ, k ≤ m →
      listColorFunction (K 4) m = chromaticPolynomial (K 4) m} : Set ℕ).Nonempty :=
    ⟨tau (K 4), fun m hm => (tau_mem (K 4) (tau_set_nonempty 4)).2 m hm⟩
  have hmem := Nat.sInf_mem hne
  by_contra hcon
  have hle : tauEveryNoChi ≤ 2 := by omega
  have h2 := hmem 2 hle
  rw [listColor_K4_2, cp_K4_2] at h2
  omega

/-! ### Exact list size: two isolated vertices -/

theorem countL_K0 {m : ℕ} (L : Fin 2 ⊕ Fin 0 → Finset ℕ) (hL : ∀ v, (L v).card = m) :
    countL (K 0) L = m * m := by
  rw [countL_K]
  simp [hL]

theorem listColor_K0_3 : listColorFunction (K 0) 3 = 9 := by
  obtain ⟨L, hL, h⟩ := listColorFunction_mem (K 0) 3
  rw [h, countL_K0 L hL]

/-- If list sizes were only bounded by `m`, the value would be `0`, not `9`. -/
theorem wrong_size_variant :
    sInf {n : ℕ | ∃ L : Fin 2 ⊕ Fin 0 → Finset ℕ, (∀ v, (L v).card ≤ 3) ∧ n = countL (K 0) L} = 0 := by
  refine Nat.le_zero.mp (Nat.sInf_le ⟨fun _ => ∅, fun _ => by simp, ?_⟩)
  rw [countL_K]
  simp

/-! ### A small exact value: `τ(K_{2,1}) = 2` -/

theorem erase_card_eq_sum (A : Finset ℕ) (c : ℕ) :
    (A.erase c).card = ∑ a ∈ A, if c ≠ a then 1 else 0 := by
  have e : A.erase c = A.filter (fun a => c ≠ a) := by
    ext x
    simp only [Finset.mem_erase, Finset.mem_filter]
    constructor
    · rintro ⟨h1, h2⟩
      exact ⟨h2, Ne.symm h1⟩
    · rintro ⟨h1, h2⟩
      exact ⟨Ne.symm h2, h1⟩
  rw [e]
  exact (Finset.sum_boole _ _).symm

theorem count_K1_ge {m : ℕ} (L : Fin 2 ⊕ Fin 1 → Finset ℕ) (hL : ∀ v, (L v).card = m) :
    m * ((m - 1) * (m - 1)) ≤ countL (K 1) L := by
  rw [countL_K]
  simp only [Fin.prod_univ_one]
  have hAc := hL (Sum.inl 0)
  have hBc := hL (Sum.inl 1)
  have hSc := hL (Sum.inr 0)
  generalize L (Sum.inl 0) = A at hAc ⊢
  generalize L (Sum.inl 1) = B at hBc ⊢
  generalize L (Sum.inr 0) = S at hSc ⊢
  have hc : ∀ a b, ((S.erase a).erase b).card = ∑ c ∈ S, if c ≠ a ∧ c ≠ b then 1 else 0 := by
    intro a b
    have e : (S.erase a).erase b = S.filter (fun c => c ≠ a ∧ c ≠ b) := by
      ext x
      simp only [Finset.mem_erase, Finset.mem_filter]
      constructor
      · rintro ⟨h1, h2, h3⟩
        exact ⟨h3, h2, h1⟩
      · rintro ⟨h1, h2, h3⟩
        exact ⟨h3, h2, h1⟩
    rw [e]
    exact (Finset.sum_boole _ _).symm
  have hfix : ∀ c, (A.erase c).card * (B.erase c).card
      = ∑ a ∈ A, ∑ b ∈ B, if c ≠ a ∧ c ≠ b then 1 else 0 := by
    intro c
    rw [erase_card_eq_sum A c, erase_card_eq_sum B c, Finset.sum_mul_sum]
    refine Finset.sum_congr rfl (fun a _ => Finset.sum_congr rfl (fun b _ => ?_))
    by_cases h1 : c ≠ a <;> by_cases h2 : c ≠ b <;> simp [h1, h2]
  have hEr : ∀ (T : Finset ℕ) (c : ℕ), T.card = m → m - 1 ≤ (T.erase c).card := by
    intro T c hT
    have h := Finset.pred_card_le_card_erase (s := T) (a := c)
    omega
  calc m * ((m - 1) * (m - 1))
      = ∑ _c ∈ S, (m - 1) * (m - 1) := by rw [Finset.sum_const, hSc, smul_eq_mul]
    _ ≤ ∑ c ∈ S, (A.erase c).card * (B.erase c).card :=
        Finset.sum_le_sum (fun c _ => Nat.mul_le_mul (hEr A c hAc) (hEr B c hBc))
    _ = ∑ c ∈ S, ∑ a ∈ A, ∑ b ∈ B, (if c ≠ a ∧ c ≠ b then 1 else 0) :=
        Finset.sum_congr rfl (fun c _ => hfix c)
    _ = ∑ a ∈ A, ∑ c ∈ S, ∑ b ∈ B, (if c ≠ a ∧ c ≠ b then 1 else 0) := Finset.sum_comm
    _ = ∑ a ∈ A, ∑ b ∈ B, ∑ c ∈ S, (if c ≠ a ∧ c ≠ b then 1 else 0) :=
        Finset.sum_congr rfl (fun a _ => Finset.sum_comm)
    _ = ∑ a ∈ A, ∑ b ∈ B, ((S.erase a).erase b).card :=
        Finset.sum_congr rfl (fun a _ => Finset.sum_congr rfl (fun b _ => (hc a b).symm))

theorem list_K1_eq {m : ℕ} (hm : 2 ≤ m) :
    listColorFunction (K 1) m = chromaticPolynomial (K 1) m := by
  apply le_antisymm (listColorFunction_le_chromaticPolynomial (K 1) m)
  obtain ⟨L, hL, hEq⟩ := listColorFunction_mem (K 1) m
  have h := count_K1_ge L hL
  rw [hEq, chromaticPolynomial_K]
  obtain ⟨n, rfl⟩ : ∃ n, m = n + 2 := ⟨m - 2, by omega⟩
  have e1 : n + 2 - 1 = n + 1 := by omega
  have e2 : n + 2 - 2 = n := by omega
  rw [e1] at h
  rw [e1, e2]
  calc (n + 2) * (n + 1) ^ 1 + (n + 2) * (n + 1) * n ^ 1
      = (n + 2) * ((n + 1) * (n + 1)) := by ring
    _ ≤ countL (K 1) L := h

/-- `τ(K_{2,1}) = 2`: the path on three vertices. Fails if the `k ≥ χ(G)` clause is dropped
(equality then already holds at `k = 0`), or if the threshold is not a minimum. -/
theorem tau_K1 : tau (K 1) = 2 := by
  apply le_antisymm
  · refine tau_le (K 1) (k := 2) ?_
    refine ⟨?_, fun m hm => list_K1_eq hm⟩
    have h := K_chromaticNumber_le_two 1
    exact_mod_cast h
  · by_contra h
    have hlt : tau (K 1) < 2 := not_le.mp h
    have hmem := tau_mem (K 1) (tau_set_nonempty 1)
    have hcol : (K 1).Colorable (tau (K 1)) :=
      SimpleGraph.chromaticNumber_le_iff_colorable.mp hmem.1
    have h1 : (K 1).Colorable 1 := hcol.mono (by omega)
    obtain ⟨C⟩ := h1
    exact C.valid (K_adj_inl_inr 1 0 0) (Subsingleton.elim _ _)

end ReviewerControls

#print axioms ReviewerControls.brute_3_3
#print axioms ReviewerControls.cp_eq_brute
#print axioms ReviewerControls.tau_K4_ge3
#print axioms ReviewerControls.listColor_K0_3
#print axioms ReviewerControls.tauEveryNoChi_ge
#print axioms ReviewerControls.tau_K1
