
import Mathlib.Combinatorics.SimpleGraph.Basic
import Mathlib.Combinatorics.SimpleGraph.Coloring.Vertex
import Mathlib.Data.Finset.Card
import Mathlib.Data.Fintype.Card
import Mathlib.Data.Fintype.Sets
import Mathlib.Analysis.Asymptotics.Theta
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Order.Lattice.Nat

/-!
# List colourings, the list colour function, and the list colour function threshold

Literal definitions from Kaul--Kumar--Mudrock--Rewers--Shin--To,
"On the List Color Function Threshold", arXiv:2202.03431, Section 1.2.
-/

open scoped Classical
open Finset

namespace ListCol

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- Proper list colourings of `G` from the list assignment `L`. -/
def ListColorings (G : SimpleGraph V) [DecidableRel G.Adj] (L : V → Finset Nat) : Type _ :=
  {f : ∀ v : V, ↥(L v) // ∀ u v : V, G.Adj u v → (f u).val ≠ (f v).val}

instance instFintypeListColorings (G : SimpleGraph V) [DecidableRel G.Adj]
    (L : V → Finset Nat) : Fintype (ListColorings G L) := by
  unfold ListColorings
  infer_instance

/-- `P(G,L)`: the number of proper `L`-colourings of `G`. -/
noncomputable def countL (G : SimpleGraph V) [DecidableRel G.Adj] (L : V → Finset Nat) : Nat :=
  Fintype.card (ListColorings G L)

/-- `P(G,m)`: the chromatic polynomial evaluated at `m`, the number of proper colourings
using colours from `[m]`. -/
noncomputable def chromaticPolynomial (G : SimpleGraph V) [DecidableRel G.Adj] (m : Nat) : Nat :=
  countL G fun _ => Finset.range m

/-- `P_ℓ(G,m)`: the minimum of `P(G,L)` over all `m`-assignments `L`. -/
noncomputable def listColorFunction (G : SimpleGraph V) [DecidableRel G.Adj] (m : Nat) : Nat :=
  sInf {n : Nat | ∃ L : V → Finset Nat, (∀ v, (L v).card = m) ∧ n = countL G L}

/-- `τ(G)`: the list colour function threshold: the smallest `k ≥ χ(G)` such that
`P_ℓ(G,m) = P(G,m)` for every `m ≥ k`. -/
noncomputable def tau (G : SimpleGraph V) [DecidableRel G.Adj] : Nat :=
  sInf {k : Nat | G.chromaticNumber ≤ (k : ℕ∞) ∧
    ∀ m : Nat, k ≤ m → listColorFunction G m = chromaticPolynomial G m}

lemma listColorFunction_set_nonempty (G : SimpleGraph V) [DecidableRel G.Adj] (m : Nat) :
    ({n : Nat | ∃ L : V → Finset Nat, (∀ v, (L v).card = m) ∧ n = countL G L} : Set Nat).Nonempty :=
  ⟨countL G (fun _ => Finset.range m),
    ⟨fun _ => Finset.range m, fun _ => Finset.card_range m, rfl⟩⟩

lemma listColorFunction_mem (G : SimpleGraph V) [DecidableRel G.Adj] (m : Nat) :
    ∃ L : V → Finset Nat, (∀ v, (L v).card = m) ∧
      listColorFunction G m = countL G L :=
  Nat.sInf_mem (listColorFunction_set_nonempty G m)

lemma listColorFunction_le_chromaticPolynomial (G : SimpleGraph V) [DecidableRel G.Adj]
    (m : Nat) : listColorFunction G m ≤ chromaticPolynomial G m := by
  unfold listColorFunction chromaticPolynomial
  exact Nat.sInf_le ⟨fun _ => Finset.range m, fun _ => Finset.card_range m, rfl⟩

lemma listColorFunction_le_countL (G : SimpleGraph V) [DecidableRel G.Adj] {m : Nat}
    (L : V → Finset Nat) (hL : ∀ v, (L v).card = m) :
    listColorFunction G m ≤ countL G L := by
  unfold listColorFunction
  exact Nat.sInf_le ⟨L, hL, rfl⟩

lemma tau_mem (G : SimpleGraph V) [DecidableRel G.Adj]
    (hne : ({k : Nat | G.chromaticNumber ≤ (k : ℕ∞) ∧
      ∀ m : Nat, k ≤ m → listColorFunction G m = chromaticPolynomial G m} : Set Nat).Nonempty) :
    tau G ∈ {k : Nat | G.chromaticNumber ≤ (k : ℕ∞) ∧
      ∀ m : Nat, k ≤ m → listColorFunction G m = chromaticPolynomial G m} :=
  Nat.sInf_mem hne

lemma tau_le (G : SimpleGraph V) [DecidableRel G.Adj]
    {k : Nat} (hk : k ∈ {k : Nat | G.chromaticNumber ≤ (k : ℕ∞) ∧
      ∀ m : Nat, k ≤ m → listColorFunction G m = chromaticPolynomial G m}) :
    tau G ≤ k :=
  Nat.sInf_le hk

/-- The complete bipartite graph `K_{2,l}` with parts of sizes `2` and `l`. -/
def K (l : Nat) : SimpleGraph (Fin 2 ⊕ Fin l) :=
  completeBipartiteGraph (Fin 2) (Fin l)

lemma K_adj_inl_inr (l : Nat) (i : Fin 2) (j : Fin l) :
    (K l).Adj (Sum.inl i) (Sum.inr j) := by
  simp [K, completeBipartiteGraph]

lemma K_adj_inr_inl (l : Nat) (i : Fin 2) (j : Fin l) :
    (K l).Adj (Sum.inr j) (Sum.inl i) := by
  simp [K, completeBipartiteGraph]

lemma K_not_adj_inl_inl (l : Nat) (i i' : Fin 2) :
    ¬ (K l).Adj (Sum.inl i) (Sum.inl i') := by
  simp [K, completeBipartiteGraph]

lemma K_not_adj_inr_inr (l : Nat) (j j' : Fin l) :
    ¬ (K l).Adj (Sum.inr j) (Sum.inr j') := by
  simp [K, completeBipartiteGraph]

lemma K_adj_cases (l : Nat) {v w : Fin 2 ⊕ Fin l} (h : (K l).Adj v w) :
    (∃ i j, v = Sum.inl i ∧ w = Sum.inr j) ∨ (∃ i j, v = Sum.inr j ∧ w = Sum.inl i) := by
  rcases v with i | j
  · rcases w with i' | j'
    · simp [K, completeBipartiteGraph] at h
    · exact Or.inl ⟨i, j', rfl, rfl⟩
  · rcases w with i' | j'
    · exact Or.inr ⟨i', j, rfl, rfl⟩
    · simp [K, completeBipartiteGraph] at h

/-- The two-colouring of `K_{2,l}`: one side gets colour `0`, the other colour `1`. -/
def Kcol (l : Nat) : Fin 2 ⊕ Fin l → Fin 2 := Sum.elim (fun _ => 0) (fun _ => 1)

lemma K_colorable_two (l : Nat) : (K l).Colorable 2 := by
  refine ⟨SimpleGraph.Coloring.mk (Kcol l) ?_⟩
  intro v w hvw
  rcases K_adj_cases l hvw with ⟨i, j, rfl, rfl⟩ | ⟨i, j, rfl, rfl⟩
  · simp [Kcol]
  · simp [Kcol]

lemma K_chromaticNumber_le_two (l : Nat) : (K l).chromaticNumber ≤ 2 :=
  SimpleGraph.chromaticNumber_le_iff_colorable.mpr (K_colorable_two l)

end ListCol
