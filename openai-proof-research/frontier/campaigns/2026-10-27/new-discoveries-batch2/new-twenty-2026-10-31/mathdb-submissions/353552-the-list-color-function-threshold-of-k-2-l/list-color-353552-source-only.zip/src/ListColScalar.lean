import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The scalar core of the main inequality for `K_{2,l}`

With `t = m - 1`, `lam t = -log (1 - 1/t)` and `mu t = log (1 + 1/t)`, for `t ≥ 3` and
`2 l ≤ t ^ 2` and `0 ≤ Z ≤ l` we prove
`1 + (1 - 1/t) ^ l ≤ Z / t + 2 * exp (-Z * lam t - (l - Z) * (lam t - mu t) / 4)`.
-/

namespace ListCol

noncomputable def lam (t : ℝ) : ℝ := -Real.log (1 - 1 / t)
noncomputable def mu (t : ℝ) : ℝ := Real.log (1 + 1 / t)

variable {t : ℝ}

lemma aPos (ht : 3 ≤ t) : 0 < 1 / t := by
  have : 0 < t := by linarith
  positivity

lemma aLe (ht : 3 ≤ t) : 1 / t ≤ 1 / 3 := by
  rw [div_le_div_iff₀ (by linarith) (by norm_num)]
  linarith

lemma sPos (ht : 3 ≤ t) : 0 < 1 - 1 / t := by
  have := aLe ht
  linarith

lemma qPos (ht : 3 ≤ t) : 0 < 1 + 1 / t := by
  have := aPos ht
  linarith

lemma exp_neg_lam (ht : 3 ≤ t) : Real.exp (-lam t) = 1 - 1 / t := by
  unfold lam
  rw [neg_neg, Real.exp_log (sPos ht)]

lemma exp_mu (ht : 3 ≤ t) : Real.exp (mu t) = 1 + 1 / t := by
  unfold mu
  rw [Real.exp_log (qPos ht)]

lemma lam_lb (ht : 3 ≤ t) : 1 / t ≤ lam t := by
  unfold lam
  have := Real.log_le_sub_one_of_pos (sPos ht)
  linarith

lemma lam_ub (ht : 3 ≤ t) : lam t ≤ 4 / 3 * (1 / t) := by
  have ha0 := aPos ht
  have ha1 := aLe ht
  set a : ℝ := 1 / t with ha
  have hs : 0 < 1 - a := by linarith
  have hx : 0 ≤ 4 / 3 * a := by linarith
  have hexp := Real.quadratic_le_exp_of_nonneg hx
  have hpoly : 1 ≤ (1 + 4 / 3 * a + (4 / 3 * a) ^ 2 / 2) * (1 - a) := by
    have h1 : 0 ≤ a * (1 / 3 - 4 / 9 * a - 8 / 9 * a ^ 2) := by
      apply mul_nonneg ha0.le
      nlinarith
    nlinarith
  have hmul : 1 ≤ Real.exp (4 / 3 * a) * (1 - a) :=
    hpoly.trans (mul_le_mul_of_nonneg_right hexp hs.le)
  have hcancel : Real.exp (-(4 / 3 * a)) * Real.exp (4 / 3 * a) = 1 := by
    rw [← Real.exp_add]
    simp
  have hneg : Real.exp (-(4 / 3 * a)) ≤ 1 - a := by
    have hepos : 0 < Real.exp (-(4 / 3 * a)) := Real.exp_pos _
    calc Real.exp (-(4 / 3 * a))
        = Real.exp (-(4 / 3 * a)) * 1 := by ring
      _ ≤ Real.exp (-(4 / 3 * a)) * (Real.exp (4 / 3 * a) * (1 - a)) :=
          mul_le_mul_of_nonneg_left hmul hepos.le
      _ = 1 - a := by rw [← mul_assoc, hcancel, one_mul]
  have hlog : -(4 / 3 * a) ≤ Real.log (1 - a) := (Real.le_log_iff_exp_le hs).mpr hneg
  unfold lam
  linarith

lemma mu_ub (ht : 3 ≤ t) : mu t ≤ 1 / t := by
  unfold mu
  have := Real.log_le_sub_one_of_pos (qPos ht)
  linarith

lemma mu_lb (ht : 3 ≤ t) : 3 / 4 * (1 / t) ≤ mu t := by
  have ha0 := aPos ht
  have ha1 := aLe ht
  unfold mu
  set a : ℝ := 1 / t with ha
  have hq : 0 < 1 + a := by linarith
  have h := Real.one_sub_inv_le_log_of_pos hq
  have hinv : (1 + a)⁻¹ ≤ 1 - 3 / 4 * a := by
    rw [inv_le_iff_one_le_mul₀ hq]
    nlinarith
  linarith

lemma mu_nonneg (ht : 3 ≤ t) : 0 ≤ mu t := by
  have := mu_lb ht
  have := aPos ht
  linarith

lemma nu_nonneg (ht : 3 ≤ t) : 0 ≤ lam t - mu t := by
  have := mu_ub ht
  have := lam_lb ht
  linarith

lemma nu_ub (ht : 3 ≤ t) : lam t - mu t ≤ 9 / 8 * (1 / t) ^ 2 := by
  have ha0 := aPos ht
  have ha1 := aLe ht
  have hsp := sPos ht
  have hqp := qPos ht
  have hlog : lam t - mu t = -Real.log ((1 - 1 / t) * (1 + 1 / t)) := by
    unfold lam mu
    rw [Real.log_mul hsp.ne' hqp.ne']
    ring
  rw [hlog]
  set a : ℝ := 1 / t with ha
  have hk : (1 - a) * (1 + a) = 1 - a ^ 2 := by ring
  rw [hk]
  have hasq : a ^ 2 ≤ 1 / 9 := by nlinarith
  have hk0 : 0 < 1 - a ^ 2 := by linarith
  have h := Real.one_sub_inv_le_log_of_pos hk0
  have hinv : (1 - a ^ 2)⁻¹ ≤ 1 + 9 / 8 * a ^ 2 := by
    rw [inv_le_iff_one_le_mul₀ hk0]
    nlinarith [sq_nonneg (a ^ 2)]
  linarith

/-- The normalised value `(1 - 1/t)^l` is a pure exponential. -/
lemma pow_eq_exp (ht : 3 ≤ t) (l : ℕ) : (1 - 1 / t) ^ l = Real.exp (-(l : ℝ) * lam t) := by
  have h : -(l : ℝ) * lam t = (l : ℝ) * (-lam t) := by ring
  rw [h, Real.exp_nat_mul, exp_neg_lam ht]

lemma bernoulli_s (ht : 3 ≤ t) (l : ℕ) : 1 - (l : ℝ) / t ≤ (1 - 1 / t) ^ l := by
  have ha1 := aLe ht
  have ha0 := aPos ht
  have h := one_add_mul_le_pow (a := -(1 / t)) (by linarith) l
  have h1 : (1 : ℝ) + -(1 / t) = 1 - 1 / t := by ring
  rw [h1] at h
  have h2 : 1 + (l : ℝ) * -(1 / t) = 1 - (l : ℝ) / t := by
    ring
  linarith

/-- `B(Z) ≥ y`: the mean-value term dominates the all-present value. -/
lemma pow_le_B (ht : 3 ≤ t) (l : ℕ) {Z : ℝ} (hZl : Z ≤ l) :
    (1 - 1 / t) ^ l ≤ Real.exp (-Z * lam t - ((l : ℝ) - Z) * (lam t - mu t) / 4) := by
  rw [pow_eq_exp ht]
  apply Real.exp_le_exp.mpr
  have hp : 0 ≤ (l : ℝ) - Z := by linarith
  have hm := mu_nonneg ht
  have hl : 0 ≤ lam t := by
    have := lam_lb ht
    have := aPos ht
    linarith
  nlinarith [mul_nonneg hp hm, mul_nonneg hp hl]

/-- The final scalar inequality. -/
theorem scalar_main (ht : 3 ≤ t) (l : ℕ) (hl : 2 * (l : ℝ) ≤ t ^ 2) {Z : ℝ} (hZl : Z ≤ l) :
    1 + (1 - 1 / t) ^ l ≤ Z / t + 2 * Real.exp (-Z * lam t - ((l : ℝ) - Z) * (lam t - mu t) / 4) := by
  have htpos : 0 < t := by linarith
  have ha0 := aPos ht
  have hlb := lam_lb ht
  have hub := lam_ub ht
  have hmb := mu_ub ht
  have hml := mu_lb ht
  have hnuU := nu_ub ht
  have hnu0 := nu_nonneg ht
  set L : ℝ := lam t with hLdef
  set M : ℝ := mu t with hMdef
  have ht1 : t * (1 / t) = 1 := by field_simp
  have hL1 : 1 ≤ t * L := by
    have := mul_le_mul_of_nonneg_left hlb htpos.le
    linarith
  have hL2 : t * L ≤ 4 / 3 := by
    have := mul_le_mul_of_nonneg_left hub htpos.le
    nlinarith
  have hM1 : 3 / 4 ≤ t * M := by
    have := mul_le_mul_of_nonneg_left hml htpos.le
    nlinarith
  have hM2 : t * M ≤ 1 := by
    have := mul_le_mul_of_nonneg_left hmb htpos.le
    linarith
  obtain ⟨ρ, hρ⟩ : ∃ ρ : ℝ, ρ = (3 * L + M) / 4 := ⟨_, rfl⟩
  obtain ⟨g, hg⟩ : ∃ g : ℝ, g = t * ρ := ⟨_, rfl⟩
  have hgeq : g = (3 * (t * L) + t * M) / 4 := by rw [hg, hρ]; ring
  have hg1 : 15 / 16 ≤ g := by rw [hgeq]; linarith
  have hg2 : g ≤ 5 / 4 := by rw [hgeq]; linarith
  have hgpos : 0 < g := by linarith
  have hρpos : 0 < ρ := by
    have hLp : 0 < L := by linarith
    have hMn : 0 ≤ M := by linarith
    rw [hρ]
    linarith
  obtain ⟨y, hy⟩ : ∃ y : ℝ, y = (1 - 1 / t) ^ l := ⟨_, rfl⟩
  have hy0 : 0 ≤ y := by rw [hy]; exact pow_nonneg (sPos ht).le _
  have hbern : 1 - (l : ℝ) / t ≤ y := by rw [hy]; exact bernoulli_s ht l
  have hyexp : y = Real.exp (-(l : ℝ) * L) := by rw [hy]; exact pow_eq_exp ht l
  rw [← hy]
  by_cases hcase : 1 ≤ 2 * y * g
  · obtain ⟨p, hp⟩ : ∃ p : ℝ, p = (l : ℝ) - Z := ⟨_, rfl⟩
    have hp0 : 0 ≤ p := by rw [hp]; linarith
    have hB : Real.exp (-Z * L - ((l : ℝ) - Z) * (L - M) / 4) = y * Real.exp (p * ρ) := by
      rw [hyexp, ← Real.exp_add]
      congr 1
      rw [hp, hρ]
      ring
    have h1 : 1 + p * ρ ≤ Real.exp (p * ρ) := by linarith [Real.add_one_le_exp (p * ρ)]
    have h2 : 1 / t ≤ 2 * y * ρ := by
      rw [div_le_iff₀ htpos]
      have : 2 * y * ρ * t = 2 * y * g := by rw [hg]; ring
      linarith
    have h3 : p * (1 / t) ≤ p * (2 * y * ρ) := mul_le_mul_of_nonneg_left h2 hp0
    have h4 : Z / t + p * (1 / t) = (l : ℝ) / t := by
      rw [hp]
      field_simp
      ring
    have h5 : y * (1 + p * ρ) ≤ y * Real.exp (p * ρ) := mul_le_mul_of_nonneg_left h1 hy0
    have h6 : y * (1 + p * ρ) = y + p * (2 * y * ρ) / 2 := by ring
    rw [hB]
    linarith
  · have hcase := not_le.mp hcase
    obtain ⟨v, hv⟩ : ∃ v : ℝ, v = Real.exp (-(l : ℝ) * (L - M) / 4) := ⟨_, rfl⟩
    have hvpos : 0 < v := by rw [hv]; exact Real.exp_pos _
    obtain ⟨c, hc⟩ : ∃ c : ℝ, c = 2 * v * g := ⟨_, rfl⟩
    have hcpos : 0 < c := by rw [hc]; positivity
    obtain ⟨w, hw⟩ : ∃ w : ℝ, w = Real.log c := ⟨_, rfl⟩
    have hEsplit : Real.exp (-Z * L - ((l : ℝ) - Z) * (L - M) / 4)
        = v * (Real.exp (-w) * Real.exp (-Z * ρ + w)) := by
      rw [hv, ← Real.exp_add, ← Real.exp_add]
      congr 1
      rw [hρ]
      ring
    have hexpw : Real.exp (-w) = c⁻¹ := by
      rw [Real.exp_neg, hw, Real.exp_log hcpos]
    have htan : 1 + (-Z * ρ + w) ≤ Real.exp (-Z * ρ + w) := by
      linarith [Real.add_one_le_exp (-Z * ρ + w)]
    have h2vc : 2 * v * c⁻¹ = g⁻¹ := by
      rw [hc]
      field_simp
    have hmain : g⁻¹ * (1 + (-Z * ρ + w)) ≤ 2 * Real.exp (-Z * L - ((l : ℝ) - Z) * (L - M) / 4) := by
      rw [hEsplit, hexpw]
      have hnn : 0 ≤ 2 * v * c⁻¹ := by positivity
      have := mul_le_mul_of_nonneg_left htan hnn
      rw [h2vc] at this
      calc g⁻¹ * (1 + (-Z * ρ + w)) ≤ g⁻¹ * Real.exp (-Z * ρ + w) := this
        _ = 2 * (v * (c⁻¹ * Real.exp (-Z * ρ + w))) := by rw [← h2vc]; ring
    have hzpart : Z / t + g⁻¹ * (-Z * ρ) = 0 := by
      rw [hg]
      have hρne : ρ ≠ 0 := hρpos.ne'
      field_simp
      ring
    have hlogeq : w = Real.log 2 + (-(l : ℝ) * (L - M) / 4) + Real.log g := by
      rw [hw, hc, Real.log_mul (by positivity) hgpos.ne', Real.log_mul (by norm_num) hvpos.ne', hv,
        Real.log_exp]
    have hlnu : (l : ℝ) * (L - M) / 4 ≤ 9 / 64 := by
      have hl0 : (0 : ℝ) ≤ l := Nat.cast_nonneg l
      have h1 : (l : ℝ) * (L - M) ≤ (l : ℝ) * (9 / 8 * (1 / t) ^ 2) :=
        mul_le_mul_of_nonneg_left hnuU hl0
      have h2 : (l : ℝ) * (1 / t) ^ 2 ≤ 1 / 2 := by
        have ht2 : 0 < t ^ 2 := by positivity
        have : (l : ℝ) * (1 / t) ^ 2 = (l : ℝ) / t ^ 2 := by
          field_simp
        rw [this, div_le_iff₀ ht2]
        linarith
      nlinarith
    have hlogg : 1 - g⁻¹ ≤ Real.log g := Real.one_sub_inv_le_log_of_pos hgpos
    have hl2 : (6931 : ℝ) / 10000 < Real.log 2 := by
      have := Real.log_two_gt_d9
      norm_num at this ⊢
      linarith
    have hginv : g⁻¹ ≤ 41 / 20 - g := by
      rw [inv_le_iff_one_le_mul₀ hgpos]
      have hq : 0 ≤ (g - 4 / 5) * (5 / 4 - g) :=
        mul_nonneg (by linarith only [hg1]) (by linarith only [hg2])
      linarith only [hq]
    have hwlb : g + 1 / 2 ≤ 1 + w := by
      rw [hlogeq]
      linarith only [hl2, hlnu, hlogg, hginv]
    have hyU : y * g ≤ 1 / 2 := by linarith only [hcase]
    have hfinal : 1 + y ≤ g⁻¹ * (1 + w) := by
      have hgi : 0 < g⁻¹ := inv_pos.mpr hgpos
      have h1 : g⁻¹ * (g + 1 / 2) ≤ g⁻¹ * (1 + w) := mul_le_mul_of_nonneg_left hwlb hgi.le
      have h2 : g⁻¹ * (g + 1 / 2) = 1 + g⁻¹ * (1 / 2) := by
        field_simp
      have h3 : y ≤ g⁻¹ * (1 / 2) := by
        have : y = g⁻¹ * (y * g) := by field_simp
        rw [this]
        exact mul_le_mul_of_nonneg_left hyU hgi.le
      linarith
    have hexpand : g⁻¹ * (1 + (-Z * ρ + w)) = g⁻¹ * (1 + w) + g⁻¹ * (-Z * ρ) := by ring
    linarith

end ListCol
