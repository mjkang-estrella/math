import ListColEndpoint

#print axioms ListCol.sq_of_ceil_le
#print axioms ListCol.kB_mem_tau_set
#print axioms ListCol.tau_set_nonempty
#print axioms ListCol.tau_le_kB
#print axioms ListCol.lt_tau_of_lt
#print axioms ListCol.tau_lower
#print axioms ListCol.tau_isTheta
#print axioms ListCol.tau_completeBipartite_isTheta
