import ListColUpper
import Mathlib.Data.Nat.Cast.Order.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.IntervalCases
import Mathlib.Tactic.NormNum

/-!
# The main inequality for `K_{2,l}`: combinatorial decomposition

Double counting of missing colours over `A ∪ B`, and the exact four-way split of the
double sum over `A × B` into diagonal, `D × D` off-diagonal, mixed, and `A' × B'` parts.
-/

open scoped Classical
open Finset

namespace ListCol

/-! ## 5. Double counting of missing colours -/

lemma filter_not_eq_sdiff (U S : Finset Nat) :
    U.filter (fun x => x ∉ S) = U \ S := by
  ext x
  simp [Finset.mem_filter, Finset.mem_sdiff]

lemma card_sdiff_of_subset {U S : Finset Nat} (h : S ⊆ U) :
    (U \ S).card = U.card - S.card := by
  rw [Finset.card_sdiff, (Finset.inter_eq_left).mpr h]

lemma sum_missCount {l : Nat} (m p : Nat) (S : Fin l → Finset Nat) (U : Finset Nat)
    (hsub : ∀ j, S j ⊆ U) (hcard : ∀ j, (S j).card = m) (hU : U.card = m + p) :
    (∑ x ∈ U, missCount S x) = p * l := by
  have hcard' : ∀ j : Fin l, (U \ S j).card = p := by
    intro j
    rw [card_sdiff_of_subset (hsub j), hcard j, hU]
    omega
  calc (∑ x ∈ U, missCount S x)
      = ∑ x ∈ U, ∑ j : Fin l, (if x ∉ S j then 1 else 0) := by
          refine Finset.sum_congr rfl (fun x _ => ?_)
          rw [missCount]
          exact (Finset.sum_boole (fun j => x ∉ S j) Finset.univ).symm
    _ = ∑ j : Fin l, ∑ x ∈ U, (if x ∉ S j then 1 else 0) := Finset.sum_comm
    _ = ∑ j : Fin l, (U.filter (fun x => x ∉ S j)).card := by
          refine Finset.sum_congr rfl (fun j _ => ?_)
          exact Finset.sum_boole (fun x => x ∉ S j) U
    _ = ∑ j : Fin l, p := by
          refine Finset.sum_congr rfl (fun j _ => ?_)
          rw [filter_not_eq_sdiff, hcard' j]
    _ = p * l := by
          rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul, mul_comm]

/-! ## 6. The four-way split of the double sum -/

theorem sum_split (A B D A' B' : Finset Nat) (f : Nat → Nat → Real)
    (hD : D = A ∩ B) (hA' : A' = A \ D) (hB' : B' = B \ D) :
    (∑ a ∈ A, ∑ b ∈ B, f a b)
      = (∑ x ∈ D, f x x)
        + (∑ x ∈ D, ∑ y ∈ D.erase x, f x y)
        + (∑ α ∈ A', ∑ x ∈ D, f α x)
        + (∑ x ∈ D, ∑ β ∈ B', f x β)
        + (∑ α ∈ A', ∑ β ∈ B', f α β) := by
  have hDA : D ⊆ A := by rw [hD]; exact Finset.inter_subset_left
  have hDB : D ⊆ B := by rw [hD]; exact Finset.inter_subset_right
  have hAsplit : D ∪ A' = A := by
    rw [hA']
    exact Finset.union_sdiff_of_subset hDA
  have hBsplit : D ∪ B' = B := by
    rw [hB']
    exact Finset.union_sdiff_of_subset hDB
  have hdisjA : Disjoint D A' := by
    rw [hA']
    exact (Finset.sdiff_disjoint (s := D) (t := A)).symm
  have hdisjB : Disjoint D B' := by
    rw [hB']
    exact (Finset.sdiff_disjoint (s := D) (t := B)).symm
  have hDD : (∑ a ∈ D, ∑ b ∈ D, f a b)
      = (∑ x ∈ D, f x x) + (∑ x ∈ D, ∑ y ∈ D.erase x, f x y) := by
    conv_rhs => rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun x hx => ?_)
    exact (Finset.add_sum_erase (s := D) (f := fun y => f x y) hx).symm
  have hinner : ∀ a, (∑ b ∈ B, f a b) = (∑ b ∈ D, f a b) + (∑ b ∈ B', f a b) := by
    intro a
    rw [← hBsplit, Finset.sum_union hdisjB]
  have hA1 : (∑ a ∈ A, ∑ b ∈ D, f a b)
      = (∑ a ∈ D, ∑ b ∈ D, f a b) + (∑ a ∈ A', ∑ b ∈ D, f a b) := by
    rw [← hAsplit, Finset.sum_union hdisjA]
  have hA2 : (∑ a ∈ A, ∑ b ∈ B', f a b)
      = (∑ a ∈ D, ∑ b ∈ B', f a b) + (∑ a ∈ A', ∑ b ∈ B', f a b) := by
    rw [← hAsplit, Finset.sum_union hdisjA]
  calc (∑ a ∈ A, ∑ b ∈ B, f a b)
      = ∑ a ∈ A, ((∑ b ∈ D, f a b) + (∑ b ∈ B', f a b)) := by
          refine Finset.sum_congr rfl (fun a _ => hinner a)
    _ = (∑ a ∈ A, ∑ b ∈ D, f a b) + (∑ a ∈ A, ∑ b ∈ B', f a b) := Finset.sum_add_distrib
    _ = ((∑ a ∈ D, ∑ b ∈ D, f a b) + (∑ a ∈ A', ∑ b ∈ D, f a b))
          + ((∑ a ∈ D, ∑ b ∈ B', f a b) + (∑ a ∈ A', ∑ b ∈ B', f a b)) := by
          rw [hA1, hA2]
    _ = (∑ x ∈ D, f x x)
          + (∑ x ∈ D, ∑ y ∈ D.erase x, f x y)
          + (∑ α ∈ A', ∑ x ∈ D, f α x)
          + (∑ x ∈ D, ∑ β ∈ B', f x β)
          + (∑ α ∈ A', ∑ β ∈ B', f α β) := by
          rw [hDD]
          abel

/-! ## 7. Per-term lower bounds -/

lemma jointMiss_le_left {l : Nat} (S : Fin l → Finset Nat) (a b : Nat) :
    jointMiss S a b ≤ missCount S a := by
  rw [jointMiss, missCount]
  apply Finset.card_le_card
  intro j
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  exact fun h => h.1

lemma jointMiss_le_missCount {l : Nat} (S : Fin l → Finset Nat) (a b : Nat) :
    jointMiss S a b ≤ missCount S b := by
  rw [jointMiss, missCount]
  apply Finset.card_le_card
  intro j
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  exact fun h => h.2

/-- For `0 <= r <= 1` the power `r ^ n` is antitone in `n`. -/
lemma pow_le_pow_of_le_one' {a : Real} (h0 : 0 ≤ a) (h1 : a ≤ 1) {n m : Nat} (hnm : n ≤ m) :
    a ^ m ≤ a ^ n :=
  pow_le_pow_of_le_one h0 h1 hnm

/-- The key comparison: `q ^ sa * tau0 ^ sb <= q ^ (sa+sb) * r ^ c` whenever `c <= sb`. -/
theorem term_ge_of_le (m : Nat) (hm : 4 ≤ m) (sa sb c : Nat) (hc : c ≤ sb) :
    mq m ^ sa * mt0 m ^ sb ≤ mq m ^ (sa + sb) * mr m ^ c := by
  have h1 : mr m ^ sb ≤ mr m ^ c :=
    pow_le_pow_of_le_one (le_of_lt (mr_pos m hm)) (mr_le_one m hm) hc
  have h2 : mt0 m ^ sb = (mq m * mr m) ^ sb := by rw [mq_mr m hm]
  have h3 : mq m ^ sa * (mq m * mr m) ^ sb = mq m ^ (sa + sb) * mr m ^ sb := by
    rw [mul_pow, ← mul_assoc, ← pow_add]
  rw [h2, h3]
  exact mul_le_mul_of_nonneg_left h1 (pow_nonneg (le_of_lt (mq_pos m hm)) _)

/-- Off-diagonal terms are at least `1` in normalised form. -/
theorem term_off_ge (m : Nat) (hm : 4 ≤ m) {l : Nat} (S : Fin l → Finset Nat) (a b : Nat) :
    (1:Real) ≤ mq m ^ (missCount S a + missCount S b) * mr m ^ (jointMiss S a b) := by
  have h := term_ge_of_le m hm (missCount S a) (missCount S b) (jointMiss S a b)
    (jointMiss_le_missCount S a b)
  have h1 : (1:Real) ≤ mq m ^ (missCount S a) := one_le_pow₀ (mq_ge_one m hm)
  have h2 : (1:Real) ≤ mt0 m ^ (missCount S b) := one_le_pow₀ (mt0_ge_one m hm)
  nlinarith [h1, h2]

/-- Mixed term bound (`alpha` not in `D`, `x` in `D`): the `q`-weight of the missing
colour `alpha` and the `tau0`-weight of `x` are dominated. -/
theorem mixed_term_ge (m : Nat) (hm : 4 ≤ m) {l : Nat} (S : Fin l → Finset Nat) (α x : Nat) :
    mq m ^ (missCount S α) * mt0 m ^ (missCount S x)
      ≤ mq m ^ (missCount S α + missCount S x) * mr m ^ (jointMiss S α x) :=
  term_ge_of_le m hm (missCount S α) (missCount S x) (jointMiss S α x)
    (jointMiss_le_missCount S α x)

/-- `A' × B'` term bound: the geometric-mean shape. -/
theorem ab_term_ge (m : Nat) (hm : 4 ≤ m) {l : Nat} (S : Fin l → Finset Nat) (α β : Nat) :
    mq m ^ (max (missCount S α) (missCount S β)) * mt0 m ^ (min (missCount S α) (missCount S β))
      ≤ mq m ^ (missCount S α + missCount S β) * mr m ^ (jointMiss S α β) := by
  have h1 : jointMiss S α β ≤ missCount S α := jointMiss_le_left S α β
  have hc : jointMiss S α β ≤ min (missCount S α) (missCount S β) :=
    le_min h1 (jointMiss_le_missCount S α β)
  have hsum : max (missCount S α) (missCount S β) + min (missCount S α) (missCount S β)
      = missCount S α + missCount S β := by omega
  have h := term_ge_of_le m hm (max (missCount S α) (missCount S β))
    (min (missCount S α) (missCount S β)) (jointMiss S α β) hc
  rwa [hsum] at h

/-! ## 8. Summed lower bounds for the mixed groups -/

theorem mixed_sum_ge (m : Nat) (hm : 4 ≤ m) {l : Nat} (S : Fin l → Finset Nat)
    (A' D : Finset Nat) :
    (∑ α ∈ A', ∑ x ∈ D, mq m ^ (missCount S α) * mt0 m ^ (missCount S x))
      ≤ (∑ α ∈ A', ∑ x ∈ D,
          mq m ^ (missCount S α + missCount S x) * mr m ^ (jointMiss S α x)) := by
  refine Finset.sum_le_sum (fun α hα => Finset.sum_le_sum (fun x hx => ?_))
  exact mixed_term_ge m hm S α x

theorem mixed_sum_ge' (m : Nat) (hm : 4 ≤ m) {l : Nat} (S : Fin l → Finset Nat)
    (D B' : Finset Nat) :
    (∑ x ∈ D, ∑ β ∈ B', mq m ^ (missCount S β) * mt0 m ^ (missCount S x))
      ≤ (∑ x ∈ D, ∑ β ∈ B',
          mq m ^ (missCount S β + missCount S x) * mr m ^ (jointMiss S β x)) := by
  refine Finset.sum_le_sum (fun x hx => Finset.sum_le_sum (fun β hβ => ?_))
  exact mixed_term_ge m hm S β x

theorem ab_sum_ge (m : Nat) (hm : 4 ≤ m) {l : Nat} (S : Fin l → Finset Nat)
    (A' B' : Finset Nat) :
    (∑ α ∈ A', ∑ β ∈ B',
        mq m ^ (max (missCount S α) (missCount S β))
          * mt0 m ^ (min (missCount S α) (missCount S β)))
      ≤ (∑ α ∈ A', ∑ β ∈ B',
          mq m ^ (missCount S α + missCount S β) * mr m ^ (jointMiss S α β)) := by
  refine Finset.sum_le_sum (fun α hα => Finset.sum_le_sum (fun β hβ => ?_))
  exact ab_term_ge m hm S α β

end ListCol
