import ListColLower
import Mathlib.Analysis.Asymptotics.Theta
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Order.Filter.AtTopBot.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The literal endpoint: `τ(K_{2,l}) = Θ(√l)`

No premise restricting the list assignments is used anywhere.
-/

open scoped Classical
open Finset Asymptotics Filter

namespace ListCol

/-- The explicit upper bound `max(4, ⌈1 + √(2 l)⌉)` for the threshold. -/
noncomputable def kB (l : ℕ) : ℕ := max 4 ⌈(1 : ℝ) + Real.sqrt (2 * (l : ℝ))⌉₊

lemma kB_ge_four (l : ℕ) : 4 ≤ kB l := le_max_left _ _

lemma kB_ge_ceil (l : ℕ) : ⌈(1 : ℝ) + Real.sqrt (2 * (l : ℝ))⌉₊ ≤ kB l := le_max_right _ _

/-- If `m ≥ ⌈1 + √(2 l)⌉` then `2 l ≤ (m - 1) ^ 2`. -/
lemma sq_of_ceil_le {l m : ℕ} (h : ⌈(1 : ℝ) + Real.sqrt (2 * (l : ℝ))⌉₊ ≤ m) (hm : 1 ≤ m) :
    2 * l ≤ (m - 1) ^ 2 := by
  have h1 : (1 : ℝ) + Real.sqrt (2 * (l : ℝ)) ≤ m := Nat.ceil_le.mp h
  have h2 : Real.sqrt (2 * (l : ℝ)) ≤ (m : ℝ) - 1 := by linarith
  have h3 : (Real.sqrt (2 * (l : ℝ))) ^ 2 ≤ ((m : ℝ) - 1) ^ 2 :=
    pow_le_pow_left₀ (Real.sqrt_nonneg _) h2 2
  rw [Real.sq_sqrt (by positivity)] at h3
  have hc : ((m - 1 : ℕ) : ℝ) = (m : ℝ) - 1 := by
    rw [Nat.cast_sub hm]
    norm_num
  rw [← hc] at h3
  exact_mod_cast h3

/-- `max(4, ⌈1 + √(2l)⌉)` belongs to the defining set of `τ(K_{2,l})`: the set is nonempty. -/
theorem kB_mem_tau_set (l : ℕ) :
    kB l ∈ {k : ℕ | (K l).chromaticNumber ≤ (k : ℕ∞) ∧
      ∀ m : ℕ, k ≤ m → listColorFunction (K l) m = chromaticPolynomial (K l) m} := by
  refine ⟨?_, fun m hm => ?_⟩
  · refine (K_chromaticNumber_le_two l).trans ?_
    have h2 : 2 ≤ kB l := by
      have := kB_ge_four l
      omega
    exact_mod_cast h2
  · have h4 : 4 ≤ m := (kB_ge_four l).trans hm
    exact listColorFunction_eq h4 (sq_of_ceil_le ((kB_ge_ceil l).trans hm) (by omega))

/-- Nonemptiness of the defining set of `τ(K_{2,l})`. -/
theorem tau_set_nonempty (l : ℕ) :
    ({k : ℕ | (K l).chromaticNumber ≤ (k : ℕ∞) ∧
      ∀ m : ℕ, k ≤ m → listColorFunction (K l) m = chromaticPolynomial (K l) m} : Set ℕ).Nonempty :=
  ⟨kB l, kB_mem_tau_set l⟩

/-- `τ(K_{2,l}) ≤ max(4, ⌈1 + √(2l)⌉)`. -/
theorem tau_le_kB (l : ℕ) : tau (K l) ≤ max 4 ⌈(1 : ℝ) + Real.sqrt (2 * (l : ℝ))⌉₊ :=
  tau_le (K l) (kB_mem_tau_set l)

/-- If the list colour function differs from the chromatic polynomial at `m`, then `m < τ`. -/
theorem lt_tau_of_lt {l m : ℕ}
    (h : listColorFunction (K l) m < chromaticPolynomial (K l) m) : m < tau (K l) := by
  by_contra hcontra
  have hle : tau (K l) ≤ m := not_lt.mp hcontra
  have hmem := tau_mem (K l) (tau_set_nonempty l)
  have heq := hmem.2 m hle
  rw [heq] at h
  exact lt_irrefl _ h

/-- The lower bound on `τ(K_{2,l})`: for `l ≥ 144`, `√l ≤ 4 τ(K_{2,l})`. -/
theorem tau_lower {l : ℕ} (hl : 144 ≤ l) : Real.sqrt (l : ℝ) ≤ 4 * (tau (K l) : ℝ) := by
  obtain ⟨s, hs⟩ : ∃ s : ℕ, s = Nat.sqrt l := ⟨_, rfl⟩
  have hs12 : 12 ≤ s := by
    rw [hs, Nat.le_sqrt']
    omega
  have hsl : s ^ 2 ≤ l := by
    rw [hs]
    exact Nat.sqrt_le' l
  have hls : l < (s + 1) ^ 2 := by
    rw [hs]
    exact Nat.lt_succ_sqrt' l
  obtain ⟨t, ht⟩ : ∃ t : ℕ, t = s / 4 := ⟨_, rfl⟩
  have h4t : 4 * t ≤ s := by omega
  have ht3 : 3 ≤ t := by omega
  obtain ⟨c, hc⟩ : ∃ c : ℕ, t = c + 1 := ⟨t - 1, by omega⟩
  have hc2 : 2 ≤ c := by omega
  have hT : 4 * (c + 1) ^ 2 ≤ l / 4 := by
    rw [← hc, Nat.le_div_iff_mul_le (by norm_num)]
    have h1 : (4 * t) ^ 2 ≤ s ^ 2 := Nat.pow_le_pow_left h4t 2
    nlinarith
  have hstrict := listColorFunction_lt hc2 hT
  have htau := lt_tau_of_lt hstrict
  have htauR : (c : ℝ) + 2 + 1 ≤ (tau (K l) : ℝ) := by exact_mod_cast htau
  have hsR : (s : ℝ) + 1 ≤ 4 * ((c : ℝ) + 2) := by
    have h1 : s ≤ 4 * t + 3 := by omega
    have h2 : (s : ℝ) ≤ 4 * (t : ℝ) + 3 := by exact_mod_cast h1
    have h3 : (t : ℝ) = (c : ℝ) + 1 := by exact_mod_cast hc
    rw [h3] at h2
    linarith
  have hsqrt : Real.sqrt (l : ℝ) ≤ (s : ℝ) + 1 := by
    rw [Real.sqrt_le_iff]
    refine ⟨by positivity, ?_⟩
    have h1 : (l : ℝ) ≤ (((s + 1) ^ 2 : ℕ) : ℝ) := by exact_mod_cast hls.le
    push_cast at h1
    exact h1
  linarith

/-- **The literal asymptotic threshold statement** (MathDB 353552). -/
theorem tau_isTheta :
    (fun l : ℕ => (tau (K l) : ℝ)) =Θ[atTop] fun l : ℕ => Real.sqrt (l : ℝ) := by
  refine ⟨IsBigO.of_bound 4 ?_, IsBigO.of_bound 4 ?_⟩
  · filter_upwards [eventually_ge_atTop 1] with l hl
    rw [Real.norm_natCast, Real.norm_of_nonneg (Real.sqrt_nonneg _)]
    have hl1 : (1 : ℝ) ≤ l := by exact_mod_cast hl
    have hs1 : 1 ≤ Real.sqrt (l : ℝ) := by
      rw [Real.one_le_sqrt]
      exact hl1
    have hs2 : Real.sqrt (2 * (l : ℝ)) ≤ 2 * Real.sqrt (l : ℝ) := by
      rw [Real.sqrt_le_iff]
      refine ⟨by positivity, ?_⟩
      have h := Real.sq_sqrt (Nat.cast_nonneg l : (0 : ℝ) ≤ (l : ℝ))
      nlinarith
    have hτ : (tau (K l) : ℝ) ≤ ((max 4 ⌈(1 : ℝ) + Real.sqrt (2 * (l : ℝ))⌉₊ : ℕ) : ℝ) := by
      exact_mod_cast tau_le_kB l
    have hceil : ((⌈(1 : ℝ) + Real.sqrt (2 * (l : ℝ))⌉₊ : ℕ) : ℝ)
        ≤ 1 + Real.sqrt (2 * (l : ℝ)) + 1 :=
      (Nat.ceil_lt_add_one (by positivity)).le
    have hmaxR : ((max 4 ⌈(1 : ℝ) + Real.sqrt (2 * (l : ℝ))⌉₊ : ℕ) : ℝ) ≤ 4 * Real.sqrt (l : ℝ) := by
      push_cast
      refine max_le (by linarith) ?_
      linarith
    linarith
  · filter_upwards [eventually_ge_atTop 144] with l hl
    rw [Real.norm_of_nonneg (Real.sqrt_nonneg _), Real.norm_natCast]
    exact tau_lower hl

/-- The same statement for the actual `completeBipartiteGraph (Fin 2) (Fin l)`, for any
decidability instance of its adjacency relation. -/
theorem tau_completeBipartite_isTheta
    (inst : ∀ l : ℕ, DecidableRel (completeBipartiteGraph (Fin 2) (Fin l)).Adj) :
    (fun l : ℕ =>
        (@tau (Fin 2 ⊕ Fin l) _ _ (completeBipartiteGraph (Fin 2) (Fin l)) (inst l) : ℝ))
      =Θ[atTop] fun l : ℕ => Real.sqrt (l : ℝ) := by
  have h : ∀ l : ℕ, @tau (Fin 2 ⊕ Fin l) _ _ (completeBipartiteGraph (Fin 2) (Fin l)) (inst l)
      = tau (K l) := by
    intro l
    unfold K
    congr!
  simp only [h]
  exact tau_isTheta

end ListCol
