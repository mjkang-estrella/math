import ListColLowerExact

/-! Gate C / D audit (reviewer-authored): axioms of main theorems and fully elaborated statements. -/

#print axioms ListCol.tau_isTheta
#print axioms ListCol.tau_completeBipartite_isTheta
#print axioms ListCol.countL_ge
#print axioms ListCol.tau_le_kB
#print axioms ListCol.tau_set_nonempty
#print axioms ListCol.tau_lower
#print axioms ListCol.tau_gt_source

set_option pp.explicit true in
#check @ListCol.tau_isTheta

#check @ListCol.tau_isTheta
#check @ListCol.tau_completeBipartite_isTheta
#check @ListCol.countL_ge
#check @ListCol.tau_le_kB
#check @ListCol.tau_set_nonempty
#check @ListCol.tau_lower
#check @ListCol.tau_gt_source

#print ListCol.K
#print completeBipartiteGraph
#print ListCol.ListColorings
#print ListCol.countL
#print ListCol.chromaticPolynomial
#print ListCol.listColorFunction
#print ListCol.tau
#print SimpleGraph.chromaticNumber
#print Asymptotics.IsTheta
