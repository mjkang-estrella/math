import ListColWeights
import ListColAvg
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The miss-count lower bound and the case `k = 1`
-/

open scoped Classical
open Finset

namespace ListCol

/-- The total number of misses of the colours in `D`. -/
noncomputable def Delta {l : ℕ} (D : Finset ℕ) (S : Fin l → Finset ℕ) : ℝ :=
  ∑ x ∈ D, (missCount S x : ℝ)

lemma Delta_eq {l : ℕ} (D : Finset ℕ) (S : Fin l → Finset ℕ) :
    Delta D S = ∑ j : Fin l, ∑ x ∈ D, (u (S j) x : ℝ) := by
  unfold Delta
  calc ∑ x ∈ D, (missCount S x : ℝ)
      = ∑ x ∈ D, ∑ j : Fin l, (u (S j) x : ℝ) := by
        refine Finset.sum_congr rfl (fun x _ => ?_)
        rw [← sum_u l S x]
        push_cast
        rfl
    _ = ∑ j : Fin l, ∑ x ∈ D, (u (S j) x : ℝ) := Finset.sum_comm

lemma Delta_nonneg {l : ℕ} (D : Finset ℕ) (S : Fin l → Finset ℕ) : 0 ≤ Delta D S :=
  Finset.sum_nonneg (fun _ _ => Nat.cast_nonneg _)

lemma sum_u_eq_card_sdiff (U S : Finset ℕ) : ∑ x ∈ U, u S x = (U \ S).card := by
  calc ∑ x ∈ U, u S x
      = ∑ x ∈ U, (if x ∉ S then 1 else 0) := Finset.sum_congr rfl (fun x _ => u_eq S x)
    _ = (U.filter (fun x => x ∉ S)).card := Finset.sum_boole _ _
    _ = (U \ S).card := by rw [filter_not_eq_sdiff]

/-- Every list misses at least `k` colours of `A ∪ B`. No containment hypothesis is used. -/
theorem miss_lower {m : ℕ} {A B S : Finset ℕ} (hA : A.card = m) (hB : B.card = m)
    (hS : S.card = m) :
    (A \ (A ∩ B)).card ≤ ∑ a ∈ A \ (A ∩ B), u S a + ∑ b ∈ B \ (A ∩ B), u S b + ∑ x ∈ A ∩ B, u S x := by
  have hDA : A ∩ B ⊆ A := Finset.inter_subset_left
  have hUeq : A ∪ B = (A \ (A ∩ B)) ∪ ((B \ (A ∩ B)) ∪ (A ∩ B)) := by
    ext x
    simp only [Finset.mem_union, Finset.mem_sdiff, Finset.mem_inter]
    tauto
  have hdis1 : Disjoint (B \ (A ∩ B)) (A ∩ B) := Finset.sdiff_disjoint
  have hdis2 : Disjoint (A \ (A ∩ B)) ((B \ (A ∩ B)) ∪ (A ∩ B)) := by
    rw [Finset.disjoint_left]
    intro x hx hx'
    simp only [Finset.mem_union, Finset.mem_sdiff, Finset.mem_inter] at hx hx'
    tauto
  have hsplit : ∑ x ∈ A ∪ B, u S x
      = ∑ a ∈ A \ (A ∩ B), u S a + ∑ b ∈ B \ (A ∩ B), u S b + ∑ x ∈ A ∩ B, u S x := by
    rw [hUeq, Finset.sum_union hdis2, Finset.sum_union hdis1, add_assoc]
  rw [← hsplit, sum_u_eq_card_sdiff]
  have h1 := Finset.le_card_sdiff S (A ∪ B)
  have h2 := Finset.card_union_add_card_inter A B
  have h3 : (A \ (A ∩ B)).card = A.card - (A ∩ B).card := Finset.card_sdiff_of_subset hDA
  have h4 : (A ∩ B).card ≤ A.card := Finset.card_le_card hDA
  omega

lemma u_of_mem {S : Finset ℕ} {x : ℕ} (h : x ∈ S) : u S x = 0 := by simp [u, h]

lemma u_of_not_mem {S : Finset ℕ} {x : ℕ} (h : x ∉ S) : u S x = 1 := by simp [u, h]

/-- The case `k = 1` of inequality (I). -/
theorem caseOne {t : ℝ} (ht : 3 ≤ t) {l m : ℕ} {S : Fin l → Finset ℕ}
    (hS : ∀ j, (S j).card = m) (hmt : t = (m : ℝ) - 1) (D : Finset ℕ) {a b : ℕ} (hab : a ≠ b)
    (hmiss : ∀ j, 1 ≤ u (S j) a + u (S j) b + ∑ x ∈ D, u (S j) x) :
    1 ≤ Delta D S / t + W t S a b := by
  have htpos : 0 < t := by linarith
  have hs := sPos ht
  have hm : (m : ℝ) = t + 1 := by rw [hmt]; ring
  obtain ⟨ind, hind⟩ : ∃ ind : Fin l → ℕ,
      ind = fun j => if a ∈ S j ∧ b ∈ S j then 1 else 0 := ⟨_, rfl⟩
  have hindj : ∀ j, ind j = if a ∈ S j ∧ b ∈ S j then 1 else 0 := by
    intro j
    rw [hind]
  have hfac : ∀ j : Fin l, (1 - 1 / t) ^ (ind j) ≤ (((((S j).erase a).erase b).card : ℝ) / t) := by
    intro j
    rw [card_real_off (hS j) hab, hm, hindj j]
    by_cases h : a ∈ S j ∧ b ∈ S j
    · have e : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 1 := by simp [h]
      rw [e, pow_one, u_of_mem h.1, u_of_mem h.2]
      apply le_of_eq
      field_simp
      push_cast
      ring
    · have e : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [h]
      rw [e, pow_zero]
      rw [le_div_iff₀ htpos]
      have hge : (1 : ℝ) ≤ (u (S j) a : ℝ) + (u (S j) b : ℝ) := by
        by_cases ha : a ∈ S j
        · have hb : b ∉ S j := fun hb => h ⟨ha, hb⟩
          rw [u_of_mem ha, u_of_not_mem hb]
          simp
        · rw [u_of_not_mem ha]
          have : (0 : ℝ) ≤ (u (S j) b : ℝ) := Nat.cast_nonneg _
          push_cast
          linarith
      linarith
  have hprod : (1 - 1 / t) ^ (∑ j : Fin l, ind j) ≤ W t S a b := by
    rw [← Finset.prod_pow_eq_pow_sum]
    exact prod_le_prod_nonneg Finset.univ (fun j _ => pow_nonneg hs.le _) (fun j _ => hfac j)
  have hbern := bernoulli_s ht (∑ j : Fin l, ind j)
  have hind_le : ∀ j, ind j ≤ ∑ x ∈ D, u (S j) x := by
    intro j
    rw [hindj j]
    by_cases h : a ∈ S j ∧ b ∈ S j
    · have := hmiss j
      rw [u_of_mem h.1, u_of_mem h.2] at this
      have e : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 1 := by simp [h]
      rw [e]
      omega
    · have e : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [h]
      rw [e]
      omega
  have hDelta : ((∑ j : Fin l, ind j : ℕ) : ℝ) ≤ Delta D S := by
    rw [Delta_eq]
    push_cast
    refine Finset.sum_le_sum (fun j _ => ?_)
    have := hind_le j
    exact_mod_cast this
  have hdiv : ((∑ j : Fin l, ind j : ℕ) : ℝ) / t ≤ Delta D S / t :=
    div_le_div_of_nonneg_right hDelta htpos.le
  linarith

end ListCol
