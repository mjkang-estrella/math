
import ListColBase
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-!
# Exact counts for `K_{2,l}`

The number of proper list colourings of `K_{2,l}` is a sum over the colours of the two
vertices of the size-`2` side, and the chromatic polynomial is
`m (m-1)^l + m (m-1) (m-2)^l`.
-/

open scoped Classical
open Finset

namespace ListCol

/-- The Finset of proper list colourings, as a filtered set of all colour choices. -/
noncomputable def coloringFinset (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) :
    Finset (∀ v : Fin 2 ⊕ Fin l, ↥(L v)) :=
  Finset.univ.filter (fun f => ∀ u v : Fin 2 ⊕ Fin l, (K l).Adj u v → (f u).val ≠ (f v).val)

lemma countL_eq_coloringFinset_card (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) :
    countL (K l) L = (coloringFinset l L).card := by
  unfold countL coloringFinset ListColorings
  exact Fintype.card_subtype _

/-- The colourings with the first vertex coloured `a` and the second coloured `b`. -/
noncomputable def fibre (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) (a b : Nat) :
    Finset (∀ v : Fin 2 ⊕ Fin l, ↥(L v)) :=
  (coloringFinset l L).filter (fun f => (f (Sum.inl 0)).val = a ∧ (f (Sum.inl 1)).val = b)

lemma fin2_if_mem (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) {a b : Nat}
    (ha : a ∈ L (Sum.inl 0)) (hb : b ∈ L (Sum.inl 1)) (i : Fin 2) :
    (if (i : Nat) = 0 then a else b) ∈ L (Sum.inl i) := by
  fin_cases i
  · simpa using ha
  · simpa using hb

lemma fin2_if_zero (a b : Nat) : (if ((0 : Fin 2) : Nat) = 0 then a else b) = a := by simp

lemma fin2_if_one (a b : Nat) : (if ((1 : Fin 2) : Nat) = 0 then a else b) = b := by simp

/-- With the colours of the two vertices of the size-`2` side fixed, a colouring is exactly a
choice from the doubly erased lists on the size-`l` side. -/
def fiberEquiv (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) (a b : Nat)
    (ha : a ∈ L (Sum.inl 0)) (hb : b ∈ L (Sum.inl 1)) :
    {f : ∀ v : Fin 2 ⊕ Fin l, ↥(L v) //
      (∀ u v, (K l).Adj u v → (f u).val ≠ (f v).val) ∧
      (f (Sum.inl 0)).val = a ∧ (f (Sum.inl 1)).val = b} ≃
    (∀ j : Fin l, ↥(((L (Sum.inr j)).erase a).erase b)) where
  toFun f j := by
    refine ⟨(f.1 (Sum.inr j)).val, ?_⟩
    refine Finset.mem_erase.mpr ⟨?_, Finset.mem_erase.mpr ⟨?_, (f.1 (Sum.inr j)).2⟩⟩
    · intro hxb
      exact f.2.1 (Sum.inr j) (Sum.inl 1) (K_adj_inr_inl l 1 j) (hxb.trans f.2.2.2.symm)
    · intro hxa
      exact f.2.1 (Sum.inr j) (Sum.inl 0) (K_adj_inr_inl l 0 j) (hxa.trans f.2.2.1.symm)
  invFun cs :=
    ⟨fun v =>
      match v with
      | Sum.inl i => ⟨if (i : Nat) = 0 then a else b, fin2_if_mem l L ha hb i⟩
      | Sum.inr j => ⟨(cs j).val,
          Finset.mem_of_mem_erase (Finset.mem_of_mem_erase (cs j).2)⟩,
     by
      intro u v huv
      rcases K_adj_cases l huv with ⟨i, j, rfl, rfl⟩ | ⟨i, j, rfl, rfl⟩
      · fin_cases i
        · simpa using Ne.symm (Finset.ne_of_mem_erase (Finset.mem_of_mem_erase (cs j).2))
        · simpa using Ne.symm (Finset.ne_of_mem_erase (cs j).2)
      · fin_cases i
        · simpa using Finset.ne_of_mem_erase (Finset.mem_of_mem_erase (cs j).2)
        · simpa using Finset.ne_of_mem_erase (cs j).2,
     by simp,
     by simp⟩
  left_inv f := by
    obtain ⟨g, hg1, hg2, hg3⟩ := f
    refine Subtype.ext ?_
    funext v
    rcases v with i | j
    · fin_cases i
      · refine Subtype.ext ?_
        simp
        exact hg2.symm
      · refine Subtype.ext ?_
        simp
        exact hg3.symm
    · exact Subtype.ext rfl
  right_inv cs := by
    funext j
    exact Subtype.ext rfl

lemma fibre_card (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) {a b : Nat}
    (ha : a ∈ L (Sum.inl 0)) (hb : b ∈ L (Sum.inl 1)) :
    (fibre l L a b).card = ∏ j : Fin l, (((L (Sum.inr j)).erase a).erase b).card := by
  have h1 : (fibre l L a b).card =
      (Finset.univ.filter (fun f : ∀ v : Fin 2 ⊕ Fin l, ↥(L v) =>
        (∀ u v, (K l).Adj u v → (f u).val ≠ (f v).val) ∧
        (f (Sum.inl 0)).val = a ∧ (f (Sum.inl 1)).val = b)).card := by
    congr 1
    ext f
    simp [fibre, coloringFinset, and_assoc]
  rw [h1, ← Fintype.card_subtype (fun f : ∀ v : Fin 2 ⊕ Fin l, ↥(L v) =>
        (∀ u v, (K l).Adj u v → (f u).val ≠ (f v).val) ∧
        (f (Sum.inl 0)).val = a ∧ (f (Sum.inl 1)).val = b)]
  rw [Fintype.card_congr (fiberEquiv l L a b ha hb)]
  rw [Fintype.card_pi]
  exact Finset.prod_congr rfl (fun j _ => Fintype.card_coe _)

lemma countL_K_eq_sum_fibre (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) :
    countL (K l) L = ∑ a ∈ L (Sum.inl 0), ∑ b ∈ L (Sum.inl 1), (fibre l L a b).card := by
  rw [countL_eq_coloringFinset_card]
  have hmaps1 : Set.MapsTo (fun f : ∀ v : Fin 2 ⊕ Fin l, ↥(L v) => (f (Sum.inl 0)).val)
      ↑(coloringFinset l L) ↑(L (Sum.inl 0)) := by
    intro f _
    exact (f (Sum.inl 0)).2
  rw [Finset.card_eq_sum_card_fiberwise hmaps1]
  refine Finset.sum_congr rfl (fun a ha => ?_)
  have hmaps2 : Set.MapsTo (fun f : ∀ v : Fin 2 ⊕ Fin l, ↥(L v) => (f (Sum.inl 1)).val)
      ↑((coloringFinset l L).filter (fun f => (f (Sum.inl 0)).val = a)) ↑(L (Sum.inl 1)) := by
    intro f _
    exact (f (Sum.inl 1)).2
  rw [Finset.card_eq_sum_card_fiberwise hmaps2]
  refine Finset.sum_congr rfl (fun b hb => ?_)
  congr 1
  ext f
  simp [fibre, and_assoc]

/-- Exact count of proper list colourings of `K_{2,l}`: sum over the colours of the two
vertices of the size-`2` side, each term a product over the lists on the size-`l` side. -/
theorem countL_K (l : Nat) (L : Fin 2 ⊕ Fin l → Finset Nat) :
    countL (K l) L = ∑ a ∈ L (Sum.inl 0), ∑ b ∈ L (Sum.inl 1),
        ∏ j : Fin l, (((L (Sum.inr j)).erase a).erase b).card := by
  rw [countL_K_eq_sum_fibre]
  exact Finset.sum_congr rfl (fun a ha =>
    Finset.sum_congr rfl (fun b hb => fibre_card l L ha hb))

lemma erase_erase_card_range (m : Nat) {a b : Nat} (ha : a ∈ Finset.range m)
    (hb : b ∈ Finset.range m) :
    (((Finset.range m).erase a).erase b).card = if a = b then m - 1 else m - 2 := by
  by_cases h : a = b
  · subst h
    have he : ((Finset.range m).erase a).erase a = (Finset.range m).erase a := by
      rw [Finset.erase_eq_self]
      exact Finset.notMem_erase a _
    rw [he, Finset.card_erase_of_mem ha, Finset.card_range]
    simp
  · have hb' : b ∈ (Finset.range m).erase a := Finset.mem_erase.mpr ⟨Ne.symm h, hb⟩
    rw [Finset.card_erase_of_mem hb', Finset.card_erase_of_mem ha, Finset.card_range]
    simp [h]
    omega

/-- The chromatic polynomial of `K_{2,l}`: `m (m-1)^l + m (m-1) (m-2)^l`. -/
theorem chromaticPolynomial_K (l m : Nat) :
    chromaticPolynomial (K l) m = m * (m - 1) ^ l + m * (m - 1) * (m - 2) ^ l := by
  unfold chromaticPolynomial
  rw [countL_K]
  have hinner : ∀ a ∈ Finset.range m, ∀ b ∈ Finset.range m,
      (∏ j : Fin l, (((Finset.range m).erase a).erase b).card)
        = (if a = b then m - 1 else m - 2) ^ l := by
    intro a ha b hb
    rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
    congr 1
    exact erase_erase_card_range m ha hb
  rw [Finset.sum_congr rfl (fun a ha =>
    Finset.sum_congr rfl (fun b hb => hinner a ha b hb))]
  have hstep : ∀ a ∈ Finset.range m,
      (∑ b ∈ Finset.range m, (if a = b then m - 1 else m - 2) ^ l)
        = (m - 1) ^ l + (m - 1) * (m - 2) ^ l := by
    intro a ha
    rw [← Finset.add_sum_erase (Finset.range m)
      (fun b => (if a = b then m - 1 else m - 2) ^ l) ha]
    have h1 : (if a = a then m - 1 else m - 2) ^ l = (m - 1) ^ l := by simp
    have h2 : (∑ b ∈ (Finset.range m).erase a, (if a = b then m - 1 else m - 2) ^ l)
        = (m - 1) * (m - 2) ^ l := by
      have hc : ∀ b ∈ (Finset.range m).erase a,
          (if a = b then m - 1 else m - 2) ^ l = (m - 2) ^ l := by
        intro b hb
        have hne : ¬ (a = b) := Ne.symm (Finset.ne_of_mem_erase hb)
        simp [hne]
      rw [Finset.sum_congr rfl hc, Finset.sum_const, Finset.card_erase_of_mem ha,
        Finset.card_range]
      simp
    rw [h1, h2]
  rw [Finset.sum_congr rfl hstep, Finset.sum_const, Finset.card_range]
  simp
  ring

end ListCol
