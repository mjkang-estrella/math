import ListColEndpoint
import Mathlib.Combinatorics.SimpleGraph.Coloring.Vertex
import Mathlib.Data.Finset.Image
import Mathlib.Logic.Equiv.Basic

/-! Gate D/E (reviewer-authored): bridges from the packet's definitions to mathlib colourings,
arbitrary colour types, instance independence, and an unpacked form of the IsTheta. -/

open scoped Classical
open Asymptotics Filter

namespace ReviewerControls
open ListCol

/-- `P(G,m)` (packet) is mathlib's number of proper colourings of `G` with colours `Fin m`. -/
noncomputable def coloringEquiv {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (m : ℕ) :
    ListColorings G (fun _ => Finset.range m) ≃ G.Coloring (Fin m) where
  toFun f := SimpleGraph.Coloring.mk
    (fun v => ⟨(f.1 v).val, Finset.mem_range.mp (f.1 v).2⟩)
    (fun {u v} h heq => f.2 u v h (congrArg Fin.val heq))
  invFun C := ⟨fun v => ⟨(C v).val, Finset.mem_range.mpr (C v).isLt⟩,
    fun _ _ h heq => C.valid h (Fin.ext heq)⟩
  left_inv f := by
    apply Subtype.ext
    funext v
    apply Subtype.ext
    rfl
  right_inv C := by
    apply DFunLike.ext
    intro v
    apply Fin.ext
    rfl

theorem chromaticPolynomial_eq_card_coloring {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (m : ℕ) [Fintype (G.Coloring (Fin m))] :
    chromaticPolynomial G m = Fintype.card (G.Coloring (Fin m)) := by
  unfold chromaticPolynomial countL
  exact Fintype.card_congr (coloringEquiv G m)

/-- List colourings with colours in an arbitrary type. -/
def ListColoringsC {V : Type*} {C : Type*} (G : SimpleGraph V) (L : V → Finset C) : Type _ :=
  {f : ∀ v : V, ↥(L v) // ∀ u v : V, G.Adj u v → (f u).val ≠ (f v).val}

/-- Any list assignment with colours in an arbitrary type can be relabelled into `ℕ`, preserving
every list size and the set of proper colourings. -/
theorem relabel {V : Type*} [Fintype V] [DecidableEq V] {C : Type*} [DecidableEq C]
    (G : SimpleGraph V) [DecidableRel G.Adj] (L : V → Finset C) :
    ∃ L' : V → Finset ℕ, (∀ v, (L' v).card = (L v).card) ∧
      Nonempty (ListColoringsC G L ≃ ListColorings G L') := by
  let U : Finset C := Finset.univ.biUnion L
  let e : U ≃ Fin U.card := U.equivFin
  let g : C → ℕ := fun c => if h : c ∈ U then (e ⟨c, h⟩).val else 0
  have hmem : ∀ v c, c ∈ L v → c ∈ U := fun v c hc =>
    Finset.mem_biUnion.mpr ⟨v, Finset.mem_univ v, hc⟩
  have gval : ∀ c (h : c ∈ U), g c = (e ⟨c, h⟩).val := by
    intro c h
    show (if h' : c ∈ U then (e ⟨c, h'⟩).val else 0) = (e ⟨c, h⟩).val
    split
    · rfl
    · contradiction
  have ginj : ∀ a ∈ U, ∀ b ∈ U, g a = g b → a = b := by
    intro a ha b hb hab
    rw [gval a ha, gval b hb] at hab
    have h := e.injective (Fin.ext hab)
    exact congrArg Subtype.val h
  have hbij : ∀ v, Function.Bijective
      (fun x : ↥(L v) => (⟨g x.1, Finset.mem_image_of_mem g x.2⟩ : ↥((L v).image g))) := by
    intro v
    constructor
    · intro a b hab
      have h : g a.1 = g b.1 := congrArg Subtype.val hab
      exact Subtype.ext (ginj _ (hmem v _ a.2) _ (hmem v _ b.2) h)
    · rintro ⟨y, hy⟩
      obtain ⟨c, hc, rfl⟩ := Finset.mem_image.mp hy
      exact ⟨⟨c, hc⟩, rfl⟩
  let hv : ∀ v, ↥(L v) ≃ ↥((L v).image g) := fun v => Equiv.ofBijective _ (hbij v)
  refine ⟨fun v => (L v).image g, fun v => ?_, ?_⟩
  · refine Finset.card_image_of_injOn ?_
    intro a ha b hb hab
    exact ginj _ (hmem v _ (Finset.mem_coe.mp ha)) _ (hmem v _ (Finset.mem_coe.mp hb)) hab
  · refine ⟨?_⟩
    unfold ListColoringsC ListColorings
    refine (Equiv.piCongrRight hv).subtypeEquiv ?_
    intro f
    constructor
    · intro hf u v huv heq
      have heq' : g (f u).1 = g (f v).1 := heq
      exact hf u v huv (ginj _ (hmem u _ (f u).2) _ (hmem v _ (f v).2) heq')
    · intro hf u v huv heq
      refine hf u v huv ?_
      change g (f u).1 = g (f v).1
      rw [heq]

/-- The minimum over `ℕ`-coloured `m`-assignments is a lower bound for the count of an
`m`-assignment with colours in any type, so `ℕ` colours lose nothing for `P_ℓ`. -/
theorem listColorFunction_le_any {V : Type*} [Fintype V] [DecidableEq V] {C : Type*} [DecidableEq C]
    (G : SimpleGraph V) [DecidableRel G.Adj] {m : ℕ} (L : V → Finset C) (hL : ∀ v, (L v).card = m)
    [Fintype (ListColoringsC G L)] :
    listColorFunction G m ≤ Fintype.card (ListColoringsC G L) := by
  obtain ⟨L', hc, ⟨e⟩⟩ := relabel G L
  have h : Fintype.card (ListColoringsC G L) = countL G L' := by
    unfold countL
    exact Fintype.card_congr e
  rw [h]
  exact listColorFunction_le_countL G L' (fun v => (hc v).trans (hL v))

/-- `τ` does not depend on any of its instance arguments. -/
theorem tau_congr {V : Type*} (G : SimpleGraph V) (i1 i2 : Fintype V) (d1 d2 : DecidableEq V)
    (r1 r2 : DecidableRel G.Adj) : @tau V i1 d1 G r1 = @tau V i2 d2 G r2 := by
  have e1 : i1 = i2 := Subsingleton.elim _ _
  have e2 : d1 = d2 := by
    funext a b
    exact Subsingleton.elim _ _
  have e3 : r1 = r2 := by
    funext a b
    exact Subsingleton.elim _ _
  subst e1
  subst e2
  subst e3
  rfl

/-- The IsTheta endpoint, unpacked into two-sided eventual bounds with positive constants. -/
theorem theta_unpacked :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ l : ℕ in atTop,
      c * Real.sqrt (l : ℝ) ≤ (tau (K l) : ℝ) ∧ (tau (K l) : ℝ) ≤ C * Real.sqrt (l : ℝ) := by
  have h := tau_isTheta
  obtain ⟨c₁, hc₁, h₁⟩ := h.1.exists_pos
  obtain ⟨c₂, hc₂, h₂⟩ := h.2.exists_pos
  refine ⟨c₂⁻¹, c₁, inv_pos.mpr hc₂, hc₁, ?_⟩
  filter_upwards [h₁.bound, h₂.bound] with l h1 h2
  rw [Real.norm_natCast, Real.norm_of_nonneg (Real.sqrt_nonneg _)] at h1
  rw [Real.norm_of_nonneg (Real.sqrt_nonneg _), Real.norm_natCast] at h2
  constructor
  · rw [inv_mul_le_iff₀ hc₂]
    exact h2
  · exact h1

end ReviewerControls

#print axioms ReviewerControls.chromaticPolynomial_eq_card_coloring
#print axioms ReviewerControls.relabel
#print axioms ReviewerControls.listColorFunction_le_any
#print axioms ReviewerControls.tau_congr
#print axioms ReviewerControls.theta_unpacked
