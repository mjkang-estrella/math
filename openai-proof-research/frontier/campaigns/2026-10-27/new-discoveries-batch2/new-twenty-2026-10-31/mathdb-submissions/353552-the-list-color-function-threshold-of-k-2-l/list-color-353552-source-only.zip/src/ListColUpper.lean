import ListColBase
import ListColCount
import Mathlib.Data.Nat.Cast.Order.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.MeanInequalities
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.IntervalCases
import Mathlib.Tactic.NormNum

/-!
# The main inequality for `K_{2,l}` (upper bound on `tau`)

Weights and exact factorisations used in the proof that for `m >= 4` and `2l <= (m-1)^2`
every `m`-assignment of `K_{2,l}` has at least `P(K_{2,l}, m)` proper list colourings.
-/

open scoped Classical
open Finset

namespace ListCol

/-! ## 1. Missing-colour indicators and exact card identities -/

/-- `1` if `x` is missing from `S`, `0` otherwise. -/
def u (S : Finset Nat) (x : Nat) : Nat := if x ∈ S then 0 else 1

lemma u_le_one (S : Finset Nat) (x : Nat) : u S x ≤ 1 := by
  unfold u; split <;> omega

lemma u_eq (S : Finset Nat) (x : Nat) : u S x = if x ∉ S then 1 else 0 := by
  unfold u; by_cases h : x ∈ S <;> simp [h]

lemma card_erase_eq (S : Finset Nat) (a : Nat) :
    (S.erase a).card = S.card - (if a ∈ S then 1 else 0) := by
  rw [Finset.card_erase_eq_ite]
  by_cases ha : a ∈ S <;> simp [ha]

lemma card_erase_add (S : Finset Nat) (a : Nat) :
    (S.erase a).card + 1 = S.card + u S a := by
  rw [card_erase_eq]
  by_cases ha : a ∈ S
  · have hpos : 0 < S.card := Finset.card_pos.mpr ⟨a, ha⟩
    simp [u, ha]
    omega
  · simp [u, ha]

lemma card_erase_erase_add (S : Finset Nat) (a b : Nat) (hab : a ≠ b) :
    ((S.erase a).erase b).card + 2 = S.card + u S a + u S b := by
  have hbne : b ≠ a := fun h => hab h.symm
  by_cases ha : a ∈ S <;> by_cases hb : b ∈ S
  · have hb' : b ∈ S.erase a := Finset.mem_erase.mpr ⟨hbne, hb⟩
    have h1 : ((S.erase a).erase b).card = (S.erase a).card - 1 := Finset.card_erase_of_mem hb'
    have h2 : (S.erase a).card = S.card - 1 := Finset.card_erase_of_mem ha
    have hp1 : 0 < S.card := Finset.card_pos.mpr ⟨a, ha⟩
    have hp2 : 0 < (S.erase a).card := Finset.card_pos.mpr ⟨b, hb'⟩
    rw [h1, h2]; simp [u, ha, hb]; omega
  · have hb' : b ∉ S.erase a := fun h => hb (Finset.mem_erase.mp h).2
    have he : (S.erase a).erase b = S.erase a := by
      rw [Finset.erase_eq_self]; exact hb'
    have h1 : ((S.erase a).erase b).card = (S.erase a).card := by rw [he]
    have h2 : (S.erase a).card = S.card - 1 := Finset.card_erase_of_mem ha
    have hp1 : 0 < S.card := Finset.card_pos.mpr ⟨a, ha⟩
    rw [h1, h2]; simp [u, ha, hb]; omega
  · have hb' : b ∈ S.erase a := Finset.mem_erase.mpr ⟨hbne, hb⟩
    have h1 : ((S.erase a).erase b).card = (S.erase a).card - 1 := Finset.card_erase_of_mem hb'
    have he : S.erase a = S := by
      rw [Finset.erase_eq_self]; exact ha
    have h2 : (S.erase a).card = S.card := by rw [he]
    have hp2 : 0 < (S.erase a).card := Finset.card_pos.mpr ⟨b, hb'⟩
    rw [h1, h2]; simp [u, ha, hb]; omega
  · have hb' : b ∉ S.erase a := fun h => hb (Finset.mem_erase.mp h).2
    have he : (S.erase a).erase b = S.erase a := by
      rw [Finset.erase_eq_self]; exact hb'
    have h1 : ((S.erase a).erase b).card = (S.erase a).card := by rw [he]
    have he2 : S.erase a = S := by
      rw [Finset.erase_eq_self]; exact ha
    have h2 : (S.erase a).card = S.card := by rw [he2]
    rw [h1, h2]; simp [u, ha, hb]

/-! ## 2. The normalising weights -/

noncomputable def mq (m : Nat) : Real := ((m:Real) - 1) / ((m:Real) - 2)
noncomputable def mr (m : Nat) : Real := ((m:Real) * ((m:Real) - 2)) / (((m:Real) - 1) ^ 2)
noncomputable def mt0 (m : Nat) : Real := (m:Real) / ((m:Real) - 1)

lemma mR_ge (m : Nat) (hm : 4 ≤ m) : (4:Real) ≤ (m:Real) := by exact_mod_cast hm

lemma m2pos (m : Nat) (hm : 4 ≤ m) : (0:Real) < (m:Real) - 2 := by
  have := mR_ge m hm; linarith

lemma m1pos (m : Nat) (hm : 4 ≤ m) : (0:Real) < (m:Real) - 1 := by
  have := mR_ge m hm; linarith

lemma mq_pos (m : Nat) (hm : 4 ≤ m) : 0 < mq m := by
  unfold mq; exact div_pos (m1pos m hm) (m2pos m hm)

lemma mr_pos (m : Nat) (hm : 4 ≤ m) : 0 < mr m := by
  unfold mr
  apply div_pos
  · nlinarith [mR_ge m hm]
  · exact pow_pos (m1pos m hm) 2

lemma mt0_pos (m : Nat) (hm : 4 ≤ m) : 0 < mt0 m := by
  unfold mt0; exact div_pos (by linarith [mR_ge m hm]) (m1pos m hm)

lemma mq_ge_one (m : Nat) (hm : 4 ≤ m) : 1 ≤ mq m := by
  unfold mq
  rw [le_div_iff₀ (m2pos m hm)]
  linarith [mR_ge m hm]

lemma mr_le_one (m : Nat) (hm : 4 ≤ m) : mr m ≤ 1 := by
  unfold mr
  rw [div_le_one (pow_pos (m1pos m hm) 2)]
  nlinarith [mR_ge m hm]

lemma mt0_ge_one (m : Nat) (hm : 4 ≤ m) : 1 ≤ mt0 m := by
  unfold mt0
  rw [le_div_iff₀ (m1pos m hm)]
  linarith [mR_ge m hm]

lemma mq_mul (m : Nat) (hm : 4 ≤ m) : ((m:Real) - 2) * mq m = (m:Real) - 1 := by
  unfold mq
  have h : ((m:Real) - 2) ≠ 0 := ne_of_gt (m2pos m hm)
  field_simp

lemma mq_sq_mr (m : Nat) (hm : 4 ≤ m) :
    ((m:Real) - 2) * mq m * mq m * mr m = (m:Real) := by
  unfold mq mr
  have h2 : ((m:Real) - 2) ≠ 0 := ne_of_gt (m2pos m hm)
  have h1 : ((m:Real) - 1) ≠ 0 := ne_of_gt (m1pos m hm)
  field_simp

lemma mq_mr (m : Nat) (hm : 4 ≤ m) : mq m * mr m = mt0 m := by
  unfold mq mr mt0
  have h2 : ((m:Real) - 2) ≠ 0 := ne_of_gt (m2pos m hm)
  have h1 : ((m:Real) - 1) ≠ 0 := ne_of_gt (m1pos m hm)
  field_simp

/-! ## 3. Per-list factor identities -/

lemma factor_off (m : Nat) (hm : 4 ≤ m) (u v : Nat) (hu : u ≤ 1) (hv : v ≤ 1) :
    ((m:Real) - 2) + (u:Real) + (v:Real)
      = ((m:Real) - 2) * mq m ^ u * mq m ^ v * mr m ^ (u * v) := by
  interval_cases u <;> interval_cases v
  · simp
  · simp; rw [mq_mul m hm]; ring
  · simp; rw [mq_mul m hm]; ring
  · simp; rw [mq_sq_mr m hm]; ring

lemma factor_diag (m : Nat) (hm : 4 ≤ m) (u : Nat) (hu : u ≤ 1) :
    ((m:Real) - 1) + (u:Real) = ((m:Real) - 2) * mq m * mt0 m ^ u := by
  interval_cases u
  · simp; exact (mq_mul m hm).symm
  · simp
    rw [mq_mul m hm]
    unfold mt0
    have h : ((m:Real) - 1) ≠ 0 := ne_of_gt (m1pos m hm)
    field_simp

/-! ## 4. Missing counts and the exact factorisation of a single term -/

noncomputable def missCount {l : Nat} (S : Fin l → Finset Nat) (x : Nat) : Nat :=
  (Finset.univ.filter (fun j => x ∉ S j)).card

noncomputable def jointMiss {l : Nat} (S : Fin l → Finset Nat) (a b : Nat) : Nat :=
  (Finset.univ.filter (fun j => a ∉ S j ∧ b ∉ S j)).card

lemma sum_u (l : Nat) (S : Fin l → Finset Nat) (a : Nat) :
    (∑ j : Fin l, u (S j) a) = missCount S a := by
  rw [missCount]
  calc (∑ j : Fin l, u (S j) a)
      = ∑ j : Fin l, (if a ∉ S j then 1 else 0) := by
        refine Finset.sum_congr rfl (fun j _ => u_eq (S j) a)
    _ = (Finset.univ.filter (fun j => a ∉ S j)).card := Finset.sum_boole _ _

lemma sum_uu (l : Nat) (S : Fin l → Finset Nat) (a b : Nat) :
    (∑ j : Fin l, u (S j) a * u (S j) b) = jointMiss S a b := by
  rw [jointMiss]
  calc (∑ j : Fin l, u (S j) a * u (S j) b)
      = ∑ j : Fin l, (if (a ∉ S j ∧ b ∉ S j) then 1 else 0) := by
        refine Finset.sum_congr rfl (fun j _ => ?_)
        by_cases ha : a ∈ S j <;> by_cases hb : b ∈ S j <;> simp [u, ha, hb]
    _ = (Finset.univ.filter (fun j => a ∉ S j ∧ b ∉ S j)).card := Finset.sum_boole _ _

/-- Exact value of one off-diagonal term, normalised by `(m-2)^l`. -/
theorem prod_off (m l : Nat) (hm : 4 ≤ m) (S : Fin l → Finset Nat)
    (hcard : ∀ j, (S j).card = m) (a b : Nat) (hab : a ≠ b) :
    ((∏ j : Fin l, (((S j).erase a).erase b).card : Nat) : Real)
      = ((m:Real) - 2) ^ l * mq m ^ (missCount S a + missCount S b)
          * mr m ^ (jointMiss S a b) := by
  rw [Nat.cast_prod]
  have h1 : ∀ j : Fin l, ((((S j).erase a).erase b).card : Real)
      = ((m:Real) - 2) + (u (S j) a : Real) + (u (S j) b : Real) := by
    intro j
    have h := card_erase_erase_add (S j) a b hab
    rw [hcard j] at h
    have h' : ((((S j).erase a).erase b).card : Real) + 2
        = (m:Real) + (u (S j) a : Real) + (u (S j) b : Real) := by
      have hc := congrArg (Nat.cast : Nat → Real) h
      push_cast at hc
      exact hc
    linarith
  rw [Finset.prod_congr rfl (fun j _ => h1 j)]
  have h2 : ∀ j : Fin l, ((m:Real) - 2) + (u (S j) a : Real) + (u (S j) b : Real)
      = ((m:Real) - 2) * mq m ^ (u (S j) a) * mq m ^ (u (S j) b)
          * mr m ^ (u (S j) a * u (S j) b) := by
    intro j
    exact factor_off m hm (u (S j) a) (u (S j) b) (u_le_one (S j) a) (u_le_one (S j) b)
  rw [Finset.prod_congr rfl (fun j _ => h2 j)]
  rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib, Finset.prod_mul_distrib]
  simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
  rw [Finset.prod_pow_eq_pow_sum, Finset.prod_pow_eq_pow_sum, Finset.prod_pow_eq_pow_sum]
  rw [sum_u, sum_u, sum_uu]
  ring

/-- Exact value of one diagonal term, normalised by `(m-2)^l`. -/
theorem prod_diag (m l : Nat) (hm : 4 ≤ m) (S : Fin l → Finset Nat)
    (hcard : ∀ j, (S j).card = m) (a : Nat) :
    ((∏ j : Fin l, ((S j).erase a).card : Nat) : Real)
      = ((m:Real) - 2) ^ l * mq m ^ l * mt0 m ^ (missCount S a) := by
  rw [Nat.cast_prod]
  have h1 : ∀ j : Fin l, (((S j).erase a).card : Real)
      = ((m:Real) - 1) + (u (S j) a : Real) := by
    intro j
    have h := card_erase_add (S j) a
    rw [hcard j] at h
    have h' : (((S j).erase a).card : Real) + 1 = (m:Real) + (u (S j) a : Real) := by
      have hc := congrArg (Nat.cast : Nat → Real) h
      push_cast at hc
      exact hc
    linarith
  rw [Finset.prod_congr rfl (fun j _ => h1 j)]
  have h2 : ∀ j : Fin l, ((m:Real) - 1) + (u (S j) a : Real)
      = ((m:Real) - 2) * mq m * mt0 m ^ (u (S j) a) := by
    intro j
    exact factor_diag m hm (u (S j) a) (u_le_one (S j) a)
  rw [Finset.prod_congr rfl (fun j _ => h2 j)]
  rw [Finset.prod_mul_distrib, Finset.prod_mul_distrib]
  simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
  rw [Finset.prod_pow_eq_pow_sum]
  rw [sum_u]

end ListCol
