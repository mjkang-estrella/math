import ListColLowerBounds
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The lower bound on `τ(K_{2,l})` (source Theorem 4, reproved with explicit crude constants)

The balanced assignment of `badL` has fewer than `P(K_{2,l}, c+2)` proper list colourings once
`4 (c+1)^2 ≤ l / 4`, so the list colour function differs from the chromatic polynomial there.
-/

open scoped Classical
open Finset

namespace ListCol

/-- The balanced assignment as a list assignment of `K_{2,l}`. -/
noncomputable def badL (c l : ℕ) : Fin 2 ⊕ Fin l → Finset ℕ :=
  Sum.elim (fun i => if i = 0 then Finset.range (c + 2) else badB c) (fun j => badS c j)

lemma card_badL (c l : ℕ) (v : Fin 2 ⊕ Fin l) : (badL c l v).card = c + 2 := by
  rcases v with i | j
  · fin_cases i
    · simp [badL, Finset.card_range]
    · simp [badL, card_badB]
  · simpa [badL] using card_badS c j

/-- The normalised count of the balanced assignment is strictly below the target value. -/
theorem bad_sum_lt {c l : ℕ} {t : ℝ} (hc : 2 ≤ c) (htc : t = (c : ℝ) + 1)
    (hT : 4 * (c + 1) ^ 2 ≤ l / 4) :
    (∑ a ∈ Finset.range (c + 2), ∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
      < (((c + 2 : ℕ) : ℝ)) + (((c + 2 : ℕ) : ℝ)) * t * (1 - 1 / t) ^ l := by
  have hcR : (2 : ℝ) ≤ c := by exact_mod_cast hc
  have ht : 3 ≤ t := by rw [htc]; linarith
  have htpos : 0 < t := by linarith
  have hmt : t = ((c + 2 : ℕ) : ℝ) - 1 := by
    push_cast
    rw [htc]
    ring
  have hm : ((c + 2 : ℕ) : ℝ) = (c : ℝ) + 2 := by
    push_cast
    ring
  have hs := sPos ht
  have hq := qPos ht
  obtain ⟨y, hy⟩ : ∃ y : ℝ, y = (1 - 1 / t) ^ l := ⟨_, rfl⟩
  obtain ⟨E, hE⟩ : ∃ E : ℝ, E = (1 - 1 / t) ^ (2 * (l / 4)) := ⟨_, rfl⟩
  obtain ⟨R, hR⟩ : ∃ R : ℝ, R = (1 - 1 / t) ^ (l / 4) * (1 + 1 / t) ^ (l / 4 + 1) := ⟨_, rfl⟩
  have hy0 : 0 ≤ y := by rw [hy]; exact pow_nonneg hs.le _
  have hTR : 4 * t ^ 2 ≤ ((l / 4 : ℕ) : ℝ) := by
    have h : ((4 * (c + 1) ^ 2 : ℕ) : ℝ) ≤ ((l / 4 : ℕ) : ℝ) := by exact_mod_cast hT
    rw [htc]
    push_cast at h
    exact h
  have hnum : 4 * (c : ℝ) * E + 4 * R ≤ 1 / 2 + 16 / 15 := by
    rw [hE, hR]
    exact bad_numeric ht hTR (Nat.cast_nonneg c) (by rw [htc]; linarith)
  -- pair bounds
  have hLL : ∀ a ∈ Finset.range c, ∀ b ∈ Finset.range c,
      W t (badS c : Fin l → Finset ℕ) a b ≤ y + (if a = b then 1 - y else 0) := by
    intro a ha b hb
    have ha' := Finset.mem_range.mp ha
    have hb' := Finset.mem_range.mp hb
    by_cases hab : a = b
    · subst hab
      have h1 : W t (badS c : Fin l → Finset ℕ) a a = 1 :=
        W_diag_of_all_mem ht (fun j => card_badS c j) hmt (fun j => bad_low c j ha')
      rw [h1]
      simp
    · have h1 : W t (badS c : Fin l → Finset ℕ) a b = y := by
        rw [hy]
        exact W_low_low ht hmt ha' hb' hab
      rw [h1]
      simp [hab]
  have hBsplit : ∀ F : ℕ → ℝ, ∑ b ∈ badB c, F b = F (c + 2) + (F (c + 3) + ∑ b ∈ Finset.range c, F b) := by
    intro F
    unfold badB
    rw [Finset.sum_insert, Finset.sum_insert]
    · simp
    · simp only [Finset.mem_insert, Finset.mem_range]
      omega
  have hGlow : ∀ a ∈ Finset.range c, (∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
      ≤ 2 * E + ((c : ℝ) * y + (1 - y)) := by
    intro a ha
    have ha' := Finset.mem_range.mp ha
    have h1 : W t (badS c : Fin l → Finset ℕ) a (c + 2) ≤ E := by
      rw [hE]
      exact W_low_specB ht hmt ha' (β := 0) (by norm_num)
    have h2 : W t (badS c : Fin l → Finset ℕ) a (c + 3) ≤ E := by
      rw [hE]
      exact W_low_specB ht hmt ha' (β := 1) (by norm_num)
    have h3 : (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) a b)
        ≤ (c : ℝ) * y + (1 - y) := by
      calc (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) a b)
          ≤ ∑ b ∈ Finset.range c, (y + (if a = b then 1 - y else 0)) :=
            Finset.sum_le_sum (fun b hb => hLL a ha b hb)
        _ = (c : ℝ) * y + (1 - y) := by
            rw [Finset.sum_add_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul]
            have hite : (∑ b ∈ Finset.range c, (if a = b then 1 - y else 0)) = 1 - y := by
              simp [Finset.sum_ite_eq, ha']
            rw [hite]
    rw [hBsplit]
    linarith
  have hGspec : ∀ α, α < 2 → (∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) (c + α) b)
      ≤ 2 * R + (c : ℝ) * E := by
    intro α hα
    have h1 : W t (badS c : Fin l → Finset ℕ) (c + α) (c + 2) ≤ R := by
      rw [hR]
      exact W_spec_spec ht hmt hα (β := 0) (by norm_num)
    have h2 : W t (badS c : Fin l → Finset ℕ) (c + α) (c + 3) ≤ R := by
      rw [hR]
      exact W_spec_spec ht hmt hα (β := 1) (by norm_num)
    have h3 : (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) (c + α) b) ≤ (c : ℝ) * E := by
      calc (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) (c + α) b)
          ≤ ∑ _b ∈ Finset.range c, E := by
            refine Finset.sum_le_sum (fun b hb => ?_)
            rw [hE]
            exact W_specA_low ht hmt hα (Finset.mem_range.mp hb)
        _ = (c : ℝ) * E := by
            rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
    rw [hBsplit]
    linarith
  have hGc : (∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) c b) ≤ 2 * R + (c : ℝ) * E :=
    hGspec 0 (by norm_num)
  have hGc1 : (∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) (c + 1) b) ≤ 2 * R + (c : ℝ) * E :=
    hGspec 1 (by norm_num)
  have hlow : (∑ a ∈ Finset.range c, ∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
      ≤ (c : ℝ) * (2 * E + ((c : ℝ) * y + (1 - y))) := by
    calc (∑ a ∈ Finset.range c, ∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
        ≤ ∑ _a ∈ Finset.range c, (2 * E + ((c : ℝ) * y + (1 - y))) :=
          Finset.sum_le_sum hGlow
      _ = (c : ℝ) * (2 * E + ((c : ℝ) * y + (1 - y))) := by
          rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  rw [Finset.sum_range_succ, Finset.sum_range_succ, ← hy]
  have hkey : (((c + 2 : ℕ) : ℝ)) + (((c + 2 : ℕ) : ℝ)) * t * y
      - ((c : ℝ) * (2 * E + ((c : ℝ) * y + (1 - y))) + (2 * R + (c : ℝ) * E) + (2 * R + (c : ℝ) * E))
      = 2 + (4 * (c : ℝ) + 2) * y - (4 * (c : ℝ) * E + 4 * R) := by
    rw [hm, htc]
    ring
  have hpos : 0 ≤ (4 * (c : ℝ) + 2) * y := mul_nonneg (by linarith) hy0
  linarith

/-- Strict inequality for the list colour function. -/
theorem listColorFunction_lt {l c : ℕ} (hc : 2 ≤ c) (hT : 4 * (c + 1) ^ 2 ≤ l / 4) :
    listColorFunction (K l) (c + 2) < chromaticPolynomial (K l) (c + 2) := by
  obtain ⟨t, ht⟩ : ∃ t : ℝ, t = (c : ℝ) + 1 := ⟨_, rfl⟩
  have hcR : (2 : ℝ) ≤ c := by exact_mod_cast hc
  have htpos : 0 < t := by rw [ht]; linarith
  have hsum := bad_sum_lt (l := l) hc ht hT
  have hle : listColorFunction (K l) (c + 2) ≤ countL (K l) (badL c l) :=
    listColorFunction_le_countL (K l) (badL c l) (card_badL c l)
  refine lt_of_le_of_lt hle ?_
  rw [chromaticPolynomial_K, countL_K]
  have h0 : badL c l (Sum.inl 0) = Finset.range (c + 2) := by simp [badL]
  have h1 : badL c l (Sum.inl 1) = badB c := by simp [badL]
  rw [h0, h1]
  have hS : (∑ a ∈ Finset.range (c + 2), ∑ b ∈ badB c,
        ∏ j : Fin l, (((badL c l (Sum.inr j)).erase a).erase b).card)
      = ∑ a ∈ Finset.range (c + 2), ∑ b ∈ badB c,
        ∏ j : Fin l, (((badS c j).erase a).erase b).card := rfl
  rw [hS]
  have hmt : t = ((c + 2 : ℕ) : ℝ) - 1 := by
    push_cast
    rw [ht]
    ring
  rw [← Nat.cast_lt (α := ℝ), count_real htpos.ne', poly_real (by omega) hmt]
  exact mul_lt_mul_of_pos_left hsum (pow_pos htpos l)

end ListCol
