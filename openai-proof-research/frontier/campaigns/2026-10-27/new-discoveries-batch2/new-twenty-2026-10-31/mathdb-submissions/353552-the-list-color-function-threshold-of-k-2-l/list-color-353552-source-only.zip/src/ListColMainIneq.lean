import ListColCaseTwo
import ListColMainP
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The main inequality

For `m ≥ 4` and `2 l ≤ (m - 1) ^ 2`, every `m`-assignment of `K_{2,l}` has at least
`P(K_{2,l}, m)` proper list colourings. No hypothesis restricting the lists is used.
-/

open scoped Classical
open Finset

namespace ListCol

/-- The normalised main inequality for an arbitrary assignment. -/
theorem main_real {t : ℝ} {l m : ℕ} (hm : 4 ≤ m) (hmt : t = (m : ℝ) - 1)
    (hl : 2 * (l : ℝ) ≤ t ^ 2) {A B : Finset ℕ} {S : Fin l → Finset ℕ}
    (hA : A.card = m) (hB : B.card = m) (hS : ∀ j, (S j).card = m) :
    (m : ℝ) + (m : ℝ) * t * (1 - 1 / t) ^ l ≤ ∑ a ∈ A, ∑ b ∈ B, W t S a b := by
  have hmR : (4 : ℝ) ≤ m := by exact_mod_cast hm
  have ht : 3 ≤ t := by rw [hmt]; linarith
  have htpos : 0 < t := by linarith
  have hs := sPos ht
  obtain ⟨y, hy⟩ : ∃ y : ℝ, y = (1 - 1 / t) ^ l := ⟨_, rfl⟩
  have hy0 : 0 ≤ y := by rw [hy]; exact pow_nonneg hs.le _
  have hWy : ∀ a b, y ≤ W t S a b := fun a b => by rw [hy]; exact W_ge_base ht hS hmt a b
  rw [← hy]
  obtain ⟨D, hD⟩ : ∃ D : Finset ℕ, D = A ∩ B := ⟨_, rfl⟩
  obtain ⟨A', hA'⟩ : ∃ A' : Finset ℕ, A' = A \ D := ⟨_, rfl⟩
  obtain ⟨B', hB'⟩ : ∃ B' : Finset ℕ, B' = B \ D := ⟨_, rfl⟩
  have hDA : D ⊆ A := by rw [hD]; exact Finset.inter_subset_left
  have hDB : D ⊆ B := by rw [hD]; exact Finset.inter_subset_right
  have hAc : A'.card + D.card = m := by
    rw [hA', Finset.card_sdiff_of_subset hDA, hA]
    have := Finset.card_le_card hDA
    omega
  have hBc : B'.card + D.card = m := by
    rw [hB', Finset.card_sdiff_of_subset hDB, hB]
    have := Finset.card_le_card hDB
    omega
  obtain ⟨k, hk⟩ : ∃ k : ℕ, k = A'.card := ⟨_, rfl⟩
  have hA'c : A'.card = k := hk.symm
  have hB'c : B'.card = k := by omega
  have hne : ∀ a ∈ A', ∀ b ∈ B', a ≠ b := by
    intro a ha b hb hab
    rw [hA', Finset.mem_sdiff] at ha
    rw [hB', Finset.mem_sdiff] at hb
    subst hab
    exact ha.2 (by rw [hD]; exact Finset.mem_inter.mpr ⟨ha.1, hb.1⟩)
  have hmiss : ∀ j, k ≤ ∑ a ∈ A', u (S j) a + ∑ b ∈ B', u (S j) b + ∑ x ∈ D, u (S j) x := by
    intro j
    have := miss_lower hA hB (hS j)
    rw [← hD, ← hA', ← hB'] at this
    rw [hk]
    exact this
  -- inequality (I)
  have hI : (k : ℝ) + (k : ℝ) * ((k : ℝ) - 1) * y
      ≤ Delta D S / t + ∑ a ∈ A', ∑ b ∈ B', W t S a b := by
    have hcases : k = 0 ∨ k = 1 ∨ 2 ≤ k := by omega
    rcases hcases with h0 | h1 | h2
    · have hΔ : 0 ≤ Delta D S / t := div_nonneg (Delta_nonneg D S) htpos.le
      have hsum : 0 ≤ ∑ a ∈ A', ∑ b ∈ B', W t S a b :=
        Finset.sum_nonneg (fun a _ => Finset.sum_nonneg (fun b _ => hy0.trans (hWy a b)))
      rw [h0]
      push_cast
      linarith
    · rw [h1] at hA'c hB'c hmiss ⊢
      obtain ⟨a, rfl⟩ := Finset.card_eq_one.mp hA'c
      obtain ⟨b, rfl⟩ := Finset.card_eq_one.mp hB'c
      have hab := hne a (Finset.mem_singleton_self a) b (Finset.mem_singleton_self b)
      simp only [Finset.sum_singleton] at hmiss ⊢
      have := caseOne ht hS hmt D hab hmiss
      push_cast
      linarith
    · rw [hy]
      exact caseTwo ht hl hS hmt h2 hA'c hB'c hne hmiss
  -- the common reduction
  obtain ⟨f, hf⟩ : ∃ f : ℕ → ℕ → ℝ, f = fun a b => W t S a b - y := ⟨_, rfl⟩
  have hfab : ∀ a b, f a b = W t S a b - y := fun a b => by rw [hf]
  have hf0 : ∀ a b, 0 ≤ f a b := fun a b => by rw [hfab]; linarith [hWy a b]
  have hsp := sum_split A B D A' B' f hD hA' hB'
  have h_lhs : (∑ a ∈ A, ∑ b ∈ B, f a b) = (∑ a ∈ A, ∑ b ∈ B, W t S a b) - (m : ℝ) * ((m : ℝ) * y) := by
    simp only [hfab, Finset.sum_sub_distrib, Finset.sum_const, hA, hB, nsmul_eq_mul]
  have h_AB : (∑ α ∈ A', ∑ β ∈ B', f α β)
      = (∑ a ∈ A', ∑ b ∈ B', W t S a b) - (k : ℝ) * ((k : ℝ) * y) := by
    simp only [hfab, Finset.sum_sub_distrib, Finset.sum_const, hA'c, hB'c, nsmul_eq_mul]
  have h_off : 0 ≤ ∑ x ∈ D, ∑ y' ∈ D.erase x, f x y' :=
    Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => hf0 _ _))
  have h_m1 : 0 ≤ ∑ α ∈ A', ∑ x ∈ D, f α x :=
    Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => hf0 _ _))
  have h_m2 : 0 ≤ ∑ x ∈ D, ∑ β ∈ B', f x β :=
    Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => hf0 _ _))
  have h_diag : (D.card : ℝ) * (1 - y) + Delta D S / t ≤ ∑ x ∈ D, f x x := by
    have h1 : ∑ x ∈ D, (1 - y + (missCount S x : ℝ) / t) ≤ ∑ x ∈ D, f x x := by
      refine Finset.sum_le_sum (fun x _ => ?_)
      rw [hfab]
      linarith [W_diag_ge ht hS hmt x]
    have h2 : ∑ x ∈ D, (1 - y + (missCount S x : ℝ) / t)
        = (D.card : ℝ) * (1 - y) + Delta D S / t := by
      rw [Finset.sum_add_distrib, Finset.sum_const, nsmul_eq_mul, ← Finset.sum_div]
      rfl
    rw [← h2]
    exact h1
  have hdk : (m : ℝ) = (D.card : ℝ) + (k : ℝ) := by
    have : m = D.card + k := by omega
    rw [this]
    push_cast
    ring
  have hexpr : (m : ℝ) + (m : ℝ) * t * y
      = (m : ℝ) * ((m : ℝ) * y) + (D.card : ℝ) * (1 - y)
        + ((k : ℝ) + (k : ℝ) * ((k : ℝ) - 1) * y) - (k : ℝ) * ((k : ℝ) * y) := by
    rw [hmt, hdk]
    ring
  rw [hexpr]
  linarith only [hsp, h_lhs, h_AB, h_off, h_m1, h_m2, h_diag, hI]

/-- `P(K_{2,l},m)` in reals, normalised. -/
lemma poly_real {t : ℝ} {l m : ℕ} (hm : 4 ≤ m) (hmt : t = (m : ℝ) - 1) :
    (((m * (m - 1) ^ l + m * (m - 1) * (m - 2) ^ l : ℕ) : ℝ))
      = t ^ l * ((m : ℝ) + (m : ℝ) * t * (1 - 1 / t) ^ l) := by
  have hmR : (4 : ℝ) ≤ m := by exact_mod_cast hm
  have htpos : 0 < t := by rw [hmt]; linarith
  have hc1 : ((m - 1 : ℕ) : ℝ) = t := by
    rw [Nat.cast_sub (by omega : 1 ≤ m), hmt]
    norm_num
  have hc2 : ((m - 2 : ℕ) : ℝ) = t - 1 := by
    rw [Nat.cast_sub (by omega : 2 ≤ m), hmt]
    norm_num
    ring
  push_cast
  rw [hc1, hc2]
  have h1 : t * (1 - 1 / t) = t - 1 := by
    field_simp
  rw [← h1, mul_pow]
  ring

/-- The count is the normalised sum times `t ^ l`. -/
lemma count_real {t : ℝ} (ht0 : t ≠ 0) {l : ℕ} (A B : Finset ℕ) (S : Fin l → Finset ℕ) :
    (((∑ a ∈ A, ∑ b ∈ B, ∏ j : Fin l, (((S j).erase a).erase b).card : ℕ)) : ℝ)
      = t ^ l * ∑ a ∈ A, ∑ b ∈ B, W t S a b := by
  push_cast
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl (fun a _ => ?_)
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl (fun b _ => ?_)
  unfold W
  rw [Finset.prod_div_distrib, Finset.prod_const, Finset.card_univ, Fintype.card_fin]
  field_simp

/-- **Main inequality**, stated for `K_{2,l}` in `ℕ`. -/
theorem countL_ge {l m : ℕ} (hm : 4 ≤ m) (hl : 2 * l ≤ (m - 1) ^ 2)
    (L : Fin 2 ⊕ Fin l → Finset ℕ) (hL : ∀ v, (L v).card = m) :
    m * (m - 1) ^ l + m * (m - 1) * (m - 2) ^ l ≤ countL (K l) L := by
  obtain ⟨t, hmt⟩ : ∃ t : ℝ, t = (m : ℝ) - 1 := ⟨_, rfl⟩
  have hmR : (4 : ℝ) ≤ m := by exact_mod_cast hm
  have htpos : 0 < t := by rw [hmt]; linarith
  have hlR : 2 * (l : ℝ) ≤ t ^ 2 := by
    have h1 : ((2 * l : ℕ) : ℝ) ≤ (((m - 1) ^ 2 : ℕ) : ℝ) := by exact_mod_cast hl
    push_cast at h1
    rw [Nat.cast_sub (by omega : 1 ≤ m)] at h1
    push_cast at h1
    rw [hmt]
    exact h1
  rw [countL_K]
  have hmain := main_real (A := L (Sum.inl 0)) (B := L (Sum.inl 1))
    (S := fun j => L (Sum.inr j)) hm hmt hlR (hL _) (hL _) (fun j => hL _)
  have hpow : (0 : ℝ) < t ^ l := pow_pos htpos l
  have hreal := mul_le_mul_of_nonneg_left hmain hpow.le
  rw [← poly_real hm hmt, ← count_real htpos.ne' (L (Sum.inl 0)) (L (Sum.inl 1))
    (fun j => L (Sum.inr j))] at hreal
  exact_mod_cast hreal

/-- The theorem in terms of the chromatic polynomial. -/
theorem chromaticPolynomial_le_countL {l m : ℕ} (hm : 4 ≤ m) (hl : 2 * l ≤ (m - 1) ^ 2)
    (L : Fin 2 ⊕ Fin l → Finset ℕ) (hL : ∀ v, (L v).card = m) :
    chromaticPolynomial (K l) m ≤ countL (K l) L := by
  rw [chromaticPolynomial_K]
  exact countL_ge hm hl L hL

/-- Equality of the list colour function and the chromatic polynomial below the threshold. -/
theorem listColorFunction_eq {l m : ℕ} (hm : 4 ≤ m) (hl : 2 * l ≤ (m - 1) ^ 2) :
    listColorFunction (K l) m = chromaticPolynomial (K l) m := by
  apply le_antisymm (listColorFunction_le_chromaticPolynomial (K l) m)
  obtain ⟨L, hL, hEq⟩ := listColorFunction_mem (K l) m
  rw [hEq]
  exact chromaticPolynomial_le_countL hm hl L hL

end ListCol
