# Independent final formal review: MathDB 353552

Reviewer: Claude Opus 5.5, high effort, done personally, no subagents. Credit 0. Campaign 58 of 80 unchanged. Root alone adjudicates.

## Recommendation: TECHNICAL_PASS_ROOT_ADJUDICATION_PENDING

I tried to break the claim and could not. `ListCol.tau_isTheta` is, in my reading, the exact MathDB statement, kernel-checked from a fresh extraction, with only the three allowed axioms. No defect affects validity or fidelity. The significance question (Gate G) stays a close call for root, and prior art is bounded only.

| Gate | Result |
|---|---|
| A fresh replay | PASS: 17 of 17 modules compile and kernel-check from an empty build |
| B source audit | PASS: no forbidden construct in any of the 17 sources |
| C axioms | PASS: three allowed axioms; full closure of 27,763 constants walked |
| D statement fidelity | PASS: exact statement; two bridges the packet leaves informal are paid in my controls |
| E controls | PASS, with one limit on the every-larger-m control stated below |
| F prior art | NO MATCH FOUND, BOUNDED AND INCOMPLETE |
| G science | MODEST, BORDERLINE: the routine objection is real and not removed by the formal route |

## Gate A: fresh extracted replay

The zip (SHA-256 8293648330e40e1f...) has 17 regular files, with no absolute path, parent reference, symlink, nested path or extra file. All 17 match SOURCE-HASHES.json. `src/` and `build/` were empty before use. Every module in BUILD-ORDER.json compiled under `-j1 -M3500 -DwarningAsError=true` and passed `leanchecker`, exit 0 for all 34 runs, with the labels the task names. Peak sampled real memory was 2.95 GiB. Details are in results/FRESH-REPLAY.json.

Twelve olean hashes are byte-identical to the 12 modules listed in inputs/lean-results.json. That file lists no hash for the other five (Base, Count, Upper, Main, MainP), so those have no reference. Runtime Lean is 4.34.1 (`#eval` in AuditDead). Binary hashes were checked by the wrapper on every run. `Mathlib.lean` and `lake-manifest.json` match PINS.json.

## Gate B: source-level audit

I read all 17 sources. A token scan found zero occurrences of sorry, admit, axiom, unsafe, partial, opaque, implemented_by, extern, native_decide, ofReduceBool, macro, syntax, elab, notation, run_cmd, set_option, attribute, priority, local or abbrev. There is no `@[...]` attribute, class, structure, inductive or mutual block. The only instance is `instFintypeListColorings`. The only scoped opening is `open scoped Classical` (15 modules). There is no `prelude`. All declarations are in namespace `ListCol`, and imports are 29 specific mathlib modules plus packet modules, so no mathlib name is redefined.

| Module | Role | Used by endpoint |
|---|---|---|
| ListColAvg | per-list inequality `perList`, tangent-line AM-GM `exp_avg`, double-sum identity | yes |
| ListColBase | definitions of list colourings, countL, P, P_l, tau, K; basic lemmas | yes, definitions audited in D |
| ListColScalar | lam, mu estimates; scalar inequality `scalar_main` | yes |
| ListColCount | fibre count `countL_K`; closed form `chromaticPolynomial_K` | yes |
| ListColUpper | miss indicator `u`, card identities; the mq, mr, mt0 weights | partly; weights unused |
| ListColMain | `sum_split`, miss counts; term and mixed-sum bounds | partly; bounds unused |
| ListColMainP | `count_K_eq_p0`, its only theorem | no, dead (imported only) |
| ListColWeights | normalised weights W, base and diagonal bounds, `factor_exp` | yes |
| ListColCaseOne | `miss_lower` (no containment premise), `caseOne` | yes |
| ListColCaseTwo | `caseTwo`, averaged joint-miss bound for k >= 2 | yes |
| ListColMainIneq | `main_real`, `countL_ge`, `listColorFunction_eq` | yes |
| ListColLowerCount | residue counts, balanced assignment, `W_off_eq` | yes |
| ListColLowerBounds | weight bounds for the balanced assignment, `bad_numeric` | yes |
| ListColLower | `badL`, `bad_sum_lt`, `listColorFunction_lt` | yes |
| ListColEndpoint | kB, `tau_set_nonempty`, `tau_le_kB`, `tau_lower`, `tau_isTheta` and the instance-general form | yes |
| ListColLowerExactA | weights for t >= 2, `four_spec_le` | only for `tau_gt_source` |
| ListColLowerExact | numerics and `tau_gt_source`, source Theorem 4 | only for `tau_gt_source` |

No conclusion-bearing premise. `tau_isTheta` has no hypotheses. `tau_completeBipartite_isTheta` has only the decidability family. `countL_ge` has `4 <= m`, `2l <= (m-1)^2` and the list-size premise. `tau_lower` has `144 <= l`; `tau_gt_source` has `16 <= l`. Intermediate premises (`hmiss` in caseOne and caseTwo, `hne` in tau_mem, `hnum` in bad_sum_lt_exact) are discharged by `miss_lower`, `tau_set_nonempty` and `exact_numeric`. The kernel check of the premise-free endpoint confirms that none remains.

## Gate C: axioms and dependencies

`#print axioms` for all seven requested theorems gives exactly `[propext, Classical.choice, Quot.sound]`. The environment walk from those seven roots fit in the limits and covers type, value, constructors and recursor rules: 27,763 constants, none missing. Kinds: 19,862 theorems, 6,249 definitions, 775 constructors, 690 inductives, 158 recursors, 22 opaque, 4 quot, 3 axioms. Axioms: propext, Quot.sound, Classical.choice. Unsafe 0. Partial 0. The 22 opaque constants are mathlib `irreducible_def` wrappers (Real, Complex, Asymptotics, topology, FDeriv and similar) plus `String.Internal.append` and `Lean.opaqueId`. implemented_by: 6 core constants (Name constructors, `Nat.repr`, `List.attachWith`, `Array.foldlM`). extern: 58 core runtime constants such as Nat and Int arithmetic. These two attributes affect compiled code only, not the kernel. No type has sorry.

Of 190 user-facing ListCol declarations (non-internal, including auto-generated `congr_simp` lemmas), 128 are used by `tau_isTheta`, 147 by the seven roots together, and 43 by none.

## Gate D: statement fidelity (most important)

**Verdict: `ListCol.tau_isTheta` is the exact MathDB statement.** The checks below are against inputs/literal353552.json and arXiv 2202.03431v2 Sections 1.1, 1.2 and Conjecture 5.

- **m-assignment.** `∀ v, (L v).card = m` is exactly the source's |L(v)| = m.
- **Proper list colouring.** `ListColorings` is a choice `f v ∈ L v` with `(f u).val ≠ (f v).val` for every adjacent pair. This is the source's proper L-colouring.
- **P(G,m).** `chromaticPolynomial G m = countL G (fun _ => range m)`. Control `chromaticPolynomial_eq_card_coloring` proves it equals mathlib's number of `G.Coloring (Fin m)`, for every graph. The closed form m(m-1)^l + m(m-1)(m-2)^l matches the source.
- **P_l(G,m).** `sInf` over `{n | ∃ L, all sizes m, n = countL G L}`. The set is proved nonempty, so this is a true minimum.
- **tau.** `sInf {k | χ(G) ≤ k ∧ ∀ m, k ≤ m → P_l = P}`: smallest k >= χ with equality for every m >= k, which is the source's wording. The set is proved nonempty by `tau_set_nonempty`, through `kB_mem_tau_set`, whose every-larger-m clause uses `listColorFunction_eq` at every m >= kB. The junk value 0 cannot occur: `tau_lower` and `lt_tau_of_lt` both go through `tau_mem`, and 0 is also excluded since K l has vertices, so χ >= 1.
- **Domain of m.** The source has N = {1,2,...}; Lean has m : ℕ. Since k >= χ >= 1, m = 0 never arises in the clause, so nothing changes.
- **Colours.** Lean uses `Finset ℕ`; the source allows any colour set. Nothing is lost. The packet leaves this informal; control `relabel` proves that any assignment in any type with decidable equality relabels into ℕ with the same list sizes and an equivalence of colouring types, and `listColorFunction_le_any` gives the lower-bound direction for every colour type. The reverse direction is immediate, as ℕ is itself a colour type.
- **The graph.** `K l` unfolds to mathlib `completeBipartiteGraph (Fin 2) (Fin l)`, whose adjacency is `(isLeft v ∧ isRight w) ∨ (isRight v ∧ isLeft w)`. This is K_{2,l}.
- **IsTheta.** The fully explicit print shows `Asymptotics.IsTheta` over `Filter.atTop` on ℕ with `Nat.instPreorder`, for `fun l => (Nat.cast (tau (K l)) : ℝ)` and `fun l => Real.sqrt (Nat.cast l)`. It is exactly Θ(√l) as l → ∞, unfolding to two big-O statements. Control `theta_unpacked` derives positive c, C with c√l ≤ τ ≤ C√l eventually.
- **Decidability instances.** `tau_completeBipartite_isTheta` quantifies over an arbitrary family of adjacency decidability instances. It fixes the Fintype and DecidableEq instances of the vertex type. Control `tau_congr` proves tau is independent of all three instance arguments, so this loses nothing.

## Gate E: semantic controls in Lean

ControlBridge and ControlValues compile and kernel-check. Their axiom prints show only the three allowed axioms. `brute` uses my own adjacency function, proved equivalent to `K`, so it does not depend on the packet's counting lemmas. All values were derived by hand first.

| Control | Result | What it would catch |
|---|---|---|
| `cp_eq_brute`, with `brute 2 2 = 2`, `brute 2 3 = 18`, `brute 3 3 = 30`, `brute 4 2 = 2` by `decide +kernel` | proved | wrong P or wrong graph |
| `closed_form_agrees` | same values from m(m-1)^l + m(m-1)(m-2)^l | wrong closed form |
| `badK4_empty`, `countL_badK4`: lists {0,1},{2,3} and {0,2},{0,3},{1,2},{1,3} | no proper colouring, directly from the definition | wrong properness |
| `listColor_K4_2 = 0` against `cp_K4_2 = 2` | proved | P_l not a minimum over assignments |
| `tau_K4_ge3` | 3 ≤ τ(K_{2,4}) | junk sInf, reversed clause direction |
| `listColor_K0_3 = 9`, `wrong_size_variant = 0` | proved | list sizes only bounded by m |
| `tau_K1 : tau (K 1) = 2` | exact small value | a dropped χ clause, non-minimal threshold |
| `tauAtKNoChi = 0` against `3 ≤ tauEveryNoChi` | proved | equality only at k instead of every m >= k |
| ControlNegative: `brute 3 3 = 31` | fails, exit 1, as intended | vacuous brute count |

Limit. The every-larger-m control separates the two readings only for k below χ, since a separation with k >= χ would be a graph with ν(G) < τ(G), which the source's Question 2 records as open. For k >= χ that clause is confirmed by reading the definition and by the elaborated print of `tau`. A variant with list sizes at least m is not separated either; it would not change the minimum. `tau_K1` uses the packet's proved `countL_K`, a kernel-checked theorem.

## Gate F: live prior art

Two searches, two query strings of the four allowed, standard mode, each precharged and saved next (results/search-1-response.txt, results/search-2-response.txt). inherited-denials.json was read in full first (331,711 characters); nothing in it blocks these sources, and I fetched no pages.

Neither search found a proof or disproof of Θ(√l). The best upper bound seen is the follow-up's τ(K_{2,n}) ≤ ⌈(n+2.05)/1.24⌉, linear, in Bounding the List Color Function Threshold from Above, Involve 16 (2023) 849-882, DOI 10.2140/involve.2023.16.849. Its Involve final, read locally at the relevant passage, keeps Conjecture 4 and says a proof "will require a novel refinement of our approach or an entirely new approach". The search did not find any 2024 to 2026 paper on K_{2,n} thresholds. The journal final of 2202.03431 was not found and its venue stays unconfirmed. These are tool summaries and result titles only. arXiv 2206.14536, 1811.02420 and 2509.16733 and the ECA 2026 paper surfaced and are unread. No MathSciNet, zbMATH or citation index was used, so this is not a worldwide novelty clearance.

## Gate G: science

I read qualification-REVIEW.md and qualification-PROOF.md in full, and the follow-up at Lemmas 5, 6, 13, Theorem 7, Conjecture 4 and the refinement sentence. I did not read its Lemma 12 directly or its full proofs.

**Case for routine.** Lemma 13 is printed block AM-GM on the k = 2 block; its fourth term is the joint-miss bound at p = 2, as the retained objection says. Lemma 5 and Lemma 6 supply containment and the k = 1 Bernoulli trade-off. The new material is a per-list inequality (`perList`, a few lines), the reduction of k >= 2 to k = 2, and one scalar inequality. There is no new invariant or construction. The lower bound and its extremal assignment are the source's. I confirmed from the follow-up text that its Theorem 7 uses block AM-GM with finite computational verification, so the description of the formal route as that architecture made uniform is fair.

**Case for substance.** A deliberately posed conjecture, stated in two papers, is settled in full. The exponent moves from the published linear bound to the conjectured √l. The Involve authors say their approach falls short and suspected a barrier at m-2 shared colours without proving it. Their m <= 5 work is case analysis closed by computational checks (the proof of Theorem 7 points to programs in its Appendix B), with no stated route to general m, so this is not one missing estimate in an existing general proof, and I found no complete reduction to a printed theorem.

**Does the formal route change this?** No. It confirms the shape of the objection: the real content sits in about three short modules (ListColAvg, ListColCaseTwo, ListColScalar), elementary throughout, using tangent lines and no special tool.

**Is removing the containment hypothesis new?** No. Follow-up Lemma 5 already gives a minimising assignment with containment for m >= χ_ℓ and l <= n, which suffices for P_l. `miss_lower` replaces it by `|U \ S| ≥ |U| - |S|`, which holds for any list; the proof only ever needs the inequality. That is a convenient one-line bypass, and it earns no separate novelty. The packet's "no containment hypothesis" comment is accurate about the proof and should not be read as a strengthening of the literature.

**My view: MODEST, BORDERLINE.** I would not exclude it on the current record, because no complete bridge from a printed theorem exists, and the campaign rule says familiar tools and shortness alone do not exclude. I would not call it strong either. The record shows the 336276 lesson that a first creditable review can fall to a later adversarial search for a generic proof; only one such qualification exists here, by the same model family as this review and as the Lean author. The formal route follows the qualification reviewer's own proof, per the Lean summary, so proof and formalization are not independent of that reviewer's reasoning. The kernel check removes the validity concern, but not this one.

## Defects

| # | Severity | Defect |
|---|---|---|
| 1 | cosmetic | 43 of 190 ListCol declarations are unused by every main theorem, including all of ListColMainP and the mq, mr, mt0 route. The Lean summary discloses only part of this. |
| 2 | cosmetic | Docstring of `listColorFunction_eq` says "below the threshold"; the theorem is at or above it. |
| 3 | cosmetic | Primed lemmas in ListColLowerExactA duplicate ListColLowerCount and ListColLowerBounds lemmas with a weaker hypothesis. |
| 4 | low | Colour-type equivalence is informal in the packet; paid here only as a control, not part of the sealed packet. |
| 5 | low | `tau_completeBipartite_isTheta` fixes the Fintype and DecidableEq instances; closed by control `tau_congr`, not part of the packet. |

Defects affecting validity or fidelity: none.

## What I did not check

- Upstream mathlib, Batteries and core oleans are trusted as pinned. `leanchecker` replays packet modules, not upstream. The mathlib revision is attested only by two metadata hashes; no git command was run.
- I read every source for statements, roles and suspicious constructs, and followed the main argument, but did not re-derive every tactic step by hand; I relied on the kernel.
- I did not attempt my own extended search for a generic short proof beyond reading the printed tools.
- Family comparison against the 57 + 39 scopes was not repeated. inputs/author-candidate.md and author-formal-plan.md were not read. INPUT-ORIGINS.json was not opened.
- The K_{3,l} note and the sharp limit are not formalized and were not checked; the literal does not need them.

## Process disclosures

- The ListColBase compile and check ran with console stdout sent to `/dev/null` and a trailing `echo`, so the shell's own exit was echo's. Its receipts and output files hold the true results (exit 0 and 0). All later runs show the true exit.
- 24 displays exceeded 15,000 characters once the runner's appended receipt line is counted (23 denial chunks at about 15,100, and read_helpers at 16,186). Each content chunk was at most 14,845.
- Retained failures: `control_bridge_compile` exit 1 (a deprecated `dif_pos` in my own code, promoted to an error, repaired by a changed source and recompiled as `control_bridge_compile_2`); `control_negative_compile` exit 1, intended.
- The pin check read `Mathlib.lean` and `lake-manifest.json` at the path named in PINS.json, under run.py, after compilation. This is the pinned dependency, not a lane.
- AuditAxioms, AuditClosure and AuditDead were compiled but not kernel-checked; they contain reporting commands and helper definitions, no result relied on as a theorem.
- Native, transient and writer resource peaks are unknown.
