import ListColLowerExactA
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# Source Theorem 4, exactly as printed

For `l ≥ 16` and `q = ⌊l/4⌋`: `τ(K_{2,l}) > ⌊(q / ln (16/7)) ^ (1/2) + 1⌋`.
-/

open scoped Classical
open Finset

namespace ListCol

lemma five_pow_gt {c : ℕ} (hc : 1 ≤ c) : 16 * (c : ℝ) < 5 ^ (c + 1) := by
  induction c, hc using Nat.le_induction with
  | base => norm_num
  | succ n hn ih =>
    have hnR : (1 : ℝ) ≤ n := by exact_mod_cast hn
    rw [pow_succ]
    push_cast
    nlinarith

/-- The numerics for source Theorem 4. -/
lemma exact_numeric {c : ℕ} (hc : 1 ≤ c) {t : ℝ} (htc : t = (c : ℝ) + 1) {T : ℕ}
    (hT : t ^ 2 * Real.log (16 / 7) ≤ T) :
    4 * (c : ℝ) * (1 - 1 / t) ^ (2 * T) + 4 * ((1 - 1 / t) * (1 + 1 / t)) ^ T < 2 := by
  have hcR : (1 : ℝ) ≤ c := by exact_mod_cast hc
  have ht2 : 2 ≤ t := by rw [htc]; linarith
  have htpos : 0 < t := by linarith
  have hs := s0' ht2
  have hq := q0' ht2
  have hL0 : 0 < Real.log (16 / 7) := Real.log_pos (by norm_num)
  have hexpL : Real.exp (-Real.log (16 / 7)) = 7 / 16 := by
    rw [Real.exp_neg, Real.exp_log (by norm_num)]
    norm_num
  obtain ⟨a, ha⟩ : ∃ a : ℝ, a = 1 / t := ⟨_, rfl⟩
  have hta : t * a = 1 := by
    rw [ha]
    field_simp
  rw [← ha] at hs hq ⊢
  -- the `κ` term
  have hkap : (1 - a) * (1 + a) = 1 - a ^ 2 := by ring
  have hk0 : 0 ≤ 1 - a ^ 2 := by
    rw [← hkap]
    positivity
  have hkle : 1 - a ^ 2 ≤ Real.exp (-(a ^ 2)) := Real.one_sub_le_exp_neg _
  have hk1 : (1 - a ^ 2) ^ T ≤ Real.exp (-(a ^ 2)) ^ T := pow_le_pow_left₀ hk0 hkle _
  obtain ⟨Y, hY⟩ : ∃ Y : ℝ, Y = (T : ℝ) * a ^ 2 := ⟨_, rfl⟩
  have hkeq : Real.exp (-(a ^ 2)) ^ T = Real.exp (-Y) := by
    rw [hY, ← Real.exp_nat_mul]
    congr 1
    ring
  rw [hkeq] at hk1
  have hYL : Real.log (16 / 7) ≤ Y := by
    have ht2a : t ^ 2 * a ^ 2 = 1 := by
      have h := congrArg (fun x => x ^ 2) hta
      simp only [mul_pow, one_pow] at h
      exact h
    have h1 : t ^ 2 * Real.log (16 / 7) * a ^ 2 ≤ (T : ℝ) * a ^ 2 :=
      mul_le_mul_of_nonneg_right hT (sq_nonneg a)
    have h2 : t ^ 2 * Real.log (16 / 7) * a ^ 2 = Real.log (16 / 7) := by
      calc t ^ 2 * Real.log (16 / 7) * a ^ 2 = (t ^ 2 * a ^ 2) * Real.log (16 / 7) := by ring
        _ = Real.log (16 / 7) := by rw [ht2a, one_mul]
    rw [hY]
    linarith
  have hexpY : Real.exp (-Y) ≤ 7 / 16 := by
    rw [← hexpL]
    exact Real.exp_le_exp.mpr (by linarith)
  have hpart2 : 4 * ((1 - a) * (1 + a)) ^ T ≤ 7 / 4 := by
    rw [hkap]
    have := hk1.trans hexpY
    linarith
  -- the `s ^ (2T)` term
  have hsle : 1 - a ≤ Real.exp (-a) := Real.one_sub_le_exp_neg _
  have hE1 : (1 - a) ^ (2 * T) ≤ Real.exp (-a) ^ (2 * T) := pow_le_pow_left₀ hs.le hsle _
  obtain ⟨X, hX⟩ : ∃ X : ℝ, X = ((2 * T : ℕ) : ℝ) * a := ⟨_, rfl⟩
  have hEeq : Real.exp (-a) ^ (2 * T) = Real.exp (-X) := by
    rw [hX, ← Real.exp_nat_mul]
    congr 1
    ring
  rw [hEeq] at hE1
  have hX2 : 2 * (((c + 1 : ℕ) : ℝ)) * Real.log (16 / 7) ≤ X := by
    have hcast : ((c + 1 : ℕ) : ℝ) = t := by
      push_cast
      rw [htc]
    rw [hcast, hX]
    push_cast
    have h1 : 2 * (t ^ 2 * Real.log (16 / 7)) * a ≤ 2 * (T : ℝ) * a := by
      have ha0 : 0 ≤ a := by
        rw [ha]
        positivity
      have h2 : t ^ 2 * Real.log (16 / 7) ≤ T := hT
      nlinarith
    have h3 : 2 * (t ^ 2 * Real.log (16 / 7)) * a = 2 * t * Real.log (16 / 7) * (t * a) := by ring
    rw [h3, hta, mul_one] at h1
    linarith
  have hexpX : Real.exp (-X) ≤ (7 / 16) ^ (2 * (c + 1)) := by
    have h1 : Real.exp (-X) ≤ Real.exp (((2 * (c + 1) : ℕ) : ℝ) * (-Real.log (16 / 7))) := by
      apply Real.exp_le_exp.mpr
      have hc' : ((2 * (c + 1) : ℕ) : ℝ) = 2 * (((c + 1 : ℕ) : ℝ)) := by push_cast; ring
      rw [hc']
      linarith
    rw [Real.exp_nat_mul, hexpL] at h1
    exact h1
  have hrat : (7 / 16 : ℝ) ^ (2 * (c + 1)) ≤ (1 / 5) ^ (c + 1) := by
    rw [pow_mul]
    apply pow_le_pow_left₀ (by norm_num)
    norm_num
  have hp : (1 / 5 : ℝ) ^ (c + 1) * 5 ^ (c + 1) = 1 := by
    rw [← mul_pow]
    norm_num
  have hp0 : 0 < (1 / 5 : ℝ) ^ (c + 1) := by positivity
  have h16 : 16 * (c : ℝ) * (1 / 5 : ℝ) ^ (c + 1) < 1 := by
    calc 16 * (c : ℝ) * (1 / 5 : ℝ) ^ (c + 1) < 5 ^ (c + 1) * (1 / 5 : ℝ) ^ (c + 1) :=
          mul_lt_mul_of_pos_right (five_pow_gt hc) hp0
      _ = 1 := by rw [mul_comm]; exact hp
  have hcase : (1 - a) ^ (2 * T) ≤ (1 / 5) ^ (c + 1) := hE1.trans (hexpX.trans hrat)
  have hc0 : (0 : ℝ) ≤ 4 * (c : ℝ) := by linarith
  have hpart1 : 4 * (c : ℝ) * (1 - a) ^ (2 * T) ≤ 4 * (c : ℝ) * (1 / 5) ^ (c + 1) :=
    mul_le_mul_of_nonneg_left hcase hc0
  have h4 : 4 * (c : ℝ) * (1 / 5 : ℝ) ^ (c + 1) = 16 * (c : ℝ) * (1 / 5 : ℝ) ^ (c + 1) / 4 := by
    ring
  linarith

/-- The normalised count of the balanced assignment is below the target, in the regime of the
source's Theorem 4. -/
theorem bad_sum_lt_exact {c l : ℕ} {t : ℝ} (hc : 1 ≤ c) (htc : t = (c : ℝ) + 1)
    (hnum : 4 * (c : ℝ) * (1 - 1 / t) ^ (2 * (l / 4))
      + 4 * ((1 - 1 / t) * (1 + 1 / t)) ^ (l / 4) < 2) :
    (∑ a ∈ Finset.range (c + 2), ∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
      < (((c + 2 : ℕ) : ℝ)) + (((c + 2 : ℕ) : ℝ)) * t * (1 - 1 / t) ^ l := by
  have hcR : (1 : ℝ) ≤ c := by exact_mod_cast hc
  have ht2 : 2 ≤ t := by rw [htc]; linarith
  have htpos : 0 < t := by linarith
  have hmt : t = ((c + 2 : ℕ) : ℝ) - 1 := by
    push_cast
    rw [htc]
    ring
  have hm : ((c + 2 : ℕ) : ℝ) = (c : ℝ) + 2 := by
    push_cast
    ring
  have hs := s0' ht2
  obtain ⟨y, hy⟩ : ∃ y : ℝ, y = (1 - 1 / t) ^ l := ⟨_, rfl⟩
  obtain ⟨E, hE⟩ : ∃ E : ℝ, E = (1 - 1 / t) ^ (2 * (l / 4)) := ⟨_, rfl⟩
  obtain ⟨K4, hK4⟩ : ∃ K4 : ℝ, K4 = 4 * ((1 - 1 / t) * (1 + 1 / t)) ^ (l / 4) := ⟨_, rfl⟩
  have hy0 : 0 ≤ y := by rw [hy]; exact pow_nonneg hs.le _
  rw [← hE, ← hK4] at hnum
  have hLL : ∀ a ∈ Finset.range c, ∀ b ∈ Finset.range c,
      W t (badS c : Fin l → Finset ℕ) a b ≤ y + (if a = b then 1 - y else 0) := by
    intro a ha b hb
    have ha' := Finset.mem_range.mp ha
    have hb' := Finset.mem_range.mp hb
    by_cases hab : a = b
    · subst hab
      have h1 : W t (badS c : Fin l → Finset ℕ) a a = 1 :=
        W_diag_of_all_mem' htpos (fun j => card_badS c j) hmt (fun j => bad_low c j ha')
      rw [h1]
      simp
    · have h1 : W t (badS c : Fin l → Finset ℕ) a b = y := by
        rw [hy]
        exact W_low_low' ht2 hmt ha' hb' hab
      rw [h1]
      simp [hab]
  have hBsplit : ∀ F : ℕ → ℝ, ∑ b ∈ badB c, F b = F (c + 2) + (F (c + 3) + ∑ b ∈ Finset.range c, F b) := by
    intro F
    unfold badB
    rw [Finset.sum_insert, Finset.sum_insert]
    · simp
    · simp only [Finset.mem_insert, Finset.mem_range]
      omega
  have hGlow : ∀ a ∈ Finset.range c, (∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
      ≤ 2 * E + ((c : ℝ) * y + (1 - y)) := by
    intro a ha
    have ha' := Finset.mem_range.mp ha
    have h1 : W t (badS c : Fin l → Finset ℕ) a (c + 2) ≤ E := by
      rw [hE]
      exact W_low_specB' ht2 hmt ha' (β := 0) (by norm_num)
    have h2 : W t (badS c : Fin l → Finset ℕ) a (c + 3) ≤ E := by
      rw [hE]
      exact W_low_specB' ht2 hmt ha' (β := 1) (by norm_num)
    have h3 : (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) a b)
        ≤ (c : ℝ) * y + (1 - y) := by
      calc (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) a b)
          ≤ ∑ b ∈ Finset.range c, (y + (if a = b then 1 - y else 0)) :=
            Finset.sum_le_sum (fun b hb => hLL a ha b hb)
        _ = (c : ℝ) * y + (1 - y) := by
            rw [Finset.sum_add_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul]
            have hite : (∑ b ∈ Finset.range c, (if a = b then 1 - y else 0)) = 1 - y := by
              simp [Finset.sum_ite_eq, ha']
            rw [hite]
    rw [hBsplit]
    linarith
  have hfour : W t (badS c : Fin l → Finset ℕ) c (c + 2)
      + W t (badS c : Fin l → Finset ℕ) (c + 1) (c + 2)
      + W t (badS c : Fin l → Finset ℕ) c (c + 3)
      + W t (badS c : Fin l → Finset ℕ) (c + 1) (c + 3) ≤ K4 := by
    rw [hK4]
    exact four_spec_le ht2 hmt
  have hrow : ∀ α, α < 2 → (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) (c + α) b)
      ≤ (c : ℝ) * E := by
    intro α hα
    calc (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) (c + α) b)
        ≤ ∑ _b ∈ Finset.range c, E := by
          refine Finset.sum_le_sum (fun b hb => ?_)
          rw [hE]
          exact W_specA_low' ht2 hmt hα (Finset.mem_range.mp hb)
      _ = (c : ℝ) * E := by
          rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have hrow0 : (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) c b) ≤ (c : ℝ) * E :=
    hrow 0 (by norm_num)
  have hrow1 : (∑ b ∈ Finset.range c, W t (badS c : Fin l → Finset ℕ) (c + 1) b) ≤ (c : ℝ) * E :=
    hrow 1 (by norm_num)
  have hlow : (∑ a ∈ Finset.range c, ∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
      ≤ (c : ℝ) * (2 * E + ((c : ℝ) * y + (1 - y))) := by
    calc (∑ a ∈ Finset.range c, ∑ b ∈ badB c, W t (badS c : Fin l → Finset ℕ) a b)
        ≤ ∑ _a ∈ Finset.range c, (2 * E + ((c : ℝ) * y + (1 - y))) :=
          Finset.sum_le_sum hGlow
      _ = (c : ℝ) * (2 * E + ((c : ℝ) * y + (1 - y))) := by
          rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  rw [Finset.sum_range_succ, Finset.sum_range_succ, ← hy, hBsplit, hBsplit]
  have hkey : (((c + 2 : ℕ) : ℝ)) + (((c + 2 : ℕ) : ℝ)) * t * y
      - ((c : ℝ) * (2 * E + ((c : ℝ) * y + (1 - y))) + K4 + (c : ℝ) * E + (c : ℝ) * E)
      = 2 + (4 * (c : ℝ) + 2) * y - (4 * (c : ℝ) * E + K4) := by
    rw [hm, htc]
    ring
  have hpos : 0 ≤ (4 * (c : ℝ) + 2) * y := mul_nonneg (by linarith) hy0
  linarith

/-- Strict inequality for the list colour function in the regime of source Theorem 4. -/
theorem listColorFunction_lt_exact {l t : ℕ} (ht : 2 ≤ t)
    (hT : (t : ℝ) ^ 2 * Real.log (16 / 7) ≤ ((l / 4 : ℕ) : ℝ)) :
    listColorFunction (K l) (t + 1) < chromaticPolynomial (K l) (t + 1) := by
  obtain ⟨c, rfl⟩ : ∃ c : ℕ, t = c + 1 := ⟨t - 1, by omega⟩
  have hc : 1 ≤ c := by omega
  obtain ⟨tr, htr⟩ : ∃ tr : ℝ, tr = (c : ℝ) + 1 := ⟨_, rfl⟩
  have hcR : (1 : ℝ) ≤ c := by exact_mod_cast hc
  have htpos : 0 < tr := by rw [htr]; linarith
  have hcast : ((c + 1 : ℕ) : ℝ) = tr := by
    push_cast
    rw [htr]
  rw [hcast] at hT
  have hnum := exact_numeric hc htr hT
  have hsum := bad_sum_lt_exact (l := l) hc htr hnum
  have hle : listColorFunction (K l) (c + 2) ≤ countL (K l) (badL c l) :=
    listColorFunction_le_countL (K l) (badL c l) (card_badL c l)
  show listColorFunction (K l) (c + 2) < chromaticPolynomial (K l) (c + 2)
  refine lt_of_le_of_lt hle ?_
  rw [chromaticPolynomial_K, countL_K]
  have h0 : badL c l (Sum.inl 0) = Finset.range (c + 2) := by simp [badL]
  have h1 : badL c l (Sum.inl 1) = badB c := by simp [badL]
  rw [h0, h1]
  have hS : (∑ a ∈ Finset.range (c + 2), ∑ b ∈ badB c,
        ∏ j : Fin l, (((badL c l (Sum.inr j)).erase a).erase b).card)
      = ∑ a ∈ Finset.range (c + 2), ∑ b ∈ badB c,
        ∏ j : Fin l, (((badS c j).erase a).erase b).card := rfl
  rw [hS]
  have hmt : tr = ((c + 2 : ℕ) : ℝ) - 1 := by
    push_cast
    rw [htr]
    ring
  by_cases hc4 : 4 ≤ c + 2
  · rw [← Nat.cast_lt (α := ℝ), count_real htpos.ne', poly_real hc4 hmt]
    exact mul_lt_mul_of_pos_left hsum (pow_pos htpos l)
  · have hc1 : c = 1 := by omega
    subst hc1
    have hpoly : (((((1 + 2) * ((1 + 2) - 1) ^ l + (1 + 2) * ((1 + 2) - 1) * ((1 + 2) - 2) ^ l : ℕ)) : ℝ))
        = tr ^ l * (((1 + 2 : ℕ) : ℝ) + ((1 + 2 : ℕ) : ℝ) * tr * (1 - 1 / tr) ^ l) := by
      have htv : tr = 2 := by rw [htr]; norm_num
      rw [htv]
      have h12 : (1 - 1 / (2 : ℝ)) = 1 / 2 := by norm_num
      rw [h12]
      push_cast
      have h2l : (2 : ℝ) ^ l * (1 / 2 : ℝ) ^ l = 1 := by
        rw [← mul_pow]
        norm_num
      norm_num
      nlinarith
    rw [← Nat.cast_lt (α := ℝ), count_real htpos.ne', hpoly]
    exact mul_lt_mul_of_pos_left hsum (pow_pos htpos l)

/-- **Source Theorem 4**: for `l ≥ 16`, with `q = ⌊l/4⌋`,
`τ(K_{2,l}) > ⌊(q / ln (16/7)) ^ (1/2) + 1⌋`. -/
theorem tau_gt_source {l : ℕ} (hl : 16 ≤ l) :
    ⌊Real.sqrt (((l / 4 : ℕ) : ℝ) / Real.log (16 / 7)) + 1⌋₊ < tau (K l) := by
  have hq4 : 4 ≤ l / 4 := by omega
  have hqR : (4 : ℝ) ≤ ((l / 4 : ℕ) : ℝ) := by exact_mod_cast hq4
  have hL0 : 0 < Real.log (16 / 7) := Real.log_pos (by norm_num)
  have hL1 : Real.log (16 / 7) ≤ 1 := by
    rw [Real.log_le_iff_le_exp (by norm_num)]
    have := Real.exp_one_gt_d9
    norm_num at this ⊢
    linarith
  obtain ⟨x, hx⟩ : ∃ x : ℝ, x = Real.sqrt (((l / 4 : ℕ) : ℝ) / Real.log (16 / 7)) := ⟨_, rfl⟩
  rw [← hx]
  have hx0 : 0 ≤ x := by rw [hx]; exact Real.sqrt_nonneg _
  rw [Nat.floor_add_one hx0]
  obtain ⟨t, ht⟩ : ∃ t : ℕ, t = ⌊x⌋₊ := ⟨_, rfl⟩
  rw [← ht]
  have htle : (t : ℝ) ≤ x := by
    rw [ht]
    exact Nat.floor_le hx0
  have hx2 : x ^ 2 = ((l / 4 : ℕ) : ℝ) / Real.log (16 / 7) := by
    rw [hx]
    exact Real.sq_sqrt (div_nonneg (by linarith) hL0.le)
  have ht2le : (t : ℝ) ^ 2 ≤ ((l / 4 : ℕ) : ℝ) / Real.log (16 / 7) := by
    rw [← hx2]
    exact pow_le_pow_left₀ (Nat.cast_nonneg t) htle 2
  have hT : (t : ℝ) ^ 2 * Real.log (16 / 7) ≤ ((l / 4 : ℕ) : ℝ) := by
    rwa [le_div_iff₀ hL0] at ht2le
  have ht2 : 2 ≤ t := by
    rw [ht]
    apply Nat.le_floor
    have h2x : (2 : ℝ) ≤ x := by
      rw [hx, Real.le_sqrt' (by norm_num), le_div_iff₀ hL0]
      have h4 : (2 : ℝ) ^ 2 * Real.log (16 / 7) ≤ 4 := by
        norm_num
        linarith
      linarith
    exact_mod_cast h2x
  exact lt_tau_of_lt (listColorFunction_lt_exact ht2 hT)

end ListCol
