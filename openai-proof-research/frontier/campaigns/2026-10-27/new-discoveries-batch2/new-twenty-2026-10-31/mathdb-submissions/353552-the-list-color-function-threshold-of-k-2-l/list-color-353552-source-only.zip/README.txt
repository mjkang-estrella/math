The list color function threshold of K_{2,l} - MathDB 353552 - source-only certificate

This archive contains the 17 Lean modules whose final theorems are ListCol.tau_isTheta and ListCol.tau_completeBipartite_isTheta, in src/, plus audit and control modules in audit/. PINS.json gives Lean 4.34.1, mathlib d13f23b723b8a846827a245b89c10fc7d3f11612 and executable hashes. Upstream libraries are trusted read-only.

To rebuild: create an empty build directory, set LEAN_PATH to build followed by the pinned mathlib and dependency library paths, then for each module in BUILD-ORDER.json in order run lean -j1 -M3500 -DwarningAsError=true -o build/MODULE.olean src/MODULE.lean and leanchecker MODULE, with LEAN_NUM_THREADS=1. Use specific imports as shipped. A 6 GiB address-space limit is too small for this toolchain's import mapping; the checked runs used 32 GiB of address space and a 6 GiB real-memory guard. No olean is shipped. SOURCE-HASHES.json binds every production source.

An independent reviewer performed a fresh extracted replay of all 17 modules from an empty build. Only propext, Classical.choice and Quot.sound are transitive axioms over a closure of 27,763 constants. See FINAL-REVIEW.md and review.json.

Limits: bounded prior-art search with no citation index; the journal final of arXiv 2202.03431, J. Graph Theory DOI 10.1002/jgt.23045, is closed and unread; arXiv 2505.05662, 2509.16733 and 2607.16810 were read only in part; colours are Finset Nat, and the relabelling bridge is proved only in the auditor's control modules included in audit/; the sharp constant is not formalized; upstream libraries were not rebuilt; no peer review, priority or worldwide novelty is claimed.
