import ListColMain
import ListColScalar
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Tactic.IntervalCases

/-!
# The normalised weights `W(a,b)` for an arbitrary list assignment

No hypothesis `S j ⊆ A ∪ B` is used anywhere below.
-/

open scoped Classical
open Finset

namespace ListCol

/-- The normalised number of extensions of the colouring `(a, b)` of the size-two side. -/
noncomputable def W (t : ℝ) {l : ℕ} (S : Fin l → Finset ℕ) (a b : ℕ) : ℝ :=
  ∏ j : Fin l, (((((S j).erase a).erase b).card : ℝ) / t)

lemma card_real_off {S : Finset ℕ} {m : ℕ} (hS : S.card = m) {a b : ℕ} (hab : a ≠ b) :
    (((S.erase a).erase b).card : ℝ) = (m : ℝ) - 2 + (u S a : ℝ) + (u S b : ℝ) := by
  have h := card_erase_erase_add S a b hab
  rw [hS] at h
  have h' : (((S.erase a).erase b).card : ℝ) + 2 = (m : ℝ) + (u S a : ℝ) + (u S b : ℝ) := by
    exact_mod_cast h
  linarith

lemma card_real_diag {S : Finset ℕ} {m : ℕ} (hS : S.card = m) (a : ℕ) :
    (((S.erase a).erase a).card : ℝ) = (m : ℝ) - 1 + (u S a : ℝ) := by
  rw [Finset.erase_idem]
  have h := card_erase_add S a
  rw [hS] at h
  have h' : ((S.erase a).card : ℝ) + 1 = (m : ℝ) + (u S a : ℝ) := by
    exact_mod_cast h
  linarith

/-- Monotonicity of a finite product of nonnegative reals. -/
lemma prod_le_prod_nonneg {ι : Type*} (s : Finset ι) {f g : ι → ℝ}
    (h0 : ∀ i ∈ s, 0 ≤ f i) (h : ∀ i ∈ s, f i ≤ g i) : ∏ i ∈ s, f i ≤ ∏ i ∈ s, g i := by
  induction s using Finset.induction_on with
  | empty => simp
  | insert a s ha ih =>
    rw [Finset.prod_insert ha, Finset.prod_insert ha]
    have hnn : 0 ≤ ∏ i ∈ s, f i :=
      Finset.prod_nonneg (fun i hi => h0 i (Finset.mem_insert_of_mem hi))
    exact mul_le_mul (h a (Finset.mem_insert_self a s))
      (ih (fun i hi => h0 i (Finset.mem_insert_of_mem hi))
        (fun i hi => h i (Finset.mem_insert_of_mem hi)))
      hnn ((h0 a (Finset.mem_insert_self a s)).trans (h a (Finset.mem_insert_self a s)))

/-- Each factor is at least `1 - 1/t`. -/
lemma factor_ge_s {t : ℝ} (ht : 3 ≤ t) {S : Finset ℕ} {m : ℕ} (hS : S.card = m)
    (hmt : t = (m : ℝ) - 1) (a b : ℕ) :
    1 - 1 / t ≤ (((S.erase a).erase b).card : ℝ) / t := by
  have htpos : 0 < t := by linarith
  have h1 : S.card - 1 ≤ (S.erase a).card := Finset.pred_card_le_card_erase
  have h2 : (S.erase a).card - 1 ≤ ((S.erase a).erase b).card := Finset.pred_card_le_card_erase
  have h3 : m ≤ ((S.erase a).erase b).card + 2 := by omega
  have h4 : (m : ℝ) ≤ (((S.erase a).erase b).card : ℝ) + 2 := by exact_mod_cast h3
  rw [le_div_iff₀ htpos]
  have : (1 - 1 / t) * t = t - 1 := by
    field_simp
  rw [this, hmt]
  linarith

/-- Every pair has normalised weight at least `y = (1 - 1/t) ^ l`. -/
lemma W_ge_base {t : ℝ} (ht : 3 ≤ t) {l m : ℕ} {S : Fin l → Finset ℕ} (hS : ∀ j, (S j).card = m)
    (hmt : t = (m : ℝ) - 1) (a b : ℕ) : (1 - 1 / t) ^ l ≤ W t S a b := by
  have hs := sPos ht
  unfold W
  have h : ∏ _j : Fin l, (1 - 1 / t) ≤ ∏ j : Fin l, (((((S j).erase a).erase b).card : ℝ) / t) :=
    prod_le_prod_nonneg Finset.univ (fun _ _ => hs.le) (fun j _ => factor_ge_s ht (hS j) hmt a b)
  simpa using h

/-- `(1 + u/t) = (1 + 1/t) ^ u` for `u ≤ 1`. -/
lemma one_add_u_div (t : ℝ) (x : ℕ) (hx : x ≤ 1) : 1 + (x : ℝ) / t = (1 + 1 / t) ^ x := by
  interval_cases x <;> simp

/-- The diagonal weight dominates a linear function of the miss count. -/
lemma W_diag_ge {t : ℝ} (ht : 3 ≤ t) {l m : ℕ} {S : Fin l → Finset ℕ} (hS : ∀ j, (S j).card = m)
    (hmt : t = (m : ℝ) - 1) (x : ℕ) : 1 + (missCount S x : ℝ) / t ≤ W t S x x := by
  have htpos : 0 < t := by linarith
  have hfac : ∀ j : Fin l, ((((S j).erase x).erase x).card : ℝ) / t = (1 + 1 / t) ^ (u (S j) x) := by
    intro j
    rw [card_real_diag (hS j) x, ← one_add_u_div t _ (u_le_one (S j) x), hmt]
    have h1 : (m : ℝ) - 1 ≠ 0 := by rw [← hmt]; linarith
    field_simp
  have hW : W t S x x = (1 + 1 / t) ^ missCount S x := by
    unfold W
    rw [Finset.prod_congr rfl (fun j _ => hfac j), Finset.prod_pow_eq_pow_sum, sum_u]
  rw [hW]
  have ha0 := aPos ht
  have h := one_add_mul_le_pow (a := 1 / t) (by linarith) (missCount S x)
  have e : 1 + (missCount S x : ℝ) * (1 / t) = 1 + (missCount S x : ℝ) / t := by
    ring
  linarith

/-- The exact exponential form of one factor, for `a ≠ b`. -/
lemma factor_exp {t : ℝ} (ht : 3 ≤ t) {S : Finset ℕ} {m : ℕ} (hS : S.card = m)
    (hmt : t = (m : ℝ) - 1) {a b : ℕ} (hab : a ≠ b) :
    (((S.erase a).erase b).card : ℝ) / t
      = Real.exp ((u S a : ℝ) * (u S b : ℝ) * mu t - (1 - (u S a : ℝ)) * (1 - (u S b : ℝ)) * lam t) := by
  have htpos : 0 < t := by linarith
  have hm : (m : ℝ) = t + 1 := by rw [hmt]; ring
  rw [card_real_off hS hab, hm]
  have hua := u_le_one S a
  have hub := u_le_one S b
  generalize u S a = x at hua ⊢
  generalize u S b = y at hub ⊢
  interval_cases x <;> interval_cases y
  · have e : Real.exp ((0 : ℕ) * (0 : ℕ) * mu t - (1 - ((0 : ℕ) : ℝ)) * (1 - ((0 : ℕ) : ℝ)) * lam t)
        = Real.exp (-lam t) := by
      congr 1
      simp
    rw [e, exp_neg_lam ht]
    simp
    field_simp
    ring
  · simp
    field_simp
    ring
  · simp
    field_simp
    ring
  · have e : Real.exp (((1 : ℕ) : ℝ) * ((1 : ℕ) : ℝ) * mu t - (1 - ((1 : ℕ) : ℝ)) * (1 - ((1 : ℕ) : ℝ)) * lam t)
        = Real.exp (mu t) := by
      congr 1
      simp
    rw [e, exp_mu ht]
    simp
    field_simp
    ring

end ListCol
