import ListColCaseOne
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The case `k ≥ 2` of inequality (I), by the averaged joint-miss bound
-/

open scoped Classical
open Finset

namespace ListCol

/-- The exponent of the weight of an off-diagonal pair. -/
noncomputable def Eexp {l : ℕ} (S : Fin l → Finset ℕ) (L M : ℝ) (a b : ℕ) : ℝ :=
  ∑ j : Fin l, ((u (S j) a : ℝ) * (u (S j) b : ℝ) * M - (1 - (u (S j) a : ℝ)) * (1 - (u (S j) b : ℝ)) * L)

lemma W_eq_exp {t : ℝ} (ht : 3 ≤ t) {l m : ℕ} {S : Fin l → Finset ℕ} (hS : ∀ j, (S j).card = m)
    (hmt : t = (m : ℝ) - 1) {a b : ℕ} (hab : a ≠ b) :
    W t S a b = Real.exp (Eexp S (lam t) (mu t) a b) := by
  unfold W Eexp
  rw [Real.exp_sum]
  exact Finset.prod_congr rfl (fun j _ => factor_exp ht (hS j) hmt hab)

/-- `∑_{a,b} E(a,b)` in terms of the per-list miss counts. -/
lemma sum_Eexp {l : ℕ} (S : Fin l → Finset ℕ) (L M : ℝ) (A' B' : Finset ℕ) (k : ℕ)
    (hA' : A'.card = k) (hB' : B'.card = k) :
    (∑ a ∈ A', ∑ b ∈ B', Eexp S L M a b)
      = ∑ j : Fin l,
          ((∑ a ∈ A', (u (S j) a : ℝ)) * (∑ b ∈ B', (u (S j) b : ℝ)) * M
            - ((k : ℝ) - ∑ a ∈ A', (u (S j) a : ℝ))
              * ((k : ℝ) - ∑ b ∈ B', (u (S j) b : ℝ)) * L) := by
  unfold Eexp
  calc (∑ a ∈ A', ∑ b ∈ B', ∑ j : Fin l,
        ((u (S j) a : ℝ) * (u (S j) b : ℝ) * M - (1 - (u (S j) a : ℝ)) * (1 - (u (S j) b : ℝ)) * L))
      = ∑ a ∈ A', ∑ j : Fin l, ∑ b ∈ B',
        ((u (S j) a : ℝ) * (u (S j) b : ℝ) * M - (1 - (u (S j) a : ℝ)) * (1 - (u (S j) b : ℝ)) * L) :=
        Finset.sum_congr rfl (fun a _ => Finset.sum_comm)
    _ = ∑ j : Fin l, ∑ a ∈ A', ∑ b ∈ B',
        ((u (S j) a : ℝ) * (u (S j) b : ℝ) * M - (1 - (u (S j) a : ℝ)) * (1 - (u (S j) b : ℝ)) * L) :=
        Finset.sum_comm
    _ = _ := by
        refine Finset.sum_congr rfl (fun j _ => ?_)
        rw [double_sum_prod A' B' (fun a => (u (S j) a : ℝ)) (fun b => (u (S j) b : ℝ))
          (fun a => 1 - (u (S j) a : ℝ)) (fun b => 1 - (u (S j) b : ℝ)) M L]
        have e1 : ∑ a ∈ A', (1 - (u (S j) a : ℝ)) = (k : ℝ) - ∑ a ∈ A', (u (S j) a : ℝ) := by
          rw [Finset.sum_sub_distrib, Finset.sum_const, hA', nsmul_eq_mul, mul_one]
        have e2 : ∑ b ∈ B', (1 - (u (S j) b : ℝ)) = (k : ℝ) - ∑ b ∈ B', (u (S j) b : ℝ) := by
          rw [Finset.sum_sub_distrib, Finset.sum_const, hB', nsmul_eq_mul, mul_one]
        rw [e1, e2]

/-- Summing the constant part over the lists. -/
lemma sum_lower_form {l : ℕ} (z : Fin l → ℝ) (L N : ℝ) :
    ∑ j : Fin l, (-z j * L - (1 - z j) * N / 4)
      = -(∑ j : Fin l, z j) * L - ((l : ℝ) - ∑ j : Fin l, z j) * N / 4 := by
  have e : ∀ j : Fin l, -z j * L - (1 - z j) * N / 4 = -N / 4 + z j * (N / 4 - L) := by
    intro j
    ring
  rw [Finset.sum_congr rfl (fun j _ => e j), Finset.sum_add_distrib, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, ← Finset.sum_mul]
  ring

/-- Inequality (I) for `k ≥ 2`. -/
theorem caseTwo {t : ℝ} (ht : 3 ≤ t) {l m k : ℕ} {S : Fin l → Finset ℕ}
    (hl : 2 * (l : ℝ) ≤ t ^ 2) (hS : ∀ j, (S j).card = m) (hmt : t = (m : ℝ) - 1)
    (hk : 2 ≤ k) {A' B' D : Finset ℕ} (hA' : A'.card = k) (hB' : B'.card = k)
    (hne : ∀ a ∈ A', ∀ b ∈ B', a ≠ b)
    (hmiss : ∀ j, k ≤ ∑ a ∈ A', u (S j) a + ∑ b ∈ B', u (S j) b + ∑ x ∈ D, u (S j) x) :
    (k : ℝ) + (k : ℝ) * ((k : ℝ) - 1) * (1 - 1 / t) ^ l
      ≤ Delta D S / t + ∑ a ∈ A', ∑ b ∈ B', W t S a b := by
  have htpos : 0 < t := by linarith
  have hkR : (2 : ℝ) ≤ k := by exact_mod_cast hk
  have hk0 : (0 : ℝ) < k := by linarith
  have hkne : (k : ℝ) ≠ 0 := hk0.ne'
  have hM0 := mu_nonneg ht
  have hML : mu t ≤ lam t := sub_nonneg.mp (nu_nonneg ht)
  -- per-list data
  obtain ⟨α, hα⟩ : ∃ α : Fin l → ℝ, α = fun j => ∑ a ∈ A', (u (S j) a : ℝ) := ⟨_, rfl⟩
  obtain ⟨β, hβ⟩ : ∃ β : Fin l → ℝ, β = fun j => ∑ b ∈ B', (u (S j) b : ℝ) := ⟨_, rfl⟩
  obtain ⟨δ, hδ⟩ : ∃ δ : Fin l → ℝ, δ = fun j => ∑ x ∈ D, (u (S j) x : ℝ) := ⟨_, rfl⟩
  have hu01 : ∀ (s : Finset ℕ) (x : ℕ), (0 : ℝ) ≤ (u s x : ℝ) ∧ (u s x : ℝ) ≤ 1 := by
    intro s x
    refine ⟨Nat.cast_nonneg _, ?_⟩
    exact_mod_cast u_le_one s x
  have hα0 : ∀ j, 0 ≤ α j := fun j => by
    rw [hα]; exact Finset.sum_nonneg (fun a _ => (hu01 _ _).1)
  have hβ0 : ∀ j, 0 ≤ β j := fun j => by
    rw [hβ]; exact Finset.sum_nonneg (fun a _ => (hu01 _ _).1)
  have hδ0 : ∀ j, 0 ≤ δ j := fun j => by
    rw [hδ]; exact Finset.sum_nonneg (fun a _ => (hu01 _ _).1)
  have hαk : ∀ j, α j ≤ k := fun j => by
    rw [hα, ← hA']
    calc (∑ a ∈ A', (u (S j) a : ℝ)) ≤ ∑ _a ∈ A', (1 : ℝ) :=
          Finset.sum_le_sum (fun a _ => (hu01 _ _).2)
      _ = (A'.card : ℝ) := by simp
  have hβk : ∀ j, β j ≤ k := fun j => by
    rw [hβ, ← hB']
    calc (∑ b ∈ B', (u (S j) b : ℝ)) ≤ ∑ _b ∈ B', (1 : ℝ) :=
          Finset.sum_le_sum (fun b _ => (hu01 _ _).2)
      _ = (B'.card : ℝ) := by simp
  have hmissR : ∀ j, (k : ℝ) ≤ α j + β j + δ j := fun j => by
    have h := (Nat.cast_le (α := ℝ)).mpr (hmiss j)
    push_cast at h
    rw [hα, hβ, hδ]
    exact h
  -- normalised quantities
  obtain ⟨x, hx⟩ : ∃ x : Fin l → ℝ, x = fun j => α j / k := ⟨_, rfl⟩
  obtain ⟨y, hy⟩ : ∃ y : Fin l → ℝ, y = fun j => β j / k := ⟨_, rfl⟩
  obtain ⟨z, hz⟩ : ∃ z : Fin l → ℝ, z = fun j => min 1 (δ j / k) := ⟨_, rfl⟩
  have hxj : ∀ j, x j = α j / k := fun j => by rw [hx]
  have hyj : ∀ j, y j = β j / k := fun j => by rw [hy]
  have hzj : ∀ j, z j = min 1 (δ j / k) := fun j => by rw [hz]
  have hx0 : ∀ j, 0 ≤ x j := fun j => by rw [hxj]; exact div_nonneg (hα0 j) hk0.le
  have hy0 : ∀ j, 0 ≤ y j := fun j => by rw [hyj]; exact div_nonneg (hβ0 j) hk0.le
  have hx1 : ∀ j, x j ≤ 1 := fun j => by
    rw [hxj, div_le_one hk0]; exact hαk j
  have hy1 : ∀ j, y j ≤ 1 := fun j => by
    rw [hyj, div_le_one hk0]; exact hβk j
  have hz0 : ∀ j, 0 ≤ z j := fun j => by
    rw [hzj]; exact le_min zero_le_one (div_nonneg (hδ0 j) hk0.le)
  have hz1 : ∀ j, z j ≤ 1 := fun j => by rw [hzj]; exact min_le_left _ _
  have hzδ : ∀ j, (k : ℝ) * z j ≤ δ j := fun j => by
    have h : z j ≤ δ j / k := by rw [hzj]; exact min_le_right _ _
    calc (k : ℝ) * z j ≤ (k : ℝ) * (δ j / k) := mul_le_mul_of_nonneg_left h hk0.le
      _ = δ j := by field_simp
  have hcover : ∀ j, 1 ≤ x j + y j + z j := fun j => by
    rcases le_total 1 (δ j / k) with h | h
    · have hz' : z j = 1 := by rw [hzj]; exact min_eq_left h
      have := hx0 j
      have := hy0 j
      linarith
    · have hz' : z j = δ j / k := by rw [hzj]; exact min_eq_right h
      rw [hz', hxj, hyj, ← add_div, ← add_div, le_div_iff₀ hk0]
      linarith [hmissR j]
  have hper : ∀ j, -z j * lam t - (1 - z j) * (lam t - mu t) / 4
      ≤ x j * y j * mu t - (1 - x j) * (1 - y j) * lam t := fun j =>
    perList hM0 hML (hx0 j) (hx1 j) (hy0 j) (hy1 j) (hz0 j) (hcover j)
  -- the mean of the exponents
  obtain ⟨Z, hZ⟩ : ∃ Z : ℝ, Z = ∑ j : Fin l, z j := ⟨_, rfl⟩
  have hZl : Z ≤ l := by
    rw [hZ]
    calc (∑ j : Fin l, z j) ≤ ∑ _j : Fin l, (1 : ℝ) := Finset.sum_le_sum (fun j _ => hz1 j)
      _ = (l : ℝ) := by simp
  obtain ⟨B, hBdef⟩ : ∃ B : ℝ, B = Real.exp (-Z * lam t - ((l : ℝ) - Z) * (lam t - mu t) / 4) :=
    ⟨_, rfl⟩
  have hmean_le : -Z * lam t - ((l : ℝ) - Z) * (lam t - mu t) / 4
      ≤ (∑ a ∈ A', ∑ b ∈ B', Eexp S (lam t) (mu t) a b) / ((k : ℝ) * (k : ℝ)) := by
    rw [sum_Eexp S (lam t) (mu t) A' B' k hA' hB', Finset.sum_div]
    have e : ∀ j : Fin l,
        (((∑ a ∈ A', (u (S j) a : ℝ)) * (∑ b ∈ B', (u (S j) b : ℝ)) * mu t
            - ((k : ℝ) - ∑ a ∈ A', (u (S j) a : ℝ))
              * ((k : ℝ) - ∑ b ∈ B', (u (S j) b : ℝ)) * lam t) / ((k : ℝ) * (k : ℝ)))
        = x j * y j * mu t - (1 - x j) * (1 - y j) * lam t := by
      intro j
      have h1 : (∑ a ∈ A', (u (S j) a : ℝ)) = α j := by rw [hα]
      have h2 : (∑ b ∈ B', (u (S j) b : ℝ)) = β j := by rw [hβ]
      rw [h1, h2, hxj, hyj]
      field_simp
    rw [Finset.sum_congr rfl (fun j _ => e j), hZ, ← sum_lower_form z (lam t) (lam t - mu t)]
    exact Finset.sum_le_sum (fun j _ => hper j)
  -- AM-GM
  have hIne : (A' ×ˢ B').Nonempty := by
    apply Finset.card_pos.mp
    rw [Finset.card_product, hA', hB']
    exact Nat.mul_pos (by omega) (by omega)
  have havg := exp_avg (A' ×ˢ B') hIne (fun p => Eexp S (lam t) (mu t) p.1 p.2)
  rw [Finset.sum_product, Finset.sum_product, Finset.card_product, hA', hB'] at havg
  push_cast at havg
  have hsumW : (∑ a ∈ A', ∑ b ∈ B', W t S a b)
      = ∑ a ∈ A', ∑ b ∈ B', Real.exp (Eexp S (lam t) (mu t) a b) :=
    Finset.sum_congr rfl (fun a ha => Finset.sum_congr rfl (fun b hb =>
      W_eq_exp ht hS hmt (hne a ha b hb)))
  have hk2 : (k : ℝ) * (k : ℝ) * B ≤ ∑ a ∈ A', ∑ b ∈ B', W t S a b := by
    rw [hsumW]
    refine le_trans ?_ havg
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    rw [hBdef]
    exact Real.exp_le_exp.mpr hmean_le
  -- finishing
  have hscalar := scalar_main ht l hl hZl
  have hBy := pow_le_B ht l hZl
  rw [← hBdef] at hscalar hBy
  have hΔ : (k : ℝ) * Z ≤ Delta D S := by
    rw [Delta_eq, hZ, Finset.mul_sum]
    exact Finset.sum_le_sum (fun j _ => by
      have := hzδ j
      rw [hδ] at this
      exact this)
  have hΔt : (k : ℝ) * (Z / t) ≤ Delta D S / t := by
    have := div_le_div_of_nonneg_right hΔ htpos.le
    rw [mul_div_assoc] at this
    exact this
  obtain ⟨y0, hy0def⟩ : ∃ y0 : ℝ, y0 = (1 - 1 / t) ^ l := ⟨_, rfl⟩
  rw [← hy0def] at hscalar hBy ⊢
  have h1 : (k : ℝ) * (1 + y0) ≤ (k : ℝ) * (Z / t + 2 * B) :=
    mul_le_mul_of_nonneg_left hscalar hk0.le
  have h2 : 0 ≤ (k : ℝ) * ((k : ℝ) - 2) * (B - y0) :=
    mul_nonneg (mul_nonneg hk0.le (by linarith)) (sub_nonneg.mpr hBy)
  nlinarith only [h1, h2, hΔt, hk2]

end ListCol
