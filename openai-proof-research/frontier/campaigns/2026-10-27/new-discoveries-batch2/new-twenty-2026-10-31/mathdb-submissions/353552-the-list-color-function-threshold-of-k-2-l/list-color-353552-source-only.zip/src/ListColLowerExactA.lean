import ListColEndpoint
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# Source Theorem 4 exactly: weights of the balanced assignment for `t ≥ 2`

The sum of the four special pairs is at most `4 κ ^ (l/4)`, with no extra factor, because
`s + q = 2` and `s q ≤ 1` (the balancing idea of the source).
-/

open scoped Classical
open Finset

namespace ListCol

variable {c l : ℕ} {t : ℝ}

lemma W_off_eq' (htpos : 0 < t) {l m : ℕ} {S : Fin l → Finset ℕ} (hS : ∀ j, (S j).card = m)
    (hmt : t = (m : ℝ) - 1) {a b : ℕ} (hab : a ≠ b) :
    W t S a b = (1 - 1 / t) ^ jointIn S a b * (1 + 1 / t) ^ jointMiss S a b := by
  have hm : (m : ℝ) = t + 1 := by rw [hmt]; ring
  have hfac : ∀ j : Fin l, (((((S j).erase a).erase b).card : ℝ) / t)
      = (1 - 1 / t) ^ (if a ∈ S j ∧ b ∈ S j then 1 else 0)
        * (1 + 1 / t) ^ (if a ∉ S j ∧ b ∉ S j then 1 else 0) := by
    intro j
    rw [card_real_off (hS j) hab, hm]
    by_cases ha : a ∈ S j <;> by_cases hb : b ∈ S j
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 1 := by simp [ha, hb]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 0 := by simp [ha]
      rw [u_of_mem ha, u_of_mem hb, e1, e2]
      push_cast
      field_simp
      ring
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [hb]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 0 := by simp [ha]
      rw [u_of_mem ha, u_of_not_mem hb, e1, e2]
      push_cast
      field_simp
      ring
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [ha]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 0 := by simp [hb]
      rw [u_of_not_mem ha, u_of_mem hb, e1, e2]
      push_cast
      field_simp
      ring
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [ha]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 1 := by simp [ha, hb]
      rw [u_of_not_mem ha, u_of_not_mem hb, e1, e2]
      push_cast
      field_simp
      ring
  unfold W
  rw [Finset.prod_congr rfl (fun j _ => hfac j), Finset.prod_mul_distrib,
    Finset.prod_pow_eq_pow_sum, Finset.prod_pow_eq_pow_sum]
  congr 2
  · unfold jointIn
    exact Finset.sum_boole _ _
  · unfold jointMiss
    exact Finset.sum_boole _ _

lemma W_diag_of_all_mem' (htpos : 0 < t) {l m : ℕ} {S : Fin l → Finset ℕ}
    (hS : ∀ j, (S j).card = m) (hmt : t = (m : ℝ) - 1) {a : ℕ} (ha : ∀ j, a ∈ S j) :
    W t S a a = 1 := by
  have hm : (m : ℝ) = t + 1 := by rw [hmt]; ring
  unfold W
  refine Finset.prod_eq_one (fun j _ => ?_)
  rw [card_real_diag (hS j) a, hm, u_of_mem (ha j)]
  push_cast
  field_simp
  ring

lemma s0' (ht2 : 2 ≤ t) : 0 < 1 - 1 / t := by
  have h : 1 / t ≤ 1 / 2 := by
    rw [div_le_div_iff₀ (by linarith) (by norm_num)]
    linarith
  linarith

lemma s1' (ht2 : 2 ≤ t) : 1 - 1 / t ≤ 1 := by
  have h : 0 < 1 / t := by
    have : 0 < t := by linarith
    positivity
  linarith

lemma q0' (ht2 : 2 ≤ t) : 0 < 1 + 1 / t := by
  have h : 0 < 1 / t := by
    have : 0 < t := by linarith
    positivity
  linarith

lemma W_low_low' (ht2 : 2 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {a b : ℕ} (ha : a < c) (hb : b < c)
    (hab : a ≠ b) : W t (badS c : Fin l → Finset ℕ) a b = (1 - 1 / t) ^ l := by
  rw [W_off_eq' (by linarith) (fun j => card_badS c j) hmt hab, jointMiss_left_low ha b]
  have h : jointIn (badS c : Fin l → Finset ℕ) a b = l := by
    unfold jointIn
    rw [Finset.filter_true_of_mem (fun j _ => ⟨bad_low c j ha, bad_low c j hb⟩), Finset.card_univ,
      Fintype.card_fin]
  rw [h, pow_zero, mul_one]

lemma W_low_specB' (ht2 : 2 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {a : ℕ} (ha : a < c) {β : ℕ}
    (hβ : β < 2) :
    W t (badS c : Fin l → Finset ℕ) a (c + 2 + β) ≤ (1 - 1 / t) ^ (2 * (l / 4)) := by
  have hab : a ≠ c + 2 + β := by omega
  rw [W_off_eq' (by linarith) (fun j => card_badS c j) hmt hab, jointMiss_left_low ha _, pow_zero,
    mul_one]
  apply pow_le_pow_of_le_one (s0' ht2).le (s1' ht2)
  unfold jointIn
  apply two_res_le (r1 := 2 * β) (r2 := 2 * β + 1) _ (by omega) (by omega) (by omega)
  intro j hj
  exact ⟨bad_low c j ha, (mem_spec_B c j hβ).2 (by omega)⟩

lemma W_specA_low' (ht2 : 2 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {α : ℕ} (hα : α < 2) {b : ℕ}
    (hb : b < c) :
    W t (badS c : Fin l → Finset ℕ) (c + α) b ≤ (1 - 1 / t) ^ (2 * (l / 4)) := by
  have hab : c + α ≠ b := by omega
  rw [W_off_eq' (by linarith) (fun j => card_badS c j) hmt hab, jointMiss_right_low _ hb, pow_zero,
    mul_one]
  apply pow_le_pow_of_le_one (s0' ht2).le (s1' ht2)
  unfold jointIn
  apply two_res_le (r1 := α) (r2 := α + 2) _ (by omega) (by omega) (by omega)
  intro j hj
  exact ⟨(mem_spec_A c j hα).2 (by omega), bad_low c j hb⟩

lemma resC_eq (l r : ℕ) (hr : r < 4) : resC l r = l / 4 + if r < l % 4 then 1 else 0 := by
  unfold resC
  exact res_count l r hr

lemma jointIn_spec {α β : ℕ} (hα : α < 2) (hβ : β < 2) :
    jointIn (badS c : Fin l → Finset ℕ) (c + α) (c + 2 + β) = resC l (α + 2 * β) := by
  unfold jointIn resC
  congr 1
  ext j
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  rw [mem_spec_A c j hα, mem_spec_B c j hβ]
  omega

lemma jointMiss_spec {α β : ℕ} (hα : α < 2) (hβ : β < 2) :
    jointMiss (badS c : Fin l → Finset ℕ) (c + α) (c + 2 + β) = resC l (1 - α + 2 * (1 - β)) := by
  unfold jointMiss resC
  congr 1
  ext j
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  rw [mem_spec_A c j hα, mem_spec_B c j hβ]
  omega

/-- The exact value of a special-pair weight. -/
lemma W_spec_val (ht2 : 2 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) {α β r r' : ℕ} (hα : α < 2)
    (hβ : β < 2) (hr : r = α + 2 * β) (hr' : r' = 1 - α + 2 * (1 - β)) :
    W t (badS c : Fin l → Finset ℕ) (c + α) (c + 2 + β)
      = ((1 - 1 / t) * (1 + 1 / t)) ^ (l / 4)
        * ((1 - 1 / t) ^ (if r < l % 4 then 1 else 0)
          * (1 + 1 / t) ^ (if r' < l % 4 then 1 else 0)) := by
  have hab : c + α ≠ c + 2 + β := by omega
  rw [W_off_eq' (by linarith) (fun j => card_badS c j) hmt hab, jointIn_spec hα hβ,
    jointMiss_spec hα hβ, ← hr, ← hr', resC_eq l r (by omega), resC_eq l r' (by omega), pow_add,
    pow_add, mul_pow]
  ring

/-- The balancing computation: the four special pairs sum to at most `4 κ ^ (l/4)`. -/
lemma four_spec_le (ht2 : 2 ≤ t) (hmt : t = ((c + 2 : ℕ) : ℝ) - 1) :
    W t (badS c : Fin l → Finset ℕ) (c + 0) (c + 2 + 0)
      + W t (badS c : Fin l → Finset ℕ) (c + 1) (c + 2 + 0)
      + W t (badS c : Fin l → Finset ℕ) (c + 0) (c + 2 + 1)
      + W t (badS c : Fin l → Finset ℕ) (c + 1) (c + 2 + 1)
      ≤ 4 * ((1 - 1 / t) * (1 + 1 / t)) ^ (l / 4) := by
  have h0 := W_spec_val (l := l) ht2 hmt (α := 0) (β := 0) (r := 0) (r' := 3) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num)
  have h1 := W_spec_val (l := l) ht2 hmt (α := 1) (β := 0) (r := 1) (r' := 2) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num)
  have h2 := W_spec_val (l := l) ht2 hmt (α := 0) (β := 1) (r := 2) (r' := 1) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num)
  have h3 := W_spec_val (l := l) ht2 hmt (α := 1) (β := 1) (r := 3) (r' := 0) (by norm_num)
    (by norm_num) (by norm_num) (by norm_num)
  rw [h0, h1, h2, h3]
  obtain ⟨A, hA⟩ : ∃ A : ℝ, A = ((1 - 1 / t) * (1 + 1 / t)) ^ (l / 4) := ⟨_, rfl⟩
  obtain ⟨s, hs⟩ : ∃ s : ℝ, s = 1 - 1 / t := ⟨_, rfl⟩
  obtain ⟨q, hq⟩ : ∃ q : ℝ, q = 1 + 1 / t := ⟨_, rfl⟩
  rw [← hA, ← hs, ← hq]
  have hA0 : 0 ≤ A := by
    rw [hA]
    exact pow_nonneg (mul_nonneg (s0' ht2).le (q0' ht2).le) _
  have hsq : s + q = 2 := by
    rw [hs, hq]
    ring
  have hprod : s * q ≤ 1 := by
    rw [hs, hq]
    have h : (1 - 1 / t) * (1 + 1 / t) = 1 - (1 / t) ^ 2 := by ring
    rw [h]
    nlinarith [sq_nonneg (1 / t)]
  have he : l % 4 < 4 := Nat.mod_lt _ (by norm_num)
  have hcases : l % 4 = 0 ∨ l % 4 = 1 ∨ l % 4 = 2 ∨ l % 4 = 3 := by omega
  rcases hcases with h | h | h | h
  · rw [h]
    norm_num
    linarith
  · rw [h]
    norm_num
    nlinarith only [hsq, hA0]
  · rw [h]
    norm_num
    nlinarith only [hsq, hA0]
  · rw [h]
    norm_num
    nlinarith only [hsq, hprod, hA0, mul_nonneg hA0 (sub_nonneg.mpr hprod)]

end ListCol
