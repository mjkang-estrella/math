import ListColMainIneq
import Mathlib.Data.Int.CardIntervalMod
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# The balanced assignment on `Fin l`: combinatorial data and weights

`A = {0, ..., c+1}`, `B = {0, ..., c-1} ∪ {c+2, c+3}`, and the `j`-th list on the large side is
`{0, ..., c-1} ∪ {c + (j % 2), c + 2 + (j / 2) % 2}`, as in the balanced assignments of
Kaul--Kumar--Mudrock--Rewers--Shin--To, arXiv:2202.03431.
-/

open scoped Classical
open Finset

namespace ListCol

/-- Exact residue count on `Fin l`. -/
lemma res_count (l r : ℕ) (hr : r < 4) :
    ((Finset.univ : Finset (Fin l)).filter (fun j => j.val % 4 = r)).card
      = l / 4 + if r < l % 4 then 1 else 0 := by
  have h := Nat.count_modEq_card l (by norm_num : 0 < 4) r
  rw [Nat.count_eq_card_filter_range, Nat.mod_eq_of_lt hr] at h
  rw [← h]
  apply Finset.card_bij (fun (j : Fin l) _ => (j : ℕ))
  · intro j hj
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj
    simp only [Finset.mem_filter, Finset.mem_range]
    refine ⟨j.isLt, ?_⟩
    unfold Nat.ModEq
    omega
  · intro a _ b _ h
    exact Fin.ext h
  · intro b hb
    simp only [Finset.mem_filter, Finset.mem_range] at hb
    refine ⟨⟨b, hb.1⟩, ?_, rfl⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    have h2 := hb.2
    unfold Nat.ModEq at h2
    omega

/-- The number of indices with a given residue mod `4`. -/
noncomputable def resC (l r : ℕ) : ℕ :=
  ((Finset.univ : Finset (Fin l)).filter (fun j => j.val % 4 = r)).card

lemma resC_ge (l r : ℕ) (hr : r < 4) : l / 4 ≤ resC l r := by
  unfold resC
  rw [res_count l r hr]
  omega

lemma resC_le (l r : ℕ) (hr : r < 4) : resC l r ≤ l / 4 + 1 := by
  unfold resC
  rw [res_count l r hr]
  split_ifs <;> omega

/-- Two residues contribute at least `2 (l/4)` indices. -/
lemma two_res_le {l : ℕ} (P : Fin l → Prop) [DecidablePred P] {r1 r2 : ℕ} (h1 : r1 < 4) (h2 : r2 < 4) (hne : r1 ≠ r2)
    (hP : ∀ j : Fin l, (j.val % 4 = r1 ∨ j.val % 4 = r2) → P j) :
    2 * (l / 4) ≤ ((Finset.univ : Finset (Fin l)).filter P).card := by
  have hsub : ((Finset.univ : Finset (Fin l)).filter (fun j => j.val % 4 = r1))
      ∪ ((Finset.univ : Finset (Fin l)).filter (fun j => j.val % 4 = r2))
      ⊆ (Finset.univ : Finset (Fin l)).filter P := by
    intro j hj
    simp only [Finset.mem_union, Finset.mem_filter, Finset.mem_univ, true_and] at hj
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    exact hP j hj
  have hdis : Disjoint ((Finset.univ : Finset (Fin l)).filter (fun j => j.val % 4 = r1))
      ((Finset.univ : Finset (Fin l)).filter (fun j => j.val % 4 = r2)) := by
    rw [Finset.disjoint_left]
    intro j hj1 hj2
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hj1 hj2
    omega
  have hcard := Finset.card_le_card hsub
  rw [Finset.card_union_of_disjoint hdis] at hcard
  have g1 := resC_ge l r1 h1
  have g2 := resC_ge l r2 h2
  unfold resC at g1 g2
  omega

/-- The `j`-th list of the balanced assignment. -/
def badS (c : ℕ) {l : ℕ} (j : Fin l) : Finset ℕ :=
  insert (c + j.val % 2) (insert (c + 2 + j.val / 2 % 2) (Finset.range c))

/-- The list of the second vertex of the size-two side. -/
def badB (c : ℕ) : Finset ℕ := insert (c + 2) (insert (c + 3) (Finset.range c))

lemma mem_badS (c : ℕ) {l : ℕ} (j : Fin l) (x : ℕ) :
    x ∈ badS c j ↔ x = c + j.val % 2 ∨ x = c + 2 + j.val / 2 % 2 ∨ x < c := by
  simp [badS, Finset.mem_insert, Finset.mem_range]

lemma mem_badB (c x : ℕ) : x ∈ badB c ↔ x = c + 2 ∨ x = c + 3 ∨ x < c := by
  simp [badB, Finset.mem_insert, Finset.mem_range]

lemma card_badS (c : ℕ) {l : ℕ} (j : Fin l) : (badS c j).card = c + 2 := by
  unfold badS
  rw [Finset.card_insert_of_notMem, Finset.card_insert_of_notMem, Finset.card_range]
  · simp only [Finset.mem_range]
    omega
  · simp only [Finset.mem_insert, Finset.mem_range]
    omega

lemma card_badB (c : ℕ) : (badB c).card = c + 2 := by
  unfold badB
  rw [Finset.card_insert_of_notMem, Finset.card_insert_of_notMem, Finset.card_range]
  · simp
  · simp only [Finset.mem_insert, Finset.mem_range]
    omega

/-- The count of lists containing both `a` and `b`. -/
noncomputable def jointIn {l : ℕ} (S : Fin l → Finset ℕ) (a b : ℕ) : ℕ :=
  ((Finset.univ : Finset (Fin l)).filter (fun j => a ∈ S j ∧ b ∈ S j)).card

/-- Exact value of an off-diagonal weight. -/
lemma W_off_eq {t : ℝ} (ht : 3 ≤ t) {l m : ℕ} {S : Fin l → Finset ℕ} (hS : ∀ j, (S j).card = m)
    (hmt : t = (m : ℝ) - 1) {a b : ℕ} (hab : a ≠ b) :
    W t S a b = (1 - 1 / t) ^ jointIn S a b * (1 + 1 / t) ^ jointMiss S a b := by
  have htpos : 0 < t := by linarith
  have hm : (m : ℝ) = t + 1 := by rw [hmt]; ring
  have hfac : ∀ j : Fin l, (((((S j).erase a).erase b).card : ℝ) / t)
      = (1 - 1 / t) ^ (if a ∈ S j ∧ b ∈ S j then 1 else 0)
        * (1 + 1 / t) ^ (if a ∉ S j ∧ b ∉ S j then 1 else 0) := by
    intro j
    rw [card_real_off (hS j) hab, hm]
    by_cases ha : a ∈ S j <;> by_cases hb : b ∈ S j
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 1 := by simp [ha, hb]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 0 := by simp [ha]
      rw [u_of_mem ha, u_of_mem hb, e1, e2]
      push_cast
      field_simp
      ring
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [hb]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 0 := by simp [ha]
      rw [u_of_mem ha, u_of_not_mem hb, e1, e2]
      push_cast
      field_simp
      ring
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [ha]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 0 := by simp [hb]
      rw [u_of_not_mem ha, u_of_mem hb, e1, e2]
      push_cast
      field_simp
      ring
    · have e1 : (if a ∈ S j ∧ b ∈ S j then 1 else 0) = 0 := by simp [ha]
      have e2 : (if a ∉ S j ∧ b ∉ S j then 1 else 0) = 1 := by simp [ha, hb]
      rw [u_of_not_mem ha, u_of_not_mem hb, e1, e2]
      push_cast
      field_simp
      ring
  unfold W
  rw [Finset.prod_congr rfl (fun j _ => hfac j), Finset.prod_mul_distrib,
    Finset.prod_pow_eq_pow_sum, Finset.prod_pow_eq_pow_sum]
  congr 2
  · unfold jointIn
    exact Finset.sum_boole _ _
  · unfold jointMiss
    exact Finset.sum_boole _ _

/-- The diagonal weight of a colour present in every list is `1`. -/
lemma W_diag_of_all_mem {t : ℝ} (ht : 3 ≤ t) {l m : ℕ} {S : Fin l → Finset ℕ}
    (hS : ∀ j, (S j).card = m) (hmt : t = (m : ℝ) - 1) {a : ℕ} (ha : ∀ j, a ∈ S j) :
    W t S a a = 1 := by
  have htpos : 0 < t := by linarith
  have hm : (m : ℝ) = t + 1 := by rw [hmt]; ring
  unfold W
  refine Finset.prod_eq_one (fun j _ => ?_)
  rw [card_real_diag (hS j) a, hm, u_of_mem (ha j)]
  push_cast
  field_simp
  ring

end ListCol
