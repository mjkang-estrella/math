import re,json,hashlib
from pathlib import Path,PurePosixPath

def extract(data,expected):
 data.decode('utf-8',errors='strict')
 pat=re.compile(rb'<!-- BEGIN FILE ([^\r\n]+) ([0-9a-f]{64}) -->\n```(lean|text)\n')
 out={}; pos=0
 for m in pat.finditer(data):
  gap=data[pos:m.start()]
  if b'<!-- BEGIN FILE' in gap or b'<!-- END FILE' in gap: raise ValueError('malformed boundary')
  name=m[1].decode('utf-8'); p=PurePosixPath(name)
  if p.is_absolute() or '..' in p.parts or str(p)!=name or '\\' in name: raise ValueError('path')
  if m[3] != (b'lean' if name.startswith('src/') else b'text'): raise ValueError('fence language')
  if name not in expected or name in out: raise ValueError('unexpected/duplicate')
  end=data.find(b'\n```\n<!-- END FILE -->',m.end())
  if end<0: raise ValueError('fence/end')
  body=data[m.end():end+1]
  if b'\n```' in body: raise ValueError('nested/fence')
  sha=hashlib.sha256(body).hexdigest()
  if sha!=m[2].decode() or sha!=expected[name]: raise ValueError('hash')
  out[name]=body;pos=end+len(b'\n```\n<!-- END FILE -->')
 if b'BEGIN FILE' in data[pos:] or b'END FILE' in data[pos:]: raise ValueError('trailing boundary')
 if set(out)!=set(expected) or len(out)!=54: raise ValueError('missing/count')
 return out

