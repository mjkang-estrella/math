# Independent replay and fidelity v1 — MathDB 358145

2026-11-14 UTC. Reviewer: GPT-6.1 Sol/high/default. No children. This is a new independent review, with a new 128-call formal allocation. Credit 0; counts remain 62/80 NEW, 101 total.

## Separate verdicts

| Gate | Outcome |
|---|---|
| Owned source v3 statement fidelity | PASS |
| Owned journal-final statement fidelity | PASS |
| Ordinary full-scope proof | PASS |
| Exact unchanged Lean endpoint | PASS |
| Strict appendix extraction | PASS, 54 files, 12 negative tests |
| Fresh production compile | PASS, 45/45 in graph order |
| Separate production kernel checks | PASS, 45/45 |
| Independent audit compile/check | PASS, 2/2 |
| Allowed axioms and supplied pins | PASS within declared upstream trust |
| Paper mathematical completeness and replay packaging | PASS with this independent extraction procedure |
| Contribution | Conditional SUBSTANTIAL; overall HOLD |
| Raw MathDB binding/current-prior/protected registry/full101/final acceptance/process | HOLD |

No mathematical GAP was found in the claimed partition inequality. None of these scoped PASS verdicts clears the held acceptance gates or waives process defects.

## Source authentication and exact scope

I visually inspected owned arXiv:2304.10708v3 PDF pages 1,3,5,11, including the 26 January 2024 version strip; and the owned journal PDF pages 1,3,5,10,11. Journal page 11 was an initial location attempt; the conjecture actually occurs on PDF page 10, printed 294. The journal is International Journal of Group Theory 14(4) (2025), 285–296, DOI 10.22108/ijgt.2024.140888.1896, online 12 November 2024. These are observations of owned files, not fresh online verification.

The rows are positive and weakly decreasing, indexed from one. L is their length; h_j is the number of rows at least j, with every missing column zero. The literal statistic is
Psi = choose(L,2) + sum_i (i-1)lambda_i + sum_(j>=1) h_j h_(j+1).
Both versions' Conjecture 5.2 assert strict D(n)>0 for all n>=7, where D(n)=choose(n,2)p(n)-sum_(lambda partitions n)Psi(lambda). This is an isolated partition inequality. No field-size, prime-power or group-integrality premise belongs to its endpoint. The empty partition gives p(0)=1. The private original MathDB binding is unavailable: raw binding remains HOLD.

## Independent ordinary proof and dependency bridges

Let m_a count parts of size a, T=sum_i(i-1)lambda_i and s=sum_a m_a(m_a+1)/2. Counting ordered pairs of boxes in columns gives sum_j h_j^2=n+2T. Since h_j-h_(j+1)=m_j, telescoping squares gives s+choose(L,2)+sum_j h_j h_(j+1)=sum_j h_j^2. Therefore Psi+s=n+3T, pointwise. Deleting t copies of a part a bijects the multiplicity tail with partitions of n-at. Summing the triangular multiplicity layers gives total s=n*p(n): the coefficient sums sum_(at=k)t and sum_(at=k)a agree by swapping factors, while marked boxes give the latter recurrence. Thus total Psi=3 total T and
2D(n)=(n^2+2n)p(n)-3 sum_lambda sum_j h_j^2.

For A_a=x^a/(1-x^a), the normalized multiplicity moments are E(m_a)=A_a, E(m_a^2)=A_a+2A_a^2 and E(m_a m_b)=A_a A_b for a!=b. Expanding n^2 and the column squares gives the diagonal weight (a^2-3a)(2t-1)+2a at at=k and mixed weight 2a(b-3) at at+bu=k, a<b. All indices are positive. Consequently the canonical coefficient c in the appendix satisfies
2D(n)=sum_(k=1..n)c(k)p(n-k).
Every manipulation is coefficientwise finite; the empty case also holds. The factor is 2D throughout. The extracted finite fiber/tail proofs connect this identity to actual partitions, rather than assuming a generic convolution equals D.

For k>=3 the a=1,2 diagonal fibers are bounded below by -4k,-2k. Other diagonal fibers are nonnegative; retaining a=k contributes k^2-k, giving diagonal total >=k^2-7k. Only (a,b)=(1,2) can give a negative mixed fiber, weight -2; each t admits at most one u, so the mixed total is >=-2k. Hence c(k)>=k^2-9k and is positive for k>=10. Direct exact evaluation gives c(0..12)=(0,0,-2,-4,-4,2,16,38,80,128,210,280,448), paying every exceptional degree 5..9. No negative degree is discarded.

The corresponding extracted interfaces are recorded completely in bridge-interfaces-v1.txt. I read these interfaces and the endpoint, literal statistic, source reduction, coefficient bounds, actual convolution, DP, injection, Euler/adjacent and ratio proof bodies in bounded slices. Large repetitive finite proof terms were sampled and kernel-checked, not represented as personally read line by line. Exact read limits are retained separately.

The Euler recurrence n*p(n)=sum_(k=1..n)sigma(k)p(n-k) follows from marking a box. The finite b(n,k) recurrence deletes one part k when present; b(0,k)=1 and b(n,0)=0 for n>0. The actual bounded-partition equivalence proves b(n,k)=p(n) for k>=n. Thus the 168 ratio bases 7..174 in the abstract recurrence certificate are instantiated with actual p, with no unproved counting-sequence premise.

For n>=175, subtract 3/2 times the recurrence at n-1. After reversal, the remainder is sigma(n)+sum_(j=1..n-1)sigma(n-j)[p(j)-3p(j-1)/2]. Strong induction makes all j>=7 brackets nonpositive. The first six brackets are (-1/2,1/2,0,1/2,-1/2,1/2); sigma(k)<=k^2 bounds the whole remainder by (5/2)n^2, including the boundary sigma(n). Let t=floor((n-1)/20). Independent multiplicities 0..t for sizes 2,3,4,5,6, filled with ones, give (t+1)^5 distinct partitions of n-1, so p(n-1)>=(n/20)^5. Since 3*175^3=16078125>5*20^5=16000000, (3/2)p(n-1)>(5/2)n^2. This pays the extra (3/2)p(n-1) when replacing n-1 by n on the left. Therefore 2p(n)<=3p(n-1) uniformly for n>=7. No ratio monotonicity or analytic asymptotic estimate is assumed.

For n>=13, let F=p(n-7)>0. Retain degrees 2,3,4,6,7 of the convolution; everything omitted is nonnegative. Five ratio steps give p(n-2)<=243F/32, p(n-3)<=81F/16, p(n-4)<=27F/8, and monotonicity gives p(n-6)>=F. Therefore
2D(n)>=(-2*243/32-4*81/16-4*27/8+16+38)F=(81/16)F>0.
The last ratio step is at n-6>=7, including n=13. Adding a part one proves monotonicity, and the all-ones partition proves positivity, so no generic hypotheses remain. Direct actual-partition computation gives D(7..12)=(6,43,120,279,551,1056); the formal finite bridge separately proves their positivity. These ranges cover every natural n>=7. Any integer n>=7 equals the cast of n.toNat, giving the unchanged IntegerTarget.

The ordinary paper supplies every bridge above. Its table and finite-source definitions agree with the formal route. I found no changed convention, eventual-only conclusion, unpaid factor, or missing finite interval. This correctness judgment does not decide whether an older proof or routine specialization exists.

## Strict extraction, unchanged source, and replay

PAPER-v1.md was read completely alongside the appendix header, recovered source and dependency graph. strict_extract_v1.py was my first independent parser; it rejected the valid appendix because it treated prose mentioning BEGIN FILE as a boundary and omitted the declared text fence. Its failed receipt and full stderr are preserved. v2 corrected those reviewer bugs, recovered exactly 54 declared files, and rejected traversal, duplicate, missing, unexpected, body-hash, bad-fence and malformed-end cases. v3 additionally enforces lean fences for src files and text fences for documentary helpers; it rejects invalid UTF-8, a wrong header hash, wrong fence language, CRLF substitution and a missing end. No malformed input was executed.

The extractor validates the entire block set before writing, uses a fixed frozen expected name/hash map, rejects absolute/traversing/noncanonical paths, duplicate/unexpected/missing names, malformed boundaries and fences, and checks header and expected SHA256 against exact UTF-8 payload bytes including final newlines. v3 re-extraction equals all v2 payloads byte-for-byte. extraction-ledger-v1.json records all 54 lengths/hashes; strict-v3-validation.json adds the last five failures. No producer mathematical source, paper or appendix repair was needed. No changed candidate is being passed off as an unchanged replay.

All 45 recovered Lean files exactly match SOURCE-PROOF-PINS.json; imports exactly match PRODUCTION-GRAPH-v9.json and are topological. The reviewer src/, build/, cache/ were empty at extraction. Only appendix-extracted payloads populated production src/. No producer build/cache/olean was read or copied. Every production compile started with no corresponding olean; the local cache remained empty. Standard/upstream libraries alone were trusted as declared.

Seven shared helper/pin payloads are byte-identical to the frozen reviewer copies: PINS, check32, checker32, formal_command, run_lean_32g, run, write_lane. The extracted extract_appendix.py was documentary only and never executed; my parser replaces its use. The ninth helper, formal-budget.json, remains byte-exact historical allocation 72 and is never used as this task's authority. The active allocation remains formal-execution-budget.json =128.

Reproduction: in a fresh authorized lane with the same pinned wrappers, use strict_extract_v3.extract on the appendix bytes and frozen APPENDIX-FILE-HASHES map, write the verified src payloads, start empty build/cache, then invoke bash ./check32.sh MODULE UNIQUE_LABEL for every module in graph order, followed by bash ./checker32.sh MODULE UNIQUE_LABEL for every module. The independent audit source is src/IndependentAudit.lean. This report's directory contains the complete original inputs and recovered sources.

## Formal endpoint, axioms, pins, and resource receipts

All 45 compiles c01..c45 and all 45 separate kernel checks k01..k45 passed. audit91 and audit92 compile and kernel-check the new reviewer audit. Total 92/128 formal calls; failures 0. Formal CPU total 211.621190 seconds, wall total 212.491627 seconds; maximum individual CPU 35.892262 seconds, wall 35.901934 seconds; peak sampled group RSS 3535843328 bytes. FORMAL-ACCOUNTING-v1.json contains every receipt, command and production metadata record. Every call's full stdout is LABEL.output.txt, stderr and full command are in LABEL.receipt.json, and wrapper console output is LABEL.display.txt. All formal stderr is empty. Source hashes are unchanged before/after each operation; checker hashes equal compiled olean hashes.

The audit independently type-checks Harada.target_proved : Harada.Target and Harada.integerTarget_proved : Harada.IntegerTarget and their explicit forall forms. It prints Rows, rows, column, T, psi, p, D, Target, IntegerTarget, canonical coeff, convolution, p_zero, uniform_ratio and endpoint proofs. Definitions are unchanged: p is card of all Nat.Partition n; D is integer subtraction; natural Target is forall n>=7, 0<D(n); IntegerTarget quantifies all integers n>=7 and uses their exact nonnegative representative. There is no free q, kernel, ratio, statistic, positive-source or group hypothesis. Audit output confirms both endpoints, actual convolution and uniform ratio depend exactly on propext, Classical.choice, Quot.sound. The entire production-source forbidden-token scan is empty, including sorry/admit/axiom/unsafe/native_decide and blanket import Mathlib.

Pin verification matched Lean and leanchecker executable SHA256, runtime 4.34.1, detached mathlib HEAD d13f23b723b8a846827a245b89c10fc7d3f11612, both supplied metadata hashes and existence of all eight upstream dependency paths. This is a pinned-tool/upstream-trust result, not a provenance audit of every upstream olean. Only the own frozen wrappers executed formal operations, retaining AS32GiB solely for compile/check, group RSS6GiB, CPU115, wall130, affinity2, j1, M3500 and warnings-as-errors. Documentary work used the 6GiB runner.

One of six scientific runs was used: exact_check_v1.py, saved inputs/bounds and outputs in exact-check-v1.json and exact-check-run1 receipt/output. It checked p through175, all 176 paper rows, all 168 ratio bases, c through12, literal Psi enumeration on 7..12 and equality with the doubled convolution. CPU 0.016074 seconds, wall 0.003501 seconds; no failure. Finite evidence is not used as a substitute for uniform proof. No search/network, installation, git, external messages, publication, account mutation, other-lane body read or children occurred.

## Hostile self-review, qualification, and unwaived process

The danger points were statistic conventions, dropped negative coefficients, the factor two, a generic helper masquerading as the endpoint, finite bases for an unrelated sequence, an induction that loses sigma(n), the extra p(n-1) payment, and an n=13 threshold gap. The source map, recurrence equivalences, actual convolution and independent audit address each. Strict replay succeeds on unchanged source. The ordinary series calculation is algebraic and finite at each degree; no numerical asymptotics or convergence premise enters. The very large abstract certificate bodies were not personally read exhaustively; every one was freshly compiled and separately checked, with actual b laws discharged. That distinction remains explicit.

The retained prior-qualification report supports conditional SUBSTANTIAL only. I read its judgment, direct coefficient/ratio route and current-publication gap discussion, not all underlying comparison arguments or their original papers. Its bounded failure to find an exact public counterpart is not worldwide novelty. Abe/Hida–Sugimoto current-final comparisons, unread predecessor derivations, chronology and other synonymous partition-statistic literature remain gaps. No fresh literature requests were authorized or made in this focused replay. Current-prior, protected registry/head, credited-family/full101 and raw MathDB binding remain HOLD. The parent alone can adjudicate contribution, novelty and acceptance. No acceptance or credit increment follows from this report.

Process HOLD is explicit. All producer/inherited deviations in FORMAL-HANDOFF-v9.md remain UNWAIVED. This review also has unwaived defects: initial run.py/write_lane.py interface reads used direct shell before switching to the runner; one functions call combined three bounded AGENTS reads into an oversized aggregate response; broad host matching unnecessarily displayed unrelated denial-key fragments; full normalized title/author and journal-host screening was completed after initial owned body/header access rather than wholly prospectively; several result-generation scripts wrote owned files with Path.write_text/write_bytes inside the capped runner rather than routing every write through write_lane.py. Some combined displays and a selected audit metadata line exceeded the logical display intention. None is a mathematical repair or a permission grant. No restricted source was requested or origin followed. This is not a clean-process PASS.

The only failed documentary invocation was strict-extraction (the reviewer v1 parser error); full stderr remains in its receipt. Corrections v1→v2→v3 are explicit own extractor versions, not edits of producer proofs. Scientific/formal failures are zero. Oversized or filtered output is not claimed as full personal reading. The full audit proof-print output is retained (158427 characters), but only definitions, endpoint types, selected bridges and all four transitive axiom lines were personally inspected.

## Handoff and sealing protocol

All report content and inventory are written before standalone frozen-after. The actual after outcome belongs to frozen-after.json; the actual exhaustive seal outcome belongs to SHA256SUMS.json and seal.receipt.json/output.txt. The manifest excludes exactly itself, its generating receipt and its stdout. No commands or writes follow sealing. Final acceptance/process gates stay HOLD regardless of the frozen/hash outcome.

## Complete artifact locations

Lane root: /home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1

- [inputs/PAPER-v1.md](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/inputs/PAPER-v1.md)
- [inputs/EXACT-LEAN-APPENDIX-v1.md](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/inputs/EXACT-LEAN-APPENDIX-v1.md)
- [inputs/PRODUCTION-GRAPH-v9.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/inputs/PRODUCTION-GRAPH-v9.json)
- [REPLAY-AND-FIDELITY-v1.md](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/REPLAY-AND-FIDELITY-v1.md)
- [INVESTIGATION-v1.md](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/INVESTIGATION-v1.md)
- [SOURCE-INVENTORY-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/SOURCE-INVENTORY-v1.json)
- [FORMAL-ACCOUNTING-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/FORMAL-ACCOUNTING-v1.json)
- [src/IndependentAudit.lean](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/src/IndependentAudit.lean)
- [audit91.output.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/audit91.output.txt)
- [audit91.receipt.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/audit91.receipt.json)
- [audit92.output.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/audit92.output.txt)
- [audit92.receipt.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/audit92.receipt.json)
- [strict_extract_v3.py](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/strict_extract_v3.py)
- [extraction-ledger-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/extraction-ledger-v1.json)
- [strict-v3-validation.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/strict-v3-validation.json)
- [CORRECTION-LEDGER-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/CORRECTION-LEDGER-v1.json)
- [pin-verification-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/pin-verification-v1.json)
- [bridge-interfaces-v1.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/bridge-interfaces-v1.txt)
- [exact_check_v1.py](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/exact_check_v1.py)
- [exact-check-v1.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/exact-check-v1.json)
- [exact-check-run1.receipt.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/exact-check-run1.receipt.json)
- [frozen-before.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/frozen-before.json)
- [frozen-after.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/frozen-after.json)
- [SHA256SUMS.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/SHA256SUMS.json)
- [seal.receipt.json](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/seal.receipt.json)
- [seal.output.txt](/home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/seal.output.txt)

Production payloads are in /home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/src and byte-exact documentary extraction in /home/mj-kang/Documents/Dev/math/openai-proof-research/frontier/campaigns/2026-10-27/new-discoveries-batch2/new-twenty-2026-10-31/harada-partition-independent-strict-replay-sol-r1/extracted. Every c01..c45/k01..k45 label has .receipt.json, .output.txt and .display.txt files at this root; FORMAL-ACCOUNTING links their records. All other documentary call receipts/full outputs and failed versions remain physically present and are covered by the terminal manifest.
