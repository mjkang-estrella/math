# A Gaussian envelope for Hermite polynomials

We prove Guo–Liu's full literal Hermite-envelope conjecture. A sine comparison gives enough strict energy loss in odd degree to attain the exact Gamma-normalized coefficient. A real-root moment inequality controls stationary peaks after the cutoff and supplies the clamped tail. Actual Rodrigues Hermite polynomials, the precise source cutoff and every assembly bridge are proved in Lean. Classical oscillator, Wallis and polynomial tools and known low/even-degree cases are credited.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE full explicit source-conjecture outcome; known even/low-degree cases, classical tools, helpers and experiments are uncredited.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: e912228169c241abc1aeeab5d6fac977f1335359afff1275292b2253640a24a8. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Bounded independent prior-art screen; adjacent MDPI2026 fractional-Hermite body unread and no exhaustive subscription-index coverage; no worldwide-priority claim.
