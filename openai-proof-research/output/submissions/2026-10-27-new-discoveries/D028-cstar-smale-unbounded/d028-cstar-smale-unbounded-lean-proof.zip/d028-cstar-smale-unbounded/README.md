# No finite C*-Smale mean-value constant at degree three

Over the fixed connected algebra C([0,1],C), no finite constant controls the first-order Smale norm divided difference for all split monic cubics. For every proposed constant, a continuous cubic family has an invertible test derivative and exactly two existing critical elements, both violating the bound. The full quantified theorem is proved in Lean. This is a stronger infinite-constant theorem, not the first refutation of the scalar or C*-constant-one conjecture, which was publicly refuted before this work.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE infinite-class family theorem absorbs rejected fixed witness (credit0); no first-resolution, degree2, selection-tool, HIGHERMEAN or DUALSMALE side credit.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 0343cecf3c8a5dc337a6e6a2f3ba1aa1caf950a3dadebbdc131bd03cf47c9076. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Marginal-parameter-refinement objection explicitly weighed by parent and two independent reviews; full quantifier and fixed-connected-algebra infinity theorem deemed substantive; Bounded DuckDuckGo/registry/arXiv/selection literature screen; no worldwide-priority guarantee; Exa429, no exhaustive subscription-index search; public scalar proofs not re-audited and not dependencies
