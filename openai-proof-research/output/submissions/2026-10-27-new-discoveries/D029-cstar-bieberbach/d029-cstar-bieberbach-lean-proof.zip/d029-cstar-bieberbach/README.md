# An injective C*-power series violating the Bieberbach coefficient bound

A normalized norm-entire power series on C([0,1],C) is globally injective and has an everywhere norm-convergent formal derivative series, but its second coefficient violates the general C*-Bieberbach order bound. A continuous exponential period anchored at zero proves global injectivity without assuming univalent scalar fibers. Lean proves the full source Conjecture 1.2/1.4 counterexample as one common outcome. Invertible-coefficient, polynomial, Robertson and Lebedev–Milin variants remain unclaimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE combined general-coefficient source outcome; fixed8t formalized, invertible-coefficient/polynomial/Robertson/Lebedev-Milin/parameter-family results unclaimed or uncredited.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 9a46032946dab2785c8397d0c127f658bff46b57649450d7aa4e079d145d4096. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

DirectPreprintsPDF403 persists; actual authorZenodo6917925 bytes and fresh live md5 verified, normalized source text agrees, no binaryidentityclaim; Bounded citation/web/superposition/registry screen, not worldwide-priority certification; SemanticScholar429 and no exhaustive subscription-index search
