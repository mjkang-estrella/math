# Unit-circle nonvanishing for rational Hartogs-triangle polynomials

For every coprime pair m>n>=1, the polynomial in Edholm–Mathew Conjecture 4.20 has no root on the unit circle and exactly m-n roots in the punctured unit disc, counted with multiplicity. A finite coefficient reindexing gives a sum of squared floor-polynomial values, and an adjacent-polynomial difference makes it strictly positive. The source coefficient bridge and full polynomial theorem are proved in Lean; older kernel identities are credited.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

One full Edholm–Mathew Conjecture4.20 resolution: all coprime0<n<m, no unit-circle roots and exactlym−n punctured-disc roots counted with multiplicity. Known differences, old Fourier/kernel identities, helpers and analytic consequences are not separate counts.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 91016233e33cebd53832e3806c1e408d733dcb0869cb76722720df0d320a42d6. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Actual full June2026 target and published Almughrabi2023 body read. Older weighted roots-of-unity identity explicitly credited; no previous full strict boundary conclusion found. Source-mentioned in-preparation successor not located/read; unpublished or absolute worldwide priority not certified.
