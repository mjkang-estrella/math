# A continuous critical-branch obstruction to C*-algebraic Sendov conjectures

A cubic over C([0,1],C) has roots of norm at most 9/10, a completely split derivative with two distinct continuous critical branches, and strictly positive continuous convex weights. Nevertheless every critical element has supremum distance greater than 21/20 from a fixed root. This refutes the published C*-Sendov Conjectures 3 and 4 as one common outcome. The scalar Sendov problem and the separate density-of-invertibles formulation are not formally claimed resolved.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE cubic in the actual commutative unital C*-algebra C([0,1],C). Roots norm<=9/10, completely split derivative, exactly two continuous critical branches, strict positive convex weights; EVERY critical element has supremum distance>21/20 from a fixed root. Both formulations one outcome. No formal353908 density-of-invertibles claim; scalar Sendov untouched.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: edc55d97791f86b9ef0b14b2253cac98dd919d5bdbbe19872b9c5487c98d3d26. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No prior source-conjecture counterexample found in inspected primary/citing/author/selection literature. Subscription indexes, exhaustive non-English coverage unavailable; bounded screen does not certify worldwide priority. Parent addendum qualifies initial failed supplemental audit logs and numerical one-branch indentation; independent strict136replay and parent extracted replay clean.
