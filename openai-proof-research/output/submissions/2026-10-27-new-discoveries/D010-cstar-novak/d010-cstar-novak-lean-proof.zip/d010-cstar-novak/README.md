# A Hermitian counterexample to C*-algebraic Novak positivity

We construct four self-adjoint inputs with two coordinates in M_2(C) for which the literal exponential-defined Novak kernel is Hermitian but not positive semidefinite. An explicit quadratic form equals cos(pi*sqrt(15))-3 and is at most -2. This refutes Krishna's C*-algebraic extension; the scalar and commutative Novak theorems are unaffected. The matrix construction and exact failure are proved in Lean.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE refutation of Krishna published Conjecture4.2 / preprint4.3 in M2(C), n4,d2. Actual self-adjoint inputs, genuine exponential-defined cosine and literal Hermitian8x8source matrix with exact quadratic form cos(pi sqrt15)−3≤−2. Scalar/commutative Novak theorems untouched; no helper or centered/uncentered extra credit.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 17e8a352cba22a593112414698826b7df860d011fca6c3432c61beb526bfcb17. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No prior full source-conjecture refutation found in inspected primary/citing literature. Classical radial-kernel mechanisms credited; Semantic Scholar corpus is incomplete, subscription indexes and systematic non-English search unavailable. Independent numerical precision/index-comment errors reconciled by parent addendum. No absolute worldwide priority certified.
