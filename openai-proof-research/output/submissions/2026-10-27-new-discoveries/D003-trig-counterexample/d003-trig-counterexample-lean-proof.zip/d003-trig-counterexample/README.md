# An exact counterexample to trigonometric positivity for square roots of geometric sums

We refute Kovalev Conjecture 1.3 using d=49, partial-sum index 949 and t=arccos(523/527). A finite integer certificate proves strict negativity of the literal trigonometric sum from the normalized square-root Taylor coefficients. The coefficient recurrence, cosine bridge and source counterexample are proved in Lean. The separate zero-free conjecture and minimality are not claimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

One counterexample to Kovalev Conjecture1.3, no zero-free Conjecture1.2 or minimality claim.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: b66de396960f2d60b6fd92c1d6aec5c88bdca9958fad3c661fec30e168f046f8. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Actual 2026 published body retains the conjecture. No prior counterexample located; finite searches cannot certify absolute priority.
