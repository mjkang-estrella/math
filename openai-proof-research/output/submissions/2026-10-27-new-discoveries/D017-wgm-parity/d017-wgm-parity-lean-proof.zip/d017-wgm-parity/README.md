# Odd-total lower bound for simple SOC representations

If positive integer weights have odd total, every literal simple second-order-cone representation of their weighted geometric mean has at least as many constraints as original variables. This answers Wang's 2024 Section 7 open question (2), rather than newly resolving the older cardinality bound in the related MathDB record. The proof initially allows repeated indices, self-loops and cycles; the structural and parity conclusions follow from soundness. The full representation endpoint is proved in Lean.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE universal parity lower bound, no extra credit for old m-1/log cardinality bounds, flow lemmas or cases. No sharpness claim.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: b5d300aa4414b5406a410a1be9a6ed16edfaf7852e5500a9a3ee788496654dfd. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Alzalg2026 technical full body unread; No MathSciNet/zbMATH sweep; No absolute worldwide priority claim
