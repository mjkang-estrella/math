# A cubic counterexample to three C*-algebraic polynomial inequalities

One degree-three matrix construction refutes Krishna's C*-algebraic Schoenberg, de Bruin–Sharma and Kushel–Tyaglov conjectures. The ordered deletion derivative factors for every complex matrix argument, including noncommuting arguments. Both adjoint versions of each proposed inequality fail through exact negative quadratic forms. Lean proves the factorization and all six Hermitian failures. The common construction counts as one outcome; classical scalar results are unaffected.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE common nonnormal-involution construction. Degree3M2(C), centered genuine roots(R,-2R,R), genuine critical factors(I,-I), ordered derivative factorization for EVERY complex matrix argument, all six literal defects Hermitian/nonPSD. Scalar classical theorems untouched; no separate conjecture/direction/helper or optional family count.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 71b02b1d0f76c731050f6b4332d6144daec2c6eb6cd08e03093101d8f178071e. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Independent primary/citing/companion search found no prior refutation or subsuming negative theorem. Subscription indexes and systematic worldwide coverage unavailable. Parent addendum corrects ancillary review alternative-coefficient arithmetic, stale script docstring and an optional tautological loop; unchanged complete literal-source Lean and paper unaffected. No absolute priority guarantee.
