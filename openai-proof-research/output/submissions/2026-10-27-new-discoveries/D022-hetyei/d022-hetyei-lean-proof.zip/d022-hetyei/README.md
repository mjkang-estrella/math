# All-order adjacent-count inequality for the flat Bernoulli game

We prove the adjacent-count inequality in Hetyei Conjecture 6.10 for every n>=12. After factorial normalization, a renewal sequence has negative increments from index 11 onward. Symmetric arrowhead matrices, weighted power inequalities and exact finite checks propagate the sign. The literal ordered-composition factorial count and every spectral, recurrence and limit bridge are proved in Lean. The source sign typo, helpers and finite checks do not count as separate results.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE combined full all-order source-conjecture resolution. The source enumeration theorem is credited upstream; all explicit finite count, composition, factorial, matrix, spectral, recurrence and limit bridges proved. Helpers, finite checks, source sign typo and metadata corrections uncounted.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: cd012536efdfc191af14ab0a0fc30b67788fb131f410f8a201cc0b09fa1aa099. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Final JCTA/Sterling body and comprehensive worldwide coverage remain unavailable; bounded independent screen found no known resolution. No worldwide-priority claim.
