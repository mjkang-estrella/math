# Nonconvergence of randomized subtraction games with odd moves

For every finite nonempty set of positive odd subtraction moves, with uniform choice among the legal moves, the probability of winning for the player to move does not converge as the heap grows. A positive finite-window invariant proves the result without a coprimality or root-simplicity assumption. This answers the separate all-odd nonconvergence assertion in Capitelli and Somma; the different MathDB root-simplicity conjecture is not resolved.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

One source-question resolution, bypassing the separate root-simplicity conjecture. No separate counts for invariant, zigzag or known small-cardinality cases.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 85194069ee35ae8d3a2b92f6d97ec42b9b009af933639075df50e71c9d2f4d96. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No earlier full resolution or directly subsuming theorem found in inspected primary literature; finite searches do not certify absolute priority.
