# Uniform Burnside–Gautschi bound for interpolated gamma values

Schmidlin Conjecture 37 holds strictly for every nonnegative base point and, more generally, every nonnegative interpolation parameter. A classical Stirling remainder bound, logarithmic entropy estimate and translated positive-discriminant certificate prove the comparison. The literal gamma-function expression, source domain and all supporting inequalities are proved in Lean. Classical estimates and the previously established x>=1 range are credited; no optimal constant is claimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE combined full source-conjecture resolution. Classical Stirling/entropy estimates and source-known x>=1 range uncredited. No optimality or worldwide-priority claim.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: fff48a37651bb893543560c7b194112e0f6f61ced47ab2e4091c9f00398fb1f9. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Wang2016 full body inaccessible; bounded independent screen found no known prior resolution, no worldwide-priority claim.
