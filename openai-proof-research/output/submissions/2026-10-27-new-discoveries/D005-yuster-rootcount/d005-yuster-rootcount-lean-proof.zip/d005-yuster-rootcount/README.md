# Four interior roots in Yuster's entropy polynomial

At k=48, the canonically parameterized polynomial in Yuster Conjecture 3.9 has at least four distinct roots strictly between zero and one. Rational parameter enclosures and five exact sign checks give the certificate. Lean proves the literal coefficients, parameter condition, four real roots and root-count contradiction. No smallest example, exact total root count or refutation of the separate known entropy inequality is claimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

One counterexample, no minimality/exact total root count/extra Wakhare formal endpoint or entropy result.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 910b35cde2310248bbf01f0193e0f21bd3311251531287a4e6565455476c9ec2. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No prior root-count refutation located. Full later Yuster–Yashfe manuscript not located; Wakhare publisher full body not separately read. Closest actual primary arXiv sources and known true entropy theorem compared and credited.
