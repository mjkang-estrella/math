# An alternating Turán inequality for normalized Euler numbers

We prove Sokal Conjecture 3.3 for every starting index n>=0 and positive shifts j,k, using the actual normalized Taylor coefficients of sec(t)+tan(t). Classical partial fractions, a uniform positive-error contraction and four parity cases establish the sign. The generating-function identity, all coefficient bridges and the complete source inequality are proved in Lean. Known subsequence results, partial fractions and finite experiments are credited rather than counted separately.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE full source-conjecture resolution. Known subsequence results, partial fractions, finite experiments, standard analysis and helpers are uncredited.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 6ab39a8083fe29a6cd29f5c9f02030cd888a7ac126c1e293077da50b0926911b. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Bounded independent prior-art screen; twelve citing bodies inspected, some typeset bodies and comprehensive database coverage unavailable; no worldwide-priority claim.
