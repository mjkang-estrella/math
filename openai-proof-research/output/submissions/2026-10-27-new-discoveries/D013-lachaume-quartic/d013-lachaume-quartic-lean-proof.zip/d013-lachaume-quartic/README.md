# Positive diagonal concavity does not imply concavity for elementary-symmetric sums

The four-variable polynomial f=1+2*sigma_1+sigma_2+2*sigma_3+sigma_4 has strictly positive coefficients and a diagonal fourth root concave on the entire positive axis, while f^(1/4) is not concave on the positive orthant. An exact identity and a strictly interior rational midpoint certificate refute Lachaume Conjecture 1. The literal elementary symmetric functions and regularity are proved in Lean. The older real-rootedness-converse failure is explicitly uncredited.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE literal Conjecture1refutation: n=p4, positive coefficients(1,2,1,2,1), actual C²fourth root, universal positive-diagonal concavity but exact strict midpoint violation inside the positive orthant. Ancillary sourceConjecture3 failure is KNOWN by translation of Zaimi2016 and receives no credit. No helpers, conjecture labels, alternate witnesses or old converse credit.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: aab52c0df93bf81b3037097e1f71964d6b83654bc498bd5db6b5785376456278. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No earlier Conjecture1refutation found in inspected primary/citing/companion sources. Actual2019citingSection5/Theorem4.17read byparent and finalreviewer; typesetJMP2018body and subscription-index/worldwide coverage remain unavailable. Original preliminary translation/positivity-range errors corrected and independently rechecked. No absolute priority guarantee.
