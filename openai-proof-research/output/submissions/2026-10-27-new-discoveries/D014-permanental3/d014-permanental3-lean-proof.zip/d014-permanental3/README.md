# Sharp universal constants for the 3 by 3 permanental Koteljanskii ratio

For every real strictly totally positive 3 by 3 matrix, the source permanental Koteljanskii ratio lies strictly between 2/3 and 9/8, and both constants are optimal. Positive scalings reduce the proof to two polynomial certificates; strictly totally positive families approach the bounds. The result answers the explicit optimal-constant question accompanying Skandera–Soskin Proposition 11. It does not resolve the separate MathDB Sihong conjecture or claim the known boundary example as new.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE combineduniversalsharpbound2/3<R<9/8 forallrealstrictTP3, bothoptimalconstants; literalallminorsandpermanents. Known9/8boundaryvalue, R<=1failures, witnesses, helpers uncounted. DifferentMathDB363360Sihongquestionnotresolved.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: b015d52e4b6396a47a0d9a3045c1ea29e6f8c59a7706325fee363d29084a6d95. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Explicitinformalsourcequestion ratherthannumberedconjecture. No prioruniversalsharpboundorimmediatesubsumingtheoremlocated in boundedindependentprimary/citingscreen. Oneindexedconvolutionciterabstractonly; BarrettJohnsontypesetversionnotseparatelyread; noMathSciNet/zbMATH/worldwidepriorityguarantee.
