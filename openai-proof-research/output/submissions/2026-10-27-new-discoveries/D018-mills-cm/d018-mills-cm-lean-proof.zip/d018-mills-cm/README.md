# A fortieth-derivative obstruction to the Mills-ratio complete-monotonicity conjecture

For the actual Gaussian Mills ratio r, the quotient -r^2/r' has negative fortieth derivative throughout some interval of strictly positive regular inputs. This refutes Ferreira–Simon Conjecture 3 already at n=0. A degree-21 integer polynomial in pi/2, rational Bernstein bounds and continuity supply the certificate. The Gaussian tail, derivative identification and interior conclusion are proved in Lean. No minimal derivative order or contradiction of the square-root-input proposition is claimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE source-conjecture refutation; no order40 minimality, no every-individual-n claim, no contradiction of the known square-root-input Proposition10.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 1721653c54bd6ca2138c14219c716e355d7d2fb120477773fffa9d083563f633. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No MathSciNet/zbMATH/direct Scopus sweep; OpenAlex3 records are not exhaustive; one Fox linkage erroneous; actual bodies and additional leads compared; No absolute worldwide priority claim
