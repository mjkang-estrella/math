# Partition coefficients for generalized peakon transfer matrices

We give a universal factorial formula for every partition coefficient in every positive trace power of the source generalized peakon Lax matrix, for all particle numbers. A curve-conditioned rank-two determinant collapse and the formal trace-log identity prove the formula and both printed families. Lean covers arbitrary coherent complex particle amplitudes and the literal square-root matrices at nonnegative real momenta. Classical determinant and multinomial tools and known families are uncredited as separate outcomes.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE full source-question outcome; classical determinant/Jacobi/trace-log/multinomial tools, already conjectured families, helpers and checks uncredited.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: b5b17dededcc7c18e3273101de18b87b88a6da68272776d010adb1cf013bb49e. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Bounded selective semiseparable/full Kostant-Toda/peakon literature and one functioning web engine; no worldwide-priority guarantee; MathDB companion IDs and first-stated-year metadata unreliable and not relied on; No exhaustive subscription-index search
