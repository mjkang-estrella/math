# Negative-order Vendi–LCR comparison without a full-rank assumption

For finite positive semidefinite similarity matrices with diagonal one and entries between zero and one, we prove the uniform Vendi–LCR comparison at every negative order using the positive spectral support evidenced in the source implementation. A spectral Jensen argument also proves the directly defined minus-infinity endpoint. Classical Jensen and Holder–McCarthy inequalities and known nonnegative/full-rank cases are credited. No analytic order-limit theorem or weighted-distribution formal extension is claimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

One uniform comparison at all finite q<0 and directly defined minus-infinity endpoint, on source-evidenced positive spectral support. Known nonnegative/fullrank cases, classical Jensen ingredient and equivalent power-sum statement uncredited. No formal analytic order-limit or weighted-p bridge.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: c812cfdf49064343a6936c704394b7e59068528cb67f952b85e34f15d93c872d. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

PRE final full body unread; current primary abstract retains fullranknegative restriction. Later Bioengineering article broadly asserts comparison citing PRE without separate singular-negative proof. Classical Jensen/Hölder–McCarthy and all known source cases credited; no earlier demonstrated full support comparison found.
