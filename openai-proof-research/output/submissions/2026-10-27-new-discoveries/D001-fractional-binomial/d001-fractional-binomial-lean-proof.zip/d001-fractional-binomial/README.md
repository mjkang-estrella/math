# A sharp converse fractional-binomial inequality through log-convexity

We prove the converse fractional-binomial inequality posed by Gerhold and Simon as Conjecture 3.2, together with a biased refinement and optimality of the coefficient. Log-convexity of a finite sum of scaled Gamma quotients and its values at parameters one and two give the comparison. The Gamma-convexity ingredient is classical and explicitly credited. The Lean certificate covers the precise source statement, refinement and sharpness.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

One combined resolution of Gerhold–Simon Conjecture 3.2; includes biased bound and optimality, no separate counts.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: baf26ba9f238e40f6fa3efa5a990b3c2b1a5a02dbdefa62cefd7a223ee9ebd15. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No prior full sharp finite-sum resolution located. Alzer full article inaccessible; exact classical summand theorem and corollary types checked in two accessible primary successors. Absolute worldwide priority not certified.
