# Strict connection–Dirac spectral dominance for every finite graph

For every nonempty finite graph simplicial complex and each permitted k, the sum of the k largest connection-matrix eigenvalues exceeds the corresponding signed-Dirac sum by at least sqrt(2)-1. Isolates and disconnected graphs are included. This proves the entire dimension-at-most-one case of Knill's conjecture, not the higher-dimensional statement. All incidence, spectral and literal face-family bridges are proved in Lean; no optimal gap is claimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONEgeneraltheorem forallnonemptyfinitegraphcomplexes/all1<=k<=#faces: S_k(L)-S_k(D)>=sqrt2-1>0. Includesisolates/disconnectedgraphs/triangleboundaries/unusedambientvertices. Higherdimensionalquestionnotclaimedsolved.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 5600ec36e8b4d690564d67ead1a762e8125ebd08cf69fddd00c602f46ac77a7c. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No prior all-k signed comparison located in inspected primary/citing/author sources or supplementarywebsearch. Generic hydrogen/KyFan/SchurHorn/Loewner facts credited. Coveragebounded; noabsolutepriorityclaim. Canonicalorientationformalized; nooptimalgapclaim.
