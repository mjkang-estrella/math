# An odd-degree identity for polynomial values at derivative roots

We prove Wojnar, Wojnar and Brin Conjecture 2 for every complex polynomial of odd degree, with derivative roots counted with multiplicity. Normalized Newton moments extend the means polynomially in the remaining degree; an apolar self-pairing and finite differences yield the identity. The literal source means and arbitrary-polynomial endpoint are proved in Lean. Classical Newton, apolarity and finite-difference ingredients are credited.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

One full arbitrary odd-degree complex-polynomial Conjecture2 resolution, with repeated roots and exact source means. No per-degree/helper/other-conjecture counts.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 6d67e327be472c2bae0dedde767d5b6146831a981ef8ce62d2e5ce28c651587d. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Toda1934 full body unread; actual1936/1940 neighboring formulas and classical apolarity read/credited. Independent review found no explicit old stronger source endpoint and recommends acceptance under documented-prior/no-known-resolution standard with this material limitation. Absolute priority not certified.
