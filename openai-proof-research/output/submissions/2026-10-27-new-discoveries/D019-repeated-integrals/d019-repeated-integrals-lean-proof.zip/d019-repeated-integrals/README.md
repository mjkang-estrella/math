# All-order smooth realization of increasing repeated-integral endpoint jets

We prove Burke–Haris–Madhavendra Conjecture 1.2 for every order, including order zero. An atomless Stieltjes measure has a strictly positive smooth density realizing its finitely many moments and equal to one near the endpoints. Separation, an explicit bump-moment openness argument and repeated integration give the full source endpoint-jet statement. All measure, kernel, openness and endpoint bridges are proved in Lean. Standard moment technology and the previously known low-order cases are credited.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE full source-conjecture resolution using standard moment tools; known n<=3 cases, library machinery and conditional sequel consequences receive no separate credit.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: fc7a025de5a87fcd760668689f26f32db4271b18c076943364668f0f0c100e42. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Standard moment tools credited, including di Dio theorem bodies compared; no claim of new general machinery; No MathSciNet/zbMATH sweep; bounded prior-art investigation does not certify worldwide priority
