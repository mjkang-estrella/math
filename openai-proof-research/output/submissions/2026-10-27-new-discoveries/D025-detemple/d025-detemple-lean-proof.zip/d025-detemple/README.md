# A failure of the DeTemple complete-monotonicity threshold

We refute the sufficient direction of Yang–Chu–Zhang Conjecture 1(ii) at a strictly positive parameter strictly below 155/294. The literal gamma/digamma quotient violates a positive-input midpoint inequality, hence its proposed negative is not completely monotone. The existential strictly interior source refutation is proved in Lean; the separately calculated rational witness is mathematical evidence, not the formal endpoint. Part (i) and an exact replacement threshold are not claimed.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE strictly interior refutation of the source CM sufficient condition; part(i), an exact replacement threshold and the specific rational witness as Lean endpoint are unclaimed.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: c55304d8805c27766eb5d48a598953e0ab535d052763f25e3678314847b34d3e. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Bounded independent prior-art screen; closest JMAA gamma-ratio remainder body remains paywalled; no worldwide-priority claim.
