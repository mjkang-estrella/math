# Convexity of the Le Roy parameter threshold

For every gamma>1, the literal positive-admissibility threshold in Simon's paper is convex on (0,1/gamma). Rescaling expresses it as a supremum of positive perspectives; finiteness and positivity identify that supremum with the source infimum. This resolves the separate threshold-convexity question at the end of Section 3. The main complete-monotonicity iff conjecture remains unclaimed. The exact infimum–supremum identification and convexity endpoint are proved in Lean.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE combined separate-source-question resolution. The main CM-iff conjecture, informal strict curvature, source-known ratio monotonicity and standard perspective/supremum tools receive no credit.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 0b0da074bb68cad4e5fc5429b1108eb840ce399f9bdb32abfe7dea513107c23a. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Bounded independent eligibility/prior-art screen; publisher and four citing bodies unread; classical perspective step credited, no worldwide-priority claim.
