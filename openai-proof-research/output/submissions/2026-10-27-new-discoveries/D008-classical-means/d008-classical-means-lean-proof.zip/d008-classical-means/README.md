# Classical-mean power sums: the exact real-exponent ranges

For the arithmetic, geometric, harmonic and quadratic means A,G,H,Q of two positive inputs, the inequality A^n+G^n<=Q^n+H^n holds universally exactly when n<=0 or n>=1. The reverse holds universally exactly at n=0. This gives one complete real-exponent classification resolving the published Mestrovic–Andjic conjecture, including strict failures in its asserted interval. Both classifications and the actual positive-input witnesses are certified in Lean.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE combined Meštrović–Andjić Conjecture1.5 (preprint1.6) resolution: forward universal exactly n≤0 or n≥1, reverse universal exactly n=0. Substantive counterexamples for every 0<n<1, including asserted 1/2≤n<1. No separate direction, endpoint, witness, helper or known integer count.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 296974db2e7f2d9acbd288430a7b658c285fa9df5cd1e6df71f13b919d459927. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Actual published source and nearest primary comparisons inspected; no known earlier full classification found. MathSciNet/zbMATH unavailable, Sándor survey only partially extractable; bounded literature search does not certify absolute worldwide priority. Parent corrected original review prose errors; unchanged complete reports retained.
