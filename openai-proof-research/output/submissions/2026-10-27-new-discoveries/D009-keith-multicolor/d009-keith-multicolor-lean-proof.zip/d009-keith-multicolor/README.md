# A strict valley in Keith's multicolor partition array

A three-color box-partition array for the 25 by 25 box at size 325 has three consecutive points on a line of step (1,-2) with coefficients 53130, 50600 and at least 52900. This refutes Keith's multicolor linear-cut unimodality conjecture. The actual generating polynomial and an injection establishing the last bound are proved in Lean. The original Dousse–Kim two-color conjecture remains untouched.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE source-question refutation: M=N25,n325,k3,x3=1,full lattice line y45−2x. Formal coefficient bounds53130,50600,third≥52900. Actual box partitions and coefficient/injection bridges proved; original two-color Dousse–Kim conjecture not refuted. No credit for individual coefficients, helpers, boxes or research-only variable-N family.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: 5b91fca46c28e6f4bcac2fab15fd10fb5bda5d9aeb757a049de9868b725be01f. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

Actual arXiv source and predecessor inspected; independent search found no known prior multicolor resolution. Final typeset Keith body unread after403; Wagner thesis assessed through official abstract/chapter descriptions, complete body unread. Citing-body coverage bounded, no exhaustive2026/worldwide priority claim. Parent addendum clarifies report wording.
