# Sharp maximal index for separately sorted arithmetic and geometric means in every dimension at least five

For each probability vector in dimension d>=5, form and independently sort all d^2 ordered arithmetic means and all d^2 ordered geometric means. The sum of their respective largest k entries is at most d for every probability vector exactly when k<=2d-5. Incidence bounds, Cauchy–Schwarz and a sharpness family prove the classification. The complete separately sorted source statement is certified in Lean.

AI-assisted preprint by Myeongjin Kang, with no affiliation. Internal AI review is not external journal peer review. The accompanying Lean certificate covers the precise scoped main statement; inspect the formal endpoint, assumptions and provenance in the supporting package. Prior-art investigations are documented bounded searches, not worldwide-priority certification. Original prose is offered under CC BY 4.0 and original code/Lean under MIT; third-party rights and existing notices are preserved. The public supporting ZIP contains original proof sources and verification evidence, with bibliographic links and hashes instead of redistributed third-party source manuscripts.

## Exact scope

ONE combined source-question resolution: for every d≥5 and 0≤k≤d², the full probability-simplex universal bound for independently sorted ordered arithmetic/geometric arrays holds iff k≤2d−5. No dimensions, helpers, directions, witnesses or small-d research extra credits.

## Replay

Use the pinned Lean version and compiled mathlib/dependency revisions in verification/pins.json. From this extracted package run:

    python3 verification/verify_candidate.py . --lean-bin /path/to/lean --packages /path/to/.lake/packages

The proof module bytes, candidate.json, pins and verifier are unchanged from the accepted/replayed research package. Only propext, Classical.choice and Quot.sound are permitted. Reports and metadata may preserve historical preacceptance status; INTERNAL-ACCEPTANCE.json records the later scoped decision. No additional claims follow merely from a publication or an empty database record.

## Provenance and source availability

Accepted internal archive SHA-256: d1ebb869d50c4ba2804ad177c072bfdf07711f0a1ed06a380e34fd1082fcd69f. Its source copies remain locally preserved. SOURCE-REFERENCES.json lists bibliographic links and excluded-member hashes. No removed raw third-party article is an input to the Lean proof. The public package has its own manifest and checksum; it is not represented as byte-identical to the larger internal archive.

## Prior-art limits

No earlier resolution found in inspected primary and full-body citing sources. Citation indexes are incomplete; one published citing body and subscription indexes remain unread. Author listings are not full-body surveys. Parent addendum qualifies review scope; no absolute worldwide priority certified.
