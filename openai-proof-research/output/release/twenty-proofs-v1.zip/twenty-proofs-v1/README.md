# Twenty Lean-verified mathematical outcomes

This collection contains twenty distinct MathDB source-question outcomes.
Each nested ZIP includes a paper, full claimed-outcome Lean proof, source
provenance, independent review, and reproduction instructions. Each package
was rebuilt from an extracted archive before acceptance; every member hash
was checked again when this collection was assembled.

These are not twenty claims of new mathematical discovery. Known-result
formalizations, counterexamples, and explicitly labeled literal-source
corrections are included. Read each package's scope and prior-status notes.
The two arithmetic inequalities share a joint paper and common proof module,
but have distinct source questions and final theorems. No supporting lemma,
dimension, or normalization is counted as an extra outcome.

Extract the desired nested package and follow its README. Lean 4.34.1 and
the pinned, compiled mathlib dependencies are required. The collection
manifest lists the exact SHA256 of every package. See ledger.json for the
individual outcomes and limitations.
